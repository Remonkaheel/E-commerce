/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Base64Variant
/*     */   implements Serializable
/*     */ {
/*     */   private static final int INT_SPACE = 32;
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final char PADDING_CHAR_NONE = '\000';
/*     */   public static final int BASE64_VALUE_INVALID = -1;
/*     */   public static final int BASE64_VALUE_PADDING = -2;
/*     */   
/*     */   public enum PaddingReadBehaviour
/*     */   {
/*  32 */     PADDING_FORBIDDEN,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  38 */     PADDING_REQUIRED,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  45 */     PADDING_ALLOWED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private final transient int[] _asciiToBase64 = new int[128];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private final transient char[] _base64ToAsciiC = new char[64];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private final transient byte[] _base64ToAsciiB = new byte[64];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String _name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final char _paddingChar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int _maxLineLength;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean _writePadding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final PaddingReadBehaviour _paddingReadBehaviour;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64Variant(String name, String base64Alphabet, boolean writePadding, char paddingChar, int maxLineLength) {
/* 148 */     this._name = name;
/* 149 */     this._writePadding = writePadding;
/* 150 */     this._paddingChar = paddingChar;
/* 151 */     this._maxLineLength = maxLineLength;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     int alphaLen = base64Alphabet.length();
/* 157 */     if (alphaLen != 64) {
/* 158 */       throw new IllegalArgumentException("Base64Alphabet length must be exactly 64 (was " + alphaLen + ")");
/*     */     }
/*     */ 
/*     */     
/* 162 */     base64Alphabet.getChars(0, alphaLen, this._base64ToAsciiC, 0);
/* 163 */     Arrays.fill(this._asciiToBase64, -1);
/* 164 */     for (int i = 0; i < alphaLen; i++) {
/* 165 */       char alpha = this._base64ToAsciiC[i];
/* 166 */       this._base64ToAsciiB[i] = (byte)alpha;
/* 167 */       this._asciiToBase64[alpha] = i;
/*     */     } 
/*     */ 
/*     */     
/* 171 */     if (writePadding) {
/* 172 */       this._asciiToBase64[paddingChar] = -2;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 177 */     this._paddingReadBehaviour = writePadding ? PaddingReadBehaviour.PADDING_REQUIRED : PaddingReadBehaviour.PADDING_FORBIDDEN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64Variant(Base64Variant base, String name, int maxLineLength) {
/* 195 */     this(base, name, base._writePadding, base._paddingChar, maxLineLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64Variant(Base64Variant base, String name, boolean writePadding, char paddingChar, int maxLineLength) {
/* 213 */     this(base, name, writePadding, paddingChar, base._paddingReadBehaviour, maxLineLength);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Base64Variant(Base64Variant base, String name, boolean writePadding, char paddingChar, PaddingReadBehaviour paddingReadBehaviour, int maxLineLength) {
/* 219 */     this._name = name;
/* 220 */     byte[] srcB = base._base64ToAsciiB;
/* 221 */     System.arraycopy(srcB, 0, this._base64ToAsciiB, 0, srcB.length);
/* 222 */     char[] srcC = base._base64ToAsciiC;
/* 223 */     System.arraycopy(srcC, 0, this._base64ToAsciiC, 0, srcC.length);
/* 224 */     int[] srcV = base._asciiToBase64;
/* 225 */     System.arraycopy(srcV, 0, this._asciiToBase64, 0, srcV.length);
/*     */     
/* 227 */     this._writePadding = writePadding;
/* 228 */     this._paddingChar = paddingChar;
/* 229 */     this._maxLineLength = maxLineLength;
/* 230 */     this._paddingReadBehaviour = paddingReadBehaviour;
/*     */   }
/*     */   
/*     */   private Base64Variant(Base64Variant base, PaddingReadBehaviour paddingReadBehaviour) {
/* 234 */     this(base, base._name, base._writePadding, base._paddingChar, paddingReadBehaviour, base._maxLineLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64Variant withPaddingAllowed() {
/* 243 */     return withReadPadding(PaddingReadBehaviour.PADDING_ALLOWED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64Variant withPaddingRequired() {
/* 251 */     return withReadPadding(PaddingReadBehaviour.PADDING_REQUIRED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64Variant withPaddingForbidden() {
/* 259 */     return withReadPadding(PaddingReadBehaviour.PADDING_FORBIDDEN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64Variant withReadPadding(PaddingReadBehaviour readPadding) {
/* 271 */     return (readPadding == this._paddingReadBehaviour) ? this : new Base64Variant(this, readPadding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Base64Variant withWritePadding(boolean writePadding) {
/* 283 */     return (writePadding == this._writePadding) ? this : new Base64Variant(this, this._name, writePadding, this._paddingChar, this._maxLineLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readResolve() {
/* 298 */     Base64Variant base = Base64Variants.valueOf(this._name);
/* 299 */     if (this._writePadding != base._writePadding || this._paddingChar != base._paddingChar || this._paddingReadBehaviour != base._paddingReadBehaviour || this._maxLineLength != base._maxLineLength)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 304 */       return new Base64Variant(base, this._name, this._writePadding, this._paddingChar, this._paddingReadBehaviour, this._maxLineLength);
/*     */     }
/*     */     
/* 307 */     return base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 316 */     return this._name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean usesPadding() {
/* 322 */     return this._writePadding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresPaddingOnRead() {
/* 330 */     return (this._paddingReadBehaviour == PaddingReadBehaviour.PADDING_REQUIRED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean acceptsPaddingOnRead() {
/* 339 */     return (this._paddingReadBehaviour != PaddingReadBehaviour.PADDING_FORBIDDEN);
/*     */   }
/*     */   
/* 342 */   public boolean usesPaddingChar(char c) { return (c == this._paddingChar); } public boolean usesPaddingChar(int ch) {
/* 343 */     return (ch == this._paddingChar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PaddingReadBehaviour paddingReadBehaviour() {
/* 351 */     return this._paddingReadBehaviour;
/*     */   }
/* 353 */   public char getPaddingChar() { return this._paddingChar; } public byte getPaddingByte() {
/* 354 */     return (byte)this._paddingChar;
/*     */   } public int getMaxLineLength() {
/* 356 */     return this._maxLineLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int decodeBase64Char(char c) {
/* 371 */     int ch = c;
/* 372 */     return (ch <= 127) ? this._asciiToBase64[ch] : -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int decodeBase64Char(int ch) {
/* 377 */     return (ch <= 127) ? this._asciiToBase64[ch] : -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int decodeBase64Byte(byte b) {
/* 382 */     int ch = b;
/*     */     
/* 384 */     if (ch < 0) {
/* 385 */       return -1;
/*     */     }
/* 387 */     return this._asciiToBase64[ch];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char encodeBase64BitsAsChar(int value) {
/* 400 */     return this._base64ToAsciiC[value];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encodeBase64Chunk(int b24, char[] buffer, int outPtr) {
/* 417 */     buffer[outPtr++] = this._base64ToAsciiC[b24 >> 18 & 0x3F];
/* 418 */     buffer[outPtr++] = this._base64ToAsciiC[b24 >> 12 & 0x3F];
/* 419 */     buffer[outPtr++] = this._base64ToAsciiC[b24 >> 6 & 0x3F];
/* 420 */     buffer[outPtr++] = this._base64ToAsciiC[b24 & 0x3F];
/* 421 */     return outPtr;
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeBase64Chunk(StringBuilder sb, int b24) {
/* 426 */     sb.append(this._base64ToAsciiC[b24 >> 18 & 0x3F]);
/* 427 */     sb.append(this._base64ToAsciiC[b24 >> 12 & 0x3F]);
/* 428 */     sb.append(this._base64ToAsciiC[b24 >> 6 & 0x3F]);
/* 429 */     sb.append(this._base64ToAsciiC[b24 & 0x3F]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encodeBase64Partial(int bits, int outputBytes, char[] buffer, int outPtr) {
/* 447 */     buffer[outPtr++] = this._base64ToAsciiC[bits >> 18 & 0x3F];
/* 448 */     buffer[outPtr++] = this._base64ToAsciiC[bits >> 12 & 0x3F];
/* 449 */     if (usesPadding()) {
/* 450 */       buffer[outPtr++] = (outputBytes == 2) ? this._base64ToAsciiC[bits >> 6 & 0x3F] : this._paddingChar;
/*     */       
/* 452 */       buffer[outPtr++] = this._paddingChar;
/*     */     }
/* 454 */     else if (outputBytes == 2) {
/* 455 */       buffer[outPtr++] = this._base64ToAsciiC[bits >> 6 & 0x3F];
/*     */     } 
/*     */     
/* 458 */     return outPtr;
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeBase64Partial(StringBuilder sb, int bits, int outputBytes) {
/* 463 */     sb.append(this._base64ToAsciiC[bits >> 18 & 0x3F]);
/* 464 */     sb.append(this._base64ToAsciiC[bits >> 12 & 0x3F]);
/* 465 */     if (usesPadding()) {
/* 466 */       sb.append((outputBytes == 2) ? this._base64ToAsciiC[bits >> 6 & 0x3F] : this._paddingChar);
/*     */       
/* 468 */       sb.append(this._paddingChar);
/*     */     }
/* 470 */     else if (outputBytes == 2) {
/* 471 */       sb.append(this._base64ToAsciiC[bits >> 6 & 0x3F]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte encodeBase64BitsAsByte(int value) {
/* 479 */     return this._base64ToAsciiB[value];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encodeBase64Chunk(int b24, byte[] buffer, int outPtr) {
/* 494 */     buffer[outPtr++] = this._base64ToAsciiB[b24 >> 18 & 0x3F];
/* 495 */     buffer[outPtr++] = this._base64ToAsciiB[b24 >> 12 & 0x3F];
/* 496 */     buffer[outPtr++] = this._base64ToAsciiB[b24 >> 6 & 0x3F];
/* 497 */     buffer[outPtr++] = this._base64ToAsciiB[b24 & 0x3F];
/* 498 */     return outPtr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encodeBase64Partial(int bits, int outputBytes, byte[] buffer, int outPtr) {
/* 516 */     buffer[outPtr++] = this._base64ToAsciiB[bits >> 18 & 0x3F];
/* 517 */     buffer[outPtr++] = this._base64ToAsciiB[bits >> 12 & 0x3F];
/* 518 */     if (usesPadding()) {
/* 519 */       byte pb = (byte)this._paddingChar;
/* 520 */       buffer[outPtr++] = (outputBytes == 2) ? this._base64ToAsciiB[bits >> 6 & 0x3F] : pb;
/*     */       
/* 522 */       buffer[outPtr++] = pb;
/*     */     }
/* 524 */     else if (outputBytes == 2) {
/* 525 */       buffer[outPtr++] = this._base64ToAsciiB[bits >> 6 & 0x3F];
/*     */     } 
/*     */     
/* 528 */     return outPtr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(byte[] input) {
/* 548 */     return encode(input, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(byte[] input, boolean addQuotes) {
/* 565 */     int inputEnd = input.length;
/* 566 */     StringBuilder sb = new StringBuilder(inputEnd + (inputEnd >> 2) + (inputEnd >> 3));
/* 567 */     if (addQuotes) {
/* 568 */       sb.append('"');
/*     */     }
/*     */     
/* 571 */     int chunksBeforeLF = getMaxLineLength() >> 2;
/*     */ 
/*     */     
/* 574 */     int inputPtr = 0;
/* 575 */     int safeInputEnd = inputEnd - 3;
/*     */     
/* 577 */     while (inputPtr <= safeInputEnd) {
/*     */       
/* 579 */       int b24 = input[inputPtr++] << 8;
/* 580 */       b24 |= input[inputPtr++] & 0xFF;
/* 581 */       b24 = b24 << 8 | input[inputPtr++] & 0xFF;
/* 582 */       encodeBase64Chunk(sb, b24);
/* 583 */       if (--chunksBeforeLF <= 0) {
/*     */         
/* 585 */         sb.append('\\');
/* 586 */         sb.append('n');
/* 587 */         chunksBeforeLF = getMaxLineLength() >> 2;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 592 */     int inputLeft = inputEnd - inputPtr;
/* 593 */     if (inputLeft > 0) {
/* 594 */       int b24 = input[inputPtr++] << 16;
/* 595 */       if (inputLeft == 2) {
/* 596 */         b24 |= (input[inputPtr++] & 0xFF) << 8;
/*     */       }
/* 598 */       encodeBase64Partial(sb, b24, inputLeft);
/*     */     } 
/*     */     
/* 601 */     if (addQuotes) {
/* 602 */       sb.append('"');
/*     */     }
/* 604 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(byte[] input, boolean addQuotes, String linefeed) {
/* 622 */     int inputEnd = input.length;
/* 623 */     StringBuilder sb = new StringBuilder(inputEnd + (inputEnd >> 2) + (inputEnd >> 3));
/* 624 */     if (addQuotes) {
/* 625 */       sb.append('"');
/*     */     }
/*     */     
/* 628 */     int chunksBeforeLF = getMaxLineLength() >> 2;
/*     */     
/* 630 */     int inputPtr = 0;
/* 631 */     int safeInputEnd = inputEnd - 3;
/*     */     
/* 633 */     while (inputPtr <= safeInputEnd) {
/* 634 */       int b24 = input[inputPtr++] << 8;
/* 635 */       b24 |= input[inputPtr++] & 0xFF;
/* 636 */       b24 = b24 << 8 | input[inputPtr++] & 0xFF;
/* 637 */       encodeBase64Chunk(sb, b24);
/* 638 */       if (--chunksBeforeLF <= 0) {
/* 639 */         sb.append(linefeed);
/* 640 */         chunksBeforeLF = getMaxLineLength() >> 2;
/*     */       } 
/*     */     } 
/* 643 */     int inputLeft = inputEnd - inputPtr;
/* 644 */     if (inputLeft > 0) {
/* 645 */       int b24 = input[inputPtr++] << 16;
/* 646 */       if (inputLeft == 2) {
/* 647 */         b24 |= (input[inputPtr++] & 0xFF) << 8;
/*     */       }
/* 649 */       encodeBase64Partial(sb, b24, inputLeft);
/*     */     } 
/*     */     
/* 652 */     if (addQuotes) {
/* 653 */       sb.append('"');
/*     */     }
/* 655 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decode(String input) throws IllegalArgumentException {
/* 673 */     ByteArrayBuilder b = new ByteArrayBuilder();
/* 674 */     decode(input, b);
/* 675 */     return b.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decode(String str, ByteArrayBuilder builder) throws IllegalArgumentException {
/* 696 */     int ptr = 0;
/* 697 */     int len = str.length();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 704 */     while (ptr < len) {
/*     */ 
/*     */       
/* 707 */       char ch = str.charAt(ptr++);
/* 708 */       if (ch > ' ') {
/* 709 */         int bits = decodeBase64Char(ch);
/* 710 */         if (bits < 0) {
/* 711 */           _reportInvalidBase64(ch, 0, null);
/*     */         }
/* 713 */         int decodedData = bits;
/*     */         
/* 715 */         if (ptr >= len) {
/* 716 */           _reportBase64EOF();
/*     */         }
/* 718 */         ch = str.charAt(ptr++);
/* 719 */         bits = decodeBase64Char(ch);
/* 720 */         if (bits < 0) {
/* 721 */           _reportInvalidBase64(ch, 1, null);
/*     */         }
/* 723 */         decodedData = decodedData << 6 | bits;
/*     */         
/* 725 */         if (ptr >= len) {
/*     */           
/* 727 */           if (!requiresPaddingOnRead()) {
/* 728 */             decodedData >>= 4;
/* 729 */             builder.append(decodedData);
/*     */             break;
/*     */           } 
/* 732 */           _reportBase64EOF();
/*     */         } 
/* 734 */         ch = str.charAt(ptr++);
/* 735 */         bits = decodeBase64Char(ch);
/*     */ 
/*     */         
/* 738 */         if (bits < 0) {
/* 739 */           if (bits != -2) {
/* 740 */             _reportInvalidBase64(ch, 2, null);
/*     */           }
/* 742 */           if (!acceptsPaddingOnRead()) {
/* 743 */             _reportBase64UnexpectedPadding();
/*     */           }
/*     */           
/* 746 */           if (ptr >= len) {
/* 747 */             _reportBase64EOF();
/*     */           }
/* 749 */           ch = str.charAt(ptr++);
/* 750 */           if (!usesPaddingChar(ch)) {
/* 751 */             _reportInvalidBase64(ch, 3, "expected padding character '" + getPaddingChar() + "'");
/*     */           }
/*     */           
/* 754 */           decodedData >>= 4;
/* 755 */           builder.append(decodedData);
/*     */           
/*     */           continue;
/*     */         } 
/* 759 */         decodedData = decodedData << 6 | bits;
/*     */         
/* 761 */         if (ptr >= len) {
/*     */           
/* 763 */           if (!requiresPaddingOnRead()) {
/* 764 */             decodedData >>= 2;
/* 765 */             builder.appendTwoBytes(decodedData);
/*     */             break;
/*     */           } 
/* 768 */           _reportBase64EOF();
/*     */         } 
/* 770 */         ch = str.charAt(ptr++);
/* 771 */         bits = decodeBase64Char(ch);
/* 772 */         if (bits < 0) {
/* 773 */           if (bits != -2) {
/* 774 */             _reportInvalidBase64(ch, 3, null);
/*     */           }
/* 776 */           if (!acceptsPaddingOnRead()) {
/* 777 */             _reportBase64UnexpectedPadding();
/*     */           }
/* 779 */           decodedData >>= 2;
/* 780 */           builder.appendTwoBytes(decodedData);
/*     */           continue;
/*     */         } 
/* 783 */         decodedData = decodedData << 6 | bits;
/* 784 */         builder.appendThreeBytes(decodedData);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 796 */     return this._name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 802 */     if (o == this) return true; 
/* 803 */     if (o == null || o.getClass() != getClass()) return false;
/*     */     
/* 805 */     Base64Variant other = (Base64Variant)o;
/* 806 */     return (other._paddingChar == this._paddingChar && other._maxLineLength == this._maxLineLength && other._writePadding == this._writePadding && other._paddingReadBehaviour == this._paddingReadBehaviour && this._name
/*     */ 
/*     */ 
/*     */       
/* 810 */       .equals(other._name));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 816 */     return this._name.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _reportInvalidBase64(char ch, int bindex, String msg) throws IllegalArgumentException {
/*     */     String base;
/* 835 */     if (ch <= ' ') {
/* 836 */       base = "Illegal white space character (code 0x" + Integer.toHexString(ch) + ") as character #" + (bindex + 1) + " of 4-char base64 unit: can only used between units";
/* 837 */     } else if (usesPaddingChar(ch)) {
/* 838 */       base = "Unexpected padding character ('" + getPaddingChar() + "') as character #" + (bindex + 1) + " of 4-char base64 unit: padding only legal as 3rd or 4th character";
/* 839 */     } else if (!Character.isDefined(ch) || Character.isISOControl(ch)) {
/*     */       
/* 841 */       base = "Illegal character (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*     */     } else {
/* 843 */       base = "Illegal character '" + ch + "' (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*     */     } 
/* 845 */     if (msg != null) {
/* 846 */       base = base + ": " + msg;
/*     */     }
/* 848 */     throw new IllegalArgumentException(base);
/*     */   }
/*     */   
/*     */   protected void _reportBase64EOF() throws IllegalArgumentException {
/* 852 */     throw new IllegalArgumentException(missingPaddingMessage());
/*     */   }
/*     */   
/*     */   protected void _reportBase64UnexpectedPadding() throws IllegalArgumentException {
/* 856 */     throw new IllegalArgumentException(unexpectedPaddingMessage());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String unexpectedPaddingMessage() {
/* 868 */     return String.format("Unexpected end of base64-encoded String: base64 variant '%s' expects no padding at the end while decoding. This Base64Variant might have been incorrectly configured", new Object[] {
/* 869 */           getName()
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String missingPaddingMessage() {
/* 881 */     return String.format("Unexpected end of base64-encoded String: base64 variant '%s' expects padding (one or more '%c' characters) at the end. This Base64Variant might have been incorrectly configured", new Object[] {
/* 882 */           getName(), Character.valueOf(getPaddingChar())
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\Base64Variant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */