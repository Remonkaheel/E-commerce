/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import java.sql.SQLWarning;
/*    */ import org.springframework.dao.UncategorizedDataAccessException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLWarningException
/*    */   extends UncategorizedDataAccessException
/*    */ {
/*    */   public SQLWarningException(String msg, SQLWarning ex) {
/* 45 */     super(msg, ex);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public SQLWarning getSQLWarning() {
/* 55 */     return (SQLWarning)getCause();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(since = "5.3.29")
/*    */   @Nullable
/*    */   public SQLWarning SQLWarning() {
/* 65 */     return getSQLWarning();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\SQLWarningException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */