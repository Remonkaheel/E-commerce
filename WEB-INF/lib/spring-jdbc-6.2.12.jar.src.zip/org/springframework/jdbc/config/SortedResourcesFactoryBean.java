/*    */ package org.springframework.jdbc.config;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.config.AbstractFactoryBean;
/*    */ import org.springframework.context.ResourceLoaderAware;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*    */ import org.springframework.core.io.support.ResourcePatternResolver;
/*    */ import org.springframework.core.io.support.ResourcePatternUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SortedResourcesFactoryBean
/*    */   extends AbstractFactoryBean<Resource[]>
/*    */   implements ResourceLoaderAware
/*    */ {
/*    */   private final List<String> locations;
/*    */   private ResourcePatternResolver resourcePatternResolver;
/*    */   
/*    */   public SortedResourcesFactoryBean(List<String> locations) {
/* 50 */     this.locations = locations;
/* 51 */     this.resourcePatternResolver = (ResourcePatternResolver)new PathMatchingResourcePatternResolver();
/*    */   }
/*    */   
/*    */   public SortedResourcesFactoryBean(ResourceLoader resourceLoader, List<String> locations) {
/* 55 */     this.locations = locations;
/* 56 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 62 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<? extends Resource[]> getObjectType() {
/* 68 */     return Resource[].class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Resource[] createInstance() throws Exception {
/* 73 */     List<Resource> scripts = new ArrayList<>();
/* 74 */     for (String location : this.locations) {
/*    */       
/* 76 */       List<Resource> resources = new ArrayList<>(Arrays.asList(this.resourcePatternResolver.getResources(location)));
/* 77 */       resources.sort((r1, r2) -> {
/*    */             
/*    */             try {
/*    */               return r1.getURL().toString().compareTo(r2.getURL().toString());
/* 81 */             } catch (IOException ex) {
/*    */               return 0;
/*    */             } 
/*    */           });
/* 85 */       scripts.addAll(resources);
/*    */     } 
/* 87 */     return scripts.<Resource>toArray(new Resource[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\config\SortedResourcesFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */