/*    */ package org.springframework.jdbc.config;
/*    */ 
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.AbstractBeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseFactoryBean;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EmbeddedDatabaseBeanDefinitionParser
/*    */   extends AbstractBeanDefinitionParser
/*    */ {
/*    */   static final String DB_NAME_ATTRIBUTE = "database-name";
/*    */   static final String GENERATE_NAME_ATTRIBUTE = "generate-name";
/*    */   
/*    */   protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext) {
/* 59 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(EmbeddedDatabaseFactoryBean.class);
/* 60 */     setGenerateUniqueDatabaseNameFlag(element, builder);
/* 61 */     setDatabaseName(element, builder);
/* 62 */     setDatabaseType(element, builder);
/* 63 */     DatabasePopulatorConfigUtils.setDatabasePopulator(element, builder);
/* 64 */     builder.getRawBeanDefinition().setSource(parserContext.extractSource(element));
/* 65 */     return builder.getBeanDefinition();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean shouldGenerateIdAsFallback() {
/* 70 */     return true;
/*    */   }
/*    */   
/*    */   private void setGenerateUniqueDatabaseNameFlag(Element element, BeanDefinitionBuilder builder) {
/* 74 */     String generateName = element.getAttribute("generate-name");
/* 75 */     if (StringUtils.hasText(generateName)) {
/* 76 */       builder.addPropertyValue("generateUniqueDatabaseName", generateName);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private void setDatabaseName(Element element, BeanDefinitionBuilder builder) {
/* 82 */     String name = element.getAttribute("database-name");
/*    */ 
/*    */     
/* 85 */     if (!StringUtils.hasText(name)) {
/* 86 */       name = element.getAttribute("id");
/*    */     }
/*    */     
/* 89 */     if (StringUtils.hasText(name)) {
/* 90 */       builder.addPropertyValue("databaseName", name);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private void setDatabaseType(Element element, BeanDefinitionBuilder builder) {
/* 96 */     String type = element.getAttribute("type");
/* 97 */     if (StringUtils.hasText(type))
/* 98 */       builder.addPropertyValue("databaseType", type); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\config\EmbeddedDatabaseBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */