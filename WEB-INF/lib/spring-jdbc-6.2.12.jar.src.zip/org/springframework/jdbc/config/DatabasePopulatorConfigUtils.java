/*     */ package org.springframework.jdbc.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.jdbc.datasource.init.CompositeDatabasePopulator;
/*     */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DatabasePopulatorConfigUtils
/*     */ {
/*     */   public static void setDatabasePopulator(Element element, BeanDefinitionBuilder builder) {
/*  44 */     List<Element> scripts = DomUtils.getChildElementsByTagName(element, "script");
/*  45 */     if (!scripts.isEmpty()) {
/*  46 */       builder.addPropertyValue("databasePopulator", createDatabasePopulator(element, scripts, "INIT"));
/*  47 */       builder.addPropertyValue("databaseCleaner", createDatabasePopulator(element, scripts, "DESTROY"));
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static BeanDefinition createDatabasePopulator(Element element, List<Element> scripts, String execution) {
/*  53 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(CompositeDatabasePopulator.class);
/*     */     
/*  55 */     boolean ignoreFailedDrops = element.getAttribute("ignore-failures").equals("DROPS");
/*  56 */     boolean continueOnError = element.getAttribute("ignore-failures").equals("ALL");
/*     */     
/*  58 */     ManagedList<BeanMetadataElement> delegates = new ManagedList();
/*  59 */     for (Element scriptElement : scripts) {
/*  60 */       String executionAttr = scriptElement.getAttribute("execution");
/*  61 */       if (!StringUtils.hasText(executionAttr)) {
/*  62 */         executionAttr = "INIT";
/*     */       }
/*  64 */       if (!execution.equals(executionAttr)) {
/*     */         continue;
/*     */       }
/*  67 */       BeanDefinitionBuilder delegate = BeanDefinitionBuilder.genericBeanDefinition(ResourceDatabasePopulator.class);
/*  68 */       delegate.addPropertyValue("ignoreFailedDrops", Boolean.valueOf(ignoreFailedDrops));
/*  69 */       delegate.addPropertyValue("continueOnError", Boolean.valueOf(continueOnError));
/*     */ 
/*     */       
/*  72 */       BeanDefinitionBuilder resourcesFactory = BeanDefinitionBuilder.genericBeanDefinition(SortedResourcesFactoryBean.class);
/*  73 */       resourcesFactory.addConstructorArgValue(new TypedStringValue(scriptElement.getAttribute("location")));
/*  74 */       delegate.addPropertyValue("scripts", resourcesFactory.getBeanDefinition());
/*  75 */       if (StringUtils.hasLength(scriptElement.getAttribute("encoding"))) {
/*  76 */         delegate.addPropertyValue("sqlScriptEncoding", new TypedStringValue(scriptElement.getAttribute("encoding")));
/*     */       }
/*  78 */       String separator = getSeparator(element, scriptElement);
/*  79 */       if (separator != null) {
/*  80 */         delegate.addPropertyValue("separator", new TypedStringValue(separator));
/*     */       }
/*  82 */       delegates.add(delegate.getBeanDefinition());
/*     */     } 
/*     */     
/*  85 */     if (delegates.isEmpty()) {
/*  86 */       return null;
/*     */     }
/*     */     
/*  89 */     builder.addPropertyValue("populators", delegates);
/*  90 */     return (BeanDefinition)builder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static String getSeparator(Element element, Element scriptElement) {
/*  95 */     String scriptSeparator = scriptElement.getAttribute("separator");
/*  96 */     if (StringUtils.hasLength(scriptSeparator)) {
/*  97 */       return scriptSeparator;
/*     */     }
/*  99 */     String elementSeparator = element.getAttribute("separator");
/* 100 */     if (StringUtils.hasLength(elementSeparator)) {
/* 101 */       return elementSeparator;
/*     */     }
/* 103 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\config\DatabasePopulatorConfigUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */