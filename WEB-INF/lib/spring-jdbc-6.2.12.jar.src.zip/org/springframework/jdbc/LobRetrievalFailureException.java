/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.springframework.dao.DataRetrievalFailureException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.2")
/*    */ public class LobRetrievalFailureException
/*    */   extends DataRetrievalFailureException
/*    */ {
/*    */   public LobRetrievalFailureException(String msg) {
/* 39 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LobRetrievalFailureException(String msg, IOException ex) {
/* 48 */     super(msg, ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\LobRetrievalFailureException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */