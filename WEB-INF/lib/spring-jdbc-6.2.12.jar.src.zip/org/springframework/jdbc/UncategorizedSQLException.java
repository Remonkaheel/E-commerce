/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.UncategorizedDataAccessException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UncategorizedSQLException
/*    */   extends UncategorizedDataAccessException
/*    */ {
/*    */   @Nullable
/*    */   private final String sql;
/*    */   
/*    */   public UncategorizedSQLException(String task, @Nullable String sql, SQLException ex) {
/* 46 */     super(task + "; uncategorized SQLException" + task + "; SQL state [" + ((sql != null) ? (" for SQL [" + sql + "]") : "") + "]; error code [" + ex
/* 47 */         .getSQLState() + "]; " + ex.getErrorCode(), 
/* 48 */         ex);
/* 49 */     this.sql = sql;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public SQLException getSQLException() {
/* 58 */     return (SQLException)getCause();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getSql() {
/* 66 */     return this.sql;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\UncategorizedSQLException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */