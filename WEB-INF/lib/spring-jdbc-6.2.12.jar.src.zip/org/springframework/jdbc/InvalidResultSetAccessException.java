/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidResultSetAccessException
/*    */   extends InvalidDataAccessResourceUsageException
/*    */ {
/*    */   @Nullable
/*    */   private final String sql;
/*    */   
/*    */   public InvalidResultSetAccessException(String task, String sql, SQLException ex) {
/* 50 */     super(task + "; invalid ResultSet access for SQL [" + task + "]", ex);
/* 51 */     this.sql = sql;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InvalidResultSetAccessException(SQLException ex) {
/* 59 */     super(ex.getMessage(), ex);
/* 60 */     this.sql = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public SQLException getSQLException() {
/* 69 */     return (SQLException)getCause();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getSql() {
/* 78 */     return this.sql;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\InvalidResultSetAccessException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */