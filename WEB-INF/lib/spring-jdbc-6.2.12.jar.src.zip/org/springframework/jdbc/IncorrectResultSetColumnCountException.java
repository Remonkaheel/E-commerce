/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import org.springframework.dao.DataRetrievalFailureException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IncorrectResultSetColumnCountException
/*    */   extends DataRetrievalFailureException
/*    */ {
/*    */   private final int expectedCount;
/*    */   private final int actualCount;
/*    */   
/*    */   public IncorrectResultSetColumnCountException(int expectedCount, int actualCount) {
/* 43 */     super("Incorrect column count: expected " + expectedCount + ", actual " + actualCount);
/* 44 */     this.expectedCount = expectedCount;
/* 45 */     this.actualCount = actualCount;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IncorrectResultSetColumnCountException(String msg, int expectedCount, int actualCount) {
/* 55 */     super(msg);
/* 56 */     this.expectedCount = expectedCount;
/* 57 */     this.actualCount = actualCount;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getExpectedCount() {
/* 65 */     return this.expectedCount;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getActualCount() {
/* 72 */     return this.actualCount;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\IncorrectResultSetColumnCountException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */