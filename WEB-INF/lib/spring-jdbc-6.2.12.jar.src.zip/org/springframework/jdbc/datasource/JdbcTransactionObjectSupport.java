/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.sql.Savepoint;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.CannotCreateTransactionException;
/*     */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*     */ import org.springframework.transaction.SavepointManager;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ import org.springframework.transaction.TransactionUsageException;
/*     */ import org.springframework.transaction.support.SmartTransactionObject;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JdbcTransactionObjectSupport
/*     */   implements SavepointManager, SmartTransactionObject
/*     */ {
/*     */   @Nullable
/*     */   private ConnectionHolder connectionHolder;
/*     */   @Nullable
/*     */   private Integer previousIsolationLevel;
/*     */   private boolean readOnly = false;
/*     */   private boolean savepointAllowed = false;
/*     */   
/*     */   public void setConnectionHolder(@Nullable ConnectionHolder connectionHolder) {
/*  64 */     this.connectionHolder = connectionHolder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionHolder getConnectionHolder() {
/*  71 */     Assert.state((this.connectionHolder != null), "No ConnectionHolder available");
/*  72 */     return this.connectionHolder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasConnectionHolder() {
/*  79 */     return (this.connectionHolder != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPreviousIsolationLevel(@Nullable Integer previousIsolationLevel) {
/*  86 */     this.previousIsolationLevel = previousIsolationLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer getPreviousIsolationLevel() {
/*  94 */     return this.previousIsolationLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadOnly(boolean readOnly) {
/* 103 */     this.readOnly = readOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 111 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSavepointAllowed(boolean savepointAllowed) {
/* 119 */     this.savepointAllowed = savepointAllowed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSavepointAllowed() {
/* 126 */     return this.savepointAllowed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createSavepoint() throws TransactionException {
/* 140 */     ConnectionHolder conHolder = getConnectionHolderForSavepoint();
/*     */     try {
/* 142 */       if (!conHolder.supportsSavepoints()) {
/* 143 */         throw new NestedTransactionNotSupportedException("Cannot create a nested transaction because savepoints are not supported by your JDBC driver");
/*     */       }
/*     */       
/* 146 */       if (conHolder.isRollbackOnly()) {
/* 147 */         throw new CannotCreateTransactionException("Cannot create savepoint for transaction which is already marked as rollback-only");
/*     */       }
/*     */       
/* 150 */       return conHolder.createSavepoint();
/*     */     }
/* 152 */     catch (SQLException ex) {
/* 153 */       throw new CannotCreateTransactionException("Could not create JDBC savepoint", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollbackToSavepoint(Object savepoint) throws TransactionException {
/* 163 */     ConnectionHolder conHolder = getConnectionHolderForSavepoint();
/*     */     try {
/* 165 */       conHolder.getConnection().rollback((Savepoint)savepoint);
/* 166 */       conHolder.resetRollbackOnly();
/*     */     }
/* 168 */     catch (Throwable ex) {
/* 169 */       throw new TransactionSystemException("Could not roll back to JDBC savepoint", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseSavepoint(Object savepoint) throws TransactionException {
/* 179 */     ConnectionHolder conHolder = getConnectionHolderForSavepoint();
/*     */     try {
/* 181 */       conHolder.getConnection().releaseSavepoint((Savepoint)savepoint);
/*     */     }
/* 183 */     catch (SQLFeatureNotSupportedException sQLFeatureNotSupportedException) {
/*     */ 
/*     */     
/* 186 */     } catch (SQLException ex) {
/* 187 */       if ("3B001".equals(ex.getSQLState())) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 192 */       String msg = ex.getMessage();
/* 193 */       if (msg == null || (!msg.contains("not supported") && !msg.contains("3B001"))) {
/* 194 */         throw new TransactionSystemException("Could not explicitly release JDBC savepoint", ex);
/*     */       }
/*     */     }
/* 197 */     catch (Throwable ex) {
/* 198 */       throw new TransactionSystemException("Could not explicitly release JDBC savepoint", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected ConnectionHolder getConnectionHolderForSavepoint() throws TransactionException {
/* 203 */     if (!isSavepointAllowed()) {
/* 204 */       throw new NestedTransactionNotSupportedException("Transaction manager does not allow nested transactions");
/*     */     }
/*     */     
/* 207 */     if (!hasConnectionHolder()) {
/* 208 */       throw new TransactionUsageException("Cannot create nested transaction when not exposing a JDBC transaction");
/*     */     }
/*     */     
/* 211 */     return getConnectionHolder();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\JdbcTransactionObjectSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */