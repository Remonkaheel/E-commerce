package org.springframework.jdbc.datasource;

import java.sql.Connection;

@FunctionalInterface
public interface ConnectionHandle {
  Connection getConnection();
  
  default void releaseConnection(Connection con) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\ConnectionHandle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */