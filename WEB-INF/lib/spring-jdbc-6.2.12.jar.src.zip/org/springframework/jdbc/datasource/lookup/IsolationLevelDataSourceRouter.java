/*     */ package org.springframework.jdbc.datasource.lookup;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IsolationLevelDataSourceRouter
/*     */   extends AbstractRoutingDataSource
/*     */ {
/* 102 */   static final Map<String, Integer> constants = Map.of("ISOLATION_DEFAULT", 
/* 103 */       Integer.valueOf(-1), "ISOLATION_READ_UNCOMMITTED", 
/* 104 */       Integer.valueOf(1), "ISOLATION_READ_COMMITTED", 
/* 105 */       Integer.valueOf(2), "ISOLATION_REPEATABLE_READ", 
/* 106 */       Integer.valueOf(4), "ISOLATION_SERIALIZABLE", 
/* 107 */       Integer.valueOf(8));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object resolveSpecifiedLookupKey(Object lookupKey) {
/* 118 */     if (lookupKey instanceof Integer) { Integer isolationLevel = (Integer)lookupKey;
/* 119 */       Assert.isTrue(constants.containsValue(isolationLevel), "Only values of isolation constants allowed");
/*     */       
/* 121 */       return isolationLevel; }
/*     */     
/* 123 */     if (lookupKey instanceof String) { String constantName = (String)lookupKey;
/* 124 */       Assert.hasText(constantName, "'lookupKey' must not be null or blank");
/* 125 */       Integer isolationLevel = constants.get(constantName);
/* 126 */       Assert.notNull(isolationLevel, "Only isolation constants allowed");
/* 127 */       return isolationLevel; }
/*     */ 
/*     */     
/* 130 */     throw new IllegalArgumentException("Invalid lookup key - needs to be isolation level Integer or isolation level name String: " + String.valueOf(lookupKey));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object determineCurrentLookupKey() {
/* 138 */     return TransactionSynchronizationManager.getCurrentTransactionIsolationLevel();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\lookup\IsolationLevelDataSourceRouter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */