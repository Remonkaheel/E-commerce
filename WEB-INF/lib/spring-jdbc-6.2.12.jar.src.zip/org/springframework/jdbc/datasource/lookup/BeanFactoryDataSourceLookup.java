/*    */ package org.springframework.jdbc.datasource.lookup;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanFactoryDataSourceLookup
/*    */   implements DataSourceLookup, BeanFactoryAware
/*    */ {
/*    */   @Nullable
/*    */   private BeanFactory beanFactory;
/*    */   
/*    */   public BeanFactoryDataSourceLookup() {}
/*    */   
/*    */   public BeanFactoryDataSourceLookup(BeanFactory beanFactory) {
/* 62 */     Assert.notNull(beanFactory, "BeanFactory is required");
/* 63 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) {
/* 69 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public DataSource getDataSource(String dataSourceName) throws DataSourceLookupFailureException {
/* 75 */     Assert.state((this.beanFactory != null), "BeanFactory is required");
/*    */     try {
/* 77 */       return (DataSource)this.beanFactory.getBean(dataSourceName, DataSource.class);
/*    */     }
/* 79 */     catch (BeansException ex) {
/* 80 */       throw new DataSourceLookupFailureException("Failed to look up DataSource bean with name '" + dataSourceName + "'", ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\lookup\BeanFactoryDataSourceLookup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */