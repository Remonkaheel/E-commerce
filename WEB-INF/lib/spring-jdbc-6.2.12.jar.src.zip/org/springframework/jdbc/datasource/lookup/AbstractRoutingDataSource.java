/*     */ package org.springframework.jdbc.datasource.lookup;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ConnectionBuilder;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.ShardingKeyBuilder;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jdbc.datasource.AbstractDataSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRoutingDataSource
/*     */   extends AbstractDataSource
/*     */   implements InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private Map<Object, Object> targetDataSources;
/*     */   @Nullable
/*     */   private Object defaultTargetDataSource;
/*     */   private boolean lenientFallback = true;
/*  55 */   private DataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Map<Object, DataSource> resolvedDataSources;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private DataSource resolvedDefaultDataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetDataSources(Map<Object, Object> targetDataSources) {
/*  75 */     this.targetDataSources = targetDataSources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultTargetDataSource(Object defaultTargetDataSource) {
/*  88 */     this.defaultTargetDataSource = defaultTargetDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLenientFallback(boolean lenientFallback) {
/* 105 */     this.lenientFallback = lenientFallback;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSourceLookup(@Nullable DataSourceLookup dataSourceLookup) {
/* 115 */     this.dataSourceLookup = (dataSourceLookup != null) ? dataSourceLookup : new JndiDataSourceLookup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 124 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() {
/* 138 */     if (this.targetDataSources == null) {
/* 139 */       throw new IllegalArgumentException("Property 'targetDataSources' is required");
/*     */     }
/* 141 */     this.resolvedDataSources = CollectionUtils.newHashMap(this.targetDataSources.size());
/* 142 */     this.targetDataSources.forEach((key, value) -> {
/*     */           Object lookupKey = resolveSpecifiedLookupKey(key);
/*     */           DataSource dataSource = resolveSpecifiedDataSource(value);
/*     */           this.resolvedDataSources.put(lookupKey, dataSource);
/*     */         });
/* 147 */     if (this.defaultTargetDataSource != null) {
/* 148 */       this.resolvedDefaultDataSource = resolveSpecifiedDataSource(this.defaultTargetDataSource);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object resolveSpecifiedLookupKey(Object lookupKey) {
/* 162 */     return lookupKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataSource resolveSpecifiedDataSource(Object dataSourceObject) throws IllegalArgumentException {
/* 175 */     if (dataSourceObject instanceof DataSource) { DataSource dataSource = (DataSource)dataSourceObject;
/* 176 */       return dataSource; }
/*     */     
/* 178 */     if (dataSourceObject instanceof String) { String dataSourceName = (String)dataSourceObject;
/* 179 */       return this.dataSourceLookup.getDataSource(dataSourceName); }
/*     */ 
/*     */     
/* 182 */     throw new IllegalArgumentException("Illegal data source value - only [javax.sql.DataSource] and String supported: " + String.valueOf(dataSourceObject));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Object, DataSource> getResolvedDataSources() {
/* 195 */     Assert.state((this.resolvedDataSources != null), "DataSources not resolved yet - call afterPropertiesSet");
/* 196 */     return Collections.unmodifiableMap(this.resolvedDataSources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getResolvedDefaultDataSource() {
/* 207 */     return this.resolvedDefaultDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 213 */     return determineTargetDataSource().getConnection();
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/* 218 */     return determineTargetDataSource().getConnection(username, password);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConnectionBuilder createConnectionBuilder() throws SQLException {
/* 223 */     return determineTargetDataSource().createConnectionBuilder();
/*     */   }
/*     */ 
/*     */   
/*     */   public ShardingKeyBuilder createShardingKeyBuilder() throws SQLException {
/* 228 */     return determineTargetDataSource().createShardingKeyBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/* 234 */     if (iface.isInstance(this)) {
/* 235 */       return (T)this;
/*     */     }
/* 237 */     return determineTargetDataSource().unwrap(iface);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 242 */     return (iface.isInstance(this) || determineTargetDataSource().isWrapperFor(iface));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataSource determineTargetDataSource() {
/* 255 */     Assert.notNull(this.resolvedDataSources, "DataSource router not initialized");
/* 256 */     Object lookupKey = determineCurrentLookupKey();
/* 257 */     DataSource dataSource = this.resolvedDataSources.get(lookupKey);
/* 258 */     if (dataSource == null && (this.lenientFallback || lookupKey == null)) {
/* 259 */       dataSource = this.resolvedDefaultDataSource;
/*     */     }
/* 261 */     if (dataSource == null) {
/* 262 */       throw new IllegalStateException("Cannot determine target DataSource for lookup key [" + String.valueOf(lookupKey) + "]");
/*     */     }
/* 264 */     return dataSource;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected abstract Object determineCurrentLookupKey();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\lookup\AbstractRoutingDataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */