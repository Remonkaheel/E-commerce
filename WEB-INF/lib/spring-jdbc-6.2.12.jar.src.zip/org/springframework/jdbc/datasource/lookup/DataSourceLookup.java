package org.springframework.jdbc.datasource.lookup;

import javax.sql.DataSource;

@FunctionalInterface
public interface DataSourceLookup {
  DataSource getDataSource(String paramString) throws DataSourceLookupFailureException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\lookup\DataSourceLookup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */