/*     */ package org.springframework.jdbc.datasource.lookup;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapDataSourceLookup
/*     */   implements DataSourceLookup
/*     */ {
/*  41 */   private final Map<String, DataSource> dataSources = new HashMap<>(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapDataSourceLookup() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapDataSourceLookup(Map<String, DataSource> dataSources) {
/*  56 */     setDataSources(dataSources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapDataSourceLookup(String dataSourceName, DataSource dataSource) {
/*  65 */     addDataSource(dataSourceName, dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSources(@Nullable Map<String, DataSource> dataSources) {
/*  77 */     if (dataSources != null) {
/*  78 */       this.dataSources.putAll(dataSources);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, DataSource> getDataSources() {
/*  88 */     return Collections.unmodifiableMap(this.dataSources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDataSource(String dataSourceName, DataSource dataSource) {
/*  98 */     Assert.notNull(dataSourceName, "DataSource name must not be null");
/*  99 */     Assert.notNull(dataSource, "DataSource must not be null");
/* 100 */     this.dataSources.put(dataSourceName, dataSource);
/*     */   }
/*     */ 
/*     */   
/*     */   public DataSource getDataSource(String dataSourceName) throws DataSourceLookupFailureException {
/* 105 */     Assert.notNull(dataSourceName, "DataSource name must not be null");
/* 106 */     DataSource dataSource = this.dataSources.get(dataSourceName);
/* 107 */     if (dataSource == null) {
/* 108 */       throw new DataSourceLookupFailureException("No DataSource with name '" + dataSourceName + "' registered");
/*     */     }
/*     */     
/* 111 */     return dataSource;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\lookup\MapDataSourceLookup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */