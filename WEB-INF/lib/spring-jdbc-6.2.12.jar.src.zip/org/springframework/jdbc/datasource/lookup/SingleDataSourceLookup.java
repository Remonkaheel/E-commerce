/*    */ package org.springframework.jdbc.datasource.lookup;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SingleDataSourceLookup
/*    */   implements DataSourceLookup
/*    */ {
/*    */   private final DataSource dataSource;
/*    */   
/*    */   public SingleDataSourceLookup(DataSource dataSource) {
/* 40 */     Assert.notNull(dataSource, "DataSource must not be null");
/* 41 */     this.dataSource = dataSource;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public DataSource getDataSource(String dataSourceName) {
/* 47 */     return this.dataSource;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\lookup\SingleDataSourceLookup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */