/*    */ package org.springframework.jdbc.datasource.lookup;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.jndi.JndiLocatorSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JndiDataSourceLookup
/*    */   extends JndiLocatorSupport
/*    */   implements DataSourceLookup
/*    */ {
/*    */   public JndiDataSourceLookup() {
/* 39 */     setResourceRef(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public DataSource getDataSource(String dataSourceName) throws DataSourceLookupFailureException {
/*    */     try {
/* 45 */       return (DataSource)lookup(dataSourceName, DataSource.class);
/*    */     }
/* 47 */     catch (NamingException ex) {
/* 48 */       throw new DataSourceLookupFailureException("Failed to look up JNDI DataSource with name '" + dataSourceName + "'", ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\lookup\JndiDataSourceLookup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */