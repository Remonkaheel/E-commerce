/*    */ package org.springframework.jdbc.datasource.lookup;
/*    */ 
/*    */ import org.springframework.dao.NonTransientDataAccessException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSourceLookupFailureException
/*    */   extends NonTransientDataAccessException
/*    */ {
/*    */   public DataSourceLookupFailureException(String msg) {
/* 36 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataSourceLookupFailureException(String msg, Throwable cause) {
/* 46 */     super(msg, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\lookup\DataSourceLookupFailureException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */