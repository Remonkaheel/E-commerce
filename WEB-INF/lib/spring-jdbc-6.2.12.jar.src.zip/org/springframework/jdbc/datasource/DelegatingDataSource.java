/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ConnectionBuilder;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.ShardingKeyBuilder;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingDataSource
/*     */   implements DataSource, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private DataSource targetDataSource;
/*     */   
/*     */   public DelegatingDataSource() {}
/*     */   
/*     */   public DelegatingDataSource(DataSource targetDataSource) {
/*  62 */     setTargetDataSource(targetDataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetDataSource(@Nullable DataSource targetDataSource) {
/*  70 */     this.targetDataSource = targetDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getTargetDataSource() {
/*  78 */     return this.targetDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataSource obtainTargetDataSource() {
/*  86 */     DataSource dataSource = getTargetDataSource();
/*  87 */     Assert.state((dataSource != null), "No 'targetDataSource' set");
/*  88 */     return dataSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  93 */     if (getTargetDataSource() == null) {
/*  94 */       throw new IllegalArgumentException("Property 'targetDataSource' is required");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 101 */     return obtainTargetDataSource().getConnection();
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/* 106 */     return obtainTargetDataSource().getConnection(username, password);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConnectionBuilder createConnectionBuilder() throws SQLException {
/* 111 */     return obtainTargetDataSource().createConnectionBuilder();
/*     */   }
/*     */ 
/*     */   
/*     */   public ShardingKeyBuilder createShardingKeyBuilder() throws SQLException {
/* 116 */     return obtainTargetDataSource().createShardingKeyBuilder();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLoginTimeout() throws SQLException {
/* 121 */     return obtainTargetDataSource().getLoginTimeout();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLoginTimeout(int seconds) throws SQLException {
/* 126 */     obtainTargetDataSource().setLoginTimeout(seconds);
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getLogWriter() throws SQLException {
/* 131 */     return obtainTargetDataSource().getLogWriter();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLogWriter(PrintWriter out) throws SQLException {
/* 136 */     obtainTargetDataSource().setLogWriter(out);
/*     */   }
/*     */ 
/*     */   
/*     */   public Logger getParentLogger() {
/* 141 */     return Logger.getLogger("global");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/* 147 */     if (iface.isInstance(this)) {
/* 148 */       return (T)this;
/*     */     }
/* 150 */     return obtainTargetDataSource().unwrap(iface);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 155 */     return (iface.isInstance(this) || obtainTargetDataSource().isWrapperFor(iface));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\DelegatingDataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */