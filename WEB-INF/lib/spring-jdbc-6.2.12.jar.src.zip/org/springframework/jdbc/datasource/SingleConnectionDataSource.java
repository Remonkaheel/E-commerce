/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleConnectionDataSource
/*     */   extends DriverManagerDataSource
/*     */   implements SmartDataSource, AutoCloseable, DisposableBean
/*     */ {
/*     */   private boolean suppressClose;
/*     */   private boolean rollbackBeforeClose;
/*     */   @Nullable
/*     */   private Boolean autoCommit;
/*     */   @Nullable
/*     */   private Connection target;
/*     */   @Nullable
/*     */   private Connection connection;
/*  79 */   private final Lock connectionLock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SingleConnectionDataSource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SingleConnectionDataSource(String url, String username, String password, boolean suppressClose) {
/*  99 */     super(url, username, password);
/* 100 */     this.suppressClose = suppressClose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SingleConnectionDataSource(String url, boolean suppressClose) {
/* 112 */     super(url);
/* 113 */     this.suppressClose = suppressClose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SingleConnectionDataSource(Connection target, boolean suppressClose) {
/* 125 */     Assert.notNull(target, "Connection must not be null");
/* 126 */     this.target = target;
/* 127 */     this.suppressClose = suppressClose;
/* 128 */     this.connection = suppressClose ? getCloseSuppressingConnectionProxy(target) : target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuppressClose(boolean suppressClose) {
/* 137 */     this.suppressClose = suppressClose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isSuppressClose() {
/* 145 */     return this.suppressClose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRollbackBeforeClose(boolean rollbackBeforeClose) {
/* 155 */     this.rollbackBeforeClose = rollbackBeforeClose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isRollbackBeforeClose() {
/* 164 */     return this.rollbackBeforeClose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoCommit(boolean autoCommit) {
/* 171 */     this.autoCommit = Boolean.valueOf(autoCommit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Boolean getAutoCommitValue() {
/* 180 */     return this.autoCommit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 187 */     this.connectionLock.lock();
/*     */     try {
/* 189 */       if (this.connection == null)
/*     */       {
/* 191 */         initConnection();
/*     */       }
/* 193 */       if (this.connection.isClosed()) {
/* 194 */         throw new SQLException("Connection was closed in SingleConnectionDataSource. Check that user code checks shouldClose() before closing Connections, or set 'suppressClose' to 'true'");
/*     */       }
/*     */ 
/*     */       
/* 198 */       return this.connection;
/*     */     } finally {
/*     */       
/* 201 */       this.connectionLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/* 212 */     if (ObjectUtils.nullSafeEquals(username, getUsername()) && 
/* 213 */       ObjectUtils.nullSafeEquals(password, getPassword())) {
/* 214 */       return getConnection();
/*     */     }
/*     */     
/* 217 */     throw new SQLException("SingleConnectionDataSource does not support custom username and password");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldClose(Connection con) {
/* 226 */     this.connectionLock.lock();
/*     */     try {
/* 228 */       return (con != this.connection && con != this.target);
/*     */     } finally {
/*     */       
/* 231 */       this.connectionLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 244 */     destroy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 255 */     this.connectionLock.lock();
/*     */     try {
/* 257 */       if (this.target != null) {
/* 258 */         closeConnection(this.target);
/*     */       }
/*     */     } finally {
/*     */       
/* 262 */       this.connectionLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initConnection() throws SQLException {
/* 271 */     if (getUrl() == null) {
/* 272 */       throw new IllegalStateException("'url' property is required for lazily initializing a Connection");
/*     */     }
/* 274 */     this.connectionLock.lock();
/*     */     try {
/* 276 */       if (this.target != null) {
/* 277 */         closeConnection(this.target);
/*     */       }
/* 279 */       this.target = getConnectionFromDriver(getUsername(), getPassword());
/* 280 */       prepareConnection(this.target);
/* 281 */       if (this.logger.isDebugEnabled()) {
/* 282 */         this.logger.debug("Established shared JDBC Connection: " + String.valueOf(this.target));
/*     */       }
/* 284 */       this.connection = isSuppressClose() ? getCloseSuppressingConnectionProxy(this.target) : this.target;
/*     */     } finally {
/*     */       
/* 287 */       this.connectionLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetConnection() {
/* 295 */     this.connectionLock.lock();
/*     */     try {
/* 297 */       if (this.target != null) {
/* 298 */         closeConnection(this.target);
/*     */       }
/* 300 */       this.target = null;
/* 301 */       this.connection = null;
/*     */     } finally {
/*     */       
/* 304 */       this.connectionLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void prepareConnection(Connection con) throws SQLException {
/* 316 */     Boolean autoCommit = getAutoCommitValue();
/* 317 */     if (autoCommit != null && con.getAutoCommit() != autoCommit.booleanValue()) {
/* 318 */       con.setAutoCommit(autoCommit.booleanValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void closeConnection(Connection con) {
/* 327 */     if (isRollbackBeforeClose()) {
/*     */       try {
/* 329 */         if (!con.getAutoCommit()) {
/* 330 */           con.rollback();
/*     */         }
/*     */       }
/* 333 */       catch (Throwable ex) {
/* 334 */         this.logger.info("Could not roll back shared JDBC Connection before close", ex);
/*     */       } 
/*     */     }
/*     */     try {
/* 338 */       con.close();
/*     */     }
/* 340 */     catch (Throwable ex) {
/* 341 */       this.logger.info("Could not close shared JDBC Connection", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection getCloseSuppressingConnectionProxy(Connection target) {
/* 352 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class
/* 353 */         .getClassLoader(), new Class[] { ConnectionProxy.class }, new CloseSuppressingInvocationHandler(target));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CloseSuppressingInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final Connection target;
/*     */ 
/*     */ 
/*     */     
/*     */     public CloseSuppressingInvocationHandler(Connection target) {
/* 367 */       this.target = target;
/*     */     } @Nullable
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */       Boolean bool3;
/*     */       Integer integer;
/*     */       Boolean bool2;
/*     */       Connection connection;
/*     */       Boolean bool1;
/* 375 */       switch (method.getName()) {
/*     */         case "equals":
/* 377 */           bool3 = Boolean.valueOf((proxy == args[0]));
/*     */         case "hashCode":
/* 379 */           integer = Integer.valueOf(System.identityHashCode(proxy));
/*     */         case "close":
/* 381 */           integer = null;
/* 382 */         case "isClosed": bool2 = Boolean.valueOf(this.target.isClosed());
/*     */         case "getTargetConnection":
/* 384 */           connection = this.target;
/* 385 */         case "unwrap": connection = ((Class)args[0]).isInstance(proxy) ? (Connection)proxy : this.target.<Connection>unwrap((Class<Connection>)args[0]);
/* 386 */         case "isWrapperFor": bool1 = Boolean.valueOf((((Class)args[0]).isInstance(proxy) || this.target.isWrapperFor((Class)args[0])));
/*     */       } 
/*     */       
/*     */       try {
/* 390 */         Object object = method.invoke(this.target, args);
/*     */       }
/* 392 */       catch (InvocationTargetException ex) {
/* 393 */         throw ex.getTargetException();
/*     */       } 
/*     */       return object;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\SingleConnectionDataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */