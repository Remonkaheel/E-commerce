/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ConnectionBuilder;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.ShardingKey;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShardingKeyDataSourceAdapter
/*     */   extends DelegatingDataSource
/*     */ {
/*     */   @Nullable
/*     */   private ShardingKeyProvider shardingkeyProvider;
/*     */   
/*     */   public ShardingKeyDataSourceAdapter(DataSource dataSource) {
/*  66 */     super(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShardingKeyDataSourceAdapter(DataSource dataSource, ShardingKeyProvider shardingKeyProvider) {
/*  77 */     super(dataSource);
/*  78 */     this.shardingkeyProvider = shardingKeyProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShardingKeyProvider(ShardingKeyProvider shardingKeyProvider) {
/*  86 */     this.shardingkeyProvider = shardingKeyProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 101 */     return createConnectionBuilder().build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/* 116 */     return createConnectionBuilder().user(username).password(password).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionBuilder createConnectionBuilder() throws SQLException {
/* 128 */     ConnectionBuilder connectionBuilder = super.createConnectionBuilder();
/* 129 */     if (this.shardingkeyProvider == null) {
/* 130 */       return connectionBuilder;
/*     */     }
/*     */     
/* 133 */     ShardingKey shardingKey = this.shardingkeyProvider.getShardingKey();
/* 134 */     ShardingKey superShardingKey = this.shardingkeyProvider.getSuperShardingKey();
/* 135 */     return connectionBuilder.shardingKey(shardingKey).superShardingKey(superShardingKey);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\ShardingKeyDataSourceAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */