package org.springframework.jdbc.datasource;

import java.sql.Connection;

public interface ConnectionProxy extends Connection {
  Connection getTargetConnection();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\ConnectionProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */