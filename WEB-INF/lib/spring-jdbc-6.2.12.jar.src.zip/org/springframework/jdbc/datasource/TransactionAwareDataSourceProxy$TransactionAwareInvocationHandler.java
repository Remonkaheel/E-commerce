/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TransactionAwareInvocationHandler
/*     */   implements InvocationHandler
/*     */ {
/*     */   private final DataSource targetDataSource;
/*     */   @Nullable
/*     */   private Connection target;
/*     */   private boolean closed = false;
/*     */   
/*     */   public TransactionAwareInvocationHandler(DataSource targetDataSource) {
/* 189 */     this.targetDataSource = targetDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */     StringBuilder sb;
/* 197 */     switch (method.getName()) {
/*     */       
/*     */       case "equals":
/* 200 */         return Boolean.valueOf((proxy == args[0]));
/*     */ 
/*     */       
/*     */       case "hashCode":
/* 204 */         return Integer.valueOf(System.identityHashCode(proxy));
/*     */ 
/*     */       
/*     */       case "toString":
/* 208 */         sb = new StringBuilder("Transaction-aware proxy for target Connection ");
/* 209 */         if (this.target != null) {
/* 210 */           sb.append('[').append(this.target).append(']');
/*     */         } else {
/*     */           
/* 213 */           sb.append("from DataSource [").append(this.targetDataSource).append(']');
/*     */         } 
/* 215 */         return sb.toString();
/*     */ 
/*     */       
/*     */       case "close":
/* 219 */         if (this.target != null) {
/*     */           
/* 221 */           ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(this.targetDataSource);
/* 222 */           if (conHolder != null && conHolder.hasConnection() && conHolder.getConnection() == this.target) {
/*     */             
/* 224 */             conHolder.released();
/*     */           } else {
/*     */             
/* 227 */             DataSourceUtils.doCloseConnection(this.target, this.targetDataSource);
/*     */           } 
/*     */         } 
/* 230 */         this.closed = true;
/* 231 */         return null;
/*     */       
/*     */       case "isClosed":
/* 234 */         return Boolean.valueOf(this.closed);
/*     */       
/*     */       case "unwrap":
/* 237 */         if (((Class)args[0]).isInstance(proxy)) {
/* 238 */           return proxy;
/*     */         }
/*     */         break;
/*     */       case "isWrapperFor":
/* 242 */         if (((Class)args[0]).isInstance(proxy)) {
/* 243 */           return Boolean.valueOf(true);
/*     */         }
/*     */         break;
/*     */     } 
/*     */     
/* 248 */     if (this.target == null) {
/* 249 */       if (method.getName().equals("getWarnings") || method.getName().equals("clearWarnings"))
/*     */       {
/* 251 */         return null;
/*     */       }
/* 253 */       if (this.closed) {
/* 254 */         throw new SQLException("Connection handle already closed");
/*     */       }
/* 256 */       if (TransactionAwareDataSourceProxy.this.shouldObtainFixedConnection(this.targetDataSource)) {
/* 257 */         this.target = DataSourceUtils.doGetConnection(this.targetDataSource);
/*     */       }
/*     */     } 
/* 260 */     Connection actualTarget = this.target;
/* 261 */     if (actualTarget == null) {
/* 262 */       actualTarget = DataSourceUtils.doGetConnection(this.targetDataSource);
/*     */     }
/*     */     
/* 265 */     if (method.getName().equals("getTargetConnection"))
/*     */     {
/* 267 */       return actualTarget;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 272 */       Object retVal = method.invoke(actualTarget, args);
/*     */ 
/*     */ 
/*     */       
/* 276 */       if (retVal instanceof Statement) { Statement statement = (Statement)retVal;
/* 277 */         DataSourceUtils.applyTransactionTimeout(statement, this.targetDataSource); }
/*     */ 
/*     */       
/* 280 */       return retVal;
/*     */     }
/* 282 */     catch (InvocationTargetException ex) {
/* 283 */       throw ex.getTargetException();
/*     */     } finally {
/*     */       
/* 286 */       if (actualTarget != this.target)
/* 287 */         DataSourceUtils.doReleaseConnection(actualTarget, this.targetDataSource); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\TransactionAwareDataSourceProxy$TransactionAwareInvocationHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */