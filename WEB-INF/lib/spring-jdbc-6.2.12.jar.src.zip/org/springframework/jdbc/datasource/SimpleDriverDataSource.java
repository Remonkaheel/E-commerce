/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleDriverDataSource
/*     */   extends AbstractDriverBasedDataSource
/*     */ {
/*     */   @Nullable
/*     */   private Driver driver;
/*     */   
/*     */   public SimpleDriverDataSource() {}
/*     */   
/*     */   public SimpleDriverDataSource(Driver driver, String url) {
/*  74 */     setDriver(driver);
/*  75 */     setUrl(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleDriverDataSource(Driver driver, String url, String username, String password) {
/*  87 */     setDriver(driver);
/*  88 */     setUrl(url);
/*  89 */     setUsername(username);
/*  90 */     setPassword(password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleDriverDataSource(Driver driver, String url, Properties conProps) {
/* 101 */     setDriver(driver);
/* 102 */     setUrl(url);
/* 103 */     setConnectionProperties(conProps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDriverClass(Class<? extends Driver> driverClass) {
/* 114 */     this.driver = (Driver)BeanUtils.instantiateClass(driverClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDriver(@Nullable Driver driver) {
/* 124 */     this.driver = driver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Driver getDriver() {
/* 132 */     return this.driver;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection getConnectionFromDriver(Properties props) throws SQLException {
/* 138 */     Driver driver = getDriver();
/* 139 */     Assert.state((driver != null), "Driver has not been set");
/* 140 */     String url = getUrl();
/* 141 */     if (this.logger.isDebugEnabled()) {
/* 142 */       this.logger.debug("Creating new JDBC Driver Connection to [" + url + "]");
/*     */     }
/* 144 */     return driver.connect(url, props);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\SimpleDriverDataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */