package org.springframework.jdbc.datasource;

import java.sql.Connection;
import javax.sql.DataSource;

public interface SmartDataSource extends DataSource {
  boolean shouldClose(Connection paramConnection);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\SmartDataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */