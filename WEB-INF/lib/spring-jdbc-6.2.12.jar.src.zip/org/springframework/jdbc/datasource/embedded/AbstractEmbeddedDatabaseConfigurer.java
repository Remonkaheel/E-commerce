/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractEmbeddedDatabaseConfigurer
/*    */   implements EmbeddedDatabaseConfigurer
/*    */ {
/* 38 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */ 
/*    */   
/*    */   public void shutdown(DataSource dataSource, String databaseName) {
/* 43 */     Connection con = null;
/*    */     try {
/* 45 */       con = dataSource.getConnection();
/* 46 */       if (con != null) {
/* 47 */         Statement stmt = con.createStatement(); 
/* 48 */         try { stmt.execute("SHUTDOWN");
/* 49 */           if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null)
/*    */             try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; } 
/*    */       } 
/* 52 */     } catch (SQLException ex) {
/* 53 */       this.logger.info("Could not shut down embedded database", ex);
/*    */     } finally {
/*    */       
/* 56 */       if (con != null)
/*    */         try {
/* 58 */           con.close();
/*    */         }
/* 60 */         catch (SQLException ex) {
/* 61 */           this.logger.debug("Could not close JDBC Connection on shutdown", ex);
/*    */         }
/* 63 */         catch (Throwable ex) {
/* 64 */           this.logger.debug("Unexpected exception on closing JDBC Connection", ex);
/*    */         }  
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\AbstractEmbeddedDatabaseConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */