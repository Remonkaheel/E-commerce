package org.springframework.jdbc.datasource.embedded;

import java.io.IOException;
import java.io.OutputStream;

class null extends OutputStream {
  public void write(int b) throws IOException {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\OutputStreamFactory$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */