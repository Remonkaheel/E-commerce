/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.sql.Driver;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.jdbc.datasource.SimpleDriverDataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SimpleDriverDataSourceFactory
/*    */   implements DataSourceFactory
/*    */ {
/* 34 */   private final SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
/*    */ 
/*    */   
/*    */   public ConnectionProperties getConnectionProperties() {
/* 38 */     return new ConnectionProperties()
/*    */       {
/*    */         public void setDriverClass(Class<? extends Driver> driverClass) {
/* 41 */           SimpleDriverDataSourceFactory.this.dataSource.setDriverClass(driverClass);
/*    */         }
/*    */ 
/*    */         
/*    */         public void setUrl(String url) {
/* 46 */           SimpleDriverDataSourceFactory.this.dataSource.setUrl(url);
/*    */         }
/*    */ 
/*    */         
/*    */         public void setUsername(String username) {
/* 51 */           SimpleDriverDataSourceFactory.this.dataSource.setUsername(username);
/*    */         }
/*    */ 
/*    */         
/*    */         public void setPassword(String password) {
/* 56 */           SimpleDriverDataSourceFactory.this.dataSource.setPassword(password);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public DataSource getDataSource() {
/* 63 */     return (DataSource)this.dataSource;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\SimpleDriverDataSourceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */