/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.sql.Driver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements ConnectionProperties
/*    */ {
/*    */   public void setDriverClass(Class<? extends Driver> driverClass) {
/* 41 */     SimpleDriverDataSourceFactory.this.dataSource.setDriverClass(driverClass);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setUrl(String url) {
/* 46 */     SimpleDriverDataSourceFactory.this.dataSource.setUrl(url);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setUsername(String username) {
/* 51 */     SimpleDriverDataSourceFactory.this.dataSource.setUsername(username);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPassword(String password) {
/* 56 */     SimpleDriverDataSourceFactory.this.dataSource.setPassword(password);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\SimpleDriverDataSourceFactory$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */