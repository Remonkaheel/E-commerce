/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.derby.jdbc.EmbeddedDriver;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DerbyEmbeddedDatabaseConfigurer
/*    */   implements EmbeddedDatabaseConfigurer
/*    */ {
/*    */   private static final String URL_TEMPLATE = "jdbc:derby:memory:%s;%s";
/*    */   @Nullable
/*    */   private static DerbyEmbeddedDatabaseConfigurer instance;
/*    */   
/*    */   public static synchronized DerbyEmbeddedDatabaseConfigurer getInstance() {
/* 51 */     if (instance == null) {
/*    */       
/* 53 */       System.setProperty("derby.stream.error.method", OutputStreamFactory.class
/* 54 */           .getName() + ".getNoopOutputStream");
/* 55 */       instance = new DerbyEmbeddedDatabaseConfigurer();
/*    */     } 
/* 57 */     return instance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void configureConnectionProperties(ConnectionProperties properties, String databaseName) {
/* 66 */     properties.setDriverClass((Class)EmbeddedDriver.class);
/* 67 */     properties.setUrl(String.format("jdbc:derby:memory:%s;%s", new Object[] { databaseName, "create=true" }));
/* 68 */     properties.setUsername("sa");
/* 69 */     properties.setPassword("");
/*    */   }
/*    */ 
/*    */   
/*    */   public void shutdown(DataSource dataSource, String databaseName) {
/*    */     try {
/* 75 */       (new EmbeddedDriver()).connect(
/* 76 */           String.format("jdbc:derby:memory:%s;%s", new Object[] { databaseName, "drop=true" }), new Properties());
/*    */     }
/* 78 */     catch (SQLException ex) {
/*    */       
/* 80 */       if (!"08006".equals(ex.getSQLState()))
/* 81 */         LogFactory.getLog(getClass()).warn("Could not shut down embedded Derby database", ex); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\DerbyEmbeddedDatabaseConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */