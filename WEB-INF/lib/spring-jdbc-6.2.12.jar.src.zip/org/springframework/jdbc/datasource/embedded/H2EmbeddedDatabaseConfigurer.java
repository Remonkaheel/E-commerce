/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.sql.Driver;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class H2EmbeddedDatabaseConfigurer
/*    */   extends AbstractEmbeddedDatabaseConfigurer
/*    */ {
/*    */   @Nullable
/*    */   private static H2EmbeddedDatabaseConfigurer instance;
/*    */   private final Class<? extends Driver> driverClass;
/*    */   
/*    */   public static synchronized H2EmbeddedDatabaseConfigurer getInstance() throws ClassNotFoundException {
/* 49 */     if (instance == null)
/*    */     {
/* 51 */       instance = new H2EmbeddedDatabaseConfigurer(ClassUtils.forName("org.h2.Driver", H2EmbeddedDatabaseConfigurer.class.getClassLoader()));
/*    */     }
/* 53 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   private H2EmbeddedDatabaseConfigurer(Class<? extends Driver> driverClass) {
/* 58 */     this.driverClass = driverClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public void configureConnectionProperties(ConnectionProperties properties, String databaseName) {
/* 63 */     properties.setDriverClass(this.driverClass);
/* 64 */     properties.setUrl(String.format("jdbc:h2:mem:%s;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=false", new Object[] { databaseName }));
/* 65 */     properties.setUsername("sa");
/* 66 */     properties.setPassword("");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\H2EmbeddedDatabaseConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */