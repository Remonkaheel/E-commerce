/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.util.function.UnaryOperator;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EmbeddedDatabaseConfigurers
/*    */ {
/*    */   public static EmbeddedDatabaseConfigurer getConfigurer(EmbeddedDatabaseType type) {
/* 42 */     Assert.notNull(type, "EmbeddedDatabaseType is required");
/*    */     try {
/* 44 */       switch (type) { default: throw new IncompatibleClassChangeError();case HSQL: case H2: case DERBY: break; }  return 
/*    */ 
/*    */         
/* 47 */         DerbyEmbeddedDatabaseConfigurer.getInstance();
/*    */     
/*    */     }
/* 50 */     catch (ClassNotFoundException|NoClassDefFoundError ex) {
/* 51 */       throw new IllegalStateException("Driver for test database type [" + String.valueOf(type) + "] is not available", ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static EmbeddedDatabaseConfigurer customizeConfigurer(EmbeddedDatabaseType type, UnaryOperator<EmbeddedDatabaseConfigurer> customizer) {
/* 67 */     EmbeddedDatabaseConfigurer defaultConfigurer = getConfigurer(type);
/* 68 */     return customizer.apply(defaultConfigurer);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\EmbeddedDatabaseConfigurers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */