package org.springframework.jdbc.datasource.embedded;

import javax.sql.DataSource;

public interface DataSourceFactory {
  ConnectionProperties getConnectionProperties();
  
  DataSource getDataSource();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\DataSourceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */