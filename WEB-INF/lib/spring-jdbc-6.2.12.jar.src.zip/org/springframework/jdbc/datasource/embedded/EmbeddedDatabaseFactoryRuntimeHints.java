/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import org.springframework.aot.hint.ExecutableMode;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.aot.hint.TypeHint;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EmbeddedDatabaseFactoryRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/* 38 */     hints.reflection().registerTypeIfPresent(classLoader, "org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseFactory$EmbeddedDataSourceProxy", builder -> builder.onReachableType(EmbeddedDatabaseFactory.class).withMethod("shutdown", Collections.emptyList(), ExecutableMode.INVOKE));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\EmbeddedDatabaseFactoryRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */