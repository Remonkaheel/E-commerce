package org.springframework.jdbc.datasource.embedded;

import javax.sql.DataSource;

public interface EmbeddedDatabaseConfigurer {
  void configureConnectionProperties(ConnectionProperties paramConnectionProperties, String paramString);
  
  void shutdown(DataSource paramDataSource, String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\EmbeddedDatabaseConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */