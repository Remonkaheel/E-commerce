/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EmbeddedDatabaseType
/*    */ {
/* 29 */   HSQL,
/*    */ 
/*    */   
/* 32 */   H2,
/*    */ 
/*    */   
/* 35 */   DERBY;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\EmbeddedDatabaseType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */