/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmbeddedDatabaseFactoryBean
/*    */   extends EmbeddedDatabaseFactory
/*    */   implements FactoryBean<DataSource>, InitializingBean, DisposableBean
/*    */ {
/*    */   @Nullable
/*    */   private DatabasePopulator databaseCleaner;
/*    */   
/*    */   public void setDatabaseCleaner(DatabasePopulator databaseCleaner) {
/* 59 */     this.databaseCleaner = databaseCleaner;
/*    */   }
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() {
/* 64 */     initDatabase();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public DataSource getObject() {
/* 71 */     return getDataSource();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<? extends DataSource> getObjectType() {
/* 76 */     return DataSource.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSingleton() {
/* 81 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 87 */     DatabasePopulator cleaner = this.databaseCleaner;
/* 88 */     if (cleaner != null && getDataSource() != null) {
/* 89 */       DatabasePopulatorUtils.execute(cleaner, getDataSource());
/*    */     }
/* 91 */     shutdownDatabase();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\EmbeddedDatabaseFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */