/*     */ package org.springframework.jdbc.datasource.embedded;
/*     */ 
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*     */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmbeddedDatabaseBuilder
/*     */ {
/*     */   private final EmbeddedDatabaseFactory databaseFactory;
/*     */   private final ResourceDatabasePopulator databasePopulator;
/*     */   private final ResourceLoader resourceLoader;
/*     */   
/*     */   public EmbeddedDatabaseBuilder() {
/*  68 */     this((ResourceLoader)new DefaultResourceLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder(ResourceLoader resourceLoader) {
/*  76 */     this.databaseFactory = new EmbeddedDatabaseFactory();
/*  77 */     this.databasePopulator = new ResourceDatabasePopulator();
/*  78 */     this.databaseFactory.setDatabasePopulator((DatabasePopulator)this.databasePopulator);
/*  79 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder generateUniqueName(boolean flag) {
/*  95 */     this.databaseFactory.setGenerateUniqueDatabaseName(flag);
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder setName(String databaseName) {
/* 110 */     this.databaseFactory.setDatabaseName(databaseName);
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder setType(EmbeddedDatabaseType databaseType) {
/* 122 */     this.databaseFactory.setDatabaseType(databaseType);
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder setDatabaseConfigurer(EmbeddedDatabaseConfigurer configurer) {
/* 135 */     this.databaseFactory.setDatabaseConfigurer(configurer);
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder setDataSourceFactory(DataSourceFactory dataSourceFactory) {
/* 148 */     Assert.notNull(dataSourceFactory, "DataSourceFactory is required");
/* 149 */     this.databaseFactory.setDataSourceFactory(dataSourceFactory);
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder addDefaultScripts() {
/* 160 */     return addScripts(new String[] { "schema.sql", "data.sql" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder addScript(String script) {
/* 169 */     this.databasePopulator.addScript(this.resourceLoader.getResource(script));
/* 170 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder addScripts(String... scripts) {
/* 180 */     for (String script : scripts) {
/* 181 */       addScript(script);
/*     */     }
/* 183 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder setScriptEncoding(String scriptEncoding) {
/* 194 */     this.databasePopulator.setSqlScriptEncoding(scriptEncoding);
/* 195 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder setSeparator(String separator) {
/* 208 */     this.databasePopulator.setSeparator(separator);
/* 209 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder setCommentPrefix(String commentPrefix) {
/* 221 */     this.databasePopulator.setCommentPrefix(commentPrefix);
/* 222 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder setCommentPrefixes(String... commentPrefixes) {
/* 233 */     this.databasePopulator.setCommentPrefixes(commentPrefixes);
/* 234 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder setBlockCommentStartDelimiter(String blockCommentStartDelimiter) {
/* 246 */     this.databasePopulator.setBlockCommentStartDelimiter(blockCommentStartDelimiter);
/* 247 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder setBlockCommentEndDelimiter(String blockCommentEndDelimiter) {
/* 259 */     this.databasePopulator.setBlockCommentEndDelimiter(blockCommentEndDelimiter);
/* 260 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder continueOnError(boolean flag) {
/* 272 */     this.databasePopulator.setContinueOnError(flag);
/* 273 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabaseBuilder ignoreFailedDrops(boolean flag) {
/* 288 */     this.databasePopulator.setIgnoreFailedDrops(flag);
/* 289 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabase build() {
/* 297 */     return this.databaseFactory.getDatabase();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\EmbeddedDatabaseBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */