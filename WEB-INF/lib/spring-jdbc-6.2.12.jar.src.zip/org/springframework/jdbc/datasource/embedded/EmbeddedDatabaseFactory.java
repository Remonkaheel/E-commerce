/*     */ package org.springframework.jdbc.datasource.embedded;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.jdbc.datasource.SimpleDriverDataSource;
/*     */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*     */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmbeddedDatabaseFactory
/*     */ {
/*     */   public static final String DEFAULT_DATABASE_NAME = "testdb";
/*  75 */   private static final Log logger = LogFactory.getLog(EmbeddedDatabaseFactory.class);
/*     */   
/*     */   private boolean generateUniqueDatabaseName = false;
/*     */   
/*  79 */   private String databaseName = "testdb";
/*     */   
/*  81 */   private DataSourceFactory dataSourceFactory = new SimpleDriverDataSourceFactory();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private EmbeddedDatabaseConfigurer databaseConfigurer;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private DatabasePopulator databasePopulator;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private DataSource dataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGenerateUniqueDatabaseName(boolean generateUniqueDatabaseName) {
/* 102 */     this.generateUniqueDatabaseName = generateUniqueDatabaseName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabaseName(String databaseName) {
/* 114 */     Assert.hasText(databaseName, "Database name is required");
/* 115 */     this.databaseName = databaseName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSourceFactory(DataSourceFactory dataSourceFactory) {
/* 124 */     Assert.notNull(dataSourceFactory, "DataSourceFactory is required");
/* 125 */     this.dataSourceFactory = dataSourceFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabaseType(EmbeddedDatabaseType type) {
/* 136 */     this.databaseConfigurer = EmbeddedDatabaseConfigurers.getConfigurer(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabaseConfigurer(EmbeddedDatabaseConfigurer configurer) {
/* 149 */     this.databaseConfigurer = configurer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabasePopulator(DatabasePopulator populator) {
/* 158 */     this.databasePopulator = populator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedDatabase getDatabase() {
/* 167 */     if (this.dataSource == null) {
/* 168 */       initDatabase();
/*     */     }
/* 170 */     return new EmbeddedDataSourceProxy(this.dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initDatabase() {
/* 185 */     if (this.generateUniqueDatabaseName) {
/* 186 */       setDatabaseName(UUID.randomUUID().toString());
/*     */     }
/*     */ 
/*     */     
/* 190 */     if (this.databaseConfigurer == null) {
/* 191 */       this.databaseConfigurer = EmbeddedDatabaseConfigurers.getConfigurer(EmbeddedDatabaseType.HSQL);
/*     */     }
/* 193 */     this.databaseConfigurer.configureConnectionProperties(this.dataSourceFactory
/* 194 */         .getConnectionProperties(), this.databaseName);
/* 195 */     this.dataSource = this.dataSourceFactory.getDataSource();
/*     */     
/* 197 */     if (logger.isInfoEnabled()) {
/* 198 */       DataSource dataSource = this.dataSource; if (dataSource instanceof SimpleDriverDataSource) { SimpleDriverDataSource simpleDriverDataSource = (SimpleDriverDataSource)dataSource;
/* 199 */         logger.info(String.format("Starting embedded database: url='%s', username='%s'", new Object[] { simpleDriverDataSource
/* 200 */                 .getUrl(), simpleDriverDataSource.getUsername() })); }
/*     */       else
/*     */       
/* 203 */       { logger.info(String.format("Starting embedded database '%s'", new Object[] { this.databaseName })); }
/*     */     
/*     */     } 
/*     */ 
/*     */     
/* 208 */     if (this.databasePopulator != null) {
/*     */       try {
/* 210 */         DatabasePopulatorUtils.execute(this.databasePopulator, this.dataSource);
/*     */       }
/* 212 */       catch (RuntimeException ex) {
/*     */         
/* 214 */         shutdownDatabase();
/* 215 */         throw ex;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void shutdownDatabase() {
/* 227 */     if (this.dataSource != null) {
/* 228 */       if (logger.isInfoEnabled()) {
/* 229 */         DataSource dataSource = this.dataSource; if (dataSource instanceof SimpleDriverDataSource) { SimpleDriverDataSource simpleDriverDataSource = (SimpleDriverDataSource)dataSource;
/* 230 */           logger.info(String.format("Shutting down embedded database: url='%s'", new Object[] { simpleDriverDataSource
/* 231 */                   .getUrl() })); }
/*     */         else
/*     */         
/* 234 */         { logger.info(String.format("Shutting down embedded database '%s'", new Object[] { this.databaseName })); }
/*     */       
/*     */       } 
/* 237 */       if (this.databaseConfigurer != null) {
/* 238 */         this.databaseConfigurer.shutdown(this.dataSource, this.databaseName);
/*     */       }
/* 240 */       this.dataSource = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected final DataSource getDataSource() {
/* 253 */     return this.dataSource;
/*     */   }
/*     */   
/*     */   private class EmbeddedDataSourceProxy
/*     */     implements EmbeddedDatabase
/*     */   {
/*     */     private final DataSource dataSource;
/*     */     
/*     */     public EmbeddedDataSourceProxy(DataSource dataSource) {
/* 262 */       this.dataSource = dataSource;
/*     */     }
/*     */ 
/*     */     
/*     */     public Connection getConnection() throws SQLException {
/* 267 */       return this.dataSource.getConnection();
/*     */     }
/*     */ 
/*     */     
/*     */     public Connection getConnection(String username, String password) throws SQLException {
/* 272 */       return this.dataSource.getConnection(username, password);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrintWriter getLogWriter() throws SQLException {
/* 277 */       return this.dataSource.getLogWriter();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setLogWriter(PrintWriter out) throws SQLException {
/* 282 */       this.dataSource.setLogWriter(out);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getLoginTimeout() throws SQLException {
/* 287 */       return this.dataSource.getLoginTimeout();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setLoginTimeout(int seconds) throws SQLException {
/* 292 */       this.dataSource.setLoginTimeout(seconds);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T unwrap(Class<T> iface) throws SQLException {
/* 297 */       return this.dataSource.unwrap(iface);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 302 */       return this.dataSource.isWrapperFor(iface);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Logger getParentLogger() {
/* 308 */       return Logger.getLogger("global");
/*     */     }
/*     */ 
/*     */     
/*     */     public void shutdown() {
/* 313 */       EmbeddedDatabaseFactory.this.shutdownDatabase();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\EmbeddedDatabaseFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */