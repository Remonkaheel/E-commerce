package org.springframework.jdbc.datasource.embedded;

import java.sql.Driver;

public interface ConnectionProperties {
  void setDriverClass(Class<? extends Driver> paramClass);
  
  void setUrl(String paramString);
  
  void setUsername(String paramString);
  
  void setPassword(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\ConnectionProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */