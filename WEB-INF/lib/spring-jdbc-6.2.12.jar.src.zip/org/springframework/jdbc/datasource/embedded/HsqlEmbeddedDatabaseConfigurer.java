/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.sql.Driver;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HsqlEmbeddedDatabaseConfigurer
/*    */   extends AbstractEmbeddedDatabaseConfigurer
/*    */ {
/*    */   @Nullable
/*    */   private static HsqlEmbeddedDatabaseConfigurer instance;
/*    */   private final Class<? extends Driver> driverClass;
/*    */   
/*    */   public static synchronized HsqlEmbeddedDatabaseConfigurer getInstance() throws ClassNotFoundException {
/* 48 */     if (instance == null)
/*    */     {
/* 50 */       instance = new HsqlEmbeddedDatabaseConfigurer(ClassUtils.forName("org.hsqldb.jdbcDriver", HsqlEmbeddedDatabaseConfigurer.class.getClassLoader()));
/*    */     }
/* 52 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   private HsqlEmbeddedDatabaseConfigurer(Class<? extends Driver> driverClass) {
/* 57 */     this.driverClass = driverClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public void configureConnectionProperties(ConnectionProperties properties, String databaseName) {
/* 62 */     properties.setDriverClass(this.driverClass);
/* 63 */     properties.setUrl("jdbc:hsqldb:mem:" + databaseName);
/* 64 */     properties.setUsername("sa");
/* 65 */     properties.setPassword("");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\HsqlEmbeddedDatabaseConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */