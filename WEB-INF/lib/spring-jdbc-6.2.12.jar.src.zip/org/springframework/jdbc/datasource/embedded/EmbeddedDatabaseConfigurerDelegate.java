/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmbeddedDatabaseConfigurerDelegate
/*    */   extends AbstractEmbeddedDatabaseConfigurer
/*    */ {
/*    */   private final EmbeddedDatabaseConfigurer target;
/*    */   
/*    */   public EmbeddedDatabaseConfigurerDelegate(EmbeddedDatabaseConfigurer target) {
/* 31 */     this.target = target;
/*    */   }
/*    */ 
/*    */   
/*    */   public void configureConnectionProperties(ConnectionProperties properties, String databaseName) {
/* 36 */     this.target.configureConnectionProperties(properties, databaseName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\embedded\EmbeddedDatabaseConfigurerDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */