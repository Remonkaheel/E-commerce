/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UserCredentialsDataSourceAdapter
/*     */   extends DelegatingDataSource
/*     */ {
/*     */   @Nullable
/*     */   private String username;
/*     */   @Nullable
/*     */   private String password;
/*     */   @Nullable
/*     */   private String catalog;
/*     */   @Nullable
/*     */   private String schema;
/*  77 */   private final ThreadLocal<JdbcUserCredentials> threadBoundCredentials = (ThreadLocal<JdbcUserCredentials>)new NamedThreadLocal("Current JDBC user credentials");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsername(String username) {
/*  90 */     this.username = username;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPassword(String password) {
/* 102 */     this.password = password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalog(String catalog) {
/* 111 */     this.catalog = catalog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchema(String schema) {
/* 120 */     this.schema = schema;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCredentialsForCurrentThread(String username, String password) {
/* 135 */     this.threadBoundCredentials.set(new JdbcUserCredentials(username, password));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeCredentialsFromCurrentThread() {
/* 144 */     this.threadBoundCredentials.remove();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 158 */     JdbcUserCredentials threadCredentials = this.threadBoundCredentials.get();
/*     */ 
/*     */     
/* 161 */     Connection con = (threadCredentials != null) ? doGetConnection(threadCredentials.username, threadCredentials.password) : doGetConnection(this.username, this.password);
/*     */     
/* 163 */     if (this.catalog != null) {
/* 164 */       con.setCatalog(this.catalog);
/*     */     }
/* 166 */     if (this.schema != null) {
/* 167 */       con.setSchema(this.schema);
/*     */     }
/* 169 */     return con;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/* 178 */     return doGetConnection(username, password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection doGetConnection(@Nullable String username, @Nullable String password) throws SQLException {
/* 193 */     Assert.state((getTargetDataSource() != null), "'targetDataSource' is required");
/* 194 */     if (StringUtils.hasLength(username)) {
/* 195 */       return getTargetDataSource().getConnection(username, password);
/*     */     }
/*     */     
/* 198 */     return getTargetDataSource().getConnection();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class JdbcUserCredentials
/*     */   {
/*     */     public final String username;
/*     */ 
/*     */     
/*     */     public final String password;
/*     */ 
/*     */ 
/*     */     
/*     */     public JdbcUserCredentials(String username, String password) {
/* 213 */       this.username = username;
/* 214 */       this.password = password;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 219 */       return "JdbcUserCredentials[username='" + this.username + "',password='" + this.password + "']";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\UserCredentialsDataSourceAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */