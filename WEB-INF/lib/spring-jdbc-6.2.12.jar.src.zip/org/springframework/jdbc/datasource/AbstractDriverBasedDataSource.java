/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDriverBasedDataSource
/*     */   extends AbstractDataSource
/*     */ {
/*     */   @Nullable
/*     */   private String url;
/*     */   @Nullable
/*     */   private String username;
/*     */   @Nullable
/*     */   private String password;
/*     */   @Nullable
/*     */   private String catalog;
/*     */   @Nullable
/*     */   private String schema;
/*     */   @Nullable
/*     */   private Properties connectionProperties;
/*     */   
/*     */   public void setUrl(@Nullable String url) {
/*  60 */     this.url = (url != null) ? url.trim() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getUrl() {
/*  68 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsername(@Nullable String username) {
/*  76 */     this.username = username;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getUsername() {
/*  84 */     return this.username;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPassword(@Nullable String password) {
/*  92 */     this.password = password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPassword() {
/* 100 */     return this.password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalog(@Nullable String catalog) {
/* 109 */     this.catalog = catalog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getCatalog() {
/* 118 */     return this.catalog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchema(@Nullable String schema) {
/* 127 */     this.schema = schema;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSchema() {
/* 136 */     return this.schema;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionProperties(@Nullable Properties connectionProperties) {
/* 148 */     this.connectionProperties = connectionProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Properties getConnectionProperties() {
/* 156 */     return this.connectionProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 169 */     return getConnectionFromDriver(getUsername(), getPassword());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/* 179 */     return getConnectionFromDriver(username, password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection getConnectionFromDriver(@Nullable String username, @Nullable String password) throws SQLException {
/* 193 */     Properties mergedProps = new Properties();
/* 194 */     Properties connProps = getConnectionProperties();
/* 195 */     if (connProps != null) {
/* 196 */       mergedProps.putAll(connProps);
/*     */     }
/* 198 */     if (username != null) {
/* 199 */       mergedProps.setProperty("user", username);
/*     */     }
/* 201 */     if (password != null) {
/* 202 */       mergedProps.setProperty("password", password);
/*     */     }
/*     */     
/* 205 */     Connection con = getConnectionFromDriver(mergedProps);
/* 206 */     if (this.catalog != null) {
/* 207 */       con.setCatalog(this.catalog);
/*     */     }
/* 209 */     if (this.schema != null) {
/* 210 */       con.setSchema(this.schema);
/*     */     }
/* 212 */     return con;
/*     */   }
/*     */   
/*     */   protected abstract Connection getConnectionFromDriver(Properties paramProperties) throws SQLException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\AbstractDriverBasedDataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */