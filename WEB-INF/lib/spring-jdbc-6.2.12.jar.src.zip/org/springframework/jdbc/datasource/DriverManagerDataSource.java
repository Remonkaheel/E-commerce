/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DriverManagerDataSource
/*     */   extends AbstractDriverBasedDataSource
/*     */ {
/*     */   public DriverManagerDataSource() {}
/*     */   
/*     */   public DriverManagerDataSource(String url) {
/*  82 */     setUrl(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DriverManagerDataSource(String url, String username, String password) {
/*  94 */     setUrl(url);
/*  95 */     setUsername(username);
/*  96 */     setPassword(password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DriverManagerDataSource(String url, Properties conProps) {
/* 107 */     setUrl(url);
/* 108 */     setConnectionProperties(conProps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDriverClassName(String driverClassName) {
/* 125 */     Assert.hasText(driverClassName, "Property 'driverClassName' must not be empty");
/* 126 */     String driverClassNameToUse = driverClassName.trim();
/*     */     try {
/* 128 */       Class.forName(driverClassNameToUse, true, ClassUtils.getDefaultClassLoader());
/*     */     }
/* 130 */     catch (ClassNotFoundException ex) {
/* 131 */       throw new IllegalStateException("Could not load JDBC driver class [" + driverClassNameToUse + "]", ex);
/*     */     } 
/* 133 */     if (this.logger.isDebugEnabled()) {
/* 134 */       this.logger.debug("Loaded JDBC driver: " + driverClassNameToUse);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection getConnectionFromDriver(Properties props) throws SQLException {
/* 141 */     String url = getUrl();
/* 142 */     Assert.state((url != null), "'url' not set");
/* 143 */     if (this.logger.isDebugEnabled()) {
/* 144 */       this.logger.debug("Creating new JDBC DriverManager Connection to [" + url + "]");
/*     */     }
/* 146 */     return getConnectionFromDriverManager(url, props);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection getConnectionFromDriverManager(String url, Properties props) throws SQLException {
/* 155 */     return DriverManager.getConnection(url, props);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\DriverManagerDataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */