/*    */ package org.springframework.jdbc.datasource;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleConnectionHandle
/*    */   implements ConnectionHandle
/*    */ {
/*    */   private final Connection connection;
/*    */   
/*    */   public SimpleConnectionHandle(Connection connection) {
/* 40 */     Assert.notNull(connection, "Connection must not be null");
/* 41 */     this.connection = connection;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Connection getConnection() {
/* 49 */     return this.connection;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 55 */     return "SimpleConnectionHandle: " + String.valueOf(this.connection);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\SimpleConnectionHandle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */