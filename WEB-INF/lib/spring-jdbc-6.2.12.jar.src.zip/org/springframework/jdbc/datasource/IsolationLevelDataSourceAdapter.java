/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IsolationLevelDataSourceAdapter
/*     */   extends UserCredentialsDataSourceAdapter
/*     */ {
/*  63 */   static final Map<String, Integer> constants = Map.of("ISOLATION_DEFAULT", 
/*  64 */       Integer.valueOf(-1), "ISOLATION_READ_UNCOMMITTED", 
/*  65 */       Integer.valueOf(1), "ISOLATION_READ_COMMITTED", 
/*  66 */       Integer.valueOf(2), "ISOLATION_REPEATABLE_READ", 
/*  67 */       Integer.valueOf(4), "ISOLATION_SERIALIZABLE", 
/*  68 */       Integer.valueOf(8));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Integer isolationLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setIsolationLevelName(String constantName) throws IllegalArgumentException {
/*  91 */     Assert.hasText(constantName, "'constantName' must not be null or blank");
/*  92 */     Integer isolationLevel = constants.get(constantName);
/*  93 */     Assert.notNull(isolationLevel, "Only isolation constants allowed");
/*  94 */     setIsolationLevel(isolationLevel.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsolationLevel(int isolationLevel) {
/* 117 */     Assert.isTrue(constants.containsValue(Integer.valueOf(isolationLevel)), "Only values of isolation constants allowed");
/* 118 */     this.isolationLevel = (isolationLevel != -1) ? Integer.valueOf(isolationLevel) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Integer getIsolationLevel() {
/* 127 */     return this.isolationLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection doGetConnection(@Nullable String username, @Nullable String password) throws SQLException {
/* 139 */     Connection con = super.doGetConnection(username, password);
/* 140 */     Boolean readOnlyToUse = getCurrentReadOnlyFlag();
/* 141 */     if (readOnlyToUse != null) {
/* 142 */       con.setReadOnly(readOnlyToUse.booleanValue());
/*     */     }
/* 144 */     Integer isolationLevelToUse = getCurrentIsolationLevel();
/* 145 */     if (isolationLevelToUse != null) {
/* 146 */       con.setTransactionIsolation(isolationLevelToUse.intValue());
/*     */     }
/* 148 */     return con;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Integer getCurrentIsolationLevel() {
/* 160 */     Integer isolationLevelToUse = TransactionSynchronizationManager.getCurrentTransactionIsolationLevel();
/* 161 */     if (isolationLevelToUse == null) {
/* 162 */       isolationLevelToUse = getIsolationLevel();
/*     */     }
/* 164 */     return isolationLevelToUse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Boolean getCurrentReadOnlyFlag() {
/* 175 */     boolean txReadOnly = TransactionSynchronizationManager.isCurrentTransactionReadOnly();
/* 176 */     return txReadOnly ? Boolean.TRUE : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\IsolationLevelDataSourceAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */