/*    */ package org.springframework.jdbc.datasource;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.SQLException;
/*    */ import java.util.logging.Logger;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractDataSource
/*    */   implements DataSource
/*    */ {
/* 43 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getLoginTimeout() throws SQLException {
/* 51 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setLoginTimeout(int timeout) throws SQLException {
/* 59 */     throw new UnsupportedOperationException("setLoginTimeout");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PrintWriter getLogWriter() {
/* 67 */     throw new UnsupportedOperationException("getLogWriter");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setLogWriter(PrintWriter pw) throws SQLException {
/* 75 */     throw new UnsupportedOperationException("setLogWriter");
/*    */   }
/*    */ 
/*    */   
/*    */   public Logger getParentLogger() {
/* 80 */     return Logger.getLogger("global");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> T unwrap(Class<T> iface) throws SQLException {
/* 86 */     if (iface.isInstance(this)) {
/* 87 */       return (T)this;
/*    */     }
/* 89 */     throw new SQLException("DataSource of type [" + getClass().getName() + "] cannot be unwrapped as [" + iface
/* 90 */         .getName() + "]");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 95 */     return iface.isInstance(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\AbstractDataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */