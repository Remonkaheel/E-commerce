/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LazyConnectionDataSourceProxy
/*     */   extends DelegatingDataSource
/*     */ {
/* 101 */   static final Map<String, Integer> constants = Map.of("TRANSACTION_READ_UNCOMMITTED", 
/* 102 */       Integer.valueOf(1), "TRANSACTION_READ_COMMITTED", 
/* 103 */       Integer.valueOf(2), "TRANSACTION_REPEATABLE_READ", 
/* 104 */       Integer.valueOf(4), "TRANSACTION_SERIALIZABLE", 
/* 105 */       Integer.valueOf(8));
/*     */ 
/*     */   
/* 108 */   private static final Log logger = LogFactory.getLog(LazyConnectionDataSourceProxy.class);
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private DataSource readOnlyDataSource;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile Boolean defaultAutoCommit;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile Integer defaultTransactionIsolation;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LazyConnectionDataSourceProxy() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LazyConnectionDataSourceProxy(DataSource targetDataSource) {
/* 134 */     setTargetDataSource(targetDataSource);
/* 135 */     afterPropertiesSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadOnlyDataSource(@Nullable DataSource readOnlyDataSource) {
/* 155 */     this.readOnlyDataSource = readOnlyDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultAutoCommit(boolean defaultAutoCommit) {
/* 166 */     this.defaultAutoCommit = Boolean.valueOf(defaultAutoCommit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultTransactionIsolationName(String constantName) {
/* 181 */     Assert.hasText(constantName, "'constantName' must not be null or blank");
/* 182 */     Integer defaultTransactionIsolation = constants.get(constantName);
/* 183 */     Assert.notNull(defaultTransactionIsolation, "Only transaction isolation constants allowed");
/* 184 */     this.defaultTransactionIsolation = defaultTransactionIsolation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultTransactionIsolation(int defaultTransactionIsolation) {
/* 200 */     Assert.isTrue(constants.containsValue(Integer.valueOf(defaultTransactionIsolation)), "Only values of transaction isolation constants allowed");
/*     */     
/* 202 */     this.defaultTransactionIsolation = Integer.valueOf(defaultTransactionIsolation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkDefaultConnectionProperties() {
/* 213 */     if (this.defaultAutoCommit == null || this.defaultTransactionIsolation == null) {
/*     */       try {
/* 215 */         Connection con = obtainTargetDataSource().getConnection(); 
/* 216 */         try { checkDefaultConnectionProperties(con);
/* 217 */           if (con != null) con.close();  } catch (Throwable throwable) { if (con != null)
/*     */             try { con.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; } 
/* 219 */       } catch (SQLException ex) {
/* 220 */         logger.debug("Could not retrieve default auto-commit and transaction isolation settings", ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkDefaultConnectionProperties(Connection con) throws SQLException {
/* 233 */     if (this.defaultAutoCommit == null) {
/* 234 */       this.defaultAutoCommit = Boolean.valueOf(con.getAutoCommit());
/*     */     }
/* 236 */     if (this.defaultTransactionIsolation == null) {
/* 237 */       this.defaultTransactionIsolation = Integer.valueOf(con.getTransactionIsolation());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Boolean defaultAutoCommit() {
/* 246 */     return this.defaultAutoCommit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Integer defaultTransactionIsolation() {
/* 254 */     return this.defaultTransactionIsolation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 268 */     checkDefaultConnectionProperties();
/* 269 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class
/* 270 */         .getClassLoader(), new Class[] { ConnectionProxy.class }, new LazyConnectionInvocationHandler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/* 287 */     checkDefaultConnectionProperties();
/* 288 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class
/* 289 */         .getClassLoader(), new Class[] { ConnectionProxy.class }, new LazyConnectionInvocationHandler(username, password));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class LazyConnectionInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     @Nullable
/*     */     private String username;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private String password;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Boolean autoCommit;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Integer transactionIsolation;
/*     */ 
/*     */     
/*     */     private boolean readOnly = false;
/*     */     
/* 315 */     private int holdability = 2;
/*     */     
/*     */     private boolean closed = false;
/*     */     
/*     */     @Nullable
/*     */     private Connection target;
/*     */     
/*     */     public LazyConnectionInvocationHandler() {
/* 323 */       this.autoCommit = LazyConnectionDataSourceProxy.this.defaultAutoCommit();
/* 324 */       this.transactionIsolation = LazyConnectionDataSourceProxy.this.defaultTransactionIsolation();
/*     */     }
/*     */     
/*     */     public LazyConnectionInvocationHandler(String username, String password) {
/* 328 */       this();
/* 329 */       this.username = username;
/* 330 */       this.password = password;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 338 */       switch (method.getName()) {
/*     */ 
/*     */         
/*     */         case "equals":
/* 342 */           return Boolean.valueOf((proxy == args[0]));
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case "hashCode":
/* 348 */           return Integer.valueOf(System.identityHashCode(proxy));
/*     */ 
/*     */         
/*     */         case "getTargetConnection":
/* 352 */           return getTargetConnection(method);
/*     */         
/*     */         case "unwrap":
/* 355 */           if (((Class)args[0]).isInstance(proxy)) {
/* 356 */             return proxy;
/*     */           }
/*     */           break;
/*     */         case "isWrapperFor":
/* 360 */           if (((Class)args[0]).isInstance(proxy)) {
/* 361 */             return Boolean.valueOf(true);
/*     */           }
/*     */           break;
/*     */       } 
/*     */       
/* 366 */       if (!hasTargetConnection())
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 371 */         switch (method.getName()) {
/*     */           case "toString":
/* 373 */             return "Lazy Connection proxy for target DataSource [" + String.valueOf(LazyConnectionDataSourceProxy.this.getTargetDataSource()) + "]";
/*     */           
/*     */           case "getAutoCommit":
/* 376 */             if (this.autoCommit != null) {
/* 377 */               return this.autoCommit;
/*     */             }
/*     */             break;
/*     */ 
/*     */           
/*     */           case "setAutoCommit":
/* 383 */             this.autoCommit = (Boolean)args[0];
/* 384 */             return null;
/*     */           
/*     */           case "getTransactionIsolation":
/* 387 */             if (this.transactionIsolation != null) {
/* 388 */               return this.transactionIsolation;
/*     */             }
/*     */             break;
/*     */ 
/*     */           
/*     */           case "setTransactionIsolation":
/* 394 */             this.transactionIsolation = (Integer)args[0];
/* 395 */             return null;
/*     */           
/*     */           case "isReadOnly":
/* 398 */             return Boolean.valueOf(this.readOnly);
/*     */           
/*     */           case "setReadOnly":
/* 401 */             this.readOnly = ((Boolean)args[0]).booleanValue();
/* 402 */             return null;
/*     */           
/*     */           case "getHoldability":
/* 405 */             return Integer.valueOf(this.holdability);
/*     */           
/*     */           case "setHoldability":
/* 408 */             this.holdability = ((Integer)args[0]).intValue();
/* 409 */             return null;
/*     */           
/*     */           case "commit":
/*     */           case "rollback":
/* 413 */             return null;
/*     */           
/*     */           case "getWarnings":
/*     */           case "clearWarnings":
/* 417 */             return null;
/*     */ 
/*     */           
/*     */           case "close":
/* 421 */             this.closed = true;
/* 422 */             return null;
/*     */           
/*     */           case "isClosed":
/* 425 */             return Boolean.valueOf(this.closed);
/*     */           
/*     */           default:
/* 428 */             if (this.closed)
/*     */             {
/*     */               
/* 431 */               throw new SQLException("Illegal operation: connection is closed");
/*     */             }
/*     */             break;
/*     */         } 
/*     */       
/*     */       }
/* 437 */       if (LazyConnectionDataSourceProxy.this.readOnlyDataSource != null && "setReadOnly".equals(method.getName()))
/*     */       {
/* 439 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 446 */         Connection conToUse = getTargetConnection(method);
/*     */         
/* 448 */         if ("rollback".equals(method.getName()) && conToUse.isClosed())
/*     */         {
/*     */           
/* 451 */           return null;
/*     */         }
/*     */         
/* 454 */         return method.invoke(conToUse, args);
/*     */       }
/* 456 */       catch (InvocationTargetException ex) {
/* 457 */         throw ex.getTargetException();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean hasTargetConnection() {
/* 465 */       return (this.target != null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Connection getTargetConnection(Method operation) throws SQLException {
/* 472 */       if (this.target == null) {
/*     */         
/* 474 */         if (LazyConnectionDataSourceProxy.logger.isTraceEnabled()) {
/* 475 */           LazyConnectionDataSourceProxy.logger.trace("Connecting to database for operation '" + operation.getName() + "'");
/*     */         }
/*     */ 
/*     */         
/* 479 */         DataSource dataSource = getDataSourceToUse();
/* 480 */         this
/* 481 */           .target = (this.username != null) ? dataSource.getConnection(this.username, this.password) : dataSource.getConnection();
/* 482 */         if (this.target == null) {
/* 483 */           throw new IllegalStateException("DataSource returned null from getConnection(): " + String.valueOf(dataSource));
/*     */         }
/*     */ 
/*     */         
/* 487 */         if (this.readOnly && LazyConnectionDataSourceProxy.this.readOnlyDataSource == null) {
/*     */           try {
/* 489 */             this.target.setReadOnly(true);
/*     */           }
/* 491 */           catch (Exception ex) {
/*     */             
/* 493 */             LazyConnectionDataSourceProxy.logger.debug("Could not set JDBC Connection read-only", ex);
/*     */           } 
/*     */         }
/* 496 */         if (this.transactionIsolation != null && 
/* 497 */           !this.transactionIsolation.equals(LazyConnectionDataSourceProxy.this.defaultTransactionIsolation())) {
/* 498 */           this.target.setTransactionIsolation(this.transactionIsolation.intValue());
/*     */         }
/* 500 */         if (this.autoCommit != null && this.autoCommit != LazyConnectionDataSourceProxy.this.defaultAutoCommit()) {
/* 501 */           this.target.setAutoCommit(this.autoCommit.booleanValue());
/*     */ 
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 507 */       else if (LazyConnectionDataSourceProxy.logger.isTraceEnabled()) {
/* 508 */         LazyConnectionDataSourceProxy.logger.trace("Using existing database connection for operation '" + operation.getName() + "'");
/*     */       } 
/*     */ 
/*     */       
/* 512 */       return this.target;
/*     */     }
/*     */     
/*     */     private DataSource getDataSourceToUse() {
/* 516 */       return (this.readOnly && LazyConnectionDataSourceProxy.this.readOnlyDataSource != null) ? LazyConnectionDataSourceProxy.this.readOnlyDataSource : LazyConnectionDataSourceProxy.this.obtainTargetDataSource();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\LazyConnectionDataSourceProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */