/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Savepoint;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.ResourceHolderSupport;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionHolder
/*     */   extends ResourceHolderSupport
/*     */ {
/*     */   public static final String SAVEPOINT_NAME_PREFIX = "SAVEPOINT_";
/*     */   @Nullable
/*     */   private ConnectionHandle connectionHandle;
/*     */   @Nullable
/*     */   private Connection currentConnection;
/*     */   private boolean transactionActive = false;
/*     */   @Nullable
/*     */   private Boolean savepointsSupported;
/*  61 */   private int savepointCounter = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionHolder(ConnectionHandle connectionHandle) {
/*  69 */     Assert.notNull(connectionHandle, "ConnectionHandle must not be null");
/*  70 */     this.connectionHandle = connectionHandle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionHolder(Connection connection) {
/*  82 */     this.connectionHandle = new SimpleConnectionHandle(connection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionHolder(Connection connection, boolean transactionActive) {
/*  94 */     this(connection);
/*  95 */     this.transactionActive = transactionActive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ConnectionHandle getConnectionHandle() {
/* 104 */     return this.connectionHandle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasConnection() {
/* 111 */     return (this.connectionHandle != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTransactionActive(boolean transactionActive) {
/* 119 */     this.transactionActive = transactionActive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isTransactionActive() {
/* 126 */     return this.transactionActive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setConnection(@Nullable Connection connection) {
/* 137 */     if (this.currentConnection != null) {
/* 138 */       if (this.connectionHandle != null) {
/* 139 */         this.connectionHandle.releaseConnection(this.currentConnection);
/*     */       }
/* 141 */       this.currentConnection = null;
/*     */     } 
/* 143 */     if (connection != null) {
/* 144 */       this.connectionHandle = new SimpleConnectionHandle(connection);
/*     */     } else {
/*     */       
/* 147 */       this.connectionHandle = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() {
/* 160 */     Assert.state((this.connectionHandle != null), "Active Connection is required");
/* 161 */     if (this.currentConnection == null) {
/* 162 */       this.currentConnection = this.connectionHandle.getConnection();
/*     */     }
/* 164 */     return this.currentConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsSavepoints() throws SQLException {
/* 173 */     if (this.savepointsSupported == null) {
/* 174 */       this.savepointsSupported = Boolean.valueOf(getConnection().getMetaData().supportsSavepoints());
/*     */     }
/* 176 */     return this.savepointsSupported.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Savepoint createSavepoint() throws SQLException {
/* 186 */     this.savepointCounter++;
/* 187 */     return getConnection().setSavepoint("SAVEPOINT_" + this.savepointCounter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void released() {
/* 199 */     super.released();
/* 200 */     if (!isOpen() && this.currentConnection != null) {
/* 201 */       if (this.connectionHandle != null) {
/* 202 */         this.connectionHandle.releaseConnection(this.currentConnection);
/*     */       }
/* 204 */       this.currentConnection = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 211 */     super.clear();
/* 212 */     this.transactionActive = false;
/* 213 */     this.savepointsSupported = null;
/* 214 */     this.savepointCounter = 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\ConnectionHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */