/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.CannotCreateTransactionException;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ import org.springframework.transaction.support.AbstractPlatformTransactionManager;
/*     */ import org.springframework.transaction.support.DefaultTransactionStatus;
/*     */ import org.springframework.transaction.support.ResourceTransactionManager;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceTransactionManager
/*     */   extends AbstractPlatformTransactionManager
/*     */   implements ResourceTransactionManager, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private DataSource dataSource;
/*     */   private boolean enforceReadOnly = false;
/*     */   
/*     */   public DataSourceTransactionManager() {
/* 136 */     setNestedTransactionAllowed(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSourceTransactionManager(DataSource dataSource) {
/* 144 */     this();
/* 145 */     setDataSource(dataSource);
/* 146 */     afterPropertiesSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(@Nullable DataSource dataSource) {
/* 169 */     if (dataSource instanceof TransactionAwareDataSourceProxy) { TransactionAwareDataSourceProxy tadsp = (TransactionAwareDataSourceProxy)dataSource;
/*     */ 
/*     */ 
/*     */       
/* 173 */       this.dataSource = tadsp.getTargetDataSource(); }
/*     */     else
/*     */     
/* 176 */     { this.dataSource = dataSource; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getDataSource() {
/* 185 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataSource obtainDataSource() {
/* 195 */     DataSource dataSource = getDataSource();
/* 196 */     Assert.state((dataSource != null), "No DataSource set");
/* 197 */     return dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnforceReadOnly(boolean enforceReadOnly) {
/* 219 */     this.enforceReadOnly = enforceReadOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnforceReadOnly() {
/* 229 */     return this.enforceReadOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 234 */     if (getDataSource() == null) {
/* 235 */       throw new IllegalArgumentException("Property 'dataSource' is required");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getResourceFactory() {
/* 242 */     return obtainDataSource();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object doGetTransaction() {
/* 247 */     DataSourceTransactionObject txObject = new DataSourceTransactionObject();
/* 248 */     txObject.setSavepointAllowed(isNestedTransactionAllowed());
/*     */     
/* 250 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(obtainDataSource());
/* 251 */     txObject.setConnectionHolder(conHolder, false);
/* 252 */     return txObject;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isExistingTransaction(Object transaction) {
/* 257 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/* 258 */     return (txObject.hasConnectionHolder() && txObject.getConnectionHolder().isTransactionActive());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBegin(Object transaction, TransactionDefinition definition) {
/* 263 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/* 264 */     Connection con = null;
/*     */     
/*     */     try {
/* 267 */       if (!txObject.hasConnectionHolder() || txObject
/* 268 */         .getConnectionHolder().isSynchronizedWithTransaction()) {
/* 269 */         Connection newCon = obtainDataSource().getConnection();
/* 270 */         if (this.logger.isDebugEnabled()) {
/* 271 */           this.logger.debug("Acquired Connection [" + String.valueOf(newCon) + "] for JDBC transaction");
/*     */         }
/* 273 */         txObject.setConnectionHolder(new ConnectionHolder(newCon), true);
/*     */       } 
/*     */       
/* 276 */       txObject.getConnectionHolder().setSynchronizedWithTransaction(true);
/* 277 */       con = txObject.getConnectionHolder().getConnection();
/*     */       
/* 279 */       Integer previousIsolationLevel = DataSourceUtils.prepareConnectionForTransaction(con, definition);
/* 280 */       txObject.setPreviousIsolationLevel(previousIsolationLevel);
/* 281 */       txObject.setReadOnly(definition.isReadOnly());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 286 */       if (con.getAutoCommit()) {
/* 287 */         txObject.setMustRestoreAutoCommit(true);
/* 288 */         if (this.logger.isDebugEnabled()) {
/* 289 */           this.logger.debug("Switching JDBC Connection [" + String.valueOf(con) + "] to manual commit");
/*     */         }
/* 291 */         con.setAutoCommit(false);
/*     */       } 
/*     */       
/* 294 */       prepareTransactionalConnection(con, definition);
/* 295 */       txObject.getConnectionHolder().setTransactionActive(true);
/*     */       
/* 297 */       int timeout = determineTimeout(definition);
/* 298 */       if (timeout != -1) {
/* 299 */         txObject.getConnectionHolder().setTimeoutInSeconds(timeout);
/*     */       }
/*     */ 
/*     */       
/* 303 */       if (txObject.isNewConnectionHolder()) {
/* 304 */         TransactionSynchronizationManager.bindResource(obtainDataSource(), txObject.getConnectionHolder());
/*     */       
/*     */       }
/*     */     }
/* 308 */     catch (Throwable ex) {
/* 309 */       if (txObject.isNewConnectionHolder()) {
/* 310 */         DataSourceUtils.releaseConnection(con, obtainDataSource());
/* 311 */         txObject.setConnectionHolder((ConnectionHolder)null, false);
/*     */       } 
/* 313 */       throw new CannotCreateTransactionException("Could not open JDBC Connection for transaction", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object doSuspend(Object transaction) {
/* 319 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/* 320 */     txObject.setConnectionHolder(null);
/* 321 */     return TransactionSynchronizationManager.unbindResource(obtainDataSource());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doResume(@Nullable Object transaction, Object suspendedResources) {
/* 326 */     TransactionSynchronizationManager.bindResource(obtainDataSource(), suspendedResources);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doCommit(DefaultTransactionStatus status) {
/* 331 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)status.getTransaction();
/* 332 */     Connection con = txObject.getConnectionHolder().getConnection();
/* 333 */     if (status.isDebug()) {
/* 334 */       this.logger.debug("Committing JDBC transaction on Connection [" + String.valueOf(con) + "]");
/*     */     }
/*     */     try {
/* 337 */       con.commit();
/*     */     }
/* 339 */     catch (SQLException ex) {
/* 340 */       throw translateException("JDBC commit", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doRollback(DefaultTransactionStatus status) {
/* 346 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)status.getTransaction();
/* 347 */     Connection con = txObject.getConnectionHolder().getConnection();
/* 348 */     if (status.isDebug()) {
/* 349 */       this.logger.debug("Rolling back JDBC transaction on Connection [" + String.valueOf(con) + "]");
/*     */     }
/*     */     try {
/* 352 */       con.rollback();
/*     */     }
/* 354 */     catch (SQLException ex) {
/* 355 */       throw translateException("JDBC rollback", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doSetRollbackOnly(DefaultTransactionStatus status) {
/* 361 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)status.getTransaction();
/* 362 */     if (status.isDebug()) {
/* 363 */       this.logger.debug("Setting JDBC transaction [" + String.valueOf(txObject.getConnectionHolder().getConnection()) + "] rollback-only");
/*     */     }
/*     */     
/* 366 */     txObject.setRollbackOnly();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doCleanupAfterCompletion(Object transaction) {
/* 371 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/*     */ 
/*     */     
/* 374 */     if (txObject.isNewConnectionHolder()) {
/* 375 */       TransactionSynchronizationManager.unbindResource(obtainDataSource());
/*     */     }
/*     */ 
/*     */     
/* 379 */     Connection con = txObject.getConnectionHolder().getConnection();
/*     */     try {
/* 381 */       if (txObject.isMustRestoreAutoCommit()) {
/* 382 */         con.setAutoCommit(true);
/*     */       }
/* 384 */       DataSourceUtils.resetConnectionAfterTransaction(con, txObject
/* 385 */           .getPreviousIsolationLevel(), txObject.isReadOnly());
/*     */     }
/* 387 */     catch (Throwable ex) {
/* 388 */       this.logger.debug("Could not reset JDBC Connection after transaction", ex);
/*     */     } 
/*     */     
/* 391 */     if (txObject.isNewConnectionHolder()) {
/* 392 */       if (this.logger.isDebugEnabled()) {
/* 393 */         this.logger.debug("Releasing JDBC Connection [" + String.valueOf(con) + "] after transaction");
/*     */       }
/* 395 */       DataSourceUtils.releaseConnection(con, this.dataSource);
/*     */     } 
/*     */     
/* 398 */     txObject.getConnectionHolder().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void prepareTransactionalConnection(Connection con, TransactionDefinition definition) throws SQLException {
/* 419 */     if (isEnforceReadOnly() && definition.isReadOnly()) {
/* 420 */       Statement stmt = con.createStatement(); try {
/* 421 */         stmt.executeUpdate("SET TRANSACTION READ ONLY");
/* 422 */         if (stmt != null) stmt.close();
/*     */       
/*     */       } catch (Throwable throwable) {
/*     */         if (stmt != null) {
/*     */           try {
/*     */             stmt.close();
/*     */           } catch (Throwable throwable1) {
/*     */             throwable.addSuppressed(throwable1);
/*     */           } 
/*     */         }
/*     */         throw throwable;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected RuntimeException translateException(String task, SQLException ex) {
/* 439 */     return (RuntimeException)new TransactionSystemException(task + " failed", ex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DataSourceTransactionObject
/*     */     extends JdbcTransactionObjectSupport
/*     */   {
/*     */     private boolean newConnectionHolder;
/*     */ 
/*     */     
/*     */     private boolean mustRestoreAutoCommit;
/*     */ 
/*     */     
/*     */     public void setConnectionHolder(@Nullable ConnectionHolder connectionHolder, boolean newConnectionHolder) {
/* 454 */       setConnectionHolder(connectionHolder);
/* 455 */       this.newConnectionHolder = newConnectionHolder;
/*     */     }
/*     */     
/*     */     public boolean isNewConnectionHolder() {
/* 459 */       return this.newConnectionHolder;
/*     */     }
/*     */     
/*     */     public void setMustRestoreAutoCommit(boolean mustRestoreAutoCommit) {
/* 463 */       this.mustRestoreAutoCommit = mustRestoreAutoCommit;
/*     */     }
/*     */     
/*     */     public boolean isMustRestoreAutoCommit() {
/* 467 */       return this.mustRestoreAutoCommit;
/*     */     }
/*     */     
/*     */     public void setRollbackOnly() {
/* 471 */       getConnectionHolder().setRollbackOnly();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRollbackOnly() {
/* 476 */       return getConnectionHolder().isRollbackOnly();
/*     */     }
/*     */ 
/*     */     
/*     */     public void flush() {
/* 481 */       TransactionSynchronizationUtils.triggerFlush();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\DataSourceTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */