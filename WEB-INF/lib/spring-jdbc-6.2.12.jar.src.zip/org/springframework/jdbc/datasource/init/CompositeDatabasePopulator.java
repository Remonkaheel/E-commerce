/*    */ package org.springframework.jdbc.datasource.init;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeDatabasePopulator
/*    */   implements DatabasePopulator
/*    */ {
/* 40 */   private final List<DatabasePopulator> populators = new ArrayList<>(4);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CompositeDatabasePopulator() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CompositeDatabasePopulator(Collection<DatabasePopulator> populators) {
/* 57 */     Assert.notNull(populators, "DatabasePopulators must not be null");
/* 58 */     this.populators.addAll(populators);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CompositeDatabasePopulator(DatabasePopulator... populators) {
/* 67 */     Assert.notNull(populators, "DatabasePopulators must not be null");
/* 68 */     this.populators.addAll(Arrays.asList(populators));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPopulators(DatabasePopulator... populators) {
/* 76 */     Assert.notNull(populators, "DatabasePopulators must not be null");
/* 77 */     this.populators.clear();
/* 78 */     this.populators.addAll(Arrays.asList(populators));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addPopulators(DatabasePopulator... populators) {
/* 85 */     Assert.notNull(populators, "DatabasePopulators must not be null");
/* 86 */     this.populators.addAll(Arrays.asList(populators));
/*    */   }
/*    */ 
/*    */   
/*    */   public void populate(Connection connection) throws SQLException, ScriptException {
/* 91 */     Assert.notNull(connection, "Connection must not be null");
/* 92 */     for (DatabasePopulator populator : this.populators)
/* 93 */       populator.populate(connection); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\init\CompositeDatabasePopulator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */