/*    */ package org.springframework.jdbc.datasource.init;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DatabasePopulatorUtils
/*    */ {
/*    */   public static void execute(DatabasePopulator populator, DataSource dataSource) throws DataAccessException {
/* 49 */     Assert.notNull(populator, "DatabasePopulator must not be null");
/* 50 */     Assert.notNull(dataSource, "DataSource must not be null");
/*    */     try {
/* 52 */       Connection connection = DataSourceUtils.getConnection(dataSource);
/*    */       try {
/* 54 */         populator.populate(connection);
/* 55 */         if (!connection.getAutoCommit() && !DataSourceUtils.isConnectionTransactional(connection, dataSource)) {
/* 56 */           connection.commit();
/*    */         }
/*    */       } finally {
/*    */         
/* 60 */         DataSourceUtils.releaseConnection(connection, dataSource);
/*    */       }
/*    */     
/* 63 */     } catch (ScriptException ex) {
/* 64 */       throw ex;
/*    */     }
/* 66 */     catch (Throwable ex) {
/* 67 */       throw new UncategorizedScriptException("Failed to execute database script", ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\init\DatabasePopulatorUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */