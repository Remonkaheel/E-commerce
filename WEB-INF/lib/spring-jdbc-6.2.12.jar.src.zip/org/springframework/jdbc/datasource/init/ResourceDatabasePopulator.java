/*     */ package org.springframework.jdbc.datasource.init;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.EncodedResource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceDatabasePopulator
/*     */   implements DatabasePopulator
/*     */ {
/*  58 */   List<Resource> scripts = new ArrayList<>();
/*     */   
/*     */   @Nullable
/*     */   private String sqlScriptEncoding;
/*     */   
/*  63 */   private String separator = ";";
/*     */   
/*  65 */   private String[] commentPrefixes = ScriptUtils.DEFAULT_COMMENT_PREFIXES;
/*     */   
/*  67 */   private String blockCommentStartDelimiter = "/*";
/*     */   
/*  69 */   private String blockCommentEndDelimiter = "*/";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean continueOnError = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignoreFailedDrops = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceDatabasePopulator() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceDatabasePopulator(Resource... scripts) {
/*  91 */     setScripts(scripts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceDatabasePopulator(boolean continueOnError, boolean ignoreFailedDrops, @Nullable String sqlScriptEncoding, Resource... scripts) {
/* 109 */     this.continueOnError = continueOnError;
/* 110 */     this.ignoreFailedDrops = ignoreFailedDrops;
/* 111 */     setSqlScriptEncoding(sqlScriptEncoding);
/* 112 */     setScripts(scripts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addScript(Resource script) {
/* 121 */     Assert.notNull(script, "'script' must not be null");
/* 122 */     this.scripts.add(script);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addScripts(Resource... scripts) {
/* 130 */     assertContentsOfScriptArray(scripts);
/* 131 */     this.scripts.addAll(Arrays.asList(scripts));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScripts(Resource... scripts) {
/* 140 */     assertContentsOfScriptArray(scripts);
/*     */     
/* 142 */     this.scripts = new ArrayList<>(Arrays.asList(scripts));
/*     */   }
/*     */   
/*     */   private void assertContentsOfScriptArray(Resource... scripts) {
/* 146 */     Assert.notNull(scripts, "'scripts' must not be null");
/* 147 */     Assert.noNullElements((Object[])scripts, "'scripts' must not contain null elements");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlScriptEncoding(@Nullable String sqlScriptEncoding) {
/* 158 */     this.sqlScriptEncoding = StringUtils.hasText(sqlScriptEncoding) ? sqlScriptEncoding : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSeparator(String separator) {
/* 169 */     this.separator = separator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommentPrefix(String commentPrefix) {
/* 179 */     Assert.hasText(commentPrefix, "'commentPrefix' must not be null or empty");
/* 180 */     this.commentPrefixes = new String[] { commentPrefix };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommentPrefixes(String... commentPrefixes) {
/* 190 */     Assert.notEmpty((Object[])commentPrefixes, "'commentPrefixes' must not be null or empty");
/* 191 */     Assert.noNullElements((Object[])commentPrefixes, "'commentPrefixes' must not contain null elements");
/* 192 */     this.commentPrefixes = commentPrefixes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlockCommentStartDelimiter(String blockCommentStartDelimiter) {
/* 205 */     Assert.hasText(blockCommentStartDelimiter, "'blockCommentStartDelimiter' must not be null or empty");
/* 206 */     this.blockCommentStartDelimiter = blockCommentStartDelimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlockCommentEndDelimiter(String blockCommentEndDelimiter) {
/* 219 */     Assert.hasText(blockCommentEndDelimiter, "'blockCommentEndDelimiter' must not be null or empty");
/* 220 */     this.blockCommentEndDelimiter = blockCommentEndDelimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContinueOnError(boolean continueOnError) {
/* 229 */     this.continueOnError = continueOnError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreFailedDrops(boolean ignoreFailedDrops) {
/* 241 */     this.ignoreFailedDrops = ignoreFailedDrops;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void populate(Connection connection) throws ScriptException {
/* 251 */     Assert.notNull(connection, "'connection' must not be null");
/* 252 */     for (Resource script : this.scripts) {
/* 253 */       EncodedResource encodedScript = new EncodedResource(script, this.sqlScriptEncoding);
/* 254 */       ScriptUtils.executeSqlScript(connection, encodedScript, this.continueOnError, this.ignoreFailedDrops, this.commentPrefixes, this.separator, this.blockCommentStartDelimiter, this.blockCommentEndDelimiter);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(DataSource dataSource) throws ScriptException {
/* 269 */     DatabasePopulatorUtils.execute(this, dataSource);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\init\ResourceDatabasePopulator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */