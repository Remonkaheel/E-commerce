package org.springframework.jdbc.datasource.init;

import java.sql.Connection;
import java.sql.SQLException;

@FunctionalInterface
public interface DatabasePopulator {
  void populate(Connection paramConnection) throws SQLException, ScriptException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\init\DatabasePopulator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */