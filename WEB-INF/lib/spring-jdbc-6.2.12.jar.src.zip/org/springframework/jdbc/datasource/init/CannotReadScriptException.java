/*    */ package org.springframework.jdbc.datasource.init;
/*    */ 
/*    */ import org.springframework.core.io.support.EncodedResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CannotReadScriptException
/*    */   extends ScriptException
/*    */ {
/*    */   public CannotReadScriptException(EncodedResource resource, Throwable cause) {
/* 37 */     super("Cannot read SQL script from " + String.valueOf(resource), cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\init\CannotReadScriptException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */