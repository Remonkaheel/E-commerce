/*     */ package org.springframework.jdbc.datasource.init;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.LineNumberReader;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.EncodedResource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ScriptUtils
/*     */ {
/*     */   public static final String DEFAULT_STATEMENT_SEPARATOR = ";";
/*     */   public static final String FALLBACK_STATEMENT_SEPARATOR = "\n";
/*     */   public static final String EOF_STATEMENT_SEPARATOR = "^^^ END OF SCRIPT ^^^";
/*     */   public static final String DEFAULT_COMMENT_PREFIX = "--";
/*  89 */   public static final String[] DEFAULT_COMMENT_PREFIXES = new String[] { "--" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_BLOCK_COMMENT_START_DELIMITER = "/*";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_BLOCK_COMMENT_END_DELIMITER = "*/";
/*     */ 
/*     */ 
/*     */   
/* 102 */   private static final Log logger = LogFactory.getLog(ScriptUtils.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void executeSqlScript(Connection connection, Resource resource) throws ScriptException {
/* 126 */     executeSqlScript(connection, new EncodedResource(resource));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void executeSqlScript(Connection connection, EncodedResource resource) throws ScriptException {
/* 150 */     executeSqlScript(connection, resource, false, false, "--", ";", "/*", "*/");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void executeSqlScript(Connection connection, EncodedResource resource, boolean continueOnError, boolean ignoreFailedDrops, String commentPrefix, @Nullable String separator, String blockCommentStartDelimiter, String blockCommentEndDelimiter) throws ScriptException {
/* 188 */     executeSqlScript(connection, resource, continueOnError, ignoreFailedDrops, new String[] { commentPrefix }, separator, blockCommentStartDelimiter, blockCommentEndDelimiter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void executeSqlScript(Connection connection, EncodedResource resource, boolean continueOnError, boolean ignoreFailedDrops, String[] commentPrefixes, @Nullable String separator, String blockCommentStartDelimiter, String blockCommentEndDelimiter) throws ScriptException {
/*     */     try {
/*     */       String script;
/* 229 */       if (logger.isDebugEnabled()) {
/* 230 */         logger.debug("Executing SQL script from " + String.valueOf(resource));
/*     */       }
/* 232 */       long startTime = System.currentTimeMillis();
/*     */ 
/*     */       
/*     */       try {
/* 236 */         script = readScript(resource, separator, commentPrefixes, blockCommentEndDelimiter);
/*     */       }
/* 238 */       catch (IOException ex) {
/* 239 */         throw new CannotReadScriptException(resource, ex);
/*     */       } 
/*     */       
/* 242 */       if (separator == null) {
/* 243 */         separator = ";";
/*     */       }
/* 245 */       if (!"^^^ END OF SCRIPT ^^^".equals(separator) && 
/* 246 */         !containsStatementSeparator(resource, script, separator, commentPrefixes, blockCommentStartDelimiter, blockCommentEndDelimiter))
/*     */       {
/* 248 */         separator = "\n";
/*     */       }
/*     */       
/* 251 */       List<String> statements = new ArrayList<>();
/* 252 */       splitSqlScript(resource, script, separator, commentPrefixes, blockCommentStartDelimiter, blockCommentEndDelimiter, statements);
/*     */ 
/*     */       
/* 255 */       int stmtNumber = 0;
/* 256 */       Statement stmt = connection.createStatement();
/*     */       try {
/* 258 */         label67: for (String statement : statements) {
/* 259 */           stmtNumber++;
/*     */           try {
/* 261 */             boolean hasResultSet = stmt.execute(statement);
/* 262 */             int updateCount = -1;
/* 263 */             if (logger.isDebugEnabled()) {
/* 264 */               logSqlWarnings(stmt);
/*     */             }
/*     */             while (true)
/* 267 */             { if (hasResultSet) {
/*     */ 
/*     */ 
/*     */                 
/* 271 */                 stmt.getResultSet();
/* 272 */                 if (logger.isDebugEnabled()) {
/* 273 */                   logger.debug("ResultSet returned for SQL: " + statement);
/*     */                 }
/*     */               } else {
/*     */                 
/* 277 */                 updateCount = stmt.getUpdateCount();
/* 278 */                 if (updateCount >= 0 && logger.isDebugEnabled()) {
/* 279 */                   logger.debug("" + updateCount + " returned as update count for SQL: " + updateCount);
/*     */                 }
/*     */               } 
/* 282 */               hasResultSet = stmt.getMoreResults();
/* 283 */               if (!hasResultSet && updateCount == -1)
/*     */                 continue label67;  } 
/* 285 */           } catch (SQLException ex) {
/* 286 */             boolean dropStatement = StringUtils.startsWithIgnoreCase(statement.trim(), "drop");
/* 287 */             if (continueOnError || (dropStatement && ignoreFailedDrops)) {
/* 288 */               if (logger.isDebugEnabled()) {
/* 289 */                 logger.debug(ScriptStatementFailedException.buildErrorMessage(statement, stmtNumber, resource), ex);
/*     */               }
/*     */               continue;
/*     */             } 
/* 293 */             throw new ScriptStatementFailedException(statement, stmtNumber, resource, ex);
/*     */           } 
/*     */         } 
/*     */       } finally {
/*     */ 
/*     */         
/*     */         try {
/* 300 */           stmt.close();
/*     */         }
/* 302 */         catch (Throwable ex) {
/* 303 */           logger.trace("Could not close JDBC Statement", ex);
/*     */         } 
/*     */       } 
/*     */       
/* 307 */       long elapsedTime = System.currentTimeMillis() - startTime;
/* 308 */       if (logger.isDebugEnabled()) {
/* 309 */         logger.debug("Executed SQL script from " + String.valueOf(resource) + " in " + elapsedTime + " ms.");
/*     */       }
/*     */     }
/* 312 */     catch (Exception ex) {
/* 313 */       if (ex instanceof ScriptException) { ScriptException scriptException = (ScriptException)ex;
/* 314 */         throw scriptException; }
/*     */       
/* 316 */       throw new UncategorizedScriptException("Failed to execute database script from resource [" + String.valueOf(resource) + "]", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void logSqlWarnings(Statement stmt) throws SQLException {
/* 322 */     SQLWarning warningToLog = stmt.getWarnings();
/* 323 */     while (warningToLog != null) {
/* 324 */       logger.debug("SQLWarning ignored: SQL state '" + warningToLog.getSQLState() + "', error code '" + warningToLog
/* 325 */           .getErrorCode() + "', message [" + warningToLog
/* 326 */           .getMessage() + "]");
/* 327 */       warningToLog = warningToLog.getNextWarning();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String readScript(EncodedResource resource, @Nullable String separator, String[] commentPrefixes, String blockCommentEndDelimiter) throws IOException {
/* 349 */     LineNumberReader lnr = new LineNumberReader(resource.getReader()); 
/* 350 */     try { String str = readScript(lnr, commentPrefixes, separator, blockCommentEndDelimiter);
/* 351 */       lnr.close(); return str; }
/*     */     catch (Throwable throwable) { try {
/*     */         lnr.close();
/*     */       } catch (Throwable throwable1) {
/*     */         throwable.addSuppressed(throwable1);
/*     */       }  throw throwable; }
/* 357 */      } private static String readScript(LineNumberReader lineNumberReader, @Nullable String[] commentPrefixes, @Nullable String separator, @Nullable String blockCommentEndDelimiter) throws IOException { String currentStatement = lineNumberReader.readLine();
/* 358 */     StringBuilder scriptBuilder = new StringBuilder();
/* 359 */     while (currentStatement != null) {
/* 360 */       if ((blockCommentEndDelimiter != null && currentStatement.contains(blockCommentEndDelimiter)) || (commentPrefixes != null && 
/* 361 */         !startsWithAny(currentStatement, commentPrefixes, 0))) {
/* 362 */         if (scriptBuilder.length() > 0) {
/* 363 */           scriptBuilder.append('\n');
/*     */         }
/* 365 */         scriptBuilder.append(currentStatement);
/*     */       } 
/* 367 */       currentStatement = lineNumberReader.readLine();
/*     */     } 
/* 369 */     appendSeparatorToScriptIfNecessary(scriptBuilder, separator);
/* 370 */     return scriptBuilder.toString(); }
/*     */ 
/*     */   
/*     */   private static void appendSeparatorToScriptIfNecessary(StringBuilder scriptBuilder, @Nullable String separator) {
/* 374 */     if (separator == null) {
/*     */       return;
/*     */     }
/* 377 */     String trimmed = separator.trim();
/* 378 */     if (trimmed.length() == separator.length()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 383 */     if (scriptBuilder.lastIndexOf(trimmed) == scriptBuilder.length() - trimmed.length()) {
/* 384 */       scriptBuilder.append(separator.substring(trimmed.length()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean containsStatementSeparator(@Nullable EncodedResource resource, String script, String separator, String[] commentPrefixes, String blockCommentStartDelimiter, String blockCommentEndDelimiter) throws ScriptException {
/* 412 */     boolean inSingleQuote = false;
/* 413 */     boolean inDoubleQuote = false;
/* 414 */     boolean inEscape = false;
/*     */     
/* 416 */     for (int i = 0; i < script.length(); i++) {
/* 417 */       char c = script.charAt(i);
/* 418 */       if (inEscape) {
/* 419 */         inEscape = false;
/*     */ 
/*     */       
/*     */       }
/* 423 */       else if (c == '\\') {
/* 424 */         inEscape = true;
/*     */       } else {
/*     */         
/* 427 */         if (!inDoubleQuote && c == '\'') {
/* 428 */           inSingleQuote = !inSingleQuote;
/*     */         }
/* 430 */         else if (!inSingleQuote && c == '"') {
/* 431 */           inDoubleQuote = !inDoubleQuote;
/*     */         } 
/* 433 */         if (!inSingleQuote && !inDoubleQuote) {
/* 434 */           if (script.startsWith(separator, i)) {
/* 435 */             return true;
/*     */           }
/* 437 */           if (startsWithAny(script, commentPrefixes, i)) {
/*     */             
/* 439 */             int indexOfNextNewline = script.indexOf('\n', i);
/* 440 */             if (indexOfNextNewline > i) {
/* 441 */               i = indexOfNextNewline;
/*     */             }
/*     */             else {
/*     */               
/*     */               break;
/*     */             }
/*     */           
/*     */           }
/* 449 */           else if (script.startsWith(blockCommentStartDelimiter, i)) {
/*     */             
/* 451 */             int indexOfCommentEnd = script.indexOf(blockCommentEndDelimiter, i);
/* 452 */             if (indexOfCommentEnd > i) {
/* 453 */               i = indexOfCommentEnd + blockCommentEndDelimiter.length() - 1;
/*     */             }
/*     */             else {
/*     */               
/* 457 */               throw new ScriptParseException("Missing block comment end delimiter: " + blockCommentEndDelimiter, resource);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 464 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void splitSqlScript(@Nullable EncodedResource resource, String script, String separator, String[] commentPrefixes, String blockCommentStartDelimiter, String blockCommentEndDelimiter, List<String> statements) throws ScriptException {
/* 496 */     Assert.hasText(script, "'script' must not be null or empty");
/* 497 */     Assert.notNull(separator, "'separator' must not be null");
/* 498 */     Assert.notEmpty((Object[])commentPrefixes, "'commentPrefixes' must not be null or empty");
/* 499 */     for (String commentPrefix : commentPrefixes) {
/* 500 */       Assert.hasText(commentPrefix, "'commentPrefixes' must not contain null or empty elements");
/*     */     }
/* 502 */     Assert.hasText(blockCommentStartDelimiter, "'blockCommentStartDelimiter' must not be null or empty");
/* 503 */     Assert.hasText(blockCommentEndDelimiter, "'blockCommentEndDelimiter' must not be null or empty");
/*     */     
/* 505 */     StringBuilder sb = new StringBuilder();
/* 506 */     boolean inSingleQuote = false;
/* 507 */     boolean inDoubleQuote = false;
/* 508 */     boolean inEscape = false;
/*     */     
/* 510 */     for (int i = 0; i < script.length(); i++) {
/* 511 */       char c = script.charAt(i);
/* 512 */       if (inEscape) {
/* 513 */         inEscape = false;
/* 514 */         sb.append(c);
/*     */         
/*     */         continue;
/*     */       } 
/* 518 */       if (c == '\\') {
/* 519 */         inEscape = true;
/* 520 */         sb.append(c);
/*     */         continue;
/*     */       } 
/* 523 */       if (!inDoubleQuote && c == '\'') {
/* 524 */         inSingleQuote = !inSingleQuote;
/*     */       }
/* 526 */       else if (!inSingleQuote && c == '"') {
/* 527 */         inDoubleQuote = !inDoubleQuote;
/*     */       } 
/* 529 */       if (!inSingleQuote && !inDoubleQuote) {
/* 530 */         if (script.startsWith(separator, i)) {
/*     */           
/* 532 */           if (sb.length() > 0) {
/* 533 */             statements.add(sb.toString());
/* 534 */             sb = new StringBuilder();
/*     */           } 
/* 536 */           i += separator.length() - 1;
/*     */           continue;
/*     */         } 
/* 539 */         if (startsWithAny(script, commentPrefixes, i)) {
/*     */           
/* 541 */           int indexOfNextNewline = script.indexOf('\n', i);
/* 542 */           if (indexOfNextNewline > i) {
/* 543 */             i = indexOfNextNewline;
/*     */           } else {
/*     */             break;
/*     */           } 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 551 */         if (script.startsWith(blockCommentStartDelimiter, i)) {
/*     */           
/* 553 */           int indexOfCommentEnd = script.indexOf(blockCommentEndDelimiter, i);
/* 554 */           if (indexOfCommentEnd > i) {
/* 555 */             i = indexOfCommentEnd + blockCommentEndDelimiter.length() - 1;
/*     */           }
/*     */           else {
/*     */             
/* 559 */             throw new ScriptParseException("Missing block comment end delimiter: " + blockCommentEndDelimiter, resource);
/*     */           } 
/*     */           continue;
/*     */         } 
/* 563 */         if (c == ' ' || c == '\r' || c == '\n' || c == '\t')
/*     */         {
/* 565 */           if (sb.length() > 0 && sb.charAt(sb.length() - 1) != ' ') {
/* 566 */             c = ' ';
/*     */           } else {
/*     */             continue;
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 573 */       sb.append(c);
/*     */       continue;
/*     */     } 
/* 576 */     if (StringUtils.hasText(sb)) {
/* 577 */       statements.add(sb.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean startsWithAny(String script, String[] prefixes, int offset) {
/* 582 */     for (String prefix : prefixes) {
/* 583 */       if (script.startsWith(prefix, offset)) {
/* 584 */         return true;
/*     */       }
/*     */     } 
/* 587 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\init\ScriptUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */