/*     */ package org.springframework.jdbc.datasource.init;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceInitializer
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*     */   @Nullable
/*     */   private DataSource dataSource;
/*     */   @Nullable
/*     */   private DatabasePopulator databasePopulator;
/*     */   @Nullable
/*     */   private DatabasePopulator databaseCleaner;
/*     */   private boolean enabled = true;
/*     */   
/*     */   public void setDataSource(DataSource dataSource) {
/*  57 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabasePopulator(@Nullable DatabasePopulator databasePopulator) {
/*  67 */     this.databasePopulator = databasePopulator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabaseCleaner(@Nullable DatabasePopulator databaseCleaner) {
/*  77 */     this.databaseCleaner = databaseCleaner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  87 */     this.enabled = enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  97 */     execute(this.databasePopulator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 106 */     execute(this.databaseCleaner);
/*     */   }
/*     */   
/*     */   private void execute(@Nullable DatabasePopulator populator) {
/* 110 */     Assert.state((this.dataSource != null), "DataSource must be set");
/* 111 */     if (this.enabled && populator != null)
/* 112 */       DatabasePopulatorUtils.execute(populator, this.dataSource); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\init\DataSourceInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */