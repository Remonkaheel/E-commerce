/*    */ package org.springframework.jdbc.datasource.init;
/*    */ 
/*    */ import org.springframework.core.io.support.EncodedResource;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScriptParseException
/*    */   extends ScriptException
/*    */ {
/*    */   public ScriptParseException(String message, @Nullable EncodedResource resource) {
/* 37 */     super(buildMessage(message, resource));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ScriptParseException(String message, @Nullable EncodedResource resource, @Nullable Throwable cause) {
/* 47 */     super(buildMessage(message, resource), cause);
/*    */   }
/*    */ 
/*    */   
/*    */   private static String buildMessage(String message, @Nullable EncodedResource resource) {
/* 52 */     return String.format("Failed to parse SQL script from resource [%s]: %s", new Object[] {
/* 53 */           (resource == null) ? "<unknown>" : resource, message
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\init\ScriptParseException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */