/*    */ package org.springframework.jdbc.datasource.init;
/*    */ 
/*    */ import org.springframework.core.io.support.EncodedResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScriptStatementFailedException
/*    */   extends ScriptException
/*    */ {
/*    */   public ScriptStatementFailedException(String stmt, int stmtNumber, EncodedResource encodedResource, Throwable cause) {
/* 41 */     super(buildErrorMessage(stmt, stmtNumber, encodedResource), cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String buildErrorMessage(String stmt, int stmtNumber, EncodedResource encodedResource) {
/* 57 */     return String.format("Failed to execute SQL script statement #%s of %s: %s", new Object[] { Integer.valueOf(stmtNumber), encodedResource, stmt });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\init\ScriptStatementFailedException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */