/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.support.TransactionSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DataSourceUtils
/*     */ {
/*     */   public static final int CONNECTION_SYNCHRONIZATION_ORDER = 1000;
/*  61 */   private static final Log logger = LogFactory.getLog(DataSourceUtils.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Connection getConnection(DataSource dataSource) throws CannotGetJdbcConnectionException {
/*     */     try {
/*  81 */       return doGetConnection(dataSource);
/*     */     }
/*  83 */     catch (SQLException ex) {
/*  84 */       throw new CannotGetJdbcConnectionException("Failed to obtain JDBC Connection", ex);
/*     */     }
/*  86 */     catch (IllegalStateException ex) {
/*  87 */       throw new CannotGetJdbcConnectionException("Failed to obtain JDBC Connection", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Connection doGetConnection(DataSource dataSource) throws SQLException {
/* 104 */     Assert.notNull(dataSource, "No DataSource specified");
/*     */     
/* 106 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/* 107 */     if (conHolder != null && (conHolder.hasConnection() || conHolder.isSynchronizedWithTransaction())) {
/* 108 */       conHolder.requested();
/* 109 */       if (!conHolder.hasConnection()) {
/* 110 */         logger.debug("Fetching resumed JDBC Connection from DataSource");
/* 111 */         conHolder.setConnection(fetchConnection(dataSource));
/*     */       } 
/* 113 */       return conHolder.getConnection();
/*     */     } 
/*     */ 
/*     */     
/* 117 */     logger.debug("Fetching JDBC Connection from DataSource");
/* 118 */     Connection con = fetchConnection(dataSource);
/*     */     
/* 120 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/*     */       
/*     */       try {
/*     */         
/* 124 */         ConnectionHolder holderToUse = conHolder;
/* 125 */         if (holderToUse == null) {
/* 126 */           holderToUse = new ConnectionHolder(con);
/*     */         } else {
/*     */           
/* 129 */           holderToUse.setConnection(con);
/*     */         } 
/* 131 */         holderToUse.requested();
/* 132 */         TransactionSynchronizationManager.registerSynchronization(new ConnectionSynchronization(holderToUse, dataSource));
/*     */         
/* 134 */         holderToUse.setSynchronizedWithTransaction(true);
/* 135 */         if (holderToUse != conHolder) {
/* 136 */           TransactionSynchronizationManager.bindResource(dataSource, holderToUse);
/*     */         }
/*     */       }
/* 139 */       catch (RuntimeException ex) {
/*     */         
/* 141 */         releaseConnection(con, dataSource);
/* 142 */         throw ex;
/*     */       } 
/*     */     }
/*     */     
/* 146 */     return con;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Connection fetchConnection(DataSource dataSource) throws SQLException {
/* 160 */     Connection con = dataSource.getConnection();
/* 161 */     if (con == null) {
/* 162 */       throw new IllegalStateException("DataSource returned null from getConnection(): " + String.valueOf(dataSource));
/*     */     }
/* 164 */     return con;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Integer prepareConnectionForTransaction(Connection con, @Nullable TransactionDefinition definition) throws SQLException {
/* 181 */     Assert.notNull(con, "No Connection specified");
/*     */     
/* 183 */     boolean debugEnabled = logger.isDebugEnabled();
/*     */     
/* 185 */     if (definition != null && definition.isReadOnly()) {
/*     */       try {
/* 187 */         if (debugEnabled) {
/* 188 */           logger.debug("Setting JDBC Connection [" + String.valueOf(con) + "] read-only");
/*     */         }
/* 190 */         con.setReadOnly(true);
/*     */       }
/* 192 */       catch (SQLException|RuntimeException ex) {
/* 193 */         Throwable exToCheck = ex;
/* 194 */         while (exToCheck != null) {
/* 195 */           if (exToCheck.getClass().getSimpleName().contains("Timeout"))
/*     */           {
/* 197 */             throw ex;
/*     */           }
/* 199 */           exToCheck = exToCheck.getCause();
/*     */         } 
/*     */         
/* 202 */         logger.debug("Could not set JDBC Connection read-only", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 207 */     Integer previousIsolationLevel = null;
/* 208 */     if (definition != null && definition.getIsolationLevel() != -1) {
/* 209 */       if (debugEnabled) {
/* 210 */         logger.debug("Changing isolation level of JDBC Connection [" + String.valueOf(con) + "] to " + definition
/* 211 */             .getIsolationLevel());
/*     */       }
/* 213 */       int currentIsolation = con.getTransactionIsolation();
/* 214 */       if (currentIsolation != definition.getIsolationLevel()) {
/* 215 */         previousIsolationLevel = Integer.valueOf(currentIsolation);
/* 216 */         con.setTransactionIsolation(definition.getIsolationLevel());
/*     */       } 
/*     */     } 
/*     */     
/* 220 */     return previousIsolationLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetConnectionAfterTransaction(Connection con, @Nullable Integer previousIsolationLevel, boolean resetReadOnly) {
/* 237 */     Assert.notNull(con, "No Connection specified");
/* 238 */     boolean debugEnabled = logger.isDebugEnabled();
/*     */     
/*     */     try {
/* 241 */       if (previousIsolationLevel != null) {
/* 242 */         if (debugEnabled) {
/* 243 */           logger.debug("Resetting isolation level of JDBC Connection [" + String.valueOf(con) + "] to " + previousIsolationLevel);
/*     */         }
/*     */         
/* 246 */         con.setTransactionIsolation(previousIsolationLevel.intValue());
/*     */       } 
/*     */ 
/*     */       
/* 250 */       if (resetReadOnly) {
/* 251 */         if (debugEnabled) {
/* 252 */           logger.debug("Resetting read-only flag of JDBC Connection [" + String.valueOf(con) + "]");
/*     */         }
/* 254 */         con.setReadOnly(false);
/*     */       }
/*     */     
/* 257 */     } catch (Throwable ex) {
/* 258 */       logger.debug("Could not reset JDBC Connection after transaction", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void resetConnectionAfterTransaction(Connection con, @Nullable Integer previousIsolationLevel) {
/* 272 */     Assert.notNull(con, "No Connection specified");
/*     */     
/*     */     try {
/* 275 */       if (previousIsolationLevel != null) {
/* 276 */         if (logger.isDebugEnabled()) {
/* 277 */           logger.debug("Resetting isolation level of JDBC Connection [" + String.valueOf(con) + "] to " + previousIsolationLevel);
/*     */         }
/*     */         
/* 280 */         con.setTransactionIsolation(previousIsolationLevel.intValue());
/*     */       } 
/*     */ 
/*     */       
/* 284 */       if (con.isReadOnly()) {
/* 285 */         if (logger.isDebugEnabled()) {
/* 286 */           logger.debug("Resetting read-only flag of JDBC Connection [" + String.valueOf(con) + "]");
/*     */         }
/* 288 */         con.setReadOnly(false);
/*     */       }
/*     */     
/* 291 */     } catch (Throwable ex) {
/* 292 */       logger.debug("Could not reset JDBC Connection after transaction", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isConnectionTransactional(Connection con, @Nullable DataSource dataSource) {
/* 306 */     if (dataSource == null) {
/* 307 */       return false;
/*     */     }
/* 309 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/* 310 */     return (conHolder != null && connectionEquals(conHolder, con));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void applyTransactionTimeout(Statement stmt, @Nullable DataSource dataSource) throws SQLException {
/* 321 */     applyTimeout(stmt, dataSource, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void applyTimeout(Statement stmt, @Nullable DataSource dataSource, int timeout) throws SQLException {
/* 334 */     Assert.notNull(stmt, "No Statement specified");
/* 335 */     ConnectionHolder holder = null;
/* 336 */     if (dataSource != null) {
/* 337 */       holder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/*     */     }
/* 339 */     if (holder != null && holder.hasTimeout()) {
/*     */       
/* 341 */       stmt.setQueryTimeout(holder.getTimeToLiveInSeconds());
/*     */     }
/* 343 */     else if (timeout >= 0) {
/*     */       
/* 345 */       stmt.setQueryTimeout(timeout);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void releaseConnection(@Nullable Connection con, @Nullable DataSource dataSource) {
/*     */     try {
/* 360 */       doReleaseConnection(con, dataSource);
/*     */     }
/* 362 */     catch (SQLException ex) {
/* 363 */       logger.debug("Could not close JDBC Connection", ex);
/*     */     }
/* 365 */     catch (Throwable ex) {
/* 366 */       logger.debug("Unexpected exception on closing JDBC Connection", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void doReleaseConnection(@Nullable Connection con, @Nullable DataSource dataSource) throws SQLException {
/* 382 */     if (con == null) {
/*     */       return;
/*     */     }
/* 385 */     if (dataSource != null) {
/* 386 */       ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/* 387 */       if (conHolder != null && connectionEquals(conHolder, con)) {
/*     */         
/* 389 */         conHolder.released();
/*     */         return;
/*     */       } 
/*     */     } 
/* 393 */     doCloseConnection(con, dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void doCloseConnection(Connection con, @Nullable DataSource dataSource) throws SQLException {
/* 405 */     if (dataSource instanceof SmartDataSource) { SmartDataSource smartDataSource = (SmartDataSource)dataSource; if (smartDataSource.shouldClose(con))
/* 406 */       { con.close(); return; }  return; }  con.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean connectionEquals(ConnectionHolder conHolder, Connection passedInCon) {
/* 421 */     if (!conHolder.hasConnection()) {
/* 422 */       return false;
/*     */     }
/* 424 */     Connection heldCon = conHolder.getConnection();
/*     */ 
/*     */     
/* 427 */     return (heldCon == passedInCon || heldCon.equals(passedInCon) || 
/* 428 */       getTargetConnection(heldCon).equals(passedInCon));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Connection getTargetConnection(Connection con) {
/* 440 */     Connection conToUse = con;
/* 441 */     while (conToUse instanceof ConnectionProxy) { ConnectionProxy connectionProxy = (ConnectionProxy)conToUse;
/* 442 */       Connection targetCon = connectionProxy.getTargetConnection();
/* 443 */       if (targetCon == conToUse) {
/*     */         break;
/*     */       }
/* 446 */       conToUse = targetCon; }
/*     */     
/* 448 */     return conToUse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getConnectionSynchronizationOrder(DataSource dataSource) {
/* 460 */     int order = 1000;
/* 461 */     DataSource currDs = dataSource;
/* 462 */     while (currDs instanceof DelegatingDataSource) { DelegatingDataSource delegatingDataSource = (DelegatingDataSource)currDs;
/* 463 */       order--;
/* 464 */       currDs = delegatingDataSource.getTargetDataSource(); }
/*     */     
/* 466 */     return order;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConnectionSynchronization
/*     */     implements TransactionSynchronization
/*     */   {
/*     */     private final ConnectionHolder connectionHolder;
/*     */ 
/*     */     
/*     */     private final DataSource dataSource;
/*     */ 
/*     */     
/*     */     private final int order;
/*     */     
/*     */     private boolean holderActive = true;
/*     */ 
/*     */     
/*     */     public ConnectionSynchronization(ConnectionHolder connectionHolder, DataSource dataSource) {
/* 486 */       this.connectionHolder = connectionHolder;
/* 487 */       this.dataSource = dataSource;
/* 488 */       this.order = DataSourceUtils.getConnectionSynchronizationOrder(dataSource);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOrder() {
/* 493 */       return this.order;
/*     */     }
/*     */ 
/*     */     
/*     */     public void suspend() {
/* 498 */       if (this.holderActive) {
/* 499 */         TransactionSynchronizationManager.unbindResource(this.dataSource);
/* 500 */         if (this.connectionHolder.hasConnection() && !this.connectionHolder.isOpen()) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 505 */           DataSourceUtils.releaseConnection(this.connectionHolder.getConnection(), this.dataSource);
/* 506 */           this.connectionHolder.setConnection((Connection)null);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void resume() {
/* 513 */       if (this.holderActive) {
/* 514 */         TransactionSynchronizationManager.bindResource(this.dataSource, this.connectionHolder);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void beforeCompletion() {
/* 525 */       if (!this.connectionHolder.isOpen()) {
/* 526 */         TransactionSynchronizationManager.unbindResource(this.dataSource);
/* 527 */         this.holderActive = false;
/* 528 */         if (this.connectionHolder.hasConnection()) {
/* 529 */           DataSourceUtils.releaseConnection(this.connectionHolder.getConnection(), this.dataSource);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void afterCompletion(int status) {
/* 539 */       if (this.holderActive) {
/*     */ 
/*     */         
/* 542 */         TransactionSynchronizationManager.unbindResourceIfPossible(this.dataSource);
/* 543 */         this.holderActive = false;
/* 544 */         if (this.connectionHolder.hasConnection()) {
/* 545 */           DataSourceUtils.releaseConnection(this.connectionHolder.getConnection(), this.dataSource);
/*     */           
/* 547 */           this.connectionHolder.setConnection((Connection)null);
/*     */         } 
/*     */       } 
/* 550 */       this.connectionHolder.reset();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\DataSourceUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */