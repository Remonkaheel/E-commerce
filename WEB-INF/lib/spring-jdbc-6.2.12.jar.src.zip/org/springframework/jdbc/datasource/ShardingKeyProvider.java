/*    */ package org.springframework.jdbc.datasource;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.sql.ShardingKey;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ShardingKeyProvider
/*    */ {
/*    */   @Nullable
/*    */   ShardingKey getShardingKey() throws SQLException;
/*    */   
/*    */   @Nullable
/*    */   default ShardingKey getSuperShardingKey() throws SQLException {
/* 58 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\datasource\ShardingKeyProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */