package org.springframework.jdbc.core;

public interface InterruptibleBatchPreparedStatementSetter extends BatchPreparedStatementSetter {
  boolean isBatchExhausted(int paramInt);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\InterruptibleBatchPreparedStatementSetter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */