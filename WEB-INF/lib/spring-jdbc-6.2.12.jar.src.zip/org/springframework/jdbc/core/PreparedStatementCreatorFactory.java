/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PreparedStatementCreatorFactory
/*     */ {
/*     */   private final String sql;
/*     */   @Nullable
/*     */   private List<SqlParameter> declaredParameters;
/*  53 */   private int resultSetType = 1003;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean updatableResults = false;
/*     */ 
/*     */   
/*     */   private boolean returnGeneratedKeys = false;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String[] generatedKeysColumnNames;
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatementCreatorFactory(String sql) {
/*  69 */     this.sql = sql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatementCreatorFactory(String sql, int... types) {
/*  78 */     this.sql = sql;
/*  79 */     this.declaredParameters = SqlParameter.sqlTypesToAnonymousParameterList(types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatementCreatorFactory(String sql, List<SqlParameter> declaredParameters) {
/*  88 */     this.sql = sql;
/*  89 */     this.declaredParameters = declaredParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getSql() {
/*  98 */     return this.sql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParameter(SqlParameter param) {
/* 107 */     if (this.declaredParameters == null) {
/* 108 */       this.declaredParameters = new ArrayList<>();
/*     */     }
/* 110 */     this.declaredParameters.add(param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResultSetType(int resultSetType) {
/* 121 */     this.resultSetType = resultSetType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpdatableResults(boolean updatableResults) {
/* 128 */     this.updatableResults = updatableResults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReturnGeneratedKeys(boolean returnGeneratedKeys) {
/* 135 */     this.returnGeneratedKeys = returnGeneratedKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGeneratedKeysColumnNames(String... names) {
/* 142 */     this.generatedKeysColumnNames = names;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatementSetter newPreparedStatementSetter(@Nullable List<?> params) {
/* 151 */     return new PreparedStatementCreatorImpl((params != null) ? params : Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatementSetter newPreparedStatementSetter(@Nullable Object[] params) {
/* 159 */     return new PreparedStatementCreatorImpl((params != null) ? Arrays.asList(params) : Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatementCreator newPreparedStatementCreator(@Nullable List<?> params) {
/* 167 */     return new PreparedStatementCreatorImpl((params != null) ? params : Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatementCreator newPreparedStatementCreator(@Nullable Object[] params) {
/* 175 */     return new PreparedStatementCreatorImpl((params != null) ? Arrays.asList(params) : Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatementCreator newPreparedStatementCreator(String sqlToUse, @Nullable Object[] params) {
/* 185 */     return new PreparedStatementCreatorImpl(sqlToUse, 
/* 186 */         (params != null) ? Arrays.asList(params) : Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class PreparedStatementCreatorImpl
/*     */     implements PreparedStatementCreator, PreparedStatementSetter, SqlProvider, ParameterDisposer
/*     */   {
/*     */     private final String actualSql;
/*     */ 
/*     */     
/*     */     private final List<?> parameters;
/*     */ 
/*     */     
/*     */     public PreparedStatementCreatorImpl(List<?> parameters) {
/* 201 */       this(PreparedStatementCreatorFactory.this.sql, parameters);
/*     */     }
/*     */     
/*     */     public PreparedStatementCreatorImpl(String actualSql, List<?> parameters) {
/* 205 */       this.actualSql = actualSql;
/* 206 */       this.parameters = parameters;
/* 207 */       if (PreparedStatementCreatorFactory.this.declaredParameters != null && parameters.size() != PreparedStatementCreatorFactory.this.declaredParameters.size()) {
/*     */         
/* 209 */         Set<String> names = new HashSet<>();
/* 210 */         for (int i = 0; i < parameters.size(); i++) {
/* 211 */           Object param = parameters.get(i);
/* 212 */           if (param instanceof SqlParameterValue) { SqlParameterValue sqlParameterValue = (SqlParameterValue)param;
/* 213 */             names.add(sqlParameterValue.getName()); }
/*     */           else
/*     */           
/* 216 */           { names.add("Parameter #" + i); }
/*     */         
/*     */         } 
/* 219 */         if (names.size() != PreparedStatementCreatorFactory.this.declaredParameters.size()) {
/* 220 */           throw new InvalidDataAccessApiUsageException("SQL [" + PreparedStatementCreatorFactory.this.sql + "]: given " + names
/* 221 */               .size() + " parameters but expected " + PreparedStatementCreatorFactory.this.declaredParameters
/* 222 */               .size());
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
/*     */       PreparedStatement ps;
/* 230 */       if (PreparedStatementCreatorFactory.this.generatedKeysColumnNames != null || PreparedStatementCreatorFactory.this.returnGeneratedKeys) {
/* 231 */         if (PreparedStatementCreatorFactory.this.generatedKeysColumnNames != null) {
/* 232 */           ps = con.prepareStatement(this.actualSql, PreparedStatementCreatorFactory.this.generatedKeysColumnNames);
/*     */         } else {
/*     */           
/* 235 */           ps = con.prepareStatement(this.actualSql, 1);
/*     */         }
/*     */       
/* 238 */       } else if (PreparedStatementCreatorFactory.this.resultSetType == 1003 && !PreparedStatementCreatorFactory.this.updatableResults) {
/* 239 */         ps = con.prepareStatement(this.actualSql);
/*     */       } else {
/*     */         
/* 242 */         ps = con.prepareStatement(this.actualSql, PreparedStatementCreatorFactory.this.resultSetType, 
/* 243 */             PreparedStatementCreatorFactory.this.updatableResults ? 1008 : 1007);
/*     */       } 
/* 245 */       setValues(ps);
/* 246 */       return ps;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setValues(PreparedStatement ps) throws SQLException {
/* 252 */       int sqlColIndx = 1;
/* 253 */       for (int i = 0; i < this.parameters.size(); i++) {
/* 254 */         Object in = this.parameters.get(i);
/* 255 */         SqlParameter declaredParameter = null;
/*     */ 
/*     */         
/* 258 */         if (in instanceof SqlParameterValue) { SqlParameterValue sqlParameterValue = (SqlParameterValue)in;
/* 259 */           in = sqlParameterValue.getValue();
/* 260 */           declaredParameter = sqlParameterValue; }
/*     */         
/* 262 */         else if (PreparedStatementCreatorFactory.this.declaredParameters != null)
/* 263 */         { if (PreparedStatementCreatorFactory.this.declaredParameters.size() <= i) {
/* 264 */             throw new InvalidDataAccessApiUsageException("SQL [" + PreparedStatementCreatorFactory.this.sql + "]: unable to access parameter number " + i + 1 + " given only " + PreparedStatementCreatorFactory.this.declaredParameters
/*     */                 
/* 266 */                 .size() + " parameters");
/*     */           }
/*     */           
/* 269 */           declaredParameter = PreparedStatementCreatorFactory.this.declaredParameters.get(i); }
/*     */         
/* 271 */         if (declaredParameter == null) {
/* 272 */           StatementCreatorUtils.setParameterValue(ps, sqlColIndx++, -2147483648, in); continue;
/*     */         } 
/* 274 */         if (in instanceof Iterable) { Iterable<?> entries = (Iterable)in; if (declaredParameter.getSqlType() != 2003) {
/* 275 */             for (Object entry : entries) {
/* 276 */               if (entry instanceof Object[]) { Object[] valueArray = (Object[])entry;
/* 277 */                 for (Object argValue : valueArray) {
/* 278 */                   StatementCreatorUtils.setParameterValue(ps, sqlColIndx++, declaredParameter, argValue);
/*     */                 }
/*     */                 continue; }
/*     */               
/* 282 */               StatementCreatorUtils.setParameterValue(ps, sqlColIndx++, declaredParameter, entry);
/*     */             } 
/*     */             continue;
/*     */           }  }
/*     */         
/* 287 */         StatementCreatorUtils.setParameterValue(ps, sqlColIndx++, declaredParameter, in);
/*     */         continue;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSql() {
/* 294 */       return PreparedStatementCreatorFactory.this.sql;
/*     */     }
/*     */ 
/*     */     
/*     */     public void cleanupParameters() {
/* 299 */       StatementCreatorUtils.cleanupParameters(this.parameters);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 304 */       return "PreparedStatementCreator: sql=[" + PreparedStatementCreatorFactory.this.sql + "]; parameters=" + String.valueOf(this.parameters);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\PreparedStatementCreatorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */