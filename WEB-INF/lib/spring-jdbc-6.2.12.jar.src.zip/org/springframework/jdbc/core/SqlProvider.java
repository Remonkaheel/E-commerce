package org.springframework.jdbc.core;

import org.springframework.lang.Nullable;

public interface SqlProvider {
  @Nullable
  String getSql();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\SqlProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */