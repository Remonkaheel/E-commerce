/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlOutParameter
/*     */   extends ResultSetSupportingSqlParameter
/*     */ {
/*     */   @Nullable
/*     */   private SqlReturnType sqlReturnType;
/*     */   
/*     */   public SqlOutParameter(String name, int sqlType) {
/*  47 */     super(name, sqlType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlOutParameter(String name, int sqlType, int scale) {
/*  58 */     super(name, sqlType, scale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlOutParameter(String name, int sqlType, @Nullable String typeName) {
/*  68 */     super(name, sqlType, typeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlOutParameter(String name, int sqlType, @Nullable String typeName, @Nullable SqlReturnType sqlReturnType) {
/*  79 */     super(name, sqlType, typeName);
/*  80 */     this.sqlReturnType = sqlReturnType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlOutParameter(String name, int sqlType, ResultSetExtractor<?> rse) {
/*  90 */     super(name, sqlType, rse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlOutParameter(String name, int sqlType, RowCallbackHandler rch) {
/* 100 */     super(name, sqlType, rch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlOutParameter(String name, int sqlType, RowMapper<?> rm) {
/* 110 */     super(name, sqlType, rm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SqlReturnType getSqlReturnType() {
/* 119 */     return this.sqlReturnType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReturnTypeSupported() {
/* 126 */     return (this.sqlReturnType != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\SqlOutParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */