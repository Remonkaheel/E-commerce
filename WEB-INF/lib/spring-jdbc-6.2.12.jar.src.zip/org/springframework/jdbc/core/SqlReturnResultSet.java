/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlReturnResultSet
/*    */   extends ResultSetSupportingSqlParameter
/*    */ {
/*    */   public SqlReturnResultSet(String name, ResultSetExtractor<?> extractor) {
/* 39 */     super(name, 0, extractor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SqlReturnResultSet(String name, RowCallbackHandler handler) {
/* 48 */     super(name, 0, handler);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SqlReturnResultSet(String name, RowMapper<?> mapper) {
/* 57 */     super(name, 0, mapper);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isResultsParameter() {
/* 66 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\SqlReturnResultSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */