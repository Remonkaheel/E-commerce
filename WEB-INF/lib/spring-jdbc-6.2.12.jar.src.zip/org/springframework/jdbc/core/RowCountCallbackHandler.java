/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RowCountCallbackHandler
/*     */   implements RowCallbackHandler
/*     */ {
/*     */   private int rowCount;
/*     */   private int columnCount;
/*     */   @Nullable
/*     */   private int[] columnTypes;
/*     */   @Nullable
/*     */   private String[] columnNames;
/*     */   
/*     */   public final void processRow(ResultSet rs) throws SQLException {
/*  77 */     if (this.rowCount == 0) {
/*  78 */       ResultSetMetaData rsmd = rs.getMetaData();
/*  79 */       this.columnCount = rsmd.getColumnCount();
/*  80 */       this.columnTypes = new int[this.columnCount];
/*  81 */       this.columnNames = new String[this.columnCount];
/*  82 */       for (int i = 0; i < this.columnCount; i++) {
/*  83 */         this.columnTypes[i] = rsmd.getColumnType(i + 1);
/*  84 */         this.columnNames[i] = JdbcUtils.lookupColumnName(rsmd, i + 1);
/*     */       } 
/*     */     } 
/*     */     
/*  88 */     processRow(rs, this.rowCount++);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processRow(ResultSet rs, int rowNum) throws SQLException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final int[] getColumnTypes() {
/* 110 */     return this.columnTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final String[] getColumnNames() {
/* 121 */     return this.columnNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRowCount() {
/* 130 */     return this.rowCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getColumnCount() {
/* 140 */     return this.columnCount;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\RowCountCallbackHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */