/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 176, d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\003\020\000\032\004\030\001H\001\"\006\b\000\020\001\030\0012\016\020\002\032\n \004*\004\030\0010\0030\003H\n¢\006\004\b\005\020\006"}, d2 = {"<anonymous>", "T", "it", "Ljava/sql/ResultSet;", "kotlin.jvm.PlatformType", "extractData", "(Ljava/sql/ResultSet;)Ljava/lang/Object;"})
/*     */ @SourceDebugExtension({"SMAP\nJdbcOperationsExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 JdbcOperationsExtensions.kt\norg/springframework/jdbc/core/JdbcOperationsExtensionsKt$query$1\n*L\n1#1,127:1\n*E\n"})
/*     */ public final class JdbcOperationsExtensionsKt$query$1<T>
/*     */   implements ResultSetExtractor
/*     */ {
/*     */   public JdbcOperationsExtensionsKt$query$1(Function1<ResultSet, T> $function) {}
/*     */   
/*     */   @Nullable
/*     */   public final T extractData(ResultSet it) {
/* 106 */     Intrinsics.checkNotNullExpressionValue(it, "it"); return (T)this.$function.invoke(it);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\JdbcOperationsExtensionsKt$query$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */