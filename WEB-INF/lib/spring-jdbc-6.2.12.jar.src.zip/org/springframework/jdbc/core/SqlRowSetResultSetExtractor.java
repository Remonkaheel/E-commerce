/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import javax.sql.rowset.CachedRowSet;
/*    */ import javax.sql.rowset.RowSetFactory;
/*    */ import javax.sql.rowset.RowSetProvider;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.jdbc.support.rowset.ResultSetWrappingSqlRowSet;
/*    */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlRowSetResultSetExtractor
/*    */   implements ResultSetExtractor<SqlRowSet>
/*    */ {
/*    */   private static final RowSetFactory rowSetFactory;
/*    */   
/*    */   static {
/*    */     try {
/* 48 */       rowSetFactory = RowSetProvider.newFactory();
/*    */     }
/* 50 */     catch (SQLException ex) {
/* 51 */       throw new IllegalStateException("Cannot create RowSetFactory through RowSetProvider", ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SqlRowSet extractData(ResultSet rs) throws SQLException {
/* 58 */     return createSqlRowSet(rs);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected SqlRowSet createSqlRowSet(ResultSet rs) throws SQLException {
/* 74 */     CachedRowSet rowSet = newCachedRowSet();
/* 75 */     rowSet.populate(rs);
/* 76 */     return (SqlRowSet)new ResultSetWrappingSqlRowSet(rowSet);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected CachedRowSet newCachedRowSet() throws SQLException {
/* 90 */     return rowSetFactory.createCachedRowSet();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\SqlRowSetResultSetExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */