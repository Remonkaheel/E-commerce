package org.springframework.jdbc.core;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface RowMapper<T> {
  @Nullable
  T mapRow(ResultSet paramResultSet, int paramInt) throws SQLException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\RowMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */