/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimplePropertyRowMapper<T>
/*     */   implements RowMapper<T>
/*     */ {
/*  77 */   private static final Object NO_DESCRIPTOR = new Object();
/*     */   
/*     */   private final Class<T> mappedClass;
/*     */   
/*     */   private final ConversionService conversionService;
/*     */   
/*     */   private final Constructor<T> mappedConstructor;
/*     */   
/*     */   private final String[] constructorParameterNames;
/*     */   
/*     */   private final TypeDescriptor[] constructorParameterTypes;
/*     */   
/*  89 */   private final Map<String, Object> propertyDescriptors = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimplePropertyRowMapper(Class<T> mappedClass) {
/*  97 */     this(mappedClass, DefaultConversionService.getSharedInstance());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimplePropertyRowMapper(Class<T> mappedClass, ConversionService conversionService) {
/* 107 */     Assert.notNull(mappedClass, "Mapped Class must not be null");
/* 108 */     Assert.notNull(conversionService, "ConversionService must not be null");
/* 109 */     this.mappedClass = mappedClass;
/* 110 */     this.conversionService = conversionService;
/*     */     
/* 112 */     this.mappedConstructor = BeanUtils.getResolvableConstructor(mappedClass);
/* 113 */     int paramCount = this.mappedConstructor.getParameterCount();
/* 114 */     this
/* 115 */       .constructorParameterNames = (paramCount > 0) ? BeanUtils.getParameterNames(this.mappedConstructor) : new String[0];
/* 116 */     this.constructorParameterTypes = new TypeDescriptor[paramCount];
/* 117 */     for (int i = 0; i < paramCount; i++) {
/* 118 */       this.constructorParameterTypes[i] = new TypeDescriptor(new MethodParameter(this.mappedConstructor, i));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T mapRow(ResultSet rs, int rowNumber) throws SQLException {
/* 125 */     Object[] args = new Object[this.constructorParameterNames.length];
/* 126 */     Set<Integer> usedIndex = new HashSet<>();
/* 127 */     for (int i = 0; i < args.length; i++) {
/* 128 */       int j; String name = this.constructorParameterNames[i];
/*     */ 
/*     */       
/*     */       try {
/* 132 */         j = rs.findColumn(name);
/*     */       }
/* 134 */       catch (SQLException ex) {
/*     */         
/* 136 */         j = rs.findColumn(JdbcUtils.convertPropertyNameToUnderscoreName(name));
/*     */       } 
/* 138 */       TypeDescriptor td = this.constructorParameterTypes[i];
/* 139 */       Object value = JdbcUtils.getResultSetValue(rs, j, td.getType());
/* 140 */       usedIndex.add(Integer.valueOf(j));
/* 141 */       args[i] = this.conversionService.convert(value, td);
/*     */     } 
/* 143 */     T mappedObject = (T)BeanUtils.instantiateClass(this.mappedConstructor, args);
/*     */     
/* 145 */     ResultSetMetaData rsmd = rs.getMetaData();
/* 146 */     int columnCount = rsmd.getColumnCount();
/* 147 */     for (int index = 1; index <= columnCount; index++) {
/* 148 */       if (!usedIndex.contains(Integer.valueOf(index))) {
/* 149 */         Object desc = getDescriptor(JdbcUtils.lookupColumnName(rsmd, index));
/* 150 */         if (desc instanceof MethodParameter) { MethodParameter mp = (MethodParameter)desc;
/* 151 */           Method method = mp.getMethod();
/* 152 */           if (method != null) {
/* 153 */             Object value = JdbcUtils.getResultSetValue(rs, index, mp.getParameterType());
/* 154 */             value = this.conversionService.convert(value, new TypeDescriptor(mp));
/* 155 */             ReflectionUtils.makeAccessible(method);
/* 156 */             ReflectionUtils.invokeMethod(method, mappedObject, new Object[] { value });
/*     */           }
/*     */            }
/* 159 */         else if (desc instanceof Field) { Field field = (Field)desc;
/* 160 */           Object value = JdbcUtils.getResultSetValue(rs, index, field.getType());
/* 161 */           value = this.conversionService.convert(value, new TypeDescriptor(field));
/* 162 */           ReflectionUtils.makeAccessible(field);
/* 163 */           ReflectionUtils.setField(field, mappedObject, value); }
/*     */       
/*     */       } 
/*     */     } 
/*     */     
/* 168 */     return mappedObject;
/*     */   }
/*     */   
/*     */   private Object getDescriptor(String column) {
/* 172 */     return this.propertyDescriptors.computeIfAbsent(column, name -> {
/*     */           PropertyDescriptor pd = BeanUtils.getPropertyDescriptor(this.mappedClass, name);
/*     */           if (pd != null && pd.getWriteMethod() != null)
/*     */             return BeanUtils.getWriteMethodParameter(pd); 
/*     */           Field field = ReflectionUtils.findField(this.mappedClass, name);
/*     */           if (field != null)
/*     */             return field; 
/*     */           String adaptedName = JdbcUtils.convertUnderscoreNameToPropertyName(name);
/*     */           if (!adaptedName.equals(name)) {
/*     */             pd = BeanUtils.getPropertyDescriptor(this.mappedClass, adaptedName);
/*     */             if (pd != null && pd.getWriteMethod() != null)
/*     */               return BeanUtils.getWriteMethodParameter(pd); 
/*     */             field = ReflectionUtils.findField(this.mappedClass, adaptedName);
/*     */             if (field != null)
/*     */               return field; 
/*     */           } 
/*     */           PropertyDescriptor[] pds = BeanUtils.getPropertyDescriptors(this.mappedClass);
/*     */           for (PropertyDescriptor candidate : pds) {
/*     */             if (name.equalsIgnoreCase(candidate.getName()))
/*     */               return BeanUtils.getWriteMethodParameter(candidate); 
/*     */           } 
/*     */           field = ReflectionUtils.findFieldIgnoreCase(this.mappedClass, name);
/*     */           return (field != null) ? field : NO_DESCRIPTOR;
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\SimplePropertyRowMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */