/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlInOutParameter
/*     */   extends SqlOutParameter
/*     */ {
/*     */   public SqlInOutParameter(String name, int sqlType) {
/*  40 */     super(name, sqlType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlInOutParameter(String name, int sqlType, int scale) {
/*  51 */     super(name, sqlType, scale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlInOutParameter(String name, int sqlType, String typeName) {
/*  61 */     super(name, sqlType, typeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlInOutParameter(String name, int sqlType, String typeName, SqlReturnType sqlReturnType) {
/*  72 */     super(name, sqlType, typeName, sqlReturnType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlInOutParameter(String name, int sqlType, ResultSetExtractor<?> rse) {
/*  82 */     super(name, sqlType, rse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlInOutParameter(String name, int sqlType, RowCallbackHandler rch) {
/*  92 */     super(name, sqlType, rch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlInOutParameter(String name, int sqlType, RowMapper<?> rm) {
/* 102 */     super(name, sqlType, rm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInputValueProvided() {
/* 111 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\SqlInOutParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */