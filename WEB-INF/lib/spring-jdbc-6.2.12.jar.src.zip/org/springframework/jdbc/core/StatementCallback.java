package org.springframework.jdbc.core;

import java.sql.SQLException;
import java.sql.Statement;
import org.springframework.dao.DataAccessException;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface StatementCallback<T> {
  @Nullable
  T doInStatement(Statement paramStatement) throws SQLException, DataAccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\StatementCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */