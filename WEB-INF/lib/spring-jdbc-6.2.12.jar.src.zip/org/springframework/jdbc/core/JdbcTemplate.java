/*      */ package org.springframework.jdbc.core;
/*      */ 
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Spliterator;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.stream.Stream;
/*      */ import java.util.stream.StreamSupport;
/*      */ import javax.sql.DataSource;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.dao.DataAccessException;
/*      */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*      */ import org.springframework.dao.support.DataAccessUtils;
/*      */ import org.springframework.jdbc.InvalidResultSetAccessException;
/*      */ import org.springframework.jdbc.SQLWarningException;
/*      */ import org.springframework.jdbc.UncategorizedSQLException;
/*      */ import org.springframework.jdbc.datasource.ConnectionProxy;
/*      */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*      */ import org.springframework.jdbc.support.JdbcAccessor;
/*      */ import org.springframework.jdbc.support.JdbcUtils;
/*      */ import org.springframework.jdbc.support.KeyHolder;
/*      */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JdbcTemplate
/*      */   extends JdbcAccessor
/*      */   implements JdbcOperations
/*      */ {
/*      */   private static final String RETURN_RESULT_SET_PREFIX = "#result-set-";
/*      */   private static final String RETURN_UPDATE_COUNT_PREFIX = "#update-count-";
/*      */   private boolean ignoreWarnings = true;
/*  131 */   private int fetchSize = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  137 */   private int maxRows = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  143 */   private int queryTimeout = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean skipResultsProcessing = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean skipUndeclaredResults = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean resultsMapCaseInsensitive = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JdbcTemplate(DataSource dataSource) {
/*  181 */     setDataSource(dataSource);
/*  182 */     afterPropertiesSet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JdbcTemplate(DataSource dataSource, boolean lazyInit) {
/*  193 */     setDataSource(dataSource);
/*  194 */     setLazyInit(lazyInit);
/*  195 */     afterPropertiesSet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIgnoreWarnings(boolean ignoreWarnings) {
/*  210 */     this.ignoreWarnings = ignoreWarnings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIgnoreWarnings() {
/*  217 */     return this.ignoreWarnings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int fetchSize) {
/*  232 */     this.fetchSize = fetchSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() {
/*  239 */     return this.fetchSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxRows(int maxRows) {
/*  255 */     this.maxRows = maxRows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxRows() {
/*  262 */     return this.maxRows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQueryTimeout(int queryTimeout) {
/*  275 */     this.queryTimeout = queryTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getQueryTimeout() {
/*  282 */     return this.queryTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSkipResultsProcessing(boolean skipResultsProcessing) {
/*  292 */     this.skipResultsProcessing = skipResultsProcessing;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSkipResultsProcessing() {
/*  299 */     return this.skipResultsProcessing;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSkipUndeclaredResults(boolean skipUndeclaredResults) {
/*  306 */     this.skipUndeclaredResults = skipUndeclaredResults;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSkipUndeclaredResults() {
/*  313 */     return this.skipUndeclaredResults;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResultsMapCaseInsensitive(boolean resultsMapCaseInsensitive) {
/*  321 */     this.resultsMapCaseInsensitive = resultsMapCaseInsensitive;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isResultsMapCaseInsensitive() {
/*  329 */     return this.resultsMapCaseInsensitive;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T execute(ConnectionCallback<T> action) throws DataAccessException {
/*  340 */     Assert.notNull(action, "Callback object must not be null");
/*      */     
/*  342 */     Connection con = DataSourceUtils.getConnection(obtainDataSource());
/*      */     
/*      */     try {
/*  345 */       Connection conToUse = createConnectionProxy(con);
/*  346 */       return action.doInConnection(conToUse);
/*      */     }
/*  348 */     catch (SQLException ex) {
/*      */ 
/*      */       
/*  351 */       String sql = getSql(action);
/*  352 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  353 */       con = null;
/*  354 */       throw translateException("ConnectionCallback", sql, ex);
/*      */     } finally {
/*      */       
/*  357 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Connection createConnectionProxy(Connection con) {
/*  373 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class
/*  374 */         .getClassLoader(), new Class[] { ConnectionProxy.class }, new CloseSuppressingInvocationHandler(con));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private <T> T execute(StatementCallback<T> action, boolean closeResources) throws DataAccessException {
/*  386 */     Assert.notNull(action, "Callback object must not be null");
/*      */     
/*  388 */     Connection con = DataSourceUtils.getConnection(obtainDataSource());
/*  389 */     Statement stmt = null;
/*      */     try {
/*  391 */       stmt = con.createStatement();
/*  392 */       applyStatementSettings(stmt);
/*  393 */       T result = action.doInStatement(stmt);
/*  394 */       handleWarnings(stmt);
/*  395 */       return result;
/*      */     }
/*  397 */     catch (SQLException ex) {
/*      */ 
/*      */       
/*  400 */       if (stmt != null) {
/*  401 */         handleWarnings(stmt, ex);
/*      */       }
/*  403 */       String sql = getSql(action);
/*  404 */       JdbcUtils.closeStatement(stmt);
/*  405 */       stmt = null;
/*  406 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  407 */       con = null;
/*  408 */       throw translateException("StatementCallback", sql, ex);
/*      */     } finally {
/*      */       
/*  411 */       if (closeResources) {
/*  412 */         JdbcUtils.closeStatement(stmt);
/*  413 */         DataSourceUtils.releaseConnection(con, getDataSource());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T execute(StatementCallback<T> action) throws DataAccessException {
/*  421 */     return execute(action, true);
/*      */   }
/*      */ 
/*      */   
/*      */   public void execute(final String sql) throws DataAccessException {
/*  426 */     if (this.logger.isDebugEnabled()) {
/*  427 */       this.logger.debug("Executing SQL statement [" + sql + "]");
/*      */     }
/*      */     class ExecuteStatementCallback
/*      */       implements StatementCallback<Object>, SqlProvider
/*      */     {
/*      */       @Nullable
/*      */       public Object doInStatement(Statement stmt) throws SQLException
/*      */       {
/*  435 */         stmt.execute(sql);
/*  436 */         return null;
/*      */       }
/*      */       
/*      */       public String getSql() {
/*  440 */         return sql;
/*      */       }
/*      */     };
/*      */     
/*  444 */     execute(new ExecuteStatementCallback(), true);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T query(final String sql, final ResultSetExtractor<T> rse) throws DataAccessException {
/*  450 */     Assert.notNull(sql, "SQL must not be null");
/*  451 */     Assert.notNull(rse, "ResultSetExtractor must not be null");
/*  452 */     if (this.logger.isDebugEnabled()) {
/*  453 */       this.logger.debug("Executing SQL query [" + sql + "]");
/*      */     }
/*      */     class QueryStatementCallback
/*      */       implements StatementCallback<T>, SqlProvider
/*      */     {
/*      */       @Nullable
/*      */       public T doInStatement(Statement stmt) throws SQLException
/*      */       {
/*  461 */         ResultSet rs = null;
/*      */         try {
/*  463 */           rs = stmt.executeQuery(sql);
/*  464 */           return (T)rse.extractData(rs);
/*      */         } finally {
/*      */           
/*  467 */           JdbcUtils.closeResultSet(rs);
/*      */         } 
/*      */       }
/*      */       
/*      */       public String getSql() {
/*  472 */         return sql;
/*      */       }
/*      */     };
/*      */     
/*  476 */     return execute(new QueryStatementCallback(), true);
/*      */   }
/*      */ 
/*      */   
/*      */   public void query(String sql, RowCallbackHandler rch) throws DataAccessException {
/*  481 */     query(sql, new RowCallbackHandlerResultSetExtractor(rch));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<T> query(String sql, RowMapper<T> rowMapper) throws DataAccessException {
/*  486 */     return result(query(sql, new RowMapperResultSetExtractor<>(rowMapper)));
/*      */   }
/*      */   
/*      */   public <T> Stream<T> queryForStream(final String sql, final RowMapper<T> rowMapper) throws DataAccessException {
/*      */     class StreamStatementCallback
/*      */       implements StatementCallback<Stream<T>>, SqlProvider
/*      */     {
/*      */       public Stream<T> doInStatement(Statement stmt) throws SQLException {
/*  494 */         ResultSet rs = stmt.executeQuery(sql);
/*  495 */         Connection con = stmt.getConnection();
/*  496 */         return (new JdbcTemplate.ResultSetSpliterator<>(rs, rowMapper)).stream().onClose(() -> {
/*      */               JdbcUtils.closeResultSet(rs);
/*      */               JdbcUtils.closeStatement(stmt);
/*      */               DataSourceUtils.releaseConnection(con, JdbcTemplate.this.getDataSource());
/*      */             });
/*      */       }
/*      */       
/*      */       public String getSql() {
/*  504 */         return sql;
/*      */       }
/*      */     };
/*      */     
/*  508 */     return result(execute(new StreamStatementCallback(), false));
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, Object> queryForMap(String sql) throws DataAccessException {
/*  513 */     return result(queryForObject(sql, getColumnMapRowMapper()));
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T queryForObject(String sql, RowMapper<T> rowMapper) throws DataAccessException {
/*  519 */     List<T> results = query(sql, rowMapper);
/*  520 */     return (T)DataAccessUtils.nullableSingleResult(results);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T queryForObject(String sql, Class<T> requiredType) throws DataAccessException {
/*  526 */     return queryForObject(sql, getSingleColumnRowMapper(requiredType));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<T> queryForList(String sql, Class<T> elementType) throws DataAccessException {
/*  531 */     return query(sql, getSingleColumnRowMapper(elementType));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Map<String, Object>> queryForList(String sql) throws DataAccessException {
/*  536 */     return query(sql, getColumnMapRowMapper());
/*      */   }
/*      */ 
/*      */   
/*      */   public SqlRowSet queryForRowSet(String sql) throws DataAccessException {
/*  541 */     return result(query(sql, new SqlRowSetResultSetExtractor()));
/*      */   }
/*      */ 
/*      */   
/*      */   public int update(final String sql) throws DataAccessException {
/*  546 */     Assert.notNull(sql, "SQL must not be null");
/*  547 */     if (this.logger.isDebugEnabled()) {
/*  548 */       this.logger.debug("Executing SQL update [" + sql + "]");
/*      */     }
/*      */     class UpdateStatementCallback
/*      */       implements StatementCallback<Integer>, SqlProvider
/*      */     {
/*      */       public Integer doInStatement(Statement stmt) throws SQLException
/*      */       {
/*  555 */         int rows = stmt.executeUpdate(sql);
/*  556 */         if (JdbcTemplate.this.logger.isTraceEnabled()) {
/*  557 */           JdbcTemplate.this.logger.trace("SQL update affected " + rows + " rows");
/*      */         }
/*  559 */         return Integer.valueOf(rows);
/*      */       }
/*      */       
/*      */       public String getSql() {
/*  563 */         return sql;
/*      */       }
/*      */     };
/*      */     
/*  567 */     return updateCount(execute(new UpdateStatementCallback(), true));
/*      */   }
/*      */ 
/*      */   
/*      */   public int[] batchUpdate(String... sql) throws DataAccessException {
/*  572 */     Assert.notEmpty((Object[])sql, "SQL array must not be empty");
/*  573 */     if (this.logger.isDebugEnabled()) {
/*  574 */       this.logger.debug("Executing SQL batch update of " + sql.length + " statements");
/*      */     }
/*      */     class BatchUpdateStatementCallback
/*      */       implements StatementCallback<int[]>, SqlProvider
/*      */     {
/*      */       @Nullable
/*      */       private String currSql;
/*      */ 
/*      */ 
/*      */       
/*      */       public int[] doInStatement(Statement stmt) throws SQLException, DataAccessException {
/*  585 */         int[] rowsAffected = new int[sql.length];
/*  586 */         if (JdbcUtils.supportsBatchUpdates(stmt.getConnection())) {
/*  587 */           for (String sqlStmt : sql) {
/*  588 */             this.currSql = appendSql(this.currSql, sqlStmt);
/*  589 */             stmt.addBatch(sqlStmt);
/*      */           } 
/*      */           try {
/*  592 */             rowsAffected = stmt.executeBatch();
/*      */           }
/*  594 */           catch (BatchUpdateException ex) {
/*  595 */             String batchExceptionSql = null;
/*  596 */             for (int i = 0; i < (ex.getUpdateCounts()).length; i++) {
/*  597 */               if (ex.getUpdateCounts()[i] == -3) {
/*  598 */                 batchExceptionSql = appendSql(batchExceptionSql, sql[i]);
/*      */               }
/*      */             } 
/*  601 */             if (StringUtils.hasLength(batchExceptionSql)) {
/*  602 */               this.currSql = batchExceptionSql;
/*      */             }
/*  604 */             throw ex;
/*      */           } 
/*      */         } else {
/*      */           
/*  608 */           for (int i = 0; i < sql.length; i++) {
/*  609 */             this.currSql = sql[i];
/*  610 */             if (!stmt.execute(sql[i])) {
/*  611 */               rowsAffected[i] = stmt.getUpdateCount();
/*      */             } else {
/*      */               
/*  614 */               throw new InvalidDataAccessApiUsageException("Invalid batch SQL statement: " + sql[i]);
/*      */             } 
/*      */           } 
/*      */         } 
/*  618 */         return rowsAffected;
/*      */       }
/*      */       
/*      */       private String appendSql(@Nullable String sql, String statement) {
/*  622 */         return StringUtils.hasLength(sql) ? (sql + "; " + sql) : statement;
/*      */       }
/*      */ 
/*      */       
/*      */       @Nullable
/*      */       public String getSql() {
/*  628 */         return this.currSql;
/*      */       }
/*      */     };
/*      */     
/*  632 */     int[] result = execute(new BatchUpdateStatementCallback(), true);
/*  633 */     Assert.state((result != null), "No update counts");
/*  634 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private <T> T execute(PreparedStatementCreator psc, PreparedStatementCallback<T> action, boolean closeResources) throws DataAccessException {
/*  646 */     Assert.notNull(psc, "PreparedStatementCreator must not be null");
/*  647 */     Assert.notNull(action, "Callback object must not be null");
/*  648 */     if (this.logger.isDebugEnabled()) {
/*  649 */       String sql = getSql(psc);
/*  650 */       this.logger.debug("Executing prepared SQL statement" + ((sql != null) ? (" [" + sql + "]") : ""));
/*      */     } 
/*      */     
/*  653 */     Connection con = DataSourceUtils.getConnection(obtainDataSource());
/*  654 */     PreparedStatement ps = null;
/*      */     try {
/*  656 */       ps = psc.createPreparedStatement(con);
/*  657 */       applyStatementSettings(ps);
/*  658 */       T result = action.doInPreparedStatement(ps);
/*  659 */       handleWarnings(ps);
/*  660 */       return result;
/*      */     }
/*  662 */     catch (SQLException ex) {
/*      */ 
/*      */       
/*  665 */       if (psc instanceof ParameterDisposer) { ParameterDisposer parameterDisposer = (ParameterDisposer)psc;
/*  666 */         parameterDisposer.cleanupParameters(); }
/*      */       
/*  668 */       if (ps != null) {
/*  669 */         handleWarnings(ps, ex);
/*      */       }
/*  671 */       String sql = getSql(psc);
/*  672 */       psc = null;
/*  673 */       JdbcUtils.closeStatement(ps);
/*  674 */       ps = null;
/*  675 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  676 */       con = null;
/*  677 */       throw translateException("PreparedStatementCallback", sql, ex);
/*      */     } finally {
/*      */       
/*  680 */       if (closeResources) {
/*  681 */         if (psc instanceof ParameterDisposer) { ParameterDisposer parameterDisposer = (ParameterDisposer)psc;
/*  682 */           parameterDisposer.cleanupParameters(); }
/*      */         
/*  684 */         JdbcUtils.closeStatement(ps);
/*  685 */         DataSourceUtils.releaseConnection(con, getDataSource());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T execute(PreparedStatementCreator psc, PreparedStatementCallback<T> action) throws DataAccessException {
/*  695 */     return execute(psc, action, true);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T execute(String sql, PreparedStatementCallback<T> action) throws DataAccessException {
/*  701 */     return execute(new SimplePreparedStatementCreator(sql), action, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T query(PreparedStatementCreator psc, @Nullable final PreparedStatementSetter pss, final ResultSetExtractor<T> rse) throws DataAccessException {
/*  720 */     Assert.notNull(rse, "ResultSetExtractor must not be null");
/*  721 */     this.logger.debug("Executing prepared SQL query");
/*      */     
/*  723 */     return execute(psc, new PreparedStatementCallback<T>()
/*      */         {
/*      */           @Nullable
/*      */           public T doInPreparedStatement(PreparedStatement ps) throws SQLException {
/*  727 */             ResultSet rs = null;
/*      */             try {
/*  729 */               if (pss != null) {
/*  730 */                 pss.setValues(ps);
/*      */               }
/*  732 */               rs = ps.executeQuery();
/*  733 */               return (T)rse.extractData(rs);
/*      */             } finally {
/*      */               
/*  736 */               JdbcUtils.closeResultSet(rs);
/*  737 */               if (pss instanceof ParameterDisposer) { ParameterDisposer parameterDisposer = (ParameterDisposer)pss;
/*  738 */                 parameterDisposer.cleanupParameters(); }
/*      */             
/*      */             } 
/*      */           }
/*      */         },  true);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T query(PreparedStatementCreator psc, ResultSetExtractor<T> rse) throws DataAccessException {
/*  748 */     return query(psc, (PreparedStatementSetter)null, rse);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T query(String sql, @Nullable PreparedStatementSetter pss, ResultSetExtractor<T> rse) throws DataAccessException {
/*  754 */     return query(new SimplePreparedStatementCreator(sql), pss, rse);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T query(String sql, Object[] args, int[] argTypes, ResultSetExtractor<T> rse) throws DataAccessException {
/*  760 */     return query(sql, newArgTypePreparedStatementSetter(args, argTypes), rse);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Nullable
/*      */   public <T> T query(String sql, @Nullable Object[] args, ResultSetExtractor<T> rse) throws DataAccessException {
/*  767 */     return query(sql, newArgPreparedStatementSetter(args), rse);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T query(String sql, ResultSetExtractor<T> rse, @Nullable Object... args) throws DataAccessException {
/*  773 */     return query(sql, newArgPreparedStatementSetter(args), rse);
/*      */   }
/*      */ 
/*      */   
/*      */   public void query(PreparedStatementCreator psc, RowCallbackHandler rch) throws DataAccessException {
/*  778 */     query(psc, new RowCallbackHandlerResultSetExtractor(rch));
/*      */   }
/*      */ 
/*      */   
/*      */   public void query(String sql, @Nullable PreparedStatementSetter pss, RowCallbackHandler rch) throws DataAccessException {
/*  783 */     query(sql, pss, new RowCallbackHandlerResultSetExtractor(rch));
/*      */   }
/*      */ 
/*      */   
/*      */   public void query(String sql, Object[] args, int[] argTypes, RowCallbackHandler rch) throws DataAccessException {
/*  788 */     query(sql, newArgTypePreparedStatementSetter(args, argTypes), rch);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void query(String sql, @Nullable Object[] args, RowCallbackHandler rch) throws DataAccessException {
/*  794 */     query(sql, newArgPreparedStatementSetter(args), rch);
/*      */   }
/*      */ 
/*      */   
/*      */   public void query(String sql, RowCallbackHandler rch, @Nullable Object... args) throws DataAccessException {
/*  799 */     query(sql, newArgPreparedStatementSetter(args), rch);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<T> query(PreparedStatementCreator psc, RowMapper<T> rowMapper) throws DataAccessException {
/*  804 */     return result(query(psc, new RowMapperResultSetExtractor<>(rowMapper)));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<T> query(String sql, @Nullable PreparedStatementSetter pss, RowMapper<T> rowMapper) throws DataAccessException {
/*  809 */     return result(query(sql, pss, new RowMapperResultSetExtractor<>(rowMapper)));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<T> query(String sql, Object[] args, int[] argTypes, RowMapper<T> rowMapper) throws DataAccessException {
/*  814 */     return result(query(sql, args, argTypes, new RowMapperResultSetExtractor<>(rowMapper)));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public <T> List<T> query(String sql, @Nullable Object[] args, RowMapper<T> rowMapper) throws DataAccessException {
/*  820 */     return result(query(sql, args, new RowMapperResultSetExtractor<>(rowMapper)));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<T> query(String sql, RowMapper<T> rowMapper, @Nullable Object... args) throws DataAccessException {
/*  825 */     return result(query(sql, args, new RowMapperResultSetExtractor<>(rowMapper)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Stream<T> queryForStream(PreparedStatementCreator psc, @Nullable PreparedStatementSetter pss, RowMapper<T> rowMapper) throws DataAccessException {
/*  844 */     return result(execute(psc, ps -> { if (pss != null) pss.setValues(ps);  ResultSet rs = ps.executeQuery(); Connection con = ps.getConnection(); return (new ResultSetSpliterator(rs, rowMapper)).stream().onClose(()); }false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Stream<T> queryForStream(PreparedStatementCreator psc, RowMapper<T> rowMapper) throws DataAccessException {
/*  863 */     return queryForStream(psc, (PreparedStatementSetter)null, rowMapper);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Stream<T> queryForStream(String sql, @Nullable PreparedStatementSetter pss, RowMapper<T> rowMapper) throws DataAccessException {
/*  868 */     return queryForStream(new SimplePreparedStatementCreator(sql), pss, rowMapper);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Stream<T> queryForStream(String sql, RowMapper<T> rowMapper, @Nullable Object... args) throws DataAccessException {
/*  873 */     return queryForStream(new SimplePreparedStatementCreator(sql), newArgPreparedStatementSetter(args), rowMapper);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T queryForObject(String sql, Object[] args, int[] argTypes, RowMapper<T> rowMapper) throws DataAccessException {
/*  881 */     List<T> results = query(sql, args, argTypes, new RowMapperResultSetExtractor<>(rowMapper, 1));
/*  882 */     return (T)DataAccessUtils.nullableSingleResult(results);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Nullable
/*      */   public <T> T queryForObject(String sql, @Nullable Object[] args, RowMapper<T> rowMapper) throws DataAccessException {
/*  889 */     List<T> results = query(sql, args, new RowMapperResultSetExtractor<>(rowMapper, 1));
/*  890 */     return (T)DataAccessUtils.nullableSingleResult(results);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T queryForObject(String sql, RowMapper<T> rowMapper, @Nullable Object... args) throws DataAccessException {
/*  896 */     List<T> results = query(sql, args, new RowMapperResultSetExtractor<>(rowMapper, 1));
/*  897 */     return (T)DataAccessUtils.nullableSingleResult(results);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T queryForObject(String sql, Object[] args, int[] argTypes, Class<T> requiredType) throws DataAccessException {
/*  905 */     return queryForObject(sql, args, argTypes, getSingleColumnRowMapper(requiredType));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Nullable
/*      */   public <T> T queryForObject(String sql, @Nullable Object[] args, Class<T> requiredType) throws DataAccessException {
/*  912 */     return queryForObject(sql, args, getSingleColumnRowMapper(requiredType));
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T queryForObject(String sql, Class<T> requiredType, @Nullable Object... args) throws DataAccessException {
/*  918 */     return queryForObject(sql, args, getSingleColumnRowMapper(requiredType));
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, Object> queryForMap(String sql, Object[] args, int[] argTypes) throws DataAccessException {
/*  923 */     return result(queryForObject(sql, args, argTypes, getColumnMapRowMapper()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, Object> queryForMap(String sql, @Nullable Object... args) throws DataAccessException {
/*  928 */     return result(queryForObject(sql, args, getColumnMapRowMapper()));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<T> queryForList(String sql, Object[] args, int[] argTypes, Class<T> elementType) throws DataAccessException {
/*  933 */     return query(sql, args, argTypes, getSingleColumnRowMapper(elementType));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public <T> List<T> queryForList(String sql, @Nullable Object[] args, Class<T> elementType) throws DataAccessException {
/*  939 */     return query(sql, args, getSingleColumnRowMapper(elementType));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<T> queryForList(String sql, Class<T> elementType, @Nullable Object... args) throws DataAccessException {
/*  944 */     return query(sql, args, getSingleColumnRowMapper(elementType));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Map<String, Object>> queryForList(String sql, Object[] args, int[] argTypes) throws DataAccessException {
/*  949 */     return query(sql, args, argTypes, getColumnMapRowMapper());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Map<String, Object>> queryForList(String sql, @Nullable Object... args) throws DataAccessException {
/*  954 */     return query(sql, args, getColumnMapRowMapper());
/*      */   }
/*      */ 
/*      */   
/*      */   public SqlRowSet queryForRowSet(String sql, Object[] args, int[] argTypes) throws DataAccessException {
/*  959 */     return result(query(sql, args, argTypes, new SqlRowSetResultSetExtractor()));
/*      */   }
/*      */ 
/*      */   
/*      */   public SqlRowSet queryForRowSet(String sql, @Nullable Object... args) throws DataAccessException {
/*  964 */     return result(query(sql, args, new SqlRowSetResultSetExtractor()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int update(PreparedStatementCreator psc, @Nullable PreparedStatementSetter pss) throws DataAccessException {
/*  970 */     this.logger.debug("Executing prepared SQL update");
/*      */     
/*  972 */     return updateCount(execute(psc, ps -> { try { if (pss != null) pss.setValues(ps);  int rows = ps.executeUpdate(); if (this.logger.isTraceEnabled()) this.logger.trace("SQL update affected " + rows + " rows");  return Integer.valueOf(rows); } finally { if (pss instanceof ParameterDisposer) { ParameterDisposer parameterDisposer = (ParameterDisposer)pss; parameterDisposer.cleanupParameters(); }  }  }true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int update(PreparedStatementCreator psc) throws DataAccessException {
/*  993 */     return update(psc, (PreparedStatementSetter)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int update(PreparedStatementCreator psc, KeyHolder generatedKeyHolder) throws DataAccessException {
/* 1000 */     Assert.notNull(generatedKeyHolder, "KeyHolder must not be null");
/* 1001 */     this.logger.debug("Executing SQL update and returning generated keys");
/*      */     
/* 1003 */     return updateCount(execute(psc, ps -> { int rows = ps.executeUpdate(); generatedKeyHolder.getKeyList().clear(); storeGeneratedKeys(generatedKeyHolder, ps, 1); if (this.logger.isTraceEnabled()) this.logger.trace("SQL update affected " + rows + " rows and returned " + generatedKeyHolder.getKeyList().size() + " keys");  return Integer.valueOf(rows); }true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int update(String sql, @Nullable PreparedStatementSetter pss) throws DataAccessException {
/* 1016 */     return update(new SimplePreparedStatementCreator(sql), pss);
/*      */   }
/*      */ 
/*      */   
/*      */   public int update(String sql, Object[] args, int[] argTypes) throws DataAccessException {
/* 1021 */     return update(sql, newArgTypePreparedStatementSetter(args, argTypes));
/*      */   }
/*      */ 
/*      */   
/*      */   public int update(String sql, @Nullable Object... args) throws DataAccessException {
/* 1026 */     return update(sql, newArgPreparedStatementSetter(args));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] batchUpdate(PreparedStatementCreator psc, BatchPreparedStatementSetter pss, KeyHolder generatedKeyHolder) throws DataAccessException {
/* 1033 */     int[] result = execute(psc, (PreparedStatementCallback)getPreparedStatementCallback(pss, generatedKeyHolder));
/*      */     
/* 1035 */     Assert.state((result != null), "No result array");
/* 1036 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public int[] batchUpdate(String sql, BatchPreparedStatementSetter pss) throws DataAccessException {
/* 1041 */     if (this.logger.isDebugEnabled()) {
/* 1042 */       this.logger.debug("Executing SQL batch update [" + sql + "]");
/*      */     }
/* 1044 */     int batchSize = pss.getBatchSize();
/* 1045 */     if (batchSize == 0) {
/* 1046 */       return new int[0];
/*      */     }
/*      */     
/* 1049 */     int[] result = execute(sql, (PreparedStatementCallback)getPreparedStatementCallback(pss, (KeyHolder)null));
/* 1050 */     Assert.state((result != null), "No result array");
/* 1051 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public int[] batchUpdate(String sql, List<Object[]> batchArgs) throws DataAccessException {
/* 1056 */     return batchUpdate(sql, batchArgs, new int[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   public int[] batchUpdate(String sql, final List<Object[]> batchArgs, final int[] argTypes) throws DataAccessException {
/* 1061 */     if (batchArgs.isEmpty()) {
/* 1062 */       return new int[0];
/*      */     }
/*      */     
/* 1065 */     return batchUpdate(sql, new BatchPreparedStatementSetter()
/*      */         {
/*      */           
/*      */           public void setValues(PreparedStatement ps, int i) throws SQLException
/*      */           {
/* 1070 */             Object[] values = batchArgs.get(i);
/* 1071 */             int colIndex = 0;
/* 1072 */             for (Object value : values) {
/* 1073 */               colIndex++;
/* 1074 */               if (value instanceof SqlParameterValue) { SqlParameterValue paramValue = (SqlParameterValue)value;
/* 1075 */                 StatementCreatorUtils.setParameterValue(ps, colIndex, paramValue, paramValue.getValue()); }
/*      */               else
/*      */               { int colType;
/*      */                 
/* 1079 */                 if (argTypes.length < colIndex) {
/* 1080 */                   colType = Integer.MIN_VALUE;
/*      */                 } else {
/*      */                   
/* 1083 */                   colType = argTypes[colIndex - 1];
/*      */                 } 
/* 1085 */                 StatementCreatorUtils.setParameterValue(ps, colIndex, colType, value); }
/*      */             
/*      */             } 
/*      */           }
/*      */           
/*      */           public int getBatchSize() {
/* 1091 */             return batchArgs.size();
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> int[][] batchUpdate(String sql, Collection<T> batchArgs, int batchSize, ParameterizedPreparedStatementSetter<T> pss) throws DataAccessException {
/* 1100 */     if (this.logger.isDebugEnabled()) {
/* 1101 */       this.logger.debug("Executing SQL batch update [" + sql + "] with a batch size of " + batchSize);
/*      */     }
/* 1103 */     int[][] result = execute(sql, ps -> {
/*      */           List<int[]> rowsAffected = (List)new ArrayList<>();
/*      */           
/*      */           try {
/*      */             boolean batchSupported = JdbcUtils.supportsBatchUpdates(ps.getConnection());
/*      */             int n = 0;
/*      */             for (T obj : batchArgs) {
/*      */               pss.setValues(ps, obj);
/*      */               n++;
/*      */               if (batchSupported) {
/*      */                 ps.addBatch();
/*      */                 if (n % batchSize == 0 || n == batchArgs.size()) {
/*      */                   if (this.logger.isTraceEnabled()) {
/*      */                     int batchIdx = (n % batchSize == 0) ? (n / batchSize) : (n / batchSize + 1);
/*      */                     int items = n - ((n % batchSize == 0) ? (n / batchSize - 1) : (n / batchSize)) * batchSize;
/*      */                     this.logger.trace("Sending SQL batch update #" + batchIdx + " with " + items + " items");
/*      */                   } 
/*      */                   try {
/*      */                     int[] updateCounts = ps.executeBatch();
/*      */                     rowsAffected.add(updateCounts);
/* 1123 */                   } catch (BatchUpdateException ex) {
/*      */                     throw new AggregatedBatchUpdateException((int[][])rowsAffected.toArray(()), ex);
/*      */                   } 
/*      */                 } 
/*      */                 
/*      */                 continue;
/*      */               } 
/*      */               
/*      */               int j = ps.executeUpdate();
/*      */               rowsAffected.add(new int[] { j });
/*      */             } 
/*      */             int[][] result1 = new int[rowsAffected.size()][];
/*      */             for (int i = 0; i < result1.length; i++) {
/*      */               result1[i] = rowsAffected.get(i);
/*      */             }
/*      */             return result1;
/*      */           } finally {
/*      */             if (pss instanceof ParameterDisposer) {
/*      */               ParameterDisposer parameterDisposer = (ParameterDisposer)pss;
/*      */               parameterDisposer.cleanupParameters();
/*      */             } 
/*      */           } 
/*      */         });
/* 1146 */     Assert.state((result != null), "No result array");
/* 1147 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T execute(CallableStatementCreator csc, CallableStatementCallback<T> action) throws DataAccessException {
/* 1160 */     Assert.notNull(csc, "CallableStatementCreator must not be null");
/* 1161 */     Assert.notNull(action, "Callback object must not be null");
/* 1162 */     if (this.logger.isDebugEnabled()) {
/* 1163 */       String sql = getSql(csc);
/* 1164 */       this.logger.debug("Calling stored procedure" + ((sql != null) ? (" [" + sql + "]") : ""));
/*      */     } 
/*      */     
/* 1167 */     Connection con = DataSourceUtils.getConnection(obtainDataSource());
/* 1168 */     CallableStatement cs = null;
/*      */     try {
/* 1170 */       cs = csc.createCallableStatement(con);
/* 1171 */       applyStatementSettings(cs);
/* 1172 */       T result = action.doInCallableStatement(cs);
/* 1173 */       handleWarnings(cs);
/* 1174 */       return result;
/*      */     }
/* 1176 */     catch (SQLException ex) {
/*      */ 
/*      */       
/* 1179 */       if (csc instanceof ParameterDisposer) { ParameterDisposer parameterDisposer = (ParameterDisposer)csc;
/* 1180 */         parameterDisposer.cleanupParameters(); }
/*      */       
/* 1182 */       if (cs != null) {
/* 1183 */         handleWarnings(cs, ex);
/*      */       }
/* 1185 */       String sql = getSql(csc);
/* 1186 */       csc = null;
/* 1187 */       JdbcUtils.closeStatement(cs);
/* 1188 */       cs = null;
/* 1189 */       DataSourceUtils.releaseConnection(con, getDataSource());
/* 1190 */       con = null;
/* 1191 */       throw translateException("CallableStatementCallback", sql, ex);
/*      */     } finally {
/*      */       
/* 1194 */       if (csc instanceof ParameterDisposer) { ParameterDisposer parameterDisposer = (ParameterDisposer)csc;
/* 1195 */         parameterDisposer.cleanupParameters(); }
/*      */       
/* 1197 */       JdbcUtils.closeStatement(cs);
/* 1198 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T execute(String callString, CallableStatementCallback<T> action) throws DataAccessException {
/* 1205 */     return execute(new SimpleCallableStatementCreator(callString), action);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> call(CallableStatementCreator csc, List<SqlParameter> declaredParameters) throws DataAccessException {
/* 1212 */     List<SqlParameter> updateCountParameters = new ArrayList<>();
/* 1213 */     List<SqlParameter> resultSetParameters = new ArrayList<>();
/* 1214 */     List<SqlParameter> callParameters = new ArrayList<>();
/*      */     
/* 1216 */     for (SqlParameter parameter : declaredParameters) {
/* 1217 */       if (parameter.isResultsParameter()) {
/* 1218 */         if (parameter instanceof SqlReturnResultSet) {
/* 1219 */           resultSetParameters.add(parameter);
/*      */           continue;
/*      */         } 
/* 1222 */         updateCountParameters.add(parameter);
/*      */         
/*      */         continue;
/*      */       } 
/* 1226 */       callParameters.add(parameter);
/*      */     } 
/*      */ 
/*      */     
/* 1230 */     Map<String, Object> result = execute(csc, cs -> {
/*      */           boolean retVal = cs.execute();
/*      */           
/*      */           int updateCount = cs.getUpdateCount();
/*      */           if (this.logger.isTraceEnabled()) {
/*      */             this.logger.trace("CallableStatement.execute() returned '" + retVal + "'");
/*      */             this.logger.trace("CallableStatement.getUpdateCount() returned " + updateCount);
/*      */           } 
/*      */           Map<String, Object> resultsMap = createResultsMap();
/*      */           if (retVal || updateCount != -1) {
/*      */             resultsMap.putAll(extractReturnedResults(cs, updateCountParameters, resultSetParameters, updateCount));
/*      */           }
/*      */           resultsMap.putAll(extractOutputParameters(cs, callParameters));
/*      */           return resultsMap;
/*      */         });
/* 1245 */     Assert.state((result != null), "No result map");
/* 1246 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, Object> extractReturnedResults(CallableStatement cs, @Nullable List<SqlParameter> updateCountParameters, @Nullable List<SqlParameter> resultSetParameters, int updateCount) throws SQLException {
/* 1260 */     Map<String, Object> results = new LinkedHashMap<>(4);
/* 1261 */     int rsIndex = 0;
/* 1262 */     int updateIndex = 0;
/*      */     
/* 1264 */     if (!isSkipResultsProcessing()) {
/*      */       boolean moreResults; do {
/* 1266 */         if (updateCount == -1) {
/* 1267 */           if (resultSetParameters != null && resultSetParameters.size() > rsIndex) {
/* 1268 */             SqlReturnResultSet declaredRsParam = (SqlReturnResultSet)resultSetParameters.get(rsIndex);
/* 1269 */             results.putAll(processResultSet(cs.getResultSet(), declaredRsParam));
/* 1270 */             rsIndex++;
/*      */           
/*      */           }
/* 1273 */           else if (!isSkipUndeclaredResults()) {
/* 1274 */             String rsName = "#result-set-" + rsIndex + 1;
/* 1275 */             SqlReturnResultSet undeclaredRsParam = new SqlReturnResultSet(rsName, getColumnMapRowMapper());
/* 1276 */             if (this.logger.isTraceEnabled()) {
/* 1277 */               this.logger.trace("Added default SqlReturnResultSet parameter named '" + rsName + "'");
/*      */             }
/* 1279 */             results.putAll(processResultSet(cs.getResultSet(), undeclaredRsParam));
/* 1280 */             rsIndex++;
/*      */           
/*      */           }
/*      */         
/*      */         }
/* 1285 */         else if (updateCountParameters != null && updateCountParameters.size() > updateIndex) {
/* 1286 */           SqlReturnUpdateCount ucParam = (SqlReturnUpdateCount)updateCountParameters.get(updateIndex);
/* 1287 */           String declaredUcName = ucParam.getName();
/* 1288 */           results.put(declaredUcName, Integer.valueOf(updateCount));
/* 1289 */           updateIndex++;
/*      */         
/*      */         }
/* 1292 */         else if (!isSkipUndeclaredResults()) {
/* 1293 */           String undeclaredName = "#update-count-" + updateIndex + 1;
/* 1294 */           if (this.logger.isTraceEnabled()) {
/* 1295 */             this.logger.trace("Added default SqlReturnUpdateCount parameter named '" + undeclaredName + "'");
/*      */           }
/* 1297 */           results.put(undeclaredName, Integer.valueOf(updateCount));
/* 1298 */           updateIndex++;
/*      */         } 
/*      */ 
/*      */         
/* 1302 */         moreResults = cs.getMoreResults();
/* 1303 */         updateCount = cs.getUpdateCount();
/* 1304 */         if (!this.logger.isTraceEnabled())
/* 1305 */           continue;  this.logger.trace("CallableStatement.getUpdateCount() returned " + updateCount);
/*      */       
/*      */       }
/* 1308 */       while (moreResults || updateCount != -1);
/*      */     } 
/* 1310 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, Object> extractOutputParameters(CallableStatement cs, List<SqlParameter> parameters) throws SQLException {
/* 1322 */     Map<String, Object> results = CollectionUtils.newLinkedHashMap(parameters.size());
/* 1323 */     int sqlColIndex = 1;
/* 1324 */     for (SqlParameter param : parameters) {
/* 1325 */       if (param instanceof SqlOutParameter) { SqlOutParameter outParam = (SqlOutParameter)param;
/* 1326 */         Assert.state((outParam.getName() != null), "Anonymous parameters not allowed");
/* 1327 */         SqlReturnType returnType = outParam.getSqlReturnType();
/* 1328 */         if (returnType != null) {
/* 1329 */           Object out = returnType.getTypeValue(cs, sqlColIndex, outParam.getSqlType(), outParam.getTypeName());
/* 1330 */           results.put(outParam.getName(), out);
/*      */         } else {
/*      */           
/* 1333 */           Object out = cs.getObject(sqlColIndex);
/* 1334 */           if (out instanceof ResultSet) { ResultSet resultSet = (ResultSet)out;
/* 1335 */             if (outParam.isResultSetSupported()) {
/* 1336 */               results.putAll(processResultSet(resultSet, outParam));
/*      */             } else {
/*      */               
/* 1339 */               String rsName = outParam.getName();
/* 1340 */               SqlReturnResultSet rsParam = new SqlReturnResultSet(rsName, getColumnMapRowMapper());
/* 1341 */               results.putAll(processResultSet(resultSet, rsParam));
/* 1342 */               if (this.logger.isTraceEnabled()) {
/* 1343 */                 this.logger.trace("Added default SqlReturnResultSet parameter named '" + rsName + "'");
/*      */               }
/*      */             }  }
/*      */           else
/*      */           
/* 1348 */           { results.put(outParam.getName(), out); }
/*      */         
/*      */         }  }
/*      */       
/* 1352 */       if (!param.isResultsParameter()) {
/* 1353 */         sqlColIndex++;
/*      */       }
/*      */     } 
/* 1356 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, Object> processResultSet(@Nullable ResultSet rs, ResultSetSupportingSqlParameter param) throws SQLException {
/* 1368 */     if (rs != null) {
/*      */       try {
/* 1370 */         if (param.getRowMapper() != null) {
/* 1371 */           RowMapper<?> rowMapper = param.getRowMapper();
/* 1372 */           Object<?> data = (Object<?>)(new RowMapperResultSetExtractor(rowMapper)).extractData(rs);
/* 1373 */           return (Map)Collections.singletonMap(param.getName(), data);
/*      */         } 
/* 1375 */         if (param.getRowCallbackHandler() != null) {
/* 1376 */           RowCallbackHandler rch = param.getRowCallbackHandler();
/* 1377 */           (new RowCallbackHandlerResultSetExtractor(rch)).extractData(rs);
/* 1378 */           return (Map)Collections.singletonMap(param.getName(), "ResultSet returned from stored procedure was processed");
/*      */         } 
/*      */         
/* 1381 */         if (param.getResultSetExtractor() != null) {
/* 1382 */           Object data = param.getResultSetExtractor().extractData(rs);
/* 1383 */           return Collections.singletonMap(param.getName(), data);
/*      */         } 
/*      */       } finally {
/*      */         
/* 1387 */         JdbcUtils.closeResultSet(rs);
/*      */       } 
/*      */     }
/* 1390 */     return Collections.emptyMap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RowMapper<Map<String, Object>> getColumnMapRowMapper() {
/* 1404 */     return new ColumnMapRowMapper();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T> RowMapper<T> getSingleColumnRowMapper(Class<T> requiredType) {
/* 1414 */     return new SingleColumnRowMapper<>(requiredType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, Object> createResultsMap() {
/* 1427 */     if (isResultsMapCaseInsensitive()) {
/* 1428 */       return (Map<String, Object>)new LinkedCaseInsensitiveMap();
/*      */     }
/*      */     
/* 1431 */     return new LinkedHashMap<>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void applyStatementSettings(Statement stmt) throws SQLException {
/* 1446 */     int fetchSize = getFetchSize();
/* 1447 */     if (fetchSize != -1) {
/* 1448 */       stmt.setFetchSize(fetchSize);
/*      */     }
/* 1450 */     int maxRows = getMaxRows();
/* 1451 */     if (maxRows != -1) {
/* 1452 */       stmt.setMaxRows(maxRows);
/*      */     }
/* 1454 */     DataSourceUtils.applyTimeout(stmt, getDataSource(), getQueryTimeout());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PreparedStatementSetter newArgPreparedStatementSetter(@Nullable Object[] args) {
/* 1465 */     return new ArgumentPreparedStatementSetter(args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PreparedStatementSetter newArgTypePreparedStatementSetter(Object[] args, int[] argTypes) {
/* 1477 */     return new ArgumentTypePreparedStatementSetter(args, argTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleWarnings(Statement stmt, SQLException ex) {
/*      */     try {
/* 1494 */       handleWarnings(stmt);
/*      */     }
/* 1496 */     catch (SQLWarningException nonIgnoredWarning) {
/* 1497 */       ex.setNextException(nonIgnoredWarning.getSQLWarning());
/*      */     }
/* 1499 */     catch (SQLException warningsEx) {
/* 1500 */       this.logger.debug("Failed to retrieve warnings", warningsEx);
/*      */     }
/* 1502 */     catch (Throwable warningsEx) {
/* 1503 */       this.logger.debug("Failed to process warnings", warningsEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleWarnings(Statement stmt) throws SQLException, SQLWarningException {
/* 1519 */     if (isIgnoreWarnings()) {
/* 1520 */       if (this.logger.isDebugEnabled()) {
/* 1521 */         SQLWarning warningToLog = stmt.getWarnings();
/* 1522 */         while (warningToLog != null) {
/* 1523 */           this.logger.debug("SQLWarning ignored: SQL state '" + warningToLog.getSQLState() + "', error code '" + warningToLog
/* 1524 */               .getErrorCode() + "', message [" + warningToLog.getMessage() + "]");
/* 1525 */           warningToLog = warningToLog.getNextWarning();
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 1530 */       handleWarnings(stmt.getWarnings());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleWarnings(@Nullable SQLWarning warning) throws SQLWarningException {
/* 1541 */     if (warning != null) {
/* 1542 */       throw new SQLWarningException("Warning not ignored", warning);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DataAccessException translateException(String task, @Nullable String sql, SQLException ex) {
/* 1556 */     DataAccessException dae = getExceptionTranslator().translate(task, sql, ex);
/* 1557 */     return (dae != null) ? dae : (DataAccessException)new UncategorizedSQLException(task, sql, ex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private static String getSql(Object obj) {
/* 1569 */     SqlProvider sqlProvider = (SqlProvider)obj; return (obj instanceof SqlProvider) ? sqlProvider.getSql() : null;
/*      */   }
/*      */   
/*      */   private static <T> T result(@Nullable T result) {
/* 1573 */     Assert.state((result != null), "No result");
/* 1574 */     return result;
/*      */   }
/*      */   
/*      */   private static int updateCount(@Nullable Integer result) {
/* 1578 */     Assert.state((result != null), "No update count");
/* 1579 */     return result.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void storeGeneratedKeys(KeyHolder generatedKeyHolder, PreparedStatement ps, int rowsExpected) throws SQLException {
/* 1585 */     List<Map<String, Object>> generatedKeys = generatedKeyHolder.getKeyList();
/* 1586 */     ResultSet keys = ps.getGeneratedKeys();
/* 1587 */     if (keys != null) {
/*      */       
/*      */       try {
/* 1590 */         RowMapperResultSetExtractor<Map<String, Object>> rse = new RowMapperResultSetExtractor<>(getColumnMapRowMapper(), rowsExpected);
/* 1591 */         generatedKeys.addAll(result(rse.extractData(keys)));
/*      */       } finally {
/*      */         
/* 1594 */         JdbcUtils.closeResultSet(keys);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private PreparedStatementCallback<int[]> getPreparedStatementCallback(BatchPreparedStatementSetter pss, @Nullable KeyHolder generatedKeyHolder) {
/* 1601 */     return ps -> {
/*      */         try {
/*      */           int batchSize = pss.getBatchSize();
/*      */           InterruptibleBatchPreparedStatementSetter ibpss = (InterruptibleBatchPreparedStatementSetter)pss;
/*      */           InterruptibleBatchPreparedStatementSetter ipss = (pss instanceof InterruptibleBatchPreparedStatementSetter) ? ibpss : null;
/*      */           if (generatedKeyHolder != null) {
/*      */             generatedKeyHolder.getKeyList().clear();
/*      */           }
/*      */           if (JdbcUtils.supportsBatchUpdates(ps.getConnection())) {
/*      */             for (int k = 0; k < batchSize; k++) {
/*      */               pss.setValues(ps, k);
/*      */               if (ipss != null && ipss.isBatchExhausted(k)) {
/*      */                 break;
/*      */               }
/*      */               ps.addBatch();
/*      */             } 
/*      */             int[] results = ps.executeBatch();
/*      */             if (generatedKeyHolder != null) {
/*      */               storeGeneratedKeys(generatedKeyHolder, ps, batchSize);
/*      */             }
/*      */             return results;
/*      */           } 
/*      */           List<Integer> rowsAffected = new ArrayList<>();
/*      */           for (int i = 0; i < batchSize; i++) {
/*      */             pss.setValues(ps, i);
/*      */             if (ipss != null && ipss.isBatchExhausted(i)) {
/*      */               break;
/*      */             }
/*      */             rowsAffected.add(Integer.valueOf(ps.executeUpdate()));
/*      */             if (generatedKeyHolder != null) {
/*      */               storeGeneratedKeys(generatedKeyHolder, ps, 1);
/*      */             }
/*      */           } 
/*      */           int[] rowsAffectedArray = new int[rowsAffected.size()];
/*      */           for (int j = 0; j < rowsAffectedArray.length; j++) {
/*      */             rowsAffectedArray[j] = ((Integer)rowsAffected.get(j)).intValue();
/*      */           }
/*      */           return rowsAffectedArray;
/*      */         } finally {
/*      */           if (pss instanceof ParameterDisposer) {
/*      */             ParameterDisposer parameterDisposer = (ParameterDisposer)pss;
/*      */             parameterDisposer.cleanupParameters();
/*      */           } 
/*      */         } 
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JdbcTemplate() {}
/*      */ 
/*      */ 
/*      */   
/*      */   private class CloseSuppressingInvocationHandler
/*      */     implements InvocationHandler
/*      */   {
/*      */     private final Connection target;
/*      */ 
/*      */     
/*      */     public CloseSuppressingInvocationHandler(Connection target) {
/* 1661 */       this.target = target;
/*      */     } @Nullable
/*      */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*      */       Boolean bool3;
/*      */       Integer integer;
/*      */       Boolean bool2;
/*      */       Connection connection;
/*      */       Boolean bool1;
/* 1669 */       switch (method.getName()) {
/*      */         case "equals":
/* 1671 */           bool3 = Boolean.valueOf((proxy == args[0]));
/*      */         case "hashCode":
/* 1673 */           integer = Integer.valueOf(System.identityHashCode(proxy));
/*      */         case "close":
/* 1675 */           integer = null;
/* 1676 */         case "isClosed": bool2 = Boolean.valueOf(false);
/*      */         case "getTargetConnection":
/* 1678 */           connection = this.target;
/*      */         case "unwrap":
/* 1680 */           connection = ((Class)args[0]).isInstance(proxy) ? (Connection)proxy : this.target.<Connection>unwrap((Class<Connection>)args[0]);
/*      */         case "isWrapperFor":
/* 1682 */           bool1 = Boolean.valueOf((((Class)args[0]).isInstance(proxy) || this.target.isWrapperFor((Class)args[0])));
/*      */       } 
/*      */       
/*      */       try {
/* 1686 */         Object retVal = method.invoke(this.target, args);
/*      */ 
/*      */ 
/*      */         
/* 1690 */         if (retVal instanceof Statement) { Statement statement = (Statement)retVal;
/* 1691 */           JdbcTemplate.this.applyStatementSettings(statement); }
/*      */ 
/*      */         
/* 1694 */         Object object1 = retVal;
/*      */       }
/* 1696 */       catch (InvocationTargetException ex) {
/* 1697 */         throw ex.getTargetException();
/*      */       } 
/*      */       return object1;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class SimplePreparedStatementCreator
/*      */     implements PreparedStatementCreator, SqlProvider
/*      */   {
/*      */     private final String sql;
/*      */ 
/*      */ 
/*      */     
/*      */     public SimplePreparedStatementCreator(String sql) {
/* 1713 */       Assert.notNull(sql, "SQL must not be null");
/* 1714 */       this.sql = sql;
/*      */     }
/*      */ 
/*      */     
/*      */     public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
/* 1719 */       return con.prepareStatement(this.sql);
/*      */     }
/*      */ 
/*      */     
/*      */     public String getSql() {
/* 1724 */       return this.sql;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class SimpleCallableStatementCreator
/*      */     implements CallableStatementCreator, SqlProvider
/*      */   {
/*      */     private final String callString;
/*      */ 
/*      */     
/*      */     public SimpleCallableStatementCreator(String callString) {
/* 1737 */       Assert.notNull(callString, "Call string must not be null");
/* 1738 */       this.callString = callString;
/*      */     }
/*      */ 
/*      */     
/*      */     public CallableStatement createCallableStatement(Connection con) throws SQLException {
/* 1743 */       return con.prepareCall(this.callString);
/*      */     }
/*      */ 
/*      */     
/*      */     public String getSql() {
/* 1748 */       return this.callString;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class RowCallbackHandlerResultSetExtractor
/*      */     implements ResultSetExtractor<Object>
/*      */   {
/*      */     private final RowCallbackHandler rch;
/*      */ 
/*      */ 
/*      */     
/*      */     public RowCallbackHandlerResultSetExtractor(RowCallbackHandler rch) {
/* 1763 */       this.rch = rch;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object extractData(ResultSet rs) throws SQLException {
/* 1769 */       while (rs.next()) {
/* 1770 */         this.rch.processRow(rs);
/*      */       }
/* 1772 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ResultSetSpliterator<T>
/*      */     implements Spliterator<T>
/*      */   {
/*      */     private final ResultSet rs;
/*      */ 
/*      */     
/*      */     private final RowMapper<T> rowMapper;
/*      */ 
/*      */     
/* 1787 */     private int rowNum = 0;
/*      */     
/*      */     public ResultSetSpliterator(ResultSet rs, RowMapper<T> rowMapper) {
/* 1790 */       this.rs = rs;
/* 1791 */       this.rowMapper = rowMapper;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean tryAdvance(Consumer<? super T> action) {
/*      */       try {
/* 1797 */         if (this.rs.next()) {
/* 1798 */           action.accept(this.rowMapper.mapRow(this.rs, this.rowNum++));
/* 1799 */           return true;
/*      */         } 
/* 1801 */         return false;
/*      */       }
/* 1803 */       catch (SQLException ex) {
/* 1804 */         throw new InvalidResultSetAccessException(ex);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Spliterator<T> trySplit() {
/* 1811 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public long estimateSize() {
/* 1816 */       return Long.MAX_VALUE;
/*      */     }
/*      */ 
/*      */     
/*      */     public int characteristics() {
/* 1821 */       return 16;
/*      */     }
/*      */     
/*      */     public Stream<T> stream() {
/* 1825 */       return StreamSupport.stream(this, false);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\JdbcTemplate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */