/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RowMapperResultSetExtractor<T>
/*    */   implements ResultSetExtractor<List<T>>
/*    */ {
/*    */   private final RowMapper<T> rowMapper;
/*    */   private final int rowsExpected;
/*    */   
/*    */   public RowMapperResultSetExtractor(RowMapper<T> rowMapper) {
/* 73 */     this(rowMapper, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RowMapperResultSetExtractor(RowMapper<T> rowMapper, int rowsExpected) {
/* 83 */     Assert.notNull(rowMapper, "RowMapper must not be null");
/* 84 */     this.rowMapper = rowMapper;
/* 85 */     this.rowsExpected = rowsExpected;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<T> extractData(ResultSet rs) throws SQLException {
/* 91 */     List<T> results = (this.rowsExpected > 0) ? new ArrayList<>(this.rowsExpected) : new ArrayList<>();
/* 92 */     int rowNum = 0;
/* 93 */     while (rs.next()) {
/* 94 */       results.add(this.rowMapper.mapRow(rs, rowNum++));
/*    */     }
/* 96 */     return results;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\RowMapperResultSetExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */