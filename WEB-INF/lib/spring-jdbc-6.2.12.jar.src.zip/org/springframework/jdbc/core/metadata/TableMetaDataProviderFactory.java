/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.dao.DataAccessResourceFailureException;
/*    */ import org.springframework.jdbc.support.JdbcUtils;
/*    */ import org.springframework.jdbc.support.MetaDataAccessException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TableMetaDataProviderFactory
/*    */ {
/* 37 */   private static final Log logger = LogFactory.getLog(TableMetaDataProviderFactory.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static TableMetaDataProvider createMetaDataProvider(DataSource dataSource, TableMetaDataContext context) {
/*    */     try {
/* 52 */       return (TableMetaDataProvider)JdbcUtils.extractDatabaseMetaData(dataSource, databaseMetaData -> {
/*    */             TableMetaDataProvider provider;
/*    */ 
/*    */             
/*    */             String databaseProductName = JdbcUtils.commonDatabaseName(databaseMetaData.getDatabaseProductName());
/*    */ 
/*    */             
/*    */             if ("Oracle".equals(databaseProductName)) {
/*    */               provider = new OracleTableMetaDataProvider(databaseMetaData, context.isOverrideIncludeSynonymsDefault());
/*    */             } else if ("PostgreSQL".equals(databaseProductName)) {
/*    */               provider = new PostgresTableMetaDataProvider(databaseMetaData);
/*    */             } else if ("Apache Derby".equals(databaseProductName)) {
/*    */               provider = new DerbyTableMetaDataProvider(databaseMetaData);
/*    */             } else if ("HSQL Database Engine".equals(databaseProductName)) {
/*    */               provider = new HsqlTableMetaDataProvider(databaseMetaData);
/*    */             } else if ("MySQL".equals(databaseProductName) || "MariaDB".equals(databaseProductName)) {
/*    */               provider = new MySQLTableMetaDataProvider(databaseMetaData);
/*    */             } else {
/*    */               provider = new GenericTableMetaDataProvider(databaseMetaData);
/*    */             } 
/*    */ 
/*    */             
/*    */             if (logger.isDebugEnabled()) {
/*    */               logger.debug("Using " + provider.getClass().getSimpleName());
/*    */             }
/*    */ 
/*    */             
/*    */             provider.initializeWithMetaData(databaseMetaData);
/*    */ 
/*    */             
/*    */             if (context.isAccessTableColumnMetaData()) {
/*    */               provider.initializeWithTableColumnMetaData(databaseMetaData, context.getCatalogName(), context.getSchemaName(), context.getTableName());
/*    */             }
/*    */ 
/*    */             
/*    */             return provider;
/*    */           });
/* 89 */     } catch (MetaDataAccessException ex) {
/* 90 */       throw new DataAccessResourceFailureException("Error retrieving database meta-data", ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\TableMetaDataProviderFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */