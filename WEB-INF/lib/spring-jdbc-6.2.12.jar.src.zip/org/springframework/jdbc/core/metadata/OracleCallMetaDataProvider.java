/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.ColumnMapRowMapper;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ import org.springframework.jdbc.core.SqlOutParameter;
/*    */ import org.springframework.jdbc.core.SqlParameter;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OracleCallMetaDataProvider
/*    */   extends GenericCallMetaDataProvider
/*    */ {
/*    */   private static final String REF_CURSOR_NAME = "REF CURSOR";
/*    */   
/*    */   public OracleCallMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/* 41 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isReturnResultSetSupported() {
/* 47 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRefCursorSupported() {
/* 52 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRefCursorSqlType() {
/* 57 */     return -10;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String metaDataCatalogNameToUse(@Nullable String catalogName) {
/* 64 */     return (catalogName == null) ? "" : catalogNameToUse(catalogName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String metaDataSchemaNameToUse(@Nullable String schemaName) {
/* 71 */     return (schemaName == null) ? getUserName() : super.metaDataSchemaNameToUse(schemaName);
/*    */   }
/*    */ 
/*    */   
/*    */   public SqlParameter createDefaultOutParameter(String parameterName, CallParameterMetaData meta) {
/* 76 */     if (meta.getSqlType() == 1111 && "REF CURSOR".equals(meta.getTypeName())) {
/* 77 */       return (SqlParameter)new SqlOutParameter(parameterName, getRefCursorSqlType(), (RowMapper)new ColumnMapRowMapper());
/*    */     }
/*    */     
/* 80 */     return super.createDefaultOutParameter(parameterName, meta);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\OracleCallMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */