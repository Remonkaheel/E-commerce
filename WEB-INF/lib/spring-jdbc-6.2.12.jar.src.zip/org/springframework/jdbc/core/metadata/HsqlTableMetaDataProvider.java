/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HsqlTableMetaDataProvider
/*    */   extends GenericTableMetaDataProvider
/*    */ {
/*    */   public HsqlTableMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/* 33 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isGetGeneratedKeysSimulated() {
/* 39 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSimpleQueryForGetGeneratedKey(String tableName, String keyColumnName) {
/* 44 */     return "select max(identity()) from " + tableName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\HsqlTableMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */