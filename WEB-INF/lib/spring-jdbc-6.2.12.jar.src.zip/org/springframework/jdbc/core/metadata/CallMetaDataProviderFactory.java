/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.jdbc.support.MetaDataAccessException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CallMetaDataProviderFactory
/*     */ {
/*     */   private static final String DB2 = "DB2";
/*     */   private static final String DERBY = "Apache Derby";
/*     */   private static final String HANA = "HDB";
/*     */   private static final String INFORMIX = "Informix Dynamic Server";
/*     */   private static final String MARIA = "MariaDB";
/*     */   private static final String MS_SQL_SERVER = "Microsoft SQL Server";
/*     */   private static final String MYSQL = "MySQL";
/*     */   private static final String ORACLE = "Oracle";
/*     */   private static final String POSTGRES = "PostgreSQL";
/*     */   private static final String SYBASE = "Sybase";
/*  53 */   public static final List<String> supportedDatabaseProductsForProcedures = List.of("Apache Derby", "DB2", "Informix Dynamic Server", "MariaDB", "Microsoft SQL Server", "MySQL", "Oracle", "PostgreSQL", "Sybase");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final List<String> supportedDatabaseProductsForFunctions = List.of("MariaDB", "Microsoft SQL Server", "MySQL", "Oracle", "PostgreSQL");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private static final Log logger = LogFactory.getLog(CallMetaDataProviderFactory.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CallMetaDataProvider createMetaDataProvider(DataSource dataSource, CallMetaDataContext context) {
/*     */     try {
/*  89 */       return (CallMetaDataProvider)JdbcUtils.extractDatabaseMetaData(dataSource, databaseMetaData -> {
/*     */             String databaseProductName = JdbcUtils.commonDatabaseName(databaseMetaData.getDatabaseProductName());
/*     */             if (databaseProductName == null) {
/*     */               databaseProductName = "";
/*     */             }
/*     */             boolean accessProcedureColumnMetaData = context.isAccessCallParameterMetaData();
/*     */             if (context.isFunction()) {
/*     */               if (!supportedDatabaseProductsForFunctions.contains(databaseProductName)) {
/*     */                 if (logger.isInfoEnabled()) {
/*     */                   logger.info(databaseProductName + " is not one of the databases fully supported for function calls -- supported are: " + databaseProductName);
/*     */                 }
/*     */                 if (accessProcedureColumnMetaData) {
/*     */                   logger.info("Metadata processing disabled - you must specify all parameters explicitly");
/*     */                   accessProcedureColumnMetaData = false;
/*     */                 } 
/*     */               } 
/*     */             } else if (!supportedDatabaseProductsForProcedures.contains(databaseProductName)) {
/*     */               if (logger.isInfoEnabled()) {
/*     */                 logger.info(databaseProductName + " is not one of the databases fully supported for procedure calls -- supported are: " + databaseProductName);
/*     */               }
/*     */               if (accessProcedureColumnMetaData) {
/*     */                 logger.info("Metadata processing disabled - you must specify all parameters explicitly");
/*     */                 accessProcedureColumnMetaData = false;
/*     */               } 
/*     */             } 
/*     */             switch (databaseProductName) {
/*     */               case "Oracle":
/*     */               
/*     */               
/*     */               case "PostgreSQL":
/*     */               
/*     */               case "Apache Derby":
/*     */               
/*     */               case "DB2":
/*     */               
/*     */               case "HDB":
/*     */               
/*     */               case "Microsoft SQL Server":
/*     */               
/*     */               case "Sybase":
/*     */               
/*     */               default:
/*     */                 break;
/*     */             } 
/*     */             CallMetaDataProvider provider = new GenericCallMetaDataProvider(databaseMetaData);
/*     */             if (logger.isDebugEnabled()) {
/*     */               logger.debug("Using " + provider.getClass().getName());
/*     */             }
/*     */             provider.initializeWithMetaData(databaseMetaData);
/*     */             if (accessProcedureColumnMetaData) {
/*     */               provider.initializeWithProcedureColumnMetaData(databaseMetaData, context.getCatalogName(), context.getSchemaName(), context.getProcedureName());
/*     */             }
/*     */             return provider;
/*     */           });
/* 143 */     } catch (MetaDataAccessException ex) {
/* 144 */       throw new DataAccessResourceFailureException("Error retrieving database meta-data", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\CallMetaDataProviderFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */