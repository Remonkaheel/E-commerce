package org.springframework.jdbc.core.metadata;

import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.List;
import org.springframework.lang.Nullable;

public interface TableMetaDataProvider {
  void initializeWithMetaData(DatabaseMetaData paramDatabaseMetaData) throws SQLException;
  
  void initializeWithTableColumnMetaData(DatabaseMetaData paramDatabaseMetaData, @Nullable String paramString1, @Nullable String paramString2, @Nullable String paramString3) throws SQLException;
  
  List<TableParameterMetaData> getTableParameterMetaData();
  
  @Nullable
  String tableNameToUse(@Nullable String paramString);
  
  @Nullable
  String columnNameToUse(@Nullable String paramString);
  
  @Nullable
  String catalogNameToUse(@Nullable String paramString);
  
  @Nullable
  String schemaNameToUse(@Nullable String paramString);
  
  @Nullable
  String metaDataCatalogNameToUse(@Nullable String paramString);
  
  @Nullable
  String metaDataSchemaNameToUse(@Nullable String paramString);
  
  boolean isTableColumnMetaDataUsed();
  
  boolean isGetGeneratedKeysSupported();
  
  boolean isGetGeneratedKeysSimulated();
  
  @Nullable
  String getSimpleQueryForGetGeneratedKey(String paramString1, String paramString2);
  
  boolean isGeneratedKeysColumnNameArraySupported();
  
  String getIdentifierQuoteString();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\TableMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */