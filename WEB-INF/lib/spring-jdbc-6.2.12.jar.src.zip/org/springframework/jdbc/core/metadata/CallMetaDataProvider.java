package org.springframework.jdbc.core.metadata;

import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.lang.Nullable;

public interface CallMetaDataProvider {
  void initializeWithMetaData(DatabaseMetaData paramDatabaseMetaData) throws SQLException;
  
  void initializeWithProcedureColumnMetaData(DatabaseMetaData paramDatabaseMetaData, @Nullable String paramString1, @Nullable String paramString2, @Nullable String paramString3) throws SQLException;
  
  List<CallParameterMetaData> getCallParameterMetaData();
  
  @Nullable
  String procedureNameToUse(@Nullable String paramString);
  
  @Nullable
  String catalogNameToUse(@Nullable String paramString);
  
  @Nullable
  String schemaNameToUse(@Nullable String paramString);
  
  @Nullable
  String metaDataCatalogNameToUse(@Nullable String paramString);
  
  @Nullable
  String metaDataSchemaNameToUse(@Nullable String paramString);
  
  @Nullable
  String parameterNameToUse(@Nullable String paramString);
  
  String namedParameterBindingToUse(@Nullable String paramString);
  
  SqlParameter createDefaultOutParameter(String paramString, CallParameterMetaData paramCallParameterMetaData);
  
  SqlParameter createDefaultInOutParameter(String paramString, CallParameterMetaData paramCallParameterMetaData);
  
  SqlParameter createDefaultInParameter(String paramString, CallParameterMetaData paramCallParameterMetaData);
  
  @Nullable
  String getUserName();
  
  boolean isProcedureColumnMetaDataUsed();
  
  boolean isReturnResultSetSupported();
  
  boolean isRefCursorSupported();
  
  int getRefCursorSqlType();
  
  boolean byPassReturnParameter(String paramString);
  
  boolean isSupportsCatalogsInProcedureCalls();
  
  boolean isSupportsSchemasInProcedureCalls();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\CallMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */