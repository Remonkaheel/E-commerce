/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericTableMetaDataProvider
/*     */   implements TableMetaDataProvider
/*     */ {
/*  48 */   protected static final Log logger = LogFactory.getLog(TableMetaDataProvider.class);
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final String userName;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String databaseVersion;
/*     */ 
/*     */   
/*     */   private boolean tableColumnMetaDataUsed = false;
/*     */ 
/*     */   
/*     */   private boolean getGeneratedKeysSupported = true;
/*     */ 
/*     */   
/*     */   private boolean generatedKeysColumnNameArraySupported = true;
/*     */ 
/*     */   
/*     */   private boolean storesUpperCaseIdentifiers = true;
/*     */ 
/*     */   
/*     */   private boolean storesLowerCaseIdentifiers = false;
/*     */ 
/*     */   
/*  74 */   private String identifierQuoteString = " ";
/*     */ 
/*     */   
/*  77 */   private final List<TableParameterMetaData> tableParameterMetaData = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GenericTableMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/*  85 */     this.userName = databaseMetaData.getUserName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeWithMetaData(DatabaseMetaData databaseMetaData) throws SQLException {
/*     */     try {
/*  92 */       setGetGeneratedKeysSupported(databaseMetaData.supportsGetGeneratedKeys());
/*  93 */       setGeneratedKeysColumnNameArraySupported(isGetGeneratedKeysSupported());
/*     */     }
/*  95 */     catch (SQLException ex) {
/*  96 */       if (logger.isWarnEnabled()) {
/*  97 */         logger.warn("Error retrieving 'DatabaseMetaData.supportsGetGeneratedKeys': " + ex.getMessage());
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 102 */       this.databaseVersion = databaseMetaData.getDatabaseProductVersion();
/*     */     }
/* 104 */     catch (SQLException ex) {
/* 105 */       if (logger.isWarnEnabled()) {
/* 106 */         logger.warn("Error retrieving 'DatabaseMetaData.getDatabaseProductVersion': " + ex.getMessage());
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 111 */       setStoresUpperCaseIdentifiers(databaseMetaData.storesUpperCaseIdentifiers());
/*     */     }
/* 113 */     catch (SQLException ex) {
/* 114 */       if (logger.isWarnEnabled()) {
/* 115 */         logger.warn("Error retrieving 'DatabaseMetaData.storesUpperCaseIdentifiers': " + ex.getMessage());
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 120 */       setStoresLowerCaseIdentifiers(databaseMetaData.storesLowerCaseIdentifiers());
/*     */     }
/* 122 */     catch (SQLException ex) {
/* 123 */       if (logger.isWarnEnabled()) {
/* 124 */         logger.warn("Error retrieving 'DatabaseMetaData.storesLowerCaseIdentifiers': " + ex.getMessage());
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 129 */       this.identifierQuoteString = databaseMetaData.getIdentifierQuoteString();
/*     */     }
/* 131 */     catch (SQLException ex) {
/* 132 */       if (logger.isWarnEnabled()) {
/* 133 */         logger.warn("Error retrieving 'DatabaseMetaData.getIdentifierQuoteString': " + ex.getMessage());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeWithTableColumnMetaData(DatabaseMetaData databaseMetaData, @Nullable String catalogName, @Nullable String schemaName, @Nullable String tableName) throws SQLException {
/* 142 */     this.tableColumnMetaDataUsed = true;
/* 143 */     locateTableAndProcessMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<TableParameterMetaData> getTableParameterMetaData() {
/* 148 */     return this.tableParameterMetaData;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String tableNameToUse(@Nullable String tableName) {
/* 154 */     return identifierNameToUse(tableName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String columnNameToUse(@Nullable String columnName) {
/* 160 */     return identifierNameToUse(columnName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String catalogNameToUse(@Nullable String catalogName) {
/* 166 */     return identifierNameToUse(catalogName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String schemaNameToUse(@Nullable String schemaName) {
/* 172 */     return identifierNameToUse(schemaName);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String identifierNameToUse(@Nullable String identifierName) {
/* 177 */     if (identifierName == null) {
/* 178 */       return null;
/*     */     }
/* 180 */     if (isStoresUpperCaseIdentifiers()) {
/* 181 */       return identifierName.toUpperCase(Locale.ROOT);
/*     */     }
/* 183 */     if (isStoresLowerCaseIdentifiers()) {
/* 184 */       return identifierName.toLowerCase(Locale.ROOT);
/*     */     }
/*     */     
/* 187 */     return identifierName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String metaDataCatalogNameToUse(@Nullable String catalogName) {
/* 197 */     return catalogNameToUse(catalogName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String metaDataSchemaNameToUse(@Nullable String schemaName) {
/* 207 */     return schemaNameToUse((schemaName != null) ? schemaName : getDefaultSchema());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getDefaultSchema() {
/* 215 */     return this.userName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getDatabaseVersion() {
/* 223 */     return this.databaseVersion;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTableColumnMetaDataUsed() {
/* 228 */     return this.tableColumnMetaDataUsed;
/*     */   }
/*     */   
/*     */   public void setGetGeneratedKeysSupported(boolean getGeneratedKeysSupported) {
/* 232 */     this.getGeneratedKeysSupported = getGeneratedKeysSupported;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isGetGeneratedKeysSupported() {
/* 237 */     return this.getGeneratedKeysSupported;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isGetGeneratedKeysSimulated() {
/* 242 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSimpleQueryForGetGeneratedKey(String tableName, String keyColumnName) {
/* 248 */     return null;
/*     */   }
/*     */   
/*     */   public void setGeneratedKeysColumnNameArraySupported(boolean generatedKeysColumnNameArraySupported) {
/* 252 */     this.generatedKeysColumnNameArraySupported = generatedKeysColumnNameArraySupported;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isGeneratedKeysColumnNameArraySupported() {
/* 257 */     return this.generatedKeysColumnNameArraySupported;
/*     */   }
/*     */   
/*     */   public void setStoresUpperCaseIdentifiers(boolean storesUpperCaseIdentifiers) {
/* 261 */     this.storesUpperCaseIdentifiers = storesUpperCaseIdentifiers;
/*     */   }
/*     */   
/*     */   public boolean isStoresUpperCaseIdentifiers() {
/* 265 */     return this.storesUpperCaseIdentifiers;
/*     */   }
/*     */   
/*     */   public void setStoresLowerCaseIdentifiers(boolean storesLowerCaseIdentifiers) {
/* 269 */     this.storesLowerCaseIdentifiers = storesLowerCaseIdentifiers;
/*     */   }
/*     */   
/*     */   public boolean isStoresLowerCaseIdentifiers() {
/* 273 */     return this.storesLowerCaseIdentifiers;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getIdentifierQuoteString() {
/* 278 */     return this.identifierQuoteString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void locateTableAndProcessMetaData(DatabaseMetaData databaseMetaData, @Nullable String catalogName, @Nullable String schemaName, @Nullable String tableName) {
/* 288 */     Map<String, TableMetaData> tableMeta = new HashMap<>();
/* 289 */     ResultSet tables = null;
/*     */     try {
/* 291 */       tables = databaseMetaData.getTables(
/* 292 */           catalogNameToUse(catalogName), schemaNameToUse(schemaName), tableNameToUse(tableName), null);
/* 293 */       while (tables != null && tables.next())
/*     */       {
/* 295 */         TableMetaData tmd = new TableMetaData(tables.getString("TABLE_CAT"), tables.getString("TABLE_SCHEM"), tables.getString("TABLE_NAME"));
/* 296 */         if (tmd.schemaName() == null) {
/* 297 */           tableMeta.put((this.userName != null) ? this.userName.toUpperCase(Locale.ROOT) : "", tmd);
/*     */           continue;
/*     */         } 
/* 300 */         tableMeta.put(tmd.schemaName().toUpperCase(Locale.ROOT), tmd);
/*     */       }
/*     */     
/*     */     }
/* 304 */     catch (SQLException ex) {
/* 305 */       if (logger.isWarnEnabled()) {
/* 306 */         logger.warn("Error while accessing table meta-data results: " + ex.getMessage());
/*     */       }
/*     */     } finally {
/*     */       
/* 310 */       JdbcUtils.closeResultSet(tables);
/*     */     } 
/*     */     
/* 313 */     if (tableMeta.isEmpty()) {
/* 314 */       if (logger.isInfoEnabled()) {
/* 315 */         logger.info("Unable to locate table meta-data for '" + tableName + "': column names must be provided");
/*     */       }
/*     */     } else {
/*     */       
/* 319 */       processTableColumns(databaseMetaData, findTableMetaData(schemaName, tableName, tableMeta));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private TableMetaData findTableMetaData(@Nullable String schemaName, @Nullable String tableName, Map<String, TableMetaData> tableMeta) {
/* 326 */     if (schemaName != null) {
/* 327 */       TableMetaData tableMetaData = tableMeta.get(schemaName.toUpperCase(Locale.ROOT));
/* 328 */       if (tableMetaData == null) {
/* 329 */         throw new DataAccessResourceFailureException("Unable to locate table meta-data for '" + tableName + "' in the '" + schemaName + "' schema");
/*     */       }
/*     */       
/* 332 */       return tableMetaData;
/*     */     } 
/* 334 */     if (tableMeta.size() == 1) {
/* 335 */       return tableMeta.values().iterator().next();
/*     */     }
/*     */     
/* 338 */     TableMetaData tmd = tableMeta.get(getDefaultSchema());
/* 339 */     if (tmd == null) {
/* 340 */       tmd = tableMeta.get((this.userName != null) ? this.userName.toUpperCase(Locale.ROOT) : "");
/*     */     }
/* 342 */     if (tmd == null) {
/* 343 */       tmd = tableMeta.get("PUBLIC");
/*     */     }
/* 345 */     if (tmd == null) {
/* 346 */       tmd = tableMeta.get("DBO");
/*     */     }
/* 348 */     if (tmd == null) {
/* 349 */       throw new DataAccessResourceFailureException("Unable to locate table meta-data for '" + tableName + "' in the default schema");
/*     */     }
/*     */     
/* 352 */     return tmd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processTableColumns(DatabaseMetaData databaseMetaData, TableMetaData tmd) {
/* 360 */     ResultSet tableColumns = null;
/* 361 */     String metaDataCatalogName = metaDataCatalogNameToUse(tmd.catalogName());
/* 362 */     String metaDataSchemaName = metaDataSchemaNameToUse(tmd.schemaName());
/* 363 */     String metaDataTableName = tableNameToUse(tmd.tableName());
/* 364 */     if (logger.isDebugEnabled()) {
/* 365 */       logger.debug("Retrieving meta-data for " + metaDataCatalogName + "/" + metaDataSchemaName + "/" + metaDataTableName);
/*     */     }
/*     */     
/*     */     try {
/* 369 */       tableColumns = databaseMetaData.getColumns(metaDataCatalogName, metaDataSchemaName, metaDataTableName, null);
/*     */       
/* 371 */       while (tableColumns != null && tableColumns.next()) {
/* 372 */         String columnName = tableColumns.getString("COLUMN_NAME");
/* 373 */         int dataType = tableColumns.getInt("DATA_TYPE");
/* 374 */         if (dataType == 3) {
/* 375 */           String typeName = tableColumns.getString("TYPE_NAME");
/* 376 */           int decimalDigits = tableColumns.getInt("DECIMAL_DIGITS");
/*     */ 
/*     */ 
/*     */           
/* 380 */           if ("NUMBER".equals(typeName) && decimalDigits == 0) {
/* 381 */             dataType = 2;
/* 382 */             if (logger.isDebugEnabled()) {
/* 383 */               logger.debug("Overriding meta-data: " + columnName + " now NUMERIC instead of DECIMAL");
/*     */             }
/*     */           } 
/*     */         } 
/* 387 */         boolean nullable = tableColumns.getBoolean("NULLABLE");
/* 388 */         TableParameterMetaData meta = new TableParameterMetaData(columnName, dataType, nullable);
/* 389 */         this.tableParameterMetaData.add(meta);
/* 390 */         if (logger.isDebugEnabled()) {
/* 391 */           logger.debug("Retrieved meta-data: '" + meta.getParameterName() + "', sqlType=" + meta
/* 392 */               .getSqlType() + ", nullable=" + meta.isNullable());
/*     */         }
/*     */       }
/*     */     
/* 396 */     } catch (SQLException ex) {
/* 397 */       if (logger.isWarnEnabled()) {
/* 398 */         logger.warn("Error while retrieving meta-data for table columns. Consider specifying explicit column names -- for example, via SimpleJdbcInsert#usingColumns().", ex);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 403 */       this.tableParameterMetaData.clear();
/*     */     } finally {
/*     */       
/* 406 */       JdbcUtils.closeResultSet(tableColumns);
/*     */     } 
/*     */   }
/*     */   private static final class TableMetaData extends Record { @Nullable
/*     */     private final String catalogName; @Nullable
/*     */     private final String schemaName; @Nullable
/*     */     private final String tableName;
/*     */     
/* 414 */     private TableMetaData(@Nullable String catalogName, @Nullable String schemaName, @Nullable String tableName) { this.catalogName = catalogName; this.schemaName = schemaName; this.tableName = tableName; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/jdbc/core/metadata/GenericTableMetaDataProvider$TableMetaData;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #414	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 414 */       //   0	7	0	this	Lorg/springframework/jdbc/core/metadata/GenericTableMetaDataProvider$TableMetaData; } @Nullable public String catalogName() { return this.catalogName; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/jdbc/core/metadata/GenericTableMetaDataProvider$TableMetaData;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #414	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/jdbc/core/metadata/GenericTableMetaDataProvider$TableMetaData; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/jdbc/core/metadata/GenericTableMetaDataProvider$TableMetaData;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #414	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/jdbc/core/metadata/GenericTableMetaDataProvider$TableMetaData;
/* 414 */       //   0	8	1	o	Ljava/lang/Object; } @Nullable public String schemaName() { return this.schemaName; } @Nullable public String tableName() { return this.tableName; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\GenericTableMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */