/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DerbyTableMetaDataProvider
/*    */   extends GenericTableMetaDataProvider
/*    */ {
/*    */   private boolean supportsGeneratedKeysOverride = false;
/*    */   
/*    */   public DerbyTableMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/* 35 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void initializeWithMetaData(DatabaseMetaData databaseMetaData) throws SQLException {
/* 41 */     super.initializeWithMetaData(databaseMetaData);
/* 42 */     if (!databaseMetaData.supportsGetGeneratedKeys()) {
/* 43 */       if (logger.isInfoEnabled()) {
/* 44 */         logger.info("Overriding supportsGetGeneratedKeys from DatabaseMetaData to 'true'; it was reported as 'false' by " + databaseMetaData
/* 45 */             .getDriverName() + " " + databaseMetaData.getDriverVersion());
/*    */       }
/* 47 */       this.supportsGeneratedKeysOverride = true;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isGetGeneratedKeysSupported() {
/* 53 */     return (super.isGetGeneratedKeysSupported() || this.supportsGeneratedKeysOverride);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\DerbyTableMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */