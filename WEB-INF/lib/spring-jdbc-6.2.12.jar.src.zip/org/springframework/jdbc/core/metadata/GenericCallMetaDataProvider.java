/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.SqlInOutParameter;
/*     */ import org.springframework.jdbc.core.SqlOutParameter;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericCallMetaDataProvider
/*     */   implements CallMetaDataProvider
/*     */ {
/*  51 */   protected static final Log logger = LogFactory.getLog(CallMetaDataProvider.class);
/*     */ 
/*     */   
/*     */   private final String userName;
/*     */   
/*     */   private boolean procedureColumnMetaDataUsed = false;
/*     */   
/*     */   private boolean supportsCatalogsInProcedureCalls = true;
/*     */   
/*     */   private boolean supportsSchemasInProcedureCalls = true;
/*     */   
/*     */   private boolean storesUpperCaseIdentifiers = true;
/*     */   
/*     */   private boolean storesLowerCaseIdentifiers = false;
/*     */   
/*  66 */   private final List<CallParameterMetaData> callParameterMetaData = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GenericCallMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/*  74 */     this.userName = databaseMetaData.getUserName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeWithMetaData(DatabaseMetaData databaseMetaData) throws SQLException {
/*     */     try {
/*  81 */       setSupportsCatalogsInProcedureCalls(databaseMetaData.supportsCatalogsInProcedureCalls());
/*     */     }
/*  83 */     catch (SQLException ex) {
/*  84 */       if (logger.isWarnEnabled()) {
/*  85 */         logger.warn("Error retrieving 'DatabaseMetaData.supportsCatalogsInProcedureCalls': " + ex.getMessage());
/*     */       }
/*     */     } 
/*     */     try {
/*  89 */       setSupportsSchemasInProcedureCalls(databaseMetaData.supportsSchemasInProcedureCalls());
/*     */     }
/*  91 */     catch (SQLException ex) {
/*  92 */       if (logger.isWarnEnabled()) {
/*  93 */         logger.warn("Error retrieving 'DatabaseMetaData.supportsSchemasInProcedureCalls': " + ex.getMessage());
/*     */       }
/*     */     } 
/*     */     try {
/*  97 */       setStoresUpperCaseIdentifiers(databaseMetaData.storesUpperCaseIdentifiers());
/*     */     }
/*  99 */     catch (SQLException ex) {
/* 100 */       if (logger.isWarnEnabled()) {
/* 101 */         logger.warn("Error retrieving 'DatabaseMetaData.storesUpperCaseIdentifiers': " + ex.getMessage());
/*     */       }
/*     */     } 
/*     */     try {
/* 105 */       setStoresLowerCaseIdentifiers(databaseMetaData.storesLowerCaseIdentifiers());
/*     */     }
/* 107 */     catch (SQLException ex) {
/* 108 */       if (logger.isWarnEnabled()) {
/* 109 */         logger.warn("Error retrieving 'DatabaseMetaData.storesLowerCaseIdentifiers': " + ex.getMessage());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeWithProcedureColumnMetaData(DatabaseMetaData databaseMetaData, @Nullable String catalogName, @Nullable String schemaName, @Nullable String procedureName) throws SQLException {
/* 118 */     this.procedureColumnMetaDataUsed = true;
/* 119 */     processProcedureColumns(databaseMetaData, catalogName, schemaName, procedureName);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<CallParameterMetaData> getCallParameterMetaData() {
/* 124 */     return this.callParameterMetaData;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String procedureNameToUse(@Nullable String procedureName) {
/* 130 */     return identifierNameToUse(procedureName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String catalogNameToUse(@Nullable String catalogName) {
/* 136 */     return identifierNameToUse(catalogName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String schemaNameToUse(@Nullable String schemaName) {
/* 142 */     return identifierNameToUse(schemaName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String metaDataCatalogNameToUse(@Nullable String catalogName) {
/* 148 */     if (isSupportsCatalogsInProcedureCalls()) {
/* 149 */       return catalogNameToUse(catalogName);
/*     */     }
/*     */     
/* 152 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String metaDataSchemaNameToUse(@Nullable String schemaName) {
/* 159 */     if (isSupportsSchemasInProcedureCalls()) {
/* 160 */       return schemaNameToUse(schemaName);
/*     */     }
/*     */     
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String parameterNameToUse(@Nullable String parameterName) {
/* 170 */     return identifierNameToUse(parameterName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String namedParameterBindingToUse(@Nullable String parameterName) {
/* 175 */     return parameterName + " => ?";
/*     */   }
/*     */ 
/*     */   
/*     */   public SqlParameter createDefaultOutParameter(String parameterName, CallParameterMetaData meta) {
/* 180 */     return (SqlParameter)new SqlOutParameter(parameterName, meta.getSqlType());
/*     */   }
/*     */ 
/*     */   
/*     */   public SqlParameter createDefaultInOutParameter(String parameterName, CallParameterMetaData meta) {
/* 185 */     return (SqlParameter)new SqlInOutParameter(parameterName, meta.getSqlType());
/*     */   }
/*     */ 
/*     */   
/*     */   public SqlParameter createDefaultInParameter(String parameterName, CallParameterMetaData meta) {
/* 190 */     return new SqlParameter(parameterName, meta.getSqlType());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUserName() {
/* 195 */     return this.userName;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isProcedureColumnMetaDataUsed() {
/* 200 */     return this.procedureColumnMetaDataUsed;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReturnResultSetSupported() {
/* 205 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRefCursorSupported() {
/* 210 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRefCursorSqlType() {
/* 215 */     return 1111;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean byPassReturnParameter(String parameterName) {
/* 220 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSupportsCatalogsInProcedureCalls(boolean supportsCatalogsInProcedureCalls) {
/* 227 */     this.supportsCatalogsInProcedureCalls = supportsCatalogsInProcedureCalls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSupportsCatalogsInProcedureCalls() {
/* 235 */     return this.supportsCatalogsInProcedureCalls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSupportsSchemasInProcedureCalls(boolean supportsSchemasInProcedureCalls) {
/* 242 */     this.supportsSchemasInProcedureCalls = supportsSchemasInProcedureCalls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSupportsSchemasInProcedureCalls() {
/* 250 */     return this.supportsSchemasInProcedureCalls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setStoresUpperCaseIdentifiers(boolean storesUpperCaseIdentifiers) {
/* 257 */     this.storesUpperCaseIdentifiers = storesUpperCaseIdentifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isStoresUpperCaseIdentifiers() {
/* 264 */     return this.storesUpperCaseIdentifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setStoresLowerCaseIdentifiers(boolean storesLowerCaseIdentifiers) {
/* 271 */     this.storesLowerCaseIdentifiers = storesLowerCaseIdentifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isStoresLowerCaseIdentifiers() {
/* 278 */     return this.storesLowerCaseIdentifiers;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String identifierNameToUse(@Nullable String identifierName) {
/* 284 */     if (identifierName == null) {
/* 285 */       return null;
/*     */     }
/* 287 */     if (isStoresUpperCaseIdentifiers()) {
/* 288 */       return identifierName.toUpperCase(Locale.ROOT);
/*     */     }
/* 290 */     if (isStoresLowerCaseIdentifiers()) {
/* 291 */       return identifierName.toLowerCase(Locale.ROOT);
/*     */     }
/*     */     
/* 294 */     return identifierName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processProcedureColumns(DatabaseMetaData databaseMetaData, @Nullable String catalogName, @Nullable String schemaName, @Nullable String procedureName) {
/* 304 */     String metaDataCatalogName = metaDataCatalogNameToUse(catalogName);
/* 305 */     String metaDataSchemaName = metaDataSchemaNameToUse(schemaName);
/* 306 */     String metaDataProcedureName = procedureNameToUse(procedureName);
/*     */     try {
/* 308 */       ProcedureMetadata procedureMetadata = getProcedureMetadata(databaseMetaData, metaDataCatalogName, metaDataSchemaName, metaDataProcedureName);
/*     */       
/* 310 */       if (procedureMetadata.hits() > 1) {
/*     */         
/* 312 */         String searchStringEscape = databaseMetaData.getSearchStringEscape();
/* 313 */         if (searchStringEscape != null) {
/* 314 */           procedureMetadata = getProcedureMetadata(databaseMetaData, metaDataCatalogName, 
/* 315 */               escapeNamePattern(metaDataSchemaName, searchStringEscape), 
/* 316 */               escapeNamePattern(metaDataProcedureName, searchStringEscape));
/*     */         }
/*     */       } 
/* 319 */       if (procedureMetadata.hits() == 0) {
/*     */         
/* 321 */         procedureMetadata = getProcedureMetadataAsFunction(databaseMetaData, metaDataCatalogName, metaDataSchemaName, metaDataProcedureName);
/*     */         
/* 323 */         if (procedureMetadata.hits() > 1) {
/*     */           
/* 325 */           String searchStringEscape = databaseMetaData.getSearchStringEscape();
/* 326 */           if (searchStringEscape != null) {
/* 327 */             procedureMetadata = getProcedureMetadataAsFunction(databaseMetaData, metaDataCatalogName, 
/*     */                 
/* 329 */                 escapeNamePattern(metaDataSchemaName, searchStringEscape), 
/* 330 */                 escapeNamePattern(metaDataProcedureName, searchStringEscape));
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 336 */       boolean isFunction = procedureMetadata.function();
/* 337 */       List<String> matches = procedureMetadata.matches;
/* 338 */       if (matches.size() > 1) {
/* 339 */         throw new InvalidDataAccessApiUsageException("Unable to determine the correct call signature - multiple signatures for '" + metaDataProcedureName + "': found " + String.valueOf(matches) + " " + (
/*     */             
/* 341 */             isFunction ? "functions" : "procedures"));
/*     */       }
/* 343 */       if (matches.isEmpty()) {
/* 344 */         if (metaDataProcedureName != null && metaDataProcedureName.contains(".") && 
/* 345 */           !StringUtils.hasText(metaDataCatalogName)) {
/* 346 */           String packageName = metaDataProcedureName.substring(0, metaDataProcedureName.indexOf('.'));
/* 347 */           throw new InvalidDataAccessApiUsageException("Unable to determine the correct call signature for '" + metaDataProcedureName + "' - package name should be specified separately using '.withCatalogName(\"" + packageName + "\")'");
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 352 */         if ("Oracle".equals(databaseMetaData.getDatabaseProductName())) {
/* 353 */           if (logger.isDebugEnabled()) {
/* 354 */             logger.debug("Oracle JDBC driver did not return procedure/function/signature for '" + metaDataProcedureName + "' - assuming a non-exposed synonym");
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 359 */           throw new InvalidDataAccessApiUsageException("Unable to determine the correct call signature - no procedure/function/signature for '" + metaDataProcedureName + "'");
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 365 */       if (logger.isDebugEnabled()) {
/* 366 */         logger.debug("Retrieving column meta-data for " + (isFunction ? "function" : "procedure") + " " + metaDataCatalogName + "/" + procedureMetadata.schemaName + "/" + procedureMetadata.procedureName);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 371 */       ResultSet columns = isFunction ? databaseMetaData.getFunctionColumns(metaDataCatalogName, procedureMetadata.schemaName, procedureMetadata.procedureName, null) : databaseMetaData.getProcedureColumns(metaDataCatalogName, procedureMetadata.schemaName, procedureMetadata.procedureName, null); 
/* 372 */       try { while (columns.next()) {
/* 373 */           String columnName = columns.getString("COLUMN_NAME");
/* 374 */           int columnType = columns.getInt("COLUMN_TYPE");
/* 375 */           if (columnName == null && isInOrOutColumn(columnType, isFunction)) {
/* 376 */             if (logger.isDebugEnabled()) {
/* 377 */               logger.debug("Skipping meta-data for: " + columnType + " " + columns.getInt("DATA_TYPE") + " " + columns
/* 378 */                   .getString("TYPE_NAME") + " " + columns.getInt("NULLABLE") + " (probably a member of a collection)");
/*     */             }
/*     */             
/*     */             continue;
/*     */           } 
/* 383 */           int nullable = isFunction ? 1 : 1;
/*     */ 
/*     */           
/* 386 */           CallParameterMetaData meta = new CallParameterMetaData(isFunction, columnName, columnType, columns.getInt("DATA_TYPE"), columns.getString("TYPE_NAME"), (columns.getInt("NULLABLE") == nullable));
/* 387 */           this.callParameterMetaData.add(meta);
/* 388 */           if (logger.isDebugEnabled()) {
/* 389 */             logger.debug("Retrieved meta-data: " + meta.getParameterName() + " " + meta
/* 390 */                 .getParameterType() + " " + meta.getSqlType() + " " + meta
/* 391 */                 .getTypeName() + " " + meta.isNullable());
/*     */           }
/*     */         } 
/*     */         
/* 395 */         if (columns != null) columns.close();  } catch (Throwable throwable) { if (columns != null)
/*     */           try { columns.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; } 
/* 397 */     } catch (SQLException ex) {
/* 398 */       if (logger.isWarnEnabled()) {
/* 399 */         logger.warn("Error while retrieving meta-data for procedure columns. Consider declaring explicit parameters -- for example, via SimpleJdbcCall#addDeclaredParameter().", ex);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ProcedureMetadata getProcedureMetadata(DatabaseMetaData databaseMetaData, @Nullable String catalogName, @Nullable String schemaName, @Nullable String procedureName) throws SQLException {
/* 413 */     if (logger.isDebugEnabled()) {
/* 414 */       logger.debug("Retrieving meta-data for " + catalogName + "/" + schemaName + "/" + procedureName);
/*     */     }
/* 416 */     List<String> matches = new ArrayList<>();
/* 417 */     ResultSet procedures = databaseMetaData.getProcedures(catalogName, schemaName, procedureName); 
/* 418 */     try { while (procedures.next()) {
/* 419 */         matches.add(procedures.getString("PROCEDURE_CAT") + "." + procedures.getString("PROCEDURE_CAT") + "." + procedures.getString("PROCEDURE_SCHEM"));
/*     */       }
/*     */       
/* 422 */       if (procedures != null) procedures.close();  } catch (Throwable throwable) { if (procedures != null)
/* 423 */         try { procedures.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return new ProcedureMetadata(schemaName, procedureName, matches, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private ProcedureMetadata getProcedureMetadataAsFunction(DatabaseMetaData databaseMetaData, @Nullable String catalogName, @Nullable String schemaName, @Nullable String procedureName) throws SQLException {
/* 428 */     if (logger.isDebugEnabled()) {
/* 429 */       logger.debug("Fallback on retrieving function meta-data for " + catalogName + "/" + schemaName + "/" + procedureName);
/*     */     }
/* 431 */     List<String> matches = new ArrayList<>();
/* 432 */     ResultSet functions = databaseMetaData.getFunctions(catalogName, schemaName, procedureName); 
/* 433 */     try { while (functions.next()) {
/* 434 */         matches.add(functions.getString("FUNCTION_CAT") + "." + functions.getString("FUNCTION_CAT") + "." + functions.getString("FUNCTION_SCHEM"));
/*     */       }
/*     */       
/* 437 */       if (functions != null) functions.close();  } catch (Throwable throwable) { if (functions != null)
/* 438 */         try { functions.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return new ProcedureMetadata(schemaName, procedureName, matches, true);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static String escapeNamePattern(@Nullable String name, @Nullable String escape) {
/* 443 */     if (name == null || escape == null) {
/* 444 */       return name;
/*     */     }
/* 446 */     return name.replace(escape, escape + escape)
/* 447 */       .replace("_", escape + "_")
/* 448 */       .replace("%", escape + "%");
/*     */   }
/*     */   
/*     */   private static boolean isInOrOutColumn(int columnType, boolean function) {
/* 452 */     if (function) {
/* 453 */       return (columnType == 1 || columnType == 2 || columnType == 3);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 458 */     return (columnType == 1 || columnType == 2 || columnType == 4);
/*     */   }
/*     */   private static final class ProcedureMetadata extends Record { @Nullable
/*     */     private final String schemaName; @Nullable
/*     */     private final String procedureName; private final List<String> matches; private final boolean function;
/*     */     
/* 464 */     private ProcedureMetadata(@Nullable String schemaName, @Nullable String procedureName, List<String> matches, boolean function) { this.schemaName = schemaName; this.procedureName = procedureName; this.matches = matches; this.function = function; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/jdbc/core/metadata/GenericCallMetaDataProvider$ProcedureMetadata;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #464	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 464 */       //   0	7	0	this	Lorg/springframework/jdbc/core/metadata/GenericCallMetaDataProvider$ProcedureMetadata; } @Nullable public String schemaName() { return this.schemaName; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/jdbc/core/metadata/GenericCallMetaDataProvider$ProcedureMetadata;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #464	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/jdbc/core/metadata/GenericCallMetaDataProvider$ProcedureMetadata; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/jdbc/core/metadata/GenericCallMetaDataProvider$ProcedureMetadata;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #464	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/jdbc/core/metadata/GenericCallMetaDataProvider$ProcedureMetadata;
/* 464 */       //   0	8	1	o	Ljava/lang/Object; } @Nullable public String procedureName() { return this.procedureName; } public List<String> matches() { return this.matches; } public boolean function() { return this.function; }
/*     */ 
/*     */     
/*     */     int hits() {
/* 468 */       return this.matches.size();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\GenericCallMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */