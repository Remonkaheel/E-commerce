/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SybaseCallMetaDataProvider
/*    */   extends GenericCallMetaDataProvider
/*    */ {
/*    */   private static final String REMOVABLE_COLUMN_PREFIX = "@";
/*    */   private static final String RETURN_VALUE_NAME = "RETURN_VALUE";
/*    */   
/*    */   public SybaseCallMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/* 40 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String parameterNameToUse(@Nullable String parameterName) {
/* 47 */     if (parameterName == null) {
/* 48 */       return null;
/*    */     }
/* 50 */     if (parameterName.length() > 1 && parameterName.startsWith("@")) {
/* 51 */       return super.parameterNameToUse(parameterName.substring(1));
/*    */     }
/*    */     
/* 54 */     return super.parameterNameToUse(parameterName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String namedParameterBindingToUse(@Nullable String parameterName) {
/* 60 */     return parameterName + " = ?";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean byPassReturnParameter(String parameterName) {
/* 65 */     return ("RETURN_VALUE".equals(parameterName) || "RETURN_VALUE"
/* 66 */       .equals(parameterNameToUse(parameterName)));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\SybaseCallMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */