/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableParameterMetaData
/*    */ {
/*    */   private final String parameterName;
/*    */   private final int sqlType;
/*    */   private final boolean nullable;
/*    */   
/*    */   public TableParameterMetaData(String columnName, int sqlType, boolean nullable) {
/* 39 */     this.parameterName = columnName;
/* 40 */     this.sqlType = sqlType;
/* 41 */     this.nullable = nullable;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getParameterName() {
/* 49 */     return this.parameterName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSqlType() {
/* 56 */     return this.sqlType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isNullable() {
/* 63 */     return this.nullable;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\TableParameterMetaData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */