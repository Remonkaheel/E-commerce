/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Locale;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DerbyCallMetaDataProvider
/*    */   extends GenericCallMetaDataProvider
/*    */ {
/*    */   public DerbyCallMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/* 36 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String metaDataSchemaNameToUse(@Nullable String schemaName) {
/* 43 */     if (schemaName != null) {
/* 44 */       return super.metaDataSchemaNameToUse(schemaName);
/*    */     }
/*    */ 
/*    */     
/* 48 */     String userName = getUserName();
/* 49 */     return (userName != null) ? userName.toUpperCase(Locale.ROOT) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\DerbyCallMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */