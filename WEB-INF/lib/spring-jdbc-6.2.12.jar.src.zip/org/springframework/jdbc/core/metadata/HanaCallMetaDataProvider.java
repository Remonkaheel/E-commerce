/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HanaCallMetaDataProvider
/*    */   extends GenericCallMetaDataProvider
/*    */ {
/*    */   public HanaCallMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/* 33 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void initializeWithMetaData(DatabaseMetaData databaseMetaData) throws SQLException {
/* 39 */     super.initializeWithMetaData(databaseMetaData);
/* 40 */     setStoresUpperCaseIdentifiers(false);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\HanaCallMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */