/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTableMetaDataProvider
/*     */   extends GenericTableMetaDataProvider
/*     */ {
/*     */   private final boolean includeSynonyms;
/*     */   @Nullable
/*     */   private final String defaultSchema;
/*     */   
/*     */   public OracleTableMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/*  55 */     this(databaseMetaData, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleTableMetaDataProvider(DatabaseMetaData databaseMetaData, boolean includeSynonyms) throws SQLException {
/*  66 */     super(databaseMetaData);
/*  67 */     this.includeSynonyms = includeSynonyms;
/*  68 */     this.defaultSchema = lookupDefaultSchema(databaseMetaData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static String lookupDefaultSchema(DatabaseMetaData databaseMetaData) {
/*     */     try {
/*  78 */       CallableStatement cstmt = null;
/*     */       try {
/*  80 */         Connection con = databaseMetaData.getConnection();
/*  81 */         if (con == null) {
/*  82 */           logger.debug("Cannot check default schema - no Connection from DatabaseMetaData");
/*  83 */           return null;
/*     */         } 
/*  85 */         cstmt = con.prepareCall("{? = call sys_context('USERENV', 'CURRENT_SCHEMA')}");
/*  86 */         cstmt.registerOutParameter(1, 12);
/*  87 */         cstmt.execute();
/*  88 */         return cstmt.getString(1);
/*     */       } finally {
/*     */         
/*  91 */         if (cstmt != null) {
/*  92 */           cstmt.close();
/*     */         }
/*     */       }
/*     */     
/*  96 */     } catch (SQLException ex) {
/*  97 */       logger.debug("Exception encountered during default schema lookup", ex);
/*  98 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getDefaultSchema() {
/* 105 */     if (this.defaultSchema != null) {
/* 106 */       return this.defaultSchema;
/*     */     }
/* 108 */     return super.getDefaultSchema();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeWithTableColumnMetaData(DatabaseMetaData databaseMetaData, @Nullable String catalogName, @Nullable String schemaName, @Nullable String tableName) throws SQLException {
/*     */     Method setIncludeSynonyms;
/*     */     Boolean originalValueForIncludeSynonyms;
/* 117 */     if (!this.includeSynonyms) {
/* 118 */       logger.debug("Defaulting to no synonyms in table meta-data lookup");
/* 119 */       super.initializeWithTableColumnMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*     */       
/*     */       return;
/*     */     } 
/* 123 */     Connection con = databaseMetaData.getConnection();
/* 124 */     if (con == null) {
/* 125 */       logger.info("Unable to include synonyms in table meta-data lookup - no Connection from DatabaseMetaData");
/* 126 */       super.initializeWithTableColumnMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 131 */       Class<?> oracleConClass = con.getClass().getClassLoader().loadClass("oracle.jdbc.OracleConnection");
/* 132 */       con = (Connection)con.unwrap(oracleConClass);
/*     */     }
/* 134 */     catch (ClassNotFoundException|SQLException ex) {
/* 135 */       if (logger.isInfoEnabled()) {
/* 136 */         logger.info("Unable to include synonyms in table meta-data lookup - no Oracle Connection: " + String.valueOf(ex));
/*     */       }
/* 138 */       super.initializeWithTableColumnMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*     */       
/*     */       return;
/*     */     } 
/* 142 */     logger.debug("Including synonyms in table meta-data lookup");
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 147 */       Method getIncludeSynonyms = con.getClass().getMethod("getIncludeSynonyms", new Class[0]);
/* 148 */       ReflectionUtils.makeAccessible(getIncludeSynonyms);
/* 149 */       originalValueForIncludeSynonyms = (Boolean)getIncludeSynonyms.invoke(con, new Object[0]);
/*     */       
/* 151 */       setIncludeSynonyms = con.getClass().getMethod("setIncludeSynonyms", new Class[] { boolean.class });
/* 152 */       ReflectionUtils.makeAccessible(setIncludeSynonyms);
/* 153 */       setIncludeSynonyms.invoke(con, new Object[] { Boolean.TRUE });
/*     */     }
/* 155 */     catch (Throwable ex) {
/* 156 */       throw new InvalidDataAccessApiUsageException("Could not prepare Oracle Connection", ex);
/*     */     } 
/*     */     
/* 159 */     super.initializeWithTableColumnMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*     */     
/*     */     try {
/* 162 */       setIncludeSynonyms.invoke(con, new Object[] { originalValueForIncludeSynonyms });
/*     */     }
/* 164 */     catch (Throwable ex) {
/* 165 */       throw new InvalidDataAccessApiUsageException("Could not reset Oracle Connection", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\OracleTableMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */