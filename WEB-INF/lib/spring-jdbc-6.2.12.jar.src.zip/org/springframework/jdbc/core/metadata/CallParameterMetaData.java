/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CallParameterMetaData
/*     */ {
/*     */   private final boolean function;
/*     */   @Nullable
/*     */   private final String parameterName;
/*     */   private final int parameterType;
/*     */   private final int sqlType;
/*     */   @Nullable
/*     */   private final String typeName;
/*     */   private final boolean nullable;
/*     */   
/*     */   public CallParameterMetaData(boolean function, @Nullable String columnName, int columnType, int sqlType, @Nullable String typeName, boolean nullable) {
/*  55 */     this.function = function;
/*  56 */     this.parameterName = columnName;
/*  57 */     this.parameterType = columnType;
/*  58 */     this.sqlType = sqlType;
/*  59 */     this.typeName = typeName;
/*  60 */     this.nullable = nullable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFunction() {
/*  69 */     return this.function;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getParameterName() {
/*  77 */     return this.parameterName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getParameterType() {
/*  84 */     return this.parameterType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReturnParameter() {
/*  95 */     return this.function ? ((this.parameterType == 4)) : (
/*  96 */       (this.parameterType == 5 || this.parameterType == 3));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOutParameter() {
/* 107 */     return this.function ? ((this.parameterType == 3)) : (
/* 108 */       (this.parameterType == 4));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInOutParameter() {
/* 118 */     return this.function ? ((this.parameterType == 2)) : (
/* 119 */       (this.parameterType == 2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSqlType() {
/* 126 */     return this.sqlType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getTypeName() {
/* 134 */     return this.typeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNullable() {
/* 141 */     return this.nullable;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\CallParameterMetaData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */