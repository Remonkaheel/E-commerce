/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.ColumnMapRowMapper;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ import org.springframework.jdbc.core.SqlOutParameter;
/*    */ import org.springframework.jdbc.core.SqlParameter;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostgresCallMetaDataProvider
/*    */   extends GenericCallMetaDataProvider
/*    */ {
/*    */   private static final String RETURN_VALUE_NAME = "returnValue";
/*    */   private final String schemaName;
/*    */   
/*    */   public PostgresCallMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/* 44 */     super(databaseMetaData);
/*    */ 
/*    */     
/* 47 */     String schema = databaseMetaData.getConnection().getSchema();
/* 48 */     this.schemaName = (schema != null) ? schema : "public";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isReturnResultSetSupported() {
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRefCursorSupported() {
/* 59 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRefCursorSqlType() {
/* 64 */     return 1111;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String metaDataSchemaNameToUse(@Nullable String schemaName) {
/* 70 */     return (schemaName == null) ? this.schemaName : super.metaDataSchemaNameToUse(schemaName);
/*    */   }
/*    */ 
/*    */   
/*    */   public SqlParameter createDefaultOutParameter(String parameterName, CallParameterMetaData meta) {
/* 75 */     if (meta.getSqlType() == 1111 && "refcursor".equals(meta.getTypeName())) {
/* 76 */       return (SqlParameter)new SqlOutParameter(parameterName, getRefCursorSqlType(), (RowMapper)new ColumnMapRowMapper());
/*    */     }
/*    */     
/* 79 */     return super.createDefaultOutParameter(parameterName, meta);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean byPassReturnParameter(String parameterName) {
/* 85 */     return "returnValue".equals(parameterName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\PostgresCallMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */