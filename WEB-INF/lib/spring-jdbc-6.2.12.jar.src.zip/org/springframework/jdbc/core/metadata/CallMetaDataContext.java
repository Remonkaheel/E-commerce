/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.SqlOutParameter;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ import org.springframework.jdbc.core.SqlReturnResultSet;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CallMetaDataContext
/*     */ {
/*  58 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String procedureName;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String catalogName;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String schemaName;
/*     */ 
/*     */   
/*  73 */   private List<SqlParameter> callParameters = new ArrayList<>();
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String actualFunctionReturnName;
/*     */ 
/*     */   
/*  80 */   private Set<String> limitedInParameterNames = new HashSet<>();
/*     */ 
/*     */   
/*  83 */   private List<String> outParameterNames = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean function = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean returnValueRequired = false;
/*     */ 
/*     */   
/*     */   private boolean accessCallParameterMetaData = true;
/*     */ 
/*     */   
/*     */   private boolean namedBinding;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private CallMetaDataProvider metaDataProvider;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFunctionReturnName(String functionReturnName) {
/* 106 */     this.actualFunctionReturnName = functionReturnName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFunctionReturnName() {
/* 113 */     return (this.actualFunctionReturnName != null) ? this.actualFunctionReturnName : "return";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLimitedInParameterNames(Set<String> limitedInParameterNames) {
/* 120 */     this.limitedInParameterNames = limitedInParameterNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getLimitedInParameterNames() {
/* 127 */     return this.limitedInParameterNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutParameterNames(List<String> outParameterNames) {
/* 134 */     this.outParameterNames = outParameterNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getOutParameterNames() {
/* 141 */     return this.outParameterNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProcedureName(@Nullable String procedureName) {
/* 148 */     this.procedureName = procedureName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getProcedureName() {
/* 156 */     return this.procedureName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalogName(@Nullable String catalogName) {
/* 163 */     this.catalogName = catalogName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getCatalogName() {
/* 171 */     return this.catalogName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchemaName(@Nullable String schemaName) {
/* 178 */     this.schemaName = schemaName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSchemaName() {
/* 186 */     return this.schemaName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFunction(boolean function) {
/* 193 */     this.function = function;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFunction() {
/* 200 */     return this.function;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReturnValueRequired(boolean returnValueRequired) {
/* 207 */     this.returnValueRequired = returnValueRequired;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReturnValueRequired() {
/* 214 */     return this.returnValueRequired;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccessCallParameterMetaData(boolean accessCallParameterMetaData) {
/* 221 */     this.accessCallParameterMetaData = accessCallParameterMetaData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAccessCallParameterMetaData() {
/* 228 */     return this.accessCallParameterMetaData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamedBinding(boolean namedBinding) {
/* 236 */     this.namedBinding = namedBinding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNamedBinding() {
/* 244 */     return this.namedBinding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeMetaData(DataSource dataSource) {
/* 253 */     this.metaDataProvider = CallMetaDataProviderFactory.createMetaDataProvider(dataSource, this);
/*     */   }
/*     */   
/*     */   private CallMetaDataProvider obtainMetaDataProvider() {
/* 257 */     Assert.state((this.metaDataProvider != null), "No CallMetaDataProvider - call initializeMetaData first");
/* 258 */     return this.metaDataProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlParameter createReturnResultSetParameter(String parameterName, RowMapper<?> rowMapper) {
/* 269 */     CallMetaDataProvider provider = obtainMetaDataProvider();
/* 270 */     if (provider.isReturnResultSetSupported()) {
/* 271 */       return (SqlParameter)new SqlReturnResultSet(parameterName, rowMapper);
/*     */     }
/*     */     
/* 274 */     if (provider.isRefCursorSupported()) {
/* 275 */       return (SqlParameter)new SqlOutParameter(parameterName, provider.getRefCursorSqlType(), rowMapper);
/*     */     }
/*     */     
/* 278 */     throw new InvalidDataAccessApiUsageException("Return of a ResultSet from a stored procedure is not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getScalarOutParameterName() {
/* 290 */     if (isFunction()) {
/* 291 */       return getFunctionReturnName();
/*     */     }
/*     */     
/* 294 */     if (this.outParameterNames.size() > 1) {
/* 295 */       this.logger.info("Accessing single output value when procedure has more than one output parameter");
/*     */     }
/* 297 */     return !this.outParameterNames.isEmpty() ? this.outParameterNames.get(0) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<SqlParameter> getCallParameters() {
/* 305 */     return this.callParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processParameters(List<SqlParameter> parameters) {
/* 315 */     this.callParameters = reconcileParameters(parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<SqlParameter> reconcileParameters(List<SqlParameter> parameters) {
/* 322 */     CallMetaDataProvider provider = obtainMetaDataProvider();
/*     */     
/* 324 */     List<SqlParameter> declaredReturnParams = new ArrayList<>();
/* 325 */     Map<String, SqlParameter> declaredParams = new LinkedHashMap<>();
/* 326 */     boolean returnDeclared = false;
/* 327 */     List<String> outParamNames = new ArrayList<>();
/* 328 */     List<String> metaDataParamNames = new ArrayList<>();
/*     */ 
/*     */     
/* 331 */     for (CallParameterMetaData meta : provider.getCallParameterMetaData()) {
/* 332 */       if (!meta.isReturnParameter()) {
/* 333 */         metaDataParamNames.add(lowerCase(meta.getParameterName()));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 338 */     for (SqlParameter param : parameters) {
/* 339 */       if (param.isResultsParameter()) {
/* 340 */         declaredReturnParams.add(param);
/*     */         continue;
/*     */       } 
/* 343 */       String paramName = param.getName();
/* 344 */       if (paramName == null) {
/* 345 */         throw new IllegalArgumentException("Anonymous parameters not supported for calls - please specify a name for the parameter of SQL type " + param
/* 346 */             .getSqlType());
/*     */       }
/* 348 */       String paramNameToMatch = lowerCase(provider.parameterNameToUse(paramName));
/* 349 */       declaredParams.put(paramNameToMatch, param);
/* 350 */       if (param instanceof SqlOutParameter) {
/* 351 */         outParamNames.add(paramName);
/* 352 */         if (isFunction() && !metaDataParamNames.contains(paramNameToMatch) && !returnDeclared) {
/* 353 */           if (this.logger.isDebugEnabled()) {
/* 354 */             this.logger.debug("Using declared out parameter '" + paramName + "' for function return value");
/*     */           }
/*     */           
/* 357 */           this.actualFunctionReturnName = paramName;
/* 358 */           returnDeclared = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 363 */     setOutParameterNames(outParamNames);
/*     */     
/* 365 */     List<SqlParameter> workParams = new ArrayList<>(declaredReturnParams);
/* 366 */     if (!provider.isProcedureColumnMetaDataUsed()) {
/* 367 */       workParams.addAll(declaredParams.values());
/* 368 */       return workParams;
/*     */     } 
/*     */     
/* 371 */     Map<String, String> limitedInParamNamesMap = CollectionUtils.newHashMap(this.limitedInParameterNames.size());
/* 372 */     for (String limitedParamName : this.limitedInParameterNames) {
/* 373 */       limitedInParamNamesMap.put(lowerCase(provider.parameterNameToUse(limitedParamName)), limitedParamName);
/*     */     }
/*     */     
/* 376 */     for (CallParameterMetaData meta : provider.getCallParameterMetaData()) {
/* 377 */       String paramName = meta.getParameterName();
/* 378 */       String paramNameToCheck = null;
/* 379 */       if (paramName != null) {
/* 380 */         paramNameToCheck = lowerCase(provider.parameterNameToUse(paramName));
/*     */       }
/* 382 */       String paramNameToUse = provider.parameterNameToUse(paramName);
/* 383 */       if (declaredParams.containsKey(paramNameToCheck) || (meta.isReturnParameter() && returnDeclared)) {
/*     */         SqlParameter param;
/* 385 */         if (meta.isReturnParameter()) {
/* 386 */           param = declaredParams.get(getFunctionReturnName());
/* 387 */           if (param == null && !getOutParameterNames().isEmpty()) {
/* 388 */             param = declaredParams.get(((String)getOutParameterNames().get(0)).toLowerCase(Locale.ROOT));
/*     */           }
/* 390 */           if (param == null) {
/* 391 */             throw new InvalidDataAccessApiUsageException("Unable to locate declared parameter for function return value -  add an SqlOutParameter with name '" + 
/*     */                 
/* 393 */                 getFunctionReturnName() + "'");
/*     */           }
/*     */           
/* 396 */           this.actualFunctionReturnName = param.getName();
/*     */         }
/*     */         else {
/*     */           
/* 400 */           param = declaredParams.get(paramNameToCheck);
/*     */         } 
/* 402 */         if (param != null) {
/* 403 */           workParams.add(param);
/* 404 */           if (this.logger.isDebugEnabled()) {
/* 405 */             this.logger.debug("Using declared parameter for '" + (
/* 406 */                 (paramNameToUse != null) ? paramNameToUse : getFunctionReturnName()) + "'");
/*     */           }
/*     */         } 
/*     */         continue;
/*     */       } 
/* 411 */       if (meta.isReturnParameter()) {
/*     */         
/* 413 */         if (!isFunction() && !isReturnValueRequired() && paramName != null && provider
/* 414 */           .byPassReturnParameter(paramName)) {
/* 415 */           if (this.logger.isDebugEnabled()) {
/* 416 */             this.logger.debug("Bypassing meta-data return parameter for '" + paramName + "'");
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/* 421 */         String returnNameToUse = StringUtils.hasLength(paramNameToUse) ? paramNameToUse : getFunctionReturnName();
/* 422 */         workParams.add(provider.createDefaultOutParameter(returnNameToUse, meta));
/* 423 */         if (isFunction()) {
/* 424 */           this.actualFunctionReturnName = returnNameToUse;
/* 425 */           outParamNames.add(returnNameToUse);
/*     */         } 
/* 427 */         if (this.logger.isDebugEnabled()) {
/* 428 */           this.logger.debug("Added meta-data return parameter for '" + returnNameToUse + "'");
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 433 */       if (paramNameToUse == null) {
/* 434 */         paramNameToUse = "";
/*     */       }
/* 436 */       if (meta.isOutParameter()) {
/* 437 */         workParams.add(provider.createDefaultOutParameter(paramNameToUse, meta));
/* 438 */         outParamNames.add(paramNameToUse);
/* 439 */         if (this.logger.isDebugEnabled())
/* 440 */           this.logger.debug("Added meta-data out parameter for '" + paramNameToUse + "'"); 
/*     */         continue;
/*     */       } 
/* 443 */       if (meta.isInOutParameter()) {
/* 444 */         workParams.add(provider.createDefaultInOutParameter(paramNameToUse, meta));
/* 445 */         outParamNames.add(paramNameToUse);
/* 446 */         if (this.logger.isDebugEnabled()) {
/* 447 */           this.logger.debug("Added meta-data in-out parameter for '" + paramNameToUse + "'");
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 452 */       if (this.limitedInParameterNames.isEmpty() || limitedInParamNamesMap
/* 453 */         .containsKey(lowerCase(paramNameToUse))) {
/* 454 */         workParams.add(provider.createDefaultInParameter(paramNameToUse, meta));
/* 455 */         if (this.logger.isDebugEnabled()) {
/* 456 */           this.logger.debug("Added meta-data in parameter for '" + paramNameToUse + "'");
/*     */         }
/*     */         continue;
/*     */       } 
/* 460 */       if (this.logger.isDebugEnabled()) {
/* 461 */         this.logger.debug("Limited set of parameters " + String.valueOf(limitedInParamNamesMap.keySet()) + " skipped parameter for '" + paramNameToUse + "'");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 470 */     return workParams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> matchInParameterValuesWithCallParameters(SqlParameterSource parameterSource) {
/* 482 */     Map<String, String> caseInsensitiveParameterNames = SqlParameterSourceUtils.extractCaseInsensitiveParameterNames(parameterSource);
/*     */     
/* 484 */     Map<String, String> callParameterNames = CollectionUtils.newHashMap(this.callParameters.size());
/* 485 */     Map<String, Object> matchedParameters = CollectionUtils.newHashMap(this.callParameters.size());
/* 486 */     for (SqlParameter parameter : this.callParameters) {
/* 487 */       if (parameter.isInputValueProvided()) {
/* 488 */         String parameterName = parameter.getName();
/* 489 */         String parameterNameToMatch = obtainMetaDataProvider().parameterNameToUse(parameterName);
/* 490 */         if (parameterNameToMatch != null) {
/* 491 */           callParameterNames.put(parameterNameToMatch.toLowerCase(Locale.ROOT), parameterName);
/*     */         }
/* 493 */         if (parameterName != null) {
/* 494 */           if (parameterSource.hasValue(parameterName)) {
/* 495 */             matchedParameters.put(parameterName, 
/* 496 */                 SqlParameterSourceUtils.getTypedValue(parameterSource, parameterName));
/*     */             continue;
/*     */           } 
/* 499 */           String lowerCaseName = parameterName.toLowerCase(Locale.ROOT);
/* 500 */           if (parameterSource.hasValue(lowerCaseName)) {
/* 501 */             matchedParameters.put(parameterName, 
/* 502 */                 SqlParameterSourceUtils.getTypedValue(parameterSource, lowerCaseName));
/*     */             continue;
/*     */           } 
/* 505 */           String englishLowerCaseName = parameterName.toLowerCase(Locale.ENGLISH);
/* 506 */           if (parameterSource.hasValue(englishLowerCaseName)) {
/* 507 */             matchedParameters.put(parameterName, 
/* 508 */                 SqlParameterSourceUtils.getTypedValue(parameterSource, englishLowerCaseName));
/*     */             continue;
/*     */           } 
/* 511 */           String propertyName = JdbcUtils.convertUnderscoreNameToPropertyName(parameterName);
/* 512 */           if (parameterSource.hasValue(propertyName)) {
/* 513 */             matchedParameters.put(parameterName, 
/* 514 */                 SqlParameterSourceUtils.getTypedValue(parameterSource, propertyName));
/*     */             continue;
/*     */           } 
/* 517 */           if (caseInsensitiveParameterNames.containsKey(lowerCaseName)) {
/* 518 */             String sourceName = caseInsensitiveParameterNames.get(lowerCaseName);
/* 519 */             matchedParameters.put(parameterName, 
/* 520 */                 SqlParameterSourceUtils.getTypedValue(parameterSource, sourceName)); continue;
/*     */           } 
/* 522 */           if (this.logger.isInfoEnabled()) {
/* 523 */             this.logger.info("Unable to locate the corresponding parameter value for '" + parameterName + "' within the parameter values provided: " + 
/*     */                 
/* 525 */                 String.valueOf(caseInsensitiveParameterNames.values()));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 535 */     if (this.logger.isDebugEnabled()) {
/* 536 */       this.logger.debug("Matching " + String.valueOf(caseInsensitiveParameterNames.values()) + " with " + String.valueOf(callParameterNames.values()));
/* 537 */       this.logger.debug("Found match for " + String.valueOf(matchedParameters.keySet()));
/*     */     } 
/* 539 */     return matchedParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ?> matchInParameterValuesWithCallParameters(Map<String, ?> inParameters) {
/* 548 */     CallMetaDataProvider provider = obtainMetaDataProvider();
/* 549 */     if (!provider.isProcedureColumnMetaDataUsed()) {
/* 550 */       return inParameters;
/*     */     }
/*     */     
/* 553 */     Map<String, String> callParameterNames = CollectionUtils.newHashMap(this.callParameters.size());
/* 554 */     for (SqlParameter parameter : this.callParameters) {
/* 555 */       if (parameter.isInputValueProvided()) {
/* 556 */         String parameterName = parameter.getName();
/* 557 */         String parameterNameToMatch = provider.parameterNameToUse(parameterName);
/* 558 */         if (parameterNameToMatch != null) {
/* 559 */           callParameterNames.put(parameterNameToMatch.toLowerCase(Locale.ROOT), parameterName);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 564 */     Map<String, Object> matchedParameters = CollectionUtils.newHashMap(inParameters.size());
/* 565 */     inParameters.forEach((parameterName, parameterValue) -> {
/*     */           String parameterNameToMatch = provider.parameterNameToUse(parameterName);
/*     */           
/*     */           String callParameterName = (String)callParameterNames.get(lowerCase(parameterNameToMatch));
/*     */           
/*     */           if (callParameterName == null) {
/*     */             if (this.logger.isDebugEnabled()) {
/*     */               Object value = parameterValue;
/*     */               if (value instanceof SqlParameterValue) {
/*     */                 SqlParameterValue sqlParameterValue = (SqlParameterValue)value;
/*     */                 value = sqlParameterValue.getValue();
/*     */               } 
/*     */               if (value != null) {
/*     */                 this.logger.debug("Unable to locate the corresponding IN or IN-OUT parameter for \"" + parameterName + "\" in the parameters used: " + String.valueOf(callParameterNames.keySet()));
/*     */               }
/*     */             } 
/*     */           } else {
/*     */             matchedParameters.put(callParameterName, parameterValue);
/*     */           } 
/*     */         });
/* 585 */     if (matchedParameters.size() < callParameterNames.size()) {
/* 586 */       for (String parameterName : callParameterNames.keySet()) {
/* 587 */         String parameterNameToMatch = provider.parameterNameToUse(parameterName);
/* 588 */         String callParameterName = callParameterNames.get(lowerCase(parameterNameToMatch));
/* 589 */         if (!matchedParameters.containsKey(callParameterName) && this.logger.isInfoEnabled()) {
/* 590 */           this.logger.info("Unable to locate the corresponding parameter value for '" + parameterName + "' within the parameter values provided: " + 
/* 591 */               String.valueOf(inParameters.keySet()));
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 596 */     if (this.logger.isDebugEnabled()) {
/* 597 */       this.logger.debug("Matching " + String.valueOf(inParameters.keySet()) + " with " + String.valueOf(callParameterNames.values()));
/* 598 */       this.logger.debug("Found match for " + String.valueOf(matchedParameters.keySet()));
/*     */     } 
/* 600 */     return matchedParameters;
/*     */   }
/*     */   
/*     */   public Map<String, ?> matchInParameterValuesWithCallParameters(Object[] parameterValues) {
/* 604 */     Map<String, Object> matchedParameters = CollectionUtils.newHashMap(parameterValues.length);
/* 605 */     int i = 0;
/* 606 */     for (SqlParameter parameter : this.callParameters) {
/* 607 */       if (parameter.isInputValueProvided()) {
/* 608 */         String parameterName = parameter.getName();
/* 609 */         matchedParameters.put(parameterName, parameterValues[i++]);
/*     */       } 
/*     */     } 
/* 612 */     return matchedParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String createCallString() {
/*     */     StringBuilder callString;
/*     */     String catalogNameToUse, schemaNameToUse;
/* 620 */     Assert.state((this.metaDataProvider != null), "No CallMetaDataProvider available");
/*     */ 
/*     */     
/* 623 */     int parameterCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 629 */     if (this.metaDataProvider.isSupportsSchemasInProcedureCalls() && 
/* 630 */       !this.metaDataProvider.isSupportsCatalogsInProcedureCalls()) {
/* 631 */       schemaNameToUse = this.metaDataProvider.catalogNameToUse(getCatalogName());
/* 632 */       catalogNameToUse = this.metaDataProvider.schemaNameToUse(getSchemaName());
/*     */     } else {
/*     */       
/* 635 */       catalogNameToUse = this.metaDataProvider.catalogNameToUse(getCatalogName());
/* 636 */       schemaNameToUse = this.metaDataProvider.schemaNameToUse(getSchemaName());
/*     */     } 
/*     */     
/* 639 */     if (isFunction() || isReturnValueRequired()) {
/* 640 */       callString = new StringBuilder("{? = call ");
/* 641 */       parameterCount = -1;
/*     */     } else {
/*     */       
/* 644 */       callString = new StringBuilder("{call ");
/*     */     } 
/*     */     
/* 647 */     if (StringUtils.hasLength(catalogNameToUse)) {
/* 648 */       callString.append(catalogNameToUse).append('.');
/*     */     }
/* 650 */     if (StringUtils.hasLength(schemaNameToUse)) {
/* 651 */       callString.append(schemaNameToUse).append('.');
/*     */     }
/* 653 */     callString.append(this.metaDataProvider.procedureNameToUse(getProcedureName()));
/* 654 */     callString.append('(');
/*     */     
/* 656 */     for (SqlParameter parameter : this.callParameters) {
/* 657 */       if (!parameter.isResultsParameter()) {
/* 658 */         if (parameterCount > 0) {
/* 659 */           callString.append(", ");
/*     */         }
/* 661 */         if (parameterCount >= 0) {
/* 662 */           callString.append(createParameterBinding(parameter));
/*     */         }
/* 664 */         parameterCount++;
/*     */       } 
/*     */     } 
/* 667 */     callString.append(")}");
/*     */     
/* 669 */     return callString.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String createParameterBinding(SqlParameter parameter) {
/* 679 */     Assert.state((this.metaDataProvider != null), "No CallMetaDataProvider available");
/* 680 */     return isNamedBinding() ? this.metaDataProvider.namedParameterBindingToUse(parameter.getName()) : "?";
/*     */   }
/*     */   
/*     */   private static String lowerCase(@Nullable String paramName) {
/* 684 */     return (paramName != null) ? paramName.toLowerCase(Locale.ROOT) : "";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\CallMetaDataContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */