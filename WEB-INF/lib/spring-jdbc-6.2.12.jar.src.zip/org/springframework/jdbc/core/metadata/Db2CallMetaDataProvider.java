/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Locale;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Db2CallMetaDataProvider
/*    */   extends GenericCallMetaDataProvider
/*    */ {
/*    */   public Db2CallMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/* 36 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void initializeWithMetaData(DatabaseMetaData databaseMetaData) throws SQLException {
/*    */     try {
/* 43 */       setSupportsCatalogsInProcedureCalls(databaseMetaData.supportsCatalogsInProcedureCalls());
/*    */     }
/* 45 */     catch (SQLException ex) {
/* 46 */       logger.debug("Error retrieving 'DatabaseMetaData.supportsCatalogsInProcedureCalls' - " + ex.getMessage());
/*    */     } 
/*    */     try {
/* 49 */       setSupportsSchemasInProcedureCalls(databaseMetaData.supportsSchemasInProcedureCalls());
/*    */     }
/* 51 */     catch (SQLException ex) {
/* 52 */       logger.debug("Error retrieving 'DatabaseMetaData.supportsSchemasInProcedureCalls' - " + ex.getMessage());
/*    */     } 
/*    */     try {
/* 55 */       setStoresUpperCaseIdentifiers(databaseMetaData.storesUpperCaseIdentifiers());
/*    */     }
/* 57 */     catch (SQLException ex) {
/* 58 */       logger.debug("Error retrieving 'DatabaseMetaData.storesUpperCaseIdentifiers' - " + ex.getMessage());
/*    */     } 
/*    */     try {
/* 61 */       setStoresLowerCaseIdentifiers(databaseMetaData.storesLowerCaseIdentifiers());
/*    */     }
/* 63 */     catch (SQLException ex) {
/* 64 */       logger.debug("Error retrieving 'DatabaseMetaData.storesLowerCaseIdentifiers' - " + ex.getMessage());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String metaDataSchemaNameToUse(@Nullable String schemaName) {
/* 71 */     if (schemaName != null) {
/* 72 */       return super.metaDataSchemaNameToUse(schemaName);
/*    */     }
/*    */ 
/*    */     
/* 76 */     String userName = getUserName();
/* 77 */     return (userName != null) ? userName.toUpperCase(Locale.ROOT) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\Db2CallMetaDataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */