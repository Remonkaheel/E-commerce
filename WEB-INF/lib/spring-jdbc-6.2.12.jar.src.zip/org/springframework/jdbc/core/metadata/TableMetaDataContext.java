/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableMetaDataContext
/*     */ {
/*  53 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String tableName;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String catalogName;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String schemaName;
/*     */ 
/*     */   
/*     */   private boolean accessTableColumnMetaData = true;
/*     */ 
/*     */   
/*     */   private boolean overrideIncludeSynonymsDefault = false;
/*     */ 
/*     */   
/*     */   private boolean quoteIdentifiers = false;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TableMetaDataProvider metaDataProvider;
/*     */ 
/*     */   
/*  81 */   private List<String> tableColumns = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean generatedKeyColumnsUsed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTableName(@Nullable String tableName) {
/*  91 */     this.tableName = tableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getTableName() {
/*  99 */     return this.tableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalogName(@Nullable String catalogName) {
/* 106 */     this.catalogName = catalogName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getCatalogName() {
/* 114 */     return this.catalogName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchemaName(@Nullable String schemaName) {
/* 121 */     this.schemaName = schemaName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSchemaName() {
/* 129 */     return this.schemaName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccessTableColumnMetaData(boolean accessTableColumnMetaData) {
/* 136 */     this.accessTableColumnMetaData = accessTableColumnMetaData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAccessTableColumnMetaData() {
/* 143 */     return this.accessTableColumnMetaData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOverrideIncludeSynonymsDefault(boolean override) {
/* 150 */     this.overrideIncludeSynonymsDefault = override;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOverrideIncludeSynonymsDefault() {
/* 157 */     return this.overrideIncludeSynonymsDefault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQuoteIdentifiers(boolean quoteIdentifiers) {
/* 170 */     this.quoteIdentifiers = quoteIdentifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isQuoteIdentifiers() {
/* 179 */     return this.quoteIdentifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getTableColumns() {
/* 186 */     return this.tableColumns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processMetaData(DataSource dataSource, List<String> declaredColumns, String[] generatedKeyNames) {
/* 197 */     this.metaDataProvider = TableMetaDataProviderFactory.createMetaDataProvider(dataSource, this);
/* 198 */     this.tableColumns = reconcileColumnsToUse(declaredColumns, generatedKeyNames);
/*     */   }
/*     */   
/*     */   private TableMetaDataProvider obtainMetaDataProvider() {
/* 202 */     Assert.state((this.metaDataProvider != null), "No TableMetaDataProvider - call processMetaData first");
/* 203 */     return this.metaDataProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> reconcileColumnsToUse(List<String> declaredColumns, String[] generatedKeyNames) {
/* 212 */     if (generatedKeyNames.length > 0) {
/* 213 */       this.generatedKeyColumnsUsed = true;
/*     */     }
/* 215 */     if (!declaredColumns.isEmpty()) {
/* 216 */       return new ArrayList<>(declaredColumns);
/*     */     }
/* 218 */     Set<String> keys = CollectionUtils.newLinkedHashSet(generatedKeyNames.length);
/* 219 */     for (String key : generatedKeyNames) {
/* 220 */       keys.add(key.toUpperCase(Locale.ROOT));
/*     */     }
/* 222 */     List<String> columns = new ArrayList<>();
/* 223 */     for (TableParameterMetaData meta : obtainMetaDataProvider().getTableParameterMetaData()) {
/* 224 */       if (!keys.contains(meta.getParameterName().toUpperCase(Locale.ROOT))) {
/* 225 */         columns.add(meta.getParameterName());
/*     */       }
/*     */     } 
/* 228 */     return columns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object> matchInParameterValuesWithInsertColumns(SqlParameterSource parameterSource) {
/* 236 */     List<Object> values = new ArrayList();
/*     */ 
/*     */ 
/*     */     
/* 240 */     Map<String, String> caseInsensitiveParameterNames = SqlParameterSourceUtils.extractCaseInsensitiveParameterNames(parameterSource);
/* 241 */     for (String column : this.tableColumns) {
/* 242 */       if (parameterSource.hasValue(column)) {
/* 243 */         values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, column));
/*     */         continue;
/*     */       } 
/* 246 */       String lowerCaseName = column.toLowerCase(Locale.ROOT);
/* 247 */       if (parameterSource.hasValue(lowerCaseName)) {
/* 248 */         values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, lowerCaseName));
/*     */         continue;
/*     */       } 
/* 251 */       String propertyName = JdbcUtils.convertUnderscoreNameToPropertyName(column);
/* 252 */       if (parameterSource.hasValue(propertyName)) {
/* 253 */         values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, propertyName));
/*     */         continue;
/*     */       } 
/* 256 */       if (caseInsensitiveParameterNames.containsKey(lowerCaseName)) {
/* 257 */         values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, caseInsensitiveParameterNames
/* 258 */               .get(lowerCaseName)));
/*     */         continue;
/*     */       } 
/* 261 */       values.add(null);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 267 */     return values;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object> matchInParameterValuesWithInsertColumns(Map<String, ?> inParameters) {
/* 275 */     List<Object> values = new ArrayList(inParameters.size());
/* 276 */     for (String column : this.tableColumns) {
/* 277 */       Object value = inParameters.get(column);
/* 278 */       if (value == null) {
/* 279 */         value = inParameters.get(column.toLowerCase(Locale.ROOT));
/* 280 */         if (value == null) {
/* 281 */           for (Map.Entry<String, ?> entry : inParameters.entrySet()) {
/* 282 */             if (column.equalsIgnoreCase(entry.getKey())) {
/* 283 */               value = entry.getValue();
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/* 289 */       values.add(value);
/*     */     } 
/* 291 */     return values;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createInsertString(String... generatedKeyNames) {
/* 299 */     Set<String> keys = CollectionUtils.newLinkedHashSet(generatedKeyNames.length);
/* 300 */     for (String key : generatedKeyNames) {
/* 301 */       keys.add(key.toUpperCase(Locale.ROOT));
/*     */     }
/*     */ 
/*     */     
/* 305 */     String identifierQuoteString = isQuoteIdentifiers() ? obtainMetaDataProvider().getIdentifierQuoteString() : null;
/* 306 */     QuoteHandler quoteHandler = new QuoteHandler(identifierQuoteString);
/*     */     
/* 308 */     StringBuilder insertStatement = new StringBuilder();
/* 309 */     insertStatement.append("INSERT INTO ");
/*     */     
/* 311 */     String catalogName = getCatalogName();
/* 312 */     if (catalogName != null) {
/* 313 */       quoteHandler.appendTo(insertStatement, catalogName);
/* 314 */       insertStatement.append('.');
/*     */     } 
/*     */     
/* 317 */     String schemaName = getSchemaName();
/* 318 */     if (schemaName != null) {
/* 319 */       quoteHandler.appendTo(insertStatement, schemaName);
/* 320 */       insertStatement.append('.');
/*     */     } 
/*     */     
/* 323 */     String tableName = getTableName();
/* 324 */     quoteHandler.appendTo(insertStatement, tableName);
/*     */     
/* 326 */     insertStatement.append(" (");
/* 327 */     int columnCount = 0;
/* 328 */     for (String columnName : getTableColumns()) {
/* 329 */       if (!keys.contains(columnName.toUpperCase(Locale.ROOT))) {
/* 330 */         columnCount++;
/* 331 */         if (columnCount > 1) {
/* 332 */           insertStatement.append(", ");
/*     */         }
/* 334 */         quoteHandler.appendTo(insertStatement, columnName);
/*     */       } 
/*     */     } 
/* 337 */     insertStatement.append(") VALUES(");
/* 338 */     if (columnCount < 1) {
/* 339 */       if (this.generatedKeyColumnsUsed) {
/* 340 */         if (this.logger.isDebugEnabled()) {
/* 341 */           this.logger.debug("Unable to locate non-key columns for table '" + tableName + "' so an empty insert statement is generated");
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 346 */         String message = "Unable to locate columns for table '" + tableName + "' so an insert statement can't be generated.";
/*     */         
/* 348 */         if (isAccessTableColumnMetaData()) {
/* 349 */           message = message + " Consider specifying explicit column names -- for example, via SimpleJdbcInsert#usingColumns().";
/*     */         }
/* 351 */         throw new InvalidDataAccessApiUsageException(message);
/*     */       } 
/*     */     }
/* 354 */     String params = String.join(", ", Collections.nCopies(columnCount, "?"));
/* 355 */     insertStatement.append(params);
/* 356 */     insertStatement.append(')');
/* 357 */     return insertStatement.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] createInsertTypes() {
/* 365 */     int[] types = new int[getTableColumns().size()];
/* 366 */     List<TableParameterMetaData> parameters = obtainMetaDataProvider().getTableParameterMetaData();
/* 367 */     Map<String, TableParameterMetaData> parameterMap = CollectionUtils.newLinkedHashMap(parameters.size());
/* 368 */     for (TableParameterMetaData tpmd : parameters) {
/* 369 */       parameterMap.put(tpmd.getParameterName().toUpperCase(Locale.ROOT), tpmd);
/*     */     }
/* 371 */     int typeIndx = 0;
/* 372 */     for (String column : getTableColumns()) {
/* 373 */       if (column == null) {
/* 374 */         types[typeIndx] = Integer.MIN_VALUE;
/*     */       } else {
/*     */         
/* 377 */         TableParameterMetaData tpmd = parameterMap.get(column.toUpperCase(Locale.ROOT));
/* 378 */         if (tpmd != null) {
/* 379 */           types[typeIndx] = tpmd.getSqlType();
/*     */         } else {
/*     */           
/* 382 */           types[typeIndx] = Integer.MIN_VALUE;
/*     */         } 
/*     */       } 
/* 385 */       typeIndx++;
/*     */     } 
/* 387 */     return types;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGetGeneratedKeysSupported() {
/* 396 */     return obtainMetaDataProvider().isGetGeneratedKeysSupported();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGetGeneratedKeysSimulated() {
/* 406 */     return obtainMetaDataProvider().isGetGeneratedKeysSimulated();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSimpleQueryForGetGeneratedKey(String tableName, String keyColumnName) {
/* 416 */     return obtainMetaDataProvider().getSimpleQueryForGetGeneratedKey(tableName, keyColumnName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGeneratedKeysColumnNameArraySupported() {
/* 424 */     return obtainMetaDataProvider().isGeneratedKeysColumnNameArraySupported();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class QuoteHandler
/*     */   {
/*     */     @Nullable
/*     */     private final String identifierQuoteString;
/*     */     
/*     */     private final boolean quoting;
/*     */     
/*     */     QuoteHandler(@Nullable String identifierQuoteString) {
/* 436 */       this.identifierQuoteString = identifierQuoteString;
/* 437 */       this.quoting = StringUtils.hasText(identifierQuoteString);
/*     */     }
/*     */     
/*     */     void appendTo(StringBuilder stringBuilder, @Nullable String item) {
/* 441 */       if (this.quoting) {
/* 442 */         stringBuilder.append(this.identifierQuoteString)
/* 443 */           .append(item).append(this.identifierQuoteString);
/*     */       } else {
/*     */         
/* 446 */         stringBuilder.append(item);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\metadata\TableMetaDataContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */