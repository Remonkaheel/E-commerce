/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArgumentTypePreparedStatementSetter
/*     */   implements PreparedStatementSetter, ParameterDisposer
/*     */ {
/*     */   @Nullable
/*     */   private final Object[] args;
/*     */   @Nullable
/*     */   private final int[] argTypes;
/*     */   
/*     */   public ArgumentTypePreparedStatementSetter(@Nullable Object[] args, @Nullable int[] argTypes) {
/*  51 */     if ((args != null && argTypes == null) || (args == null && argTypes != null) || (args != null && args.length != argTypes.length))
/*     */     {
/*  53 */       throw new InvalidDataAccessApiUsageException("args and argTypes parameters must match");
/*     */     }
/*  55 */     this.args = args;
/*  56 */     this.argTypes = argTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValues(PreparedStatement ps) throws SQLException {
/*  62 */     int parameterPosition = 1;
/*  63 */     if (this.args != null && this.argTypes != null) {
/*  64 */       for (int i = 0; i < this.args.length; i++) {
/*  65 */         Object arg = this.args[i];
/*  66 */         if (arg instanceof Collection) { Collection<?> entries = (Collection)arg; if (this.argTypes[i] != 2003) {
/*  67 */             for (Object entry : entries) {
/*  68 */               if (entry instanceof Object[]) { Object[] valueArray = (Object[])entry;
/*  69 */                 for (Object argValue : valueArray) {
/*  70 */                   doSetValue(ps, parameterPosition, this.argTypes[i], argValue);
/*  71 */                   parameterPosition++;
/*     */                 } 
/*     */                 continue; }
/*     */               
/*  75 */               doSetValue(ps, parameterPosition, this.argTypes[i], entry);
/*  76 */               parameterPosition++;
/*     */             } 
/*     */             continue;
/*     */           }  }
/*     */         
/*  81 */         doSetValue(ps, parameterPosition, this.argTypes[i], arg);
/*  82 */         parameterPosition++;
/*     */         continue;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doSetValue(PreparedStatement ps, int parameterPosition, int argType, @Nullable Object argValue) throws SQLException {
/* 101 */     StatementCreatorUtils.setParameterValue(ps, parameterPosition, argType, argValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public void cleanupParameters() {
/* 106 */     StatementCreatorUtils.cleanupParameters(this.args);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\ArgumentTypePreparedStatementSetter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */