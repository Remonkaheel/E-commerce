/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataClassRowMapper<T>
/*     */   extends BeanPropertyRowMapper<T>
/*     */ {
/*     */   @Nullable
/*     */   private Constructor<T> mappedConstructor;
/*     */   @Nullable
/*     */   private String[] constructorParameterNames;
/*     */   @Nullable
/*     */   private TypeDescriptor[] constructorParameterTypes;
/*     */   
/*     */   public DataClassRowMapper() {}
/*     */   
/*     */   public DataClassRowMapper(Class<T> mappedClass) {
/*  87 */     super(mappedClass);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize(Class<T> mappedClass) {
/*  93 */     super.initialize(mappedClass);
/*     */     
/*  95 */     this.mappedConstructor = BeanUtils.getResolvableConstructor(mappedClass);
/*  96 */     int paramCount = this.mappedConstructor.getParameterCount();
/*  97 */     if (paramCount > 0) {
/*  98 */       this.constructorParameterNames = BeanUtils.getParameterNames(this.mappedConstructor);
/*  99 */       for (String name : this.constructorParameterNames) {
/* 100 */         suppressProperty(name);
/*     */       }
/* 102 */       this.constructorParameterTypes = new TypeDescriptor[paramCount];
/* 103 */       for (int i = 0; i < paramCount; i++) {
/* 104 */         this.constructorParameterTypes[i] = new TypeDescriptor(new MethodParameter(this.mappedConstructor, i));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected T constructMappedInstance(ResultSet rs, TypeConverter tc) throws SQLException {
/*     */     Object[] args;
/* 111 */     Assert.state((this.mappedConstructor != null), "Mapped constructor was not initialized");
/*     */ 
/*     */     
/* 114 */     if (this.constructorParameterNames != null && this.constructorParameterTypes != null) {
/* 115 */       args = new Object[this.constructorParameterNames.length];
/* 116 */       for (int i = 0; i < args.length; i++) {
/* 117 */         int index; String name = this.constructorParameterNames[i];
/*     */ 
/*     */         
/*     */         try {
/* 121 */           index = rs.findColumn(lowerCaseName(name));
/*     */         }
/* 123 */         catch (SQLException ex) {
/*     */           
/* 125 */           index = rs.findColumn(underscoreName(name));
/*     */         } 
/* 127 */         TypeDescriptor td = this.constructorParameterTypes[i];
/* 128 */         Object value = getColumnValue(rs, index, td.getType());
/* 129 */         args[i] = tc.convertIfNecessary(value, td.getType(), td);
/*     */       } 
/*     */     } else {
/*     */       
/* 133 */       args = new Object[0];
/*     */     } 
/*     */     
/* 136 */     return (T)BeanUtils.instantiateClass(this.mappedConstructor, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> DataClassRowMapper<T> newInstance(Class<T> mappedClass) {
/* 146 */     return new DataClassRowMapper<>(mappedClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> DataClassRowMapper<T> newInstance(Class<T> mappedClass, @Nullable ConversionService conversionService) {
/* 160 */     DataClassRowMapper<T> rowMapper = newInstance(mappedClass);
/* 161 */     rowMapper.setConversionService(conversionService);
/* 162 */     return rowMapper;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\DataClassRowMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */