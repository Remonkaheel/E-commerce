package org.springframework.jdbc.core;

import java.sql.CallableStatement;
import java.sql.SQLException;
import org.springframework.lang.Nullable;

public interface SqlReturnType {
  public static final int TYPE_UNKNOWN = -2147483648;
  
  Object getTypeValue(CallableStatement paramCallableStatement, int paramInt1, int paramInt2, @Nullable String paramString) throws SQLException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\SqlReturnType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */