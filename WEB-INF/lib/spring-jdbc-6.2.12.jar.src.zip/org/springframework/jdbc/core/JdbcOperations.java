package org.springframework.jdbc.core;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.lang.Nullable;

public interface JdbcOperations {
  @Nullable
  <T> T execute(ConnectionCallback<T> paramConnectionCallback) throws DataAccessException;
  
  @Nullable
  <T> T execute(StatementCallback<T> paramStatementCallback) throws DataAccessException;
  
  void execute(String paramString) throws DataAccessException;
  
  @Nullable
  <T> T query(String paramString, ResultSetExtractor<T> paramResultSetExtractor) throws DataAccessException;
  
  void query(String paramString, RowCallbackHandler paramRowCallbackHandler) throws DataAccessException;
  
  <T> List<T> query(String paramString, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  <T> Stream<T> queryForStream(String paramString, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  @Nullable
  <T> T queryForObject(String paramString, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  @Nullable
  <T> T queryForObject(String paramString, Class<T> paramClass) throws DataAccessException;
  
  Map<String, Object> queryForMap(String paramString) throws DataAccessException;
  
  <T> List<T> queryForList(String paramString, Class<T> paramClass) throws DataAccessException;
  
  List<Map<String, Object>> queryForList(String paramString) throws DataAccessException;
  
  SqlRowSet queryForRowSet(String paramString) throws DataAccessException;
  
  int update(String paramString) throws DataAccessException;
  
  int[] batchUpdate(String... paramVarArgs) throws DataAccessException;
  
  @Nullable
  <T> T execute(PreparedStatementCreator paramPreparedStatementCreator, PreparedStatementCallback<T> paramPreparedStatementCallback) throws DataAccessException;
  
  @Nullable
  <T> T execute(String paramString, PreparedStatementCallback<T> paramPreparedStatementCallback) throws DataAccessException;
  
  @Nullable
  <T> T query(PreparedStatementCreator paramPreparedStatementCreator, ResultSetExtractor<T> paramResultSetExtractor) throws DataAccessException;
  
  @Nullable
  <T> T query(String paramString, @Nullable PreparedStatementSetter paramPreparedStatementSetter, ResultSetExtractor<T> paramResultSetExtractor) throws DataAccessException;
  
  @Nullable
  <T> T query(String paramString, Object[] paramArrayOfObject, int[] paramArrayOfint, ResultSetExtractor<T> paramResultSetExtractor) throws DataAccessException;
  
  @Deprecated
  @Nullable
  <T> T query(String paramString, @Nullable Object[] paramArrayOfObject, ResultSetExtractor<T> paramResultSetExtractor) throws DataAccessException;
  
  @Nullable
  <T> T query(String paramString, ResultSetExtractor<T> paramResultSetExtractor, @Nullable Object... paramVarArgs) throws DataAccessException;
  
  void query(PreparedStatementCreator paramPreparedStatementCreator, RowCallbackHandler paramRowCallbackHandler) throws DataAccessException;
  
  void query(String paramString, @Nullable PreparedStatementSetter paramPreparedStatementSetter, RowCallbackHandler paramRowCallbackHandler) throws DataAccessException;
  
  void query(String paramString, Object[] paramArrayOfObject, int[] paramArrayOfint, RowCallbackHandler paramRowCallbackHandler) throws DataAccessException;
  
  @Deprecated
  void query(String paramString, @Nullable Object[] paramArrayOfObject, RowCallbackHandler paramRowCallbackHandler) throws DataAccessException;
  
  void query(String paramString, RowCallbackHandler paramRowCallbackHandler, @Nullable Object... paramVarArgs) throws DataAccessException;
  
  <T> List<T> query(PreparedStatementCreator paramPreparedStatementCreator, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  <T> List<T> query(String paramString, @Nullable PreparedStatementSetter paramPreparedStatementSetter, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  <T> List<T> query(String paramString, Object[] paramArrayOfObject, int[] paramArrayOfint, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  @Deprecated
  <T> List<T> query(String paramString, @Nullable Object[] paramArrayOfObject, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  <T> List<T> query(String paramString, RowMapper<T> paramRowMapper, @Nullable Object... paramVarArgs) throws DataAccessException;
  
  <T> Stream<T> queryForStream(PreparedStatementCreator paramPreparedStatementCreator, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  <T> Stream<T> queryForStream(String paramString, @Nullable PreparedStatementSetter paramPreparedStatementSetter, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  <T> Stream<T> queryForStream(String paramString, RowMapper<T> paramRowMapper, @Nullable Object... paramVarArgs) throws DataAccessException;
  
  @Nullable
  <T> T queryForObject(String paramString, Object[] paramArrayOfObject, int[] paramArrayOfint, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  @Deprecated
  @Nullable
  <T> T queryForObject(String paramString, @Nullable Object[] paramArrayOfObject, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  @Nullable
  <T> T queryForObject(String paramString, RowMapper<T> paramRowMapper, @Nullable Object... paramVarArgs) throws DataAccessException;
  
  @Nullable
  <T> T queryForObject(String paramString, Object[] paramArrayOfObject, int[] paramArrayOfint, Class<T> paramClass) throws DataAccessException;
  
  @Deprecated
  @Nullable
  <T> T queryForObject(String paramString, @Nullable Object[] paramArrayOfObject, Class<T> paramClass) throws DataAccessException;
  
  @Nullable
  <T> T queryForObject(String paramString, Class<T> paramClass, @Nullable Object... paramVarArgs) throws DataAccessException;
  
  Map<String, Object> queryForMap(String paramString, Object[] paramArrayOfObject, int[] paramArrayOfint) throws DataAccessException;
  
  Map<String, Object> queryForMap(String paramString, @Nullable Object... paramVarArgs) throws DataAccessException;
  
  <T> List<T> queryForList(String paramString, Object[] paramArrayOfObject, int[] paramArrayOfint, Class<T> paramClass) throws DataAccessException;
  
  @Deprecated
  <T> List<T> queryForList(String paramString, @Nullable Object[] paramArrayOfObject, Class<T> paramClass) throws DataAccessException;
  
  <T> List<T> queryForList(String paramString, Class<T> paramClass, @Nullable Object... paramVarArgs) throws DataAccessException;
  
  List<Map<String, Object>> queryForList(String paramString, Object[] paramArrayOfObject, int[] paramArrayOfint) throws DataAccessException;
  
  List<Map<String, Object>> queryForList(String paramString, @Nullable Object... paramVarArgs) throws DataAccessException;
  
  SqlRowSet queryForRowSet(String paramString, Object[] paramArrayOfObject, int[] paramArrayOfint) throws DataAccessException;
  
  SqlRowSet queryForRowSet(String paramString, @Nullable Object... paramVarArgs) throws DataAccessException;
  
  int update(PreparedStatementCreator paramPreparedStatementCreator) throws DataAccessException;
  
  int update(PreparedStatementCreator paramPreparedStatementCreator, KeyHolder paramKeyHolder) throws DataAccessException;
  
  int update(String paramString, @Nullable PreparedStatementSetter paramPreparedStatementSetter) throws DataAccessException;
  
  int update(String paramString, Object[] paramArrayOfObject, int[] paramArrayOfint) throws DataAccessException;
  
  int update(String paramString, @Nullable Object... paramVarArgs) throws DataAccessException;
  
  int[] batchUpdate(String paramString, BatchPreparedStatementSetter paramBatchPreparedStatementSetter) throws DataAccessException;
  
  int[] batchUpdate(PreparedStatementCreator paramPreparedStatementCreator, BatchPreparedStatementSetter paramBatchPreparedStatementSetter, KeyHolder paramKeyHolder) throws DataAccessException;
  
  int[] batchUpdate(String paramString, List<Object[]> paramList) throws DataAccessException;
  
  int[] batchUpdate(String paramString, List<Object[]> paramList, int[] paramArrayOfint) throws DataAccessException;
  
  <T> int[][] batchUpdate(String paramString, Collection<T> paramCollection, int paramInt, ParameterizedPreparedStatementSetter<T> paramParameterizedPreparedStatementSetter) throws DataAccessException;
  
  @Nullable
  <T> T execute(CallableStatementCreator paramCallableStatementCreator, CallableStatementCallback<T> paramCallableStatementCallback) throws DataAccessException;
  
  @Nullable
  <T> T execute(String paramString, CallableStatementCallback<T> paramCallableStatementCallback) throws DataAccessException;
  
  Map<String, Object> call(CallableStatementCreator paramCallableStatementCreator, List<SqlParameter> paramList) throws DataAccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\JdbcOperations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */