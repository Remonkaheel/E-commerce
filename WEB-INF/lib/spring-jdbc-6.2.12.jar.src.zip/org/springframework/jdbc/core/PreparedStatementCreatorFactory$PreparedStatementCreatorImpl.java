/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PreparedStatementCreatorImpl
/*     */   implements PreparedStatementCreator, PreparedStatementSetter, SqlProvider, ParameterDisposer
/*     */ {
/*     */   private final String actualSql;
/*     */   private final List<?> parameters;
/*     */   
/*     */   public PreparedStatementCreatorImpl(PreparedStatementCreatorFactory paramPreparedStatementCreatorFactory, List<?> parameters) {
/* 201 */     this(paramPreparedStatementCreatorFactory.sql, parameters);
/*     */   }
/*     */   
/*     */   public PreparedStatementCreatorImpl(String actualSql, List<?> parameters) {
/* 205 */     this.actualSql = actualSql;
/* 206 */     this.parameters = parameters;
/* 207 */     if (paramPreparedStatementCreatorFactory.declaredParameters != null && parameters.size() != paramPreparedStatementCreatorFactory.declaredParameters.size()) {
/*     */       
/* 209 */       Set<String> names = new HashSet<>();
/* 210 */       for (int i = 0; i < parameters.size(); i++) {
/* 211 */         Object param = parameters.get(i);
/* 212 */         if (param instanceof SqlParameterValue) { SqlParameterValue sqlParameterValue = (SqlParameterValue)param;
/* 213 */           names.add(sqlParameterValue.getName()); }
/*     */         else
/*     */         
/* 216 */         { names.add("Parameter #" + i); }
/*     */       
/*     */       } 
/* 219 */       if (names.size() != paramPreparedStatementCreatorFactory.declaredParameters.size()) {
/* 220 */         throw new InvalidDataAccessApiUsageException("SQL [" + paramPreparedStatementCreatorFactory.sql + "]: given " + names
/* 221 */             .size() + " parameters but expected " + paramPreparedStatementCreatorFactory.declaredParameters
/* 222 */             .size());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
/*     */     PreparedStatement ps;
/* 230 */     if (PreparedStatementCreatorFactory.this.generatedKeysColumnNames != null || PreparedStatementCreatorFactory.this.returnGeneratedKeys) {
/* 231 */       if (PreparedStatementCreatorFactory.this.generatedKeysColumnNames != null) {
/* 232 */         ps = con.prepareStatement(this.actualSql, PreparedStatementCreatorFactory.this.generatedKeysColumnNames);
/*     */       } else {
/*     */         
/* 235 */         ps = con.prepareStatement(this.actualSql, 1);
/*     */       }
/*     */     
/* 238 */     } else if (PreparedStatementCreatorFactory.this.resultSetType == 1003 && !PreparedStatementCreatorFactory.this.updatableResults) {
/* 239 */       ps = con.prepareStatement(this.actualSql);
/*     */     } else {
/*     */       
/* 242 */       ps = con.prepareStatement(this.actualSql, PreparedStatementCreatorFactory.this.resultSetType, 
/* 243 */           PreparedStatementCreatorFactory.this.updatableResults ? 1008 : 1007);
/*     */     } 
/* 245 */     setValues(ps);
/* 246 */     return ps;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValues(PreparedStatement ps) throws SQLException {
/* 252 */     int sqlColIndx = 1;
/* 253 */     for (int i = 0; i < this.parameters.size(); i++) {
/* 254 */       Object in = this.parameters.get(i);
/* 255 */       SqlParameter declaredParameter = null;
/*     */ 
/*     */       
/* 258 */       if (in instanceof SqlParameterValue) { SqlParameterValue sqlParameterValue = (SqlParameterValue)in;
/* 259 */         in = sqlParameterValue.getValue();
/* 260 */         declaredParameter = sqlParameterValue; }
/*     */       
/* 262 */       else if (PreparedStatementCreatorFactory.this.declaredParameters != null)
/* 263 */       { if (PreparedStatementCreatorFactory.this.declaredParameters.size() <= i) {
/* 264 */           throw new InvalidDataAccessApiUsageException("SQL [" + PreparedStatementCreatorFactory.this.sql + "]: unable to access parameter number " + i + 1 + " given only " + PreparedStatementCreatorFactory.this.declaredParameters
/*     */               
/* 266 */               .size() + " parameters");
/*     */         }
/*     */         
/* 269 */         declaredParameter = PreparedStatementCreatorFactory.this.declaredParameters.get(i); }
/*     */       
/* 271 */       if (declaredParameter == null) {
/* 272 */         StatementCreatorUtils.setParameterValue(ps, sqlColIndx++, -2147483648, in); continue;
/*     */       } 
/* 274 */       if (in instanceof Iterable) { Iterable<?> entries = (Iterable)in; if (declaredParameter.getSqlType() != 2003) {
/* 275 */           for (Object entry : entries) {
/* 276 */             if (entry instanceof Object[]) { Object[] valueArray = (Object[])entry;
/* 277 */               for (Object argValue : valueArray) {
/* 278 */                 StatementCreatorUtils.setParameterValue(ps, sqlColIndx++, declaredParameter, argValue);
/*     */               }
/*     */               continue; }
/*     */             
/* 282 */             StatementCreatorUtils.setParameterValue(ps, sqlColIndx++, declaredParameter, entry);
/*     */           } 
/*     */           continue;
/*     */         }  }
/*     */       
/* 287 */       StatementCreatorUtils.setParameterValue(ps, sqlColIndx++, declaredParameter, in);
/*     */       continue;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSql() {
/* 294 */     return PreparedStatementCreatorFactory.this.sql;
/*     */   }
/*     */ 
/*     */   
/*     */   public void cleanupParameters() {
/* 299 */     StatementCreatorUtils.cleanupParameters(this.parameters);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 304 */     return "PreparedStatementCreator: sql=[" + PreparedStatementCreatorFactory.this.sql + "]; parameters=" + String.valueOf(this.parameters);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\PreparedStatementCreatorFactory$PreparedStatementCreatorImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */