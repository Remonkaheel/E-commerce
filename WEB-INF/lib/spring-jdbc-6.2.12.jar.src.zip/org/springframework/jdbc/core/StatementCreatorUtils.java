/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.Date;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.jdbc.support.SqlValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StatementCreatorUtils
/*     */ {
/*     */   public static final String IGNORE_GETPARAMETERTYPE_PROPERTY_NAME = "spring.jdbc.getParameterType.ignore";
/*  84 */   private static final Log logger = LogFactory.getLog(StatementCreatorUtils.class);
/*     */   
/*  86 */   private static final Map<Class<?>, Integer> javaTypeToSqlTypeMap = new HashMap<>(64);
/*     */   
/*     */   @Nullable
/*  89 */   static Boolean shouldIgnoreGetParameterType = SpringProperties.checkFlag("spring.jdbc.getParameterType.ignore");
/*     */   
/*     */   static {
/*  92 */     javaTypeToSqlTypeMap.put(boolean.class, Integer.valueOf(16));
/*  93 */     javaTypeToSqlTypeMap.put(Boolean.class, Integer.valueOf(16));
/*  94 */     javaTypeToSqlTypeMap.put(byte.class, Integer.valueOf(-6));
/*  95 */     javaTypeToSqlTypeMap.put(Byte.class, Integer.valueOf(-6));
/*  96 */     javaTypeToSqlTypeMap.put(short.class, Integer.valueOf(5));
/*  97 */     javaTypeToSqlTypeMap.put(Short.class, Integer.valueOf(5));
/*  98 */     javaTypeToSqlTypeMap.put(int.class, Integer.valueOf(4));
/*  99 */     javaTypeToSqlTypeMap.put(Integer.class, Integer.valueOf(4));
/* 100 */     javaTypeToSqlTypeMap.put(long.class, Integer.valueOf(-5));
/* 101 */     javaTypeToSqlTypeMap.put(Long.class, Integer.valueOf(-5));
/* 102 */     javaTypeToSqlTypeMap.put(BigInteger.class, Integer.valueOf(-5));
/* 103 */     javaTypeToSqlTypeMap.put(float.class, Integer.valueOf(6));
/* 104 */     javaTypeToSqlTypeMap.put(Float.class, Integer.valueOf(6));
/* 105 */     javaTypeToSqlTypeMap.put(double.class, Integer.valueOf(8));
/* 106 */     javaTypeToSqlTypeMap.put(Double.class, Integer.valueOf(8));
/* 107 */     javaTypeToSqlTypeMap.put(BigDecimal.class, Integer.valueOf(3));
/* 108 */     javaTypeToSqlTypeMap.put(LocalDate.class, Integer.valueOf(91));
/* 109 */     javaTypeToSqlTypeMap.put(LocalTime.class, Integer.valueOf(92));
/* 110 */     javaTypeToSqlTypeMap.put(LocalDateTime.class, Integer.valueOf(93));
/* 111 */     javaTypeToSqlTypeMap.put(OffsetTime.class, Integer.valueOf(2013));
/* 112 */     javaTypeToSqlTypeMap.put(OffsetDateTime.class, Integer.valueOf(2014));
/* 113 */     javaTypeToSqlTypeMap.put(Date.class, Integer.valueOf(91));
/* 114 */     javaTypeToSqlTypeMap.put(Time.class, Integer.valueOf(92));
/* 115 */     javaTypeToSqlTypeMap.put(Timestamp.class, Integer.valueOf(93));
/* 116 */     javaTypeToSqlTypeMap.put(Blob.class, Integer.valueOf(2004));
/* 117 */     javaTypeToSqlTypeMap.put(Clob.class, Integer.valueOf(2005));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int javaTypeToSqlParameterType(@Nullable Class<?> javaType) {
/* 127 */     if (javaType == null) {
/* 128 */       return Integer.MIN_VALUE;
/*     */     }
/* 130 */     Integer sqlType = javaTypeToSqlTypeMap.get(javaType);
/* 131 */     if (sqlType != null) {
/* 132 */       return sqlType.intValue();
/*     */     }
/* 134 */     if (Number.class.isAssignableFrom(javaType)) {
/* 135 */       return 2;
/*     */     }
/* 137 */     if (isStringValue(javaType)) {
/* 138 */       return 12;
/*     */     }
/* 140 */     if (isDateValue(javaType) || Calendar.class.isAssignableFrom(javaType)) {
/* 141 */       return 93;
/*     */     }
/* 143 */     return Integer.MIN_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setParameterValue(PreparedStatement ps, int paramIndex, SqlParameter param, @Nullable Object inValue) throws SQLException {
/* 158 */     setParameterValueInternal(ps, paramIndex, param.getSqlType(), param.getTypeName(), param.getScale(), inValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setParameterValue(PreparedStatement ps, int paramIndex, int sqlType, @Nullable Object inValue) throws SQLException {
/* 174 */     setParameterValueInternal(ps, paramIndex, sqlType, null, null, inValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setParameterValue(PreparedStatement ps, int paramIndex, int sqlType, String typeName, @Nullable Object inValue) throws SQLException {
/* 192 */     setParameterValueInternal(ps, paramIndex, sqlType, typeName, null, inValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setParameterValueInternal(PreparedStatement ps, int paramIndex, int sqlType, @Nullable String typeName, @Nullable Integer scale, @Nullable Object inValue) throws SQLException {
/* 212 */     String typeNameToUse = typeName;
/* 213 */     int sqlTypeToUse = sqlType;
/* 214 */     Object inValueToUse = inValue;
/*     */ 
/*     */     
/* 217 */     if (inValue instanceof SqlParameterValue) { SqlParameterValue parameterValue = (SqlParameterValue)inValue;
/* 218 */       if (logger.isDebugEnabled()) {
/* 219 */         logger.debug("Overriding type info with runtime info from SqlParameterValue: column index " + paramIndex + ", SQL type " + parameterValue
/* 220 */             .getSqlType() + ", type name " + parameterValue.getTypeName());
/*     */       }
/* 222 */       if (parameterValue.getSqlType() != Integer.MIN_VALUE) {
/* 223 */         sqlTypeToUse = parameterValue.getSqlType();
/*     */       }
/* 225 */       if (parameterValue.getTypeName() != null) {
/* 226 */         typeNameToUse = parameterValue.getTypeName();
/*     */       }
/* 228 */       inValueToUse = parameterValue.getValue(); }
/*     */ 
/*     */     
/* 231 */     if (logger.isTraceEnabled()) {
/* 232 */       logger.trace("Setting SQL statement parameter value: column index " + paramIndex + ", parameter value [" + String.valueOf(inValueToUse) + "], value class [" + (
/*     */           
/* 234 */           (inValueToUse != null) ? inValueToUse.getClass().getName() : "null") + "], SQL type " + (
/* 235 */           (sqlTypeToUse == Integer.MIN_VALUE) ? "unknown" : Integer.toString(sqlTypeToUse)));
/*     */     }
/*     */     
/* 238 */     if (inValueToUse == null) {
/* 239 */       setNull(ps, paramIndex, sqlTypeToUse, typeNameToUse);
/*     */     } else {
/*     */       
/* 242 */       setValue(ps, paramIndex, sqlTypeToUse, typeNameToUse, scale, inValueToUse);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setNull(PreparedStatement ps, int paramIndex, int sqlType, @Nullable String typeName) throws SQLException {
/* 253 */     if (sqlType == Integer.MIN_VALUE || (sqlType == 1111 && typeName == null)) {
/* 254 */       boolean callGetParameterType = false;
/* 255 */       boolean useSetObject = false;
/* 256 */       Integer sqlTypeToUse = null;
/* 257 */       if (shouldIgnoreGetParameterType != null) {
/* 258 */         callGetParameterType = !shouldIgnoreGetParameterType.booleanValue();
/*     */       } else {
/*     */         
/* 261 */         String jdbcDriverName = ps.getConnection().getMetaData().getDriverName();
/* 262 */         if (jdbcDriverName.startsWith("PostgreSQL")) {
/* 263 */           sqlTypeToUse = Integer.valueOf(0);
/*     */         }
/* 265 */         else if (jdbcDriverName.startsWith("Microsoft") && jdbcDriverName.contains("SQL Server")) {
/* 266 */           sqlTypeToUse = Integer.valueOf(0);
/* 267 */           useSetObject = true;
/*     */         } else {
/*     */           
/* 270 */           callGetParameterType = true;
/*     */         } 
/*     */       } 
/* 273 */       if (callGetParameterType) {
/*     */         try {
/* 275 */           sqlTypeToUse = Integer.valueOf(ps.getParameterMetaData().getParameterType(paramIndex));
/*     */         }
/* 277 */         catch (SQLException ex) {
/* 278 */           if (logger.isDebugEnabled()) {
/* 279 */             logger.debug("JDBC getParameterType call failed - using fallback method instead: " + String.valueOf(ex));
/*     */           }
/*     */         } 
/*     */       }
/* 283 */       if (sqlTypeToUse == null) {
/*     */         
/* 285 */         sqlTypeToUse = Integer.valueOf(0);
/* 286 */         DatabaseMetaData dbmd = ps.getConnection().getMetaData();
/* 287 */         String jdbcDriverName = dbmd.getDriverName();
/* 288 */         String databaseProductName = dbmd.getDatabaseProductName();
/* 289 */         if (databaseProductName.startsWith("Informix") || (jdbcDriverName
/* 290 */           .startsWith("Microsoft") && jdbcDriverName.contains("SQL Server"))) {
/*     */           
/* 292 */           useSetObject = true;
/*     */         }
/* 294 */         else if (databaseProductName.startsWith("DB2") || jdbcDriverName
/* 295 */           .startsWith("jConnect") || jdbcDriverName
/* 296 */           .startsWith("SQLServer") || jdbcDriverName
/* 297 */           .startsWith("Apache Derby")) {
/* 298 */           sqlTypeToUse = Integer.valueOf(12);
/*     */         } 
/*     */       } 
/* 301 */       if (useSetObject) {
/* 302 */         ps.setObject(paramIndex, null);
/*     */       } else {
/*     */         
/* 305 */         ps.setNull(paramIndex, sqlTypeToUse.intValue());
/*     */       }
/*     */     
/* 308 */     } else if (typeName != null) {
/* 309 */       ps.setNull(paramIndex, sqlType, typeName);
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 315 */         ps.setNull(paramIndex, sqlType);
/*     */       }
/* 317 */       catch (SQLFeatureNotSupportedException ex) {
/* 318 */         if (sqlType == 0) {
/* 319 */           throw ex;
/*     */         }
/*     */ 
/*     */         
/* 323 */         ps.setNull(paramIndex, 0);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setValue(PreparedStatement ps, int paramIndex, int sqlType, @Nullable String typeName, @Nullable Integer scale, Object inValue) throws SQLException {
/* 331 */     if (inValue instanceof SqlTypeValue) { SqlTypeValue sqlTypeValue = (SqlTypeValue)inValue;
/* 332 */       sqlTypeValue.setTypeValue(ps, paramIndex, sqlType, typeName); }
/*     */     
/* 334 */     else if (inValue instanceof SqlValue) { SqlValue sqlValue = (SqlValue)inValue;
/* 335 */       sqlValue.setValue(ps, paramIndex); }
/*     */     
/* 337 */     else if (sqlType == 12 || sqlType == -1)
/* 338 */     { ps.setString(paramIndex, inValue.toString()); }
/*     */     
/* 340 */     else if (sqlType == -9 || sqlType == -16)
/* 341 */     { ps.setNString(paramIndex, inValue.toString()); }
/*     */     
/* 343 */     else if ((sqlType == 2005 || sqlType == 2011) && isStringValue(inValue.getClass()))
/* 344 */     { String strVal = inValue.toString();
/* 345 */       if (strVal.length() > 4000) {
/*     */ 
/*     */         
/* 348 */         if (sqlType == 2011) {
/* 349 */           ps.setNClob(paramIndex, new StringReader(strVal), strVal.length());
/*     */         } else {
/*     */           
/* 352 */           ps.setClob(paramIndex, new StringReader(strVal), strVal.length());
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 357 */       else if (sqlType == 2011) {
/* 358 */         ps.setNString(paramIndex, strVal);
/*     */       } else {
/*     */         
/* 361 */         ps.setString(paramIndex, strVal);
/*     */       }
/*     */        }
/*     */     
/* 365 */     else if (sqlType == 3 || sqlType == 2)
/* 366 */     { if (inValue instanceof BigDecimal) { BigDecimal bigDecimal = (BigDecimal)inValue;
/* 367 */         ps.setBigDecimal(paramIndex, bigDecimal); }
/*     */       
/* 369 */       else if (scale != null)
/* 370 */       { ps.setObject(paramIndex, inValue, sqlType, scale.intValue()); }
/*     */       else
/*     */       
/* 373 */       { ps.setObject(paramIndex, inValue, sqlType); }
/*     */       
/*     */        }
/* 376 */     else if (sqlType == 16)
/* 377 */     { if (inValue instanceof Boolean) { Boolean flag = (Boolean)inValue;
/* 378 */         ps.setBoolean(paramIndex, flag.booleanValue()); }
/*     */       else
/*     */       
/* 381 */       { ps.setObject(paramIndex, inValue, 16); }
/*     */       
/*     */        }
/* 384 */     else if (sqlType == 91)
/* 385 */     { if (inValue instanceof Date) { Date date = (Date)inValue;
/* 386 */         if (inValue instanceof Date) { Date sqlDate = (Date)inValue;
/* 387 */           ps.setDate(paramIndex, sqlDate); }
/*     */         else
/*     */         
/* 390 */         { ps.setDate(paramIndex, new Date(date.getTime())); }
/*     */         
/*     */          }
/* 393 */       else if (inValue instanceof Calendar) { Calendar cal = (Calendar)inValue;
/* 394 */         ps.setDate(paramIndex, new Date(cal.getTime().getTime()), cal); }
/*     */       else
/*     */       
/* 397 */       { ps.setObject(paramIndex, inValue, 91); }
/*     */       
/*     */        }
/* 400 */     else if (sqlType == 92)
/* 401 */     { if (inValue instanceof Date) { Date date = (Date)inValue;
/* 402 */         if (inValue instanceof Time) { Time time = (Time)inValue;
/* 403 */           ps.setTime(paramIndex, time); }
/*     */         else
/*     */         
/* 406 */         { ps.setTime(paramIndex, new Time(date.getTime())); }
/*     */         
/*     */          }
/* 409 */       else if (inValue instanceof Calendar) { Calendar cal = (Calendar)inValue;
/* 410 */         ps.setTime(paramIndex, new Time(cal.getTime().getTime()), cal); }
/*     */       else
/*     */       
/* 413 */       { ps.setObject(paramIndex, inValue, 92); }
/*     */       
/*     */        }
/* 416 */     else if (sqlType == 93)
/* 417 */     { if (inValue instanceof Date) { Date date = (Date)inValue;
/* 418 */         if (inValue instanceof Timestamp) { Timestamp timestamp = (Timestamp)inValue;
/* 419 */           ps.setTimestamp(paramIndex, timestamp); }
/*     */         else
/*     */         
/* 422 */         { ps.setTimestamp(paramIndex, new Timestamp(date.getTime())); }
/*     */         
/*     */          }
/* 425 */       else if (inValue instanceof Calendar) { Calendar cal = (Calendar)inValue;
/* 426 */         ps.setTimestamp(paramIndex, new Timestamp(cal.getTime().getTime()), cal); }
/*     */       else
/*     */       
/* 429 */       { ps.setObject(paramIndex, inValue, 93); }
/*     */       
/*     */        }
/* 432 */     else if (sqlType == Integer.MIN_VALUE || (sqlType == 1111 && "Oracle"
/* 433 */       .equals(ps.getConnection().getMetaData().getDatabaseProductName())))
/* 434 */     { if (inValue instanceof byte[]) { byte[] bytes = (byte[])inValue;
/* 435 */         ps.setBytes(paramIndex, bytes); }
/*     */       
/* 437 */       else if (isStringValue(inValue.getClass()))
/* 438 */       { ps.setString(paramIndex, inValue.toString()); }
/*     */       
/* 440 */       else if (isDateValue(inValue.getClass()))
/* 441 */       { ps.setTimestamp(paramIndex, new Timestamp(((Date)inValue).getTime())); }
/*     */       
/* 443 */       else if (inValue instanceof Calendar) { Calendar cal = (Calendar)inValue;
/* 444 */         ps.setTimestamp(paramIndex, new Timestamp(cal.getTime().getTime()), cal); }
/*     */       
/*     */       else
/*     */       
/* 448 */       { ps.setObject(paramIndex, inValue); }
/*     */        }
/*     */     else
/*     */     
/*     */     { 
/*     */       try {
/*     */         
/* 455 */         ps.setObject(paramIndex, inValue, sqlType);
/*     */       }
/* 457 */       catch (SQLFeatureNotSupportedException ex) {
/*     */ 
/*     */         
/* 460 */         ps.setObject(paramIndex, inValue);
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isStringValue(Class<?> inValueType) {
/* 470 */     return (CharSequence.class.isAssignableFrom(inValueType) || StringWriter.class
/* 471 */       .isAssignableFrom(inValueType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isDateValue(Class<?> inValueType) {
/* 479 */     return (Date.class.isAssignableFrom(inValueType) && 
/* 480 */       !Date.class.isAssignableFrom(inValueType) && 
/* 481 */       !Time.class.isAssignableFrom(inValueType) && 
/* 482 */       !Timestamp.class.isAssignableFrom(inValueType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void cleanupParameters(@Nullable Object... paramValues) {
/* 493 */     if (paramValues != null) {
/* 494 */       cleanupParameters(Arrays.asList(paramValues));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void cleanupParameters(@Nullable Collection<?> paramValues) {
/* 506 */     if (paramValues != null)
/* 507 */       for (Object inValue : paramValues) {
/*     */         
/* 509 */         if (inValue instanceof SqlParameterValue) { SqlParameterValue sqlParameterValue = (SqlParameterValue)inValue;
/* 510 */           inValue = sqlParameterValue.getValue(); }
/*     */ 
/*     */         
/* 513 */         if (inValue instanceof SqlValue) { SqlValue sqlValue = (SqlValue)inValue;
/* 514 */           sqlValue.cleanup(); continue; }
/*     */         
/* 516 */         if (inValue instanceof DisposableSqlTypeValue) { DisposableSqlTypeValue disposableSqlTypeValue = (DisposableSqlTypeValue)inValue;
/* 517 */           disposableSqlTypeValue.cleanup(); }
/*     */       
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\StatementCreatorUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */