/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlParameter
/*     */ {
/*     */   @Nullable
/*     */   private String name;
/*     */   private final int sqlType;
/*     */   @Nullable
/*     */   private String typeName;
/*     */   @Nullable
/*     */   private Integer scale;
/*     */   
/*     */   public SqlParameter(int sqlType) {
/*  59 */     this.sqlType = sqlType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlParameter(int sqlType, @Nullable String typeName) {
/*  68 */     this.sqlType = sqlType;
/*  69 */     this.typeName = typeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlParameter(int sqlType, int scale) {
/*  79 */     this.sqlType = sqlType;
/*  80 */     this.scale = Integer.valueOf(scale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlParameter(String name, int sqlType) {
/*  89 */     this.name = name;
/*  90 */     this.sqlType = sqlType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlParameter(String name, int sqlType, @Nullable String typeName) {
/* 100 */     this.name = name;
/* 101 */     this.sqlType = sqlType;
/* 102 */     this.typeName = typeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlParameter(String name, int sqlType, int scale) {
/* 113 */     this.name = name;
/* 114 */     this.sqlType = sqlType;
/* 115 */     this.scale = Integer.valueOf(scale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlParameter(SqlParameter otherParam) {
/* 123 */     Assert.notNull(otherParam, "SqlParameter object must not be null");
/* 124 */     this.name = otherParam.name;
/* 125 */     this.sqlType = otherParam.sqlType;
/* 126 */     this.typeName = otherParam.typeName;
/* 127 */     this.scale = otherParam.scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getName() {
/* 136 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSqlType() {
/* 143 */     return this.sqlType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getTypeName() {
/* 151 */     return this.typeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer getScale() {
/* 159 */     return this.scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInputValueProvided() {
/* 169 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResultsParameter() {
/* 178 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<SqlParameter> sqlTypesToAnonymousParameterList(@Nullable int... types) {
/* 187 */     if (types == null) {
/* 188 */       return new ArrayList<>();
/*     */     }
/* 190 */     List<SqlParameter> result = new ArrayList<>(types.length);
/* 191 */     for (int type : types) {
/* 192 */       result.add(new SqlParameter(type));
/*     */     }
/* 194 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\SqlParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */