package org.springframework.jdbc.core;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface PreparedStatementCallback<T> {
  @Nullable
  T doInPreparedStatement(PreparedStatement paramPreparedStatement) throws SQLException, DataAccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\PreparedStatementCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */