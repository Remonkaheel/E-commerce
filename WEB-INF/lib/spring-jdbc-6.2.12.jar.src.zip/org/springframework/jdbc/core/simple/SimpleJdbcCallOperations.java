package org.springframework.jdbc.core.simple;

import java.util.Map;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.lang.Nullable;

public interface SimpleJdbcCallOperations {
  SimpleJdbcCallOperations withProcedureName(String paramString);
  
  SimpleJdbcCallOperations withFunctionName(String paramString);
  
  SimpleJdbcCallOperations withSchemaName(String paramString);
  
  SimpleJdbcCallOperations withCatalogName(String paramString);
  
  SimpleJdbcCallOperations withReturnValue();
  
  SimpleJdbcCallOperations declareParameters(SqlParameter... paramVarArgs);
  
  SimpleJdbcCallOperations useInParameterNames(String... paramVarArgs);
  
  SimpleJdbcCallOperations returningResultSet(String paramString, RowMapper<?> paramRowMapper);
  
  SimpleJdbcCallOperations withoutProcedureColumnMetaDataAccess();
  
  SimpleJdbcCallOperations withNamedBinding();
  
  @Nullable
  <T> T executeFunction(Class<T> paramClass, Object... paramVarArgs);
  
  @Nullable
  <T> T executeFunction(Class<T> paramClass, Map<String, ?> paramMap);
  
  @Nullable
  <T> T executeFunction(Class<T> paramClass, SqlParameterSource paramSqlParameterSource);
  
  @Nullable
  <T> T executeObject(Class<T> paramClass, Object... paramVarArgs);
  
  @Nullable
  <T> T executeObject(Class<T> paramClass, Map<String, ?> paramMap);
  
  @Nullable
  <T> T executeObject(Class<T> paramClass, SqlParameterSource paramSqlParameterSource);
  
  Map<String, Object> execute(Object... paramVarArgs);
  
  Map<String, Object> execute(Map<String, ?> paramMap);
  
  Map<String, Object> execute(SqlParameterSource paramSqlParameterSource);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\simple\SimpleJdbcCallOperations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */