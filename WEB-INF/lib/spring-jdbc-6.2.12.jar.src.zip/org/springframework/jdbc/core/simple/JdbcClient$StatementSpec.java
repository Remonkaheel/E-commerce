package org.springframework.jdbc.core.simple;

import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.lang.Nullable;

public interface StatementSpec {
  StatementSpec param(@Nullable Object paramObject);
  
  StatementSpec param(int paramInt, @Nullable Object paramObject);
  
  StatementSpec param(int paramInt1, @Nullable Object paramObject, int paramInt2);
  
  StatementSpec param(String paramString, @Nullable Object paramObject);
  
  StatementSpec param(String paramString, @Nullable Object paramObject, int paramInt);
  
  StatementSpec params(Object... paramVarArgs);
  
  StatementSpec params(List<?> paramList);
  
  StatementSpec params(Map<String, ?> paramMap);
  
  StatementSpec paramSource(Object paramObject);
  
  StatementSpec paramSource(SqlParameterSource paramSqlParameterSource);
  
  JdbcClient.ResultQuerySpec query();
  
  <T> JdbcClient.MappedQuerySpec<T> query(Class<T> paramClass);
  
  <T> JdbcClient.MappedQuerySpec<T> query(RowMapper<T> paramRowMapper);
  
  void query(RowCallbackHandler paramRowCallbackHandler);
  
  <T> T query(ResultSetExtractor<T> paramResultSetExtractor);
  
  int update();
  
  int update(KeyHolder paramKeyHolder);
  
  int update(KeyHolder paramKeyHolder, String... paramVarArgs);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\simple\JdbcClient$StatementSpec.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */