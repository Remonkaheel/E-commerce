package org.springframework.jdbc.core.simple;

import java.util.Map;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.KeyHolder;

public interface SimpleJdbcInsertOperations {
  SimpleJdbcInsertOperations withTableName(String paramString);
  
  SimpleJdbcInsertOperations withSchemaName(String paramString);
  
  SimpleJdbcInsertOperations withCatalogName(String paramString);
  
  SimpleJdbcInsertOperations usingColumns(String... paramVarArgs);
  
  SimpleJdbcInsertOperations usingGeneratedKeyColumns(String... paramVarArgs);
  
  SimpleJdbcInsertOperations usingQuotedIdentifiers();
  
  SimpleJdbcInsertOperations withoutTableColumnMetaDataAccess();
  
  SimpleJdbcInsertOperations includeSynonymsForTableColumnMetaData();
  
  int execute(Map<String, ?> paramMap);
  
  int execute(SqlParameterSource paramSqlParameterSource);
  
  Number executeAndReturnKey(Map<String, ?> paramMap);
  
  Number executeAndReturnKey(SqlParameterSource paramSqlParameterSource);
  
  KeyHolder executeAndReturnKeyHolder(Map<String, ?> paramMap);
  
  KeyHolder executeAndReturnKeyHolder(SqlParameterSource paramSqlParameterSource);
  
  int[] executeBatch(Map<String, ?>... paramVarArgs);
  
  int[] executeBatch(SqlParameterSource... paramVarArgs);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\simple\SimpleJdbcInsertOperations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */