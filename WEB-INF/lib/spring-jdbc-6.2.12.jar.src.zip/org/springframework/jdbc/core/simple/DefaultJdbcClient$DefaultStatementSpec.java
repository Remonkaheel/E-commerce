/*     */ package org.springframework.jdbc.core.simple;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreatorFactory;
/*     */ import org.springframework.jdbc.core.ResultSetExtractor;
/*     */ import org.springframework.jdbc.core.RowCallbackHandler;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.SimplePropertyRowMapper;
/*     */ import org.springframework.jdbc.core.SingleColumnRowMapper;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.SimplePropertySqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.support.KeyHolder;
/*     */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultStatementSpec
/*     */   implements JdbcClient.StatementSpec
/*     */ {
/*     */   private final String sql;
/*  97 */   private final List<Object> indexedParams = new ArrayList();
/*     */   
/*  99 */   private final MapSqlParameterSource namedParams = new MapSqlParameterSource();
/*     */   
/* 101 */   private SqlParameterSource namedParamSource = (SqlParameterSource)this.namedParams;
/*     */   
/*     */   public DefaultStatementSpec(String sql) {
/* 104 */     this.sql = sql;
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcClient.StatementSpec param(@Nullable Object value) {
/* 109 */     validateIndexedParamValue(value);
/* 110 */     this.indexedParams.add(value);
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcClient.StatementSpec param(int jdbcIndex, @Nullable Object value) {
/* 116 */     if (jdbcIndex < 1) {
/* 117 */       throw new IllegalArgumentException("Invalid JDBC index: needs to start at 1");
/*     */     }
/* 119 */     validateIndexedParamValue(value);
/* 120 */     int index = jdbcIndex - 1;
/* 121 */     int size = this.indexedParams.size();
/* 122 */     if (index < size) {
/* 123 */       this.indexedParams.set(index, value);
/*     */     } else {
/*     */       
/* 126 */       for (int i = size; i < index; i++) {
/* 127 */         this.indexedParams.add(null);
/*     */       }
/* 129 */       this.indexedParams.add(value);
/*     */     } 
/* 131 */     return this;
/*     */   }
/*     */   
/*     */   private void validateIndexedParamValue(@Nullable Object value) {
/* 135 */     if (value instanceof Iterable) {
/* 136 */       throw new IllegalArgumentException("Invalid positional parameter value of type Iterable (" + value
/* 137 */           .getClass().getSimpleName() + "): Parameter expansion is only supported with named parameters.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcClient.StatementSpec param(int jdbcIndex, @Nullable Object value, int sqlType) {
/* 144 */     return param(jdbcIndex, new SqlParameterValue(sqlType, value));
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcClient.StatementSpec param(String name, @Nullable Object value) {
/* 149 */     this.namedParams.addValue(name, value);
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcClient.StatementSpec param(String name, @Nullable Object value, int sqlType) {
/* 155 */     this.namedParams.addValue(name, value, sqlType);
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcClient.StatementSpec params(Object... values) {
/* 161 */     Collections.addAll(this.indexedParams, values);
/* 162 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcClient.StatementSpec params(List<?> values) {
/* 167 */     this.indexedParams.addAll(values);
/* 168 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcClient.StatementSpec params(Map<String, ?> paramMap) {
/* 173 */     this.namedParams.addValues(paramMap);
/* 174 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcClient.StatementSpec paramSource(Object namedParamObject) {
/* 180 */     Map map = (Map)namedParamObject; this
/*     */       
/* 182 */       .namedParamSource = (namedParamObject instanceof Map) ? (SqlParameterSource)new MapSqlParameterSource(map) : (SqlParameterSource)new SimplePropertySqlParameterSource(namedParamObject);
/* 183 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcClient.StatementSpec paramSource(SqlParameterSource namedParamSource) {
/* 188 */     this.namedParamSource = namedParamSource;
/* 189 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcClient.ResultQuerySpec query() {
/* 194 */     return useNamedParams() ? 
/* 195 */       new NamedParamResultQuerySpec() : 
/* 196 */       new IndexedParamResultQuerySpec();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> JdbcClient.MappedQuerySpec<T> query(Class<T> mappedClass) {
/* 202 */     RowMapper<?> rowMapper = DefaultJdbcClient.this.rowMapperCache.computeIfAbsent(mappedClass, key -> BeanUtils.isSimpleProperty(mappedClass) ? (RowMapper)new SingleColumnRowMapper(mappedClass) : (RowMapper)new SimplePropertyRowMapper(mappedClass));
/*     */ 
/*     */     
/* 205 */     return query((RowMapper)rowMapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> JdbcClient.MappedQuerySpec<T> query(RowMapper<T> rowMapper) {
/* 210 */     return useNamedParams() ? 
/* 211 */       new NamedParamMappedQuerySpec<>(rowMapper) : 
/* 212 */       new IndexedParamMappedQuerySpec<>(rowMapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public void query(RowCallbackHandler rch) {
/* 217 */     if (useNamedParams()) {
/* 218 */       DefaultJdbcClient.this.namedParamOps.query(this.sql, this.namedParamSource, rch);
/*     */     } else {
/*     */       
/* 221 */       DefaultJdbcClient.this.classicOps.query(statementCreatorForIndexedParams(), rch);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T query(ResultSetExtractor<T> rse) {
/* 229 */     T result = useNamedParams() ? (T)DefaultJdbcClient.this.namedParamOps.query(this.sql, this.namedParamSource, rse) : (T)DefaultJdbcClient.this.classicOps.query(statementCreatorForIndexedParams(), rse);
/* 230 */     Assert.state((result != null), "No result from ResultSetExtractor");
/* 231 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int update() {
/* 236 */     return useNamedParams() ? 
/* 237 */       DefaultJdbcClient.this.namedParamOps.update(this.sql, this.namedParamSource) : 
/* 238 */       DefaultJdbcClient.this.classicOps.update(statementCreatorForIndexedParams());
/*     */   }
/*     */ 
/*     */   
/*     */   public int update(KeyHolder generatedKeyHolder) {
/* 243 */     return useNamedParams() ? 
/* 244 */       DefaultJdbcClient.this.namedParamOps.update(this.sql, this.namedParamSource, generatedKeyHolder) : 
/* 245 */       DefaultJdbcClient.this.classicOps.update(statementCreatorForIndexedParamsWithKeys(null), generatedKeyHolder);
/*     */   }
/*     */ 
/*     */   
/*     */   public int update(KeyHolder generatedKeyHolder, String... keyColumnNames) {
/* 250 */     return useNamedParams() ? 
/* 251 */       DefaultJdbcClient.this.namedParamOps.update(this.sql, this.namedParamSource, generatedKeyHolder, keyColumnNames) : 
/* 252 */       DefaultJdbcClient.this.classicOps.update(statementCreatorForIndexedParamsWithKeys(keyColumnNames), generatedKeyHolder);
/*     */   }
/*     */   
/*     */   private boolean useNamedParams() {
/* 256 */     boolean hasNamedParams = (this.namedParams.hasValues() || this.namedParamSource != this.namedParams);
/* 257 */     if (hasNamedParams && !this.indexedParams.isEmpty()) {
/* 258 */       throw new IllegalStateException("Configure either named or indexed parameters, not both");
/*     */     }
/* 260 */     if (this.namedParams.hasValues() && this.namedParamSource != this.namedParams) {
/* 261 */       throw new IllegalStateException("Configure either individual named parameters or a SqlParameterSource, not both");
/*     */     }
/*     */     
/* 264 */     return hasNamedParams;
/*     */   }
/*     */   
/*     */   private PreparedStatementCreator statementCreatorForIndexedParams() {
/* 268 */     return (new PreparedStatementCreatorFactory(this.sql)).newPreparedStatementCreator(this.indexedParams);
/*     */   }
/*     */   
/*     */   private PreparedStatementCreator statementCreatorForIndexedParamsWithKeys(@Nullable String[] keyColumnNames) {
/* 272 */     PreparedStatementCreatorFactory pscf = new PreparedStatementCreatorFactory(this.sql);
/* 273 */     if (keyColumnNames != null) {
/* 274 */       pscf.setGeneratedKeysColumnNames(keyColumnNames);
/*     */     } else {
/*     */       
/* 277 */       pscf.setReturnGeneratedKeys(true);
/*     */     } 
/* 279 */     return pscf.newPreparedStatementCreator(this.indexedParams);
/*     */   }
/*     */ 
/*     */   
/*     */   private class IndexedParamResultQuerySpec
/*     */     implements JdbcClient.ResultQuerySpec
/*     */   {
/*     */     public SqlRowSet rowSet() {
/* 287 */       return this.this$1.this$0.classicOps.queryForRowSet(DefaultJdbcClient.DefaultStatementSpec.this.sql, DefaultJdbcClient.DefaultStatementSpec.this.indexedParams.toArray());
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Map<String, Object>> listOfRows() {
/* 292 */       return this.this$1.this$0.classicOps.queryForList(DefaultJdbcClient.DefaultStatementSpec.this.sql, DefaultJdbcClient.DefaultStatementSpec.this.indexedParams.toArray());
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<String, Object> singleRow() {
/* 297 */       return this.this$1.this$0.classicOps.queryForMap(DefaultJdbcClient.DefaultStatementSpec.this.sql, DefaultJdbcClient.DefaultStatementSpec.this.indexedParams.toArray());
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Object> singleColumn() {
/* 302 */       return this.this$1.this$0.classicOps.queryForList(DefaultJdbcClient.DefaultStatementSpec.this.sql, Object.class, DefaultJdbcClient.DefaultStatementSpec.this.indexedParams.toArray());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class NamedParamResultQuerySpec
/*     */     implements JdbcClient.ResultQuerySpec
/*     */   {
/*     */     public SqlRowSet rowSet() {
/* 311 */       return this.this$1.this$0.namedParamOps.queryForRowSet(DefaultJdbcClient.DefaultStatementSpec.this.sql, DefaultJdbcClient.DefaultStatementSpec.this.namedParamSource);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Map<String, Object>> listOfRows() {
/* 316 */       return this.this$1.this$0.namedParamOps.queryForList(DefaultJdbcClient.DefaultStatementSpec.this.sql, DefaultJdbcClient.DefaultStatementSpec.this.namedParamSource);
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<String, Object> singleRow() {
/* 321 */       return this.this$1.this$0.namedParamOps.queryForMap(DefaultJdbcClient.DefaultStatementSpec.this.sql, DefaultJdbcClient.DefaultStatementSpec.this.namedParamSource);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Object> singleColumn() {
/* 326 */       return this.this$1.this$0.namedParamOps.queryForList(DefaultJdbcClient.DefaultStatementSpec.this.sql, DefaultJdbcClient.DefaultStatementSpec.this.namedParamSource, Object.class);
/*     */     }
/*     */   }
/*     */   
/*     */   private class IndexedParamMappedQuerySpec<T>
/*     */     implements JdbcClient.MappedQuerySpec<T>
/*     */   {
/*     */     private final RowMapper<T> rowMapper;
/*     */     
/*     */     public IndexedParamMappedQuerySpec(RowMapper<T> rowMapper) {
/* 336 */       this.rowMapper = rowMapper;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<T> stream() {
/* 341 */       return this.this$1.this$0.classicOps.queryForStream(DefaultJdbcClient.DefaultStatementSpec.this.sql, this.rowMapper, DefaultJdbcClient.DefaultStatementSpec.this.indexedParams.toArray());
/*     */     }
/*     */ 
/*     */     
/*     */     public List<T> list() {
/* 346 */       return this.this$1.this$0.classicOps.query(DefaultJdbcClient.DefaultStatementSpec.this.sql, this.rowMapper, DefaultJdbcClient.DefaultStatementSpec.this.indexedParams.toArray());
/*     */     }
/*     */   }
/*     */   
/*     */   private class NamedParamMappedQuerySpec<T>
/*     */     implements JdbcClient.MappedQuerySpec<T>
/*     */   {
/*     */     private final RowMapper<T> rowMapper;
/*     */     
/*     */     public NamedParamMappedQuerySpec(RowMapper<T> rowMapper) {
/* 356 */       this.rowMapper = rowMapper;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<T> stream() {
/* 361 */       return this.this$1.this$0.namedParamOps.queryForStream(DefaultJdbcClient.DefaultStatementSpec.this.sql, DefaultJdbcClient.DefaultStatementSpec.this.namedParamSource, this.rowMapper);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<T> list() {
/* 366 */       return this.this$1.this$0.namedParamOps.query(DefaultJdbcClient.DefaultStatementSpec.this.sql, DefaultJdbcClient.DefaultStatementSpec.this.namedParamSource, this.rowMapper);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\simple\DefaultJdbcClient$DefaultStatementSpec.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */