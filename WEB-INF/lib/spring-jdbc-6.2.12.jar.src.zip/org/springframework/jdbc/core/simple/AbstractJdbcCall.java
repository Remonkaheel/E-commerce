/*     */ package org.springframework.jdbc.core.simple;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.CallableStatementCreator;
/*     */ import org.springframework.jdbc.core.CallableStatementCreatorFactory;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.jdbc.core.metadata.CallMetaDataContext;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJdbcCall
/*     */ {
/*  57 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   private final JdbcTemplate jdbcTemplate;
/*     */ 
/*     */   
/*  63 */   private final CallMetaDataContext callMetaDataContext = new CallMetaDataContext();
/*     */ 
/*     */   
/*  66 */   private final List<SqlParameter> declaredParameters = new ArrayList<>();
/*     */ 
/*     */   
/*  69 */   private final Map<String, RowMapper<?>> declaredRowMappers = new LinkedHashMap<>();
/*     */ 
/*     */   
/*  72 */   private final Lock compilationLock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean compiled;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String callString;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private CallableStatementCreatorFactory callableStatementFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractJdbcCall(DataSource dataSource) {
/*  97 */     this.jdbcTemplate = new JdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractJdbcCall(JdbcTemplate jdbcTemplate) {
/* 105 */     Assert.notNull(jdbcTemplate, "JdbcTemplate must not be null");
/* 106 */     this.jdbcTemplate = jdbcTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcTemplate getJdbcTemplate() {
/* 114 */     return this.jdbcTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProcedureName(@Nullable String procedureName) {
/* 121 */     this.callMetaDataContext.setProcedureName(procedureName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getProcedureName() {
/* 129 */     return this.callMetaDataContext.getProcedureName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInParameterNames(Set<String> inParameterNames) {
/* 136 */     this.callMetaDataContext.setLimitedInParameterNames(inParameterNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getInParameterNames() {
/* 143 */     return this.callMetaDataContext.getLimitedInParameterNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalogName(@Nullable String catalogName) {
/* 150 */     this.callMetaDataContext.setCatalogName(catalogName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getCatalogName() {
/* 158 */     return this.callMetaDataContext.getCatalogName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchemaName(@Nullable String schemaName) {
/* 165 */     this.callMetaDataContext.setSchemaName(schemaName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSchemaName() {
/* 173 */     return this.callMetaDataContext.getSchemaName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFunction(boolean function) {
/* 181 */     this.callMetaDataContext.setFunction(function);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFunction() {
/* 188 */     return this.callMetaDataContext.isFunction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReturnValueRequired(boolean returnValueRequired) {
/* 196 */     this.callMetaDataContext.setReturnValueRequired(returnValueRequired);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReturnValueRequired() {
/* 203 */     return this.callMetaDataContext.isReturnValueRequired();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamedBinding(boolean namedBinding) {
/* 212 */     this.callMetaDataContext.setNamedBinding(namedBinding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNamedBinding() {
/* 220 */     return this.callMetaDataContext.isNamedBinding();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccessCallParameterMetaData(boolean accessCallParameterMetaData) {
/* 228 */     this.callMetaDataContext.setAccessCallParameterMetaData(accessCallParameterMetaData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getCallString() {
/* 236 */     return this.callString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CallableStatementCreatorFactory getCallableStatementFactory() {
/* 243 */     Assert.state((this.callableStatementFactory != null), "No CallableStatementCreatorFactory available");
/* 244 */     return this.callableStatementFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDeclaredParameter(SqlParameter parameter) {
/* 257 */     Assert.notNull(parameter, "The supplied parameter must not be null");
/* 258 */     if (!StringUtils.hasText(parameter.getName())) {
/* 259 */       throw new InvalidDataAccessApiUsageException("You must specify a parameter name when declaring parameters for \"" + 
/* 260 */           getProcedureName() + "\"");
/*     */     }
/* 262 */     this.declaredParameters.add(parameter);
/* 263 */     if (this.logger.isDebugEnabled()) {
/* 264 */       this.logger.debug("Added declared parameter for [" + getProcedureName() + "]: " + parameter.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDeclaredRowMapper(String parameterName, RowMapper<?> rowMapper) {
/* 274 */     this.declaredRowMappers.put(parameterName, rowMapper);
/* 275 */     if (this.logger.isDebugEnabled()) {
/* 276 */       this.logger.debug("Added row mapper for [" + getProcedureName() + "]: " + parameterName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void compile() throws InvalidDataAccessApiUsageException {
/* 293 */     this.compilationLock.lock();
/*     */     try {
/* 295 */       if (!isCompiled()) {
/* 296 */         if (getProcedureName() == null) {
/* 297 */           throw new InvalidDataAccessApiUsageException("Procedure or Function name is required");
/*     */         }
/*     */         try {
/* 300 */           this.jdbcTemplate.afterPropertiesSet();
/*     */         }
/* 302 */         catch (IllegalArgumentException ex) {
/* 303 */           throw new InvalidDataAccessApiUsageException(ex.getMessage());
/*     */         } 
/* 305 */         compileInternal();
/* 306 */         this.compiled = true;
/* 307 */         if (this.logger.isDebugEnabled()) {
/* 308 */           this.logger.debug("SqlCall for " + (isFunction() ? "function" : "procedure") + " [" + 
/* 309 */               getProcedureName() + "] compiled");
/*     */         }
/*     */       } 
/*     */     } finally {
/*     */       
/* 314 */       this.compilationLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void compileInternal() {
/* 324 */     DataSource dataSource = getJdbcTemplate().getDataSource();
/* 325 */     Assert.state((dataSource != null), "No DataSource set");
/* 326 */     this.callMetaDataContext.initializeMetaData(dataSource);
/*     */ 
/*     */     
/* 329 */     this.declaredRowMappers.forEach((key, value) -> this.declaredParameters.add(this.callMetaDataContext.createReturnResultSetParameter(key, value)));
/* 330 */     this.callMetaDataContext.processParameters(this.declaredParameters);
/*     */     
/* 332 */     this.callString = this.callMetaDataContext.createCallString();
/* 333 */     if (this.logger.isDebugEnabled()) {
/* 334 */       this.logger.debug("Compiled stored procedure. Call string is [" + this.callString + "]");
/*     */     }
/*     */     
/* 337 */     this
/* 338 */       .callableStatementFactory = new CallableStatementCreatorFactory(this.callString, this.callMetaDataContext.getCallParameters());
/*     */     
/* 340 */     onCompileInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onCompileInternal() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompiled() {
/* 355 */     return this.compiled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkCompiled() {
/* 364 */     if (!isCompiled()) {
/* 365 */       this.logger.debug("JdbcCall call not compiled before execution - invoking compile");
/* 366 */       compile();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, Object> doExecute(SqlParameterSource parameterSource) {
/* 381 */     checkCompiled();
/* 382 */     Map<String, Object> params = matchInParameterValuesWithCallParameters(parameterSource);
/* 383 */     return executeCallInternal(params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, Object> doExecute(Object... args) {
/* 393 */     checkCompiled();
/* 394 */     Map<String, ?> params = matchInParameterValuesWithCallParameters(args);
/* 395 */     return executeCallInternal(params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, Object> doExecute(Map<String, ?> args) {
/* 404 */     checkCompiled();
/* 405 */     Map<String, ?> params = matchInParameterValuesWithCallParameters(args);
/* 406 */     return executeCallInternal(params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> executeCallInternal(Map<String, ?> args) {
/* 413 */     CallableStatementCreator csc = getCallableStatementFactory().newCallableStatementCreator(args);
/* 414 */     if (this.logger.isDebugEnabled()) {
/* 415 */       this.logger.debug("The following parameters are used for call " + getCallString() + " with " + String.valueOf(args));
/* 416 */       int i = 1;
/* 417 */       for (SqlParameter param : getCallParameters()) {
/* 418 */         this.logger.debug("" + i + ": " + i + ", SQL type " + param.getName() + ", type name " + param.getSqlType() + ", parameter class [" + param
/* 419 */             .getTypeName() + "]");
/* 420 */         i++;
/*     */       } 
/*     */     } 
/* 423 */     return getJdbcTemplate().call(csc, getCallParameters());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getScalarOutParameterName() {
/* 433 */     return this.callMetaDataContext.getScalarOutParameterName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<SqlParameter> getCallParameters() {
/* 441 */     return this.callMetaDataContext.getCallParameters();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, Object> matchInParameterValuesWithCallParameters(SqlParameterSource parameterSource) {
/* 451 */     return this.callMetaDataContext.matchInParameterValuesWithCallParameters(parameterSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, ?> matchInParameterValuesWithCallParameters(Object[] args) {
/* 461 */     return this.callMetaDataContext.matchInParameterValuesWithCallParameters(args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, ?> matchInParameterValuesWithCallParameters(Map<String, ?> args) {
/* 471 */     return this.callMetaDataContext.matchInParameterValuesWithCallParameters(args);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\simple\AbstractJdbcCall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */