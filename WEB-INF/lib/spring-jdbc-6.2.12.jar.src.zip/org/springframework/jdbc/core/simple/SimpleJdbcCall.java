/*     */ package org.springframework.jdbc.core.simple;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleJdbcCall
/*     */   extends AbstractJdbcCall
/*     */   implements SimpleJdbcCallOperations
/*     */ {
/*     */   public SimpleJdbcCall(DataSource dataSource) {
/*  72 */     super(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleJdbcCall(JdbcTemplate jdbcTemplate) {
/*  81 */     super(jdbcTemplate);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleJdbcCall withProcedureName(String procedureName) {
/*  87 */     setProcedureName(procedureName);
/*  88 */     setFunction(false);
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcCall withFunctionName(String functionName) {
/*  94 */     setProcedureName(functionName);
/*  95 */     setFunction(true);
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcCall withSchemaName(String schemaName) {
/* 101 */     setSchemaName(schemaName);
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcCall withCatalogName(String catalogName) {
/* 107 */     setCatalogName(catalogName);
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcCall withReturnValue() {
/* 113 */     setReturnValueRequired(true);
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcCall declareParameters(SqlParameter... sqlParameters) {
/* 119 */     for (SqlParameter sqlParameter : sqlParameters) {
/* 120 */       if (sqlParameter != null) {
/* 121 */         addDeclaredParameter(sqlParameter);
/*     */       }
/*     */     } 
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcCall useInParameterNames(String... inParameterNames) {
/* 129 */     setInParameterNames(new LinkedHashSet<>(Arrays.asList(inParameterNames)));
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcCall returningResultSet(String parameterName, RowMapper<?> rowMapper) {
/* 135 */     addDeclaredRowMapper(parameterName, rowMapper);
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcCall withoutProcedureColumnMetaDataAccess() {
/* 141 */     setAccessCallParameterMetaData(false);
/* 142 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcCall withNamedBinding() {
/* 147 */     setNamedBinding(true);
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T executeFunction(Class<T> returnType, Object... args) {
/* 155 */     return (T)doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T executeFunction(Class<T> returnType, Map<String, ?> args) {
/* 162 */     return (T)doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T executeFunction(Class<T> returnType, SqlParameterSource args) {
/* 169 */     return (T)doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T executeObject(Class<T> returnType, Object... args) {
/* 176 */     return (T)doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T executeObject(Class<T> returnType, Map<String, ?> args) {
/* 183 */     return (T)doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T executeObject(Class<T> returnType, SqlParameterSource args) {
/* 190 */     return (T)doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> execute(Object... args) {
/* 195 */     return doExecute(args);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> execute(Map<String, ?> args) {
/* 200 */     return doExecute(args);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> execute(SqlParameterSource parameterSource) {
/* 205 */     return doExecute(parameterSource);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\simple\SimpleJdbcCall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */