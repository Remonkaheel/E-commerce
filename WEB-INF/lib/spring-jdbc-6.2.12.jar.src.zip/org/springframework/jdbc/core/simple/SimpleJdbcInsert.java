/*     */ package org.springframework.jdbc.core.simple;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.support.KeyHolder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleJdbcInsert
/*     */   extends AbstractJdbcInsert
/*     */   implements SimpleJdbcInsertOperations
/*     */ {
/*     */   public SimpleJdbcInsert(DataSource dataSource) {
/*  62 */     super(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleJdbcInsert(JdbcTemplate jdbcTemplate) {
/*  71 */     super(jdbcTemplate);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleJdbcInsert withTableName(String tableName) {
/*  77 */     setTableName(tableName);
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcInsert withSchemaName(String schemaName) {
/*  83 */     setSchemaName(schemaName);
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcInsert withCatalogName(String catalogName) {
/*  89 */     setCatalogName(catalogName);
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcInsert usingColumns(String... columnNames) {
/*  95 */     setColumnNames(Arrays.asList(columnNames));
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcInsert usingGeneratedKeyColumns(String... columnNames) {
/* 101 */     setGeneratedKeyNames(columnNames);
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcInsert usingQuotedIdentifiers() {
/* 107 */     setQuoteIdentifiers(true);
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcInsert withoutTableColumnMetaDataAccess() {
/* 113 */     setAccessTableColumnMetaData(false);
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleJdbcInsert includeSynonymsForTableColumnMetaData() {
/* 119 */     setOverrideIncludeSynonymsDefault(true);
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public int execute(Map<String, ?> args) {
/* 125 */     return doExecute(args);
/*     */   }
/*     */ 
/*     */   
/*     */   public int execute(SqlParameterSource parameterSource) {
/* 130 */     return doExecute(parameterSource);
/*     */   }
/*     */ 
/*     */   
/*     */   public Number executeAndReturnKey(Map<String, ?> args) {
/* 135 */     return doExecuteAndReturnKey(args);
/*     */   }
/*     */ 
/*     */   
/*     */   public Number executeAndReturnKey(SqlParameterSource parameterSource) {
/* 140 */     return doExecuteAndReturnKey(parameterSource);
/*     */   }
/*     */ 
/*     */   
/*     */   public KeyHolder executeAndReturnKeyHolder(Map<String, ?> args) {
/* 145 */     return doExecuteAndReturnKeyHolder(args);
/*     */   }
/*     */ 
/*     */   
/*     */   public KeyHolder executeAndReturnKeyHolder(SqlParameterSource parameterSource) {
/* 150 */     return doExecuteAndReturnKeyHolder(parameterSource);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] executeBatch(Map<String, ?>... batch) {
/* 156 */     return doExecuteBatch(batch);
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] executeBatch(SqlParameterSource... batch) {
/* 161 */     return doExecuteBatch(batch);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\simple\SimpleJdbcInsert.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */