/*     */ package org.springframework.jdbc.core.simple;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataIntegrityViolationException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*     */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.StatementCreatorUtils;
/*     */ import org.springframework.jdbc.core.metadata.TableMetaDataContext;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.support.GeneratedKeyHolder;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.jdbc.support.KeyHolder;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJdbcInsert
/*     */ {
/*  67 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   private final JdbcTemplate jdbcTemplate;
/*     */ 
/*     */   
/*  73 */   private final TableMetaDataContext tableMetaDataContext = new TableMetaDataContext();
/*     */ 
/*     */   
/*  76 */   private final List<String> declaredColumns = new ArrayList<>();
/*     */ 
/*     */   
/*  79 */   private String[] generatedKeyNames = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean compiled;
/*     */ 
/*     */ 
/*     */   
/*  88 */   private String insertString = "";
/*     */ 
/*     */   
/*  91 */   private int[] insertTypes = new int[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractJdbcInsert(DataSource dataSource) {
/*  99 */     this.jdbcTemplate = new JdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractJdbcInsert(JdbcTemplate jdbcTemplate) {
/* 107 */     Assert.notNull(jdbcTemplate, "JdbcTemplate must not be null");
/* 108 */     this.jdbcTemplate = jdbcTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcTemplate getJdbcTemplate() {
/* 120 */     return this.jdbcTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTableName(@Nullable String tableName) {
/* 127 */     checkIfConfigurationModificationIsAllowed();
/* 128 */     this.tableMetaDataContext.setTableName(tableName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getTableName() {
/* 136 */     return this.tableMetaDataContext.getTableName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchemaName(@Nullable String schemaName) {
/* 143 */     checkIfConfigurationModificationIsAllowed();
/* 144 */     this.tableMetaDataContext.setSchemaName(schemaName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSchemaName() {
/* 152 */     return this.tableMetaDataContext.getSchemaName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalogName(@Nullable String catalogName) {
/* 159 */     checkIfConfigurationModificationIsAllowed();
/* 160 */     this.tableMetaDataContext.setCatalogName(catalogName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getCatalogName() {
/* 168 */     return this.tableMetaDataContext.getCatalogName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnNames(List<String> columnNames) {
/* 175 */     checkIfConfigurationModificationIsAllowed();
/* 176 */     this.declaredColumns.clear();
/* 177 */     this.declaredColumns.addAll(columnNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getColumnNames() {
/* 184 */     return Collections.unmodifiableList(this.declaredColumns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGeneratedKeyName(String generatedKeyName) {
/* 191 */     checkIfConfigurationModificationIsAllowed();
/* 192 */     this.generatedKeyNames = new String[] { generatedKeyName };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGeneratedKeyNames(String... generatedKeyNames) {
/* 199 */     checkIfConfigurationModificationIsAllowed();
/* 200 */     this.generatedKeyNames = generatedKeyNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getGeneratedKeyNames() {
/* 207 */     return this.generatedKeyNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccessTableColumnMetaData(boolean accessTableColumnMetaData) {
/* 215 */     this.tableMetaDataContext.setAccessTableColumnMetaData(accessTableColumnMetaData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOverrideIncludeSynonymsDefault(boolean override) {
/* 223 */     this.tableMetaDataContext.setOverrideIncludeSynonymsDefault(override);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInsertString() {
/* 230 */     return this.insertString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getInsertTypes() {
/* 237 */     return this.insertTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQuoteIdentifiers(boolean quoteIdentifiers) {
/* 250 */     this.tableMetaDataContext.setQuoteIdentifiers(quoteIdentifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isQuoteIdentifiers() {
/* 259 */     return this.tableMetaDataContext.isQuoteIdentifiers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void compile() throws InvalidDataAccessApiUsageException {
/* 275 */     if (!isCompiled()) {
/* 276 */       if (getTableName() == null) {
/* 277 */         throw new InvalidDataAccessApiUsageException("Table name is required");
/*     */       }
/* 279 */       if (isQuoteIdentifiers() && this.declaredColumns.isEmpty()) {
/* 280 */         throw new InvalidDataAccessApiUsageException("Explicit column names must be provided when using quoted identifiers");
/*     */       }
/*     */       
/*     */       try {
/* 284 */         this.jdbcTemplate.afterPropertiesSet();
/*     */       }
/* 286 */       catch (IllegalArgumentException ex) {
/* 287 */         throw new InvalidDataAccessApiUsageException(ex.getMessage());
/*     */       } 
/* 289 */       compileInternal();
/* 290 */       this.compiled = true;
/* 291 */       if (this.logger.isDebugEnabled()) {
/* 292 */         this.logger.debug("JdbcInsert for table [" + getTableName() + "] compiled");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void compileInternal() {
/* 303 */     DataSource dataSource = getJdbcTemplate().getDataSource();
/* 304 */     Assert.state((dataSource != null), "No DataSource set");
/* 305 */     this.tableMetaDataContext.processMetaData(dataSource, getColumnNames(), getGeneratedKeyNames());
/* 306 */     this.insertString = this.tableMetaDataContext.createInsertString(getGeneratedKeyNames());
/* 307 */     this.insertTypes = this.tableMetaDataContext.createInsertTypes();
/* 308 */     if (this.logger.isDebugEnabled()) {
/* 309 */       this.logger.debug("Compiled insert object: insert string is [" + this.insertString + "]");
/*     */     }
/* 311 */     onCompileInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onCompileInternal() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompiled() {
/* 326 */     return this.compiled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkCompiled() {
/* 335 */     if (!isCompiled()) {
/* 336 */       this.logger.debug("JdbcInsert not compiled before execution - invoking compile");
/* 337 */       compile();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkIfConfigurationModificationIsAllowed() {
/* 346 */     if (isCompiled()) {
/* 347 */       throw new InvalidDataAccessApiUsageException("Configuration cannot be altered once the class has been compiled or used");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int doExecute(Map<String, ?> args) {
/* 363 */     checkCompiled();
/* 364 */     List<Object> values = matchInParameterValuesWithInsertColumns(args);
/* 365 */     return executeInsertInternal(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int doExecute(SqlParameterSource parameterSource) {
/* 374 */     checkCompiled();
/* 375 */     List<Object> values = matchInParameterValuesWithInsertColumns(parameterSource);
/* 376 */     return executeInsertInternal(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int executeInsertInternal(List<?> values) {
/* 383 */     if (this.logger.isDebugEnabled()) {
/* 384 */       this.logger.debug("The following parameters are used for insert " + getInsertString() + " with: " + String.valueOf(values));
/*     */     }
/* 386 */     return getJdbcTemplate().update(getInsertString(), values.toArray(), getInsertTypes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Number doExecuteAndReturnKey(Map<String, ?> args) {
/* 396 */     checkCompiled();
/* 397 */     List<Object> values = matchInParameterValuesWithInsertColumns(args);
/* 398 */     return executeInsertAndReturnKeyInternal(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Number doExecuteAndReturnKey(SqlParameterSource parameterSource) {
/* 408 */     checkCompiled();
/* 409 */     List<Object> values = matchInParameterValuesWithInsertColumns(parameterSource);
/* 410 */     return executeInsertAndReturnKeyInternal(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected KeyHolder doExecuteAndReturnKeyHolder(Map<String, ?> args) {
/* 420 */     checkCompiled();
/* 421 */     List<Object> values = matchInParameterValuesWithInsertColumns(args);
/* 422 */     return executeInsertAndReturnKeyHolderInternal(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected KeyHolder doExecuteAndReturnKeyHolder(SqlParameterSource parameterSource) {
/* 432 */     checkCompiled();
/* 433 */     List<Object> values = matchInParameterValuesWithInsertColumns(parameterSource);
/* 434 */     return executeInsertAndReturnKeyHolderInternal(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Number executeInsertAndReturnKeyInternal(List<?> values) {
/* 441 */     KeyHolder kh = executeInsertAndReturnKeyHolderInternal(values);
/* 442 */     if (kh.getKey() != null) {
/* 443 */       return kh.getKey();
/*     */     }
/*     */     
/* 446 */     throw new DataIntegrityViolationException("Unable to retrieve the generated key for the insert: " + 
/* 447 */         getInsertString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private KeyHolder executeInsertAndReturnKeyHolderInternal(List<?> values) {
/* 455 */     if (this.logger.isDebugEnabled()) {
/* 456 */       this.logger.debug("The following parameters are used for call " + getInsertString() + " with: " + String.valueOf(values));
/*     */     }
/* 458 */     GeneratedKeyHolder generatedKeyHolder = new GeneratedKeyHolder();
/*     */     
/* 460 */     if (this.tableMetaDataContext.isGetGeneratedKeysSupported()) {
/* 461 */       getJdbcTemplate().update(con -> { PreparedStatement ps = prepareStatementForGeneratedKeys(con); setParameterValues(ps, values, getInsertTypes()); return ps; }(KeyHolder)generatedKeyHolder);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 471 */       if (!this.tableMetaDataContext.isGetGeneratedKeysSimulated()) {
/* 472 */         throw new InvalidDataAccessResourceUsageException("The getGeneratedKeys feature is not supported by this database");
/*     */       }
/*     */       
/* 475 */       if ((getGeneratedKeyNames()).length < 1) {
/* 476 */         throw new InvalidDataAccessApiUsageException("Generated Key Name(s) not specified. Using the generated keys features requires specifying the name(s) of the generated column(s)");
/*     */       }
/*     */       
/* 479 */       if ((getGeneratedKeyNames()).length > 1) {
/* 480 */         throw new InvalidDataAccessApiUsageException("Current database only supports retrieving the key for a single column. There are " + (
/*     */             
/* 482 */             getGeneratedKeyNames()).length + " columns specified: " + Arrays.toString(getGeneratedKeyNames()));
/*     */       }
/*     */       
/* 485 */       Assert.state((getTableName() != null), "No table name set");
/* 486 */       String keyQuery = this.tableMetaDataContext.getSimpleQueryForGetGeneratedKey(
/* 487 */           getTableName(), getGeneratedKeyNames()[0]);
/* 488 */       Assert.state((keyQuery != null), "Query for simulating get generated keys must not be null");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 494 */       if (keyQuery.toUpperCase(Locale.ROOT).startsWith("RETURNING")) {
/* 495 */         Long key = (Long)getJdbcTemplate().queryForObject(
/* 496 */             getInsertString() + " " + getInsertString(), Long.class, values.toArray());
/* 497 */         Map<String, Object> keys = new HashMap<>(2);
/* 498 */         keys.put(getGeneratedKeyNames()[0], key);
/* 499 */         generatedKeyHolder.getKeyList().add(keys);
/*     */       } else {
/*     */         
/* 502 */         getJdbcTemplate().execute(con -> {
/*     */               PreparedStatement ps = null;
/*     */               
/*     */               try {
/*     */                 ps = con.prepareStatement(getInsertString());
/*     */                 
/*     */                 setParameterValues(ps, values, getInsertTypes());
/*     */                 
/*     */                 ps.executeUpdate();
/*     */               } finally {
/*     */                 JdbcUtils.closeStatement(ps);
/*     */               } 
/*     */               
/*     */               Statement keyStmt = null;
/*     */               
/*     */               ResultSet rs = null;
/*     */               try {
/*     */                 keyStmt = con.createStatement();
/*     */                 rs = keyStmt.executeQuery(keyQuery);
/*     */                 if (rs.next()) {
/*     */                   long key = rs.getLong(1);
/*     */                   Map<String, Object> keys = new HashMap<>(2);
/*     */                   keys.put(getGeneratedKeyNames()[0], Long.valueOf(key));
/*     */                   keyHolder.getKeyList().add(keys);
/*     */                 } 
/*     */               } finally {
/*     */                 JdbcUtils.closeResultSet(rs);
/*     */                 JdbcUtils.closeStatement(keyStmt);
/*     */               } 
/*     */               return null;
/*     */             });
/*     */       } 
/*     */     } 
/* 535 */     return (KeyHolder)generatedKeyHolder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PreparedStatement prepareStatementForGeneratedKeys(Connection con) throws SQLException {
/*     */     PreparedStatement ps;
/* 544 */     if ((getGeneratedKeyNames()).length < 1) {
/* 545 */       throw new InvalidDataAccessApiUsageException("Generated Key Name(s) not specified. Using the generated keys features requires specifying the name(s) of the generated column(s).");
/*     */     }
/*     */ 
/*     */     
/* 549 */     if (this.tableMetaDataContext.isGeneratedKeysColumnNameArraySupported()) {
/* 550 */       if (this.logger.isDebugEnabled()) {
/* 551 */         this.logger.debug("Using generated keys support with array of column names.");
/*     */       }
/* 553 */       ps = con.prepareStatement(getInsertString(), getGeneratedKeyNames());
/*     */     } else {
/*     */       
/* 556 */       if (this.logger.isDebugEnabled()) {
/* 557 */         this.logger.debug("Using generated keys support with Statement.RETURN_GENERATED_KEYS.");
/*     */       }
/* 559 */       ps = con.prepareStatement(getInsertString(), 1);
/*     */     } 
/* 561 */     return ps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int[] doExecuteBatch(Map<String, ?>... batch) {
/* 571 */     checkCompiled();
/* 572 */     List<List<Object>> batchValues = new ArrayList<>(batch.length);
/* 573 */     for (Map<String, ?> args : batch) {
/* 574 */       batchValues.add(matchInParameterValuesWithInsertColumns(args));
/*     */     }
/* 576 */     return executeBatchInternal(batchValues);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int[] doExecuteBatch(SqlParameterSource... batch) {
/* 586 */     checkCompiled();
/* 587 */     List<List<Object>> batchValues = new ArrayList<>(batch.length);
/* 588 */     for (SqlParameterSource parameterSource : batch) {
/* 589 */       batchValues.add(matchInParameterValuesWithInsertColumns(parameterSource));
/*     */     }
/* 591 */     return executeBatchInternal(batchValues);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] executeBatchInternal(final List<List<Object>> batchValues) {
/* 598 */     if (this.logger.isDebugEnabled()) {
/* 599 */       this.logger.debug("Executing statement " + getInsertString() + " with batch of size: " + batchValues.size());
/*     */     }
/* 601 */     return getJdbcTemplate().batchUpdate(getInsertString(), new BatchPreparedStatementSetter()
/*     */         {
/*     */           public void setValues(PreparedStatement ps, int i) throws SQLException
/*     */           {
/* 605 */             AbstractJdbcInsert.this.setParameterValues(ps, batchValues.get(i), AbstractJdbcInsert.this.getInsertTypes());
/*     */           }
/*     */           
/*     */           public int getBatchSize() {
/* 609 */             return batchValues.size();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setParameterValues(PreparedStatement preparedStatement, List<?> values, @Nullable int... columnTypes) throws SQLException {
/* 622 */     int colIndex = 0;
/* 623 */     for (Object value : values) {
/* 624 */       colIndex++;
/* 625 */       if (columnTypes == null || colIndex > columnTypes.length) {
/* 626 */         StatementCreatorUtils.setParameterValue(preparedStatement, colIndex, -2147483648, value);
/*     */         continue;
/*     */       } 
/* 629 */       StatementCreatorUtils.setParameterValue(preparedStatement, colIndex, columnTypes[colIndex - 1], value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Object> matchInParameterValuesWithInsertColumns(SqlParameterSource parameterSource) {
/* 641 */     return this.tableMetaDataContext.matchInParameterValuesWithInsertColumns(parameterSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Object> matchInParameterValuesWithInsertColumns(Map<String, ?> args) {
/* 651 */     return this.tableMetaDataContext.matchInParameterValuesWithInsertColumns(args);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\simple\AbstractJdbcInsert.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */