/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ import java.sql.BatchUpdateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AggregatedBatchUpdateException
/*    */   extends BatchUpdateException
/*    */ {
/*    */   private final int[][] successfulUpdateCounts;
/*    */   private final BatchUpdateException originalException;
/*    */   
/*    */   public AggregatedBatchUpdateException(int[][] successfulUpdateCounts, BatchUpdateException original) {
/* 42 */     super(original.getMessage(), original.getSQLState(), original.getErrorCode(), original
/* 43 */         .getUpdateCounts(), original.getCause());
/* 44 */     this.successfulUpdateCounts = successfulUpdateCounts;
/* 45 */     this.originalException = original;
/*    */     
/* 47 */     setNextException(original.getNextException());
/* 48 */     for (Throwable suppressed : original.getSuppressed()) {
/* 49 */       addSuppressed(suppressed);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int[][] getSuccessfulUpdateCounts() {
/* 62 */     return this.successfulUpdateCounts;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BatchUpdateException getOriginalException() {
/* 70 */     return this.originalException;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\AggregatedBatchUpdateException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */