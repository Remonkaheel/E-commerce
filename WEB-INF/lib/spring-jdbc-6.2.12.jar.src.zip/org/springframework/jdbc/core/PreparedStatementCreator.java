package org.springframework.jdbc.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@FunctionalInterface
public interface PreparedStatementCreator {
  PreparedStatement createPreparedStatement(Connection paramConnection) throws SQLException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\PreparedStatementCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */