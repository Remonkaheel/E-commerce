/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.functions.Function2;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000B\n\002\b\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\021\n\002\020\000\n\000\n\002\030\002\n\002\030\002\n\000\n\002\020\002\n\000\n\002\020 \n\002\030\002\n\002\020\b\n\002\b\004\n\002\020\025\n\002\b\007\032O\020\000\032\002H\001\"\006\b\000\020\001\030\001*\0020\0022\006\020\003\032\0020\0042\022\020\005\032\n\022\006\b\001\022\0020\0070\006\"\0020\0072\024\b\004\020\b\032\016\022\004\022\0020\n\022\004\022\002H\0010\tH\bø\001\000¢\006\002\020\013\032?\020\000\032\0020\f*\0020\0022\006\020\003\032\0020\0042\022\020\005\032\n\022\006\b\001\022\0020\0070\006\"\0020\0072\022\020\b\032\016\022\004\022\0020\n\022\004\022\0020\f0\t¢\006\002\020\r\032Q\020\000\032\b\022\004\022\002H\0010\016\"\004\b\000\020\001*\0020\0022\006\020\003\032\0020\0042\022\020\005\032\n\022\006\b\001\022\0020\0070\006\"\0020\0072\030\020\b\032\024\022\004\022\0020\n\022\004\022\0020\020\022\004\022\002H\0010\017¢\006\002\020\021\032#\020\022\032\b\022\004\022\002H\0010\016\"\006\b\000\020\001\030\001*\0020\0022\006\020\003\032\0020\004H\b\0328\020\022\032\b\022\004\022\002H\0010\016\"\006\b\000\020\001\030\001*\0020\0022\006\020\003\032\0020\0042\016\020\005\032\n\022\006\b\001\022\0020\0070\006H\b¢\006\002\020\023\032@\020\022\032\b\022\004\022\002H\0010\016\"\006\b\000\020\001\030\001*\0020\0022\006\020\003\032\0020\0042\016\020\005\032\n\022\006\b\001\022\0020\0070\0062\006\020\024\032\0020\025H\b¢\006\002\020\026\032\"\020\027\032\002H\001\"\006\b\000\020\001\030\001*\0020\0022\006\020\003\032\0020\004H\b¢\006\002\020\030\0324\020\027\032\004\030\001H\001\"\006\b\000\020\001\030\001*\0020\0022\006\020\003\032\0020\0042\016\020\005\032\n\022\006\b\001\022\0020\0070\006H\b¢\006\002\020\031\032U\020\027\032\002H\001\"\006\b\000\020\001\030\001*\0020\0022\006\020\003\032\0020\0042\022\020\005\032\n\022\006\b\001\022\0020\0070\006\"\0020\0072\032\b\004\020\b\032\024\022\004\022\0020\n\022\004\022\0020\020\022\004\022\002H\0010\017H\bø\001\000¢\006\002\020\032\032<\020\027\032\004\030\001H\001\"\006\b\000\020\001\030\001*\0020\0022\006\020\003\032\0020\0042\016\020\005\032\n\022\006\b\001\022\0020\0070\0062\006\020\024\032\0020\025H\b¢\006\002\020\033\002\007\n\005\b20\001¨\006\034"}, d2 = {"query", "T", "Lorg/springframework/jdbc/core/JdbcOperations;", "sql", "", "args", "", "", "function", "Lkotlin/Function1;", "Ljava/sql/ResultSet;", "(Lorg/springframework/jdbc/core/JdbcOperations;Ljava/lang/String;[Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "", "(Lorg/springframework/jdbc/core/JdbcOperations;Ljava/lang/String;[Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)V", "", "Lkotlin/Function2;", "", "(Lorg/springframework/jdbc/core/JdbcOperations;Ljava/lang/String;[Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Ljava/util/List;", "queryForList", "(Lorg/springframework/jdbc/core/JdbcOperations;Ljava/lang/String;[Ljava/lang/Object;)Ljava/util/List;", "argTypes", "", "(Lorg/springframework/jdbc/core/JdbcOperations;Ljava/lang/String;[Ljava/lang/Object;[I)Ljava/util/List;", "queryForObject", "(Lorg/springframework/jdbc/core/JdbcOperations;Ljava/lang/String;)Ljava/lang/Object;", "(Lorg/springframework/jdbc/core/JdbcOperations;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", "(Lorg/springframework/jdbc/core/JdbcOperations;Ljava/lang/String;[Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Ljava/lang/Object;", "(Lorg/springframework/jdbc/core/JdbcOperations;Ljava/lang/String;[Ljava/lang/Object;[I)Ljava/lang/Object;", "spring-jdbc"})
/*     */ public final class JdbcOperationsExtensionsKt
/*     */ {
/*     */   @Metadata(mv = {1, 7, 0}, k = 3, xi = 176, d1 = {"\000\024\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\020\000\032\004\030\001H\001\"\006\b\000\020\001\030\0012\016\020\002\032\n \004*\004\030\0010\0030\0032\006\020\005\032\0020\006H\n¢\006\004\b\007\020\b"}, d2 = {"<anonymous>", "T", "resultSet", "Ljava/sql/ResultSet;", "kotlin.jvm.PlatformType", "i", "", "mapRow", "(Ljava/sql/ResultSet;I)Ljava/lang/Object;"})
/*     */   @SourceDebugExtension({"SMAP\nJdbcOperationsExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 JdbcOperationsExtensions.kt\norg/springframework/jdbc/core/JdbcOperationsExtensionsKt$queryForObject$1\n*L\n1#1,127:1\n*E\n"})
/*     */   public static final class JdbcOperationsExtensionsKt$queryForObject$1<T>
/*     */     implements RowMapper
/*     */   {
/*     */     public JdbcOperationsExtensionsKt$queryForObject$1(Function2<ResultSet, Integer, T> $function) {}
/*     */     
/*     */     @Nullable
/*     */     public final T mapRow(ResultSet resultSet, int i) {
/*  38 */       Intrinsics.checkNotNullExpressionValue(resultSet, "resultSet"); return (T)this.$function.invoke(resultSet, Integer.valueOf(i));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Metadata(mv = {1, 7, 0}, k = 3, xi = 176, d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\003\020\000\032\004\030\001H\001\"\006\b\000\020\001\030\0012\016\020\002\032\n \004*\004\030\0010\0030\003H\n¢\006\004\b\005\020\006"}, d2 = {"<anonymous>", "T", "it", "Ljava/sql/ResultSet;", "kotlin.jvm.PlatformType", "extractData", "(Ljava/sql/ResultSet;)Ljava/lang/Object;"})
/*     */   @SourceDebugExtension({"SMAP\nJdbcOperationsExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 JdbcOperationsExtensions.kt\norg/springframework/jdbc/core/JdbcOperationsExtensionsKt$query$1\n*L\n1#1,127:1\n*E\n"})
/*     */   public static final class JdbcOperationsExtensionsKt$query$1<T>
/*     */     implements ResultSetExtractor
/*     */   {
/*     */     public JdbcOperationsExtensionsKt$query$1(Function1<ResultSet, T> $function) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public final T extractData(ResultSet it) {
/* 106 */       Intrinsics.checkNotNullExpressionValue(it, "it"); return (T)this.$function.invoke(it);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void query(@NotNull JdbcOperations $this$query, @NotNull String sql, @NotNull Object[] args, @NotNull Function1 function) {
/* 116 */     Intrinsics.checkNotNullParameter($this$query, "<this>"); Intrinsics.checkNotNullParameter(sql, "sql"); Intrinsics.checkNotNullParameter(args, "args"); Intrinsics.checkNotNullParameter(function, "function"); $this$query.query(sql, function::query$lambda$0, Arrays.copyOf(args, args.length)); } private static final void query$lambda$0(Function1 $function, ResultSet it) { Intrinsics.checkNotNullParameter($function, "$function"); Intrinsics.checkNotNullExpressionValue(it, "it"); $function.invoke(it); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static final <T> List<T> query(@NotNull JdbcOperations $this$query, @NotNull String sql, @NotNull Object[] args, @NotNull Function2 function) {
/* 126 */     Intrinsics.checkNotNullParameter($this$query, "<this>"); Intrinsics.checkNotNullParameter(sql, "sql"); Intrinsics.checkNotNullParameter(args, "args"); Intrinsics.checkNotNullParameter(function, "function"); Intrinsics.checkNotNullExpressionValue($this$query.query(sql, function::query$lambda$1, Arrays.copyOf(args, args.length)), "query(sql, { rs, i -> function(rs, i) }, *args)"); return (List)$this$query.query(sql, function::query$lambda$1, Arrays.copyOf(args, args.length)); } private static final Object query$lambda$1(Function2 $function, ResultSet rs, int i) { Intrinsics.checkNotNullParameter($function, "$function"); Intrinsics.checkNotNullExpressionValue(rs, "rs"); return $function.invoke(rs, Integer.valueOf(i)); }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\JdbcOperationsExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */