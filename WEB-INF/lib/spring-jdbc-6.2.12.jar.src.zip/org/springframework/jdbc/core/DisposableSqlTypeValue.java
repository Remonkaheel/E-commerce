package org.springframework.jdbc.core;

public interface DisposableSqlTypeValue extends SqlTypeValue {
  void cleanup();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\DisposableSqlTypeValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */