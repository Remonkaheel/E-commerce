/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.dao.TypeMismatchDataAccessException;
/*     */ import org.springframework.jdbc.IncorrectResultSetColumnCountException;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleColumnRowMapper<T>
/*     */   implements RowMapper<T>
/*     */ {
/*     */   @Nullable
/*     */   private Class<?> requiredType;
/*     */   @Nullable
/*  54 */   private ConversionService conversionService = DefaultConversionService.getSharedInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SingleColumnRowMapper() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SingleColumnRowMapper(Class<T> requiredType) {
/*  69 */     if (requiredType != Object.class) {
/*  70 */       setRequiredType(requiredType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequiredType(Class<T> requiredType) {
/*  81 */     this.requiredType = ClassUtils.resolvePrimitiveIfNecessary(requiredType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConversionService(@Nullable ConversionService conversionService) {
/*  91 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 109 */     ResultSetMetaData rsmd = rs.getMetaData();
/* 110 */     int nrOfColumns = rsmd.getColumnCount();
/* 111 */     if (nrOfColumns != 1) {
/* 112 */       throw new IncorrectResultSetColumnCountException(1, nrOfColumns);
/*     */     }
/*     */ 
/*     */     
/* 116 */     Object result = getColumnValue(rs, 1, this.requiredType);
/* 117 */     if (result != null && this.requiredType != null && !this.requiredType.isInstance(result)) {
/*     */       
/*     */       try {
/* 120 */         return (T)convertValueToRequiredType(result, this.requiredType);
/*     */       }
/* 122 */       catch (IllegalArgumentException ex) {
/* 123 */         throw new TypeMismatchDataAccessException("Type mismatch affecting row number " + rowNum + " and column type '" + rsmd
/*     */             
/* 125 */             .getColumnTypeName(1) + "': " + ex.getMessage());
/*     */       } 
/*     */     }
/* 128 */     return (T)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getColumnValue(ResultSet rs, int index, @Nullable Class<?> requiredType) throws SQLException {
/* 150 */     if (requiredType != null) {
/* 151 */       return JdbcUtils.getResultSetValue(rs, index, requiredType);
/*     */     }
/*     */ 
/*     */     
/* 155 */     return getColumnValue(rs, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getColumnValue(ResultSet rs, int index) throws SQLException {
/* 175 */     return JdbcUtils.getResultSetValue(rs, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object convertValueToRequiredType(Object value, Class<?> requiredType) {
/* 196 */     if (String.class == requiredType) {
/* 197 */       return value.toString();
/*     */     }
/* 199 */     if (Number.class.isAssignableFrom(requiredType)) {
/* 200 */       if (value instanceof Number) { Number number = (Number)value;
/*     */         
/* 202 */         return NumberUtils.convertNumberToTargetClass(number, requiredType); }
/*     */ 
/*     */ 
/*     */       
/* 206 */       return NumberUtils.parseNumber(value.toString(), requiredType);
/*     */     } 
/*     */     
/* 209 */     if (this.conversionService != null && this.conversionService.canConvert(value.getClass(), requiredType)) {
/* 210 */       return this.conversionService.convert(value, requiredType);
/*     */     }
/*     */     
/* 213 */     throw new IllegalArgumentException("Value [" + String.valueOf(value) + "] is of type [" + value
/* 214 */         .getClass().getName() + "] and cannot be converted to required type [" + requiredType
/* 215 */         .getName() + "]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> SingleColumnRowMapper<T> newInstance(Class<T> requiredType) {
/* 227 */     return new SingleColumnRowMapper<>(requiredType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> SingleColumnRowMapper<T> newInstance(Class<T> requiredType, @Nullable ConversionService conversionService) {
/* 242 */     SingleColumnRowMapper<T> rowMapper = newInstance(requiredType);
/* 243 */     rowMapper.setConversionService(conversionService);
/* 244 */     return rowMapper;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\SingleColumnRowMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */