/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.NotWritablePropertyException;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.dao.DataRetrievalFailureException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanPropertyRowMapper<T>
/*     */   implements RowMapper<T>
/*     */ {
/*  95 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Class<T> mappedClass;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkFullyPopulated = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean primitivesDefaultedForNullValue = false;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/* 113 */   private ConversionService conversionService = DefaultConversionService.getSharedInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Map<String, PropertyDescriptor> mappedProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Set<String> mappedPropertyNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyRowMapper() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyRowMapper(Class<T> mappedClass) {
/* 138 */     initialize(mappedClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyRowMapper(Class<T> mappedClass, boolean checkFullyPopulated) {
/* 148 */     initialize(mappedClass);
/* 149 */     this.checkFullyPopulated = checkFullyPopulated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappedClass(Class<T> mappedClass) {
/* 157 */     if (this.mappedClass == null) {
/* 158 */       initialize(mappedClass);
/*     */     
/*     */     }
/* 161 */     else if (this.mappedClass != mappedClass) {
/* 162 */       throw new InvalidDataAccessApiUsageException("The mapped class can not be reassigned to map to " + String.valueOf(mappedClass) + " since it is already providing mapping for " + String.valueOf(this.mappedClass));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Class<T> getMappedClass() {
/* 173 */     return this.mappedClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCheckFullyPopulated(boolean checkFullyPopulated) {
/* 182 */     this.checkFullyPopulated = checkFullyPopulated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCheckFullyPopulated() {
/* 190 */     return this.checkFullyPopulated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrimitivesDefaultedForNullValue(boolean primitivesDefaultedForNullValue) {
/* 208 */     this.primitivesDefaultedForNullValue = primitivesDefaultedForNullValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPrimitivesDefaultedForNullValue() {
/* 216 */     return this.primitivesDefaultedForNullValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConversionService(@Nullable ConversionService conversionService) {
/* 228 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ConversionService getConversionService() {
/* 238 */     return this.conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize(Class<T> mappedClass) {
/* 250 */     this.mappedClass = mappedClass;
/* 251 */     this.mappedProperties = new HashMap<>();
/* 252 */     this.mappedPropertyNames = new HashSet<>();
/*     */     
/* 254 */     for (PropertyDescriptor pd : BeanUtils.getPropertyDescriptors(mappedClass)) {
/* 255 */       if (pd.getWriteMethod() != null) {
/* 256 */         Set<String> mappedNames = mappedNames(pd);
/* 257 */         for (String mappedName : mappedNames) {
/* 258 */           this.mappedProperties.put(mappedName, pd);
/*     */         }
/* 260 */         this.mappedPropertyNames.add(pd.getName());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void suppressProperty(String propertyName) {
/* 271 */     if (this.mappedProperties != null) {
/* 272 */       this.mappedProperties.remove(lowerCaseName(propertyName));
/* 273 */       this.mappedProperties.remove(underscoreName(propertyName));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<String> mappedNames(PropertyDescriptor pd) {
/* 291 */     Set<String> mappedNames = new HashSet<>(4);
/* 292 */     mappedNames.add(lowerCaseName(pd.getName()));
/* 293 */     mappedNames.add(underscoreName(pd.getName()));
/* 294 */     return mappedNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String lowerCaseName(String name) {
/* 306 */     return name.toLowerCase(Locale.US);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String underscoreName(String name) {
/* 318 */     return JdbcUtils.convertPropertyNameToUnderscoreName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T mapRow(ResultSet rs, int rowNumber) throws SQLException {
/* 329 */     BeanWrapperImpl bw = new BeanWrapperImpl();
/* 330 */     initBeanWrapper((BeanWrapper)bw);
/*     */     
/* 332 */     T mappedObject = constructMappedInstance(rs, (TypeConverter)bw);
/* 333 */     bw.setBeanInstance(mappedObject);
/*     */     
/* 335 */     ResultSetMetaData rsmd = rs.getMetaData();
/* 336 */     int columnCount = rsmd.getColumnCount();
/* 337 */     Set<String> populatedProperties = isCheckFullyPopulated() ? new HashSet<>() : null;
/*     */     
/* 339 */     for (int index = 1; index <= columnCount; index++) {
/* 340 */       String column = JdbcUtils.lookupColumnName(rsmd, index);
/* 341 */       String property = lowerCaseName(StringUtils.delete(column, " "));
/* 342 */       PropertyDescriptor pd = (this.mappedProperties != null) ? this.mappedProperties.get(property) : null;
/* 343 */       if (pd != null) {
/*     */         try {
/* 345 */           Object value = getColumnValue(rs, index, pd);
/* 346 */           if (rowNumber == 0 && this.logger.isDebugEnabled()) {
/* 347 */             this.logger.debug("Mapping column '" + column + "' to property '" + pd.getName() + "' of type '" + 
/* 348 */                 ClassUtils.getQualifiedName(pd.getPropertyType()) + "'");
/*     */           }
/*     */           try {
/* 351 */             bw.setPropertyValue(pd.getName(), value);
/*     */           }
/* 353 */           catch (TypeMismatchException ex) {
/* 354 */             if (value == null && isPrimitivesDefaultedForNullValue()) {
/* 355 */               if (this.logger.isDebugEnabled()) {
/* 356 */                 String propertyType = ClassUtils.getQualifiedName(pd.getPropertyType());
/* 357 */                 this.logger.debug("Ignoring intercepted TypeMismatchException for row %d and column '%s' with null value when setting property '%s' of type '%s' on object: %s\"\n"
/*     */ 
/*     */                     
/* 360 */                     .formatted(new Object[] { Integer.valueOf(rowNumber), column, pd.getName(), propertyType, mappedObject }, ), (Throwable)ex);
/*     */               } 
/*     */             } else {
/*     */               
/* 364 */               throw ex;
/*     */             } 
/*     */           } 
/* 367 */           if (populatedProperties != null) {
/* 368 */             populatedProperties.add(pd.getName());
/*     */           }
/*     */         }
/* 371 */         catch (NotWritablePropertyException ex) {
/* 372 */           throw new DataRetrievalFailureException("Unable to map column '" + column + "' to property '" + pd
/* 373 */               .getName() + "'", ex);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 378 */     if (populatedProperties != null && !populatedProperties.equals(this.mappedPropertyNames)) {
/* 379 */       throw new InvalidDataAccessApiUsageException("Given ResultSet does not contain all properties necessary to populate object of " + String.valueOf(this.mappedClass) + ": " + String.valueOf(this.mappedPropertyNames));
/*     */     }
/*     */ 
/*     */     
/* 383 */     return mappedObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T constructMappedInstance(ResultSet rs, TypeConverter tc) throws SQLException {
/* 395 */     Assert.state((this.mappedClass != null), "Mapped class was not specified");
/* 396 */     return (T)BeanUtils.instantiateClass(this.mappedClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initBeanWrapper(BeanWrapper bw) {
/* 409 */     ConversionService cs = getConversionService();
/* 410 */     if (cs != null) {
/* 411 */       bw.setConversionService(cs);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getColumnValue(ResultSet rs, int index, PropertyDescriptor pd) throws SQLException {
/* 431 */     return JdbcUtils.getResultSetValue(rs, index, pd.getPropertyType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getColumnValue(ResultSet rs, int index, Class<?> paramType) throws SQLException {
/* 450 */     return JdbcUtils.getResultSetValue(rs, index, paramType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> BeanPropertyRowMapper<T> newInstance(Class<T> mappedClass) {
/* 460 */     return new BeanPropertyRowMapper<>(mappedClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> BeanPropertyRowMapper<T> newInstance(Class<T> mappedClass, @Nullable ConversionService conversionService) {
/* 475 */     BeanPropertyRowMapper<T> rowMapper = newInstance(mappedClass);
/* 476 */     rowMapper.setConversionService(conversionService);
/* 477 */     return rowMapper;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\BeanPropertyRowMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */