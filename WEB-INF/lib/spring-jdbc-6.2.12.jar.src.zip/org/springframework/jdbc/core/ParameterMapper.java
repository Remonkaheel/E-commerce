package org.springframework.jdbc.core;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

@FunctionalInterface
public interface ParameterMapper {
  Map<String, ?> createMap(Connection paramConnection) throws SQLException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\ParameterMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */