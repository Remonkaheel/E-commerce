/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArgumentPreparedStatementSetter
/*    */   implements PreparedStatementSetter, ParameterDisposer
/*    */ {
/*    */   @Nullable
/*    */   private final Object[] args;
/*    */   
/*    */   public ArgumentPreparedStatementSetter(@Nullable Object[] args) {
/* 42 */     this.args = args;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValues(PreparedStatement ps) throws SQLException {
/* 48 */     if (this.args != null) {
/* 49 */       for (int i = 0; i < this.args.length; i++) {
/* 50 */         Object arg = this.args[i];
/* 51 */         doSetValue(ps, i + 1, arg);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doSetValue(PreparedStatement ps, int parameterPosition, @Nullable Object argValue) throws SQLException {
/* 68 */     if (argValue instanceof SqlParameterValue) { SqlParameterValue paramValue = (SqlParameterValue)argValue;
/* 69 */       StatementCreatorUtils.setParameterValue(ps, parameterPosition, paramValue, paramValue.getValue()); }
/*    */     else
/*    */     
/* 72 */     { StatementCreatorUtils.setParameterValue(ps, parameterPosition, -2147483648, argValue); }
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   public void cleanupParameters() {
/* 78 */     StatementCreatorUtils.cleanupParameters(this.args);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\ArgumentPreparedStatementSetter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */