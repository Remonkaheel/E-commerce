/*    */ package org.springframework.jdbc.core.support;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.jdbc.core.PreparedStatementCallback;
/*    */ import org.springframework.jdbc.support.lob.LobCreator;
/*    */ import org.springframework.jdbc.support.lob.LobHandler;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.2")
/*    */ public abstract class AbstractLobCreatingPreparedStatementCallback
/*    */   implements PreparedStatementCallback<Integer>
/*    */ {
/*    */   private final LobHandler lobHandler;
/*    */   
/*    */   public AbstractLobCreatingPreparedStatementCallback(LobHandler lobHandler) {
/* 68 */     Assert.notNull(lobHandler, "LobHandler must not be null");
/* 69 */     this.lobHandler = lobHandler;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final Integer doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
/* 75 */     LobCreator lobCreator = this.lobHandler.getLobCreator(); try {
/* 76 */       setValues(ps, lobCreator);
/* 77 */       Integer integer = Integer.valueOf(ps.executeUpdate());
/* 78 */       if (lobCreator != null) lobCreator.close(); 
/*    */       return integer;
/*    */     } catch (Throwable throwable) {
/*    */       if (lobCreator != null)
/*    */         try {
/*    */           lobCreator.close();
/*    */         } catch (Throwable throwable1) {
/*    */           throwable.addSuppressed(throwable1);
/*    */         }  
/*    */       throw throwable;
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract void setValues(PreparedStatement paramPreparedStatement, LobCreator paramLobCreator) throws SQLException, DataAccessException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\support\AbstractLobCreatingPreparedStatementCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */