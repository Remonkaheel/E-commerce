/*    */ package org.springframework.jdbc.core.support;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.InterruptibleBatchPreparedStatementSetter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractInterruptibleBatchPreparedStatementSetter
/*    */   implements InterruptibleBatchPreparedStatementSetter
/*    */ {
/*    */   private boolean exhausted;
/*    */   
/*    */   public final void setValues(PreparedStatement ps, int i) throws SQLException {
/* 45 */     this.exhausted = !setValuesIfAvailable(ps, i);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isBatchExhausted(int i) {
/* 53 */     return this.exhausted;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getBatchSize() {
/* 62 */     return Integer.MAX_VALUE;
/*    */   }
/*    */   
/*    */   protected abstract boolean setValuesIfAvailable(PreparedStatement paramPreparedStatement, int paramInt) throws SQLException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\support\AbstractInterruptibleBatchPreparedStatementSetter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */