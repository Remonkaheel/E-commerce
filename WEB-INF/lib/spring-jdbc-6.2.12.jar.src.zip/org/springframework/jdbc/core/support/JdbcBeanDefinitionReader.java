/*     */ package org.springframework.jdbc.core.support;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.PropertiesBeanDefinitionReader;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class JdbcBeanDefinitionReader
/*     */ {
/*     */   private final PropertiesBeanDefinitionReader propReader;
/*     */   @Nullable
/*     */   private JdbcTemplate jdbcTemplate;
/*     */   
/*     */   public JdbcBeanDefinitionReader(BeanDefinitionRegistry beanFactory) {
/*  64 */     this.propReader = new PropertiesBeanDefinitionReader(beanFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcBeanDefinitionReader(PropertiesBeanDefinitionReader reader) {
/*  75 */     Assert.notNull(reader, "Bean definition reader must not be null");
/*  76 */     this.propReader = reader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(DataSource dataSource) {
/*  85 */     this.jdbcTemplate = new JdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
/*  93 */     Assert.notNull(jdbcTemplate, "JdbcTemplate must not be null");
/*  94 */     this.jdbcTemplate = jdbcTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadBeanDefinitions(String sql) {
/* 108 */     Assert.notNull(this.jdbcTemplate, "Not fully configured - specify DataSource or JdbcTemplate");
/* 109 */     Properties props = new Properties();
/* 110 */     this.jdbcTemplate.query(sql, rs -> {
/*     */           String beanName = rs.getString(1);
/*     */           
/*     */           String property = rs.getString(2);
/*     */           String value = rs.getString(3);
/*     */           props.setProperty(beanName + "." + beanName, value);
/*     */         });
/* 117 */     this.propReader.registerBeanDefinitions(props);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\support\JdbcBeanDefinitionReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */