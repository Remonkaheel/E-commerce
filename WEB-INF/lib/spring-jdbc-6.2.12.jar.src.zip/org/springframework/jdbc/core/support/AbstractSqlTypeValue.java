/*    */ package org.springframework.jdbc.core.support;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.SqlTypeValue;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSqlTypeValue
/*    */   implements SqlTypeValue
/*    */ {
/*    */   public final void setTypeValue(PreparedStatement ps, int paramIndex, int sqlType, @Nullable String typeName) throws SQLException {
/* 60 */     Object value = createTypeValue(ps.getConnection(), sqlType, typeName);
/* 61 */     if (sqlType == Integer.MIN_VALUE) {
/* 62 */       ps.setObject(paramIndex, value);
/*    */     } else {
/*    */       
/* 65 */       ps.setObject(paramIndex, value, sqlType);
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract Object createTypeValue(Connection paramConnection, int paramInt, @Nullable String paramString) throws SQLException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\support\AbstractSqlTypeValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */