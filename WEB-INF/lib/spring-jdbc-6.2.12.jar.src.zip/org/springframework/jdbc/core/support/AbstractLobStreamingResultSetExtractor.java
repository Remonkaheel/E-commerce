/*     */ package org.springframework.jdbc.core.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.EmptyResultDataAccessException;
/*     */ import org.springframework.dao.IncorrectResultSizeDataAccessException;
/*     */ import org.springframework.jdbc.LobRetrievalFailureException;
/*     */ import org.springframework.jdbc.core.ResultSetExtractor;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(since = "6.2")
/*     */ public abstract class AbstractLobStreamingResultSetExtractor<T>
/*     */   implements ResultSetExtractor<T>
/*     */ {
/*     */   @Nullable
/*     */   public final T extractData(ResultSet rs) throws SQLException, DataAccessException {
/*  75 */     if (!rs.next()) {
/*  76 */       handleNoRowFound();
/*     */     } else {
/*     */       
/*     */       try {
/*  80 */         streamData(rs);
/*  81 */         if (rs.next()) {
/*  82 */           handleMultipleRowsFound();
/*     */         }
/*     */       }
/*  85 */       catch (IOException ex) {
/*  86 */         throw new LobRetrievalFailureException("Could not stream LOB content", ex);
/*     */       } 
/*     */     } 
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleNoRowFound() throws DataAccessException {
/*  99 */     throw new EmptyResultDataAccessException("LobStreamingResultSetExtractor did not find row in database", 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleMultipleRowsFound() throws DataAccessException {
/* 110 */     throw new IncorrectResultSizeDataAccessException("LobStreamingResultSetExtractor found multiple rows in database", 1);
/*     */   }
/*     */   
/*     */   protected abstract void streamData(ResultSet paramResultSet) throws SQLException, IOException, DataAccessException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\support\AbstractLobStreamingResultSetExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */