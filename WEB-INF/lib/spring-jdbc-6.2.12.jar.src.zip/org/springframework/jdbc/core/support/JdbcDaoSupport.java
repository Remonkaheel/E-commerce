/*     */ package org.springframework.jdbc.core.support;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.support.DaoSupport;
/*     */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.support.SQLExceptionTranslator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JdbcDaoSupport
/*     */   extends DaoSupport
/*     */ {
/*     */   @Nullable
/*     */   private JdbcTemplate jdbcTemplate;
/*     */   
/*     */   public final void setDataSource(DataSource dataSource) {
/*  58 */     if (this.jdbcTemplate == null || dataSource != this.jdbcTemplate.getDataSource()) {
/*  59 */       this.jdbcTemplate = createJdbcTemplate(dataSource);
/*  60 */       initTemplateConfig();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JdbcTemplate createJdbcTemplate(DataSource dataSource) {
/*  74 */     return new JdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final DataSource getDataSource() {
/*  82 */     return (this.jdbcTemplate != null) ? this.jdbcTemplate.getDataSource() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setJdbcTemplate(@Nullable JdbcTemplate jdbcTemplate) {
/*  90 */     this.jdbcTemplate = jdbcTemplate;
/*  91 */     initTemplateConfig();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final JdbcTemplate getJdbcTemplate() {
/* 100 */     return this.jdbcTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initTemplateConfig() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkDaoConfig() {
/* 116 */     if (this.jdbcTemplate == null) {
/* 117 */       throw new IllegalArgumentException("'dataSource' or 'jdbcTemplate' is required");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SQLExceptionTranslator getExceptionTranslator() {
/* 128 */     JdbcTemplate jdbcTemplate = getJdbcTemplate();
/* 129 */     Assert.state((jdbcTemplate != null), "No JdbcTemplate set");
/* 130 */     return jdbcTemplate.getExceptionTranslator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Connection getConnection() throws CannotGetJdbcConnectionException {
/* 140 */     DataSource dataSource = getDataSource();
/* 141 */     Assert.state((dataSource != null), "No DataSource set");
/* 142 */     return DataSourceUtils.getConnection(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void releaseConnection(Connection con) {
/* 152 */     DataSourceUtils.releaseConnection(con, getDataSource());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\support\JdbcDaoSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */