/*     */ package org.springframework.jdbc.core.support;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.jdbc.core.DisposableSqlTypeValue;
/*     */ import org.springframework.jdbc.support.lob.DefaultLobHandler;
/*     */ import org.springframework.jdbc.support.lob.LobCreator;
/*     */ import org.springframework.jdbc.support.lob.LobHandler;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(since = "6.2")
/*     */ public class SqlLobValue
/*     */   implements DisposableSqlTypeValue
/*     */ {
/*     */   @Nullable
/*     */   private final Object content;
/*     */   private final int length;
/*     */   private final LobCreator lobCreator;
/*     */   
/*     */   public SqlLobValue(@Nullable byte[] bytes) {
/*  94 */     this(bytes, (LobHandler)new DefaultLobHandler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlLobValue(@Nullable byte[] bytes, LobHandler lobHandler) {
/* 103 */     this.content = bytes;
/* 104 */     this.length = (bytes != null) ? bytes.length : 0;
/* 105 */     this.lobCreator = lobHandler.getLobCreator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlLobValue(@Nullable String content) {
/* 115 */     this(content, (LobHandler)new DefaultLobHandler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlLobValue(@Nullable String content, LobHandler lobHandler) {
/* 124 */     this.content = content;
/* 125 */     this.length = (content != null) ? content.length() : 0;
/* 126 */     this.lobCreator = lobHandler.getLobCreator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlLobValue(InputStream stream, int length) {
/* 137 */     this(stream, length, (LobHandler)new DefaultLobHandler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlLobValue(InputStream stream, int length, LobHandler lobHandler) {
/* 147 */     this.content = stream;
/* 148 */     this.length = length;
/* 149 */     this.lobCreator = lobHandler.getLobCreator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlLobValue(Reader reader, int length) {
/* 160 */     this(reader, length, (LobHandler)new DefaultLobHandler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlLobValue(Reader reader, int length, LobHandler lobHandler) {
/* 170 */     this.content = reader;
/* 171 */     this.length = length;
/* 172 */     this.lobCreator = lobHandler.getLobCreator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeValue(PreparedStatement ps, int paramIndex, int sqlType, @Nullable String typeName) throws SQLException {
/* 183 */     if (sqlType == 2004)
/* 184 */     { if (this.content instanceof byte[] || this.content == null) {
/* 185 */         this.lobCreator.setBlobAsBytes(ps, paramIndex, (byte[])this.content);
/*     */       } else {
/* 187 */         Object object = this.content; if (object instanceof String) { String string = (String)object;
/* 188 */           this.lobCreator.setBlobAsBytes(ps, paramIndex, string.getBytes()); }
/*     */         else
/* 190 */         { object = this.content; if (object instanceof InputStream) { InputStream inputStream = (InputStream)object;
/* 191 */             this.lobCreator.setBlobAsBinaryStream(ps, paramIndex, inputStream, this.length); }
/*     */           else
/*     */           
/* 194 */           { throw new IllegalArgumentException("Content type [" + this.content
/* 195 */                 .getClass().getName() + "] not supported for BLOB columns"); }  }
/*     */       
/*     */       }  }
/* 198 */     else if (sqlType == 2005)
/* 199 */     { if (this.content instanceof String || this.content == null) {
/* 200 */         this.lobCreator.setClobAsString(ps, paramIndex, (String)this.content);
/*     */       } else {
/* 202 */         Object object = this.content; if (object instanceof InputStream) { InputStream inputStream = (InputStream)object;
/* 203 */           this.lobCreator.setClobAsAsciiStream(ps, paramIndex, inputStream, this.length); }
/*     */         else
/* 205 */         { object = this.content; if (object instanceof Reader) { Reader reader = (Reader)object;
/* 206 */             this.lobCreator.setClobAsCharacterStream(ps, paramIndex, reader, this.length); }
/*     */           else
/*     */           
/* 209 */           { throw new IllegalArgumentException("Content type [" + this.content
/* 210 */                 .getClass().getName() + "] not supported for CLOB columns"); }
/*     */            }
/*     */       
/*     */       }  }
/* 214 */     else { throw new IllegalArgumentException("SqlLobValue only supports SQL types BLOB and CLOB"); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/* 223 */     this.lobCreator.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\support\SqlLobValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */