/*     */ package org.springframework.jdbc.core.support;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.core.io.InputStreamSource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.jdbc.core.SqlTypeValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlBinaryValue
/*     */   implements SqlTypeValue
/*     */ {
/*     */   private final Object content;
/*     */   private final long length;
/*     */   
/*     */   public SqlBinaryValue(byte[] bytes) {
/*  66 */     this.content = bytes;
/*  67 */     this.length = bytes.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlBinaryValue(InputStream stream, long length) {
/*  76 */     this.content = stream;
/*  77 */     this.length = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlBinaryValue(InputStreamSource resource, long length) {
/*  88 */     this.content = resource;
/*  89 */     this.length = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlBinaryValue(Resource resource) {
/*  98 */     this.content = resource;
/*  99 */     this.length = -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeValue(PreparedStatement ps, int paramIndex, int sqlType, @Nullable String typeName) throws SQLException {
/* 107 */     Object object = this.content; if (object instanceof byte[]) { byte[] bytes = (byte[])object;
/* 108 */       setByteArray(ps, paramIndex, sqlType, bytes); }
/*     */     else
/* 110 */     { object = this.content; if (object instanceof InputStream) { InputStream inputStream = (InputStream)object;
/* 111 */         setInputStream(ps, paramIndex, sqlType, inputStream, this.length); }
/*     */       else
/* 113 */       { object = this.content; if (object instanceof Resource) { Resource resource = (Resource)object;
/*     */           try {
/* 115 */             setInputStream(ps, paramIndex, sqlType, resource.getInputStream(), resource.contentLength());
/*     */           }
/* 117 */           catch (IOException ex) {
/* 118 */             throw new IllegalArgumentException("Cannot open binary stream for JDBC value: " + String.valueOf(resource), ex);
/*     */           }  }
/*     */         else
/* 121 */         { object = this.content; if (object instanceof InputStreamSource) { InputStreamSource resource = (InputStreamSource)object;
/*     */             try {
/* 123 */               setInputStream(ps, paramIndex, sqlType, resource.getInputStream(), this.length);
/*     */             }
/* 125 */             catch (IOException ex) {
/* 126 */               throw new IllegalArgumentException("Cannot open binary stream for JDBC value: " + String.valueOf(resource), ex);
/*     */             }  }
/*     */           else
/*     */           
/* 130 */           { throw new IllegalArgumentException("Illegal content type: " + this.content.getClass().getName()); }
/*     */            }
/*     */          }
/*     */        }
/*     */   
/*     */   }
/*     */   private void setByteArray(PreparedStatement ps, int paramIndex, int sqlType, byte[] bytes) throws SQLException {
/* 137 */     if (sqlType == 2004) {
/* 138 */       ps.setBlob(paramIndex, new ByteArrayInputStream(bytes), bytes.length);
/*     */     } else {
/*     */       
/* 141 */       ps.setBytes(paramIndex, bytes);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setInputStream(PreparedStatement ps, int paramIndex, int sqlType, InputStream is, long length) throws SQLException {
/* 148 */     if (sqlType == 2004) {
/* 149 */       ps.setBlob(paramIndex, is, length);
/*     */     } else {
/*     */       
/* 152 */       ps.setBinaryStream(paramIndex, is, length);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\support\SqlBinaryValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */