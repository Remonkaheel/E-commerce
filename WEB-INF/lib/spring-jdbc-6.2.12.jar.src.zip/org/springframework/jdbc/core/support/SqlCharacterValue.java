/*     */ package org.springframework.jdbc.core.support;
/*     */ 
/*     */ import java.io.CharArrayReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.jdbc.core.SqlTypeValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlCharacterValue
/*     */   implements SqlTypeValue
/*     */ {
/*     */   private final Object content;
/*     */   private final long length;
/*     */   
/*     */   public SqlCharacterValue(CharSequence string) {
/*  64 */     this.content = string;
/*  65 */     this.length = string.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlCharacterValue(char[] characters) {
/*  73 */     this.content = characters;
/*  74 */     this.length = characters.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlCharacterValue(Reader reader, long length) {
/*  83 */     this.content = reader;
/*  84 */     this.length = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlCharacterValue(InputStream asciiStream, long length) {
/*  93 */     this.content = asciiStream;
/*  94 */     this.length = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeValue(PreparedStatement ps, int paramIndex, int sqlType, @Nullable String typeName) throws SQLException {
/* 102 */     if (this.content instanceof CharSequence) {
/* 103 */       setString(ps, paramIndex, sqlType, this.content.toString());
/*     */     } else {
/* 105 */       Object object = this.content; if (object instanceof char[]) { char[] chars = (char[])object;
/* 106 */         setReader(ps, paramIndex, sqlType, new CharArrayReader(chars), this.length); }
/*     */       else
/* 108 */       { object = this.content; if (object instanceof Reader) { Reader reader = (Reader)object;
/* 109 */           setReader(ps, paramIndex, sqlType, reader, this.length); }
/*     */         else
/* 111 */         { object = this.content; if (object instanceof InputStream) { InputStream asciiStream = (InputStream)object;
/* 112 */             ps.setAsciiStream(paramIndex, asciiStream, this.length); }
/*     */           else
/*     */           
/* 115 */           { throw new IllegalArgumentException("Illegal content type: " + this.content.getClass().getName()); }
/*     */            }
/*     */          }
/*     */     
/*     */     } 
/*     */   }
/*     */   private void setString(PreparedStatement ps, int paramIndex, int sqlType, String string) throws SQLException {
/* 122 */     if (sqlType == 2005) {
/* 123 */       ps.setClob(paramIndex, new StringReader(string), string.length());
/*     */     }
/* 125 */     else if (sqlType == 2011) {
/* 126 */       ps.setNClob(paramIndex, new StringReader(string), string.length());
/*     */     } else {
/*     */       
/* 129 */       ps.setString(paramIndex, string);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setReader(PreparedStatement ps, int paramIndex, int sqlType, Reader reader, long length) throws SQLException {
/* 136 */     if (sqlType == 2005) {
/* 137 */       ps.setClob(paramIndex, reader, length);
/*     */     }
/* 139 */     else if (sqlType == 2011) {
/* 140 */       ps.setNClob(paramIndex, reader, length);
/*     */     } else {
/*     */       
/* 143 */       ps.setCharacterStream(paramIndex, reader, length);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\support\SqlCharacterValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */