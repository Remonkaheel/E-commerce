/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlParameterValue
/*    */   extends SqlParameter
/*    */ {
/*    */   @Nullable
/*    */   private final Object value;
/*    */   
/*    */   public SqlParameterValue(int sqlType, @Nullable Object value) {
/* 51 */     super(sqlType);
/* 52 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SqlParameterValue(int sqlType, @Nullable String typeName, @Nullable Object value) {
/* 62 */     super(sqlType, typeName);
/* 63 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SqlParameterValue(int sqlType, int scale, @Nullable Object value) {
/* 74 */     super(sqlType, scale);
/* 75 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SqlParameterValue(SqlParameter declaredParam, @Nullable Object value) {
/* 84 */     super(declaredParam);
/* 85 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object getValue() {
/* 94 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\SqlParameterValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */