package org.springframework.jdbc.core;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

@FunctionalInterface
public interface CallableStatementCreator {
  CallableStatement createCallableStatement(Connection paramConnection) throws SQLException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\CallableStatementCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */