/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CallableStatementCreatorFactory
/*     */ {
/*     */   private final String callString;
/*     */   private final List<SqlParameter> declaredParameters;
/*  48 */   private int resultSetType = 1003;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean updatableResults = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatementCreatorFactory(String callString) {
/*  59 */     this.callString = callString;
/*  60 */     this.declaredParameters = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatementCreatorFactory(String callString, List<SqlParameter> declaredParameters) {
/*  69 */     this.callString = callString;
/*  70 */     this.declaredParameters = declaredParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getCallString() {
/*  79 */     return this.callString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParameter(SqlParameter param) {
/*  88 */     this.declaredParameters.add(param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResultSetType(int resultSetType) {
/* 100 */     this.resultSetType = resultSetType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpdatableResults(boolean updatableResults) {
/* 107 */     this.updatableResults = updatableResults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatementCreator newCallableStatementCreator(@Nullable Map<String, ?> params) {
/* 116 */     return new CallableStatementCreatorImpl((params != null) ? params : new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatementCreator newCallableStatementCreator(ParameterMapper inParamMapper) {
/* 124 */     return new CallableStatementCreatorImpl(inParamMapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class CallableStatementCreatorImpl
/*     */     implements CallableStatementCreator, SqlProvider, ParameterDisposer
/*     */   {
/*     */     @Nullable
/*     */     private ParameterMapper inParameterMapper;
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Map<String, ?> inParameters;
/*     */ 
/*     */ 
/*     */     
/*     */     public CallableStatementCreatorImpl(ParameterMapper inParamMapper) {
/* 144 */       this.inParameterMapper = inParamMapper;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CallableStatementCreatorImpl(Map<String, ?> inParams) {
/* 152 */       this.inParameters = inParams;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public CallableStatement createCallableStatement(Connection con) throws SQLException {
/* 158 */       if (this.inParameterMapper != null) {
/* 159 */         this.inParameters = this.inParameterMapper.createMap(con);
/*     */       
/*     */       }
/* 162 */       else if (this.inParameters == null) {
/* 163 */         throw new InvalidDataAccessApiUsageException("A ParameterMapper or a Map of parameters must be provided");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 168 */       CallableStatement cs = null;
/* 169 */       if (CallableStatementCreatorFactory.this.resultSetType == 1003 && !CallableStatementCreatorFactory.this.updatableResults) {
/* 170 */         cs = con.prepareCall(CallableStatementCreatorFactory.this.callString);
/*     */       } else {
/*     */         
/* 173 */         cs = con.prepareCall(CallableStatementCreatorFactory.this.callString, CallableStatementCreatorFactory.this.resultSetType, 
/* 174 */             CallableStatementCreatorFactory.this.updatableResults ? 1008 : 1007);
/*     */       } 
/*     */       
/* 177 */       int sqlColIndx = 1;
/* 178 */       for (SqlParameter declaredParam : CallableStatementCreatorFactory.this.declaredParameters) {
/* 179 */         if (!declaredParam.isResultsParameter()) {
/*     */ 
/*     */           
/* 182 */           Object inValue = this.inParameters.get(declaredParam.getName());
/* 183 */           if (declaredParam instanceof ResultSetSupportingSqlParameter) {
/*     */ 
/*     */             
/* 186 */             if (declaredParam instanceof SqlOutParameter) {
/* 187 */               if (declaredParam.getTypeName() != null) {
/* 188 */                 cs.registerOutParameter(sqlColIndx, declaredParam.getSqlType(), declaredParam.getTypeName());
/*     */               
/*     */               }
/* 191 */               else if (declaredParam.getScale() != null) {
/* 192 */                 cs.registerOutParameter(sqlColIndx, declaredParam.getSqlType(), declaredParam.getScale().intValue());
/*     */               } else {
/*     */                 
/* 195 */                 cs.registerOutParameter(sqlColIndx, declaredParam.getSqlType());
/*     */               } 
/*     */               
/* 198 */               if (declaredParam.isInputValueProvided()) {
/* 199 */                 StatementCreatorUtils.setParameterValue(cs, sqlColIndx, declaredParam, inValue);
/*     */               }
/*     */             }
/*     */           
/*     */           } else {
/*     */             
/* 205 */             if (!this.inParameters.containsKey(declaredParam.getName())) {
/* 206 */               throw new InvalidDataAccessApiUsageException("Required input parameter '" + declaredParam
/* 207 */                   .getName() + "' is missing");
/*     */             }
/* 209 */             StatementCreatorUtils.setParameterValue(cs, sqlColIndx, declaredParam, inValue);
/*     */           } 
/* 211 */           sqlColIndx++;
/*     */         } 
/*     */       } 
/*     */       
/* 215 */       return cs;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSql() {
/* 220 */       return CallableStatementCreatorFactory.this.callString;
/*     */     }
/*     */ 
/*     */     
/*     */     public void cleanupParameters() {
/* 225 */       if (this.inParameters != null) {
/* 226 */         StatementCreatorUtils.cleanupParameters(this.inParameters.values());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 232 */       return "CallableStatementCreator: sql=[" + CallableStatementCreatorFactory.this.callString + "]; parameters=" + String.valueOf(this.inParameters);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\CallableStatementCreatorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */