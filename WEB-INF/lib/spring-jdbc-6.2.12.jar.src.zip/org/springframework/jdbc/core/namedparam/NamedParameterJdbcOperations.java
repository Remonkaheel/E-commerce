package org.springframework.jdbc.core.namedparam;

import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.lang.Nullable;

public interface NamedParameterJdbcOperations {
  JdbcOperations getJdbcOperations();
  
  @Nullable
  <T> T execute(String paramString, SqlParameterSource paramSqlParameterSource, PreparedStatementCallback<T> paramPreparedStatementCallback) throws DataAccessException;
  
  @Nullable
  <T> T execute(String paramString, Map<String, ?> paramMap, PreparedStatementCallback<T> paramPreparedStatementCallback) throws DataAccessException;
  
  @Nullable
  <T> T execute(String paramString, PreparedStatementCallback<T> paramPreparedStatementCallback) throws DataAccessException;
  
  @Nullable
  <T> T query(String paramString, SqlParameterSource paramSqlParameterSource, ResultSetExtractor<T> paramResultSetExtractor) throws DataAccessException;
  
  @Nullable
  <T> T query(String paramString, Map<String, ?> paramMap, ResultSetExtractor<T> paramResultSetExtractor) throws DataAccessException;
  
  @Nullable
  <T> T query(String paramString, ResultSetExtractor<T> paramResultSetExtractor) throws DataAccessException;
  
  void query(String paramString, SqlParameterSource paramSqlParameterSource, RowCallbackHandler paramRowCallbackHandler) throws DataAccessException;
  
  void query(String paramString, Map<String, ?> paramMap, RowCallbackHandler paramRowCallbackHandler) throws DataAccessException;
  
  void query(String paramString, RowCallbackHandler paramRowCallbackHandler) throws DataAccessException;
  
  <T> List<T> query(String paramString, SqlParameterSource paramSqlParameterSource, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  <T> List<T> query(String paramString, Map<String, ?> paramMap, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  <T> List<T> query(String paramString, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  <T> Stream<T> queryForStream(String paramString, SqlParameterSource paramSqlParameterSource, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  <T> Stream<T> queryForStream(String paramString, Map<String, ?> paramMap, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  @Nullable
  <T> T queryForObject(String paramString, SqlParameterSource paramSqlParameterSource, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  @Nullable
  <T> T queryForObject(String paramString, Map<String, ?> paramMap, RowMapper<T> paramRowMapper) throws DataAccessException;
  
  @Nullable
  <T> T queryForObject(String paramString, SqlParameterSource paramSqlParameterSource, Class<T> paramClass) throws DataAccessException;
  
  @Nullable
  <T> T queryForObject(String paramString, Map<String, ?> paramMap, Class<T> paramClass) throws DataAccessException;
  
  Map<String, Object> queryForMap(String paramString, SqlParameterSource paramSqlParameterSource) throws DataAccessException;
  
  Map<String, Object> queryForMap(String paramString, Map<String, ?> paramMap) throws DataAccessException;
  
  <T> List<T> queryForList(String paramString, SqlParameterSource paramSqlParameterSource, Class<T> paramClass) throws DataAccessException;
  
  <T> List<T> queryForList(String paramString, Map<String, ?> paramMap, Class<T> paramClass) throws DataAccessException;
  
  List<Map<String, Object>> queryForList(String paramString, SqlParameterSource paramSqlParameterSource) throws DataAccessException;
  
  List<Map<String, Object>> queryForList(String paramString, Map<String, ?> paramMap) throws DataAccessException;
  
  SqlRowSet queryForRowSet(String paramString, SqlParameterSource paramSqlParameterSource) throws DataAccessException;
  
  SqlRowSet queryForRowSet(String paramString, Map<String, ?> paramMap) throws DataAccessException;
  
  int update(String paramString, SqlParameterSource paramSqlParameterSource) throws DataAccessException;
  
  int update(String paramString, Map<String, ?> paramMap) throws DataAccessException;
  
  int update(String paramString, SqlParameterSource paramSqlParameterSource, KeyHolder paramKeyHolder) throws DataAccessException;
  
  int update(String paramString, SqlParameterSource paramSqlParameterSource, KeyHolder paramKeyHolder, String[] paramArrayOfString) throws DataAccessException;
  
  int[] batchUpdate(String paramString, SqlParameterSource[] paramArrayOfSqlParameterSource);
  
  int[] batchUpdate(String paramString, Map<String, ?>[] paramArrayOfMap);
  
  int[] batchUpdate(String paramString, SqlParameterSource[] paramArrayOfSqlParameterSource, KeyHolder paramKeyHolder);
  
  int[] batchUpdate(String paramString, SqlParameterSource[] paramArrayOfSqlParameterSource, KeyHolder paramKeyHolder, String[] paramArrayOfString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\namedparam\NamedParameterJdbcOperations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */