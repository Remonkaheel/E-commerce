/*    */ package org.springframework.jdbc.core.namedparam;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptySqlParameterSource
/*    */   implements SqlParameterSource
/*    */ {
/* 32 */   public static final EmptySqlParameterSource INSTANCE = new EmptySqlParameterSource();
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasValue(String paramName) {
/* 37 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object getValue(String paramName) throws IllegalArgumentException {
/* 43 */     throw new IllegalArgumentException("This SqlParameterSource is empty");
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSqlType(String paramName) {
/* 48 */     return Integer.MIN_VALUE;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getTypeName(String paramName) {
/* 54 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String[] getParameterNames() {
/* 60 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\namedparam\EmptySqlParameterSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */