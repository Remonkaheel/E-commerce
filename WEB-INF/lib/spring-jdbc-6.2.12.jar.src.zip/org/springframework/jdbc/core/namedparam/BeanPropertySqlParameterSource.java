/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.NotReadablePropertyException;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.jdbc.core.StatementCreatorUtils;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanPropertySqlParameterSource
/*     */   extends AbstractSqlParameterSource
/*     */ {
/*     */   private final BeanWrapper beanWrapper;
/*     */   @Nullable
/*     */   private String[] propertyNames;
/*     */   
/*     */   public BeanPropertySqlParameterSource(Object object) {
/*  59 */     this.beanWrapper = PropertyAccessorFactory.forBeanPropertyAccess(object);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasValue(String paramName) {
/*  65 */     return this.beanWrapper.isReadableProperty(paramName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getValue(String paramName) throws IllegalArgumentException {
/*     */     try {
/*  72 */       return this.beanWrapper.getPropertyValue(paramName);
/*     */     }
/*  74 */     catch (NotReadablePropertyException ex) {
/*  75 */       throw new IllegalArgumentException(ex.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSqlType(String paramName) {
/*  85 */     int sqlType = super.getSqlType(paramName);
/*  86 */     if (sqlType != Integer.MIN_VALUE) {
/*  87 */       return sqlType;
/*     */     }
/*  89 */     Class<?> propType = this.beanWrapper.getPropertyType(paramName);
/*  90 */     return StatementCreatorUtils.javaTypeToSqlParameterType(propType);
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public String[] getParameterNames() {
/*  96 */     return getReadablePropertyNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getReadablePropertyNames() {
/* 105 */     if (this.propertyNames == null) {
/* 106 */       List<String> names = new ArrayList<>();
/* 107 */       PropertyDescriptor[] props = this.beanWrapper.getPropertyDescriptors();
/* 108 */       for (PropertyDescriptor pd : props) {
/* 109 */         if (this.beanWrapper.isReadableProperty(pd.getName())) {
/* 110 */           names.add(pd.getName());
/*     */         }
/*     */       } 
/* 113 */       this.propertyNames = StringUtils.toStringArray(names);
/*     */     } 
/* 115 */     return this.propertyNames;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\namedparam\BeanPropertySqlParameterSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */