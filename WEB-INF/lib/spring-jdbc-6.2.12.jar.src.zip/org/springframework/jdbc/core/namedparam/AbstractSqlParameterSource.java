/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringJoiner;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSqlParameterSource
/*     */   implements SqlParameterSource
/*     */ {
/*  44 */   private final Map<String, Integer> sqlTypes = new HashMap<>();
/*     */   
/*  46 */   private final Map<String, String> typeNames = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerSqlType(String paramName, int sqlType) {
/*  55 */     Assert.notNull(paramName, "Parameter name must not be null");
/*  56 */     this.sqlTypes.put(paramName, Integer.valueOf(sqlType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerTypeName(String paramName, String typeName) {
/*  65 */     Assert.notNull(paramName, "Parameter name must not be null");
/*  66 */     this.typeNames.put(paramName, typeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSqlType(String paramName) {
/*  77 */     Assert.notNull(paramName, "Parameter name must not be null");
/*  78 */     return ((Integer)this.sqlTypes.getOrDefault(paramName, Integer.valueOf(-2147483648))).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getTypeName(String paramName) {
/*  90 */     Assert.notNull(paramName, "Parameter name must not be null");
/*  91 */     return this.typeNames.get(paramName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     String[] parameterNames = getParameterNames();
/* 104 */     if (parameterNames != null) {
/* 105 */       StringJoiner result = new StringJoiner(", ", getClass().getSimpleName() + " {", "}");
/* 106 */       for (String parameterName : parameterNames) {
/* 107 */         Object value = getValue(parameterName);
/* 108 */         if (value instanceof SqlParameterValue) { SqlParameterValue sqlParameterValue = (SqlParameterValue)value;
/* 109 */           value = sqlParameterValue.getValue(); }
/*     */         
/* 111 */         String typeName = getTypeName(parameterName);
/* 112 */         if (typeName == null) {
/* 113 */           int sqlType = getSqlType(parameterName);
/* 114 */           if (sqlType != Integer.MIN_VALUE) {
/* 115 */             typeName = JdbcUtils.resolveTypeName(sqlType);
/* 116 */             if (typeName == null) {
/* 117 */               typeName = String.valueOf(sqlType);
/*     */             }
/*     */           } 
/*     */         } 
/* 121 */         StringBuilder entry = new StringBuilder();
/* 122 */         entry.append(parameterName).append('=').append(value);
/* 123 */         if (typeName != null) {
/* 124 */           entry.append(" (type:").append(typeName).append(')');
/*     */         }
/* 126 */         result.add(entry);
/*     */       } 
/* 128 */       return result.toString();
/*     */     } 
/*     */     
/* 131 */     return getClass().getSimpleName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\namedparam\AbstractSqlParameterSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */