/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Stream;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.DataAccessUtils;
/*     */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.ColumnMapRowMapper;
/*     */ import org.springframework.jdbc.core.JdbcOperations;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.PreparedStatementCallback;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreatorFactory;
/*     */ import org.springframework.jdbc.core.ResultSetExtractor;
/*     */ import org.springframework.jdbc.core.RowCallbackHandler;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.SingleColumnRowMapper;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.jdbc.core.SqlRowSetResultSetExtractor;
/*     */ import org.springframework.jdbc.support.KeyHolder;
/*     */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentLruCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedParameterJdbcTemplate
/*     */   implements NamedParameterJdbcOperations
/*     */ {
/*     */   public static final int DEFAULT_CACHE_LIMIT = 256;
/*     */   private final JdbcOperations classicJdbcTemplate;
/*  89 */   private volatile ConcurrentLruCache<String, ParsedSql> parsedSqlCache = new ConcurrentLruCache(256, NamedParameterUtils::parseSqlStatement);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamedParameterJdbcTemplate(DataSource dataSource) {
/*  99 */     Assert.notNull(dataSource, "DataSource must not be null");
/* 100 */     this.classicJdbcTemplate = (JdbcOperations)new JdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamedParameterJdbcTemplate(JdbcOperations classicJdbcTemplate) {
/* 109 */     Assert.notNull(classicJdbcTemplate, "JdbcTemplate must not be null");
/* 110 */     this.classicJdbcTemplate = classicJdbcTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcOperations getJdbcOperations() {
/* 120 */     return this.classicJdbcTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcTemplate getJdbcTemplate() {
/* 131 */     Assert.state(this.classicJdbcTemplate instanceof JdbcTemplate, "No JdbcTemplate available");
/* 132 */     return (JdbcTemplate)this.classicJdbcTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCacheLimit(int cacheLimit) {
/* 140 */     this.parsedSqlCache = new ConcurrentLruCache(cacheLimit, NamedParameterUtils::parseSqlStatement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCacheLimit() {
/* 147 */     return this.parsedSqlCache.capacity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T execute(String sql, SqlParameterSource paramSource, PreparedStatementCallback<T> action) throws DataAccessException {
/* 156 */     return (T)getJdbcOperations().execute(getPreparedStatementCreator(sql, paramSource), action);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T execute(String sql, Map<String, ?> paramMap, PreparedStatementCallback<T> action) throws DataAccessException {
/* 164 */     return execute(sql, new MapSqlParameterSource(paramMap), action);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T execute(String sql, PreparedStatementCallback<T> action) throws DataAccessException {
/* 170 */     return execute(sql, EmptySqlParameterSource.INSTANCE, action);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T query(String sql, SqlParameterSource paramSource, ResultSetExtractor<T> rse) throws DataAccessException {
/* 178 */     return (T)getJdbcOperations().query(getPreparedStatementCreator(sql, paramSource), rse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T query(String sql, Map<String, ?> paramMap, ResultSetExtractor<T> rse) throws DataAccessException {
/* 186 */     return query(sql, new MapSqlParameterSource(paramMap), rse);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T query(String sql, ResultSetExtractor<T> rse) throws DataAccessException {
/* 192 */     return query(sql, EmptySqlParameterSource.INSTANCE, rse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void query(String sql, SqlParameterSource paramSource, RowCallbackHandler rch) throws DataAccessException {
/* 199 */     getJdbcOperations().query(getPreparedStatementCreator(sql, paramSource), rch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void query(String sql, Map<String, ?> paramMap, RowCallbackHandler rch) throws DataAccessException {
/* 206 */     query(sql, new MapSqlParameterSource(paramMap), rch);
/*     */   }
/*     */ 
/*     */   
/*     */   public void query(String sql, RowCallbackHandler rch) throws DataAccessException {
/* 211 */     query(sql, EmptySqlParameterSource.INSTANCE, rch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<T> query(String sql, SqlParameterSource paramSource, RowMapper<T> rowMapper) throws DataAccessException {
/* 218 */     return getJdbcOperations().query(getPreparedStatementCreator(sql, paramSource), rowMapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<T> query(String sql, Map<String, ?> paramMap, RowMapper<T> rowMapper) throws DataAccessException {
/* 225 */     return query(sql, new MapSqlParameterSource(paramMap), rowMapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> List<T> query(String sql, RowMapper<T> rowMapper) throws DataAccessException {
/* 230 */     return query(sql, EmptySqlParameterSource.INSTANCE, rowMapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Stream<T> queryForStream(String sql, SqlParameterSource paramSource, RowMapper<T> rowMapper) throws DataAccessException {
/* 237 */     return getJdbcOperations().queryForStream(getPreparedStatementCreator(sql, paramSource), rowMapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Stream<T> queryForStream(String sql, Map<String, ?> paramMap, RowMapper<T> rowMapper) throws DataAccessException {
/* 244 */     return queryForStream(sql, new MapSqlParameterSource(paramMap), rowMapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T queryForObject(String sql, SqlParameterSource paramSource, RowMapper<T> rowMapper) throws DataAccessException {
/* 252 */     List<T> results = getJdbcOperations().query(getPreparedStatementCreator(sql, paramSource), rowMapper);
/* 253 */     return (T)DataAccessUtils.nullableSingleResult(results);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T queryForObject(String sql, Map<String, ?> paramMap, RowMapper<T> rowMapper) throws DataAccessException {
/* 261 */     return queryForObject(sql, new MapSqlParameterSource(paramMap), rowMapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T queryForObject(String sql, SqlParameterSource paramSource, Class<T> requiredType) throws DataAccessException {
/* 269 */     return queryForObject(sql, paramSource, (RowMapper<T>)new SingleColumnRowMapper(requiredType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T queryForObject(String sql, Map<String, ?> paramMap, Class<T> requiredType) throws DataAccessException {
/* 277 */     return queryForObject(sql, paramMap, (RowMapper<T>)new SingleColumnRowMapper(requiredType));
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> queryForMap(String sql, SqlParameterSource paramSource) throws DataAccessException {
/* 282 */     Map<String, Object> result = queryForObject(sql, paramSource, (RowMapper<Map<String, Object>>)new ColumnMapRowMapper());
/* 283 */     Assert.state((result != null), "No result map");
/* 284 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> queryForMap(String sql, Map<String, ?> paramMap) throws DataAccessException {
/* 289 */     Map<String, Object> result = queryForObject(sql, paramMap, (RowMapper<Map<String, Object>>)new ColumnMapRowMapper());
/* 290 */     Assert.state((result != null), "No result map");
/* 291 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<T> queryForList(String sql, SqlParameterSource paramSource, Class<T> elementType) throws DataAccessException {
/* 298 */     return query(sql, paramSource, (RowMapper<T>)new SingleColumnRowMapper(elementType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<T> queryForList(String sql, Map<String, ?> paramMap, Class<T> elementType) throws DataAccessException {
/* 305 */     return queryForList(sql, new MapSqlParameterSource(paramMap), elementType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Map<String, Object>> queryForList(String sql, SqlParameterSource paramSource) throws DataAccessException {
/* 312 */     return query(sql, paramSource, (RowMapper<Map<String, Object>>)new ColumnMapRowMapper());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Map<String, Object>> queryForList(String sql, Map<String, ?> paramMap) throws DataAccessException {
/* 319 */     return queryForList(sql, new MapSqlParameterSource(paramMap));
/*     */   }
/*     */ 
/*     */   
/*     */   public SqlRowSet queryForRowSet(String sql, SqlParameterSource paramSource) throws DataAccessException {
/* 324 */     SqlRowSet result = (SqlRowSet)getJdbcOperations().query(
/* 325 */         getPreparedStatementCreator(sql, paramSource), (ResultSetExtractor)new SqlRowSetResultSetExtractor());
/* 326 */     Assert.state((result != null), "No result");
/* 327 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SqlRowSet queryForRowSet(String sql, Map<String, ?> paramMap) throws DataAccessException {
/* 332 */     return queryForRowSet(sql, new MapSqlParameterSource(paramMap));
/*     */   }
/*     */ 
/*     */   
/*     */   public int update(String sql, SqlParameterSource paramSource) throws DataAccessException {
/* 337 */     return getJdbcOperations().update(getPreparedStatementCreator(sql, paramSource));
/*     */   }
/*     */ 
/*     */   
/*     */   public int update(String sql, Map<String, ?> paramMap) throws DataAccessException {
/* 342 */     return update(sql, new MapSqlParameterSource(paramMap));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(String sql, SqlParameterSource paramSource, KeyHolder generatedKeyHolder) throws DataAccessException {
/* 349 */     return update(sql, paramSource, generatedKeyHolder, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(String sql, SqlParameterSource paramSource, KeyHolder generatedKeyHolder, @Nullable String[] keyColumnNames) throws DataAccessException {
/* 357 */     PreparedStatementCreator psc = getPreparedStatementCreator(sql, paramSource, pscf -> {
/*     */           if (keyColumnNames != null) {
/*     */             pscf.setGeneratedKeysColumnNames(keyColumnNames);
/*     */           } else {
/*     */             pscf.setReturnGeneratedKeys(true);
/*     */           } 
/*     */         });
/*     */     
/* 365 */     return getJdbcOperations().update(psc, generatedKeyHolder);
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] batchUpdate(String sql, final SqlParameterSource[] batchArgs) {
/* 370 */     if (batchArgs.length == 0) {
/* 371 */       return new int[0];
/*     */     }
/*     */     
/* 374 */     final ParsedSql parsedSql = getParsedSql(sql);
/* 375 */     final PreparedStatementCreatorFactory pscf = getPreparedStatementCreatorFactory(parsedSql, batchArgs[0]);
/*     */     
/* 377 */     return getJdbcOperations().batchUpdate(pscf
/* 378 */         .getSql(), new BatchPreparedStatementSetter()
/*     */         {
/*     */           public void setValues(PreparedStatement ps, int i) throws SQLException
/*     */           {
/* 382 */             Object[] values = NamedParameterUtils.buildValueArray(parsedSql, batchArgs[i], null);
/* 383 */             pscf.newPreparedStatementSetter(values).setValues(ps);
/*     */           }
/*     */           
/*     */           public int getBatchSize() {
/* 387 */             return batchArgs.length;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] batchUpdate(String sql, Map<String, ?>[] batchValues) {
/* 394 */     return batchUpdate(sql, SqlParameterSourceUtils.createBatch(batchValues));
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] batchUpdate(String sql, SqlParameterSource[] batchArgs, KeyHolder generatedKeyHolder) {
/* 399 */     return batchUpdate(sql, batchArgs, generatedKeyHolder, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] batchUpdate(String sql, final SqlParameterSource[] batchArgs, KeyHolder generatedKeyHolder, @Nullable String[] keyColumnNames) {
/* 406 */     if (batchArgs.length == 0) {
/* 407 */       return new int[0];
/*     */     }
/*     */     
/* 410 */     final ParsedSql parsedSql = getParsedSql(sql);
/* 411 */     SqlParameterSource paramSource = batchArgs[0];
/* 412 */     final PreparedStatementCreatorFactory pscf = getPreparedStatementCreatorFactory(parsedSql, paramSource);
/* 413 */     if (keyColumnNames != null) {
/* 414 */       pscf.setGeneratedKeysColumnNames(keyColumnNames);
/*     */     } else {
/*     */       
/* 417 */       pscf.setReturnGeneratedKeys(true);
/*     */     } 
/* 419 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, paramSource, null);
/* 420 */     PreparedStatementCreator psc = pscf.newPreparedStatementCreator(params);
/* 421 */     return getJdbcOperations().batchUpdate(psc, new BatchPreparedStatementSetter()
/*     */         {
/*     */           public void setValues(PreparedStatement ps, int i) throws SQLException {
/* 424 */             Object[] values = NamedParameterUtils.buildValueArray(parsedSql, batchArgs[i], null);
/* 425 */             pscf.newPreparedStatementSetter(values).setValues(ps);
/*     */           }
/*     */ 
/*     */           
/*     */           public int getBatchSize() {
/* 430 */             return batchArgs.length;
/*     */           }
/*     */         }generatedKeyHolder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PreparedStatementCreator getPreparedStatementCreator(String sql, SqlParameterSource paramSource) {
/* 446 */     return getPreparedStatementCreator(sql, paramSource, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PreparedStatementCreator getPreparedStatementCreator(String sql, SqlParameterSource paramSource, @Nullable Consumer<PreparedStatementCreatorFactory> customizer) {
/* 467 */     ParsedSql parsedSql = getParsedSql(sql);
/* 468 */     PreparedStatementCreatorFactory pscf = getPreparedStatementCreatorFactory(parsedSql, paramSource);
/* 469 */     if (customizer != null) {
/* 470 */       customizer.accept(pscf);
/*     */     }
/* 472 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, paramSource, null);
/* 473 */     return pscf.newPreparedStatementCreator(params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParsedSql getParsedSql(String sql) {
/* 483 */     Assert.notNull(sql, "SQL must not be null");
/* 484 */     return (ParsedSql)this.parsedSqlCache.get(sql);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PreparedStatementCreatorFactory getPreparedStatementCreatorFactory(ParsedSql parsedSql, SqlParameterSource paramSource) {
/* 499 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, paramSource);
/* 500 */     List<SqlParameter> declaredParameters = NamedParameterUtils.buildSqlParameterList(parsedSql, paramSource);
/* 501 */     return new PreparedStatementCreatorFactory(sqlToUse, declaredParameters);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\namedparam\NamedParameterJdbcTemplate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */