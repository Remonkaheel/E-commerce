/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.jdbc.core.StatementCreatorUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimplePropertySqlParameterSource
/*     */   extends AbstractSqlParameterSource
/*     */ {
/*  52 */   private static final Object NO_DESCRIPTOR = new Object();
/*     */   
/*     */   private final Object paramObject;
/*     */   
/*  56 */   private final Map<String, Object> propertyDescriptors = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimplePropertySqlParameterSource(Object paramObject) {
/*  64 */     Assert.notNull(paramObject, "Parameter object must not be null");
/*  65 */     this.paramObject = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasValue(String paramName) {
/*  71 */     return (getDescriptor(paramName) != NO_DESCRIPTOR);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getValue(String paramName) throws IllegalArgumentException {
/*  77 */     Object desc = getDescriptor(paramName);
/*  78 */     if (desc instanceof PropertyDescriptor) { PropertyDescriptor pd = (PropertyDescriptor)desc;
/*  79 */       ReflectionUtils.makeAccessible(pd.getReadMethod());
/*  80 */       return ReflectionUtils.invokeMethod(pd.getReadMethod(), this.paramObject); }
/*     */     
/*  82 */     if (desc instanceof Field) { Field field = (Field)desc;
/*  83 */       ReflectionUtils.makeAccessible(field);
/*  84 */       return ReflectionUtils.getField(field, this.paramObject); }
/*     */     
/*  86 */     throw new IllegalArgumentException("Cannot retrieve value for parameter '" + paramName + "' - neither a getter method nor a raw field found");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSqlType(String paramName) {
/*  96 */     int sqlType = super.getSqlType(paramName);
/*  97 */     if (sqlType != Integer.MIN_VALUE) {
/*  98 */       return sqlType;
/*     */     }
/* 100 */     Object desc = getDescriptor(paramName);
/* 101 */     if (desc instanceof PropertyDescriptor) { PropertyDescriptor pd = (PropertyDescriptor)desc;
/* 102 */       return StatementCreatorUtils.javaTypeToSqlParameterType(pd.getPropertyType()); }
/*     */     
/* 104 */     if (desc instanceof Field) { Field field = (Field)desc;
/* 105 */       return StatementCreatorUtils.javaTypeToSqlParameterType(field.getType()); }
/*     */     
/* 107 */     return Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */   private Object getDescriptor(String paramName) {
/* 111 */     return this.propertyDescriptors.computeIfAbsent(paramName, name -> {
/*     */           PropertyDescriptor pd = BeanUtils.getPropertyDescriptor(this.paramObject.getClass(), name);
/*     */           if (pd != null && pd.getReadMethod() != null)
/*     */             return pd; 
/*     */           Field field = ReflectionUtils.findField(this.paramObject.getClass(), name);
/*     */           return (field != null) ? field : NO_DESCRIPTOR;
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\namedparam\SimplePropertySqlParameterSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */