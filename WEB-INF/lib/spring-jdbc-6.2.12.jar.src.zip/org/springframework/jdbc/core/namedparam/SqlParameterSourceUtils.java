/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SqlParameterSourceUtils
/*     */ {
/*     */   public static SqlParameterSource[] createBatch(Object... candidates) {
/*  49 */     return createBatch(Arrays.asList(candidates));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SqlParameterSource[] createBatch(Collection<?> candidates) {
/*  65 */     SqlParameterSource[] batch = new SqlParameterSource[candidates.size()];
/*  66 */     int i = 0;
/*  67 */     for (Object candidate : candidates) {
/*  68 */       Map<String, ?> map = (Map)candidate; batch[i] = (candidate instanceof Map) ? new MapSqlParameterSource(map) : 
/*  69 */         new BeanPropertySqlParameterSource(candidate);
/*  70 */       i++;
/*     */     } 
/*  72 */     return batch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SqlParameterSource[] createBatch(Map<String, ?>[] valueMaps) {
/*  84 */     SqlParameterSource[] batch = new SqlParameterSource[valueMaps.length];
/*  85 */     for (int i = 0; i < valueMaps.length; i++) {
/*  86 */       batch[i] = new MapSqlParameterSource(valueMaps[i]);
/*     */     }
/*  88 */     return batch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Object getTypedValue(SqlParameterSource source, String parameterName) {
/* 100 */     int sqlType = source.getSqlType(parameterName);
/* 101 */     if (sqlType != Integer.MIN_VALUE) {
/* 102 */       return new SqlParameterValue(sqlType, source.getTypeName(parameterName), source.getValue(parameterName));
/*     */     }
/*     */     
/* 105 */     return source.getValue(parameterName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> extractCaseInsensitiveParameterNames(SqlParameterSource parameterSource) {
/* 115 */     Map<String, String> caseInsensitiveParameterNames = new HashMap<>();
/* 116 */     String[] paramNames = parameterSource.getParameterNames();
/* 117 */     if (paramNames != null) {
/* 118 */       for (String name : paramNames) {
/* 119 */         caseInsensitiveParameterNames.put(name.toLowerCase(Locale.ROOT), name);
/*     */       }
/*     */     }
/* 122 */     return caseInsensitiveParameterNames;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\namedparam\SqlParameterSourceUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */