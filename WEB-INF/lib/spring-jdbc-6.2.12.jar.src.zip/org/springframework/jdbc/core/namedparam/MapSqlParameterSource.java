/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapSqlParameterSource
/*     */   extends AbstractSqlParameterSource
/*     */ {
/*  49 */   private final Map<String, Object> values = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapSqlParameterSource(String paramName, @Nullable Object value) {
/*  68 */     addValue(paramName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapSqlParameterSource(@Nullable Map<String, ?> values) {
/*  76 */     addValues(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapSqlParameterSource addValue(String paramName, @Nullable Object value) {
/*  88 */     Assert.notNull(paramName, "Parameter name must not be null");
/*  89 */     this.values.put(paramName, value);
/*  90 */     if (value instanceof SqlParameterValue) { SqlParameterValue sqlParameterValue = (SqlParameterValue)value;
/*  91 */       registerSqlType(paramName, sqlParameterValue.getSqlType()); }
/*     */     
/*  93 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapSqlParameterSource addValue(String paramName, @Nullable Object value, int sqlType) {
/* 105 */     Assert.notNull(paramName, "Parameter name must not be null");
/* 106 */     this.values.put(paramName, value);
/* 107 */     registerSqlType(paramName, sqlType);
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapSqlParameterSource addValue(String paramName, @Nullable Object value, int sqlType, String typeName) {
/* 121 */     Assert.notNull(paramName, "Parameter name must not be null");
/* 122 */     this.values.put(paramName, value);
/* 123 */     registerSqlType(paramName, sqlType);
/* 124 */     registerTypeName(paramName, typeName);
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapSqlParameterSource addValues(@Nullable Map<String, ?> values) {
/* 135 */     if (values != null)
/* 136 */       values.forEach((key, value) -> {
/*     */             this.values.put(key, value);
/*     */             if (value instanceof SqlParameterValue) {
/*     */               SqlParameterValue sqlParameterValue = (SqlParameterValue)value;
/*     */               registerSqlType(key, sqlParameterValue.getSqlType());
/*     */             } 
/*     */           }); 
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasValues() {
/* 151 */     return !this.values.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getValues() {
/* 158 */     return Collections.unmodifiableMap(this.values);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasValue(String paramName) {
/* 164 */     return this.values.containsKey(paramName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getValue(String paramName) {
/* 170 */     if (!hasValue(paramName)) {
/* 171 */       throw new IllegalArgumentException("No value registered for key '" + paramName + "'");
/*     */     }
/* 173 */     return this.values.get(paramName);
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public String[] getParameterNames() {
/* 179 */     return StringUtils.toStringArray(this.values.keySet());
/*     */   }
/*     */   
/*     */   public MapSqlParameterSource() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\namedparam\MapSqlParameterSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */