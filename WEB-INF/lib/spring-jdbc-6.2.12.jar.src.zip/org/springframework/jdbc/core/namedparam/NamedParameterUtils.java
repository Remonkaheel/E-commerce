/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NamedParameterUtils
/*     */ {
/*  46 */   private static final String[] START_SKIP = new String[] { "'", "\"", "--", "/*", "`" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private static final String[] STOP_SKIP = new String[] { "'", "\"", "\n", "*/", "`" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PARAMETER_SEPARATORS = "\"':&,;()|=+-*%/\\<>^";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private static final boolean[] separatorIndex = new boolean[128];
/*     */   
/*     */   static {
/*  66 */     for (char c : "\"':&,;()|=+-*%/\\<>^".toCharArray()) {
/*  67 */       separatorIndex[c] = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ParsedSql parseSqlStatement(String sql) {
/*  83 */     Assert.notNull(sql, "SQL must not be null");
/*     */     
/*  85 */     Set<String> namedParameters = new HashSet<>();
/*  86 */     StringBuilder sqlToUse = new StringBuilder(sql);
/*  87 */     List<ParameterHolder> parameterList = new ArrayList<>();
/*     */     
/*  89 */     char[] statement = sql.toCharArray();
/*  90 */     int namedParameterCount = 0;
/*  91 */     int unnamedParameterCount = 0;
/*  92 */     int totalParameterCount = 0;
/*     */     
/*  94 */     int escapes = 0;
/*  95 */     int i = 0;
/*  96 */     while (i < statement.length) {
/*  97 */       int skipToPosition = i;
/*  98 */       while (i < statement.length) {
/*  99 */         skipToPosition = skipCommentsAndQuotes(statement, i);
/* 100 */         if (i == skipToPosition) {
/*     */           break;
/*     */         }
/*     */         
/* 104 */         i = skipToPosition;
/*     */       } 
/*     */       
/* 107 */       if (i >= statement.length) {
/*     */         break;
/*     */       }
/* 110 */       char c = statement[i];
/* 111 */       if (c == ':' || c == '&') {
/* 112 */         int j = i + 1;
/* 113 */         if (c == ':' && j < statement.length && statement[j] == ':') {
/*     */           
/* 115 */           i += 2;
/*     */           continue;
/*     */         } 
/* 118 */         String parameter = null;
/* 119 */         if (c == ':' && j < statement.length && statement[j] == '{') {
/*     */           
/* 121 */           while (statement[j] != '}') {
/* 122 */             j++;
/* 123 */             if (j >= statement.length) {
/* 124 */               throw new InvalidDataAccessApiUsageException("Non-terminated named parameter declaration at position " + i + " in statement: " + sql);
/*     */             }
/*     */ 
/*     */             
/* 128 */             if (statement[j] == ':' || statement[j] == '{') {
/* 129 */               throw new InvalidDataAccessApiUsageException("Parameter name contains invalid character '" + statement[j] + "' at position " + i + " in statement: " + sql);
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 134 */           if (j - i > 2) {
/* 135 */             parameter = sql.substring(i + 2, j);
/* 136 */             namedParameterCount = addNewNamedParameter(namedParameters, namedParameterCount, parameter);
/*     */             
/* 138 */             totalParameterCount = addNamedParameter(parameterList, totalParameterCount, escapes, i, j + 1, parameter);
/*     */           } 
/*     */           
/* 141 */           j++;
/*     */         } else {
/*     */           
/* 144 */           boolean paramWithSquareBrackets = false;
/* 145 */           while (j < statement.length) {
/* 146 */             c = statement[j];
/* 147 */             if (isParameterSeparator(c)) {
/*     */               break;
/*     */             }
/* 150 */             if (c == '[') {
/* 151 */               paramWithSquareBrackets = true;
/*     */             }
/* 153 */             else if (c == ']') {
/* 154 */               if (!paramWithSquareBrackets) {
/*     */                 break;
/*     */               }
/* 157 */               paramWithSquareBrackets = false;
/*     */             } 
/* 159 */             j++;
/*     */           } 
/* 161 */           if (j - i > 1) {
/* 162 */             parameter = sql.substring(i + 1, j);
/* 163 */             namedParameterCount = addNewNamedParameter(namedParameters, namedParameterCount, parameter);
/*     */             
/* 165 */             totalParameterCount = addNamedParameter(parameterList, totalParameterCount, escapes, i, j, parameter);
/*     */           } 
/*     */         } 
/*     */         
/* 169 */         i = j - 1;
/*     */       } else {
/*     */         
/* 172 */         if (c == '\\') {
/* 173 */           int j = i + 1;
/* 174 */           if (j < statement.length && statement[j] == ':') {
/*     */             
/* 176 */             sqlToUse.deleteCharAt(i - escapes);
/* 177 */             escapes++;
/* 178 */             i += 2;
/*     */             continue;
/*     */           } 
/*     */         } 
/* 182 */         if (c == '?') {
/* 183 */           int j = i + 1;
/* 184 */           if (j < statement.length && (statement[j] == '?' || statement[j] == '|' || statement[j] == '&')) {
/*     */             
/* 186 */             i += 2;
/*     */             continue;
/*     */           } 
/* 189 */           unnamedParameterCount++;
/* 190 */           totalParameterCount++;
/*     */         } 
/*     */       } 
/* 193 */       i++;
/*     */     } 
/* 195 */     ParsedSql parsedSql = new ParsedSql(sqlToUse.toString());
/* 196 */     for (ParameterHolder ph : parameterList) {
/* 197 */       parsedSql.addNamedParameter(ph.getParameterName(), ph.getStartIndex(), ph.getEndIndex());
/*     */     }
/* 199 */     parsedSql.setNamedParameterCount(namedParameterCount);
/* 200 */     parsedSql.setUnnamedParameterCount(unnamedParameterCount);
/* 201 */     parsedSql.setTotalParameterCount(totalParameterCount);
/* 202 */     return parsedSql;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int addNamedParameter(List<ParameterHolder> parameterList, int totalParameterCount, int escapes, int i, int j, String parameter) {
/* 208 */     parameterList.add(new ParameterHolder(parameter, i - escapes, j - escapes));
/* 209 */     totalParameterCount++;
/* 210 */     return totalParameterCount;
/*     */   }
/*     */   
/*     */   private static int addNewNamedParameter(Set<String> namedParameters, int namedParameterCount, String parameter) {
/* 214 */     if (!namedParameters.contains(parameter)) {
/* 215 */       namedParameters.add(parameter);
/* 216 */       namedParameterCount++;
/*     */     } 
/* 218 */     return namedParameterCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int skipCommentsAndQuotes(char[] statement, int position) {
/* 228 */     for (int i = 0; i < START_SKIP.length; i++) {
/* 229 */       if (statement[position] == START_SKIP[i].charAt(0)) {
/* 230 */         boolean match = true;
/* 231 */         for (int j = 1; j < START_SKIP[i].length(); j++) {
/* 232 */           if (statement[position + j] != START_SKIP[i].charAt(j)) {
/* 233 */             match = false;
/*     */             break;
/*     */           } 
/*     */         } 
/* 237 */         if (match) {
/* 238 */           int offset = START_SKIP[i].length();
/* 239 */           for (int m = position + offset; m < statement.length; m++) {
/* 240 */             if (statement[m] == STOP_SKIP[i].charAt(0)) {
/* 241 */               boolean endMatch = true;
/* 242 */               int endPos = m;
/* 243 */               for (int n = 1; n < STOP_SKIP[i].length(); n++) {
/* 244 */                 if (m + n >= statement.length)
/*     */                 {
/* 246 */                   return statement.length;
/*     */                 }
/* 248 */                 if (statement[m + n] != STOP_SKIP[i].charAt(n)) {
/* 249 */                   endMatch = false;
/*     */                   break;
/*     */                 } 
/* 252 */                 endPos = m + n;
/*     */               } 
/* 254 */               if (endMatch)
/*     */               {
/* 256 */                 return endPos + 1;
/*     */               }
/*     */             } 
/*     */           } 
/*     */           
/* 261 */           return statement.length;
/*     */         } 
/*     */       } 
/*     */     } 
/* 265 */     return position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String substituteNamedParameters(ParsedSql parsedSql, @Nullable SqlParameterSource paramSource) {
/* 287 */     String originalSql = parsedSql.getOriginalSql();
/* 288 */     List<String> paramNames = parsedSql.getParameterNames();
/* 289 */     if (paramNames.isEmpty()) {
/* 290 */       return originalSql;
/*     */     }
/*     */     
/* 293 */     StringBuilder actualSql = new StringBuilder(originalSql.length());
/* 294 */     int lastIndex = 0;
/* 295 */     for (int i = 0; i < paramNames.size(); i++) {
/* 296 */       String paramName = paramNames.get(i);
/* 297 */       int[] indexes = parsedSql.getParameterIndexes(i);
/* 298 */       int startIndex = indexes[0];
/* 299 */       int endIndex = indexes[1];
/* 300 */       actualSql.append(originalSql, lastIndex, startIndex);
/* 301 */       if (paramSource != null && paramSource.hasValue(paramName)) {
/* 302 */         Object value = paramSource.getValue(paramName);
/* 303 */         if (value instanceof SqlParameterValue) { SqlParameterValue sqlParameterValue = (SqlParameterValue)value;
/* 304 */           value = sqlParameterValue.getValue(); }
/*     */         
/* 306 */         if (value instanceof Iterable) { Iterable<?> iterable = (Iterable)value;
/* 307 */           int k = 0;
/* 308 */           for (Object entryItem : iterable) {
/* 309 */             if (k > 0) {
/* 310 */               actualSql.append(", ");
/*     */             }
/* 312 */             k++;
/* 313 */             if (entryItem instanceof Object[]) { Object[] expressionList = (Object[])entryItem;
/* 314 */               actualSql.append('(');
/* 315 */               for (int m = 0; m < expressionList.length; m++) {
/* 316 */                 if (m > 0) {
/* 317 */                   actualSql.append(", ");
/*     */                 }
/* 319 */                 actualSql.append('?');
/*     */               } 
/* 321 */               actualSql.append(')');
/*     */               continue; }
/*     */             
/* 324 */             actualSql.append('?');
/*     */           }
/*     */            }
/*     */         else
/*     */         
/* 329 */         { actualSql.append('?'); }
/*     */       
/*     */       } else {
/*     */         
/* 333 */         actualSql.append('?');
/*     */       } 
/* 335 */       lastIndex = endIndex;
/*     */     } 
/* 337 */     actualSql.append(originalSql, lastIndex, originalSql.length());
/* 338 */     return actualSql.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object[] buildValueArray(ParsedSql parsedSql, SqlParameterSource paramSource, @Nullable List<SqlParameter> declaredParams) {
/* 353 */     Object[] paramArray = new Object[parsedSql.getTotalParameterCount()];
/* 354 */     if (parsedSql.getNamedParameterCount() > 0 && parsedSql.getUnnamedParameterCount() > 0) {
/* 355 */       throw new InvalidDataAccessApiUsageException("Not allowed to mix named and traditional ? placeholders. You have " + parsedSql
/*     */           
/* 357 */           .getNamedParameterCount() + " named parameter(s) and " + parsedSql
/* 358 */           .getUnnamedParameterCount() + " traditional placeholder(s) in statement: " + parsedSql
/* 359 */           .getOriginalSql());
/*     */     }
/* 361 */     List<String> paramNames = parsedSql.getParameterNames();
/* 362 */     for (int i = 0; i < paramNames.size(); i++) {
/* 363 */       String paramName = paramNames.get(i);
/*     */       try {
/* 365 */         SqlParameter param = findParameter(declaredParams, paramName, i);
/* 366 */         Object paramValue = paramSource.getValue(paramName);
/* 367 */         if (paramValue instanceof SqlParameterValue) {
/* 368 */           paramArray[i] = paramValue;
/*     */         } else {
/*     */           
/* 371 */           paramArray[i] = (param != null) ? new SqlParameterValue(param, paramValue) : 
/* 372 */             SqlParameterSourceUtils.getTypedValue(paramSource, paramName);
/*     */         }
/*     */       
/* 375 */       } catch (IllegalArgumentException ex) {
/* 376 */         throw new InvalidDataAccessApiUsageException("No value supplied for the SQL parameter '" + paramName + "': " + ex
/* 377 */             .getMessage());
/*     */       } 
/*     */     } 
/* 380 */     return paramArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static SqlParameter findParameter(@Nullable List<SqlParameter> declaredParams, String paramName, int paramIndex) {
/* 394 */     if (declaredParams != null) {
/*     */       
/* 396 */       for (SqlParameter declaredParam : declaredParams) {
/* 397 */         if (paramName.equals(declaredParam.getName())) {
/* 398 */           return declaredParam;
/*     */         }
/*     */       } 
/*     */       
/* 402 */       if (paramIndex < declaredParams.size()) {
/* 403 */         SqlParameter declaredParam = declaredParams.get(paramIndex);
/*     */         
/* 405 */         if (declaredParam.getName() == null) {
/* 406 */           return declaredParam;
/*     */         }
/*     */       } 
/*     */     } 
/* 410 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isParameterSeparator(char c) {
/* 418 */     return ((c < '' && separatorIndex[c]) || Character.isWhitespace(c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] buildSqlTypeArray(ParsedSql parsedSql, SqlParameterSource paramSource) {
/* 430 */     int[] sqlTypes = new int[parsedSql.getTotalParameterCount()];
/* 431 */     List<String> paramNames = parsedSql.getParameterNames();
/* 432 */     for (int i = 0; i < paramNames.size(); i++) {
/* 433 */       String paramName = paramNames.get(i);
/* 434 */       sqlTypes[i] = paramSource.getSqlType(paramName);
/*     */     } 
/* 436 */     return sqlTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<SqlParameter> buildSqlParameterList(ParsedSql parsedSql, SqlParameterSource paramSource) {
/* 448 */     List<String> paramNames = parsedSql.getParameterNames();
/* 449 */     List<SqlParameter> params = new ArrayList<>(paramNames.size());
/* 450 */     for (String paramName : paramNames) {
/* 451 */       params.add(new SqlParameter(paramName, paramSource
/* 452 */             .getSqlType(paramName), paramSource.getTypeName(paramName)));
/*     */     }
/* 454 */     return params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String parseSqlStatementIntoString(String sql) {
/* 472 */     ParsedSql parsedSql = parseSqlStatement(sql);
/* 473 */     return substituteNamedParameters(parsedSql, (SqlParameterSource)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String substituteNamedParameters(String sql, SqlParameterSource paramSource) {
/* 488 */     ParsedSql parsedSql = parseSqlStatement(sql);
/* 489 */     return substituteNamedParameters(parsedSql, paramSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object[] buildValueArray(String sql, Map<String, ?> paramMap) {
/* 501 */     ParsedSql parsedSql = parseSqlStatement(sql);
/* 502 */     return buildValueArray(parsedSql, new MapSqlParameterSource(paramMap), null);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ParameterHolder
/*     */   {
/*     */     private final String parameterName;
/*     */     
/*     */     private final int startIndex;
/*     */     
/*     */     private final int endIndex;
/*     */     
/*     */     public ParameterHolder(String parameterName, int startIndex, int endIndex) {
/* 515 */       this.parameterName = parameterName;
/* 516 */       this.startIndex = startIndex;
/* 517 */       this.endIndex = endIndex;
/*     */     }
/*     */     
/*     */     public String getParameterName() {
/* 521 */       return this.parameterName;
/*     */     }
/*     */     
/*     */     public int getStartIndex() {
/* 525 */       return this.startIndex;
/*     */     }
/*     */     
/*     */     public int getEndIndex() {
/* 529 */       return this.endIndex;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\namedparam\NamedParameterUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */