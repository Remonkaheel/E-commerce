/*    */ package org.springframework.jdbc.core.namedparam;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000 \n\000\n\002\020\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\000\n\000\n\002\020\b\n\002\b\002\032\037\020\000\032\0020\001*\0020\0022\006\020\003\032\0020\0042\b\020\005\032\004\030\0010\006H\002\032'\020\000\032\0020\001*\0020\0022\006\020\003\032\0020\0042\006\020\007\032\0020\b2\b\020\005\032\004\030\0010\006H\002\032/\020\000\032\0020\001*\0020\0022\006\020\003\032\0020\0042\006\020\007\032\0020\b2\006\020\t\032\0020\0042\b\020\005\032\004\030\0010\006H\002¨\006\n"}, d2 = {"set", "", "Lorg/springframework/jdbc/core/namedparam/MapSqlParameterSource;", "paramName", "", "value", "", "sqlType", "", "typeName", "spring-jdbc"})
/*    */ public final class MapSqlParameterSourceExtensionsKt
/*    */ {
/*    */   public static final void set(@NotNull MapSqlParameterSource $this$set, @NotNull String paramName, @Nullable Object value) {
/* 30 */     Intrinsics.checkNotNullParameter($this$set, "<this>"); Intrinsics.checkNotNullParameter(paramName, "paramName"); $this$set.addValue(paramName, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final void set(@NotNull MapSqlParameterSource $this$set, @NotNull String paramName, int sqlType, @Nullable Object value) {
/* 44 */     Intrinsics.checkNotNullParameter($this$set, "<this>"); Intrinsics.checkNotNullParameter(paramName, "paramName"); $this$set.addValue(paramName, value, sqlType);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final void set(@NotNull MapSqlParameterSource $this$set, @NotNull String paramName, int sqlType, @NotNull String typeName, @Nullable Object value) {
/* 58 */     Intrinsics.checkNotNullParameter($this$set, "<this>"); Intrinsics.checkNotNullParameter(paramName, "paramName"); Intrinsics.checkNotNullParameter(typeName, "typeName"); $this$set.addValue(paramName, value, sqlType, typeName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\namedparam\MapSqlParameterSourceExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */