/*    */ package org.springframework.jdbc.core.namedparam;
/*    */ 
/*    */ import org.springframework.jdbc.core.JdbcOperations;
/*    */ import org.springframework.jdbc.core.JdbcTemplate;
/*    */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamedParameterJdbcDaoSupport
/*    */   extends JdbcDaoSupport
/*    */ {
/*    */   @Nullable
/*    */   private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
/*    */   
/*    */   protected void initTemplateConfig() {
/* 42 */     JdbcTemplate jdbcTemplate = getJdbcTemplate();
/* 43 */     if (jdbcTemplate != null) {
/* 44 */       this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate((JdbcOperations)jdbcTemplate);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate() {
/* 53 */     return this.namedParameterJdbcTemplate;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\namedparam\NamedParameterJdbcDaoSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */