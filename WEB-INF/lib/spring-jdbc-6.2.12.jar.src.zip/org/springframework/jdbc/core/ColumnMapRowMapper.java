/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.ResultSetMetaData;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Map;
/*    */ import org.springframework.jdbc.support.JdbcUtils;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColumnMapRowMapper
/*    */   implements RowMapper<Map<String, Object>>
/*    */ {
/*    */   public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 50 */     ResultSetMetaData rsmd = rs.getMetaData();
/* 51 */     int columnCount = rsmd.getColumnCount();
/* 52 */     Map<String, Object> mapOfColumnValues = createColumnMap(columnCount);
/* 53 */     for (int i = 1; i <= columnCount; i++) {
/* 54 */       String column = JdbcUtils.lookupColumnName(rsmd, i);
/* 55 */       mapOfColumnValues.putIfAbsent(getColumnKey(column), getColumnValue(rs, i));
/*    */     } 
/* 57 */     return mapOfColumnValues;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Map<String, Object> createColumnMap(int columnCount) {
/* 69 */     return (Map<String, Object>)new LinkedCaseInsensitiveMap(columnCount);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getColumnKey(String columnName) {
/* 80 */     return columnName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   protected Object getColumnValue(ResultSet rs, int index) throws SQLException {
/* 95 */     return JdbcUtils.getResultSetValue(rs, index);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\ColumnMapRowMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */