/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultSetSupportingSqlParameter
/*     */   extends SqlParameter
/*     */ {
/*     */   @Nullable
/*     */   private ResultSetExtractor<?> resultSetExtractor;
/*     */   @Nullable
/*     */   private RowCallbackHandler rowCallbackHandler;
/*     */   @Nullable
/*     */   private RowMapper<?> rowMapper;
/*     */   
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType) {
/*  48 */     super(name, sqlType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType, int scale) {
/*  59 */     super(name, sqlType, scale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType, @Nullable String typeName) {
/*  69 */     super(name, sqlType, typeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType, ResultSetExtractor<?> rse) {
/*  79 */     super(name, sqlType);
/*  80 */     this.resultSetExtractor = rse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType, RowCallbackHandler rch) {
/*  90 */     super(name, sqlType);
/*  91 */     this.rowCallbackHandler = rch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType, RowMapper<?> rm) {
/* 101 */     super(name, sqlType);
/* 102 */     this.rowMapper = rm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResultSetSupported() {
/* 111 */     return (this.resultSetExtractor != null || this.rowCallbackHandler != null || this.rowMapper != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ResultSetExtractor<?> getResultSetExtractor() {
/* 119 */     return this.resultSetExtractor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public RowCallbackHandler getRowCallbackHandler() {
/* 127 */     return this.rowCallbackHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public RowMapper<?> getRowMapper() {
/* 135 */     return this.rowMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInputValueProvided() {
/* 144 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\ResultSetSupportingSqlParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */