package org.springframework.jdbc.core;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface ResultSetExtractor<T> {
  @Nullable
  T extractData(ResultSet paramResultSet) throws SQLException, DataAccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\core\ResultSetExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */