/*    */ package org.springframework.jdbc.support;
/*    */ 
/*    */ import java.sql.Array;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.DataAccessResourceFailureException;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlArrayValue
/*    */   implements SqlValue
/*    */ {
/*    */   private final String typeName;
/*    */   private final Object[] elements;
/*    */   @Nullable
/*    */   private Array array;
/*    */   
/*    */   public SqlArrayValue(String typeName, Object... elements) {
/* 55 */     Assert.notNull(typeName, "Type name must not be null");
/* 56 */     Assert.notNull(elements, "Elements array must not be null");
/* 57 */     this.typeName = typeName;
/* 58 */     this.elements = elements;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(PreparedStatement ps, int paramIndex) throws SQLException {
/* 64 */     this.array = ps.getConnection().createArrayOf(this.typeName, this.elements);
/* 65 */     ps.setArray(paramIndex, this.array);
/*    */   }
/*    */ 
/*    */   
/*    */   public void cleanup() {
/* 70 */     if (this.array != null)
/*    */       try {
/* 72 */         this.array.free();
/*    */       }
/* 74 */       catch (SQLException ex) {
/* 75 */         throw new DataAccessResourceFailureException("Could not free Array object", ex);
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\SqlArrayValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */