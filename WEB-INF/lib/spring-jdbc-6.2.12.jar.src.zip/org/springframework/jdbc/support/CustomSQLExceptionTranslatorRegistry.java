/*    */ package org.springframework.jdbc.support;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CustomSQLExceptionTranslatorRegistry
/*    */ {
/* 38 */   private static final Log logger = LogFactory.getLog(CustomSQLExceptionTranslatorRegistry.class);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   private static final CustomSQLExceptionTranslatorRegistry instance = new CustomSQLExceptionTranslatorRegistry();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static CustomSQLExceptionTranslatorRegistry getInstance() {
/* 50 */     return instance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 59 */   private final Map<String, SQLExceptionTranslator> translatorMap = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerTranslator(String dbName, SQLExceptionTranslator translator) {
/* 76 */     SQLExceptionTranslator replaced = this.translatorMap.put(dbName, translator);
/* 77 */     if (logger.isDebugEnabled()) {
/* 78 */       if (replaced != null) {
/* 79 */         logger.debug("Replacing custom translator [" + String.valueOf(replaced) + "] for database '" + dbName + "' with [" + String.valueOf(translator) + "]");
/*    */       }
/*    */       else {
/*    */         
/* 83 */         logger.debug("Adding custom translator of type [" + translator.getClass().getName() + "] for database '" + dbName + "'");
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public SQLExceptionTranslator findTranslatorForDatabase(String dbName) {
/* 96 */     return this.translatorMap.get(dbName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\CustomSQLExceptionTranslatorRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */