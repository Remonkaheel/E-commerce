/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.jdbc.datasource.DataSourceTransactionManager;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdbcTransactionManager
/*     */   extends DataSourceTransactionManager
/*     */ {
/*     */   @Nullable
/*     */   private volatile SQLExceptionTranslator exceptionTranslator;
/*     */   private boolean lazyInit = true;
/*     */   
/*     */   public JdbcTransactionManager() {}
/*     */   
/*     */   public JdbcTransactionManager(DataSource dataSource) {
/*  75 */     this();
/*  76 */     setDataSource(dataSource);
/*  77 */     afterPropertiesSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabaseProductName(String dbName) {
/*  93 */     if (SQLErrorCodeSQLExceptionTranslator.hasUserProvidedErrorCodesFile()) {
/*  94 */       this.exceptionTranslator = new SQLErrorCodeSQLExceptionTranslator(dbName);
/*     */     } else {
/*     */       
/*  97 */       this.exceptionTranslator = new SQLExceptionSubclassTranslator();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExceptionTranslator(SQLExceptionTranslator exceptionTranslator) {
/* 111 */     this.exceptionTranslator = exceptionTranslator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLExceptionTranslator getExceptionTranslator() {
/* 120 */     SQLExceptionTranslator exceptionTranslator = this.exceptionTranslator;
/* 121 */     if (exceptionTranslator != null) {
/* 122 */       return exceptionTranslator;
/*     */     }
/* 124 */     synchronized (this) {
/* 125 */       exceptionTranslator = this.exceptionTranslator;
/* 126 */       if (exceptionTranslator == null) {
/* 127 */         if (SQLErrorCodeSQLExceptionTranslator.hasUserProvidedErrorCodesFile()) {
/* 128 */           exceptionTranslator = new SQLErrorCodeSQLExceptionTranslator(obtainDataSource());
/*     */         } else {
/*     */           
/* 131 */           exceptionTranslator = new SQLExceptionSubclassTranslator();
/*     */         } 
/* 133 */         this.exceptionTranslator = exceptionTranslator;
/*     */       } 
/* 135 */       return exceptionTranslator;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLazyInit(boolean lazyInit) {
/* 148 */     this.lazyInit = lazyInit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLazyInit() {
/* 156 */     return this.lazyInit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 165 */     super.afterPropertiesSet();
/* 166 */     if (!isLazyInit()) {
/* 167 */       getExceptionTranslator();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RuntimeException translateException(String task, SQLException ex) {
/* 180 */     DataAccessException dae = getExceptionTranslator().translate(task, null, ex);
/* 181 */     if (dae != null) {
/* 182 */       return (RuntimeException)dae;
/*     */     }
/* 184 */     return super.translateException(task, ex);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\JdbcTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */