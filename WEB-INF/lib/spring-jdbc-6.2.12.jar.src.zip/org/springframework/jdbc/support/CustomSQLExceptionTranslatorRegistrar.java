/*    */ package org.springframework.jdbc.support;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CustomSQLExceptionTranslatorRegistrar
/*    */   implements InitializingBean
/*    */ {
/* 37 */   private final Map<String, SQLExceptionTranslator> translators = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTranslators(Map<String, SQLExceptionTranslator> translators) {
/* 47 */     this.translators.putAll(translators);
/*    */   }
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() {
/* 52 */     this.translators.forEach((dbName, translator) -> CustomSQLExceptionTranslatorRegistry.getInstance().registerTranslator(dbName, translator));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\CustomSQLExceptionTranslatorRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */