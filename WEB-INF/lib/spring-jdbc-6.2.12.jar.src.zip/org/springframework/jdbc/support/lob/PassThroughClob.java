/*     */ package org.springframework.jdbc.support.lob;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.sql.Clob;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ class PassThroughClob
/*     */   implements Clob
/*     */ {
/*     */   @Nullable
/*     */   private String content;
/*     */   @Nullable
/*     */   private Reader characterStream;
/*     */   @Nullable
/*     */   private InputStream asciiStream;
/*     */   private final long contentLength;
/*     */   
/*     */   public PassThroughClob(String content) {
/*  57 */     this.content = content;
/*  58 */     this.contentLength = content.length();
/*     */   }
/*     */   
/*     */   public PassThroughClob(Reader characterStream, long contentLength) {
/*  62 */     this.characterStream = characterStream;
/*  63 */     this.contentLength = contentLength;
/*     */   }
/*     */   
/*     */   public PassThroughClob(InputStream asciiStream, long contentLength) {
/*  67 */     this.asciiStream = asciiStream;
/*  68 */     this.contentLength = contentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long length() throws SQLException {
/*  74 */     return this.contentLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public Reader getCharacterStream() throws SQLException {
/*  79 */     if (this.content != null) {
/*  80 */       return new StringReader(this.content);
/*     */     }
/*  82 */     if (this.characterStream != null) {
/*  83 */       return this.characterStream;
/*     */     }
/*     */     
/*  86 */     return new InputStreamReader(
/*  87 */         (this.asciiStream != null) ? this.asciiStream : InputStream.nullInputStream(), StandardCharsets.US_ASCII);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getAsciiStream() throws SQLException {
/*     */     try {
/*  95 */       if (this.content != null) {
/*  96 */         return new ByteArrayInputStream(this.content.getBytes(StandardCharsets.US_ASCII));
/*     */       }
/*  98 */       if (this.characterStream != null) {
/*  99 */         String tempContent = FileCopyUtils.copyToString(this.characterStream);
/* 100 */         return new ByteArrayInputStream(tempContent.getBytes(StandardCharsets.US_ASCII));
/*     */       } 
/*     */       
/* 103 */       return (this.asciiStream != null) ? this.asciiStream : InputStream.nullInputStream();
/*     */     
/*     */     }
/* 106 */     catch (IOException ex) {
/* 107 */       throw new SQLException("Failed to read stream content: " + String.valueOf(ex));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Reader getCharacterStream(long pos, long length) throws SQLException {
/* 114 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Writer setCharacterStream(long pos) throws SQLException {
/* 119 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream setAsciiStream(long pos) throws SQLException {
/* 124 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSubString(long pos, int length) throws SQLException {
/* 129 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int setString(long pos, String str) throws SQLException {
/* 134 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int setString(long pos, String str, int offset, int len) throws SQLException {
/* 139 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public long position(String searchstr, long start) throws SQLException {
/* 144 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public long position(Clob searchstr, long start) throws SQLException {
/* 149 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void truncate(long len) throws SQLException {
/* 154 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void free() throws SQLException {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\lob\PassThroughClob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */