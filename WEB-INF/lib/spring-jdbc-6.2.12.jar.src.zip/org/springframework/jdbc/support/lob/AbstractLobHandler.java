/*    */ package org.springframework.jdbc.support.lob;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.2")
/*    */ public abstract class AbstractLobHandler
/*    */   implements LobHandler
/*    */ {
/*    */   @Nullable
/*    */   public byte[] getBlobAsBytes(ResultSet rs, String columnName) throws SQLException {
/* 44 */     return getBlobAsBytes(rs, rs.findColumn(columnName));
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public InputStream getBlobAsBinaryStream(ResultSet rs, String columnName) throws SQLException {
/* 50 */     return getBlobAsBinaryStream(rs, rs.findColumn(columnName));
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getClobAsString(ResultSet rs, String columnName) throws SQLException {
/* 56 */     return getClobAsString(rs, rs.findColumn(columnName));
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public InputStream getClobAsAsciiStream(ResultSet rs, String columnName) throws SQLException {
/* 62 */     return getClobAsAsciiStream(rs, rs.findColumn(columnName));
/*    */   }
/*    */ 
/*    */   
/*    */   public Reader getClobAsCharacterStream(ResultSet rs, String columnName) throws SQLException {
/* 67 */     return getClobAsCharacterStream(rs, rs.findColumn(columnName));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\lob\AbstractLobHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */