/*     */ package org.springframework.jdbc.support.lob;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.sql.Blob;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ class PassThroughBlob
/*     */   implements Blob
/*     */ {
/*     */   @Nullable
/*     */   private byte[] content;
/*     */   @Nullable
/*     */   private InputStream binaryStream;
/*     */   private final long contentLength;
/*     */   
/*     */   public PassThroughBlob(byte[] content) {
/*  47 */     this.content = content;
/*  48 */     this.contentLength = content.length;
/*     */   }
/*     */   
/*     */   public PassThroughBlob(InputStream binaryStream, long contentLength) {
/*  52 */     this.binaryStream = binaryStream;
/*  53 */     this.contentLength = contentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long length() throws SQLException {
/*  59 */     return this.contentLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getBinaryStream() throws SQLException {
/*  64 */     if (this.content != null) {
/*  65 */       return new ByteArrayInputStream(this.content);
/*     */     }
/*     */     
/*  68 */     return (this.binaryStream != null) ? this.binaryStream : InputStream.nullInputStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getBinaryStream(long pos, long length) throws SQLException {
/*  75 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream setBinaryStream(long pos) throws SQLException {
/*  80 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBytes(long pos, int length) throws SQLException {
/*  85 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int setBytes(long pos, byte[] bytes) throws SQLException {
/*  90 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int setBytes(long pos, byte[] bytes, int offset, int len) throws SQLException {
/*  95 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public long position(byte[] pattern, long start) throws SQLException {
/* 100 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public long position(Blob pattern, long start) throws SQLException {
/* 105 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void truncate(long len) throws SQLException {
/* 110 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void free() throws SQLException {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\lob\PassThroughBlob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */