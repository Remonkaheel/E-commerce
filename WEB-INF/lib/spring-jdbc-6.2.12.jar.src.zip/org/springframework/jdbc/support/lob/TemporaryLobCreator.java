/*     */ package org.springframework.jdbc.support.lob;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(since = "6.2")
/*     */ public class TemporaryLobCreator
/*     */   implements LobCreator
/*     */ {
/*  55 */   protected static final Log logger = LogFactory.getLog(TemporaryLobCreator.class);
/*     */   
/*  57 */   private final Set<Blob> temporaryBlobs = new LinkedHashSet<>(1);
/*     */   
/*  59 */   private final Set<Clob> temporaryClobs = new LinkedHashSet<>(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlobAsBytes(PreparedStatement ps, int paramIndex, @Nullable byte[] content) throws SQLException {
/*  66 */     if (content != null) {
/*  67 */       Blob blob = ps.getConnection().createBlob();
/*  68 */       blob.setBytes(1L, content);
/*  69 */       this.temporaryBlobs.add(blob);
/*  70 */       ps.setBlob(paramIndex, blob);
/*     */     } else {
/*     */       
/*  73 */       ps.setBlob(paramIndex, (Blob)null);
/*     */     } 
/*     */     
/*  76 */     if (logger.isDebugEnabled()) {
/*  77 */       logger.debug((content != null) ? ("Copied bytes into temporary BLOB with length " + content.length) : 
/*  78 */           "Set BLOB to null");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlobAsBinaryStream(PreparedStatement ps, int paramIndex, @Nullable InputStream binaryStream, int contentLength) throws SQLException {
/*  87 */     if (binaryStream != null) {
/*  88 */       Blob blob = ps.getConnection().createBlob();
/*     */       try {
/*  90 */         FileCopyUtils.copy(binaryStream, blob.setBinaryStream(1L));
/*     */       }
/*  92 */       catch (IOException ex) {
/*  93 */         throw new DataAccessResourceFailureException("Could not copy into LOB stream", ex);
/*     */       } 
/*  95 */       this.temporaryBlobs.add(blob);
/*  96 */       ps.setBlob(paramIndex, blob);
/*     */     } else {
/*     */       
/*  99 */       ps.setBlob(paramIndex, (Blob)null);
/*     */     } 
/*     */     
/* 102 */     if (logger.isDebugEnabled()) {
/* 103 */       logger.debug((binaryStream != null) ? ("Copied binary stream into temporary BLOB with length " + 
/* 104 */           contentLength) : 
/* 105 */           "Set BLOB to null");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClobAsString(PreparedStatement ps, int paramIndex, @Nullable String content) throws SQLException {
/* 113 */     if (content != null) {
/* 114 */       Clob clob = ps.getConnection().createClob();
/* 115 */       clob.setString(1L, content);
/* 116 */       this.temporaryClobs.add(clob);
/* 117 */       ps.setClob(paramIndex, clob);
/*     */     } else {
/*     */       
/* 120 */       ps.setClob(paramIndex, (Clob)null);
/*     */     } 
/*     */     
/* 123 */     if (logger.isDebugEnabled()) {
/* 124 */       logger.debug((content != null) ? ("Copied string into temporary CLOB with length " + content.length()) : 
/* 125 */           "Set CLOB to null");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClobAsAsciiStream(PreparedStatement ps, int paramIndex, @Nullable InputStream asciiStream, int contentLength) throws SQLException {
/* 134 */     if (asciiStream != null) {
/* 135 */       Clob clob = ps.getConnection().createClob();
/*     */       try {
/* 137 */         FileCopyUtils.copy(asciiStream, clob.setAsciiStream(1L));
/*     */       }
/* 139 */       catch (IOException ex) {
/* 140 */         throw new DataAccessResourceFailureException("Could not copy into LOB stream", ex);
/*     */       } 
/* 142 */       this.temporaryClobs.add(clob);
/* 143 */       ps.setClob(paramIndex, clob);
/*     */     } else {
/*     */       
/* 146 */       ps.setClob(paramIndex, (Clob)null);
/*     */     } 
/*     */     
/* 149 */     if (logger.isDebugEnabled()) {
/* 150 */       logger.debug((asciiStream != null) ? ("Copied ASCII stream into temporary CLOB with length " + 
/* 151 */           contentLength) : 
/* 152 */           "Set CLOB to null");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClobAsCharacterStream(PreparedStatement ps, int paramIndex, @Nullable Reader characterStream, int contentLength) throws SQLException {
/* 161 */     if (characterStream != null) {
/* 162 */       Clob clob = ps.getConnection().createClob();
/*     */       try {
/* 164 */         FileCopyUtils.copy(characterStream, clob.setCharacterStream(1L));
/*     */       }
/* 166 */       catch (IOException ex) {
/* 167 */         throw new DataAccessResourceFailureException("Could not copy into LOB stream", ex);
/*     */       } 
/* 169 */       this.temporaryClobs.add(clob);
/* 170 */       ps.setClob(paramIndex, clob);
/*     */     } else {
/*     */       
/* 173 */       ps.setClob(paramIndex, (Clob)null);
/*     */     } 
/*     */     
/* 176 */     if (logger.isDebugEnabled()) {
/* 177 */       logger.debug((characterStream != null) ? ("Copied character stream into temporary CLOB with length " + 
/* 178 */           contentLength) : 
/* 179 */           "Set CLOB to null");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 185 */     for (Blob blob : this.temporaryBlobs) {
/*     */       try {
/* 187 */         blob.free();
/*     */       }
/* 189 */       catch (SQLException ex) {
/* 190 */         logger.warn("Could not free BLOB", ex);
/*     */       } 
/*     */     } 
/* 193 */     for (Clob clob : this.temporaryClobs) {
/*     */       try {
/* 195 */         clob.free();
/*     */       }
/* 197 */       catch (SQLException ex) {
/* 198 */         logger.warn("Could not free CLOB", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\lob\TemporaryLobCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */