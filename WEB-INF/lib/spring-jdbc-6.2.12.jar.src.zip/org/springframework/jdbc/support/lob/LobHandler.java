package org.springframework.jdbc.support.lob;

import java.io.InputStream;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.lang.Nullable;

@Deprecated(since = "6.2")
public interface LobHandler {
  @Nullable
  byte[] getBlobAsBytes(ResultSet paramResultSet, String paramString) throws SQLException;
  
  @Nullable
  byte[] getBlobAsBytes(ResultSet paramResultSet, int paramInt) throws SQLException;
  
  @Nullable
  InputStream getBlobAsBinaryStream(ResultSet paramResultSet, String paramString) throws SQLException;
  
  @Nullable
  InputStream getBlobAsBinaryStream(ResultSet paramResultSet, int paramInt) throws SQLException;
  
  @Nullable
  String getClobAsString(ResultSet paramResultSet, String paramString) throws SQLException;
  
  @Nullable
  String getClobAsString(ResultSet paramResultSet, int paramInt) throws SQLException;
  
  @Nullable
  InputStream getClobAsAsciiStream(ResultSet paramResultSet, String paramString) throws SQLException;
  
  @Nullable
  InputStream getClobAsAsciiStream(ResultSet paramResultSet, int paramInt) throws SQLException;
  
  Reader getClobAsCharacterStream(ResultSet paramResultSet, String paramString) throws SQLException;
  
  Reader getClobAsCharacterStream(ResultSet paramResultSet, int paramInt) throws SQLException;
  
  LobCreator getLobCreator();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\lob\LobHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */