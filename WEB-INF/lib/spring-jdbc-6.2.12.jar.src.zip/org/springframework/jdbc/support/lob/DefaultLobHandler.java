/*     */ package org.springframework.jdbc.support.lob;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(since = "6.2")
/*     */ public class DefaultLobHandler
/*     */   extends AbstractLobHandler
/*     */ {
/*  89 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean wrapAsLob = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean streamAsLob = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean createTemporaryLob = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWrapAsLob(boolean wrapAsLob) {
/* 114 */     this.wrapAsLob = wrapAsLob;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStreamAsLob(boolean streamAsLob) {
/* 132 */     this.streamAsLob = streamAsLob;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCreateTemporaryLob(boolean createTemporaryLob) {
/* 149 */     this.createTemporaryLob = createTemporaryLob;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public byte[] getBlobAsBytes(ResultSet rs, int columnIndex) throws SQLException {
/* 156 */     this.logger.debug("Returning BLOB as bytes");
/* 157 */     if (this.wrapAsLob) {
/* 158 */       Blob blob = rs.getBlob(columnIndex);
/* 159 */       return blob.getBytes(1L, (int)blob.length());
/*     */     } 
/*     */     
/* 162 */     return rs.getBytes(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InputStream getBlobAsBinaryStream(ResultSet rs, int columnIndex) throws SQLException {
/* 169 */     this.logger.debug("Returning BLOB as binary stream");
/* 170 */     if (this.wrapAsLob) {
/* 171 */       Blob blob = rs.getBlob(columnIndex);
/* 172 */       return blob.getBinaryStream();
/*     */     } 
/*     */     
/* 175 */     return rs.getBinaryStream(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getClobAsString(ResultSet rs, int columnIndex) throws SQLException {
/* 182 */     this.logger.debug("Returning CLOB as string");
/* 183 */     if (this.wrapAsLob) {
/* 184 */       Clob clob = rs.getClob(columnIndex);
/* 185 */       return clob.getSubString(1L, (int)clob.length());
/*     */     } 
/*     */     
/* 188 */     return rs.getString(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getClobAsAsciiStream(ResultSet rs, int columnIndex) throws SQLException {
/* 194 */     this.logger.debug("Returning CLOB as ASCII stream");
/* 195 */     if (this.wrapAsLob) {
/* 196 */       Clob clob = rs.getClob(columnIndex);
/* 197 */       return clob.getAsciiStream();
/*     */     } 
/*     */     
/* 200 */     return rs.getAsciiStream(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Reader getClobAsCharacterStream(ResultSet rs, int columnIndex) throws SQLException {
/* 206 */     this.logger.debug("Returning CLOB as character stream");
/* 207 */     if (this.wrapAsLob) {
/* 208 */       Clob clob = rs.getClob(columnIndex);
/* 209 */       return clob.getCharacterStream();
/*     */     } 
/*     */     
/* 212 */     return rs.getCharacterStream(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LobCreator getLobCreator() {
/* 218 */     return this.createTemporaryLob ? new TemporaryLobCreator() : new DefaultLobCreator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class DefaultLobCreator
/*     */     implements LobCreator
/*     */   {
/*     */     public void setBlobAsBytes(PreparedStatement ps, int paramIndex, @Nullable byte[] content) throws SQLException {
/* 232 */       if (DefaultLobHandler.this.streamAsLob) {
/* 233 */         if (content != null) {
/* 234 */           ps.setBlob(paramIndex, new ByteArrayInputStream(content), content.length);
/*     */         } else {
/*     */           
/* 237 */           ps.setBlob(paramIndex, (Blob)null);
/*     */         }
/*     */       
/* 240 */       } else if (DefaultLobHandler.this.wrapAsLob) {
/* 241 */         if (content != null) {
/* 242 */           ps.setBlob(paramIndex, new PassThroughBlob(content));
/*     */         } else {
/*     */           
/* 245 */           ps.setBlob(paramIndex, (Blob)null);
/*     */         } 
/*     */       } else {
/*     */         
/* 249 */         ps.setBytes(paramIndex, content);
/*     */       } 
/* 251 */       if (DefaultLobHandler.this.logger.isDebugEnabled()) {
/* 252 */         DefaultLobHandler.this.logger.debug((content != null) ? ("Set bytes for BLOB with length " + content.length) : 
/* 253 */             "Set BLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setBlobAsBinaryStream(PreparedStatement ps, int paramIndex, @Nullable InputStream binaryStream, int contentLength) throws SQLException {
/* 262 */       if (DefaultLobHandler.this.streamAsLob) {
/* 263 */         if (binaryStream != null) {
/* 264 */           if (contentLength >= 0) {
/* 265 */             ps.setBlob(paramIndex, binaryStream, contentLength);
/*     */           } else {
/*     */             
/* 268 */             ps.setBlob(paramIndex, binaryStream);
/*     */           } 
/*     */         } else {
/*     */           
/* 272 */           ps.setBlob(paramIndex, (Blob)null);
/*     */         }
/*     */       
/* 275 */       } else if (DefaultLobHandler.this.wrapAsLob) {
/* 276 */         if (binaryStream != null) {
/* 277 */           ps.setBlob(paramIndex, new PassThroughBlob(binaryStream, contentLength));
/*     */         } else {
/*     */           
/* 280 */           ps.setBlob(paramIndex, (Blob)null);
/*     */         }
/*     */       
/* 283 */       } else if (contentLength >= 0) {
/* 284 */         ps.setBinaryStream(paramIndex, binaryStream, contentLength);
/*     */       } else {
/*     */         
/* 287 */         ps.setBinaryStream(paramIndex, binaryStream);
/*     */       } 
/* 289 */       if (DefaultLobHandler.this.logger.isDebugEnabled()) {
/* 290 */         DefaultLobHandler.this.logger.debug((binaryStream != null) ? ("Set binary stream for BLOB with length " + contentLength) : 
/* 291 */             "Set BLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setClobAsString(PreparedStatement ps, int paramIndex, @Nullable String content) throws SQLException {
/* 299 */       if (DefaultLobHandler.this.streamAsLob) {
/* 300 */         if (content != null) {
/* 301 */           ps.setClob(paramIndex, new StringReader(content), content.length());
/*     */         } else {
/*     */           
/* 304 */           ps.setClob(paramIndex, (Clob)null);
/*     */         }
/*     */       
/* 307 */       } else if (DefaultLobHandler.this.wrapAsLob) {
/* 308 */         if (content != null) {
/* 309 */           ps.setClob(paramIndex, new PassThroughClob(content));
/*     */         } else {
/*     */           
/* 312 */           ps.setClob(paramIndex, (Clob)null);
/*     */         } 
/*     */       } else {
/*     */         
/* 316 */         ps.setString(paramIndex, content);
/*     */       } 
/* 318 */       if (DefaultLobHandler.this.logger.isDebugEnabled()) {
/* 319 */         DefaultLobHandler.this.logger.debug((content != null) ? ("Set string for CLOB with length " + content.length()) : 
/* 320 */             "Set CLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setClobAsAsciiStream(PreparedStatement ps, int paramIndex, @Nullable InputStream asciiStream, int contentLength) throws SQLException {
/* 329 */       if (DefaultLobHandler.this.streamAsLob) {
/* 330 */         if (asciiStream != null) {
/* 331 */           Reader reader = new InputStreamReader(asciiStream, StandardCharsets.US_ASCII);
/* 332 */           if (contentLength >= 0) {
/* 333 */             ps.setClob(paramIndex, reader, contentLength);
/*     */           } else {
/*     */             
/* 336 */             ps.setClob(paramIndex, reader);
/*     */           } 
/*     */         } else {
/*     */           
/* 340 */           ps.setClob(paramIndex, (Clob)null);
/*     */         }
/*     */       
/* 343 */       } else if (DefaultLobHandler.this.wrapAsLob) {
/* 344 */         if (asciiStream != null) {
/* 345 */           ps.setClob(paramIndex, new PassThroughClob(asciiStream, contentLength));
/*     */         } else {
/*     */           
/* 348 */           ps.setClob(paramIndex, (Clob)null);
/*     */         }
/*     */       
/* 351 */       } else if (contentLength >= 0) {
/* 352 */         ps.setAsciiStream(paramIndex, asciiStream, contentLength);
/*     */       } else {
/*     */         
/* 355 */         ps.setAsciiStream(paramIndex, asciiStream);
/*     */       } 
/* 357 */       if (DefaultLobHandler.this.logger.isDebugEnabled()) {
/* 358 */         DefaultLobHandler.this.logger.debug((asciiStream != null) ? ("Set ASCII stream for CLOB with length " + contentLength) : 
/* 359 */             "Set CLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setClobAsCharacterStream(PreparedStatement ps, int paramIndex, @Nullable Reader characterStream, int contentLength) throws SQLException {
/* 368 */       if (DefaultLobHandler.this.streamAsLob) {
/* 369 */         if (characterStream != null) {
/* 370 */           if (contentLength >= 0) {
/* 371 */             ps.setClob(paramIndex, characterStream, contentLength);
/*     */           } else {
/*     */             
/* 374 */             ps.setClob(paramIndex, characterStream);
/*     */           } 
/*     */         } else {
/*     */           
/* 378 */           ps.setClob(paramIndex, (Clob)null);
/*     */         }
/*     */       
/* 381 */       } else if (DefaultLobHandler.this.wrapAsLob) {
/* 382 */         if (characterStream != null) {
/* 383 */           ps.setClob(paramIndex, new PassThroughClob(characterStream, contentLength));
/*     */         } else {
/*     */           
/* 386 */           ps.setClob(paramIndex, (Clob)null);
/*     */         }
/*     */       
/* 389 */       } else if (contentLength >= 0) {
/* 390 */         ps.setCharacterStream(paramIndex, characterStream, contentLength);
/*     */       } else {
/*     */         
/* 393 */         ps.setCharacterStream(paramIndex, characterStream);
/*     */       } 
/* 395 */       if (DefaultLobHandler.this.logger.isDebugEnabled())
/* 396 */         DefaultLobHandler.this.logger.debug((characterStream != null) ? ("Set character stream for CLOB with length " + contentLength) : 
/* 397 */             "Set CLOB to null"); 
/*     */     }
/*     */     
/*     */     public void close() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\lob\DefaultLobHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */