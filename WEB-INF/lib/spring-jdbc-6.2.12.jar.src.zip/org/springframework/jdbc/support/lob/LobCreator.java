package org.springframework.jdbc.support.lob;

import java.io.Closeable;
import java.io.InputStream;
import java.io.Reader;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.springframework.lang.Nullable;

@Deprecated(since = "6.2")
public interface LobCreator extends Closeable {
  void setBlobAsBytes(PreparedStatement paramPreparedStatement, int paramInt, @Nullable byte[] paramArrayOfbyte) throws SQLException;
  
  void setBlobAsBinaryStream(PreparedStatement paramPreparedStatement, int paramInt1, @Nullable InputStream paramInputStream, int paramInt2) throws SQLException;
  
  void setClobAsString(PreparedStatement paramPreparedStatement, int paramInt, @Nullable String paramString) throws SQLException;
  
  void setClobAsAsciiStream(PreparedStatement paramPreparedStatement, int paramInt1, @Nullable InputStream paramInputStream, int paramInt2) throws SQLException;
  
  void setClobAsCharacterStream(PreparedStatement paramPreparedStatement, int paramInt1, @Nullable Reader paramReader, int paramInt2) throws SQLException;
  
  void close();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\lob\LobCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */