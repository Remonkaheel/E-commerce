package org.springframework.jdbc.support;

import java.sql.DatabaseMetaData;
import java.sql.SQLException;

@FunctionalInterface
public interface DatabaseMetaDataCallback<T> {
  T processMetaData(DatabaseMetaData paramDatabaseMetaData) throws SQLException, MetaDataAccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\DatabaseMetaDataCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */