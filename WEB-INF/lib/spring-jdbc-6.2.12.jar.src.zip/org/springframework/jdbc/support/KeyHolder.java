package org.springframework.jdbc.support;

import java.util.List;
import java.util.Map;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.lang.Nullable;

public interface KeyHolder {
  @Nullable
  Number getKey() throws InvalidDataAccessApiUsageException;
  
  @Nullable
  <T> T getKeyAs(Class<T> paramClass) throws InvalidDataAccessApiUsageException;
  
  @Nullable
  Map<String, Object> getKeys() throws InvalidDataAccessApiUsageException;
  
  List<Map<String, Object>> getKeyList();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\KeyHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */