/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Arrays;
/*     */ import java.util.function.Supplier;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.dao.CannotAcquireLockException;
/*     */ import org.springframework.dao.CannotSerializeTransactionException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.dao.DataIntegrityViolationException;
/*     */ import org.springframework.dao.DeadlockLoserDataAccessException;
/*     */ import org.springframework.dao.DuplicateKeyException;
/*     */ import org.springframework.dao.PermissionDeniedDataAccessException;
/*     */ import org.springframework.dao.TransientDataAccessResourceException;
/*     */ import org.springframework.jdbc.BadSqlGrammarException;
/*     */ import org.springframework.jdbc.InvalidResultSetAccessException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ import org.springframework.util.function.SupplierUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLErrorCodeSQLExceptionTranslator
/*     */   extends AbstractFallbackSQLExceptionTranslator
/*     */ {
/*     */   private static final int MESSAGE_ONLY_CONSTRUCTOR = 1;
/*     */   private static final int MESSAGE_THROWABLE_CONSTRUCTOR = 2;
/*     */   private static final int MESSAGE_SQLEX_CONSTRUCTOR = 3;
/*     */   private static final int MESSAGE_SQL_THROWABLE_CONSTRUCTOR = 4;
/*     */   private static final int MESSAGE_SQL_SQLEX_CONSTRUCTOR = 5;
/*  83 */   private static final boolean userProvidedErrorCodesFilePresent = (new ClassPathResource("sql-error-codes.xml", SQLErrorCodesFactory.class
/*     */       
/*  85 */       .getClassLoader())).exists();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private SingletonSupplier<SQLErrorCodes> sqlErrorCodes;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLErrorCodeSQLExceptionTranslator() {
/*  96 */     setFallbackTranslator(new SQLExceptionSubclassTranslator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLErrorCodeSQLExceptionTranslator(DataSource dataSource) {
/* 108 */     this();
/* 109 */     setDataSource(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLErrorCodeSQLExceptionTranslator(String dbName) {
/* 121 */     this();
/* 122 */     setDatabaseProductName(dbName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLErrorCodeSQLExceptionTranslator(SQLErrorCodes sec) {
/* 131 */     this();
/* 132 */     this.sqlErrorCodes = SingletonSupplier.of(sec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(DataSource dataSource) {
/* 146 */     this
/* 147 */       .sqlErrorCodes = SingletonSupplier.of(() -> SQLErrorCodesFactory.getInstance().resolveErrorCodes(dataSource));
/* 148 */     this.sqlErrorCodes.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabaseProductName(String dbName) {
/* 160 */     this.sqlErrorCodes = SingletonSupplier.of(SQLErrorCodesFactory.getInstance().getErrorCodes(dbName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlErrorCodes(@Nullable SQLErrorCodes sec) {
/* 168 */     this.sqlErrorCodes = SingletonSupplier.ofNullable(sec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SQLErrorCodes getSqlErrorCodes() {
/* 178 */     return (SQLErrorCodes)SupplierUtils.resolve((Supplier)this.sqlErrorCodes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected DataAccessException doTranslate(String task, @Nullable String sql, SQLException ex) {
/* 186 */     SQLException sqlEx = ex;
/* 187 */     if (sqlEx instanceof java.sql.BatchUpdateException && sqlEx.getNextException() != null) {
/* 188 */       SQLException nestedSqlEx = sqlEx.getNextException();
/* 189 */       if (nestedSqlEx.getErrorCode() > 0 || nestedSqlEx.getSQLState() != null) {
/* 190 */         sqlEx = nestedSqlEx;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 195 */     DataAccessException dae = customTranslate(task, sql, sqlEx);
/* 196 */     if (dae != null) {
/* 197 */       return dae;
/*     */     }
/*     */ 
/*     */     
/* 201 */     SQLErrorCodes sqlErrorCodes = getSqlErrorCodes();
/* 202 */     if (sqlErrorCodes != null) {
/* 203 */       SQLExceptionTranslator customTranslator = sqlErrorCodes.getCustomSqlExceptionTranslator();
/* 204 */       if (customTranslator != null) {
/* 205 */         dae = customTranslator.translate(task, sql, sqlEx);
/* 206 */         if (dae != null) {
/* 207 */           return dae;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 213 */     if (sqlErrorCodes != null) {
/*     */       String errorCode;
/* 215 */       if (sqlErrorCodes.isUseSqlStateForTranslation()) {
/* 216 */         errorCode = sqlEx.getSQLState();
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 221 */         SQLException current = sqlEx;
/* 222 */         while (current.getErrorCode() == 0) { Throwable throwable = current.getCause(); if (throwable instanceof SQLException) { SQLException sqlException = (SQLException)throwable;
/* 223 */             current = sqlException; }
/*     */            }
/* 225 */          errorCode = Integer.toString(current.getErrorCode());
/*     */       } 
/*     */       
/* 228 */       if (errorCode != null) {
/*     */         
/* 230 */         CustomSQLErrorCodesTranslation[] customTranslations = sqlErrorCodes.getCustomTranslations();
/* 231 */         if (customTranslations != null) {
/* 232 */           for (CustomSQLErrorCodesTranslation customTranslation : customTranslations) {
/* 233 */             if (Arrays.binarySearch((Object[])customTranslation.getErrorCodes(), errorCode) >= 0 && customTranslation
/* 234 */               .getExceptionClass() != null) {
/* 235 */               dae = createCustomException(task, sql, sqlEx, customTranslation.getExceptionClass());
/* 236 */               if (dae != null) {
/* 237 */                 logTranslation(task, sql, sqlEx, true);
/* 238 */                 return dae;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }
/*     */         
/* 244 */         if (Arrays.binarySearch((Object[])sqlErrorCodes.getBadSqlGrammarCodes(), errorCode) >= 0) {
/* 245 */           logTranslation(task, sql, sqlEx, false);
/* 246 */           return (DataAccessException)new BadSqlGrammarException(task, (sql != null) ? sql : "", sqlEx);
/*     */         } 
/* 248 */         if (Arrays.binarySearch((Object[])sqlErrorCodes.getInvalidResultSetAccessCodes(), errorCode) >= 0) {
/* 249 */           logTranslation(task, sql, sqlEx, false);
/* 250 */           return (DataAccessException)new InvalidResultSetAccessException(task, (sql != null) ? sql : "", sqlEx);
/*     */         } 
/* 252 */         if (Arrays.binarySearch((Object[])sqlErrorCodes.getDuplicateKeyCodes(), errorCode) >= 0) {
/* 253 */           logTranslation(task, sql, sqlEx, false);
/* 254 */           return (DataAccessException)new DuplicateKeyException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         } 
/* 256 */         if (Arrays.binarySearch((Object[])sqlErrorCodes.getDataIntegrityViolationCodes(), errorCode) >= 0) {
/* 257 */           logTranslation(task, sql, sqlEx, false);
/* 258 */           return (DataAccessException)new DataIntegrityViolationException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         } 
/* 260 */         if (Arrays.binarySearch((Object[])sqlErrorCodes.getPermissionDeniedCodes(), errorCode) >= 0) {
/* 261 */           logTranslation(task, sql, sqlEx, false);
/* 262 */           return (DataAccessException)new PermissionDeniedDataAccessException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         } 
/* 264 */         if (Arrays.binarySearch((Object[])sqlErrorCodes.getDataAccessResourceFailureCodes(), errorCode) >= 0) {
/* 265 */           logTranslation(task, sql, sqlEx, false);
/* 266 */           return (DataAccessException)new DataAccessResourceFailureException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         } 
/* 268 */         if (Arrays.binarySearch((Object[])sqlErrorCodes.getTransientDataAccessResourceCodes(), errorCode) >= 0) {
/* 269 */           logTranslation(task, sql, sqlEx, false);
/* 270 */           return (DataAccessException)new TransientDataAccessResourceException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         } 
/* 272 */         if (Arrays.binarySearch((Object[])sqlErrorCodes.getCannotAcquireLockCodes(), errorCode) >= 0) {
/* 273 */           logTranslation(task, sql, sqlEx, false);
/* 274 */           return (DataAccessException)new CannotAcquireLockException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         } 
/* 276 */         if (Arrays.binarySearch((Object[])sqlErrorCodes.getDeadlockLoserCodes(), errorCode) >= 0) {
/* 277 */           logTranslation(task, sql, sqlEx, false);
/* 278 */           return (DataAccessException)new DeadlockLoserDataAccessException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         } 
/* 280 */         if (Arrays.binarySearch((Object[])sqlErrorCodes.getCannotSerializeTransactionCodes(), errorCode) >= 0) {
/* 281 */           logTranslation(task, sql, sqlEx, false);
/* 282 */           return (DataAccessException)new CannotSerializeTransactionException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 288 */     if (this.logger.isDebugEnabled()) {
/*     */       String codes;
/* 290 */       if (sqlErrorCodes != null && sqlErrorCodes.isUseSqlStateForTranslation()) {
/* 291 */         codes = "SQL state '" + sqlEx.getSQLState() + "', error code '" + sqlEx.getErrorCode();
/*     */       } else {
/*     */         
/* 294 */         codes = "Error code '" + sqlEx.getErrorCode() + "'";
/*     */       } 
/* 296 */       this.logger.debug("Unable to translate SQLException with " + codes + ", will now try the fallback translator");
/*     */     } 
/*     */     
/* 299 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1")
/*     */   @Nullable
/*     */   protected DataAccessException customTranslate(String task, @Nullable String sql, SQLException sqlEx) {
/* 317 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected DataAccessException createCustomException(String task, @Nullable String sql, SQLException sqlEx, Class<?> exceptionClass) {
/*     */     try {
/*     */       Constructor<?> exceptionConstructor;
/*     */       Class<?>[] messageAndSqlAndSqlExArgsClass, messageAndSqlAndThrowableArgsClass, messageAndSqlExArgsClass, messageAndThrowableArgsClass, messageOnlyArgsClass;
/*     */       Object[] messageAndSqlAndSqlExArgs, messageAndSqlAndThrowableArgs, messageAndSqlExArgs, messageAndThrowableArgs, messageOnlyArgs;
/* 339 */       int constructorType = 0;
/* 340 */       Constructor[] arrayOfConstructor = (Constructor[])exceptionClass.getConstructors();
/* 341 */       for (Constructor<?> constructor : arrayOfConstructor) {
/* 342 */         Class<?>[] parameterTypes = constructor.getParameterTypes();
/* 343 */         if (parameterTypes.length == 1 && String.class == parameterTypes[0] && constructorType < 1)
/*     */         {
/* 345 */           constructorType = 1;
/*     */         }
/* 347 */         if (parameterTypes.length == 2 && String.class == parameterTypes[0] && Throwable.class == parameterTypes[1] && constructorType < 2)
/*     */         {
/*     */           
/* 350 */           constructorType = 2;
/*     */         }
/* 352 */         if (parameterTypes.length == 2 && String.class == parameterTypes[0] && SQLException.class == parameterTypes[1] && constructorType < 3)
/*     */         {
/*     */           
/* 355 */           constructorType = 3;
/*     */         }
/* 357 */         if (parameterTypes.length == 3 && String.class == parameterTypes[0] && String.class == parameterTypes[1] && Throwable.class == parameterTypes[2] && constructorType < 4)
/*     */         {
/*     */           
/* 360 */           constructorType = 4;
/*     */         }
/* 362 */         if (parameterTypes.length == 3 && String.class == parameterTypes[0] && String.class == parameterTypes[1] && SQLException.class == parameterTypes[2] && constructorType < 5)
/*     */         {
/*     */           
/* 365 */           constructorType = 5;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 371 */       switch (constructorType) {
/*     */         case 5:
/* 373 */           messageAndSqlAndSqlExArgsClass = new Class[] { String.class, String.class, SQLException.class };
/* 374 */           messageAndSqlAndSqlExArgs = new Object[] { task, sql, sqlEx };
/* 375 */           exceptionConstructor = exceptionClass.getConstructor(messageAndSqlAndSqlExArgsClass);
/*     */ 
/*     */         
/*     */         case 4:
/* 379 */           messageAndSqlAndThrowableArgsClass = new Class[] { String.class, String.class, Throwable.class };
/* 380 */           messageAndSqlAndThrowableArgs = new Object[] { task, sql, sqlEx };
/* 381 */           exceptionConstructor = exceptionClass.getConstructor(messageAndSqlAndThrowableArgsClass);
/*     */ 
/*     */         
/*     */         case 3:
/* 385 */           messageAndSqlExArgsClass = new Class[] { String.class, SQLException.class };
/* 386 */           messageAndSqlExArgs = new Object[] { task + ": " + task, sqlEx };
/* 387 */           exceptionConstructor = exceptionClass.getConstructor(messageAndSqlExArgsClass);
/*     */ 
/*     */         
/*     */         case 2:
/* 391 */           messageAndThrowableArgsClass = new Class[] { String.class, Throwable.class };
/* 392 */           messageAndThrowableArgs = new Object[] { task + ": " + task, sqlEx };
/* 393 */           exceptionConstructor = exceptionClass.getConstructor(messageAndThrowableArgsClass);
/*     */ 
/*     */         
/*     */         case 1:
/* 397 */           messageOnlyArgsClass = new Class[] { String.class };
/* 398 */           messageOnlyArgs = new Object[] { task + ": " + task };
/* 399 */           exceptionConstructor = exceptionClass.getConstructor(messageOnlyArgsClass);
/*     */       } 
/*     */ 
/*     */       
/* 403 */       if (this.logger.isWarnEnabled()) {
/* 404 */         this.logger.warn("Unable to find appropriate constructor of custom exception class [" + exceptionClass
/* 405 */             .getName() + "]");
/*     */       }
/* 407 */       return null;
/*     */ 
/*     */     
/*     */     }
/* 411 */     catch (Throwable ex) {
/* 412 */       if (this.logger.isWarnEnabled()) {
/* 413 */         this.logger.warn("Unable to instantiate custom exception class [" + exceptionClass.getName() + "]", ex);
/*     */       }
/* 415 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void logTranslation(String task, @Nullable String sql, SQLException sqlEx, boolean custom) {
/* 420 */     if (this.logger.isDebugEnabled()) {
/* 421 */       String intro = custom ? "Custom translation of" : "Translating";
/* 422 */       this.logger.debug(intro + " SQLException with SQL state '" + intro + "', error code '" + sqlEx.getSQLState() + "', message [" + sqlEx
/* 423 */           .getErrorCode() + "]" + sqlEx.getMessage() + " for task [" + (
/* 424 */           (sql != null) ? ("; SQL was [" + sql + "]") : "") + "]");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean hasUserProvidedErrorCodesFile() {
/* 434 */     return userProvidedErrorCodesFilePresent;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\SQLErrorCodeSQLExceptionTranslator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */