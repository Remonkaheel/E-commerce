/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFallbackSQLExceptionTranslator
/*     */   implements SQLExceptionTranslator
/*     */ {
/*  42 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private SQLExceptionTranslator fallbackTranslator;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private SQLExceptionTranslator customTranslator;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFallbackTranslator(@Nullable SQLExceptionTranslator fallback) {
/*  56 */     this.fallbackTranslator = fallback;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SQLExceptionTranslator getFallbackTranslator() {
/*  65 */     return this.fallbackTranslator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCustomTranslator(@Nullable SQLExceptionTranslator customTranslator) {
/*  75 */     this.customTranslator = customTranslator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SQLExceptionTranslator getCustomTranslator() {
/*  85 */     return this.customTranslator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataAccessException translate(String task, @Nullable String sql, SQLException ex) {
/*  96 */     Assert.notNull(ex, "Cannot translate a null SQLException");
/*     */     
/*  98 */     SQLExceptionTranslator custom = getCustomTranslator();
/*  99 */     if (custom != null) {
/* 100 */       DataAccessException dataAccessException = custom.translate(task, sql, ex);
/* 101 */       if (dataAccessException != null)
/*     */       {
/* 103 */         return dataAccessException;
/*     */       }
/*     */     } 
/*     */     
/* 107 */     DataAccessException dae = doTranslate(task, sql, ex);
/* 108 */     if (dae != null)
/*     */     {
/* 110 */       return dae;
/*     */     }
/*     */ 
/*     */     
/* 114 */     SQLExceptionTranslator fallback = getFallbackTranslator();
/* 115 */     if (fallback != null) {
/* 116 */       return fallback.translate(task, sql, ex);
/*     */     }
/*     */     
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract DataAccessException doTranslate(String paramString1, @Nullable String paramString2, SQLException paramSQLException);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String buildMessage(String task, @Nullable String sql, SQLException ex) {
/* 147 */     return task + "; " + task + ((sql != null) ? ("SQL [" + sql + "]; ") : "");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\AbstractFallbackSQLExceptionTranslator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */