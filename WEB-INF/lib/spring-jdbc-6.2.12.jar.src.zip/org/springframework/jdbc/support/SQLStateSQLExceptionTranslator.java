/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Set;
/*     */ import org.springframework.dao.CannotAcquireLockException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.dao.DataIntegrityViolationException;
/*     */ import org.springframework.dao.DuplicateKeyException;
/*     */ import org.springframework.dao.PessimisticLockingFailureException;
/*     */ import org.springframework.dao.QueryTimeoutException;
/*     */ import org.springframework.dao.TransientDataAccessResourceException;
/*     */ import org.springframework.jdbc.BadSqlGrammarException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLStateSQLExceptionTranslator
/*     */   extends AbstractFallbackSQLExceptionTranslator
/*     */ {
/*  58 */   private static final Set<String> BAD_SQL_GRAMMAR_CODES = Set.of("07", "21", "2A", "37", "42", "65");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private static final Set<String> DATA_INTEGRITY_VIOLATION_CODES = Set.of("01", "02", "22", "23", "27", "44");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   private static final Set<String> PESSIMISTIC_LOCKING_FAILURE_CODES = Set.of("40", "61");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private static final Set<String> DATA_ACCESS_RESOURCE_FAILURE_CODES = Set.of("08", "53", "54", "57", "58");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private static final Set<String> TRANSIENT_DATA_ACCESS_RESOURCE_CODES = Set.of("JW", "JZ", "S1");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private static final Set<Integer> DUPLICATE_KEY_ERROR_CODES = Set.of(
/*  96 */       Integer.valueOf(1), 
/*  97 */       Integer.valueOf(301), 
/*  98 */       Integer.valueOf(1062), 
/*  99 */       Integer.valueOf(2601), 
/* 100 */       Integer.valueOf(2627), 
/* 101 */       Integer.valueOf(-239), 
/* 102 */       Integer.valueOf(-268));
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected DataAccessException doTranslate(String task, @Nullable String sql, SQLException ex) {
/*     */     String sqlState;
/* 109 */     SQLException sqlEx = ex;
/*     */     
/* 111 */     if (sqlEx instanceof java.sql.BatchUpdateException) {
/*     */ 
/*     */       
/* 114 */       if (sqlEx.getNextException() != null) {
/* 115 */         SQLException nestedSqlEx = sqlEx.getNextException();
/* 116 */         if (nestedSqlEx.getSQLState() != null) {
/* 117 */           sqlEx = nestedSqlEx;
/*     */         }
/*     */       } 
/* 120 */       sqlState = sqlEx.getSQLState();
/*     */     }
/*     */     else {
/*     */       
/* 124 */       sqlState = getSqlState(sqlEx);
/*     */     } 
/*     */ 
/*     */     
/* 128 */     if (sqlState != null && sqlState.length() >= 2) {
/* 129 */       String classCode = sqlState.substring(0, 2);
/* 130 */       if (this.logger.isDebugEnabled()) {
/* 131 */         this.logger.debug("Extracted SQL state class '" + classCode + "' from value '" + sqlState + "'");
/*     */       }
/* 133 */       if (BAD_SQL_GRAMMAR_CODES.contains(classCode)) {
/* 134 */         return (DataAccessException)new BadSqlGrammarException(task, (sql != null) ? sql : "", sqlEx);
/*     */       }
/* 136 */       if (DATA_INTEGRITY_VIOLATION_CODES.contains(classCode)) {
/* 137 */         if (indicatesDuplicateKey(sqlState, sqlEx.getErrorCode())) {
/* 138 */           return (DataAccessException)new DuplicateKeyException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/* 140 */         return (DataAccessException)new DataIntegrityViolationException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       } 
/* 142 */       if (PESSIMISTIC_LOCKING_FAILURE_CODES.contains(classCode)) {
/* 143 */         if (indicatesCannotAcquireLock(sqlState)) {
/* 144 */           return (DataAccessException)new CannotAcquireLockException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/* 146 */         return (DataAccessException)new PessimisticLockingFailureException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       } 
/* 148 */       if (DATA_ACCESS_RESOURCE_FAILURE_CODES.contains(classCode)) {
/* 149 */         if (indicatesQueryTimeout(sqlState)) {
/* 150 */           return (DataAccessException)new QueryTimeoutException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/* 152 */         return (DataAccessException)new DataAccessResourceFailureException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       } 
/* 154 */       if (TRANSIENT_DATA_ACCESS_RESOURCE_CODES.contains(classCode)) {
/* 155 */         return (DataAccessException)new TransientDataAccessResourceException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 161 */     if (sqlEx.getClass().getName().contains("Timeout")) {
/* 162 */       return (DataAccessException)new QueryTimeoutException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */     }
/*     */ 
/*     */     
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String getSqlState(SQLException ex) {
/* 179 */     String sqlState = ex.getSQLState();
/* 180 */     if (sqlState == null) {
/* 181 */       SQLException nestedEx = ex.getNextException();
/* 182 */       if (nestedEx != null) {
/* 183 */         sqlState = nestedEx.getSQLState();
/*     */       }
/*     */     } 
/* 186 */     return sqlState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean indicatesDuplicateKey(@Nullable String sqlState, int errorCode) {
/* 199 */     return ("23505".equals(sqlState) || ("23000"
/* 200 */       .equals(sqlState) && DUPLICATE_KEY_ERROR_CODES.contains(Integer.valueOf(errorCode))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean indicatesCannotAcquireLock(@Nullable String sqlState) {
/* 209 */     return "40001".equals(sqlState);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean indicatesQueryTimeout(@Nullable String sqlState) {
/* 218 */     return "57014".equals(sqlState);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\SQLStateSQLExceptionTranslator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */