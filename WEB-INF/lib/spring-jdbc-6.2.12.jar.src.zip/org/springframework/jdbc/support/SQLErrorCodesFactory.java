/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLErrorCodesFactory
/*     */ {
/*     */   public static final String SQL_ERROR_CODE_OVERRIDE_PATH = "sql-error-codes.xml";
/*     */   public static final String SQL_ERROR_CODE_DEFAULT_PATH = "org/springframework/jdbc/support/sql-error-codes.xml";
/*  67 */   private static final Log logger = LogFactory.getLog(SQLErrorCodesFactory.class);
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static SQLErrorCodesFactory instance;
/*     */ 
/*     */   
/*     */   private final Map<String, SQLErrorCodes> errorCodesMap;
/*     */ 
/*     */   
/*     */   private final Map<DataSource, SQLErrorCodes> dataSourceCache;
/*     */ 
/*     */ 
/*     */   
/*     */   public static SQLErrorCodesFactory getInstance() {
/*  82 */     if (instance == null) {
/*  83 */       instance = new SQLErrorCodesFactory();
/*     */     }
/*  85 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SQLErrorCodesFactory() {
/*     */     Map<String, SQLErrorCodes> errorCodes;
/*  98 */     this.dataSourceCache = (Map<DataSource, SQLErrorCodes>)new ConcurrentReferenceHashMap(16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 114 */       DefaultListableBeanFactory lbf = new DefaultListableBeanFactory();
/* 115 */       lbf.setBeanClassLoader(getClass().getClassLoader());
/* 116 */       XmlBeanDefinitionReader bdr = new XmlBeanDefinitionReader((BeanDefinitionRegistry)lbf);
/*     */ 
/*     */       
/* 119 */       Resource resource = loadResource("org/springframework/jdbc/support/sql-error-codes.xml");
/* 120 */       if (resource != null && resource.exists()) {
/* 121 */         bdr.loadBeanDefinitions(resource);
/*     */       } else {
/*     */         
/* 124 */         logger.info("Default sql-error-codes.xml not found (should be included in spring-jdbc jar)");
/*     */       } 
/*     */ 
/*     */       
/* 128 */       resource = loadResource("sql-error-codes.xml");
/* 129 */       if (resource != null && resource.exists()) {
/* 130 */         bdr.loadBeanDefinitions(resource);
/* 131 */         logger.debug("Found custom sql-error-codes.xml file at the root of the classpath");
/*     */       } 
/*     */ 
/*     */       
/* 135 */       errorCodes = lbf.getBeansOfType(SQLErrorCodes.class, true, false);
/* 136 */       if (logger.isTraceEnabled()) {
/* 137 */         logger.trace("SQLErrorCodes loaded: " + String.valueOf(errorCodes.keySet()));
/*     */       }
/*     */     }
/* 140 */     catch (BeansException ex) {
/* 141 */       logger.warn("Error loading SQL error codes from config file", (Throwable)ex);
/* 142 */       errorCodes = Collections.emptyMap();
/*     */     } 
/*     */     
/* 145 */     this.errorCodesMap = errorCodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Resource loadResource(String path) {
/* 161 */     return (Resource)new ClassPathResource(path, getClass().getClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLErrorCodes getErrorCodes(String databaseName) {
/* 174 */     Assert.notNull(databaseName, "Database product name must not be null");
/*     */     
/* 176 */     SQLErrorCodes sec = this.errorCodesMap.get(databaseName);
/* 177 */     if (sec == null) {
/* 178 */       for (SQLErrorCodes candidate : this.errorCodesMap.values()) {
/* 179 */         if (PatternMatchUtils.simpleMatch(candidate.getDatabaseProductNames(), databaseName)) {
/* 180 */           sec = candidate;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 185 */     if (sec != null) {
/* 186 */       checkCustomTranslatorRegistry(databaseName, sec);
/* 187 */       if (logger.isDebugEnabled()) {
/* 188 */         logger.debug("SQL error codes for '" + databaseName + "' found");
/*     */       }
/* 190 */       return sec;
/*     */     } 
/*     */ 
/*     */     
/* 194 */     if (logger.isDebugEnabled()) {
/* 195 */       logger.debug("SQL error codes for '" + databaseName + "' not found");
/*     */     }
/* 197 */     return new SQLErrorCodes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLErrorCodes getErrorCodes(DataSource dataSource) {
/* 211 */     SQLErrorCodes sec = resolveErrorCodes(dataSource);
/* 212 */     return (sec != null) ? sec : new SQLErrorCodes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SQLErrorCodes resolveErrorCodes(DataSource dataSource) {
/* 228 */     Assert.notNull(dataSource, "DataSource must not be null");
/* 229 */     if (logger.isDebugEnabled()) {
/* 230 */       logger.debug("Looking up default SQLErrorCodes for DataSource [" + identify(dataSource) + "]");
/*     */     }
/*     */ 
/*     */     
/* 234 */     SQLErrorCodes sec = this.dataSourceCache.get(dataSource);
/* 235 */     if (sec == null) {
/* 236 */       synchronized (this.dataSourceCache) {
/*     */         
/* 238 */         sec = this.dataSourceCache.get(dataSource);
/* 239 */         if (sec == null) {
/*     */           
/*     */           try {
/* 242 */             String name = JdbcUtils.<String>extractDatabaseMetaData(dataSource, DatabaseMetaData::getDatabaseProductName);
/*     */             
/* 244 */             if (StringUtils.hasLength(name)) {
/* 245 */               return registerDatabase(dataSource, name);
/*     */             }
/*     */           }
/* 248 */           catch (MetaDataAccessException ex) {
/* 249 */             logger.warn("Error while extracting database name", (Throwable)ex);
/*     */           } 
/* 251 */           return null;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 256 */     if (logger.isDebugEnabled()) {
/* 257 */       logger.debug("SQLErrorCodes found in cache for DataSource [" + identify(dataSource) + "]");
/*     */     }
/*     */     
/* 260 */     return sec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLErrorCodes registerDatabase(DataSource dataSource, String databaseName) {
/* 272 */     SQLErrorCodes sec = getErrorCodes(databaseName);
/* 273 */     if (logger.isDebugEnabled()) {
/* 274 */       logger.debug("Caching SQL error codes for DataSource [" + identify(dataSource) + "]: database product name is '" + databaseName + "'");
/*     */     }
/*     */     
/* 277 */     this.dataSourceCache.put(dataSource, sec);
/* 278 */     return sec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SQLErrorCodes unregisterDatabase(DataSource dataSource) {
/* 291 */     return this.dataSourceCache.remove(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String identify(DataSource dataSource) {
/* 301 */     return dataSource.getClass().getName() + "@" + dataSource.getClass().getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkCustomTranslatorRegistry(String databaseName, SQLErrorCodes errorCodes) {
/* 309 */     SQLExceptionTranslator customTranslator = CustomSQLExceptionTranslatorRegistry.getInstance().findTranslatorForDatabase(databaseName);
/* 310 */     if (customTranslator != null) {
/* 311 */       if (errorCodes.getCustomSqlExceptionTranslator() != null && logger.isDebugEnabled()) {
/* 312 */         logger.debug("Overriding already defined custom translator '" + errorCodes
/* 313 */             .getCustomSqlExceptionTranslator().getClass().getSimpleName() + " with '" + customTranslator
/* 314 */             .getClass().getSimpleName() + "' found in the CustomSQLExceptionTranslatorRegistry for database '" + databaseName + "'");
/*     */       
/*     */       }
/* 317 */       else if (logger.isTraceEnabled()) {
/* 318 */         logger.trace("Using custom translator '" + customTranslator.getClass().getSimpleName() + "' found in the CustomSQLExceptionTranslatorRegistry for database '" + databaseName + "'");
/*     */       } 
/*     */       
/* 321 */       errorCodes.setCustomSqlExceptionTranslator(customTranslator);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\SQLErrorCodesFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */