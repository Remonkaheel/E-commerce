/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatabaseStartupValidator
/*     */   implements InitializingBean
/*     */ {
/*     */   public static final int DEFAULT_INTERVAL = 1;
/*     */   public static final int DEFAULT_TIMEOUT = 60;
/*  58 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private DataSource dataSource;
/*     */   
/*     */   @Nullable
/*     */   private String validationQuery;
/*     */   
/*  66 */   private int interval = 1;
/*     */   
/*  68 */   private int timeout = 60;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(DataSource dataSource) {
/*  75 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setValidationQuery(String validationQuery) {
/*  84 */     this.validationQuery = validationQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterval(int interval) {
/*  92 */     this.interval = interval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeout(int timeout) {
/* 100 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 111 */     if (this.dataSource == null) {
/* 112 */       throw new IllegalArgumentException("Property 'dataSource' is required");
/*     */     }
/*     */     
/*     */     try {
/* 116 */       boolean validated = false;
/* 117 */       long beginTime = System.currentTimeMillis();
/* 118 */       long deadLine = beginTime + TimeUnit.SECONDS.toMillis(this.timeout);
/* 119 */       SQLException latestEx = null;
/*     */       
/* 121 */       while (!validated && System.currentTimeMillis() < deadLine) {
/* 122 */         Connection con = null;
/* 123 */         Statement stmt = null;
/*     */         try {
/* 125 */           con = this.dataSource.getConnection();
/* 126 */           if (con == null) {
/* 127 */             throw new CannotGetJdbcConnectionException("Failed to execute validation: DataSource returned null from getConnection(): " + String.valueOf(this.dataSource));
/*     */           }
/*     */           
/* 130 */           if (this.validationQuery == null) {
/* 131 */             validated = con.isValid(this.interval);
/*     */           } else {
/*     */             
/* 134 */             stmt = con.createStatement();
/* 135 */             stmt.execute(this.validationQuery);
/* 136 */             validated = true;
/*     */           }
/*     */         
/* 139 */         } catch (SQLException ex) {
/* 140 */           latestEx = ex;
/* 141 */           if (this.logger.isDebugEnabled()) {
/* 142 */             if (this.validationQuery != null) {
/* 143 */               this.logger.debug("Validation query [" + this.validationQuery + "] threw exception", ex);
/*     */             } else {
/*     */               
/* 146 */               this.logger.debug("Validation check threw exception", ex);
/*     */             } 
/*     */           }
/* 149 */           if (this.logger.isInfoEnabled()) {
/* 150 */             float rest = (float)(deadLine - System.currentTimeMillis()) / 1000.0F;
/* 151 */             if (rest > this.interval) {
/* 152 */               this.logger.info("Database has not started up yet - retrying in " + this.interval + " seconds (timeout in " + rest + " seconds)");
/*     */             }
/*     */           }
/*     */         
/*     */         } finally {
/*     */           
/* 158 */           JdbcUtils.closeStatement(stmt);
/* 159 */           JdbcUtils.closeConnection(con);
/*     */         } 
/*     */         
/* 162 */         if (!validated) {
/* 163 */           TimeUnit.SECONDS.sleep(this.interval);
/*     */         }
/*     */       } 
/*     */       
/* 167 */       if (!validated) {
/* 168 */         throw new CannotGetJdbcConnectionException("Database has not started up within " + this.timeout + " seconds", latestEx);
/*     */       }
/*     */ 
/*     */       
/* 172 */       if (this.logger.isInfoEnabled()) {
/* 173 */         float duration = (float)(System.currentTimeMillis() - beginTime) / 1000.0F;
/* 174 */         this.logger.info("Database startup detected after " + duration + " seconds");
/*     */       }
/*     */     
/* 177 */     } catch (InterruptedException ex) {
/*     */       
/* 179 */       Thread.currentThread().interrupt();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\DatabaseStartupValidator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */