package org.springframework.jdbc.support;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public interface SqlValue {
  void setValue(PreparedStatement paramPreparedStatement, int paramInt) throws SQLException;
  
  void cleanup();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\SqlValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */