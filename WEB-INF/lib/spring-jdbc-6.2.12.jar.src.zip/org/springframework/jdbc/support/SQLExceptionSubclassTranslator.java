/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.dao.CannotAcquireLockException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.dao.DataIntegrityViolationException;
/*     */ import org.springframework.dao.DuplicateKeyException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.dao.PermissionDeniedDataAccessException;
/*     */ import org.springframework.dao.PessimisticLockingFailureException;
/*     */ import org.springframework.dao.QueryTimeoutException;
/*     */ import org.springframework.dao.RecoverableDataAccessException;
/*     */ import org.springframework.dao.TransientDataAccessResourceException;
/*     */ import org.springframework.jdbc.BadSqlGrammarException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLExceptionSubclassTranslator
/*     */   extends AbstractFallbackSQLExceptionTranslator
/*     */ {
/*     */   public SQLExceptionSubclassTranslator() {
/*  70 */     setFallbackTranslator(new SQLStateSQLExceptionTranslator());
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected DataAccessException doTranslate(String task, @Nullable String sql, SQLException ex) {
/*  76 */     SQLException sqlEx = ex;
/*  77 */     if (sqlEx instanceof java.sql.BatchUpdateException && sqlEx.getNextException() != null) {
/*  78 */       sqlEx = sqlEx.getNextException();
/*     */     }
/*     */     
/*  81 */     if (sqlEx instanceof java.sql.SQLTransientException) {
/*  82 */       if (sqlEx instanceof java.sql.SQLTransientConnectionException) {
/*  83 */         return (DataAccessException)new TransientDataAccessResourceException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       }
/*  85 */       if (sqlEx instanceof java.sql.SQLTransactionRollbackException) {
/*  86 */         if (SQLStateSQLExceptionTranslator.indicatesCannotAcquireLock(sqlEx.getSQLState())) {
/*  87 */           return (DataAccessException)new CannotAcquireLockException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/*  89 */         return (DataAccessException)new PessimisticLockingFailureException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       } 
/*  91 */       if (sqlEx instanceof java.sql.SQLTimeoutException) {
/*  92 */         return (DataAccessException)new QueryTimeoutException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       }
/*     */     }
/*  95 */     else if (sqlEx instanceof java.sql.SQLNonTransientException) {
/*  96 */       if (sqlEx instanceof java.sql.SQLNonTransientConnectionException) {
/*  97 */         return (DataAccessException)new DataAccessResourceFailureException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       }
/*  99 */       if (sqlEx instanceof java.sql.SQLDataException) {
/* 100 */         return (DataAccessException)new DataIntegrityViolationException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       }
/* 102 */       if (sqlEx instanceof java.sql.SQLIntegrityConstraintViolationException) {
/* 103 */         if (SQLStateSQLExceptionTranslator.indicatesDuplicateKey(sqlEx.getSQLState(), sqlEx.getErrorCode())) {
/* 104 */           return (DataAccessException)new DuplicateKeyException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/* 106 */         return (DataAccessException)new DataIntegrityViolationException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       } 
/* 108 */       if (sqlEx instanceof java.sql.SQLInvalidAuthorizationSpecException) {
/* 109 */         return (DataAccessException)new PermissionDeniedDataAccessException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       }
/* 111 */       if (sqlEx instanceof java.sql.SQLSyntaxErrorException) {
/* 112 */         return (DataAccessException)new BadSqlGrammarException(task, (sql != null) ? sql : "", sqlEx);
/*     */       }
/* 114 */       if (sqlEx instanceof java.sql.SQLFeatureNotSupportedException) {
/* 115 */         return (DataAccessException)new InvalidDataAccessApiUsageException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */       }
/*     */     }
/* 118 */     else if (sqlEx instanceof java.sql.SQLRecoverableException) {
/* 119 */       return (DataAccessException)new RecoverableDataAccessException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */     } 
/*     */ 
/*     */     
/* 123 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\SQLExceptionSubclassTranslator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */