/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JdbcAccessor
/*     */   implements InitializingBean
/*     */ {
/*  44 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private DataSource dataSource;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile SQLExceptionTranslator exceptionTranslator;
/*     */ 
/*     */   
/*     */   private boolean lazyInit = true;
/*     */ 
/*     */   
/*     */   public void setDataSource(@Nullable DataSource dataSource) {
/*  59 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getDataSource() {
/*  67 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataSource obtainDataSource() {
/*  77 */     DataSource dataSource = getDataSource();
/*  78 */     Assert.state((dataSource != null), "No DataSource set");
/*  79 */     return dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabaseProductName(String dbName) {
/*  92 */     if (SQLErrorCodeSQLExceptionTranslator.hasUserProvidedErrorCodesFile()) {
/*  93 */       this.exceptionTranslator = new SQLErrorCodeSQLExceptionTranslator(dbName);
/*     */     } else {
/*     */       
/*  96 */       this.exceptionTranslator = new SQLExceptionSubclassTranslator();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExceptionTranslator(SQLExceptionTranslator exceptionTranslator) {
/* 109 */     this.exceptionTranslator = exceptionTranslator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLExceptionTranslator getExceptionTranslator() {
/* 118 */     SQLExceptionTranslator exceptionTranslator = this.exceptionTranslator;
/* 119 */     if (exceptionTranslator != null) {
/* 120 */       return exceptionTranslator;
/*     */     }
/* 122 */     synchronized (this) {
/* 123 */       exceptionTranslator = this.exceptionTranslator;
/* 124 */       if (exceptionTranslator == null) {
/* 125 */         if (SQLErrorCodeSQLExceptionTranslator.hasUserProvidedErrorCodesFile()) {
/* 126 */           exceptionTranslator = new SQLErrorCodeSQLExceptionTranslator(obtainDataSource());
/*     */         } else {
/*     */           
/* 129 */           exceptionTranslator = new SQLExceptionSubclassTranslator();
/*     */         } 
/* 131 */         this.exceptionTranslator = exceptionTranslator;
/*     */       } 
/* 133 */       return exceptionTranslator;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLazyInit(boolean lazyInit) {
/* 146 */     this.lazyInit = lazyInit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLazyInit() {
/* 154 */     return this.lazyInit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 163 */     if (getDataSource() == null) {
/* 164 */       throw new IllegalArgumentException("Property 'dataSource' is required");
/*     */     }
/* 166 */     if (!isLazyInit())
/* 167 */       getExceptionTranslator(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\JdbcAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */