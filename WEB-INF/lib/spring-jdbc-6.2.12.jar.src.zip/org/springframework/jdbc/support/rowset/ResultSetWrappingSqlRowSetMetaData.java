/*     */ package org.springframework.jdbc.support.rowset;
/*     */ 
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.jdbc.InvalidResultSetAccessException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultSetWrappingSqlRowSetMetaData
/*     */   implements SqlRowSetMetaData
/*     */ {
/*     */   private final ResultSetMetaData resultSetMetaData;
/*     */   @Nullable
/*     */   private String[] columnNames;
/*     */   
/*     */   public ResultSetWrappingSqlRowSetMetaData(ResultSetMetaData resultSetMetaData) {
/*  55 */     this.resultSetMetaData = resultSetMetaData;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCatalogName(int column) throws InvalidResultSetAccessException {
/*     */     try {
/*  62 */       return this.resultSetMetaData.getCatalogName(column);
/*     */     }
/*  64 */     catch (SQLException se) {
/*  65 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnClassName(int column) throws InvalidResultSetAccessException {
/*     */     try {
/*  72 */       return this.resultSetMetaData.getColumnClassName(column);
/*     */     }
/*  74 */     catch (SQLException se) {
/*  75 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnCount() throws InvalidResultSetAccessException {
/*     */     try {
/*  82 */       return this.resultSetMetaData.getColumnCount();
/*     */     }
/*  84 */     catch (SQLException se) {
/*  85 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getColumnNames() throws InvalidResultSetAccessException {
/*  91 */     if (this.columnNames == null) {
/*  92 */       this.columnNames = new String[getColumnCount()];
/*  93 */       for (int i = 0; i < getColumnCount(); i++) {
/*  94 */         this.columnNames[i] = getColumnName(i + 1);
/*     */       }
/*     */     } 
/*  97 */     return this.columnNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnDisplaySize(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 103 */       return this.resultSetMetaData.getColumnDisplaySize(column);
/*     */     }
/* 105 */     catch (SQLException se) {
/* 106 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnLabel(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 113 */       return this.resultSetMetaData.getColumnLabel(column);
/*     */     }
/* 115 */     catch (SQLException se) {
/* 116 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnName(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 123 */       return this.resultSetMetaData.getColumnName(column);
/*     */     }
/* 125 */     catch (SQLException se) {
/* 126 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnType(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 133 */       return this.resultSetMetaData.getColumnType(column);
/*     */     }
/* 135 */     catch (SQLException se) {
/* 136 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnTypeName(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 143 */       return this.resultSetMetaData.getColumnTypeName(column);
/*     */     }
/* 145 */     catch (SQLException se) {
/* 146 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrecision(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 153 */       return this.resultSetMetaData.getPrecision(column);
/*     */     }
/* 155 */     catch (SQLException se) {
/* 156 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getScale(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 163 */       return this.resultSetMetaData.getScale(column);
/*     */     }
/* 165 */     catch (SQLException se) {
/* 166 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSchemaName(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 173 */       return this.resultSetMetaData.getSchemaName(column);
/*     */     }
/* 175 */     catch (SQLException se) {
/* 176 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTableName(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 183 */       return this.resultSetMetaData.getTableName(column);
/*     */     }
/* 185 */     catch (SQLException se) {
/* 186 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCaseSensitive(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 193 */       return this.resultSetMetaData.isCaseSensitive(column);
/*     */     }
/* 195 */     catch (SQLException se) {
/* 196 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCurrency(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 203 */       return this.resultSetMetaData.isCurrency(column);
/*     */     }
/* 205 */     catch (SQLException se) {
/* 206 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSigned(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 213 */       return this.resultSetMetaData.isSigned(column);
/*     */     }
/* 215 */     catch (SQLException se) {
/* 216 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\rowset\ResultSetWrappingSqlRowSetMetaData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */