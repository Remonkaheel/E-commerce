package org.springframework.jdbc.support.rowset;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.lang.Nullable;

public interface SqlRowSet extends Serializable {
  SqlRowSetMetaData getMetaData();
  
  int findColumn(String paramString) throws InvalidResultSetAccessException;
  
  @Nullable
  BigDecimal getBigDecimal(int paramInt) throws InvalidResultSetAccessException;
  
  @Nullable
  BigDecimal getBigDecimal(String paramString) throws InvalidResultSetAccessException;
  
  boolean getBoolean(int paramInt) throws InvalidResultSetAccessException;
  
  boolean getBoolean(String paramString) throws InvalidResultSetAccessException;
  
  byte getByte(int paramInt) throws InvalidResultSetAccessException;
  
  byte getByte(String paramString) throws InvalidResultSetAccessException;
  
  @Nullable
  Date getDate(int paramInt) throws InvalidResultSetAccessException;
  
  @Nullable
  Date getDate(String paramString) throws InvalidResultSetAccessException;
  
  @Nullable
  Date getDate(int paramInt, Calendar paramCalendar) throws InvalidResultSetAccessException;
  
  @Nullable
  Date getDate(String paramString, Calendar paramCalendar) throws InvalidResultSetAccessException;
  
  double getDouble(int paramInt) throws InvalidResultSetAccessException;
  
  double getDouble(String paramString) throws InvalidResultSetAccessException;
  
  float getFloat(int paramInt) throws InvalidResultSetAccessException;
  
  float getFloat(String paramString) throws InvalidResultSetAccessException;
  
  int getInt(int paramInt) throws InvalidResultSetAccessException;
  
  int getInt(String paramString) throws InvalidResultSetAccessException;
  
  long getLong(int paramInt) throws InvalidResultSetAccessException;
  
  long getLong(String paramString) throws InvalidResultSetAccessException;
  
  @Nullable
  String getNString(int paramInt) throws InvalidResultSetAccessException;
  
  @Nullable
  String getNString(String paramString) throws InvalidResultSetAccessException;
  
  @Nullable
  Object getObject(int paramInt) throws InvalidResultSetAccessException;
  
  @Nullable
  Object getObject(String paramString) throws InvalidResultSetAccessException;
  
  @Nullable
  Object getObject(int paramInt, Map<String, Class<?>> paramMap) throws InvalidResultSetAccessException;
  
  @Nullable
  Object getObject(String paramString, Map<String, Class<?>> paramMap) throws InvalidResultSetAccessException;
  
  @Nullable
  <T> T getObject(int paramInt, Class<T> paramClass) throws InvalidResultSetAccessException;
  
  @Nullable
  <T> T getObject(String paramString, Class<T> paramClass) throws InvalidResultSetAccessException;
  
  short getShort(int paramInt) throws InvalidResultSetAccessException;
  
  short getShort(String paramString) throws InvalidResultSetAccessException;
  
  @Nullable
  String getString(int paramInt) throws InvalidResultSetAccessException;
  
  @Nullable
  String getString(String paramString) throws InvalidResultSetAccessException;
  
  @Nullable
  Time getTime(int paramInt) throws InvalidResultSetAccessException;
  
  @Nullable
  Time getTime(String paramString) throws InvalidResultSetAccessException;
  
  @Nullable
  Time getTime(int paramInt, Calendar paramCalendar) throws InvalidResultSetAccessException;
  
  @Nullable
  Time getTime(String paramString, Calendar paramCalendar) throws InvalidResultSetAccessException;
  
  @Nullable
  Timestamp getTimestamp(int paramInt) throws InvalidResultSetAccessException;
  
  @Nullable
  Timestamp getTimestamp(String paramString) throws InvalidResultSetAccessException;
  
  @Nullable
  Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws InvalidResultSetAccessException;
  
  @Nullable
  Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws InvalidResultSetAccessException;
  
  boolean absolute(int paramInt) throws InvalidResultSetAccessException;
  
  void afterLast() throws InvalidResultSetAccessException;
  
  void beforeFirst() throws InvalidResultSetAccessException;
  
  boolean first() throws InvalidResultSetAccessException;
  
  int getRow() throws InvalidResultSetAccessException;
  
  boolean isAfterLast() throws InvalidResultSetAccessException;
  
  boolean isBeforeFirst() throws InvalidResultSetAccessException;
  
  boolean isFirst() throws InvalidResultSetAccessException;
  
  boolean isLast() throws InvalidResultSetAccessException;
  
  boolean last() throws InvalidResultSetAccessException;
  
  boolean next() throws InvalidResultSetAccessException;
  
  boolean previous() throws InvalidResultSetAccessException;
  
  boolean relative(int paramInt) throws InvalidResultSetAccessException;
  
  boolean wasNull() throws InvalidResultSetAccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\rowset\SqlRowSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */