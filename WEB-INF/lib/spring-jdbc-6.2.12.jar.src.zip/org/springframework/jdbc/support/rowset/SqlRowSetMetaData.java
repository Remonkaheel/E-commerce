package org.springframework.jdbc.support.rowset;

import org.springframework.jdbc.InvalidResultSetAccessException;

public interface SqlRowSetMetaData {
  String getCatalogName(int paramInt) throws InvalidResultSetAccessException;
  
  String getColumnClassName(int paramInt) throws InvalidResultSetAccessException;
  
  int getColumnCount() throws InvalidResultSetAccessException;
  
  String[] getColumnNames() throws InvalidResultSetAccessException;
  
  int getColumnDisplaySize(int paramInt) throws InvalidResultSetAccessException;
  
  String getColumnLabel(int paramInt) throws InvalidResultSetAccessException;
  
  String getColumnName(int paramInt) throws InvalidResultSetAccessException;
  
  int getColumnType(int paramInt) throws InvalidResultSetAccessException;
  
  String getColumnTypeName(int paramInt) throws InvalidResultSetAccessException;
  
  int getPrecision(int paramInt) throws InvalidResultSetAccessException;
  
  int getScale(int paramInt) throws InvalidResultSetAccessException;
  
  String getSchemaName(int paramInt) throws InvalidResultSetAccessException;
  
  String getTableName(int paramInt) throws InvalidResultSetAccessException;
  
  boolean isCaseSensitive(int paramInt) throws InvalidResultSetAccessException;
  
  boolean isCurrency(int paramInt) throws InvalidResultSetAccessException;
  
  boolean isSigned(int paramInt) throws InvalidResultSetAccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\rowset\SqlRowSetMetaData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */