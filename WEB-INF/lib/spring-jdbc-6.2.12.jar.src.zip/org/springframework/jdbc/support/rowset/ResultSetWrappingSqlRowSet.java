/*     */ package org.springframework.jdbc.support.rowset;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Date;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.springframework.jdbc.InvalidResultSetAccessException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultSetWrappingSqlRowSet
/*     */   implements SqlRowSet
/*     */ {
/*     */   private static final long serialVersionUID = -4688694393146734764L;
/*     */   private final ResultSet resultSet;
/*     */   private final SqlRowSetMetaData rowSetMetaData;
/*     */   private final Map<String, Integer> columnLabelMap;
/*     */   
/*     */   public ResultSetWrappingSqlRowSet(ResultSet resultSet) throws InvalidResultSetAccessException {
/*  92 */     this.resultSet = resultSet;
/*     */     try {
/*  94 */       this.rowSetMetaData = new ResultSetWrappingSqlRowSetMetaData(resultSet.getMetaData());
/*     */     }
/*  96 */     catch (SQLException se) {
/*  97 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */     try {
/* 100 */       ResultSetMetaData rsmd = resultSet.getMetaData();
/* 101 */       if (rsmd != null) {
/* 102 */         int columnCount = rsmd.getColumnCount();
/* 103 */         this.columnLabelMap = CollectionUtils.newHashMap(columnCount * 2);
/* 104 */         for (int i = 1; i <= columnCount; i++) {
/* 105 */           String key = rsmd.getColumnLabel(i);
/*     */ 
/*     */           
/* 108 */           if (!this.columnLabelMap.containsKey(key)) {
/* 109 */             this.columnLabelMap.put(key, Integer.valueOf(i));
/*     */           }
/*     */ 
/*     */           
/* 113 */           String table = rsmd.getTableName(i);
/* 114 */           if (StringUtils.hasLength(table)) {
/* 115 */             key = table + "." + table;
/* 116 */             if (!this.columnLabelMap.containsKey(key)) {
/* 117 */               this.columnLabelMap.put(key, Integer.valueOf(i));
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 123 */         this.columnLabelMap = Collections.emptyMap();
/*     */       }
/*     */     
/* 126 */     } catch (SQLException se) {
/* 127 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ResultSet getResultSet() {
/* 139 */     return this.resultSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SqlRowSetMetaData getMetaData() {
/* 147 */     return this.rowSetMetaData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int findColumn(String columnLabel) throws InvalidResultSetAccessException {
/* 155 */     Integer columnIndex = this.columnLabelMap.get(columnLabel);
/* 156 */     if (columnIndex != null) {
/* 157 */       return columnIndex.intValue();
/*     */     }
/*     */     
/*     */     try {
/* 161 */       return this.resultSet.findColumn(columnLabel);
/*     */     }
/* 163 */     catch (SQLException se) {
/* 164 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BigDecimal getBigDecimal(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 179 */       return this.resultSet.getBigDecimal(columnIndex);
/*     */     }
/* 181 */     catch (SQLException se) {
/* 182 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BigDecimal getBigDecimal(String columnLabel) throws InvalidResultSetAccessException {
/* 192 */     return getBigDecimal(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBoolean(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 201 */       return this.resultSet.getBoolean(columnIndex);
/*     */     }
/* 203 */     catch (SQLException se) {
/* 204 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBoolean(String columnLabel) throws InvalidResultSetAccessException {
/* 213 */     return getBoolean(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getByte(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 222 */       return this.resultSet.getByte(columnIndex);
/*     */     }
/* 224 */     catch (SQLException se) {
/* 225 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getByte(String columnLabel) throws InvalidResultSetAccessException {
/* 234 */     return getByte(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Date getDate(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 244 */       return this.resultSet.getDate(columnIndex);
/*     */     }
/* 246 */     catch (SQLException se) {
/* 247 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Date getDate(String columnLabel) throws InvalidResultSetAccessException {
/* 257 */     return getDate(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Date getDate(int columnIndex, Calendar cal) throws InvalidResultSetAccessException {
/*     */     try {
/* 267 */       return this.resultSet.getDate(columnIndex, cal);
/*     */     }
/* 269 */     catch (SQLException se) {
/* 270 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Date getDate(String columnLabel, Calendar cal) throws InvalidResultSetAccessException {
/* 280 */     return getDate(findColumn(columnLabel), cal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDouble(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 289 */       return this.resultSet.getDouble(columnIndex);
/*     */     }
/* 291 */     catch (SQLException se) {
/* 292 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDouble(String columnLabel) throws InvalidResultSetAccessException {
/* 301 */     return getDouble(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloat(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 310 */       return this.resultSet.getFloat(columnIndex);
/*     */     }
/* 312 */     catch (SQLException se) {
/* 313 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloat(String columnLabel) throws InvalidResultSetAccessException {
/* 322 */     return getFloat(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInt(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 331 */       return this.resultSet.getInt(columnIndex);
/*     */     }
/* 333 */     catch (SQLException se) {
/* 334 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInt(String columnLabel) throws InvalidResultSetAccessException {
/* 343 */     return getInt(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLong(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 352 */       return this.resultSet.getLong(columnIndex);
/*     */     }
/* 354 */     catch (SQLException se) {
/* 355 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLong(String columnLabel) throws InvalidResultSetAccessException {
/* 364 */     return getLong(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getNString(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 374 */       return this.resultSet.getNString(columnIndex);
/*     */     }
/* 376 */     catch (SQLException se) {
/* 377 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getNString(String columnLabel) throws InvalidResultSetAccessException {
/* 387 */     return getNString(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getObject(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 397 */       return this.resultSet.getObject(columnIndex);
/*     */     }
/* 399 */     catch (SQLException se) {
/* 400 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getObject(String columnLabel) throws InvalidResultSetAccessException {
/* 410 */     return getObject(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getObject(int columnIndex, Map<String, Class<?>> map) throws InvalidResultSetAccessException {
/*     */     try {
/* 420 */       return this.resultSet.getObject(columnIndex, map);
/*     */     }
/* 422 */     catch (SQLException se) {
/* 423 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getObject(String columnLabel, Map<String, Class<?>> map) throws InvalidResultSetAccessException {
/* 433 */     return getObject(findColumn(columnLabel), map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getObject(int columnIndex, Class<T> type) throws InvalidResultSetAccessException {
/*     */     try {
/* 443 */       return this.resultSet.getObject(columnIndex, type);
/*     */     }
/* 445 */     catch (SQLException se) {
/* 446 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getObject(String columnLabel, Class<T> type) throws InvalidResultSetAccessException {
/* 456 */     return getObject(findColumn(columnLabel), type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getShort(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 465 */       return this.resultSet.getShort(columnIndex);
/*     */     }
/* 467 */     catch (SQLException se) {
/* 468 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getShort(String columnLabel) throws InvalidResultSetAccessException {
/* 477 */     return getShort(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getString(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 487 */       return this.resultSet.getString(columnIndex);
/*     */     }
/* 489 */     catch (SQLException se) {
/* 490 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getString(String columnLabel) throws InvalidResultSetAccessException {
/* 500 */     return getString(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Time getTime(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 510 */       return this.resultSet.getTime(columnIndex);
/*     */     }
/* 512 */     catch (SQLException se) {
/* 513 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Time getTime(String columnLabel) throws InvalidResultSetAccessException {
/* 523 */     return getTime(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Time getTime(int columnIndex, Calendar cal) throws InvalidResultSetAccessException {
/*     */     try {
/* 533 */       return this.resultSet.getTime(columnIndex, cal);
/*     */     }
/* 535 */     catch (SQLException se) {
/* 536 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Time getTime(String columnLabel, Calendar cal) throws InvalidResultSetAccessException {
/* 546 */     return getTime(findColumn(columnLabel), cal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Timestamp getTimestamp(int columnIndex) throws InvalidResultSetAccessException {
/*     */     try {
/* 556 */       return this.resultSet.getTimestamp(columnIndex);
/*     */     }
/* 558 */     catch (SQLException se) {
/* 559 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Timestamp getTimestamp(String columnLabel) throws InvalidResultSetAccessException {
/* 569 */     return getTimestamp(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Timestamp getTimestamp(int columnIndex, Calendar cal) throws InvalidResultSetAccessException {
/*     */     try {
/* 579 */       return this.resultSet.getTimestamp(columnIndex, cal);
/*     */     }
/* 581 */     catch (SQLException se) {
/* 582 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Timestamp getTimestamp(String columnLabel, Calendar cal) throws InvalidResultSetAccessException {
/* 592 */     return getTimestamp(findColumn(columnLabel), cal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean absolute(int row) throws InvalidResultSetAccessException {
/*     */     try {
/* 604 */       return this.resultSet.absolute(row);
/*     */     }
/* 606 */     catch (SQLException se) {
/* 607 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterLast() throws InvalidResultSetAccessException {
/*     */     try {
/* 617 */       this.resultSet.afterLast();
/*     */     }
/* 619 */     catch (SQLException se) {
/* 620 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeFirst() throws InvalidResultSetAccessException {
/*     */     try {
/* 630 */       this.resultSet.beforeFirst();
/*     */     }
/* 632 */     catch (SQLException se) {
/* 633 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean first() throws InvalidResultSetAccessException {
/*     */     try {
/* 643 */       return this.resultSet.first();
/*     */     }
/* 645 */     catch (SQLException se) {
/* 646 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRow() throws InvalidResultSetAccessException {
/*     */     try {
/* 656 */       return this.resultSet.getRow();
/*     */     }
/* 658 */     catch (SQLException se) {
/* 659 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAfterLast() throws InvalidResultSetAccessException {
/*     */     try {
/* 669 */       return this.resultSet.isAfterLast();
/*     */     }
/* 671 */     catch (SQLException se) {
/* 672 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBeforeFirst() throws InvalidResultSetAccessException {
/*     */     try {
/* 682 */       return this.resultSet.isBeforeFirst();
/*     */     }
/* 684 */     catch (SQLException se) {
/* 685 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFirst() throws InvalidResultSetAccessException {
/*     */     try {
/* 695 */       return this.resultSet.isFirst();
/*     */     }
/* 697 */     catch (SQLException se) {
/* 698 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLast() throws InvalidResultSetAccessException {
/*     */     try {
/* 708 */       return this.resultSet.isLast();
/*     */     }
/* 710 */     catch (SQLException se) {
/* 711 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean last() throws InvalidResultSetAccessException {
/*     */     try {
/* 721 */       return this.resultSet.last();
/*     */     }
/* 723 */     catch (SQLException se) {
/* 724 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean next() throws InvalidResultSetAccessException {
/*     */     try {
/* 734 */       return this.resultSet.next();
/*     */     }
/* 736 */     catch (SQLException se) {
/* 737 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean previous() throws InvalidResultSetAccessException {
/*     */     try {
/* 747 */       return this.resultSet.previous();
/*     */     }
/* 749 */     catch (SQLException se) {
/* 750 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean relative(int rows) throws InvalidResultSetAccessException {
/*     */     try {
/* 760 */       return this.resultSet.relative(rows);
/*     */     }
/* 762 */     catch (SQLException se) {
/* 763 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean wasNull() throws InvalidResultSetAccessException {
/*     */     try {
/* 773 */       return this.resultSet.wasNull();
/*     */     }
/* 775 */     catch (SQLException se) {
/* 776 */       throw new InvalidResultSetAccessException(se);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\rowset\ResultSetWrappingSqlRowSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */