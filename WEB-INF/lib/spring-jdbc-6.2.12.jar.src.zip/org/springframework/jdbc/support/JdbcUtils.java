/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.Date;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.sql.Types;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.NumberUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JdbcUtils
/*     */ {
/*     */   public static final int TYPE_UNKNOWN = -2147483648;
/*  62 */   private static final Log logger = LogFactory.getLog(JdbcUtils.class);
/*     */   
/*  64 */   private static final Map<Integer, String> typeNames = new HashMap<>();
/*     */   
/*     */   static {
/*     */     try {
/*  68 */       for (Field field : Types.class.getFields()) {
/*  69 */         typeNames.put((Integer)field.get(null), field.getName());
/*     */       }
/*     */     }
/*  72 */     catch (Exception ex) {
/*  73 */       throw new IllegalStateException("Failed to resolve JDBC Types constants", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeConnection(@Nullable Connection con) {
/*  84 */     if (con != null) {
/*     */       try {
/*  86 */         con.close();
/*     */       }
/*  88 */       catch (SQLException ex) {
/*  89 */         logger.debug("Could not close JDBC Connection", ex);
/*     */       }
/*  91 */       catch (Throwable ex) {
/*     */         
/*  93 */         logger.debug("Unexpected exception on closing JDBC Connection", ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeStatement(@Nullable Statement stmt) {
/* 104 */     if (stmt != null) {
/*     */       try {
/* 106 */         stmt.close();
/*     */       }
/* 108 */       catch (SQLException ex) {
/* 109 */         logger.trace("Could not close JDBC Statement", ex);
/*     */       }
/* 111 */       catch (Throwable ex) {
/*     */         
/* 113 */         logger.trace("Unexpected exception on closing JDBC Statement", ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeResultSet(@Nullable ResultSet rs) {
/* 124 */     if (rs != null) {
/*     */       try {
/* 126 */         rs.close();
/*     */       }
/* 128 */       catch (SQLException ex) {
/* 129 */         logger.trace("Could not close JDBC ResultSet", ex);
/*     */       }
/* 131 */       catch (Throwable ex) {
/*     */         
/* 133 */         logger.trace("Unexpected exception on closing JDBC ResultSet", ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Object getResultSetValue(ResultSet rs, int index, @Nullable Class<?> requiredType) throws SQLException {
/*     */     Object value;
/* 155 */     if (requiredType == null) {
/* 156 */       return getResultSetValue(rs, index);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     if (String.class == requiredType) {
/* 163 */       return rs.getString(index);
/*     */     }
/* 165 */     if (boolean.class == requiredType || Boolean.class == requiredType) {
/* 166 */       value = Boolean.valueOf(rs.getBoolean(index));
/*     */     }
/* 168 */     else if (byte.class == requiredType || Byte.class == requiredType) {
/* 169 */       value = Byte.valueOf(rs.getByte(index));
/*     */     }
/* 171 */     else if (short.class == requiredType || Short.class == requiredType) {
/* 172 */       value = Short.valueOf(rs.getShort(index));
/*     */     }
/* 174 */     else if (int.class == requiredType || Integer.class == requiredType) {
/* 175 */       value = Integer.valueOf(rs.getInt(index));
/*     */     }
/* 177 */     else if (long.class == requiredType || Long.class == requiredType) {
/* 178 */       value = Long.valueOf(rs.getLong(index));
/*     */     }
/* 180 */     else if (float.class == requiredType || Float.class == requiredType) {
/* 181 */       value = Float.valueOf(rs.getFloat(index));
/*     */     }
/* 183 */     else if (double.class == requiredType || Double.class == requiredType || Number.class == requiredType) {
/*     */       
/* 185 */       value = Double.valueOf(rs.getDouble(index));
/*     */     } else {
/* 187 */       if (BigDecimal.class == requiredType) {
/* 188 */         return rs.getBigDecimal(index);
/*     */       }
/* 190 */       if (Date.class == requiredType) {
/* 191 */         return rs.getDate(index);
/*     */       }
/* 193 */       if (Time.class == requiredType) {
/* 194 */         return rs.getTime(index);
/*     */       }
/* 196 */       if (Timestamp.class == requiredType || Date.class == requiredType) {
/* 197 */         return rs.getTimestamp(index);
/*     */       }
/* 199 */       if (byte[].class == requiredType) {
/* 200 */         return rs.getBytes(index);
/*     */       }
/* 202 */       if (Blob.class == requiredType) {
/* 203 */         return rs.getBlob(index);
/*     */       }
/* 205 */       if (Clob.class == requiredType) {
/* 206 */         return rs.getClob(index);
/*     */       }
/* 208 */       if (requiredType.isEnum()) {
/*     */ 
/*     */ 
/*     */         
/* 212 */         Object obj = rs.getObject(index);
/* 213 */         if (obj instanceof String) {
/* 214 */           return obj;
/*     */         }
/* 216 */         if (obj instanceof Number) { Number number = (Number)obj;
/*     */ 
/*     */           
/* 219 */           return NumberUtils.convertNumberToTargetClass(number, Integer.class); }
/*     */ 
/*     */ 
/*     */         
/* 223 */         return rs.getString(index);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 230 */         return rs.getObject(index, requiredType);
/*     */       }
/* 232 */       catch (SQLFeatureNotSupportedException|AbstractMethodError ex) {
/* 233 */         logger.debug("JDBC driver does not support JDBC 4.1 'getObject(int, Class)' method", ex);
/*     */       }
/* 235 */       catch (SQLException ex) {
/* 236 */         if (logger.isDebugEnabled()) {
/* 237 */           logger.debug("JDBC driver has limited support for 'getObject(int, Class)' with column type: " + requiredType
/* 238 */               .getName(), ex);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 244 */       String typeName = requiredType.getSimpleName();
/* 245 */       switch (typeName) { case "LocalDate": case "LocalTime": case "LocalDateTime":  }  return 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 251 */         getResultSetValue(rs, index);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 256 */     return rs.wasNull() ? null : value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Object getResultSetValue(ResultSet rs, int index) throws SQLException {
/* 279 */     Object obj = rs.getObject(index);
/* 280 */     String className = null;
/* 281 */     if (obj != null) {
/* 282 */       className = obj.getClass().getName();
/*     */     }
/* 284 */     if (obj instanceof Blob) { Blob blob = (Blob)obj;
/* 285 */       obj = blob.getBytes(1L, (int)blob.length()); }
/*     */     
/* 287 */     else if (obj instanceof Clob) { Clob clob = (Clob)obj;
/* 288 */       obj = clob.getSubString(1L, (int)clob.length()); }
/*     */     
/* 290 */     else if ("oracle.sql.TIMESTAMP".equals(className) || "oracle.sql.TIMESTAMPTZ".equals(className))
/* 291 */     { obj = rs.getTimestamp(index); }
/*     */     
/* 293 */     else if (className != null && className.startsWith("oracle.sql.DATE"))
/* 294 */     { String metaDataClassName = rs.getMetaData().getColumnClassName(index);
/* 295 */       if ("java.sql.Timestamp".equals(metaDataClassName) || "oracle.sql.TIMESTAMP".equals(metaDataClassName)) {
/* 296 */         obj = rs.getTimestamp(index);
/*     */       } else {
/*     */         
/* 299 */         obj = rs.getDate(index);
/*     */       }
/*     */        }
/* 302 */     else if (obj instanceof Date && 
/* 303 */       "java.sql.Timestamp".equals(rs.getMetaData().getColumnClassName(index)))
/* 304 */     { obj = rs.getTimestamp(index); }
/*     */ 
/*     */     
/* 307 */     return obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T extractDatabaseMetaData(DataSource dataSource, DatabaseMetaDataCallback<T> action) throws MetaDataAccessException {
/* 329 */     Connection con = null; try {
/*     */       DatabaseMetaData metaData;
/* 331 */       con = DataSourceUtils.getConnection(dataSource);
/*     */       
/*     */       try {
/* 334 */         metaData = con.getMetaData();
/*     */       }
/* 336 */       catch (SQLException ex) {
/* 337 */         if (DataSourceUtils.isConnectionTransactional(con, dataSource)) {
/*     */           
/* 339 */           DataSourceUtils.releaseConnection(con, dataSource);
/* 340 */           con = null;
/* 341 */           logger.debug("Failed to obtain DatabaseMetaData from transactional Connection - retrying against fresh Connection", ex);
/*     */           
/* 343 */           con = dataSource.getConnection();
/* 344 */           metaData = con.getMetaData();
/*     */         } else {
/*     */           
/* 347 */           throw ex;
/*     */         } 
/*     */       } 
/* 350 */       if (metaData == null)
/*     */       {
/* 352 */         throw new MetaDataAccessException("DatabaseMetaData returned by Connection [" + String.valueOf(con) + "] was null");
/*     */       }
/* 354 */       return action.processMetaData(metaData);
/*     */     }
/* 356 */     catch (CannotGetJdbcConnectionException ex) {
/* 357 */       DatabaseMetaData metaData; throw new MetaDataAccessException("Could not get Connection for extracting meta-data", metaData);
/*     */     }
/* 359 */     catch (SQLException ex) {
/* 360 */       throw new MetaDataAccessException("Error while extracting DatabaseMetaData", ex);
/*     */     }
/* 362 */     catch (AbstractMethodError err) {
/* 363 */       throw new MetaDataAccessException("JDBC DatabaseMetaData method not implemented by JDBC driver - upgrade your driver", err);
/*     */     }
/*     */     finally {
/*     */       
/* 367 */       DataSourceUtils.releaseConnection(con, dataSource);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> T extractDatabaseMetaData(DataSource dataSource, String metaDataMethodName) throws MetaDataAccessException {
/* 389 */     return extractDatabaseMetaData(dataSource, dbmd -> {
/*     */ 
/*     */           
/*     */           try {
/*     */             return DatabaseMetaData.class.getMethod(metaDataMethodName, new Class[0]).invoke(dbmd, new Object[0]);
/* 394 */           } catch (NoSuchMethodException ex) {
/*     */             
/*     */             throw new MetaDataAccessException("No method named '" + metaDataMethodName + "' found on DatabaseMetaData instance [" + String.valueOf(dbmd) + "]", ex);
/*     */           }
/* 398 */           catch (IllegalAccessException ex) {
/*     */             
/*     */             throw new MetaDataAccessException("Could not access DatabaseMetaData method '" + metaDataMethodName + "'", ex);
/*     */           }
/* 402 */           catch (InvocationTargetException ex) {
/*     */             Throwable patt14768$temp = ex.getTargetException();
/*     */             if (patt14768$temp instanceof SQLException) {
/*     */               SQLException sqlException = (SQLException)patt14768$temp;
/*     */               throw sqlException;
/*     */             } 
/*     */             throw new MetaDataAccessException("Invocation of DatabaseMetaData method '" + metaDataMethodName + "' failed", ex);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean supportsBatchUpdates(Connection con) {
/*     */     try {
/* 425 */       DatabaseMetaData dbmd = con.getMetaData();
/* 426 */       if (dbmd != null) {
/* 427 */         if (dbmd.supportsBatchUpdates()) {
/* 428 */           logger.debug("JDBC driver supports batch updates");
/* 429 */           return true;
/*     */         } 
/*     */         
/* 432 */         logger.debug("JDBC driver does not support batch updates");
/*     */       }
/*     */     
/*     */     }
/* 436 */     catch (SQLException ex) {
/* 437 */       logger.debug("JDBC driver 'supportsBatchUpdates' method threw exception", ex);
/*     */     } 
/* 439 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static String commonDatabaseName(@Nullable String source) {
/* 450 */     String name = source;
/* 451 */     if (source != null && source.startsWith("DB2")) {
/* 452 */       name = "DB2";
/*     */     }
/* 454 */     else if ("Sybase SQL Server".equals(source) || "Adaptive Server Enterprise"
/* 455 */       .equals(source) || "ASE"
/* 456 */       .equals(source) || "sql server"
/* 457 */       .equalsIgnoreCase(source)) {
/* 458 */       name = "Sybase";
/*     */     } 
/* 460 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNumeric(int sqlType) {
/* 469 */     return (-7 == sqlType || -5 == sqlType || 3 == sqlType || 8 == sqlType || 6 == sqlType || 4 == sqlType || 2 == sqlType || 7 == sqlType || 5 == sqlType || -6 == sqlType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static String resolveTypeName(int sqlType) {
/* 484 */     return typeNames.get(Integer.valueOf(sqlType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String lookupColumnName(ResultSetMetaData resultSetMetaData, int columnIndex) throws SQLException {
/* 500 */     String name = resultSetMetaData.getColumnLabel(columnIndex);
/* 501 */     if (!StringUtils.hasLength(name)) {
/* 502 */       name = resultSetMetaData.getColumnName(columnIndex);
/*     */     }
/* 504 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String convertPropertyNameToUnderscoreName(@Nullable String name) {
/* 516 */     if (!StringUtils.hasLength(name)) {
/* 517 */       return "";
/*     */     }
/*     */     
/* 520 */     StringBuilder result = new StringBuilder();
/* 521 */     result.append(Character.toLowerCase(name.charAt(0)));
/* 522 */     for (int i = 1; i < name.length(); i++) {
/* 523 */       char c = name.charAt(i);
/* 524 */       if (Character.isUpperCase(c)) {
/* 525 */         result.append('_').append(Character.toLowerCase(c));
/*     */       } else {
/*     */         
/* 528 */         result.append(c);
/*     */       } 
/*     */     } 
/* 531 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String convertUnderscoreNameToPropertyName(@Nullable String name) {
/* 542 */     if (!StringUtils.hasLength(name)) {
/* 543 */       return "";
/*     */     }
/*     */     
/* 546 */     StringBuilder result = new StringBuilder();
/* 547 */     boolean nextIsUpper = false;
/* 548 */     if (name.length() > 1 && name.charAt(1) == '_') {
/* 549 */       result.append(Character.toUpperCase(name.charAt(0)));
/*     */     } else {
/*     */       
/* 552 */       result.append(Character.toLowerCase(name.charAt(0)));
/*     */     } 
/* 554 */     for (int i = 1; i < name.length(); i++) {
/* 555 */       char c = name.charAt(i);
/* 556 */       if (c == '_') {
/* 557 */         nextIsUpper = true;
/*     */       
/*     */       }
/* 560 */       else if (nextIsUpper) {
/* 561 */         result.append(Character.toUpperCase(c));
/* 562 */         nextIsUpper = false;
/*     */       } else {
/*     */         
/* 565 */         result.append(Character.toLowerCase(c));
/*     */       } 
/*     */     } 
/*     */     
/* 569 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\JdbcUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */