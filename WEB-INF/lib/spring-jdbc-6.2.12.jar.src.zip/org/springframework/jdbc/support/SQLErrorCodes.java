/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLErrorCodes
/*     */ {
/*     */   @Nullable
/*     */   private String[] databaseProductNames;
/*     */   private boolean useSqlStateForTranslation = false;
/*  43 */   private String[] badSqlGrammarCodes = new String[0];
/*     */   
/*  45 */   private String[] invalidResultSetAccessCodes = new String[0];
/*     */   
/*  47 */   private String[] duplicateKeyCodes = new String[0];
/*     */   
/*  49 */   private String[] dataIntegrityViolationCodes = new String[0];
/*     */   
/*  51 */   private String[] permissionDeniedCodes = new String[0];
/*     */   
/*  53 */   private String[] dataAccessResourceFailureCodes = new String[0];
/*     */   
/*  55 */   private String[] transientDataAccessResourceCodes = new String[0];
/*     */   
/*  57 */   private String[] cannotAcquireLockCodes = new String[0];
/*     */   
/*  59 */   private String[] deadlockLoserCodes = new String[0];
/*     */   
/*  61 */   private String[] cannotSerializeTransactionCodes = new String[0];
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private CustomSQLErrorCodesTranslation[] customTranslations;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private SQLExceptionTranslator customSqlExceptionTranslator;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabaseProductName(@Nullable String databaseProductName) {
/*  75 */     this.databaseProductNames = new String[] { databaseProductName };
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getDatabaseProductName() {
/*  80 */     return (this.databaseProductNames != null && this.databaseProductNames.length > 0) ? 
/*  81 */       this.databaseProductNames[0] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabaseProductNames(@Nullable String... databaseProductNames) {
/*  89 */     this.databaseProductNames = databaseProductNames;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String[] getDatabaseProductNames() {
/*  94 */     return this.databaseProductNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseSqlStateForTranslation(boolean useStateCodeForTranslation) {
/* 102 */     this.useSqlStateForTranslation = useStateCodeForTranslation;
/*     */   }
/*     */   
/*     */   public boolean isUseSqlStateForTranslation() {
/* 106 */     return this.useSqlStateForTranslation;
/*     */   }
/*     */   
/*     */   public void setBadSqlGrammarCodes(String... badSqlGrammarCodes) {
/* 110 */     this.badSqlGrammarCodes = StringUtils.sortStringArray(badSqlGrammarCodes);
/*     */   }
/*     */   
/*     */   public String[] getBadSqlGrammarCodes() {
/* 114 */     return this.badSqlGrammarCodes;
/*     */   }
/*     */   
/*     */   public void setInvalidResultSetAccessCodes(String... invalidResultSetAccessCodes) {
/* 118 */     this.invalidResultSetAccessCodes = StringUtils.sortStringArray(invalidResultSetAccessCodes);
/*     */   }
/*     */   
/*     */   public String[] getInvalidResultSetAccessCodes() {
/* 122 */     return this.invalidResultSetAccessCodes;
/*     */   }
/*     */   
/*     */   public String[] getDuplicateKeyCodes() {
/* 126 */     return this.duplicateKeyCodes;
/*     */   }
/*     */   
/*     */   public void setDuplicateKeyCodes(String... duplicateKeyCodes) {
/* 130 */     this.duplicateKeyCodes = duplicateKeyCodes;
/*     */   }
/*     */   
/*     */   public void setDataIntegrityViolationCodes(String... dataIntegrityViolationCodes) {
/* 134 */     this.dataIntegrityViolationCodes = StringUtils.sortStringArray(dataIntegrityViolationCodes);
/*     */   }
/*     */   
/*     */   public String[] getDataIntegrityViolationCodes() {
/* 138 */     return this.dataIntegrityViolationCodes;
/*     */   }
/*     */   
/*     */   public void setPermissionDeniedCodes(String... permissionDeniedCodes) {
/* 142 */     this.permissionDeniedCodes = StringUtils.sortStringArray(permissionDeniedCodes);
/*     */   }
/*     */   
/*     */   public String[] getPermissionDeniedCodes() {
/* 146 */     return this.permissionDeniedCodes;
/*     */   }
/*     */   
/*     */   public void setDataAccessResourceFailureCodes(String... dataAccessResourceFailureCodes) {
/* 150 */     this.dataAccessResourceFailureCodes = StringUtils.sortStringArray(dataAccessResourceFailureCodes);
/*     */   }
/*     */   
/*     */   public String[] getDataAccessResourceFailureCodes() {
/* 154 */     return this.dataAccessResourceFailureCodes;
/*     */   }
/*     */   
/*     */   public void setTransientDataAccessResourceCodes(String... transientDataAccessResourceCodes) {
/* 158 */     this.transientDataAccessResourceCodes = StringUtils.sortStringArray(transientDataAccessResourceCodes);
/*     */   }
/*     */   
/*     */   public String[] getTransientDataAccessResourceCodes() {
/* 162 */     return this.transientDataAccessResourceCodes;
/*     */   }
/*     */   
/*     */   public void setCannotAcquireLockCodes(String... cannotAcquireLockCodes) {
/* 166 */     this.cannotAcquireLockCodes = StringUtils.sortStringArray(cannotAcquireLockCodes);
/*     */   }
/*     */   
/*     */   public String[] getCannotAcquireLockCodes() {
/* 170 */     return this.cannotAcquireLockCodes;
/*     */   }
/*     */   
/*     */   public void setDeadlockLoserCodes(String... deadlockLoserCodes) {
/* 174 */     this.deadlockLoserCodes = StringUtils.sortStringArray(deadlockLoserCodes);
/*     */   }
/*     */   
/*     */   public String[] getDeadlockLoserCodes() {
/* 178 */     return this.deadlockLoserCodes;
/*     */   }
/*     */   
/*     */   public void setCannotSerializeTransactionCodes(String... cannotSerializeTransactionCodes) {
/* 182 */     this.cannotSerializeTransactionCodes = StringUtils.sortStringArray(cannotSerializeTransactionCodes);
/*     */   }
/*     */   
/*     */   public String[] getCannotSerializeTransactionCodes() {
/* 186 */     return this.cannotSerializeTransactionCodes;
/*     */   }
/*     */   
/*     */   public void setCustomTranslations(CustomSQLErrorCodesTranslation... customTranslations) {
/* 190 */     this.customTranslations = customTranslations;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public CustomSQLErrorCodesTranslation[] getCustomTranslations() {
/* 195 */     return this.customTranslations;
/*     */   }
/*     */   
/*     */   public void setCustomSqlExceptionTranslatorClass(@Nullable Class<? extends SQLExceptionTranslator> customTranslatorClass) {
/* 199 */     if (customTranslatorClass != null) {
/*     */       try {
/* 201 */         this
/* 202 */           .customSqlExceptionTranslator = ReflectionUtils.accessibleConstructor(customTranslatorClass, new Class[0]).newInstance(new Object[0]);
/*     */       }
/* 204 */       catch (Throwable ex) {
/* 205 */         throw new IllegalStateException("Unable to instantiate custom translator", ex);
/*     */       } 
/*     */     } else {
/*     */       
/* 209 */       this.customSqlExceptionTranslator = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setCustomSqlExceptionTranslator(@Nullable SQLExceptionTranslator customSqlExceptionTranslator) {
/* 214 */     this.customSqlExceptionTranslator = customSqlExceptionTranslator;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public SQLExceptionTranslator getCustomSqlExceptionTranslator() {
/* 219 */     return this.customSqlExceptionTranslator;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\SQLErrorCodes.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */