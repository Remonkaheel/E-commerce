/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.dao.DataRetrievalFailureException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeneratedKeyHolder
/*     */   implements KeyHolder
/*     */ {
/*     */   private final List<Map<String, Object>> keyList;
/*     */   
/*     */   public GeneratedKeyHolder() {
/*  50 */     this.keyList = new ArrayList<>(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedKeyHolder(List<Map<String, Object>> keyList) {
/*  58 */     this.keyList = keyList;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Number getKey() throws InvalidDataAccessApiUsageException, DataRetrievalFailureException {
/*  65 */     return getKeyAs(Number.class);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getKeyAs(Class<T> keyType) throws InvalidDataAccessApiUsageException, DataRetrievalFailureException {
/*  71 */     if (this.keyList.isEmpty()) {
/*  72 */       return null;
/*     */     }
/*  74 */     if (this.keyList.size() > 1 || ((Map)this.keyList.get(0)).size() > 1) {
/*  75 */       throw new InvalidDataAccessApiUsageException("The getKey method should only be used when a single key is returned. The current key entry contains multiple keys: " + String.valueOf(this.keyList));
/*     */     }
/*     */ 
/*     */     
/*  79 */     Iterator<Object> keyIter = ((Map)this.keyList.get(0)).values().iterator();
/*  80 */     if (keyIter.hasNext()) {
/*  81 */       Object key = keyIter.next();
/*  82 */       if (key == null || !keyType.isAssignableFrom(key.getClass())) {
/*  83 */         throw new DataRetrievalFailureException("The generated key type is not supported. Unable to cast [" + (
/*     */             
/*  85 */             (key != null) ? key.getClass().getName() : null) + "] to [" + keyType
/*  86 */             .getName() + "].");
/*     */       }
/*  88 */       return keyType.cast(key);
/*     */     } 
/*     */     
/*  91 */     throw new DataRetrievalFailureException("Unable to retrieve the generated key. Check that the table has an identity column enabled.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Map<String, Object> getKeys() throws InvalidDataAccessApiUsageException {
/*  99 */     if (this.keyList.isEmpty()) {
/* 100 */       return null;
/*     */     }
/* 102 */     if (this.keyList.size() > 1) {
/* 103 */       throw new InvalidDataAccessApiUsageException("The getKeys method should only be used when keys for a single row are returned. The current key list contains keys for multiple rows: " + String.valueOf(this.keyList));
/*     */     }
/*     */ 
/*     */     
/* 107 */     return this.keyList.get(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Map<String, Object>> getKeyList() {
/* 112 */     return this.keyList;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\GeneratedKeyHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */