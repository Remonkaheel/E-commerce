package org.springframework.jdbc.support.xml;

import org.springframework.jdbc.support.SqlValue;

@Deprecated(since = "6.2")
public interface SqlXmlValue extends SqlValue {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\xml\SqlXmlValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */