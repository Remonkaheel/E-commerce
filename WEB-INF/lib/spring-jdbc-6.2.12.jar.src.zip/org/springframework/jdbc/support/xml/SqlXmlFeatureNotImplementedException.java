/*    */ package org.springframework.jdbc.support.xml;
/*    */ 
/*    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.2")
/*    */ public class SqlXmlFeatureNotImplementedException
/*    */   extends InvalidDataAccessApiUsageException
/*    */ {
/*    */   public SqlXmlFeatureNotImplementedException(String msg) {
/* 43 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SqlXmlFeatureNotImplementedException(String msg, Throwable cause) {
/* 52 */     super(msg, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\xml\SqlXmlFeatureNotImplementedException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */