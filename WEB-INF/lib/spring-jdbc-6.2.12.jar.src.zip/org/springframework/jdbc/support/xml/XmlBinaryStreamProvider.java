package org.springframework.jdbc.support.xml;

import java.io.IOException;
import java.io.OutputStream;

@Deprecated(since = "6.2")
public interface XmlBinaryStreamProvider {
  void provideXml(OutputStream paramOutputStream) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\xml\XmlBinaryStreamProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */