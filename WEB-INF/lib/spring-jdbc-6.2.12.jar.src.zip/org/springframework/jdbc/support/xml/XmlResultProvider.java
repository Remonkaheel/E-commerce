package org.springframework.jdbc.support.xml;

import javax.xml.transform.Result;

@Deprecated(since = "6.2")
public interface XmlResultProvider {
  void provideXml(Result paramResult);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\xml\XmlResultProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */