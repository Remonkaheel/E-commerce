package org.springframework.jdbc.support.xml;

import java.io.InputStream;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import org.springframework.lang.Nullable;
import org.w3c.dom.Document;

@Deprecated(since = "6.2")
public interface SqlXmlHandler {
  @Nullable
  String getXmlAsString(ResultSet paramResultSet, String paramString) throws SQLException;
  
  @Nullable
  String getXmlAsString(ResultSet paramResultSet, int paramInt) throws SQLException;
  
  @Nullable
  InputStream getXmlAsBinaryStream(ResultSet paramResultSet, String paramString) throws SQLException;
  
  @Nullable
  InputStream getXmlAsBinaryStream(ResultSet paramResultSet, int paramInt) throws SQLException;
  
  @Nullable
  Reader getXmlAsCharacterStream(ResultSet paramResultSet, String paramString) throws SQLException;
  
  @Nullable
  Reader getXmlAsCharacterStream(ResultSet paramResultSet, int paramInt) throws SQLException;
  
  @Nullable
  Source getXmlAsSource(ResultSet paramResultSet, String paramString, @Nullable Class<? extends Source> paramClass) throws SQLException;
  
  @Nullable
  Source getXmlAsSource(ResultSet paramResultSet, int paramInt, @Nullable Class<? extends Source> paramClass) throws SQLException;
  
  SqlXmlValue newSqlXmlValue(String paramString);
  
  SqlXmlValue newSqlXmlValue(XmlBinaryStreamProvider paramXmlBinaryStreamProvider);
  
  SqlXmlValue newSqlXmlValue(XmlCharacterStreamProvider paramXmlCharacterStreamProvider);
  
  SqlXmlValue newSqlXmlValue(Class<? extends Result> paramClass, XmlResultProvider paramXmlResultProvider);
  
  SqlXmlValue newSqlXmlValue(Document paramDocument);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\xml\SqlXmlHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */