/*     */ package org.springframework.jdbc.support.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(since = "6.2")
/*     */ public class Jdbc4SqlXmlHandler
/*     */   implements SqlXmlHandler
/*     */ {
/*     */   @Nullable
/*     */   public String getXmlAsString(ResultSet rs, String columnName) throws SQLException {
/*  64 */     SQLXML xmlObject = rs.getSQLXML(columnName);
/*  65 */     return (xmlObject != null) ? xmlObject.getString() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getXmlAsString(ResultSet rs, int columnIndex) throws SQLException {
/*  71 */     SQLXML xmlObject = rs.getSQLXML(columnIndex);
/*  72 */     return (xmlObject != null) ? xmlObject.getString() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InputStream getXmlAsBinaryStream(ResultSet rs, String columnName) throws SQLException {
/*  78 */     SQLXML xmlObject = rs.getSQLXML(columnName);
/*  79 */     return (xmlObject != null) ? xmlObject.getBinaryStream() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InputStream getXmlAsBinaryStream(ResultSet rs, int columnIndex) throws SQLException {
/*  85 */     SQLXML xmlObject = rs.getSQLXML(columnIndex);
/*  86 */     return (xmlObject != null) ? xmlObject.getBinaryStream() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Reader getXmlAsCharacterStream(ResultSet rs, String columnName) throws SQLException {
/*  92 */     SQLXML xmlObject = rs.getSQLXML(columnName);
/*  93 */     return (xmlObject != null) ? xmlObject.getCharacterStream() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Reader getXmlAsCharacterStream(ResultSet rs, int columnIndex) throws SQLException {
/*  99 */     SQLXML xmlObject = rs.getSQLXML(columnIndex);
/* 100 */     return (xmlObject != null) ? xmlObject.getCharacterStream() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Source getXmlAsSource(ResultSet rs, String columnName, @Nullable Class<? extends Source> sourceClass) throws SQLException {
/* 108 */     SQLXML xmlObject = rs.getSQLXML(columnName);
/* 109 */     if (xmlObject == null) {
/* 110 */       return null;
/*     */     }
/* 112 */     return (sourceClass != null) ? xmlObject.<Source>getSource((Class)sourceClass) : xmlObject.<Source>getSource((Class)DOMSource.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Source getXmlAsSource(ResultSet rs, int columnIndex, @Nullable Class<? extends Source> sourceClass) throws SQLException {
/* 120 */     SQLXML xmlObject = rs.getSQLXML(columnIndex);
/* 121 */     if (xmlObject == null) {
/* 122 */       return null;
/*     */     }
/* 124 */     return (sourceClass != null) ? xmlObject.<Source>getSource((Class)sourceClass) : xmlObject.<Source>getSource((Class)DOMSource.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlXmlValue newSqlXmlValue(final String value) {
/* 134 */     return new AbstractJdbc4SqlXmlValue()
/*     */       {
/*     */         protected void provideXml(SQLXML xmlObject) throws SQLException, IOException {
/* 137 */           xmlObject.setString(value);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public SqlXmlValue newSqlXmlValue(final XmlBinaryStreamProvider provider) {
/* 144 */     return new AbstractJdbc4SqlXmlValue()
/*     */       {
/*     */         protected void provideXml(SQLXML xmlObject) throws SQLException, IOException {
/* 147 */           provider.provideXml(xmlObject.setBinaryStream());
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public SqlXmlValue newSqlXmlValue(final XmlCharacterStreamProvider provider) {
/* 154 */     return new AbstractJdbc4SqlXmlValue()
/*     */       {
/*     */         protected void provideXml(SQLXML xmlObject) throws SQLException, IOException {
/* 157 */           provider.provideXml(xmlObject.setCharacterStream());
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public SqlXmlValue newSqlXmlValue(final Class<? extends Result> resultClass, final XmlResultProvider provider) {
/* 164 */     return new AbstractJdbc4SqlXmlValue()
/*     */       {
/*     */         protected void provideXml(SQLXML xmlObject) throws SQLException, IOException {
/* 167 */           provider.provideXml(xmlObject.setResult(resultClass));
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public SqlXmlValue newSqlXmlValue(final Document document) {
/* 174 */     return new AbstractJdbc4SqlXmlValue()
/*     */       {
/*     */         protected void provideXml(SQLXML xmlObject) throws SQLException, IOException {
/* 177 */           ((DOMResult)xmlObject.<DOMResult>setResult(DOMResult.class)).setNode(document);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static abstract class AbstractJdbc4SqlXmlValue
/*     */     implements SqlXmlValue
/*     */   {
/*     */     @Nullable
/*     */     private SQLXML xmlObject;
/*     */ 
/*     */ 
/*     */     
/*     */     public void setValue(PreparedStatement ps, int paramIndex) throws SQLException {
/* 193 */       this.xmlObject = ps.getConnection().createSQLXML();
/*     */       try {
/* 195 */         provideXml(this.xmlObject);
/*     */       }
/* 197 */       catch (IOException ex) {
/* 198 */         throw new DataAccessResourceFailureException("Failure encountered while providing XML", ex);
/*     */       } 
/* 200 */       ps.setSQLXML(paramIndex, this.xmlObject);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cleanup() {
/* 205 */       if (this.xmlObject != null)
/*     */         try {
/* 207 */           this.xmlObject.free();
/*     */         }
/* 209 */         catch (SQLException ex) {
/* 210 */           throw new DataAccessResourceFailureException("Could not free SQLXML object", ex);
/*     */         }  
/*     */     }
/*     */     
/*     */     protected abstract void provideXml(SQLXML param1SQLXML) throws SQLException, IOException;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\xml\Jdbc4SqlXmlHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */