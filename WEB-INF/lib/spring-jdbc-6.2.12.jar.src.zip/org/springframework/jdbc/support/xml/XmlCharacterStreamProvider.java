package org.springframework.jdbc.support.xml;

import java.io.IOException;
import java.io.Writer;

@Deprecated(since = "6.2")
public interface XmlCharacterStreamProvider {
  void provideXml(Writer paramWriter) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\xml\XmlCharacterStreamProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */