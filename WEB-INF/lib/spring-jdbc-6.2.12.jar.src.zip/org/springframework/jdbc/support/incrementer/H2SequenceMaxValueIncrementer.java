/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class H2SequenceMaxValueIncrementer
/*    */   extends AbstractSequenceMaxValueIncrementer
/*    */ {
/*    */   public H2SequenceMaxValueIncrementer() {}
/*    */   
/*    */   public H2SequenceMaxValueIncrementer(DataSource dataSource, String incrementerName) {
/* 45 */     super(dataSource, incrementerName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getSequenceQuery() {
/* 51 */     return "values next value for " + getIncrementerName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\H2SequenceMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */