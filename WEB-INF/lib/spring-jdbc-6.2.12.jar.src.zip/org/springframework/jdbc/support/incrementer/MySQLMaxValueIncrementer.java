/*     */ package org.springframework.jdbc.support.incrementer;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MySQLMaxValueIncrementer
/*     */   extends AbstractColumnMaxValueIncrementer
/*     */ {
/*     */   private static final String VALUE_SQL = "select last_insert_id()";
/*  71 */   private long nextId = 0L;
/*     */ 
/*     */   
/*  74 */   private long maxId = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean useNewConnection = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MySQLMaxValueIncrementer() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MySQLMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName) {
/*  96 */     super(dataSource, incrementerName, columnName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseNewConnection(boolean useNewConnection) {
/* 112 */     this.useNewConnection = useNewConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized long getNextKey() throws DataAccessException {
/* 118 */     if (this.maxId == this.nextId) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 127 */       Connection con = null;
/* 128 */       Statement stmt = null;
/* 129 */       boolean mustRestoreAutoCommit = false;
/*     */       try {
/* 131 */         if (this.useNewConnection) {
/* 132 */           con = getDataSource().getConnection();
/* 133 */           if (con.getAutoCommit()) {
/* 134 */             mustRestoreAutoCommit = true;
/* 135 */             con.setAutoCommit(false);
/*     */           } 
/*     */         } else {
/*     */           
/* 139 */           con = DataSourceUtils.getConnection(getDataSource());
/*     */         } 
/* 141 */         stmt = con.createStatement();
/* 142 */         if (!this.useNewConnection) {
/* 143 */           DataSourceUtils.applyTransactionTimeout(stmt, getDataSource());
/*     */         }
/*     */         
/* 146 */         String columnName = getColumnName();
/*     */         try {
/* 148 */           stmt.executeUpdate("update " + getIncrementerName() + " set " + columnName + " = last_insert_id(" + columnName + " + " + 
/* 149 */               getCacheSize() + ") limit 1");
/*     */         }
/* 151 */         catch (SQLException ex) {
/* 152 */           throw new DataAccessResourceFailureException("Could not increment " + columnName + " for " + 
/* 153 */               getIncrementerName() + " sequence table", ex);
/*     */         } 
/*     */         
/* 156 */         ResultSet rs = stmt.executeQuery("select last_insert_id()");
/*     */         try {
/* 158 */           if (!rs.next()) {
/* 159 */             throw new DataAccessResourceFailureException("last_insert_id() failed after executing an update");
/*     */           }
/* 161 */           this.maxId = rs.getLong(1);
/*     */         } finally {
/*     */           
/* 164 */           JdbcUtils.closeResultSet(rs);
/*     */         } 
/* 166 */         this.nextId = this.maxId - getCacheSize() + 1L;
/*     */       }
/* 168 */       catch (SQLException ex) {
/* 169 */         throw new DataAccessResourceFailureException("Could not obtain last_insert_id()", ex);
/*     */       } finally {
/*     */         
/* 172 */         JdbcUtils.closeStatement(stmt);
/* 173 */         if (con != null) {
/* 174 */           if (this.useNewConnection) {
/*     */             try {
/* 176 */               con.commit();
/* 177 */               if (mustRestoreAutoCommit) {
/* 178 */                 con.setAutoCommit(true);
/*     */               }
/*     */             }
/* 181 */             catch (SQLException ignore) {
/* 182 */               throw new DataAccessResourceFailureException("Unable to commit new sequence value changes for " + 
/* 183 */                   getIncrementerName());
/*     */             } 
/* 185 */             JdbcUtils.closeConnection(con);
/*     */           } else {
/*     */             
/* 188 */             DataSourceUtils.releaseConnection(con, getDataSource());
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/* 194 */       this.nextId++;
/*     */     } 
/* 196 */     return this.nextId;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\MySQLMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */