/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SybaseAnywhereMaxValueIncrementer
/*    */   extends SybaseMaxValueIncrementer
/*    */ {
/*    */   public SybaseAnywhereMaxValueIncrementer() {}
/*    */   
/*    */   public SybaseAnywhereMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName) {
/* 72 */     super(dataSource, incrementerName, columnName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getIncrementStatement() {
/* 78 */     return "insert into " + getIncrementerName() + " values(DEFAULT)";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\SybaseAnywhereMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */