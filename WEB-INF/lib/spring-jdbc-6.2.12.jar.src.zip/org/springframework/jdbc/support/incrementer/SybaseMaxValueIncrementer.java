/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SybaseMaxValueIncrementer
/*    */   extends AbstractIdentityColumnMaxValueIncrementer
/*    */ {
/*    */   public SybaseMaxValueIncrementer() {}
/*    */   
/*    */   public SybaseMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName) {
/* 73 */     super(dataSource, incrementerName, columnName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getIncrementStatement() {
/* 79 */     return "insert into " + getIncrementerName() + " values()";
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getIdentityStatement() {
/* 84 */     return "select @@identity";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\SybaseMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */