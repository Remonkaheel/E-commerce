/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OracleSequenceMaxValueIncrementer
/*    */   extends AbstractSequenceMaxValueIncrementer
/*    */ {
/*    */   public OracleSequenceMaxValueIncrementer() {}
/*    */   
/*    */   public OracleSequenceMaxValueIncrementer(DataSource dataSource, String incrementerName) {
/* 45 */     super(dataSource, incrementerName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getSequenceQuery() {
/* 51 */     return "select " + getIncrementerName() + ".nextval from dual";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\OracleSequenceMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */