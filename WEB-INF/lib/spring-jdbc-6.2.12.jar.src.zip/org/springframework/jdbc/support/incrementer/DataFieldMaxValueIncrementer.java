package org.springframework.jdbc.support.incrementer;

import org.springframework.dao.DataAccessException;

public interface DataFieldMaxValueIncrementer {
  int nextIntValue() throws DataAccessException;
  
  long nextLongValue() throws DataAccessException;
  
  String nextStringValue() throws DataAccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\DataFieldMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */