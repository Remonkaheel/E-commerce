/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MariaDBSequenceMaxValueIncrementer
/*    */   extends AbstractSequenceMaxValueIncrementer
/*    */ {
/*    */   public MariaDBSequenceMaxValueIncrementer() {}
/*    */   
/*    */   public MariaDBSequenceMaxValueIncrementer(DataSource dataSource, String incrementerName) {
/* 44 */     super(dataSource, incrementerName);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getSequenceQuery() {
/* 49 */     return "select next value for " + getIncrementerName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\MariaDBSequenceMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */