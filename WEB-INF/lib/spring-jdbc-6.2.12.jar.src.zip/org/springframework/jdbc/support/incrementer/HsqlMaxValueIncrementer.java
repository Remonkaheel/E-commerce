/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HsqlMaxValueIncrementer
/*    */   extends AbstractIdentityColumnMaxValueIncrementer
/*    */ {
/*    */   public HsqlMaxValueIncrementer() {}
/*    */   
/*    */   public HsqlMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName) {
/* 66 */     super(dataSource, incrementerName, columnName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getIncrementStatement() {
/* 72 */     return "insert into " + getIncrementerName() + " values(null)";
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getIdentityStatement() {
/* 77 */     return "select max(identity()) from " + getIncrementerName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\HsqlMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */