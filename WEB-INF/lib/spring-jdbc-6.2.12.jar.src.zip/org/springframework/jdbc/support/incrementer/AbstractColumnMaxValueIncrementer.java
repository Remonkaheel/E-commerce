/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractColumnMaxValueIncrementer
/*    */   extends AbstractDataFieldMaxValueIncrementer
/*    */ {
/*    */   private String columnName;
/* 37 */   private int cacheSize = 1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AbstractColumnMaxValueIncrementer() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AbstractColumnMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName) {
/* 57 */     super(dataSource, incrementerName);
/* 58 */     Assert.notNull(columnName, "Column name must not be null");
/* 59 */     this.columnName = columnName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setColumnName(String columnName) {
/* 67 */     this.columnName = columnName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getColumnName() {
/* 74 */     return this.columnName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCacheSize(int cacheSize) {
/* 81 */     this.cacheSize = cacheSize;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getCacheSize() {
/* 88 */     return this.cacheSize;
/*    */   }
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() {
/* 93 */     super.afterPropertiesSet();
/* 94 */     if (this.columnName == null)
/* 95 */       throw new IllegalArgumentException("Property 'columnName' is required"); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\AbstractColumnMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */