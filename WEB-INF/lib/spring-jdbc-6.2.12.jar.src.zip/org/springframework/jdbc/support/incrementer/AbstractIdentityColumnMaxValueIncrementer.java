/*     */ package org.springframework.jdbc.support.incrementer;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractIdentityColumnMaxValueIncrementer
/*     */   extends AbstractColumnMaxValueIncrementer
/*     */ {
/*     */   private boolean deleteSpecificValues = false;
/*     */   private long[] valueCache;
/*  47 */   private int nextValueIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractIdentityColumnMaxValueIncrementer() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractIdentityColumnMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName) {
/*  62 */     super(dataSource, incrementerName, columnName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeleteSpecificValues(boolean deleteSpecificValues) {
/*  73 */     this.deleteSpecificValues = deleteSpecificValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeleteSpecificValues() {
/*  81 */     return this.deleteSpecificValues;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized long getNextKey() throws DataAccessException {
/*  87 */     if (this.nextValueIndex < 0 || this.nextValueIndex >= getCacheSize()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  93 */       Connection con = DataSourceUtils.getConnection(getDataSource());
/*  94 */       Statement stmt = null;
/*     */       try {
/*  96 */         stmt = con.createStatement();
/*  97 */         DataSourceUtils.applyTransactionTimeout(stmt, getDataSource());
/*  98 */         this.valueCache = new long[getCacheSize()];
/*  99 */         this.nextValueIndex = 0;
/* 100 */         for (int i = 0; i < getCacheSize(); i++) {
/* 101 */           stmt.executeUpdate(getIncrementStatement());
/* 102 */           ResultSet rs = stmt.executeQuery(getIdentityStatement());
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 113 */         stmt.executeUpdate(getDeleteStatement(this.valueCache));
/*     */       }
/* 115 */       catch (SQLException ex) {
/* 116 */         throw new DataAccessResourceFailureException("Could not increment identity", ex);
/*     */       } finally {
/*     */         
/* 119 */         JdbcUtils.closeStatement(stmt);
/* 120 */         DataSourceUtils.releaseConnection(con, getDataSource());
/*     */       } 
/*     */     } 
/* 123 */     return this.valueCache[this.nextValueIndex++];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getIncrementStatement();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getIdentityStatement();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDeleteStatement(long[] values) {
/* 150 */     StringBuilder sb = new StringBuilder(64);
/* 151 */     sb.append("delete from ").append(getIncrementerName()).append(" where ").append(getColumnName());
/* 152 */     if (isDeleteSpecificValues()) {
/* 153 */       sb.append(" in (").append(values[0] - 1L);
/* 154 */       for (int i = 0; i < values.length - 1; i++) {
/* 155 */         sb.append(", ").append(values[i]);
/*     */       }
/* 157 */       sb.append(')');
/*     */     } else {
/*     */       
/* 160 */       long maxValue = values[values.length - 1];
/* 161 */       sb.append(" < ").append(maxValue);
/*     */     } 
/* 163 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\AbstractIdentityColumnMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */