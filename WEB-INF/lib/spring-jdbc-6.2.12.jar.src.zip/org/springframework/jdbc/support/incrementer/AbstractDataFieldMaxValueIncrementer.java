/*     */ package org.springframework.jdbc.support.incrementer;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDataFieldMaxValueIncrementer
/*     */   implements DataFieldMaxValueIncrementer, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private DataSource dataSource;
/*     */   @Nullable
/*     */   private String incrementerName;
/*  46 */   protected int paddingLength = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractDataFieldMaxValueIncrementer() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractDataFieldMaxValueIncrementer(DataSource dataSource, String incrementerName) {
/*  63 */     Assert.notNull(dataSource, "DataSource must not be null");
/*  64 */     Assert.notNull(incrementerName, "Incrementer name must not be null");
/*  65 */     this.dataSource = dataSource;
/*  66 */     this.incrementerName = incrementerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(DataSource dataSource) {
/*  74 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSource getDataSource() {
/*  82 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncrementerName(String incrementerName) {
/*  89 */     this.incrementerName = incrementerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIncrementerName() {
/*  97 */     return this.incrementerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPaddingLength(int paddingLength) {
/* 105 */     this.paddingLength = paddingLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPaddingLength() {
/* 112 */     return this.paddingLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 117 */     if (this.dataSource == null) {
/* 118 */       throw new IllegalArgumentException("Property 'dataSource' is required");
/*     */     }
/* 120 */     if (this.incrementerName == null) {
/* 121 */       throw new IllegalArgumentException("Property 'incrementerName' is required");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int nextIntValue() throws DataAccessException {
/* 128 */     return (int)getNextKey();
/*     */   }
/*     */ 
/*     */   
/*     */   public long nextLongValue() throws DataAccessException {
/* 133 */     return getNextKey();
/*     */   }
/*     */ 
/*     */   
/*     */   public String nextStringValue() throws DataAccessException {
/* 138 */     String s = Long.toString(getNextKey());
/* 139 */     int len = s.length();
/* 140 */     if (len < this.paddingLength) {
/* 141 */       s = "0".repeat(this.paddingLength - len) + "0".repeat(this.paddingLength - len);
/*     */     }
/* 143 */     return s;
/*     */   }
/*     */   
/*     */   protected abstract long getNextKey();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\AbstractDataFieldMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */