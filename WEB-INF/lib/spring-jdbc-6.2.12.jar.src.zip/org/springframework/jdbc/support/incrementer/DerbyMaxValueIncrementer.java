/*     */ package org.springframework.jdbc.support.incrementer;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DerbyMaxValueIncrementer
/*     */   extends AbstractIdentityColumnMaxValueIncrementer
/*     */ {
/*     */   private static final String DEFAULT_DUMMY_NAME = "dummy";
/*  62 */   private String dummyName = "dummy";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DerbyMaxValueIncrementer() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DerbyMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName) {
/*  81 */     super(dataSource, incrementerName, columnName);
/*  82 */     this.dummyName = "dummy";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DerbyMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName, String dummyName) {
/*  93 */     super(dataSource, incrementerName, columnName);
/*  94 */     this.dummyName = dummyName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDummyName(String dummyName) {
/* 102 */     this.dummyName = dummyName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDummyName() {
/* 109 */     return this.dummyName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getIncrementStatement() {
/* 115 */     return "insert into " + getIncrementerName() + " (" + getDummyName() + ") values(null)";
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getIdentityStatement() {
/* 120 */     return "select IDENTITY_VAL_LOCAL() from " + getIncrementerName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\incrementer\DerbyMaxValueIncrementer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */