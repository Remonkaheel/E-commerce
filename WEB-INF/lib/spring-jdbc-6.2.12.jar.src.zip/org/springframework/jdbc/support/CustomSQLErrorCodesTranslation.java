/*    */ package org.springframework.jdbc.support;
/*    */ 
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CustomSQLErrorCodesTranslation
/*    */ {
/* 34 */   private String[] errorCodes = new String[0];
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private Class<?> exceptionClass;
/*    */ 
/*    */ 
/*    */   
/*    */   public void setErrorCodes(String... errorCodes) {
/* 44 */     this.errorCodes = StringUtils.sortStringArray(errorCodes);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getErrorCodes() {
/* 51 */     return this.errorCodes;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setExceptionClass(@Nullable Class<?> exceptionClass) {
/* 58 */     if (exceptionClass != null && !DataAccessException.class.isAssignableFrom(exceptionClass)) {
/* 59 */       throw new IllegalArgumentException("Invalid exception class [" + String.valueOf(exceptionClass) + "]: needs to be a subclass of [org.springframework.dao.DataAccessException]");
/*    */     }
/*    */     
/* 62 */     this.exceptionClass = exceptionClass;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Class<?> getExceptionClass() {
/* 70 */     return this.exceptionClass;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\support\CustomSQLErrorCodesTranslation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */