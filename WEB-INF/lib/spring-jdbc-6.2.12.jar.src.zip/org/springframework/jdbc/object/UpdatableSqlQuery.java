/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UpdatableSqlQuery<T>
/*     */   extends SqlQuery<T>
/*     */ {
/*     */   public UpdatableSqlQuery() {
/*  46 */     setUpdatableResults(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UpdatableSqlQuery(DataSource ds, String sql) {
/*  55 */     super(ds, sql);
/*  56 */     setUpdatableResults(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RowMapper<T> newRowMapper(@Nullable Object[] parameters, @Nullable Map<?, ?> context) {
/*  66 */     return new RowMapperImpl(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T updateRow(ResultSet paramResultSet, int paramInt, @Nullable Map<?, ?> paramMap) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class RowMapperImpl
/*     */     implements RowMapper<T>
/*     */   {
/*     */     @Nullable
/*     */     private final Map<?, ?> context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RowMapperImpl(Map<?, ?> context) {
/*  97 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     public T mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 102 */       T result = UpdatableSqlQuery.this.updateRow(rs, rowNum, this.context);
/* 103 */       rs.updateRow();
/* 104 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\object\UpdatableSqlQuery.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */