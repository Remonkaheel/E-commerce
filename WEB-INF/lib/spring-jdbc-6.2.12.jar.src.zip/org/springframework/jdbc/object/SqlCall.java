/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.CallableStatementCreator;
/*     */ import org.springframework.jdbc.core.CallableStatementCreatorFactory;
/*     */ import org.springframework.jdbc.core.ParameterMapper;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SqlCall
/*     */   extends RdbmsOperation
/*     */ {
/*     */   private boolean function = false;
/*     */   private boolean sqlReadyForUse = false;
/*     */   @Nullable
/*     */   private String callString;
/*     */   @Nullable
/*     */   private CallableStatementCreatorFactory callableStatementFactory;
/*     */   
/*     */   public SqlCall() {}
/*     */   
/*     */   public SqlCall(DataSource ds, String sql) {
/*  90 */     setDataSource(ds);
/*  91 */     setSql(sql);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFunction(boolean function) {
/*  99 */     this.function = function;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFunction() {
/* 106 */     return this.function;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlReadyForUse(boolean sqlReadyForUse) {
/* 113 */     this.sqlReadyForUse = sqlReadyForUse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSqlReadyForUse() {
/* 120 */     return this.sqlReadyForUse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void compileInternal() {
/* 131 */     if (isSqlReadyForUse()) {
/* 132 */       this.callString = resolveSql();
/*     */     } else {
/*     */       
/* 135 */       StringBuilder callString = new StringBuilder(32);
/* 136 */       List<SqlParameter> parameters = getDeclaredParameters();
/* 137 */       int parameterCount = 0;
/* 138 */       if (isFunction()) {
/* 139 */         callString.append("{? = call ").append(resolveSql()).append('(');
/* 140 */         parameterCount = -1;
/*     */       } else {
/*     */         
/* 143 */         callString.append("{call ").append(resolveSql()).append('(');
/*     */       } 
/* 145 */       for (SqlParameter parameter : parameters) {
/* 146 */         if (!parameter.isResultsParameter()) {
/* 147 */           if (parameterCount > 0) {
/* 148 */             callString.append(", ");
/*     */           }
/* 150 */           if (parameterCount >= 0) {
/* 151 */             callString.append('?');
/*     */           }
/* 153 */           parameterCount++;
/*     */         } 
/*     */       } 
/* 156 */       callString.append(")}");
/* 157 */       this.callString = callString.toString();
/*     */     } 
/* 159 */     if (this.logger.isDebugEnabled()) {
/* 160 */       this.logger.debug("Compiled stored procedure. Call string is [" + this.callString + "]");
/*     */     }
/*     */     
/* 163 */     this.callableStatementFactory = new CallableStatementCreatorFactory(this.callString, getDeclaredParameters());
/* 164 */     this.callableStatementFactory.setResultSetType(getResultSetType());
/* 165 */     this.callableStatementFactory.setUpdatableResults(isUpdatableResults());
/*     */     
/* 167 */     onCompileInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onCompileInternal() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getCallString() {
/* 182 */     return this.callString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CallableStatementCreator newCallableStatementCreator(@Nullable Map<String, ?> inParams) {
/* 191 */     Assert.state((this.callableStatementFactory != null), "No CallableStatementFactory available");
/* 192 */     return this.callableStatementFactory.newCallableStatementCreator(inParams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CallableStatementCreator newCallableStatementCreator(ParameterMapper inParamMapper) {
/* 201 */     Assert.state((this.callableStatementFactory != null), "No CallableStatementFactory available");
/* 202 */     return this.callableStatementFactory.newCallableStatementCreator(inParamMapper);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\object\SqlCall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */