/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreatorFactory;
/*     */ import org.springframework.jdbc.core.PreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterUtils;
/*     */ import org.springframework.jdbc.core.namedparam.ParsedSql;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SqlOperation
/*     */   extends RdbmsOperation
/*     */ {
/*     */   @Nullable
/*     */   private PreparedStatementCreatorFactory preparedStatementFactory;
/*     */   @Nullable
/*     */   private ParsedSql cachedSql;
/*  51 */   private final Object parsedSqlMonitor = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void compileInternal() {
/*  60 */     this.preparedStatementFactory = new PreparedStatementCreatorFactory(resolveSql(), getDeclaredParameters());
/*  61 */     this.preparedStatementFactory.setResultSetType(getResultSetType());
/*  62 */     this.preparedStatementFactory.setUpdatableResults(isUpdatableResults());
/*  63 */     this.preparedStatementFactory.setReturnGeneratedKeys(isReturnGeneratedKeys());
/*  64 */     if (getGeneratedKeysColumnNames() != null) {
/*  65 */       this.preparedStatementFactory.setGeneratedKeysColumnNames(getGeneratedKeysColumnNames());
/*     */     }
/*     */     
/*  68 */     onCompileInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onCompileInternal() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParsedSql getParsedSql() {
/*  84 */     synchronized (this.parsedSqlMonitor) {
/*  85 */       if (this.cachedSql == null) {
/*  86 */         this.cachedSql = NamedParameterUtils.parseSqlStatement(resolveSql());
/*     */       }
/*  88 */       return this.cachedSql;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PreparedStatementSetter newPreparedStatementSetter(@Nullable Object[] params) {
/*  99 */     Assert.state((this.preparedStatementFactory != null), "No PreparedStatementFactory available");
/* 100 */     return this.preparedStatementFactory.newPreparedStatementSetter(params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PreparedStatementCreator newPreparedStatementCreator(@Nullable Object[] params) {
/* 109 */     Assert.state((this.preparedStatementFactory != null), "No PreparedStatementFactory available");
/* 110 */     return this.preparedStatementFactory.newPreparedStatementCreator(params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PreparedStatementCreator newPreparedStatementCreator(String sqlToUse, @Nullable Object[] params) {
/* 121 */     Assert.state((this.preparedStatementFactory != null), "No PreparedStatementFactory available");
/* 122 */     return this.preparedStatementFactory.newPreparedStatementCreator(sqlToUse, params);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\object\SqlOperation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */