/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.ParameterMapper;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StoredProcedure
/*     */   extends SqlCall
/*     */ {
/*     */   protected StoredProcedure() {}
/*     */   
/*     */   protected StoredProcedure(DataSource ds, String name) {
/*  56 */     setDataSource(ds);
/*  57 */     setSql(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StoredProcedure(JdbcTemplate jdbcTemplate, String name) {
/*  66 */     setJdbcTemplate(jdbcTemplate);
/*  67 */     setSql(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean allowsUnusedParameters() {
/*  77 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void declareParameter(SqlParameter param) throws InvalidDataAccessApiUsageException {
/*  95 */     if (param.getName() == null) {
/*  96 */       throw new InvalidDataAccessApiUsageException("Parameters to stored procedures must have names as well as types");
/*     */     }
/*  98 */     super.declareParameter(param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> execute(Object... inParams) {
/* 113 */     Map<String, Object> paramsToUse = new HashMap<>();
/* 114 */     validateParameters(inParams);
/* 115 */     int i = 0;
/* 116 */     for (SqlParameter sqlParameter : getDeclaredParameters()) {
/* 117 */       if (sqlParameter.isInputValueProvided() && i < inParams.length) {
/* 118 */         paramsToUse.put(sqlParameter.getName(), inParams[i++]);
/*     */       }
/*     */     } 
/* 121 */     return getJdbcTemplate().call(newCallableStatementCreator(paramsToUse), getDeclaredParameters());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> execute(Map<String, ?> inParams) throws DataAccessException {
/* 139 */     validateParameters(inParams.values().toArray());
/* 140 */     return getJdbcTemplate().call(newCallableStatementCreator(inParams), getDeclaredParameters());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> execute(ParameterMapper inParamMapper) throws DataAccessException {
/* 160 */     checkCompiled();
/* 161 */     return getJdbcTemplate().call(newCallableStatementCreator(inParamMapper), getDeclaredParameters());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\object\StoredProcedure.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */