/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.JdbcUpdateAffectedIncorrectNumberOfRowsException;
/*     */ import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterUtils;
/*     */ import org.springframework.jdbc.core.namedparam.ParsedSql;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.support.KeyHolder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlUpdate
/*     */   extends SqlOperation
/*     */ {
/*  57 */   private int maxRowsAffected = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private int requiredRowsAffected = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlUpdate() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlUpdate(DataSource ds, String sql) {
/*  81 */     setDataSource(ds);
/*  82 */     setSql(sql);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlUpdate(DataSource ds, String sql, int[] types) {
/*  95 */     setDataSource(ds);
/*  96 */     setSql(sql);
/*  97 */     setTypes(types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlUpdate(DataSource ds, String sql, int[] types, int maxRowsAffected) {
/* 113 */     setDataSource(ds);
/* 114 */     setSql(sql);
/* 115 */     setTypes(types);
/* 116 */     this.maxRowsAffected = maxRowsAffected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxRowsAffected(int maxRowsAffected) {
/* 127 */     this.maxRowsAffected = maxRowsAffected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequiredRowsAffected(int requiredRowsAffected) {
/* 139 */     this.requiredRowsAffected = requiredRowsAffected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkRowsAffected(int rowsAffected) throws JdbcUpdateAffectedIncorrectNumberOfRowsException {
/* 152 */     if (this.maxRowsAffected > 0 && rowsAffected > this.maxRowsAffected) {
/* 153 */       throw new JdbcUpdateAffectedIncorrectNumberOfRowsException(resolveSql(), this.maxRowsAffected, rowsAffected);
/*     */     }
/* 155 */     if (this.requiredRowsAffected > 0 && rowsAffected != this.requiredRowsAffected) {
/* 156 */       throw new JdbcUpdateAffectedIncorrectNumberOfRowsException(resolveSql(), this.requiredRowsAffected, rowsAffected);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(Object... params) throws DataAccessException {
/* 168 */     validateParameters(params);
/* 169 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(params));
/* 170 */     checkRowsAffected(rowsAffected);
/* 171 */     return rowsAffected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(Object[] params, KeyHolder generatedKeyHolder) throws DataAccessException {
/* 182 */     if (!isReturnGeneratedKeys() && getGeneratedKeysColumnNames() == null) {
/* 183 */       throw new InvalidDataAccessApiUsageException("The update method taking a KeyHolder should only be used when generated keys have been configured by calling either 'setReturnGeneratedKeys' or 'setGeneratedKeysColumnNames'.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 188 */     validateParameters(params);
/* 189 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(params), generatedKeyHolder);
/* 190 */     checkRowsAffected(rowsAffected);
/* 191 */     return rowsAffected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update() throws DataAccessException {
/* 198 */     return update(new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(int p1) throws DataAccessException {
/* 205 */     return update(new Object[] { Integer.valueOf(p1) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(int p1, int p2) throws DataAccessException {
/* 212 */     return update(new Object[] { Integer.valueOf(p1), Integer.valueOf(p2) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(long p1) throws DataAccessException {
/* 219 */     return update(new Object[] { Long.valueOf(p1) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(long p1, long p2) throws DataAccessException {
/* 226 */     return update(new Object[] { Long.valueOf(p1), Long.valueOf(p2) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(String p) throws DataAccessException {
/* 233 */     return update(new Object[] { p });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(String p1, String p2) throws DataAccessException {
/* 240 */     return update(new Object[] { p1, p2 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int updateByNamedParam(Map<String, ?> paramMap) throws DataAccessException {
/* 251 */     validateNamedParameters(paramMap);
/* 252 */     ParsedSql parsedSql = getParsedSql();
/* 253 */     MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);
/* 254 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, (SqlParameterSource)paramSource);
/* 255 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, (SqlParameterSource)paramSource, getDeclaredParameters());
/* 256 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(sqlToUse, params));
/* 257 */     checkRowsAffected(rowsAffected);
/* 258 */     return rowsAffected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int updateByNamedParam(Map<String, ?> paramMap, KeyHolder generatedKeyHolder) throws DataAccessException {
/* 270 */     validateNamedParameters(paramMap);
/* 271 */     ParsedSql parsedSql = getParsedSql();
/* 272 */     MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);
/* 273 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, (SqlParameterSource)paramSource);
/* 274 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, (SqlParameterSource)paramSource, getDeclaredParameters());
/* 275 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(sqlToUse, params), generatedKeyHolder);
/* 276 */     checkRowsAffected(rowsAffected);
/* 277 */     return rowsAffected;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\object\SqlUpdate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */