/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.TypeMismatchDataAccessException;
/*     */ import org.springframework.jdbc.core.SingleColumnRowMapper;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlFunction<T>
/*     */   extends MappingSqlQuery<T>
/*     */ {
/*  55 */   private final SingleColumnRowMapper<T> rowMapper = new SingleColumnRowMapper();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlFunction() {
/*  68 */     setRowsExpected(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlFunction(DataSource ds, String sql) {
/*  79 */     setRowsExpected(1);
/*  80 */     setDataSource(ds);
/*  81 */     setSql(sql);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlFunction(DataSource ds, String sql, int[] types) {
/*  94 */     setRowsExpected(1);
/*  95 */     setDataSource(ds);
/*  96 */     setSql(sql);
/*  97 */     setTypes(types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlFunction(DataSource ds, String sql, int[] types, Class<T> resultType) {
/* 112 */     setRowsExpected(1);
/* 113 */     setDataSource(ds);
/* 114 */     setSql(sql);
/* 115 */     setTypes(types);
/* 116 */     setResultType(resultType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResultType(Class<T> resultType) {
/* 126 */     this.rowMapper.setRequiredType(resultType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected T mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 138 */     return (T)this.rowMapper.mapRow(rs, rowNum);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int run() {
/* 147 */     return run(new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int run(int parameter) {
/* 156 */     return run(new Object[] { Integer.valueOf(parameter) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int run(Object... parameters) {
/*     */     Number number;
/* 167 */     Object obj = findObject(parameters);
/* 168 */     if (obj instanceof Number) { number = (Number)obj; }
/* 169 */     else { throw new TypeMismatchDataAccessException("Could not convert result object [" + String.valueOf(obj) + "] to int"); }
/*     */     
/* 171 */     return number.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object runGeneric() {
/* 181 */     return findObject((Object[])null, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object runGeneric(int parameter) {
/* 191 */     return findObject(parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object runGeneric(Object[] parameters) {
/* 204 */     return findObject(parameters);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\object\SqlFunction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */