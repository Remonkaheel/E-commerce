/*    */ package org.springframework.jdbc.object;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericSqlQuery<T>
/*    */   extends SqlQuery<T>
/*    */ {
/*    */   @Nullable
/*    */   private RowMapper<T> rowMapper;
/*    */   @Nullable
/*    */   private Class<? extends RowMapper> rowMapperClass;
/*    */   
/*    */   public void setRowMapper(RowMapper<T> rowMapper) {
/* 52 */     this.rowMapper = rowMapper;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRowMapperClass(Class<? extends RowMapper> rowMapperClass) {
/* 61 */     this.rowMapperClass = rowMapperClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() {
/* 66 */     super.afterPropertiesSet();
/* 67 */     Assert.isTrue((this.rowMapper != null || this.rowMapperClass != null), "'rowMapper' or 'rowMapperClass' is required");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected RowMapper<T> newRowMapper(@Nullable Object[] parameters, @Nullable Map<?, ?> context) {
/* 75 */     if (this.rowMapper != null) {
/* 76 */       return this.rowMapper;
/*    */     }
/*    */     
/* 79 */     Assert.state((this.rowMapperClass != null), "No RowMapper set");
/* 80 */     return (RowMapper<T>)BeanUtils.instantiateClass(this.rowMapperClass);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\object\GenericSqlQuery.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */