/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.DataAccessUtils;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterUtils;
/*     */ import org.springframework.jdbc.core.namedparam.ParsedSql;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SqlQuery<T>
/*     */   extends SqlOperation
/*     */ {
/*  60 */   private int rowsExpected = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlQuery() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlQuery(DataSource ds, String sql) {
/*  78 */     setDataSource(ds);
/*  79 */     setSql(sql);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2.4", forRemoval = true)
/*     */   public void setRowsExpected(int rowsExpected) {
/*  92 */     this.rowsExpected = rowsExpected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2.4", forRemoval = true)
/*     */   public int getRowsExpected() {
/* 102 */     return this.rowsExpected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute(@Nullable Object[] params, @Nullable Map<?, ?> context) throws DataAccessException {
/* 118 */     validateParameters(params);
/* 119 */     RowMapper<T> rowMapper = newRowMapper(params, context);
/* 120 */     return getJdbcTemplate().query(newPreparedStatementCreator(params), rowMapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute(Object... params) throws DataAccessException {
/* 130 */     return execute(params, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute(Map<?, ?> context) throws DataAccessException {
/* 138 */     return execute((Object[])null, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute() throws DataAccessException {
/* 145 */     return execute((Object[])null, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute(int p1, @Nullable Map<?, ?> context) throws DataAccessException {
/* 154 */     return execute(new Object[] { Integer.valueOf(p1) }, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute(int p1) throws DataAccessException {
/* 162 */     return execute(p1, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute(int p1, int p2, @Nullable Map<?, ?> context) throws DataAccessException {
/* 172 */     return execute(new Object[] { Integer.valueOf(p1), Integer.valueOf(p2) }, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute(int p1, int p2) throws DataAccessException {
/* 181 */     return execute(p1, p2, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute(long p1, @Nullable Map<?, ?> context) throws DataAccessException {
/* 190 */     return execute(new Object[] { Long.valueOf(p1) }, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute(long p1) throws DataAccessException {
/* 198 */     return execute(p1, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute(String p1, @Nullable Map<?, ?> context) throws DataAccessException {
/* 207 */     return execute(new Object[] { p1 }, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> execute(String p1) throws DataAccessException {
/* 215 */     return execute(p1, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> executeByNamedParam(Map<String, ?> paramMap, @Nullable Map<?, ?> context) throws DataAccessException {
/* 231 */     validateNamedParameters(paramMap);
/* 232 */     ParsedSql parsedSql = getParsedSql();
/* 233 */     MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);
/* 234 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, (SqlParameterSource)paramSource);
/* 235 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, (SqlParameterSource)paramSource, getDeclaredParameters());
/* 236 */     RowMapper<T> rowMapper = newRowMapper(params, context);
/* 237 */     return getJdbcTemplate().query(newPreparedStatementCreator(sqlToUse, params), rowMapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> executeByNamedParam(Map<String, ?> paramMap) throws DataAccessException {
/* 247 */     return executeByNamedParam(paramMap, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObject(@Nullable Object[] params, @Nullable Map<?, ?> context) throws DataAccessException {
/* 261 */     List<T> results = execute(params, context);
/* 262 */     return (T)DataAccessUtils.singleResult(results);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObject(Object... params) throws DataAccessException {
/* 270 */     return findObject(params, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObject(int p1, @Nullable Map<?, ?> context) throws DataAccessException {
/* 279 */     return findObject(new Object[] { Integer.valueOf(p1) }, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObject(int p1) throws DataAccessException {
/* 287 */     return findObject(p1, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObject(int p1, int p2, @Nullable Map<?, ?> context) throws DataAccessException {
/* 296 */     return findObject(new Object[] { Integer.valueOf(p1), Integer.valueOf(p2) }, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObject(int p1, int p2) throws DataAccessException {
/* 304 */     return findObject(p1, p2, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObject(long p1, @Nullable Map<?, ?> context) throws DataAccessException {
/* 313 */     return findObject(new Object[] { Long.valueOf(p1) }, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObject(long p1) throws DataAccessException {
/* 321 */     return findObject(p1, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObject(String p1, @Nullable Map<?, ?> context) throws DataAccessException {
/* 330 */     return findObject(new Object[] { p1 }, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObject(String p1) throws DataAccessException {
/* 338 */     return findObject(p1, (Map<?, ?>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObjectByNamedParam(Map<String, ?> paramMap, @Nullable Map<?, ?> context) throws DataAccessException {
/* 354 */     List<T> results = executeByNamedParam(paramMap, context);
/* 355 */     return (T)DataAccessUtils.singleResult(results);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findObjectByNamedParam(Map<String, ?> paramMap) throws DataAccessException {
/* 366 */     return findObjectByNamedParam(paramMap, (Map<?, ?>)null);
/*     */   }
/*     */   
/*     */   protected abstract RowMapper<T> newRowMapper(@Nullable Object[] paramArrayOfObject, @Nullable Map<?, ?> paramMap);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\object\SqlQuery.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */