/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RdbmsOperation
/*     */   implements InitializingBean
/*     */ {
/*  65 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*  68 */   private JdbcTemplate jdbcTemplate = new JdbcTemplate();
/*     */   
/*  70 */   private int resultSetType = 1003;
/*     */   
/*     */   private boolean updatableResults = false;
/*     */   
/*     */   private boolean returnGeneratedKeys = false;
/*     */   
/*     */   @Nullable
/*     */   private String[] generatedKeysColumnNames;
/*     */   
/*     */   @Nullable
/*     */   private String sql;
/*     */   
/*  82 */   private final List<SqlParameter> declaredParameters = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean compiled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
/*  99 */     this.jdbcTemplate = jdbcTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcTemplate getJdbcTemplate() {
/* 106 */     return this.jdbcTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(DataSource dataSource) {
/* 114 */     this.jdbcTemplate.setDataSource(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFetchSize(int fetchSize) {
/* 126 */     this.jdbcTemplate.setFetchSize(fetchSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxRows(int maxRows) {
/* 137 */     this.jdbcTemplate.setMaxRows(maxRows);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQueryTimeout(int queryTimeout) {
/* 148 */     this.jdbcTemplate.setQueryTimeout(queryTimeout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResultSetType(int resultSetType) {
/* 160 */     this.resultSetType = resultSetType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getResultSetType() {
/* 167 */     return this.resultSetType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpdatableResults(boolean updatableResults) {
/* 176 */     if (isCompiled()) {
/* 177 */       throw new InvalidDataAccessApiUsageException("The updatableResults flag must be set before the operation is compiled");
/*     */     }
/*     */     
/* 180 */     this.updatableResults = updatableResults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUpdatableResults() {
/* 187 */     return this.updatableResults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReturnGeneratedKeys(boolean returnGeneratedKeys) {
/* 196 */     if (isCompiled()) {
/* 197 */       throw new InvalidDataAccessApiUsageException("The returnGeneratedKeys flag must be set before the operation is compiled");
/*     */     }
/*     */     
/* 200 */     this.returnGeneratedKeys = returnGeneratedKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReturnGeneratedKeys() {
/* 208 */     return this.returnGeneratedKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGeneratedKeysColumnNames(@Nullable String... names) {
/* 216 */     if (isCompiled()) {
/* 217 */       throw new InvalidDataAccessApiUsageException("The column names for the generated keys must be set before the operation is compiled");
/*     */     }
/*     */     
/* 220 */     this.generatedKeysColumnNames = names;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String[] getGeneratedKeysColumnNames() {
/* 228 */     return this.generatedKeysColumnNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSql(@Nullable String sql) {
/* 235 */     this.sql = sql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSql() {
/* 244 */     return this.sql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String resolveSql() {
/* 253 */     String sql = getSql();
/* 254 */     Assert.state((sql != null), "No SQL set");
/* 255 */     return sql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypes(@Nullable int[] types) throws InvalidDataAccessApiUsageException {
/* 268 */     if (isCompiled()) {
/* 269 */       throw new InvalidDataAccessApiUsageException("Cannot add parameters once query is compiled");
/*     */     }
/* 271 */     if (types != null) {
/* 272 */       for (int type : types) {
/* 273 */         declareParameter(new SqlParameter(type));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void declareParameter(SqlParameter param) throws InvalidDataAccessApiUsageException {
/* 291 */     if (isCompiled()) {
/* 292 */       throw new InvalidDataAccessApiUsageException("Cannot add parameters once the query is compiled");
/*     */     }
/* 294 */     this.declaredParameters.add(param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameters(SqlParameter... parameters) {
/* 305 */     if (isCompiled()) {
/* 306 */       throw new InvalidDataAccessApiUsageException("Cannot add parameters once the query is compiled");
/*     */     }
/* 308 */     for (int i = 0; i < parameters.length; i++) {
/* 309 */       if (parameters[i] != null) {
/* 310 */         this.declaredParameters.add(parameters[i]);
/*     */       } else {
/*     */         
/* 313 */         throw new InvalidDataAccessApiUsageException("Cannot add parameter at index " + i + " from " + 
/* 314 */             String.valueOf(Arrays.asList(parameters)) + " since it is 'null'");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<SqlParameter> getDeclaredParameters() {
/* 323 */     return this.declaredParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 332 */     compile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void compile() throws InvalidDataAccessApiUsageException {
/* 342 */     if (!isCompiled()) {
/* 343 */       if (getSql() == null) {
/* 344 */         throw new InvalidDataAccessApiUsageException("Property 'sql' is required");
/*     */       }
/*     */       
/*     */       try {
/* 348 */         this.jdbcTemplate.afterPropertiesSet();
/*     */       }
/* 350 */       catch (IllegalArgumentException ex) {
/* 351 */         throw new InvalidDataAccessApiUsageException(ex.getMessage());
/*     */       } 
/*     */       
/* 354 */       compileInternal();
/* 355 */       this.compiled = true;
/*     */       
/* 357 */       if (this.logger.isDebugEnabled()) {
/* 358 */         this.logger.debug("RdbmsOperation with SQL [" + getSql() + "] compiled");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompiled() {
/* 370 */     return this.compiled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkCompiled() {
/* 380 */     if (!isCompiled()) {
/* 381 */       this.logger.debug("SQL operation not compiled before execution - invoking compile");
/* 382 */       compile();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateParameters(@Nullable Object[] parameters) throws InvalidDataAccessApiUsageException {
/* 394 */     checkCompiled();
/* 395 */     int declaredInParameters = 0;
/* 396 */     for (SqlParameter param : this.declaredParameters) {
/* 397 */       if (param.isInputValueProvided()) {
/* 398 */         if (!supportsLobParameters() && (param
/* 399 */           .getSqlType() == 2004 || param.getSqlType() == 2005)) {
/* 400 */           throw new InvalidDataAccessApiUsageException("BLOB or CLOB parameters are not allowed for this kind of operation");
/*     */         }
/*     */         
/* 403 */         declaredInParameters++;
/*     */       } 
/*     */     } 
/* 406 */     validateParameterCount((parameters != null) ? parameters.length : 0, declaredInParameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateNamedParameters(@Nullable Map<String, ?> parameters) throws InvalidDataAccessApiUsageException {
/* 417 */     checkCompiled();
/* 418 */     Map<String, ?> paramsToUse = (parameters != null) ? parameters : Collections.emptyMap();
/* 419 */     int declaredInParameters = 0;
/* 420 */     for (SqlParameter param : this.declaredParameters) {
/* 421 */       if (param.isInputValueProvided()) {
/* 422 */         if (!supportsLobParameters() && (param
/* 423 */           .getSqlType() == 2004 || param.getSqlType() == 2005)) {
/* 424 */           throw new InvalidDataAccessApiUsageException("BLOB or CLOB parameters are not allowed for this kind of operation");
/*     */         }
/*     */         
/* 427 */         if (param.getName() != null && !paramsToUse.containsKey(param.getName())) {
/* 428 */           throw new InvalidDataAccessApiUsageException("The parameter named '" + param.getName() + "' was not among the parameters supplied: " + 
/* 429 */               String.valueOf(paramsToUse.keySet()));
/*     */         }
/* 431 */         declaredInParameters++;
/*     */       } 
/*     */     } 
/* 434 */     validateParameterCount(paramsToUse.size(), declaredInParameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateParameterCount(int suppliedParamCount, int declaredInParamCount) {
/* 443 */     if (suppliedParamCount < declaredInParamCount) {
/* 444 */       throw new InvalidDataAccessApiUsageException("" + suppliedParamCount + " parameters were supplied, but " + suppliedParamCount + " in parameters were declared in class [" + declaredInParamCount + "]");
/*     */     }
/*     */     
/* 447 */     if (suppliedParamCount > this.declaredParameters.size() && !allowsUnusedParameters()) {
/* 448 */       throw new InvalidDataAccessApiUsageException("" + suppliedParamCount + " parameters were supplied, but " + suppliedParamCount + " parameters were declared in class [" + declaredInParamCount + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void compileInternal() throws InvalidDataAccessApiUsageException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supportsLobParameters() {
/* 468 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean allowsUnusedParameters() {
/* 478 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\object\RdbmsOperation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */