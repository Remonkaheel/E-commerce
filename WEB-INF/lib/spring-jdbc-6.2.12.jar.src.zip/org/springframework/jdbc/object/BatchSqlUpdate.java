/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatchSqlUpdate
/*     */   extends SqlUpdate
/*     */ {
/*     */   public static final int DEFAULT_BATCH_SIZE = 5000;
/*  55 */   private int batchSize = 5000;
/*     */   
/*     */   private boolean trackRowsAffected = true;
/*     */   
/*  59 */   private final Deque<Object[]> parameterQueue = new ArrayDeque();
/*     */   
/*  61 */   private final List<Integer> rowsAffected = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BatchSqlUpdate() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BatchSqlUpdate(DataSource ds, String sql) {
/*  80 */     super(ds, sql);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BatchSqlUpdate(DataSource ds, String sql, int[] types) {
/*  93 */     super(ds, sql, types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BatchSqlUpdate(DataSource ds, String sql, int[] types, int batchSize) {
/* 109 */     super(ds, sql, types);
/* 110 */     setBatchSize(batchSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBatchSize(int batchSize) {
/* 124 */     this.batchSize = batchSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrackRowsAffected(boolean trackRowsAffected) {
/* 135 */     this.trackRowsAffected = trackRowsAffected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supportsLobParameters() {
/* 143 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(Object... params) throws DataAccessException {
/* 163 */     validateParameters(params);
/* 164 */     this.parameterQueue.add((Object[])params.clone());
/*     */     
/* 166 */     if (this.parameterQueue.size() == this.batchSize) {
/* 167 */       if (this.logger.isDebugEnabled()) {
/* 168 */         this.logger.debug("Triggering auto-flush because queue reached batch size of " + this.batchSize);
/*     */       }
/* 170 */       flush();
/*     */     } 
/*     */     
/* 173 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] flush() {
/* 181 */     if (this.parameterQueue.isEmpty()) {
/* 182 */       return new int[0];
/*     */     }
/*     */     
/* 185 */     int[] rowsAffected = getJdbcTemplate().batchUpdate(
/* 186 */         resolveSql(), new BatchPreparedStatementSetter()
/*     */         {
/*     */           public int getBatchSize()
/*     */           {
/* 190 */             return BatchSqlUpdate.this.parameterQueue.size();
/*     */           }
/*     */           
/*     */           public void setValues(PreparedStatement ps, int index) throws SQLException {
/* 194 */             Object[] params = BatchSqlUpdate.this.parameterQueue.removeFirst();
/* 195 */             BatchSqlUpdate.this.newPreparedStatementSetter(params).setValues(ps);
/*     */           }
/*     */         });
/*     */     
/* 199 */     for (int rowCount : rowsAffected) {
/* 200 */       checkRowsAffected(rowCount);
/* 201 */       if (this.trackRowsAffected) {
/* 202 */         this.rowsAffected.add(Integer.valueOf(rowCount));
/*     */       }
/*     */     } 
/*     */     
/* 206 */     return rowsAffected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getQueueCount() {
/* 214 */     return this.parameterQueue.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExecutionCount() {
/* 221 */     return this.rowsAffected.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getRowsAffected() {
/* 232 */     int[] result = new int[this.rowsAffected.size()];
/* 233 */     for (int i = 0; i < this.rowsAffected.size(); i++) {
/* 234 */       result[i] = ((Integer)this.rowsAffected.get(i)).intValue();
/*     */     }
/* 236 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 244 */     this.parameterQueue.clear();
/* 245 */     this.rowsAffected.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\object\BatchSqlUpdate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */