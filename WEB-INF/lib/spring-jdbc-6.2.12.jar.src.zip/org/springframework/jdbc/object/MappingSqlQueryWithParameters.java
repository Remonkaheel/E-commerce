/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MappingSqlQueryWithParameters<T>
/*     */   extends SqlQuery<T>
/*     */ {
/*     */   public MappingSqlQueryWithParameters() {}
/*     */   
/*     */   public MappingSqlQueryWithParameters(DataSource ds, String sql) {
/*  67 */     super(ds, sql);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RowMapper<T> newRowMapper(@Nullable Object[] parameters, @Nullable Map<?, ?> context) {
/*  77 */     return new RowMapperImpl(parameters, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract T mapRow(ResultSet paramResultSet, int paramInt, @Nullable Object[] paramArrayOfObject, @Nullable Map<?, ?> paramMap) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class RowMapperImpl
/*     */     implements RowMapper<T>
/*     */   {
/*     */     @Nullable
/*     */     private final Object[] params;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final Map<?, ?> context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RowMapperImpl(@Nullable Object[] parameters, Map<?, ?> context) {
/* 116 */       this.params = parameters;
/* 117 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 123 */       return MappingSqlQueryWithParameters.this.mapRow(rs, rowNum, this.params, this.context);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\object\MappingSqlQueryWithParameters.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */