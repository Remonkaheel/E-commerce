/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import org.springframework.dao.IncorrectUpdateSemanticsDataAccessException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdbcUpdateAffectedIncorrectNumberOfRowsException
/*    */   extends IncorrectUpdateSemanticsDataAccessException
/*    */ {
/*    */   private final int expected;
/*    */   private final int actual;
/*    */   
/*    */   public JdbcUpdateAffectedIncorrectNumberOfRowsException(String sql, int expected, int actual) {
/* 46 */     super("SQL update '" + sql + "' affected " + actual + " rows, not " + expected + " as expected");
/* 47 */     this.expected = expected;
/* 48 */     this.actual = actual;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getExpectedRowsAffected() {
/* 56 */     return this.expected;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getActualRowsAffected() {
/* 63 */     return this.actual;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean wasDataUpdated() {
/* 68 */     return (getActualRowsAffected() > 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\JdbcUpdateAffectedIncorrectNumberOfRowsException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */