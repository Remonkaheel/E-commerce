/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BadSqlGrammarException
/*    */   extends InvalidDataAccessResourceUsageException
/*    */ {
/*    */   private final String sql;
/*    */   
/*    */   public BadSqlGrammarException(String task, String sql, SQLException ex) {
/* 48 */     super(task + "; bad SQL grammar [" + task + "]", ex);
/* 49 */     this.sql = sql;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public SQLException getSQLException() {
/* 58 */     return (SQLException)getCause();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getSql() {
/* 65 */     return this.sql;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jdbc-6.2.12.jar!\org\springframework\jdbc\BadSqlGrammarException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */