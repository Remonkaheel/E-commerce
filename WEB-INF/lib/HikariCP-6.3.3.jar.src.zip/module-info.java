module com.zaxxer.hikari {
  requires java.base;
  requires java.sql;
  requires java.management;
  requires java.naming;
  requires org.slf4j;
  requires org.hibernate.orm.core;
  requires simpleclient;
  requires metrics.core;
  requires metrics.healthchecks;
  requires io.dropwizard.metrics5;
  requires micrometer.core;
  requires org.javassist;
  
  exports com.zaxxer.hikari;
  exports com.zaxxer.hikari.hibernate;
  exports com.zaxxer.hikari.metrics;
  exports com.zaxxer.hikari.metrics.dropwizard;
  exports com.zaxxer.hikari.metrics.micrometer;
  exports com.zaxxer.hikari.metrics.prometheus;
  exports com.zaxxer.hikari.pool;
  exports com.zaxxer.hikari.util;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\module-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */