package com.zaxxer.hikari.metrics;

public interface MetricsTrackerFactory {
  IMetricsTracker create(String paramString, PoolStats paramPoolStats);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikari\metrics\MetricsTrackerFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */