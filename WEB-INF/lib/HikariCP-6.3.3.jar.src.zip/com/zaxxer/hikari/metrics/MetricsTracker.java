package com.zaxxer.hikari.metrics;

@Deprecated
public class MetricsTracker implements IMetricsTracker {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikari\metrics\MetricsTracker.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */