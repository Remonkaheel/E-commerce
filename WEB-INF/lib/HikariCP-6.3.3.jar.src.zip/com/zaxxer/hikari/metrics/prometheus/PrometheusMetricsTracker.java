/*     */ package com.zaxxer.hikari.metrics.prometheus;
/*     */ 
/*     */ import com.zaxxer.hikari.metrics.IMetricsTracker;
/*     */ import io.prometheus.client.CollectorRegistry;
/*     */ import io.prometheus.client.Counter;
/*     */ import io.prometheus.client.Summary;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PrometheusMetricsTracker
/*     */   implements IMetricsTracker
/*     */ {
/*  43 */   private static final Counter CONNECTION_TIMEOUT_COUNTER = ((Counter.Builder)((Counter.Builder)((Counter.Builder)Counter.build()
/*  44 */     .name("hikaricp_connection_timeout_total"))
/*  45 */     .labelNames(new String[] { "pool"
/*  46 */       })).help("Connection timeout total count"))
/*  47 */     .create();
/*     */ 
/*     */   
/*  50 */   private static final Summary ELAPSED_ACQUIRED_SUMMARY = createSummary("hikaricp_connection_acquired_nanos", "Connection acquired time (ns)");
/*     */ 
/*     */   
/*  53 */   private static final Summary ELAPSED_USAGE_SUMMARY = createSummary("hikaricp_connection_usage_millis", "Connection usage (ms)");
/*     */ 
/*     */   
/*  56 */   private static final Summary ELAPSED_CREATION_SUMMARY = createSummary("hikaricp_connection_creation_millis", "Connection creation (ms)");
/*     */   
/*  58 */   private static final Map<CollectorRegistry, PrometheusMetricsTrackerFactory.RegistrationStatus> registrationStatuses = new ConcurrentHashMap<>();
/*     */   
/*     */   private final String poolName;
/*     */   
/*     */   private final HikariCPCollector hikariCPCollector;
/*     */   
/*     */   private final Counter.Child connectionTimeoutCounterChild;
/*     */   
/*     */   private final Summary.Child elapsedAcquiredSummaryChild;
/*     */   private final Summary.Child elapsedUsageSummaryChild;
/*     */   private final Summary.Child elapsedCreationSummaryChild;
/*     */   
/*     */   PrometheusMetricsTracker(String poolName, CollectorRegistry collectorRegistry, HikariCPCollector hikariCPCollector) {
/*  71 */     registerMetrics(collectorRegistry);
/*  72 */     this.poolName = poolName;
/*  73 */     this.hikariCPCollector = hikariCPCollector;
/*  74 */     this.connectionTimeoutCounterChild = (Counter.Child)CONNECTION_TIMEOUT_COUNTER.labels(new String[] { poolName });
/*  75 */     this.elapsedAcquiredSummaryChild = (Summary.Child)ELAPSED_ACQUIRED_SUMMARY.labels(new String[] { poolName });
/*  76 */     this.elapsedUsageSummaryChild = (Summary.Child)ELAPSED_USAGE_SUMMARY.labels(new String[] { poolName });
/*  77 */     this.elapsedCreationSummaryChild = (Summary.Child)ELAPSED_CREATION_SUMMARY.labels(new String[] { poolName });
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerMetrics(CollectorRegistry collectorRegistry) {
/*  82 */     if (registrationStatuses.putIfAbsent(collectorRegistry, PrometheusMetricsTrackerFactory.RegistrationStatus.REGISTERED) == null) {
/*  83 */       CONNECTION_TIMEOUT_COUNTER.register(collectorRegistry);
/*  84 */       ELAPSED_ACQUIRED_SUMMARY.register(collectorRegistry);
/*  85 */       ELAPSED_USAGE_SUMMARY.register(collectorRegistry);
/*  86 */       ELAPSED_CREATION_SUMMARY.register(collectorRegistry);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordConnectionAcquiredNanos(long elapsedAcquiredNanos) {
/*  93 */     this.elapsedAcquiredSummaryChild.observe(elapsedAcquiredNanos);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordConnectionUsageMillis(long elapsedBorrowedMillis) {
/*  99 */     this.elapsedUsageSummaryChild.observe(elapsedBorrowedMillis);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordConnectionCreatedMillis(long connectionCreatedMillis) {
/* 105 */     this.elapsedCreationSummaryChild.observe(connectionCreatedMillis);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordConnectionTimeout() {
/* 111 */     this.connectionTimeoutCounterChild.inc();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Summary createSummary(String name, String help) {
/* 116 */     return ((Summary.Builder)((Summary.Builder)((Summary.Builder)Summary.build()
/* 117 */       .name(name))
/* 118 */       .labelNames(new String[] { "pool"
/* 119 */         })).help(help))
/* 120 */       .quantile(0.5D, 0.05D)
/* 121 */       .quantile(0.95D, 0.01D)
/* 122 */       .quantile(0.99D, 0.001D)
/* 123 */       .maxAgeSeconds(TimeUnit.MINUTES.toSeconds(5L))
/* 124 */       .ageBuckets(5)
/* 125 */       .create();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 131 */     this.hikariCPCollector.remove(this.poolName);
/* 132 */     CONNECTION_TIMEOUT_COUNTER.remove(new String[] { this.poolName });
/* 133 */     ELAPSED_ACQUIRED_SUMMARY.remove(new String[] { this.poolName });
/* 134 */     ELAPSED_USAGE_SUMMARY.remove(new String[] { this.poolName });
/* 135 */     ELAPSED_CREATION_SUMMARY.remove(new String[] { this.poolName });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikari\metrics\prometheus\PrometheusMetricsTracker.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */