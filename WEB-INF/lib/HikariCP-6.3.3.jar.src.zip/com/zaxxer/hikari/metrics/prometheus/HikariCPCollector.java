/*    */ package com.zaxxer.hikari.metrics.prometheus;
/*    */ 
/*    */ import com.zaxxer.hikari.metrics.PoolStats;
/*    */ import io.prometheus.client.Collector;
/*    */ import io.prometheus.client.GaugeMetricFamily;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HikariCPCollector
/*    */   extends Collector
/*    */ {
/* 43 */   private static final List<String> LABEL_NAMES = Collections.singletonList("pool");
/*    */   
/* 45 */   private final Map<String, PoolStats> poolStatsMap = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Collector.MetricFamilySamples> collect() {
/* 50 */     return Arrays.asList(new Collector.MetricFamilySamples[] { (Collector.MetricFamilySamples)
/* 51 */           createGauge("hikaricp_active_connections", "Active connections", PoolStats::getActiveConnections), (Collector.MetricFamilySamples)
/*    */           
/* 53 */           createGauge("hikaricp_idle_connections", "Idle connections", PoolStats::getIdleConnections), (Collector.MetricFamilySamples)
/*    */           
/* 55 */           createGauge("hikaricp_pending_threads", "Pending threads", PoolStats::getPendingThreads), (Collector.MetricFamilySamples)
/*    */           
/* 57 */           createGauge("hikaricp_connections", "The number of current connections", PoolStats::getTotalConnections), (Collector.MetricFamilySamples)
/*    */           
/* 59 */           createGauge("hikaricp_max_connections", "Max connections", PoolStats::getMaxConnections), (Collector.MetricFamilySamples)
/*    */           
/* 61 */           createGauge("hikaricp_min_connections", "Min connections", PoolStats::getMinConnections) });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void add(String name, PoolStats poolStats) {
/* 68 */     this.poolStatsMap.put(name, poolStats);
/*    */   }
/*    */ 
/*    */   
/*    */   void remove(String name) {
/* 73 */     this.poolStatsMap.remove(name);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private GaugeMetricFamily createGauge(String metric, String help, Function<PoolStats, Integer> metricValueFunction) {
/* 79 */     GaugeMetricFamily metricFamily = new GaugeMetricFamily(metric, help, LABEL_NAMES);
/* 80 */     this.poolStatsMap.forEach((k, v) -> metricFamily.addMetric(Collections.singletonList(k), ((Integer)metricValueFunction.apply(v)).intValue()));
/*    */ 
/*    */ 
/*    */     
/* 84 */     return metricFamily;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikari\metrics\prometheus\HikariCPCollector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */