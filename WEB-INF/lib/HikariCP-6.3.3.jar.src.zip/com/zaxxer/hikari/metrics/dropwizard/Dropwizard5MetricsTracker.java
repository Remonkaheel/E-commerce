/*     */ package com.zaxxer.hikari.metrics.dropwizard;
/*     */ 
/*     */ import com.zaxxer.hikari.metrics.IMetricsTracker;
/*     */ import com.zaxxer.hikari.metrics.PoolStats;
/*     */ import io.dropwizard.metrics5.Histogram;
/*     */ import io.dropwizard.metrics5.Meter;
/*     */ import io.dropwizard.metrics5.Metric;
/*     */ import io.dropwizard.metrics5.MetricRegistry;
/*     */ import io.dropwizard.metrics5.Timer;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Dropwizard5MetricsTracker
/*     */   implements IMetricsTracker
/*     */ {
/*     */   private final String poolName;
/*     */   private final Timer connectionObtainTimer;
/*     */   private final Histogram connectionUsage;
/*     */   private final Histogram connectionCreation;
/*     */   private final Meter connectionTimeoutMeter;
/*     */   private final MetricRegistry registry;
/*     */   
/*     */   Dropwizard5MetricsTracker(String poolName, PoolStats poolStats, MetricRegistry registry) {
/*  52 */     this.poolName = poolName;
/*  53 */     this.registry = registry;
/*  54 */     this.connectionObtainTimer = registry.timer(MetricRegistry.name(poolName, new String[] { "pool", "Wait" }));
/*  55 */     this.connectionUsage = registry.histogram(MetricRegistry.name(poolName, new String[] { "pool", "Usage" }));
/*  56 */     this.connectionCreation = registry.histogram(MetricRegistry.name(poolName, new String[] { "pool", "ConnectionCreation" }));
/*  57 */     this.connectionTimeoutMeter = registry.meter(MetricRegistry.name(poolName, new String[] { "pool", "ConnectionTimeoutRate" }));
/*     */ 
/*     */     
/*  60 */     Objects.requireNonNull(poolStats); registry.register(MetricRegistry.name(poolName, new String[] { "pool", "TotalConnections" }), (Metric)poolStats::getTotalConnections);
/*     */ 
/*     */     
/*  63 */     Objects.requireNonNull(poolStats); registry.register(MetricRegistry.name(poolName, new String[] { "pool", "IdleConnections" }), (Metric)poolStats::getIdleConnections);
/*     */ 
/*     */     
/*  66 */     Objects.requireNonNull(poolStats); registry.register(MetricRegistry.name(poolName, new String[] { "pool", "ActiveConnections" }), (Metric)poolStats::getActiveConnections);
/*     */ 
/*     */     
/*  69 */     Objects.requireNonNull(poolStats); registry.register(MetricRegistry.name(poolName, new String[] { "pool", "PendingConnections" }), (Metric)poolStats::getPendingThreads);
/*     */ 
/*     */     
/*  72 */     Objects.requireNonNull(poolStats); registry.register(MetricRegistry.name(poolName, new String[] { "pool", "MaxConnections" }), (Metric)poolStats::getMaxConnections);
/*     */ 
/*     */     
/*  75 */     Objects.requireNonNull(poolStats); registry.register(MetricRegistry.name(poolName, new String[] { "pool", "MinConnections" }), (Metric)poolStats::getMinConnections);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  82 */     this.registry.remove(MetricRegistry.name(this.poolName, new String[] { "pool", "Wait" }));
/*  83 */     this.registry.remove(MetricRegistry.name(this.poolName, new String[] { "pool", "Usage" }));
/*  84 */     this.registry.remove(MetricRegistry.name(this.poolName, new String[] { "pool", "ConnectionCreation" }));
/*  85 */     this.registry.remove(MetricRegistry.name(this.poolName, new String[] { "pool", "ConnectionTimeoutRate" }));
/*  86 */     this.registry.remove(MetricRegistry.name(this.poolName, new String[] { "pool", "TotalConnections" }));
/*  87 */     this.registry.remove(MetricRegistry.name(this.poolName, new String[] { "pool", "IdleConnections" }));
/*  88 */     this.registry.remove(MetricRegistry.name(this.poolName, new String[] { "pool", "ActiveConnections" }));
/*  89 */     this.registry.remove(MetricRegistry.name(this.poolName, new String[] { "pool", "PendingConnections" }));
/*  90 */     this.registry.remove(MetricRegistry.name(this.poolName, new String[] { "pool", "MaxConnections" }));
/*  91 */     this.registry.remove(MetricRegistry.name(this.poolName, new String[] { "pool", "MinConnections" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordConnectionAcquiredNanos(long elapsedAcquiredNanos) {
/*  98 */     this.connectionObtainTimer.update(elapsedAcquiredNanos, TimeUnit.NANOSECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordConnectionUsageMillis(long elapsedBorrowedMillis) {
/* 105 */     this.connectionUsage.update(elapsedBorrowedMillis);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordConnectionTimeout() {
/* 111 */     this.connectionTimeoutMeter.mark();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordConnectionCreatedMillis(long connectionCreatedMillis) {
/* 117 */     this.connectionCreation.update(connectionCreatedMillis);
/*     */   }
/*     */ 
/*     */   
/*     */   public Timer getConnectionAcquisitionTimer() {
/* 122 */     return this.connectionObtainTimer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Histogram getConnectionDurationHistogram() {
/* 127 */     return this.connectionUsage;
/*     */   }
/*     */ 
/*     */   
/*     */   public Histogram getConnectionCreationHistogram() {
/* 132 */     return this.connectionCreation;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikari\metrics\dropwizard\Dropwizard5MetricsTracker.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */