/*    */ package com.zaxxer.hikari.util;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.sql.SQLTransientException;
/*    */ import java.util.concurrent.Semaphore;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuspendResumeLock
/*    */ {
/* 33 */   public static final SuspendResumeLock FAUX_LOCK = new SuspendResumeLock(false)
/*    */     {
/*    */       public void acquire() {}
/*    */ 
/*    */ 
/*    */       
/*    */       public void release() {}
/*    */ 
/*    */       
/*    */       public void suspend() {}
/*    */ 
/*    */       
/*    */       public void resume() {}
/*    */     };
/*    */ 
/*    */   
/*    */   private static final int MAX_PERMITS = 10000;
/*    */   
/*    */   private final Semaphore acquisitionSemaphore;
/*    */ 
/*    */   
/*    */   public SuspendResumeLock() {
/* 55 */     this(true);
/*    */   }
/*    */ 
/*    */   
/*    */   private SuspendResumeLock(boolean createSemaphore) {
/* 60 */     this.acquisitionSemaphore = createSemaphore ? new Semaphore(10000, true) : null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void acquire() throws SQLException {
/* 65 */     if (this.acquisitionSemaphore.tryAcquire()) {
/*    */       return;
/*    */     }
/* 68 */     if (Boolean.getBoolean("com.zaxxer.hikari.throwIfSuspended")) {
/* 69 */       throw new SQLTransientException("The pool is currently suspended and configured to throw exceptions upon acquisition");
/*    */     }
/*    */     
/* 72 */     this.acquisitionSemaphore.acquireUninterruptibly();
/*    */   }
/*    */ 
/*    */   
/*    */   public void release() {
/* 77 */     this.acquisitionSemaphore.release();
/*    */   }
/*    */ 
/*    */   
/*    */   public void suspend() {
/* 82 */     this.acquisitionSemaphore.acquireUninterruptibly(10000);
/*    */   }
/*    */ 
/*    */   
/*    */   public void resume() {
/* 87 */     this.acquisitionSemaphore.release(10000);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikar\\util\SuspendResumeLock.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */