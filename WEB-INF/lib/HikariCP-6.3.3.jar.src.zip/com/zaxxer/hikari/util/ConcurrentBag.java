/*     */ package com.zaxxer.hikari.util;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.locks.LockSupport;
/*     */ import java.util.stream.Collectors;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConcurrentBag<T extends ConcurrentBag.IConcurrentBagEntry>
/*     */   implements AutoCloseable
/*     */ {
/*  62 */   private static final Logger LOGGER = LoggerFactory.getLogger(ConcurrentBag.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final CopyOnWriteArrayList<T> sharedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean useWeakThreadLocals;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ThreadLocal<List<Object>> threadLocalList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final IBagStateListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final AtomicInteger waiters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean closed;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final SynchronousQueue<T> handoffQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentBag(IBagStateListener listener) {
/* 111 */     this.listener = listener;
/* 112 */     this.useWeakThreadLocals = useWeakThreadLocals();
/*     */     
/* 114 */     this.handoffQueue = new SynchronousQueue<>(true);
/* 115 */     this.waiters = new AtomicInteger();
/* 116 */     this.sharedList = new CopyOnWriteArrayList<>();
/* 117 */     this.threadLocalList = ThreadLocal.withInitial(() -> this.useWeakThreadLocals ? new ArrayList(16) : new FastList(IConcurrentBagEntry.class, 16));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T borrow(long timeout, TimeUnit timeUnit) throws InterruptedException {
/* 134 */     List<Object> list = this.threadLocalList.get();
/* 135 */     for (int i = list.size() - 1; i >= 0; i--) {
/* 136 */       Object entry = list.remove(i);
/*     */       
/* 138 */       IConcurrentBagEntry iConcurrentBagEntry = this.useWeakThreadLocals ? ((WeakReference<IConcurrentBagEntry>)entry).get() : (IConcurrentBagEntry)entry;
/* 139 */       if (iConcurrentBagEntry != null && iConcurrentBagEntry.compareAndSet(0, 1)) {
/* 140 */         return (T)iConcurrentBagEntry;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 145 */     int waiting = this.waiters.incrementAndGet();
/*     */     try {
/* 147 */       for (IConcurrentBagEntry iConcurrentBagEntry : this.sharedList) {
/* 148 */         if (iConcurrentBagEntry.compareAndSet(0, 1)) {
/*     */           
/* 150 */           if (waiting > 1) {
/* 151 */             this.listener.addBagItem(waiting - 1);
/*     */           }
/* 153 */           return (T)iConcurrentBagEntry;
/*     */         } 
/*     */       } 
/*     */       
/* 157 */       this.listener.addBagItem(waiting);
/*     */       
/* 159 */       timeout = timeUnit.toNanos(timeout);
/*     */       do {
/* 161 */         long start = ClockSource.currentTime();
/* 162 */         IConcurrentBagEntry iConcurrentBagEntry = (IConcurrentBagEntry)this.handoffQueue.poll(timeout, TimeUnit.NANOSECONDS);
/* 163 */         if (iConcurrentBagEntry == null || iConcurrentBagEntry.compareAndSet(0, 1)) {
/* 164 */           return (T)iConcurrentBagEntry;
/*     */         }
/*     */         
/* 167 */         timeout -= ClockSource.elapsedNanos(start);
/* 168 */       } while (timeout > 10000L);
/*     */       
/* 170 */       return null;
/*     */     } finally {
/*     */       
/* 173 */       this.waiters.decrementAndGet();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requite(T bagEntry) {
/* 188 */     bagEntry.setState(0);
/*     */     
/* 190 */     for (int i = 0; this.waiters.get() > 0; i++) {
/* 191 */       if (bagEntry.getState() != 0 || this.handoffQueue.offer(bagEntry)) {
/*     */         return;
/*     */       }
/* 194 */       if ((i & 0xFF) == 255) {
/* 195 */         LockSupport.parkNanos(TimeUnit.MICROSECONDS.toNanos(10L));
/*     */       } else {
/*     */         
/* 198 */         Thread.yield();
/*     */       } 
/*     */     } 
/*     */     
/* 202 */     List<Object> threadLocalEntries = this.threadLocalList.get();
/* 203 */     if (threadLocalEntries.size() < 16) {
/* 204 */       threadLocalEntries.add(this.useWeakThreadLocals ? new WeakReference<>(bagEntry) : bagEntry);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(T bagEntry) {
/* 215 */     if (this.closed) {
/* 216 */       LOGGER.info("ConcurrentBag has been closed, ignoring add()");
/* 217 */       throw new IllegalStateException("ConcurrentBag has been closed, ignoring add()");
/*     */     } 
/*     */     
/* 220 */     this.sharedList.add(bagEntry);
/*     */ 
/*     */     
/* 223 */     while (this.waiters.get() > 0 && bagEntry.getState() == 0 && !this.handoffQueue.offer(bagEntry)) {
/* 224 */       Thread.yield();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(T bagEntry) {
/* 239 */     if (!bagEntry.compareAndSet(1, -1) && !bagEntry.compareAndSet(-2, -1) && !this.closed) {
/* 240 */       LOGGER.warn("Attempt to remove an object from the bag that was not borrowed or reserved: {}", bagEntry);
/* 241 */       return false;
/*     */     } 
/*     */     
/* 244 */     boolean removed = this.sharedList.remove(bagEntry);
/* 245 */     if (!removed && !this.closed) {
/* 246 */       LOGGER.warn("Attempt to remove an object from the bag that does not exist: {}", bagEntry);
/*     */     }
/*     */     
/* 249 */     ((List)this.threadLocalList.get()).remove(bagEntry);
/*     */     
/* 251 */     return removed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 260 */     this.closed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> values(int state) {
/* 274 */     List<T> list = (List<T>)this.sharedList.stream().filter(e -> (e.getState() == state)).collect(Collectors.toList());
/* 275 */     Collections.reverse(list);
/* 276 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> values() {
/* 290 */     return (List<T>)this.sharedList.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean reserve(T bagEntry) {
/* 307 */     return bagEntry.compareAndSet(0, -2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unreserve(T bagEntry) {
/* 319 */     if (bagEntry.compareAndSet(-2, 0)) {
/*     */       
/* 321 */       while (this.waiters.get() > 0 && bagEntry.getState() == 0 && !this.handoffQueue.offer(bagEntry)) {
/* 322 */         Thread.yield();
/*     */       }
/*     */     } else {
/*     */       
/* 326 */       LOGGER.warn("Attempt to relinquish an object to the bag that was not reserved: {}", bagEntry);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWaitingThreadCount() {
/* 338 */     return this.waiters.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCount(int state) {
/* 349 */     int count = 0;
/* 350 */     for (IConcurrentBagEntry iConcurrentBagEntry : this.sharedList) {
/* 351 */       if (iConcurrentBagEntry.getState() == state) {
/* 352 */         count++;
/*     */       }
/*     */     } 
/* 355 */     return count;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getStateCounts() {
/* 360 */     int[] states = new int[6];
/* 361 */     for (IConcurrentBagEntry iConcurrentBagEntry : this.sharedList) {
/* 362 */       states[iConcurrentBagEntry.getState()] = states[iConcurrentBagEntry.getState()] + 1;
/*     */     }
/* 364 */     states[4] = this.sharedList.size();
/* 365 */     states[5] = this.waiters.get();
/*     */     
/* 367 */     return states;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 377 */     return this.sharedList.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dumpState() {
/* 382 */     this.sharedList.forEach(entry -> LOGGER.info(entry.toString()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean useWeakThreadLocals() {
/*     */     try {
/* 395 */       if (System.getProperty("com.zaxxer.hikari.useWeakReferences") != null) {
/* 396 */         return Boolean.getBoolean("com.zaxxer.hikari.useWeakReferences");
/*     */       }
/*     */       
/* 399 */       return (getClass().getClassLoader() != ClassLoader.getSystemClassLoader());
/*     */     }
/* 401 */     catch (SecurityException se) {
/* 402 */       return true;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface IBagStateListener {
/*     */     void addBagItem(int param1Int);
/*     */   }
/*     */   
/*     */   public static interface IConcurrentBagEntry {
/*     */     public static final int STATE_NOT_IN_USE = 0;
/*     */     public static final int STATE_IN_USE = 1;
/*     */     public static final int STATE_REMOVED = -1;
/*     */     public static final int STATE_RESERVED = -2;
/*     */     
/*     */     boolean compareAndSet(int param1Int1, int param1Int2);
/*     */     
/*     */     void setState(int param1Int);
/*     */     
/*     */     int getState();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikar\\util\ConcurrentBag.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */