/*     */ package com.zaxxer.hikari.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.RandomAccess;
/*     */ import java.util.Spliterator;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.UnaryOperator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FastList<T>
/*     */   implements List<T>, RandomAccess, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -4598088075242913858L;
/*     */   private final Class<?> clazz;
/*     */   private T[] elementData;
/*     */   private int size;
/*     */   
/*     */   public FastList(Class<?> clazz) {
/*  55 */     this.elementData = (T[])Array.newInstance(clazz, 32);
/*  56 */     this.clazz = clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastList(Class<?> clazz, int capacity) {
/*  67 */     this.elementData = (T[])Array.newInstance(clazz, capacity);
/*  68 */     this.clazz = clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(T element) {
/*  79 */     if (this.size < this.elementData.length) {
/*  80 */       this.elementData[this.size++] = element;
/*     */     }
/*     */     else {
/*     */       
/*  84 */       int oldCapacity = this.elementData.length;
/*  85 */       int newCapacity = oldCapacity << 1;
/*     */       
/*  87 */       T[] newElementData = (T[])Array.newInstance(this.clazz, newCapacity);
/*  88 */       System.arraycopy(this.elementData, 0, newElementData, 0, oldCapacity);
/*  89 */       newElementData[this.size++] = element;
/*  90 */       this.elementData = newElementData;
/*     */     } 
/*     */     
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T get(int index) {
/* 105 */     return this.elementData[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T removeLast() {
/* 117 */     T element = this.elementData[--this.size];
/* 118 */     this.elementData[this.size] = null;
/* 119 */     return element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(Object element) {
/* 132 */     for (int index = this.size - 1; index >= 0; index--) {
/* 133 */       if (element == this.elementData[index]) {
/* 134 */         int numMoved = this.size - index - 1;
/* 135 */         if (numMoved > 0) {
/* 136 */           System.arraycopy(this.elementData, index + 1, this.elementData, index, numMoved);
/*     */         }
/* 138 */         this.elementData[--this.size] = null;
/* 139 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 143 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 152 */     for (int i = 0; i < this.size; i++) {
/* 153 */       this.elementData[i] = null;
/*     */     }
/*     */     
/* 156 */     this.size = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 167 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 174 */     return (this.size == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T set(int index, T element) {
/* 181 */     T old = this.elementData[index];
/* 182 */     this.elementData[index] = element;
/* 183 */     return old;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T remove(int index) {
/* 190 */     if (this.size == 0) {
/* 191 */       return null;
/*     */     }
/*     */     
/* 194 */     T old = this.elementData[index];
/*     */     
/* 196 */     int numMoved = this.size - index - 1;
/* 197 */     if (numMoved > 0) {
/* 198 */       System.arraycopy(this.elementData, index + 1, this.elementData, index, numMoved);
/*     */     }
/*     */     
/* 201 */     this.elementData[--this.size] = null;
/*     */     
/* 203 */     return old;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 210 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 217 */     return new Iterator<T>()
/*     */       {
/*     */         private int index;
/*     */ 
/*     */         
/*     */         public boolean hasNext() {
/* 223 */           return (this.index < FastList.this.size);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public T next() {
/* 229 */           if (this.index < FastList.this.size) {
/* 230 */             return FastList.this.elementData[this.index++];
/*     */           }
/*     */           
/* 233 */           throw new NoSuchElementException("No more elements in FastList");
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 242 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E> E[] toArray(E[] a) {
/* 249 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> c) {
/* 256 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends T> c) {
/* 263 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(int index, Collection<? extends T> c) {
/* 270 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 277 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> c) {
/* 284 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int index, T element) {
/* 291 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOf(Object o) {
/* 298 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 305 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListIterator<T> listIterator() {
/* 312 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListIterator<T> listIterator(int index) {
/* 319 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> subList(int fromIndex, int toIndex) {
/* 326 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 333 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEach(Consumer<? super T> action) {
/* 340 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Spliterator<T> spliterator() {
/* 347 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeIf(Predicate<? super T> filter) {
/* 354 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAll(UnaryOperator<T> operator) {
/* 361 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sort(Comparator<? super T> c) {
/* 368 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikar\\util\FastList.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */