/*     */ package com.zaxxer.hikari.util;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.DataSource;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DriverDataSource
/*     */   implements DataSource
/*     */ {
/*  42 */   private static final Logger LOGGER = LoggerFactory.getLogger(DriverDataSource.class);
/*     */   
/*     */   private static final String PASSWORD = "password";
/*     */   
/*     */   private static final String USER = "user";
/*     */   private final String jdbcUrl;
/*     */   private final Properties driverProperties;
/*     */   private Driver driver;
/*     */   
/*     */   public DriverDataSource(String jdbcUrl, String driverClassName, Properties properties, String username, String password) {
/*  52 */     this.jdbcUrl = jdbcUrl;
/*  53 */     this.driverProperties = new Properties();
/*     */     
/*  55 */     this.driverProperties.putAll(properties);
/*     */     
/*  57 */     if (username != null) {
/*  58 */       this.driverProperties.put("user", this.driverProperties.getProperty("user", username));
/*     */     }
/*  60 */     if (password != null) {
/*  61 */       this.driverProperties.put("password", this.driverProperties.getProperty("password", password));
/*     */     }
/*     */     
/*  64 */     if (driverClassName != null) {
/*  65 */       Enumeration<Driver> drivers = DriverManager.getDrivers();
/*  66 */       while (drivers.hasMoreElements()) {
/*  67 */         Driver d = drivers.nextElement();
/*  68 */         if (d.getClass().getName().equals(driverClassName)) {
/*  69 */           this.driver = d;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*  74 */       if (this.driver == null) {
/*  75 */         LOGGER.warn("Registered driver with driverClassName={} was not found, trying direct instantiation.", driverClassName);
/*  76 */         Class<?> driverClass = null;
/*  77 */         ClassLoader threadContextClassLoader = Thread.currentThread().getContextClassLoader();
/*     */         try {
/*  79 */           if (threadContextClassLoader != null) {
/*     */             try {
/*  81 */               driverClass = threadContextClassLoader.loadClass(driverClassName);
/*  82 */               LOGGER.debug("Driver class {} found in Thread context class loader {}", driverClassName, threadContextClassLoader);
/*     */             }
/*  84 */             catch (ClassNotFoundException e) {
/*  85 */               LOGGER.debug("Driver class {} not found in Thread context class loader {}, trying classloader {}", new Object[] { driverClassName, threadContextClassLoader, 
/*  86 */                     getClass().getClassLoader() });
/*     */             } 
/*     */           }
/*     */           
/*  90 */           if (driverClass == null) {
/*  91 */             driverClass = getClass().getClassLoader().loadClass(driverClassName);
/*  92 */             LOGGER.debug("Driver class {} found in the HikariConfig class classloader {}", driverClassName, getClass().getClassLoader());
/*     */           } 
/*  94 */         } catch (ClassNotFoundException e) {
/*  95 */           LOGGER.debug("Failed to load driver class {} from HikariConfig class classloader {}", driverClassName, getClass().getClassLoader());
/*     */         } 
/*     */         
/*  98 */         if (driverClass != null) {
/*     */           try {
/* 100 */             this.driver = driverClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/* 101 */           } catch (Exception e) {
/* 102 */             LOGGER.warn("Failed to create instance of driver class {}, trying jdbcUrl resolution", driverClassName, e);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     String sanitizedUrl = UtilityElf.maskPasswordInJdbcUrl(jdbcUrl);
/*     */     
/*     */     try {
/* 111 */       if (this.driver == null) {
/* 112 */         this.driver = DriverManager.getDriver(jdbcUrl);
/* 113 */         LOGGER.debug("Loaded driver with class name {} for jdbcUrl={}", this.driver.getClass().getName(), sanitizedUrl);
/*     */       }
/* 115 */       else if (!this.driver.acceptsURL(jdbcUrl)) {
/* 116 */         throw new RuntimeException("Driver " + driverClassName + " claims to not accept jdbcUrl, " + sanitizedUrl);
/*     */       }
/*     */     
/* 119 */     } catch (SQLException e) {
/* 120 */       throw new RuntimeException("Failed to get driver instance for jdbcUrl=" + sanitizedUrl, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 127 */     return this.driver.connect(this.jdbcUrl, this.driverProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/* 133 */     Properties cloned = (Properties)this.driverProperties.clone();
/* 134 */     if (username != null) {
/* 135 */       cloned.put("user", username);
/* 136 */       if (cloned.containsKey("username")) {
/* 137 */         cloned.put("username", username);
/*     */       }
/*     */     } 
/* 140 */     if (password != null) {
/* 141 */       cloned.put("password", password);
/*     */     }
/*     */     
/* 144 */     return this.driver.connect(this.jdbcUrl, cloned);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getLogWriter() throws SQLException {
/* 150 */     throw new SQLFeatureNotSupportedException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogWriter(PrintWriter logWriter) throws SQLException {
/* 156 */     throw new SQLFeatureNotSupportedException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginTimeout(int seconds) throws SQLException {
/* 162 */     DriverManager.setLoginTimeout(seconds);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLoginTimeout() throws SQLException {
/* 168 */     return DriverManager.getLoginTimeout();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Logger getParentLogger() throws SQLFeatureNotSupportedException {
/* 174 */     return this.driver.getParentLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/* 180 */     throw new SQLFeatureNotSupportedException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 186 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikar\\util\DriverDataSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */