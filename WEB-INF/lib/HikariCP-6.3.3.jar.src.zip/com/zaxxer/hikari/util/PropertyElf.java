/*     */ package com.zaxxer.hikari.util;
/*     */ 
/*     */ import com.zaxxer.hikari.HikariConfig;
/*     */ import java.lang.reflect.Method;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Optional;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PropertyElf
/*     */ {
/*     */   private static final char ESCAPE_CHAR = '\\';
/*     */   private static final char SEPARATOR_CHAR = ',';
/*  37 */   private static final Pattern DURATION_PATTERN = Pattern.compile("^(?<number>\\d+)(?<unit>ms|s|m|h|d)$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setTargetFromProperties(Object target, Properties properties) {
/*  45 */     if (target == null || properties == null) {
/*     */       return;
/*     */     }
/*     */     
/*  49 */     List<Method> methods = Arrays.asList(target.getClass().getMethods());
/*  50 */     properties.forEach((key, value) -> {
/*     */           String keyName = key.toString();
/*     */           if (target instanceof HikariConfig && keyName.startsWith("dataSource.")) {
/*     */             ((HikariConfig)target).addDataSourceProperty(keyName.substring("dataSource.".length()), value);
/*     */           } else {
/*     */             setProperty(target, keyName, value, methods);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<String> getPropertyNames(Class<?> targetClass) {
/*  69 */     HashSet<String> set = new HashSet<>();
/*  70 */     for (Method method : targetClass.getMethods()) {
/*  71 */       String name = propertyNameFromGetterName(method.getName());
/*     */       try {
/*  73 */         if ((method.getParameterTypes()).length == 0 && name != null) {
/*  74 */           targetClass.getMethod("set" + capitalizedPropertyName(name), new Class[] { method.getReturnType() });
/*  75 */           set.add(name);
/*     */         }
/*     */       
/*  78 */       } catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  83 */     return set;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getProperty(String propName, Object target) {
/*     */     try {
/*  90 */       String capitalized = "get" + capitalizedPropertyName(propName);
/*  91 */       Method method = target.getClass().getMethod(capitalized, new Class[0]);
/*  92 */       return method.invoke(target, new Object[0]);
/*     */     }
/*  94 */     catch (Exception e) {
/*     */       try {
/*  96 */         String capitalized = "is" + capitalizedPropertyName(propName);
/*  97 */         Method method = target.getClass().getMethod(capitalized, new Class[0]);
/*  98 */         return method.invoke(target, new Object[0]);
/*     */       }
/* 100 */       catch (Exception e2) {
/* 101 */         return null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Properties copyProperties(Properties props) {
/* 108 */     Properties copy = new Properties();
/* 109 */     props.forEach((key, value) -> copy.setProperty(key.toString(), value.toString()));
/* 110 */     return copy;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String propertyNameFromGetterName(String methodName) {
/* 115 */     String name = null;
/* 116 */     if (methodName.startsWith("get") && methodName.length() > 3) {
/* 117 */       name = methodName.substring(3);
/*     */     }
/* 119 */     else if (methodName.startsWith("is") && methodName.length() > 2) {
/* 120 */       name = methodName.substring(2);
/*     */     } 
/*     */     
/* 123 */     if (name != null) {
/* 124 */       return "" + Character.toLowerCase(name.charAt(0)) + Character.toLowerCase(name.charAt(0));
/*     */     }
/*     */     
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void setProperty(Object target, String propName, Object propValue, List<Method> methods) {
/* 132 */     Logger logger = LoggerFactory.getLogger(PropertyElf.class);
/*     */ 
/*     */     
/* 135 */     String methodName = "set" + propName.substring(0, 1).toUpperCase(Locale.ENGLISH) + propName.substring(1);
/* 136 */     Method writeMethod = methods.stream().filter(m -> (m.getName().equals(methodName) && m.getParameterCount() == 1)).findFirst().orElse(null);
/*     */     
/* 138 */     if (writeMethod == null) {
/* 139 */       String methodName2 = "set" + propName.toUpperCase(Locale.ENGLISH);
/* 140 */       writeMethod = methods.stream().filter(m -> (m.getName().equals(methodName2) && m.getParameterCount() == 1)).findFirst().orElse(null);
/*     */     } 
/*     */     
/* 143 */     if (writeMethod == null) {
/* 144 */       logger.error("Property {} does not exist on target {}", propName, target.getClass());
/* 145 */       throw new RuntimeException(String.format("Property %s does not exist on target %s", new Object[] { propName, target.getClass() }));
/*     */     } 
/*     */     
/*     */     try {
/* 149 */       Class<?> paramClass = writeMethod.getParameterTypes()[0];
/* 150 */       String value = propValue.toString();
/* 151 */       if (paramClass == int.class) {
/* 152 */         writeMethod.invoke(target, new Object[] { Integer.valueOf(Integer.parseInt(propValue.toString())) });
/*     */       }
/* 154 */       else if (paramClass == long.class) {
/* 155 */         writeMethod.invoke(target, new Object[] { parseDuration(value).map(Duration::toMillis).orElseGet(() -> Long.valueOf(Long.parseLong(value))) });
/*     */       }
/* 157 */       else if (paramClass == short.class) {
/* 158 */         writeMethod.invoke(target, new Object[] { Short.valueOf(Short.parseShort(value)) });
/*     */       }
/* 160 */       else if (paramClass == boolean.class || paramClass == Boolean.class) {
/* 161 */         writeMethod.invoke(target, new Object[] { Boolean.valueOf(Boolean.parseBoolean(value)) });
/*     */       }
/* 163 */       else if (paramClass.isArray() && char.class.isAssignableFrom(paramClass.getComponentType())) {
/* 164 */         writeMethod.invoke(target, new Object[] { value.toCharArray() });
/*     */       }
/* 166 */       else if (paramClass.isArray() && int.class.isAssignableFrom(paramClass.getComponentType())) {
/* 167 */         writeMethod.invoke(target, new Object[] { parseIntArray(value) });
/*     */       }
/* 169 */       else if (paramClass.isArray() && String.class.isAssignableFrom(paramClass.getComponentType())) {
/* 170 */         writeMethod.invoke(target, new Object[] { parseStringArray(value) });
/*     */       }
/* 172 */       else if (paramClass == String.class) {
/* 173 */         writeMethod.invoke(target, new Object[] { value });
/*     */       } else {
/*     */         
/*     */         try {
/* 177 */           logger.debug("Try to create a new instance of \"{}\"", propValue);
/* 178 */           writeMethod.invoke(target, new Object[] { Class.forName(propValue.toString()).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]) });
/*     */         }
/* 180 */         catch (InstantiationException|ClassNotFoundException e) {
/* 181 */           logger.debug("Class \"{}\" not found or could not instantiate it (Default constructor)", propValue);
/* 182 */           writeMethod.invoke(target, new Object[] { propValue });
/*     */         }
/*     */       
/*     */       } 
/* 186 */     } catch (Exception e) {
/* 187 */       logger.error("Failed to set property {} on target {}", new Object[] { propName, target.getClass(), e });
/* 188 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String capitalizedPropertyName(String propertyName) {
/* 195 */     return propertyName.substring(0, 1).toUpperCase(Locale.ENGLISH) + propertyName.substring(0, 1).toUpperCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int[] parseIntArray(String value) {
/* 200 */     if (value == null || value.isEmpty()) {
/* 201 */       return new int[0];
/*     */     }
/*     */     
/* 204 */     String[] split = value.split(",");
/* 205 */     int[] intArray = new int[split.length];
/* 206 */     for (int i = 0; i < split.length; i++) {
/* 207 */       intArray[i] = Integer.parseInt(split[i]);
/*     */     }
/* 209 */     return intArray;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String[] parseStringArray(String value) {
/* 214 */     if (value == null || value.isEmpty()) {
/* 215 */       return new String[0];
/*     */     }
/*     */     
/* 218 */     ArrayList<String> resultList = new ArrayList<>();
/* 219 */     boolean inEscape = false;
/* 220 */     StringBuilder currentField = new StringBuilder();
/* 221 */     for (char c : value.toCharArray()) {
/*     */       
/* 223 */       if (inEscape) {
/* 224 */         currentField.append(c);
/* 225 */         inEscape = false;
/*     */       }
/* 227 */       else if (c == '\\') {
/* 228 */         inEscape = true;
/* 229 */       } else if (c == ',') {
/* 230 */         resultList.add(currentField.toString());
/* 231 */         currentField.setLength(0);
/*     */       } else {
/*     */         
/* 234 */         currentField.append(c);
/*     */       } 
/*     */     } 
/*     */     
/* 238 */     if (inEscape) {
/* 239 */       throw new IllegalArgumentException(String.format("Unterminated escape sequence in property value: %s", new Object[] { value }));
/*     */     }
/*     */     
/* 242 */     resultList.add(currentField.toString());
/* 243 */     return resultList.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Optional<Duration> parseDuration(String value) {
/* 248 */     Matcher matcher = DURATION_PATTERN.matcher(value);
/* 249 */     if (matcher.matches()) {
/* 250 */       long number = Long.parseLong(matcher.group("number"));
/* 251 */       String unit = matcher.group("unit");
/* 252 */       switch (unit) {
/*     */         case "ms":
/* 254 */           return Optional.of(Duration.ofMillis(number));
/*     */         case "s":
/* 256 */           return Optional.of(Duration.ofSeconds(number));
/*     */         case "m":
/* 258 */           return Optional.of(Duration.ofMinutes(number));
/*     */         case "h":
/* 260 */           return Optional.of(Duration.ofHours(number));
/*     */         case "d":
/* 262 */           return Optional.of(Duration.ofDays(number));
/*     */       } 
/* 264 */       throw new IllegalStateException(String.format("Could not match unit, got %s (from given value %s)", new Object[] { unit, value }));
/*     */     } 
/*     */     
/* 267 */     return Optional.empty();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikar\\util\PropertyElf.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */