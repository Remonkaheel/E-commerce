/*     */ package com.zaxxer.hikari.util;
/*     */ 
/*     */ import com.zaxxer.hikari.pool.ProxyCallableStatement;
/*     */ import com.zaxxer.hikari.pool.ProxyConnection;
/*     */ import com.zaxxer.hikari.pool.ProxyDatabaseMetaData;
/*     */ import com.zaxxer.hikari.pool.ProxyPreparedStatement;
/*     */ import com.zaxxer.hikari.pool.ProxyResultSet;
/*     */ import com.zaxxer.hikari.pool.ProxyStatement;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javassist.CannotCompileException;
/*     */ import javassist.ClassPath;
/*     */ import javassist.ClassPool;
/*     */ import javassist.CtClass;
/*     */ import javassist.CtMethod;
/*     */ import javassist.CtNewMethod;
/*     */ import javassist.LoaderClassPath;
/*     */ import javassist.Modifier;
/*     */ import javassist.NotFoundException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JavassistProxyFactory
/*     */ {
/*     */   private static ClassPool classPool;
/*  45 */   private static String genDirectory = "target" + File.separator + "classes";
/*     */   
/*     */   public static void main(String... args) throws Exception {
/*  48 */     classPool = new ClassPool();
/*  49 */     classPool.importPackage("java.sql");
/*  50 */     classPool.appendClassPath((ClassPath)new LoaderClassPath(JavassistProxyFactory.class.getClassLoader()));
/*     */     
/*  52 */     if (args.length > 0) {
/*  53 */       String parentDir = args[0];
/*  54 */       if (!parentDir.endsWith(File.separator)) {
/*  55 */         parentDir = parentDir + parentDir;
/*     */       }
/*  57 */       genDirectory = parentDir + parentDir;
/*     */     } 
/*     */     
/*  60 */     System.out.println("Generating following classes to " + genDirectory);
/*     */ 
/*     */     
/*  63 */     String methodBody = "{ try { return delegate.method($$); } catch (SQLException e) { throw checkException(e); } }";
/*  64 */     generateProxyClass(Connection.class, ProxyConnection.class.getName(), methodBody);
/*  65 */     generateProxyClass(Statement.class, ProxyStatement.class.getName(), methodBody);
/*  66 */     generateProxyClass(ResultSet.class, ProxyResultSet.class.getName(), methodBody);
/*  67 */     generateProxyClass(DatabaseMetaData.class, ProxyDatabaseMetaData.class.getName(), methodBody);
/*     */ 
/*     */     
/*  70 */     methodBody = "{ try { return ((cast) delegate).method($$); } catch (SQLException e) { throw checkException(e); } }";
/*  71 */     generateProxyClass(PreparedStatement.class, ProxyPreparedStatement.class.getName(), methodBody);
/*  72 */     generateProxyClass(CallableStatement.class, ProxyCallableStatement.class.getName(), methodBody);
/*     */     
/*  74 */     modifyProxyFactory();
/*     */   }
/*     */   
/*     */   private static void modifyProxyFactory() throws NotFoundException, CannotCompileException, IOException {
/*  78 */     System.out.println("Generating method bodies for com.zaxxer.hikari.proxy.ProxyFactory");
/*     */     
/*  80 */     String packageName = ProxyConnection.class.getPackage().getName();
/*  81 */     CtClass proxyCt = classPool.getCtClass("com.zaxxer.hikari.pool.ProxyFactory");
/*  82 */     for (CtMethod method : proxyCt.getMethods()) {
/*  83 */       switch (method.getName()) {
/*     */         case "getProxyConnection":
/*  85 */           method.setBody("{return new " + packageName + ".HikariProxyConnection($$);}");
/*     */           break;
/*     */         case "getProxyStatement":
/*  88 */           method.setBody("{return new " + packageName + ".HikariProxyStatement($$);}");
/*     */           break;
/*     */         case "getProxyPreparedStatement":
/*  91 */           method.setBody("{return new " + packageName + ".HikariProxyPreparedStatement($$);}");
/*     */           break;
/*     */         case "getProxyCallableStatement":
/*  94 */           method.setBody("{return new " + packageName + ".HikariProxyCallableStatement($$);}");
/*     */           break;
/*     */         case "getProxyResultSet":
/*  97 */           method.setBody("{return new " + packageName + ".HikariProxyResultSet($$);}");
/*     */           break;
/*     */         case "getProxyDatabaseMetaData":
/* 100 */           method.setBody("{return new " + packageName + ".HikariProxyDatabaseMetaData($$);}");
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 108 */     proxyCt.writeFile(genDirectory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> void generateProxyClass(Class<T> primaryInterface, String superClassName, String methodBody) throws Exception {
/* 116 */     String newClassName = superClassName.replaceAll("(.+)\\.(\\w+)", "$1.Hikari$2");
/*     */     
/* 118 */     CtClass superCt = classPool.getCtClass(superClassName);
/* 119 */     CtClass targetCt = classPool.makeClass(newClassName, superCt);
/* 120 */     targetCt.setModifiers(Modifier.setPublic(16));
/*     */     
/* 122 */     System.out.println("Generating " + newClassName);
/*     */ 
/*     */     
/* 125 */     HashSet<String> superSigs = new HashSet<>();
/* 126 */     for (CtMethod method : superCt.getMethods()) {
/* 127 */       if ((method.getModifiers() & 0x10) == 16) {
/* 128 */         superSigs.add(method.getName() + method.getName());
/*     */       }
/*     */     } 
/*     */     
/* 132 */     HashSet<String> methods = new HashSet<>();
/* 133 */     for (Class<?> intf : getAllInterfaces(primaryInterface)) {
/* 134 */       CtClass intfCt = classPool.getCtClass(intf.getName());
/* 135 */       targetCt.addInterface(intfCt);
/* 136 */       for (CtMethod intfMethod : intfCt.getDeclaredMethods()) {
/* 137 */         String signature = intfMethod.getName() + intfMethod.getName();
/*     */ 
/*     */         
/* 140 */         if (!superSigs.contains(signature))
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 145 */           if (!methods.contains(signature)) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 150 */             methods.add(signature);
/*     */ 
/*     */             
/* 153 */             CtMethod method = CtNewMethod.copy(intfMethod, targetCt, null);
/*     */             
/* 155 */             String modifiedBody = methodBody;
/*     */ 
/*     */             
/* 158 */             CtMethod superMethod = superCt.getMethod(intfMethod.getName(), intfMethod.getSignature());
/* 159 */             if ((superMethod.getModifiers() & 0x400) != 1024 && !isDefaultMethod(intf, intfMethod)) {
/* 160 */               modifiedBody = modifiedBody.replace("((cast) ", "");
/* 161 */               modifiedBody = modifiedBody.replace("delegate", "super");
/* 162 */               modifiedBody = modifiedBody.replace("super)", "super");
/*     */             } 
/*     */             
/* 165 */             modifiedBody = modifiedBody.replace("cast", primaryInterface.getName());
/*     */ 
/*     */             
/* 168 */             if (isThrowsSqlException(intfMethod)) {
/* 169 */               modifiedBody = modifiedBody.replace("method", method.getName());
/*     */             } else {
/*     */               
/* 172 */               modifiedBody = "{ return ((cast) delegate).method($$); }".replace("method", method.getName()).replace("cast", primaryInterface.getName());
/*     */             } 
/*     */             
/* 175 */             if (method.getReturnType() == CtClass.voidType) {
/* 176 */               modifiedBody = modifiedBody.replace("return", "");
/*     */             }
/*     */             
/* 179 */             method.setBody(modifiedBody);
/* 180 */             targetCt.addMethod(method);
/*     */           }  } 
/*     */       } 
/*     */     } 
/* 184 */     targetCt.getClassFile().setMajorVersion(52);
/* 185 */     targetCt.writeFile(genDirectory);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isThrowsSqlException(CtMethod method) {
/*     */     try {
/* 191 */       for (CtClass clazz : method.getExceptionTypes()) {
/* 192 */         if (clazz.getSimpleName().equals("SQLException")) {
/* 193 */           return true;
/*     */         }
/*     */       }
/*     */     
/* 197 */     } catch (NotFoundException notFoundException) {}
/*     */ 
/*     */ 
/*     */     
/* 201 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isDefaultMethod(Class<?> intf, CtMethod intfMethod) throws Exception {
/* 206 */     ArrayList<Class<?>> paramTypes = new ArrayList<>();
/*     */     
/* 208 */     for (CtClass pt : intfMethod.getParameterTypes()) {
/* 209 */       paramTypes.add(toJavaClass(pt));
/*     */     }
/*     */     
/* 212 */     return intf.getDeclaredMethod(intfMethod.getName(), (Class[])paramTypes.<Class<?>[]>toArray((Class<?>[][])new Class[0])).toString().contains("default ");
/*     */   }
/*     */ 
/*     */   
/*     */   private static Set<Class<?>> getAllInterfaces(Class<?> clazz) {
/* 217 */     LinkedHashSet<Class<?>> interfaces = new LinkedHashSet<>();
/* 218 */     for (Class<?> intf : clazz.getInterfaces()) {
/* 219 */       if ((intf.getInterfaces()).length > 0) {
/* 220 */         interfaces.addAll(getAllInterfaces(intf));
/*     */       }
/* 222 */       interfaces.add(intf);
/*     */     } 
/* 224 */     if (clazz.getSuperclass() != null) {
/* 225 */       interfaces.addAll(getAllInterfaces(clazz.getSuperclass()));
/*     */     }
/*     */     
/* 228 */     if (clazz.isInterface()) {
/* 229 */       interfaces.add(clazz);
/*     */     }
/*     */     
/* 232 */     return interfaces;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Class<?> toJavaClass(CtClass cls) throws Exception {
/* 237 */     if (cls.getName().endsWith("[]")) {
/* 238 */       return Array.newInstance(toJavaClass(cls.getName().replace("[]", "")), 0).getClass();
/*     */     }
/*     */     
/* 241 */     return toJavaClass(cls.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> toJavaClass(String cn) throws Exception {
/* 247 */     switch (cn) {
/*     */       case "int":
/* 249 */         return int.class;
/*     */       case "long":
/* 251 */         return long.class;
/*     */       case "short":
/* 253 */         return short.class;
/*     */       case "byte":
/* 255 */         return byte.class;
/*     */       case "float":
/* 257 */         return float.class;
/*     */       case "double":
/* 259 */         return double.class;
/*     */       case "boolean":
/* 261 */         return boolean.class;
/*     */       case "char":
/* 263 */         return char.class;
/*     */       case "void":
/* 265 */         return void.class;
/*     */     } 
/* 267 */     return Class.forName(cn);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikar\\util\JavassistProxyFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */