/*    */ package com.zaxxer.hikari.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum IsolationLevel
/*    */ {
/* 29 */   TRANSACTION_NONE(0),
/* 30 */   TRANSACTION_READ_UNCOMMITTED(1),
/* 31 */   TRANSACTION_READ_COMMITTED(2),
/* 32 */   TRANSACTION_CURSOR_STABILITY(3),
/* 33 */   TRANSACTION_REPEATABLE_READ(4),
/* 34 */   TRANSACTION_LAST_COMMITTED(5),
/* 35 */   TRANSACTION_SERIALIZABLE(8),
/* 36 */   TRANSACTION_SQL_SERVER_SNAPSHOT_ISOLATION_LEVEL(4096);
/*    */   
/*    */   private final int levelId;
/*    */   
/*    */   IsolationLevel(int levelId) {
/* 41 */     this.levelId = levelId;
/*    */   }
/*    */   
/*    */   public int getLevelId() {
/* 45 */     return this.levelId;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikar\\util\IsolationLevel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */