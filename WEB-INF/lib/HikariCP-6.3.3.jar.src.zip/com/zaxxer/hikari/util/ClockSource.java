/*     */ package com.zaxxer.hikari.util;
/*     */ 
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ClockSource
/*     */ {
/*  38 */   public static final ClockSource CLOCK = Factory.create();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long currentTime() {
/*  46 */     return CLOCK.currentTime0();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long currentTime0();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long toMillis(long time) {
/*  59 */     return CLOCK.toMillis0(time);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long toMillis0(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long toNanos(long time) {
/*  72 */     return CLOCK.toNanos0(time);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long toNanos0(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long elapsedMillis(long startTime) {
/*  85 */     return CLOCK.elapsedMillis0(startTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long elapsedMillis0(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long elapsedMillis(long startTime, long endTime) {
/*  99 */     return CLOCK.elapsedMillis0(startTime, endTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long elapsedMillis0(long paramLong1, long paramLong2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long elapsedNanos(long startTime) {
/* 112 */     return CLOCK.elapsedNanos0(startTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long elapsedNanos0(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long elapsedNanos(long startTime, long endTime) {
/* 126 */     return CLOCK.elapsedNanos0(startTime, endTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long elapsedNanos0(long paramLong1, long paramLong2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long plusMillis(long time, long millis) {
/* 139 */     return CLOCK.plusMillis0(time, millis);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long plusMillis0(long paramLong1, long paramLong2);
/*     */ 
/*     */ 
/*     */   
/*     */   static TimeUnit getSourceTimeUnit() {
/* 149 */     return CLOCK.getSourceTimeUnit0();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TimeUnit getSourceTimeUnit0();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String elapsedDisplayString(long startTime, long endTime) {
/* 162 */     return CLOCK.elapsedDisplayString0(startTime, endTime);
/*     */   }
/*     */   
/*     */   default String elapsedDisplayString0(long startTime, long endTime) {
/* 166 */     long elapsedNanos = elapsedNanos0(startTime, endTime);
/*     */     
/* 168 */     StringBuilder sb = new StringBuilder((elapsedNanos < 0L) ? "-" : "");
/* 169 */     elapsedNanos = Math.abs(elapsedNanos);
/*     */     
/* 171 */     for (TimeUnit unit : TIMEUNITS_DESCENDING) {
/* 172 */       long converted = unit.convert(elapsedNanos, TimeUnit.NANOSECONDS);
/* 173 */       if (converted > 0L) {
/* 174 */         sb.append(converted).append(TIMEUNIT_DISPLAY_VALUES[unit.ordinal()]);
/* 175 */         elapsedNanos -= TimeUnit.NANOSECONDS.convert(converted, unit);
/*     */       } 
/*     */     } 
/*     */     
/* 179 */     return sb.toString();
/*     */   }
/*     */   
/* 182 */   public static final TimeUnit[] TIMEUNITS_DESCENDING = new TimeUnit[] { TimeUnit.DAYS, TimeUnit.HOURS, TimeUnit.MINUTES, TimeUnit.SECONDS, TimeUnit.MILLISECONDS, TimeUnit.MICROSECONDS, TimeUnit.NANOSECONDS };
/*     */   
/* 184 */   public static final String[] TIMEUNIT_DISPLAY_VALUES = new String[] { "ns", "µs", "ms", "s", "m", "h", "d" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Factory
/*     */   {
/*     */     private static ClockSource create() {
/* 193 */       String os = System.getProperty("os.name");
/* 194 */       if ("Mac OS X".equals(os)) {
/* 195 */         return new ClockSource.MillisecondClockSource();
/*     */       }
/*     */       
/* 198 */       return new ClockSource.NanosecondClockSource();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class MillisecondClockSource
/*     */     implements ClockSource
/*     */   {
/*     */     public long currentTime0() {
/* 213 */       return System.currentTimeMillis();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long elapsedMillis0(long startTime) {
/* 219 */       return System.currentTimeMillis() - startTime;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long elapsedMillis0(long startTime, long endTime) {
/* 225 */       return endTime - startTime;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long elapsedNanos0(long startTime) {
/* 231 */       return TimeUnit.MILLISECONDS.toNanos(System.currentTimeMillis() - startTime);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long elapsedNanos0(long startTime, long endTime) {
/* 237 */       return TimeUnit.MILLISECONDS.toNanos(endTime - startTime);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long toMillis0(long time) {
/* 243 */       return time;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long toNanos0(long time) {
/* 249 */       return TimeUnit.MILLISECONDS.toNanos(time);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long plusMillis0(long time, long millis) {
/* 255 */       return time + millis;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TimeUnit getSourceTimeUnit0() {
/* 261 */       return TimeUnit.MILLISECONDS;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class NanosecondClockSource
/*     */     implements ClockSource
/*     */   {
/*     */     public long currentTime0() {
/* 275 */       return System.nanoTime();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long toMillis0(long time) {
/* 281 */       return TimeUnit.NANOSECONDS.toMillis(time);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long toNanos0(long time) {
/* 287 */       return time;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long elapsedMillis0(long startTime) {
/* 293 */       return TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTime);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long elapsedMillis0(long startTime, long endTime) {
/* 299 */       return TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long elapsedNanos0(long startTime) {
/* 305 */       return System.nanoTime() - startTime;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long elapsedNanos0(long startTime, long endTime) {
/* 311 */       return endTime - startTime;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long plusMillis0(long time, long millis) {
/* 317 */       return time + TimeUnit.MILLISECONDS.toNanos(millis);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TimeUnit getSourceTimeUnit0() {
/* 323 */       return TimeUnit.NANOSECONDS;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikar\\util\ClockSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */