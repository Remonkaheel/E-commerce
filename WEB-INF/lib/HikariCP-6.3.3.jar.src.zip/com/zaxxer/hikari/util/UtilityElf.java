/*     */ package com.zaxxer.hikari.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Arrays;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.IntStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UtilityElf
/*     */ {
/*  40 */   private static final Pattern PASSWORD_MASKING_PATTERN = Pattern.compile("([?&;][^&#;=]*[pP]assword=)[^&#;]*");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String maskPasswordInJdbcUrl(String jdbcUrl) {
/*  49 */     return PASSWORD_MASKING_PATTERN.matcher(jdbcUrl).replaceAll("$1<masked>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getNullIfEmpty(String text) {
/*  60 */     return (text == null) ? null : (text.trim().isEmpty() ? null : text.trim());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void quietlySleep(long millis) {
/*     */     try {
/*  71 */       Thread.sleep(millis);
/*     */     }
/*  73 */     catch (InterruptedException e) {
/*     */       
/*  75 */       Thread.currentThread().interrupt();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean safeIsAssignableFrom(Object obj, String className) {
/*     */     try {
/*  87 */       Class<?> clazz = Class.forName(className);
/*  88 */       return clazz.isAssignableFrom(obj.getClass());
/*  89 */     } catch (ClassNotFoundException ignored) {
/*  90 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T createInstance(String className, Class<T> clazz, Object... args) {
/* 106 */     if (className == null) {
/* 107 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 111 */       Class<?> loaded = UtilityElf.class.getClassLoader().loadClass(className);
/* 112 */       int totalArgs = args.length;
/*     */       
/* 114 */       if (totalArgs == 0) {
/* 115 */         return clazz.cast(loaded.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
/*     */       }
/*     */       
/* 118 */       Class<?>[] argClasses = new Class[totalArgs];
/* 119 */       for (int i = 0; i < totalArgs; i++) {
/* 120 */         argClasses[i] = args[i].getClass();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 132 */       Constructor<?> constructor = (Constructor)Arrays.<Constructor<?>>stream(loaded.getConstructors()).filter(c -> { if (c.getParameterCount() != totalArgs) return false;  Class<?>[] params = c.getParameterTypes(); return IntStream.range(0, totalArgs).allMatch(()); }).findFirst().orElseThrow(() -> new RuntimeException("No suitable constructor found for class " + className + " with arguments " + Arrays.toString(args)));
/*     */       
/* 134 */       return clazz.cast(constructor.newInstance(args));
/*     */     }
/* 136 */     catch (Exception e) {
/* 137 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ThreadPoolExecutor createThreadPoolExecutor(int queueSize, String threadName, ThreadFactory threadFactory, RejectedExecutionHandler policy) {
/* 152 */     return createThreadPoolExecutor(new LinkedBlockingQueue<>(queueSize), threadName, threadFactory, policy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ThreadPoolExecutor createThreadPoolExecutor(BlockingQueue<Runnable> queue, String threadName, ThreadFactory threadFactory, RejectedExecutionHandler policy) {
/* 166 */     if (threadFactory == null) {
/* 167 */       threadFactory = new DefaultThreadFactory(threadName);
/*     */     }
/*     */     
/* 170 */     ThreadPoolExecutor executor = new ThreadPoolExecutor(1, 1, 5L, TimeUnit.SECONDS, queue, threadFactory, policy);
/* 171 */     executor.allowCoreThreadTimeOut(true);
/* 172 */     return executor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getTransactionIsolation(String transactionIsolationName) {
/* 187 */     if (transactionIsolationName != null) {
/*     */       
/*     */       try {
/* 190 */         String upperCaseIsolationLevelName = transactionIsolationName.toUpperCase(Locale.ENGLISH);
/* 191 */         return IsolationLevel.valueOf(upperCaseIsolationLevelName).getLevelId();
/* 192 */       } catch (IllegalArgumentException e) {
/*     */         
/*     */         try {
/* 195 */           int level = Integer.parseInt(transactionIsolationName);
/* 196 */           for (IsolationLevel iso : IsolationLevel.values()) {
/* 197 */             if (iso.getLevelId() == level) {
/* 198 */               return iso.getLevelId();
/*     */             }
/*     */           } 
/*     */           
/* 202 */           throw new IllegalArgumentException("Invalid transaction isolation value: " + transactionIsolationName);
/*     */         }
/* 204 */         catch (NumberFormatException nfe) {
/* 205 */           throw new IllegalArgumentException("Invalid transaction isolation value: " + transactionIsolationName, nfe);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 210 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CustomDiscardPolicy
/*     */     implements RejectedExecutionHandler
/*     */   {
/*     */     public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class DefaultThreadFactory
/*     */     implements ThreadFactory
/*     */   {
/*     */     private final String threadName;
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean daemon;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DefaultThreadFactory(String threadName) {
/* 239 */       this.threadName = threadName;
/* 240 */       this.daemon = true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Thread newThread(Runnable r) {
/* 246 */       Thread thread = new Thread(r, this.threadName);
/* 247 */       thread.setDaemon(this.daemon);
/* 248 */       return thread;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikar\\util\UtilityElf.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */