/*    */ package com.zaxxer.hikari.util;
/*    */ 
/*    */ import javax.management.ConstructorParameters;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Credentials
/*    */ {
/*    */   private final String username;
/*    */   private final String password;
/*    */   
/*    */   public static Credentials of(String username, String password) {
/* 38 */     return new Credentials(username, password);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @ConstructorParameters({"username", "password"})
/*    */   public Credentials(String username, String password) {
/* 50 */     this.username = username;
/* 51 */     this.password = password;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUsername() {
/* 61 */     return this.username;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPassword() {
/* 71 */     return this.password;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikar\\util\Credentials.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */