/*      */ package com.zaxxer.hikari;
/*      */ 
/*      */ import com.zaxxer.hikari.metrics.MetricsTrackerFactory;
/*      */ import com.zaxxer.hikari.util.Credentials;
/*      */ import com.zaxxer.hikari.util.PropertyElf;
/*      */ import com.zaxxer.hikari.util.UtilityElf;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.security.AccessControlException;
/*      */ import java.util.Properties;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.ThreadLocalRandom;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import javax.naming.InitialContext;
/*      */ import javax.naming.NamingException;
/*      */ import javax.sql.DataSource;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HikariConfig
/*      */   implements HikariConfigMXBean
/*      */ {
/*   47 */   private static final Logger LOGGER = LoggerFactory.getLogger(HikariConfig.class);
/*      */   
/*   49 */   private static final char[] ID_CHARACTERS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
/*   50 */   private static final long CONNECTION_TIMEOUT = TimeUnit.SECONDS.toMillis(30L);
/*   51 */   private static final long VALIDATION_TIMEOUT = TimeUnit.SECONDS.toMillis(5L);
/*   52 */   private static final long SOFT_TIMEOUT_FLOOR = Long.getLong("com.zaxxer.hikari.timeoutMs.floor", 250L).longValue();
/*   53 */   private static final long IDLE_TIMEOUT = TimeUnit.MINUTES.toMillis(10L);
/*   54 */   private static final long MAX_LIFETIME = TimeUnit.MINUTES.toMillis(30L);
/*   55 */   private static final long DEFAULT_KEEPALIVE_TIME = TimeUnit.MINUTES.toMillis(2L);
/*      */   
/*      */   private static final int DEFAULT_POOL_SIZE = 10;
/*      */   
/*      */   private static boolean unitTest = false;
/*      */   
/*      */   private volatile String catalog;
/*      */   
/*      */   private volatile long connectionTimeout;
/*      */   private volatile long validationTimeout;
/*      */   private volatile long idleTimeout;
/*      */   private volatile long leakDetectionThreshold;
/*      */   private volatile long maxLifetime;
/*      */   private volatile int maxPoolSize;
/*      */   private volatile int minIdle;
/*   70 */   private final AtomicReference<Credentials> credentials = new AtomicReference<>(Credentials.of(null, null));
/*      */   
/*      */   private long initializationFailTimeout;
/*      */   
/*      */   private String connectionInitSql;
/*      */   
/*      */   private String connectionTestQuery;
/*      */   
/*      */   private String dataSourceClassName;
/*      */   
/*      */   private String dataSourceJndiName;
/*      */   
/*      */   private String driverClassName;
/*      */   
/*      */   private String exceptionOverrideClassName;
/*      */   
/*      */   private SQLExceptionOverride exceptionOverride;
/*      */   
/*      */   private String jdbcUrl;
/*      */   
/*      */   private String poolName;
/*      */   
/*      */   private String schema;
/*      */   
/*      */   private String transactionIsolationName;
/*      */   
/*      */   private boolean isAutoCommit;
/*      */   
/*      */   private boolean isReadOnly;
/*      */   
/*      */   private boolean isIsolateInternalQueries;
/*      */   private boolean isRegisterMbeans;
/*      */   private boolean isAllowPoolSuspension;
/*      */   private DataSource dataSource;
/*      */   private Properties dataSourceProperties;
/*      */   private ThreadFactory threadFactory;
/*      */   private ScheduledExecutorService scheduledExecutor;
/*      */   private MetricsTrackerFactory metricsTrackerFactory;
/*      */   private Object metricRegistry;
/*      */   private Object healthCheckRegistry;
/*      */   private Properties healthCheckProperties;
/*      */   private long keepaliveTime;
/*      */   private volatile boolean sealed;
/*      */   
/*      */   public HikariConfig() {
/*  115 */     this.dataSourceProperties = new Properties();
/*  116 */     this.healthCheckProperties = new Properties();
/*      */     
/*  118 */     this.minIdle = -1;
/*  119 */     this.maxPoolSize = 10;
/*  120 */     this.maxLifetime = MAX_LIFETIME;
/*  121 */     this.connectionTimeout = CONNECTION_TIMEOUT;
/*  122 */     this.validationTimeout = VALIDATION_TIMEOUT;
/*  123 */     this.idleTimeout = IDLE_TIMEOUT;
/*  124 */     this.initializationFailTimeout = 1L;
/*  125 */     this.isAutoCommit = true;
/*  126 */     this.keepaliveTime = DEFAULT_KEEPALIVE_TIME;
/*      */     
/*  128 */     String systemProp = System.getProperty("hikaricp.configurationFile");
/*  129 */     if (systemProp != null) {
/*  130 */       loadProperties(systemProp);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HikariConfig(Properties properties) {
/*  141 */     this();
/*  142 */     PropertyElf.setTargetFromProperties(this, properties);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HikariConfig(String propertyFileName) {
/*  154 */     this();
/*      */     
/*  156 */     loadProperties(propertyFileName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCatalog() {
/*  167 */     return this.catalog;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCatalog(String catalog) {
/*  174 */     this.catalog = catalog;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getConnectionTimeout() {
/*  182 */     return this.connectionTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnectionTimeout(long connectionTimeoutMs) {
/*  189 */     if (connectionTimeoutMs == 0L) {
/*  190 */       this.connectionTimeout = 2147483647L;
/*      */     } else {
/*  192 */       if (connectionTimeoutMs < SOFT_TIMEOUT_FLOOR) {
/*  193 */         throw new IllegalArgumentException("connectionTimeout cannot be less than " + SOFT_TIMEOUT_FLOOR + "ms");
/*      */       }
/*      */       
/*  196 */       this.connectionTimeout = connectionTimeoutMs;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getIdleTimeout() {
/*  204 */     return this.idleTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIdleTimeout(long idleTimeoutMs) {
/*  211 */     if (idleTimeoutMs < 0L) {
/*  212 */       throw new IllegalArgumentException("idleTimeout cannot be negative");
/*      */     }
/*  214 */     this.idleTimeout = idleTimeoutMs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLeakDetectionThreshold() {
/*  221 */     return this.leakDetectionThreshold;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLeakDetectionThreshold(long leakDetectionThresholdMs) {
/*  228 */     this.leakDetectionThreshold = leakDetectionThresholdMs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getMaxLifetime() {
/*  235 */     return this.maxLifetime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxLifetime(long maxLifetimeMs) {
/*  242 */     this.maxLifetime = maxLifetimeMs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaximumPoolSize() {
/*  249 */     return this.maxPoolSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaximumPoolSize(int maxPoolSize) {
/*  256 */     if (maxPoolSize < 1) {
/*  257 */       throw new IllegalArgumentException("maxPoolSize cannot be less than 1");
/*      */     }
/*  259 */     this.maxPoolSize = maxPoolSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMinimumIdle() {
/*  266 */     return this.minIdle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMinimumIdle(int minIdle) {
/*  273 */     if (minIdle < 0) {
/*  274 */       throw new IllegalArgumentException("minimumIdle cannot be negative");
/*      */     }
/*  276 */     this.minIdle = minIdle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPassword() {
/*  285 */     return ((Credentials)this.credentials.get()).getPassword();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPassword(String password) {
/*  295 */     this.credentials.updateAndGet(current -> Credentials.of(current.getUsername(), password));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUsername() {
/*  305 */     return ((Credentials)this.credentials.get()).getUsername();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUsername(String username) {
/*  316 */     this.credentials.updateAndGet(current -> Credentials.of(username, current.getPassword()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCredentials(Credentials credentials) {
/*  327 */     this.credentials.set(credentials);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Credentials getCredentials() {
/*  337 */     return this.credentials.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getValidationTimeout() {
/*  344 */     return this.validationTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValidationTimeout(long validationTimeoutMs) {
/*  351 */     if (validationTimeoutMs < SOFT_TIMEOUT_FLOOR) {
/*  352 */       throw new IllegalArgumentException("validationTimeout cannot be less than " + SOFT_TIMEOUT_FLOOR + "ms");
/*      */     }
/*      */     
/*  355 */     this.validationTimeout = validationTimeoutMs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getConnectionTestQuery() {
/*  369 */     return this.connectionTestQuery;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnectionTestQuery(String connectionTestQuery) {
/*  381 */     checkIfSealed();
/*  382 */     this.connectionTestQuery = connectionTestQuery;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getConnectionInitSql() {
/*  393 */     return this.connectionInitSql;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnectionInitSql(String connectionInitSql) {
/*  405 */     checkIfSealed();
/*  406 */     this.connectionInitSql = connectionInitSql;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataSource getDataSource() {
/*  417 */     return this.dataSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDataSource(DataSource dataSource) {
/*  428 */     checkIfSealed();
/*  429 */     this.dataSource = dataSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDataSourceClassName() {
/*  439 */     return this.dataSourceClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDataSourceClassName(String className) {
/*  449 */     checkIfSealed();
/*  450 */     this.dataSourceClassName = className;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDataSourceProperty(String propertyName, Object value) {
/*  468 */     checkIfSealed();
/*  469 */     this.dataSourceProperties.put(propertyName, value);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDataSourceJNDI() {
/*  474 */     return this.dataSourceJndiName;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDataSourceJNDI(String jndiDataSource) {
/*  479 */     checkIfSealed();
/*  480 */     this.dataSourceJndiName = jndiDataSource;
/*      */   }
/*      */ 
/*      */   
/*      */   public Properties getDataSourceProperties() {
/*  485 */     return this.dataSourceProperties;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDataSourceProperties(Properties dsProperties) {
/*  490 */     checkIfSealed();
/*  491 */     this.dataSourceProperties.putAll(dsProperties);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDriverClassName() {
/*  496 */     return this.driverClassName;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDriverClassName(String driverClassName) {
/*  501 */     checkIfSealed();
/*      */     
/*  503 */     Class<?> driverClass = attemptFromContextLoader(driverClassName);
/*      */     try {
/*  505 */       if (driverClass == null) {
/*  506 */         driverClass = getClass().getClassLoader().loadClass(driverClassName);
/*  507 */         LOGGER.debug("Driver class {} found in the HikariConfig class classloader {}", driverClassName, getClass().getClassLoader());
/*      */       } 
/*  509 */     } catch (ClassNotFoundException e) {
/*  510 */       LOGGER.error("Failed to load driver class {} from HikariConfig class classloader {}", driverClassName, getClass().getClassLoader());
/*      */     } 
/*      */     
/*  513 */     if (driverClass == null) {
/*  514 */       throw new RuntimeException("Failed to load driver class " + driverClassName + " in either of HikariConfig class loader or Thread context classloader");
/*      */     }
/*      */     
/*      */     try {
/*  518 */       driverClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*  519 */       this.driverClassName = driverClassName;
/*      */     }
/*  521 */     catch (Exception e) {
/*  522 */       throw new RuntimeException("Failed to instantiate class " + driverClassName, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String getJdbcUrl() {
/*  528 */     return this.jdbcUrl;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setJdbcUrl(String jdbcUrl) {
/*  533 */     checkIfSealed();
/*  534 */     this.jdbcUrl = jdbcUrl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAutoCommit() {
/*  544 */     return this.isAutoCommit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoCommit(boolean isAutoCommit) {
/*  554 */     checkIfSealed();
/*  555 */     this.isAutoCommit = isAutoCommit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAllowPoolSuspension() {
/*  565 */     return this.isAllowPoolSuspension;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowPoolSuspension(boolean isAllowPoolSuspension) {
/*  577 */     checkIfSealed();
/*  578 */     this.isAllowPoolSuspension = isAllowPoolSuspension;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getInitializationFailTimeout() {
/*  590 */     return this.initializationFailTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInitializationFailTimeout(long initializationFailTimeout) {
/*  628 */     checkIfSealed();
/*  629 */     this.initializationFailTimeout = initializationFailTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIsolateInternalQueries() {
/*  640 */     return this.isIsolateInternalQueries;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIsolateInternalQueries(boolean isolate) {
/*  651 */     checkIfSealed();
/*  652 */     this.isIsolateInternalQueries = isolate;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetricsTrackerFactory getMetricsTrackerFactory() {
/*  657 */     return this.metricsTrackerFactory;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMetricsTrackerFactory(MetricsTrackerFactory metricsTrackerFactory) {
/*  662 */     if (this.metricRegistry != null) {
/*  663 */       throw new IllegalStateException("cannot use setMetricsTrackerFactory() and setMetricRegistry() together");
/*      */     }
/*      */     
/*  666 */     this.metricsTrackerFactory = metricsTrackerFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getMetricRegistry() {
/*  676 */     return this.metricRegistry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMetricRegistry(Object metricRegistry) {
/*  686 */     if (this.metricsTrackerFactory != null) {
/*  687 */       throw new IllegalStateException("cannot use setMetricRegistry() and setMetricsTrackerFactory() together");
/*      */     }
/*      */     
/*  690 */     if (metricRegistry != null) {
/*  691 */       metricRegistry = getObjectOrPerformJndiLookup(metricRegistry);
/*      */       
/*  693 */       if (!UtilityElf.safeIsAssignableFrom(metricRegistry, "com.codahale.metrics.MetricRegistry") && 
/*  694 */         !UtilityElf.safeIsAssignableFrom(metricRegistry, "io.dropwizard.metrics5.MetricRegistry") && 
/*  695 */         !UtilityElf.safeIsAssignableFrom(metricRegistry, "io.micrometer.core.instrument.MeterRegistry")) {
/*  696 */         throw new IllegalArgumentException("Class must be instance of com.codahale.metrics.MetricRegistry, io.dropwizard.metrics5.MetricRegistry, or io.micrometer.core.instrument.MeterRegistry");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  701 */     this.metricRegistry = metricRegistry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getHealthCheckRegistry() {
/*  712 */     return this.healthCheckRegistry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHealthCheckRegistry(Object healthCheckRegistry) {
/*  723 */     checkIfSealed();
/*      */     
/*  725 */     if (healthCheckRegistry != null) {
/*  726 */       healthCheckRegistry = getObjectOrPerformJndiLookup(healthCheckRegistry);
/*      */       
/*  728 */       if (!(healthCheckRegistry instanceof com.codahale.metrics.health.HealthCheckRegistry)) {
/*  729 */         throw new IllegalArgumentException("Class must be an instance of com.codahale.metrics.health.HealthCheckRegistry");
/*      */       }
/*      */     } 
/*      */     
/*  733 */     this.healthCheckRegistry = healthCheckRegistry;
/*      */   }
/*      */ 
/*      */   
/*      */   public Properties getHealthCheckProperties() {
/*  738 */     return this.healthCheckProperties;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setHealthCheckProperties(Properties healthCheckProperties) {
/*  743 */     checkIfSealed();
/*  744 */     this.healthCheckProperties.putAll(healthCheckProperties);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addHealthCheckProperty(String key, String value) {
/*  749 */     checkIfSealed();
/*  750 */     this.healthCheckProperties.setProperty(key, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getKeepaliveTime() {
/*  760 */     return this.keepaliveTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeepaliveTime(long keepaliveTimeMs) {
/*  770 */     this.keepaliveTime = keepaliveTimeMs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReadOnly() {
/*  780 */     return this.isReadOnly;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReadOnly(boolean readOnly) {
/*  790 */     checkIfSealed();
/*  791 */     this.isReadOnly = readOnly;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRegisterMbeans() {
/*  802 */     return this.isRegisterMbeans;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRegisterMbeans(boolean register) {
/*  812 */     checkIfSealed();
/*  813 */     this.isRegisterMbeans = register;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPoolName() {
/*  820 */     return this.poolName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPoolName(String poolName) {
/*  831 */     checkIfSealed();
/*  832 */     this.poolName = poolName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ScheduledExecutorService getScheduledExecutor() {
/*  842 */     return this.scheduledExecutor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setScheduledExecutor(ScheduledExecutorService executor) {
/*  852 */     checkIfSealed();
/*  853 */     this.scheduledExecutor = executor;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getTransactionIsolation() {
/*  858 */     return this.transactionIsolationName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSchema() {
/*  868 */     return this.schema;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSchema(String schema) {
/*  878 */     checkIfSealed();
/*  879 */     this.schema = schema;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getExceptionOverrideClassName() {
/*  890 */     return this.exceptionOverrideClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExceptionOverrideClassName(String exceptionOverrideClassName) {
/*  901 */     checkIfSealed();
/*      */     
/*  903 */     Class<?> overrideClass = attemptFromContextLoader(exceptionOverrideClassName);
/*      */     try {
/*  905 */       if (overrideClass == null) {
/*  906 */         overrideClass = getClass().getClassLoader().loadClass(exceptionOverrideClassName);
/*  907 */         LOGGER.debug("SQLExceptionOverride class {} found in the HikariConfig class classloader {}", exceptionOverrideClassName, getClass().getClassLoader());
/*      */       } 
/*  909 */     } catch (ClassNotFoundException e) {
/*  910 */       LOGGER.error("Failed to load SQLExceptionOverride class {} from HikariConfig class classloader {}", exceptionOverrideClassName, getClass().getClassLoader());
/*      */     } 
/*      */     
/*  913 */     if (overrideClass == null) {
/*  914 */       throw new RuntimeException("Failed to load SQLExceptionOverride class " + exceptionOverrideClassName + " in either of HikariConfig class loader or Thread context classloader");
/*      */     }
/*      */     
/*  917 */     if (!SQLExceptionOverride.class.isAssignableFrom(overrideClass)) {
/*  918 */       throw new RuntimeException("Loaded SQLExceptionOverride class " + exceptionOverrideClassName + " does not implement " + SQLExceptionOverride.class.getName());
/*      */     }
/*      */     
/*      */     try {
/*  922 */       this.exceptionOverride = overrideClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*  923 */       this.exceptionOverrideClassName = exceptionOverrideClassName;
/*      */     }
/*  925 */     catch (Exception e) {
/*  926 */       throw new RuntimeException("Failed to instantiate class " + exceptionOverrideClassName, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLExceptionOverride getExceptionOverride() {
/*  939 */     return this.exceptionOverride;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExceptionOverride(SQLExceptionOverride exceptionOverride) {
/*  949 */     checkIfSealed();
/*  950 */     this.exceptionOverride = exceptionOverride;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionIsolation(String isolationLevel) {
/*  962 */     checkIfSealed();
/*  963 */     this.transactionIsolationName = isolationLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ThreadFactory getThreadFactory() {
/*  973 */     return this.threadFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setThreadFactory(ThreadFactory threadFactory) {
/*  983 */     checkIfSealed();
/*  984 */     this.threadFactory = threadFactory;
/*      */   }
/*      */ 
/*      */   
/*      */   void seal() {
/*  989 */     this.sealed = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyStateTo(HikariConfig other) {
/* 1000 */     for (Field field : HikariConfig.class.getDeclaredFields()) {
/*      */       try {
/* 1002 */         if (!Modifier.isFinal(field.getModifiers())) {
/* 1003 */           field.setAccessible(true);
/* 1004 */           field.set(other, field.get(this));
/* 1005 */         } else if (field.getType().isAssignableFrom(AtomicReference.class)) {
/* 1006 */           ((AtomicReference)field.get(other)).set(((AtomicReference)field.get(this)).get());
/*      */         }
/*      */       
/* 1009 */       } catch (Exception e) {
/* 1010 */         throw new RuntimeException("Failed to copy HikariConfig state: " + e.getMessage(), e);
/*      */       } 
/*      */     } 
/*      */     
/* 1014 */     other.sealed = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Class<?> attemptFromContextLoader(String className) {
/* 1022 */     ClassLoader threadContextClassLoader = Thread.currentThread().getContextClassLoader();
/* 1023 */     if (threadContextClassLoader != null) {
/*      */       try {
/* 1025 */         Class<?> driverClass = threadContextClassLoader.loadClass(className);
/* 1026 */         LOGGER.debug("Class {} found in Thread context class loader {}", className, threadContextClassLoader);
/* 1027 */         return driverClass;
/* 1028 */       } catch (ClassNotFoundException e) {
/* 1029 */         LOGGER.debug("Class {} not found in Thread context class loader {}, trying classloader {}", new Object[] { this.driverClassName, threadContextClassLoader, 
/* 1030 */               getClass().getClassLoader() });
/*      */       } 
/*      */     }
/*      */     
/* 1034 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void validate() {
/* 1040 */     if (this.poolName == null) {
/* 1041 */       this.poolName = generatePoolName();
/*      */     }
/* 1043 */     else if (this.isRegisterMbeans && this.poolName.contains(":")) {
/* 1044 */       throw new IllegalArgumentException("poolName cannot contain ':' when used with JMX");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1049 */     this.catalog = UtilityElf.getNullIfEmpty(this.catalog);
/* 1050 */     this.connectionInitSql = UtilityElf.getNullIfEmpty(this.connectionInitSql);
/* 1051 */     this.connectionTestQuery = UtilityElf.getNullIfEmpty(this.connectionTestQuery);
/* 1052 */     this.transactionIsolationName = UtilityElf.getNullIfEmpty(this.transactionIsolationName);
/* 1053 */     this.dataSourceClassName = UtilityElf.getNullIfEmpty(this.dataSourceClassName);
/* 1054 */     this.dataSourceJndiName = UtilityElf.getNullIfEmpty(this.dataSourceJndiName);
/* 1055 */     this.driverClassName = UtilityElf.getNullIfEmpty(this.driverClassName);
/* 1056 */     this.jdbcUrl = UtilityElf.getNullIfEmpty(this.jdbcUrl);
/*      */ 
/*      */     
/* 1059 */     if (this.dataSource != null) {
/* 1060 */       if (this.dataSourceClassName != null) {
/* 1061 */         LOGGER.warn("{} - using dataSource and ignoring dataSourceClassName.", this.poolName);
/*      */       }
/*      */     }
/* 1064 */     else if (this.dataSourceClassName != null) {
/* 1065 */       if (this.driverClassName != null) {
/* 1066 */         LOGGER.error("{} - cannot use driverClassName and dataSourceClassName together.", this.poolName);
/*      */ 
/*      */         
/* 1069 */         throw new IllegalStateException("cannot use driverClassName and dataSourceClassName together.");
/*      */       } 
/* 1071 */       if (this.jdbcUrl != null) {
/* 1072 */         LOGGER.warn("{} - using dataSourceClassName and ignoring jdbcUrl.", this.poolName);
/*      */       }
/*      */     }
/* 1075 */     else if (this.jdbcUrl == null && this.dataSourceJndiName == null) {
/*      */ 
/*      */       
/* 1078 */       if (this.driverClassName != null) {
/* 1079 */         LOGGER.error("{} - jdbcUrl is required with driverClassName.", this.poolName);
/* 1080 */         throw new IllegalArgumentException("jdbcUrl is required with driverClassName.");
/*      */       } 
/*      */       
/* 1083 */       LOGGER.error("{} - dataSource or dataSourceClassName or jdbcUrl is required.", this.poolName);
/* 1084 */       throw new IllegalArgumentException("dataSource or dataSourceClassName or jdbcUrl is required.");
/*      */     } 
/*      */     
/* 1087 */     validateNumerics();
/*      */     
/* 1089 */     if (LOGGER.isDebugEnabled() || unitTest) {
/* 1090 */       logConfiguration();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void validateNumerics() {
/* 1096 */     if (this.maxLifetime != 0L && this.maxLifetime < TimeUnit.SECONDS.toMillis(30L)) {
/* 1097 */       LOGGER.warn("{} - maxLifetime is less than 30000ms, setting to default {}ms.", this.poolName, Long.valueOf(MAX_LIFETIME));
/* 1098 */       this.maxLifetime = MAX_LIFETIME;
/*      */     } 
/*      */ 
/*      */     
/* 1102 */     if (this.keepaliveTime != 0L && this.keepaliveTime < TimeUnit.SECONDS.toMillis(30L)) {
/* 1103 */       LOGGER.warn("{} - keepaliveTime is less than 30000ms, disabling it.", this.poolName);
/* 1104 */       this.keepaliveTime = 0L;
/*      */     } 
/*      */ 
/*      */     
/* 1108 */     if (this.keepaliveTime != 0L && this.maxLifetime != 0L && this.keepaliveTime >= this.maxLifetime) {
/* 1109 */       LOGGER.warn("{} - keepaliveTime is greater than or equal to maxLifetime, disabling it.", this.poolName);
/* 1110 */       this.keepaliveTime = 0L;
/*      */     } 
/*      */     
/* 1113 */     if (this.leakDetectionThreshold > 0L && !unitTest && (
/* 1114 */       this.leakDetectionThreshold < TimeUnit.SECONDS.toMillis(2L) || (this.leakDetectionThreshold > this.maxLifetime && this.maxLifetime > 0L))) {
/* 1115 */       LOGGER.warn("{} - leakDetectionThreshold is less than 2000ms or more than maxLifetime, disabling it.", this.poolName);
/* 1116 */       this.leakDetectionThreshold = 0L;
/*      */     } 
/*      */ 
/*      */     
/* 1120 */     if (this.connectionTimeout < SOFT_TIMEOUT_FLOOR) {
/* 1121 */       LOGGER.warn("{} - connectionTimeout is less than {}ms, setting to {}ms.", new Object[] { this.poolName, Long.valueOf(SOFT_TIMEOUT_FLOOR), Long.valueOf(CONNECTION_TIMEOUT) });
/* 1122 */       this.connectionTimeout = CONNECTION_TIMEOUT;
/*      */     } 
/*      */     
/* 1125 */     if (this.validationTimeout < SOFT_TIMEOUT_FLOOR) {
/* 1126 */       LOGGER.warn("{} - validationTimeout is less than {}ms, setting to {}ms.", new Object[] { this.poolName, Long.valueOf(SOFT_TIMEOUT_FLOOR), Long.valueOf(VALIDATION_TIMEOUT) });
/* 1127 */       this.validationTimeout = VALIDATION_TIMEOUT;
/*      */     } 
/*      */     
/* 1130 */     if (this.minIdle < 0 || this.minIdle > this.maxPoolSize) {
/* 1131 */       this.minIdle = this.maxPoolSize;
/*      */     }
/*      */     
/* 1134 */     if (this.idleTimeout + TimeUnit.SECONDS.toMillis(1L) > this.maxLifetime && this.maxLifetime > 0L && this.minIdle < this.maxPoolSize) {
/* 1135 */       LOGGER.warn("{} - idleTimeout is close to or more than maxLifetime, disabling it.", this.poolName);
/* 1136 */       this.idleTimeout = 0L;
/*      */     }
/* 1138 */     else if (this.idleTimeout != 0L && this.idleTimeout < TimeUnit.SECONDS.toMillis(10L) && this.minIdle < this.maxPoolSize) {
/* 1139 */       LOGGER.warn("{} - idleTimeout is less than 10000ms, setting to default {}ms.", this.poolName, Long.valueOf(IDLE_TIMEOUT));
/* 1140 */       this.idleTimeout = IDLE_TIMEOUT;
/*      */     }
/* 1142 */     else if (this.idleTimeout != IDLE_TIMEOUT && this.idleTimeout != 0L && this.minIdle == this.maxPoolSize) {
/* 1143 */       LOGGER.warn("{} - idleTimeout has been set but has no effect because the pool is operating as a fixed size pool.", this.poolName);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkIfSealed() {
/* 1149 */     if (this.sealed) throw new IllegalStateException("The configuration of the pool is sealed once started. Use HikariConfigMXBean for runtime changes.");
/*      */   
/*      */   }
/*      */   
/*      */   private void logConfiguration() {
/* 1154 */     LOGGER.debug("{} - configuration:", this.poolName);
/* 1155 */     TreeSet<String> propertyNames = new TreeSet<>(PropertyElf.getPropertyNames(HikariConfig.class));
/* 1156 */     for (String prop : propertyNames) {
/*      */       try {
/* 1158 */         Object value = PropertyElf.getProperty(prop, this);
/* 1159 */         if ("dataSourceProperties".equals(prop)) {
/* 1160 */           Properties dsProps = PropertyElf.copyProperties(this.dataSourceProperties);
/* 1161 */           dsProps.setProperty("password", "<masked>");
/* 1162 */           value = dsProps;
/*      */         } 
/*      */         
/* 1165 */         if ("initializationFailTimeout".equals(prop) && this.initializationFailTimeout == Long.MAX_VALUE) {
/* 1166 */           value = "infinite";
/*      */         }
/* 1168 */         else if ("transactionIsolation".equals(prop) && this.transactionIsolationName == null) {
/* 1169 */           value = "default";
/*      */         }
/* 1171 */         else if (prop.matches("scheduledExecutorService|threadFactory") && value == null) {
/* 1172 */           value = "internal";
/*      */         }
/* 1174 */         else if (prop.contains("jdbcUrl") && value instanceof String) {
/* 1175 */           value = UtilityElf.maskPasswordInJdbcUrl((String)value);
/*      */         }
/* 1177 */         else if (prop.contains("password")) {
/* 1178 */           value = "<masked>";
/*      */         }
/* 1180 */         else if (value instanceof String) {
/* 1181 */           value = "\"" + value + "\"";
/*      */         }
/* 1183 */         else if (value == null) {
/* 1184 */           value = "none";
/*      */         } 
/* 1186 */         LOGGER.debug("{}{}", (prop + "................................................").substring(0, 32), value);
/*      */       }
/* 1188 */       catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadProperties(String propertyFileName) {
/*      */     
/* 1196 */     try { InputStream is = openPropertiesInputStream(propertyFileName); 
/* 1197 */       try { if (is != null) {
/* 1198 */           Properties props = new Properties();
/* 1199 */           props.load(is);
/* 1200 */           PropertyElf.setTargetFromProperties(this, props);
/*      */         } else {
/*      */           
/* 1203 */           throw new IllegalArgumentException("Cannot find property file: " + propertyFileName);
/*      */         } 
/* 1205 */         if (is != null) is.close();  } catch (Throwable throwable) { if (is != null)
/* 1206 */           try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException io)
/* 1207 */     { throw new RuntimeException("Failed to read property file", io); }
/*      */   
/*      */   }
/*      */   
/*      */   private InputStream openPropertiesInputStream(String propertyFileName) throws FileNotFoundException {
/* 1212 */     File propFile = new File(propertyFileName);
/* 1213 */     if (propFile.isFile()) {
/* 1214 */       return new FileInputStream(propFile);
/*      */     }
/* 1216 */     InputStream propertiesInputStream = getClass().getResourceAsStream(propertyFileName);
/* 1217 */     if (propertiesInputStream == null) {
/* 1218 */       propertiesInputStream = getClass().getClassLoader().getResourceAsStream(propertyFileName);
/*      */     }
/* 1220 */     return propertiesInputStream;
/*      */   }
/*      */ 
/*      */   
/*      */   private String generatePoolName() {
/* 1225 */     String prefix = "HikariPool-";
/*      */     
/*      */     try {
/* 1228 */       synchronized (System.getProperties()) {
/* 1229 */         String next = String.valueOf(Integer.getInteger("com.zaxxer.hikari.pool_number", 0).intValue() + 1);
/* 1230 */         System.setProperty("com.zaxxer.hikari.pool_number", next);
/* 1231 */         return "HikariPool-" + next;
/*      */       } 
/* 1233 */     } catch (AccessControlException e) {
/*      */ 
/*      */       
/* 1236 */       ThreadLocalRandom random = ThreadLocalRandom.current();
/* 1237 */       StringBuilder buf = new StringBuilder("HikariPool-");
/*      */       
/* 1239 */       for (int i = 0; i < 4; i++) {
/* 1240 */         buf.append(ID_CHARACTERS[random.nextInt(62)]);
/*      */       }
/*      */       
/* 1243 */       LOGGER.info("assigned random pool name '{}' (security manager prevented access to system properties)", buf);
/*      */       
/* 1245 */       return buf.toString();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private Object getObjectOrPerformJndiLookup(Object object) {
/* 1251 */     if (object instanceof String) {
/*      */       try {
/* 1253 */         InitialContext initCtx = new InitialContext();
/* 1254 */         return initCtx.lookup((String)object);
/*      */       }
/* 1256 */       catch (NamingException e) {
/* 1257 */         throw new IllegalArgumentException(e);
/*      */       } 
/*      */     }
/* 1260 */     return object;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikari\HikariConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */