/*     */ package com.zaxxer.hikari.pool;
/*     */ 
/*     */ import com.zaxxer.hikari.HikariConfig;
/*     */ import com.zaxxer.hikari.SQLExceptionOverride;
/*     */ import com.zaxxer.hikari.metrics.IMetricsTracker;
/*     */ import com.zaxxer.hikari.util.ClockSource;
/*     */ import com.zaxxer.hikari.util.Credentials;
/*     */ import com.zaxxer.hikari.util.DriverDataSource;
/*     */ import com.zaxxer.hikari.util.PropertyElf;
/*     */ import com.zaxxer.hikari.util.UtilityElf;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLTransientConnectionException;
/*     */ import java.sql.Statement;
/*     */ import java.util.Properties;
/*     */ import java.util.StringJoiner;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.sql.DataSource;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class PoolBase
/*     */ {
/*  55 */   private final Logger logger = LoggerFactory.getLogger(PoolBase.class);
/*     */   
/*     */   public final HikariConfig config;
/*     */   
/*     */   IMetricsTrackerDelegate metricsTracker;
/*     */   
/*     */   protected final String poolName;
/*     */   
/*     */   volatile String catalog;
/*     */   
/*     */   final AtomicReference<Throwable> lastConnectionFailure;
/*     */   
/*     */   final AtomicLong connectionFailureTimestamp;
/*     */   long connectionTimeout;
/*     */   long validationTimeout;
/*     */   SQLExceptionOverride exceptionOverride;
/*  71 */   private static final String[] RESET_STATES = new String[] { "readOnly", "autoCommit", "isolation", "catalog", "netTimeout", "schema" };
/*     */   private static final int UNINITIALIZED = -1;
/*     */   private static final int TRUE = 1;
/*     */   private static final int FALSE = 0;
/*  75 */   private static final int MINIMUM_LOGIN_TIMEOUT = Integer.getInteger("com.zaxxer.hikari.minimumLoginTimeoutSecs", 1).intValue();
/*  76 */   private static final boolean LEGACY_USERPASS_DS_OVERRIDE = Boolean.getBoolean("com.zaxxer.hikari.legacy.supportUserPassDataSourceOverride");
/*     */   
/*     */   private int networkTimeout;
/*     */   
/*     */   private volatile int isNetworkTimeoutSupported;
/*     */   
/*     */   private int isQueryTimeoutSupported;
/*     */   
/*     */   private int defaultTransactionIsolation;
/*     */   
/*     */   private int transactionIsolation;
/*     */   private Executor netTimeoutExecutor;
/*     */   private DataSource dataSource;
/*     */   private final String schema;
/*     */   private final boolean isReadOnly;
/*     */   private final boolean isAutoCommit;
/*     */   private final boolean isUseJdbc4Validation;
/*     */   private final boolean isIsolateInternalQueries;
/*     */   private volatile boolean isValidChecked;
/*     */   
/*     */   PoolBase(HikariConfig config) {
/*  97 */     this.config = config;
/*     */     
/*  99 */     this.networkTimeout = -1;
/* 100 */     this.catalog = config.getCatalog();
/* 101 */     this.schema = config.getSchema();
/* 102 */     this.isReadOnly = config.isReadOnly();
/* 103 */     this.isAutoCommit = config.isAutoCommit();
/* 104 */     this.exceptionOverride = config.getExceptionOverride();
/* 105 */     this.transactionIsolation = UtilityElf.getTransactionIsolation(config.getTransactionIsolation());
/*     */     
/* 107 */     this.isQueryTimeoutSupported = -1;
/* 108 */     this.isNetworkTimeoutSupported = -1;
/* 109 */     this.isUseJdbc4Validation = (config.getConnectionTestQuery() == null);
/* 110 */     this.isIsolateInternalQueries = config.isIsolateInternalQueries();
/*     */     
/* 112 */     this.poolName = config.getPoolName();
/* 113 */     this.connectionTimeout = config.getConnectionTimeout();
/* 114 */     this.validationTimeout = config.getValidationTimeout();
/* 115 */     this.lastConnectionFailure = new AtomicReference<>();
/* 116 */     this.connectionFailureTimestamp = new AtomicLong();
/*     */     
/* 118 */     initializeDataSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 125 */     return this.poolName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void recycle(PoolEntry paramPoolEntry);
/*     */ 
/*     */ 
/*     */   
/*     */   void quietlyCloseConnection(Connection connection, String closureReason) {
/* 136 */     if (connection != null) {
/*     */       try {
/* 138 */         this.logger.debug("{} - Closing connection {}: {}", new Object[] { this.poolName, connection, closureReason });
/*     */ 
/*     */         
/* 141 */         try { Connection connection1 = connection; 
/* 142 */           try { if (!connection.isClosed())
/* 143 */               setNetworkTimeout(connection, TimeUnit.SECONDS.toMillis(15L)); 
/* 144 */             if (connection1 != null) connection1.close();  } catch (Throwable throwable) { if (connection1 != null) try { connection1.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException sQLException) {}
/*     */ 
/*     */       
/*     */       }
/* 148 */       catch (Exception e) {
/* 149 */         this.logger.debug("{} - Closing connection {} failed", new Object[] { this.poolName, connection, e });
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isConnectionDead(Connection connection) {
/*     */     try {
/* 157 */       setNetworkTimeout(connection, this.validationTimeout);
/*     */       
/* 159 */       try { int validationSeconds = (int)Math.max(1000L, this.validationTimeout) / 1000;
/*     */         
/* 161 */         if (this.isUseJdbc4Validation) {
/* 162 */           return !connection.isValid(validationSeconds);
/*     */         }
/*     */         
/* 165 */         Statement statement = connection.createStatement(); 
/* 166 */         try { if (this.isNetworkTimeoutSupported != 1) {
/* 167 */             setQueryTimeout(statement, validationSeconds);
/*     */           }
/*     */           
/* 170 */           statement.execute(this.config.getConnectionTestQuery());
/* 171 */           if (statement != null) statement.close();  } catch (Throwable throwable) { if (statement != null)
/*     */             try { statement.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/*     */          }
/* 174 */       finally { setNetworkTimeout(connection, this.networkTimeout);
/*     */         
/* 176 */         if (this.isIsolateInternalQueries && !this.isAutoCommit) {
/* 177 */           connection.rollback();
/*     */         } }
/*     */ 
/*     */       
/* 181 */       return false;
/*     */     }
/* 183 */     catch (Exception e) {
/* 184 */       this.lastConnectionFailure.set(e);
/* 185 */       this.logger.warn("{} - Failed to validate connection {} ({}). Possibly consider using a shorter maxLifetime value.", new Object[] { this.poolName, connection, e
/* 186 */             .getMessage() });
/* 187 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   Throwable getLastConnectionFailure() {
/* 193 */     return this.lastConnectionFailure.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public DataSource getUnwrappedDataSource() {
/* 198 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PoolEntry newPoolEntry(boolean isEmptyPool) throws Exception {
/* 207 */     return new PoolEntry(newConnection(isEmptyPool), this, this.isReadOnly, this.isAutoCommit);
/*     */   }
/*     */ 
/*     */   
/*     */   void resetConnectionState(Connection connection, ProxyConnection proxyConnection, int dirtyBits) throws SQLException {
/* 212 */     int resetBits = 0;
/*     */     
/* 214 */     if ((dirtyBits & 0x1) != 0 && proxyConnection.getReadOnlyState() != this.isReadOnly) {
/* 215 */       connection.setReadOnly(this.isReadOnly);
/* 216 */       resetBits |= 0x1;
/*     */     } 
/*     */     
/* 219 */     if ((dirtyBits & 0x2) != 0 && proxyConnection.getAutoCommitState() != this.isAutoCommit) {
/* 220 */       connection.setAutoCommit(this.isAutoCommit);
/* 221 */       resetBits |= 0x2;
/*     */     } 
/*     */     
/* 224 */     if ((dirtyBits & 0x4) != 0 && proxyConnection.getTransactionIsolationState() != this.transactionIsolation) {
/*     */       
/* 226 */       connection.setTransactionIsolation(this.transactionIsolation);
/* 227 */       resetBits |= 0x4;
/*     */     } 
/*     */     
/* 230 */     if ((dirtyBits & 0x8) != 0 && this.catalog != null && !this.catalog.equals(proxyConnection.getCatalogState())) {
/* 231 */       connection.setCatalog(this.catalog);
/* 232 */       resetBits |= 0x8;
/*     */     } 
/*     */     
/* 235 */     if ((dirtyBits & 0x10) != 0 && proxyConnection.getNetworkTimeoutState() != this.networkTimeout) {
/* 236 */       setNetworkTimeout(connection, this.networkTimeout);
/* 237 */       resetBits |= 0x10;
/*     */     } 
/*     */     
/* 240 */     if ((dirtyBits & 0x20) != 0 && this.schema != null && !this.schema.equals(proxyConnection.getSchemaState())) {
/* 241 */       connection.setSchema(this.schema);
/* 242 */       resetBits |= 0x20;
/*     */     } 
/*     */     
/* 245 */     if (resetBits != 0 && this.logger.isDebugEnabled()) {
/* 246 */       this.logger.debug("{} - Reset ({}) on connection {}", new Object[] { this.poolName, stringFromResetBits(resetBits), connection });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void shutdownNetworkTimeoutExecutor() {
/* 252 */     this.isNetworkTimeoutSupported = -1;
/* 253 */     if (this.netTimeoutExecutor instanceof ThreadPoolExecutor) {
/* 254 */       ((ThreadPoolExecutor)this.netTimeoutExecutor).shutdownNow();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   long getLoginTimeout() {
/*     */     try {
/* 261 */       return (this.dataSource != null) ? this.dataSource.getLoginTimeout() : TimeUnit.SECONDS.toSeconds(5L);
/* 262 */     } catch (SQLException e) {
/* 263 */       return TimeUnit.SECONDS.toSeconds(5L);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handleMBeans(HikariPool hikariPool, boolean register) {
/* 278 */     if (!this.config.isRegisterMbeans()) {
/*     */       return;
/*     */     }
/*     */     try {
/*     */       ObjectName beanConfigName, beanPoolName;
/* 283 */       MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */ 
/*     */       
/* 286 */       if ("true".equals(System.getProperty("hikaricp.jmx.register2.0"))) {
/* 287 */         beanConfigName = new ObjectName("com.zaxxer.hikari:type=PoolConfig,name=" + this.poolName);
/* 288 */         beanPoolName = new ObjectName("com.zaxxer.hikari:type=Pool,name=" + this.poolName);
/*     */       } else {
/* 290 */         beanConfigName = new ObjectName("com.zaxxer.hikari:type=PoolConfig (" + this.poolName + ")");
/* 291 */         beanPoolName = new ObjectName("com.zaxxer.hikari:type=Pool (" + this.poolName + ")");
/*     */       } 
/* 293 */       if (register) {
/* 294 */         if (!mBeanServer.isRegistered(beanConfigName)) {
/* 295 */           mBeanServer.registerMBean(this.config, beanConfigName);
/* 296 */           mBeanServer.registerMBean(hikariPool, beanPoolName);
/*     */         } else {
/* 298 */           this.logger.error("{} - JMX name ({}) is already registered.", this.poolName, this.poolName);
/*     */         }
/*     */       
/* 301 */       } else if (mBeanServer.isRegistered(beanConfigName)) {
/* 302 */         mBeanServer.unregisterMBean(beanConfigName);
/* 303 */         mBeanServer.unregisterMBean(beanPoolName);
/*     */       }
/*     */     
/* 306 */     } catch (Exception e) {
/* 307 */       this.logger.warn("{} - Failed to {} management beans.", new Object[] { this.poolName, register ? "register" : "unregister", e });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeDataSource() {
/* 320 */     String jdbcUrl = this.config.getJdbcUrl();
/* 321 */     String dsClassName = this.config.getDataSourceClassName();
/* 322 */     String driverClassName = this.config.getDriverClassName();
/* 323 */     String dataSourceJNDI = this.config.getDataSourceJNDI();
/* 324 */     Properties dataSourceProperties = this.config.getDataSourceProperties();
/* 325 */     Credentials credentials = getCredentials();
/*     */     
/* 327 */     DataSource dataSource = this.config.getDataSource();
/* 328 */     if (dsClassName != null && dataSource == null) {
/* 329 */       dataSource = (DataSource)UtilityElf.createInstance(dsClassName, DataSource.class, new Object[0]);
/* 330 */       PropertyElf.setTargetFromProperties(dataSource, dataSourceProperties);
/*     */     } else {
/* 332 */       DriverDataSource driverDataSource; if (jdbcUrl != null && dataSource == null) {
/* 333 */         driverDataSource = new DriverDataSource(jdbcUrl, driverClassName, dataSourceProperties, credentials.getUsername(), credentials.getPassword());
/*     */       }
/* 335 */       else if (dataSourceJNDI != null && driverDataSource == null) {
/*     */         try {
/* 337 */           InitialContext ic = new InitialContext();
/* 338 */           dataSource = (DataSource)ic.lookup(dataSourceJNDI);
/* 339 */         } catch (NamingException e) {
/* 340 */           throw new HikariPool.PoolInitializationException(e);
/*     */         } 
/*     */       } 
/*     */     } 
/* 344 */     if (dataSource != null) {
/* 345 */       setLoginTimeout(dataSource);
/* 346 */       createNetworkTimeoutExecutor(dataSource, dsClassName, jdbcUrl);
/*     */     } 
/*     */     
/* 349 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Connection newConnection(boolean isEmptyPool) throws Exception {
/* 359 */     long start = ClockSource.currentTime();
/* 360 */     UUID id = UUID.randomUUID();
/*     */     
/* 362 */     Connection connection = null;
/*     */     try {
/* 364 */       Credentials credentials = getCredentials();
/* 365 */       String username = credentials.getUsername();
/* 366 */       String password = credentials.getPassword();
/*     */       
/* 368 */       this.logger.debug("{} - Attempting to create/setup new connection ({})", this.poolName, id);
/*     */       
/* 370 */       connection = (username == null) ? this.dataSource.getConnection() : this.dataSource.getConnection(username, password);
/* 371 */       if (connection == null) {
/* 372 */         throw new SQLTransientConnectionException("DataSource returned null unexpectedly");
/*     */       }
/*     */       
/* 375 */       setupConnection(connection);
/*     */       
/* 377 */       this.lastConnectionFailure.set(null);
/* 378 */       this.connectionFailureTimestamp.set(0L);
/*     */       
/* 380 */       this.logger.debug("{} - Established new connection ({})", this.poolName, id);
/* 381 */       return connection;
/*     */     }
/* 383 */     catch (Throwable t) {
/* 384 */       this.logger.debug("{} - Failed to create/setup connection ({}): {}", new Object[] { this.poolName, id, t.getMessage() });
/*     */       
/* 386 */       this.connectionFailureTimestamp.compareAndSet(0L, start);
/* 387 */       if (isEmptyPool && ClockSource.elapsedMillis(this.connectionFailureTimestamp.get()) > TimeUnit.MINUTES.toMillis(1L)) {
/* 388 */         this.logger.warn("{} - Pool is empty, failed to create/setup connection ({})", new Object[] { this.poolName, id, t });
/* 389 */         this.connectionFailureTimestamp.set(0L);
/*     */       } 
/*     */       
/* 392 */       if (connection != null) {
/* 393 */         quietlyCloseConnection(connection, "(Failed to create/setup connection (".concat(id.toString()).concat(")"));
/*     */       }
/*     */       
/* 396 */       this.lastConnectionFailure.set(t);
/* 397 */       throw t;
/*     */     }
/*     */     finally {
/*     */       
/* 401 */       if (this.metricsTracker != null) {
/* 402 */         this.metricsTracker.recordConnectionCreated(ClockSource.elapsedMillis(start));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupConnection(Connection connection) throws ConnectionSetupException {
/*     */     try {
/* 416 */       if (this.networkTimeout == -1) {
/* 417 */         this.networkTimeout = getAndSetNetworkTimeout(connection, this.validationTimeout);
/*     */       } else {
/*     */         
/* 420 */         setNetworkTimeout(connection, this.validationTimeout);
/*     */       } 
/*     */       
/* 423 */       if (connection.isReadOnly() != this.isReadOnly) {
/* 424 */         connection.setReadOnly(this.isReadOnly);
/*     */       }
/*     */       
/* 427 */       if (connection.getAutoCommit() != this.isAutoCommit) {
/* 428 */         connection.setAutoCommit(this.isAutoCommit);
/*     */       }
/*     */       
/* 431 */       checkDriverSupport(connection);
/*     */       
/* 433 */       if (this.transactionIsolation != this.defaultTransactionIsolation)
/*     */       {
/* 435 */         connection.setTransactionIsolation(this.transactionIsolation);
/*     */       }
/*     */       
/* 438 */       if (this.catalog != null) {
/* 439 */         connection.setCatalog(this.catalog);
/*     */       }
/*     */       
/* 442 */       if (this.schema != null) {
/* 443 */         connection.setSchema(this.schema);
/*     */       }
/*     */       
/* 446 */       executeSql(connection, this.config.getConnectionInitSql(), true);
/*     */       
/* 448 */       setNetworkTimeout(connection, this.networkTimeout);
/*     */     }
/* 450 */     catch (SQLException e) {
/* 451 */       throw new ConnectionSetupException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkDriverSupport(Connection connection) throws SQLException {
/* 462 */     if (!this.isValidChecked) {
/* 463 */       checkValidationSupport(connection);
/* 464 */       checkDefaultIsolation(connection);
/*     */       
/* 466 */       this.isValidChecked = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkValidationSupport(Connection connection) throws SQLException {
/*     */     try {
/* 479 */       if (this.isUseJdbc4Validation) {
/* 480 */         connection.isValid(Math.max(1, (int)TimeUnit.MILLISECONDS.toSeconds(this.validationTimeout)));
/*     */       } else {
/*     */         
/* 483 */         executeSql(connection, this.config.getConnectionTestQuery(), false);
/*     */       }
/*     */     
/* 486 */     } catch (Exception|AbstractMethodError e) {
/* 487 */       this.logger.error("{} - Failed to execute{} connection test query ({}).", new Object[] { this.poolName, this.isUseJdbc4Validation ? " isValid() for connection, configure" : "", e.getMessage() });
/* 488 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkDefaultIsolation(Connection connection) throws SQLException {
/*     */     try {
/* 501 */       this.defaultTransactionIsolation = connection.getTransactionIsolation();
/* 502 */       if (this.transactionIsolation == -1) {
/* 503 */         this.transactionIsolation = this.defaultTransactionIsolation;
/*     */       }
/*     */     }
/* 506 */     catch (SQLException e) {
/* 507 */       this.logger.warn("{} - Default transaction isolation level detection failed ({}).", this.poolName, e.getMessage());
/* 508 */       if (e.getSQLState() != null && !e.getSQLState().startsWith("08")) {
/* 509 */         throw e;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setQueryTimeout(Statement statement, int timeoutSec) {
/* 522 */     if (this.isQueryTimeoutSupported != 0) {
/*     */       try {
/* 524 */         statement.setQueryTimeout(timeoutSec);
/* 525 */         this.isQueryTimeoutSupported = 1;
/*     */       }
/* 527 */       catch (Exception e) {
/* 528 */         if (this.isQueryTimeoutSupported == -1) {
/* 529 */           this.isQueryTimeoutSupported = 0;
/* 530 */           this.logger.info("{} - Failed to set query timeout for statement. ({})", this.poolName, e.getMessage());
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getAndSetNetworkTimeout(Connection connection, long timeoutMs) {
/* 546 */     if (this.isNetworkTimeoutSupported != 0) {
/*     */       try {
/* 548 */         int originalTimeout = connection.getNetworkTimeout();
/* 549 */         connection.setNetworkTimeout(this.netTimeoutExecutor, (int)timeoutMs);
/* 550 */         this.isNetworkTimeoutSupported = 1;
/* 551 */         return originalTimeout;
/*     */       }
/* 553 */       catch (Exception|AbstractMethodError e) {
/* 554 */         if (this.isNetworkTimeoutSupported == -1) {
/* 555 */           this.isNetworkTimeoutSupported = 0;
/*     */           
/* 557 */           this.logger.info("{} - Driver does not support get/set network timeout for connections. ({})", this.poolName, e.getMessage());
/* 558 */           if (this.validationTimeout < TimeUnit.SECONDS.toMillis(1L)) {
/* 559 */             this.logger.warn("{} - A validationTimeout of less than 1 second cannot be honored on drivers without setNetworkTimeout() support.", this.poolName);
/*     */           }
/* 561 */           else if (this.validationTimeout % TimeUnit.SECONDS.toMillis(1L) != 0L) {
/* 562 */             this.logger.warn("{} - A validationTimeout with fractional second granularity cannot be honored on drivers without setNetworkTimeout() support.", this.poolName);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 568 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setNetworkTimeout(Connection connection, long timeoutMs) throws SQLException {
/* 581 */     if (this.isNetworkTimeoutSupported == 1) {
/* 582 */       connection.setNetworkTimeout(this.netTimeoutExecutor, (int)timeoutMs);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void executeSql(Connection connection, String sql, boolean isCommit) throws SQLException {
/* 596 */     if (sql != null) {
/* 597 */       Statement statement = connection.createStatement();
/*     */       
/* 599 */       try { statement.execute(sql);
/* 600 */         if (statement != null) statement.close();  } catch (Throwable throwable) { if (statement != null)
/*     */           try { statement.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/* 602 */        if (this.isIsolateInternalQueries && !this.isAutoCommit) {
/* 603 */         if (isCommit) {
/* 604 */           connection.commit();
/*     */         } else {
/*     */           
/* 607 */           connection.rollback();
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void createNetworkTimeoutExecutor(DataSource dataSource, String dsClassName, String jdbcUrl) {
/* 616 */     if ((dsClassName != null && dsClassName.contains("Mysql")) || (jdbcUrl != null && jdbcUrl
/* 617 */       .contains("mysql")) || (dataSource != null && dataSource
/* 618 */       .getClass().getName().contains("Mysql"))) {
/* 619 */       this.netTimeoutExecutor = new SynchronousExecutor();
/*     */     } else {
/*     */       
/* 622 */       ThreadFactory threadFactory = this.config.getThreadFactory();
/* 623 */       threadFactory = (threadFactory != null) ? threadFactory : (ThreadFactory)new UtilityElf.DefaultThreadFactory(this.poolName + ":network-timeout-executor");
/* 624 */       ThreadPoolExecutor executor = (ThreadPoolExecutor)Executors.newCachedThreadPool(threadFactory);
/* 625 */       executor.setKeepAliveTime(15L, TimeUnit.SECONDS);
/* 626 */       executor.allowCoreThreadTimeOut(true);
/* 627 */       this.netTimeoutExecutor = executor;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setLoginTimeout(DataSource dataSource) {
/* 638 */     if (this.connectionTimeout != 2147483647L) {
/*     */       try {
/* 640 */         dataSource.setLoginTimeout(Math.max(MINIMUM_LOGIN_TIMEOUT, (int)TimeUnit.MILLISECONDS.toSeconds(500L + this.connectionTimeout)));
/*     */       }
/* 642 */       catch (Exception e) {
/* 643 */         this.logger.info("{} - Failed to set login timeout for data source. ({})", this.poolName, e.getMessage());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String stringFromResetBits(int bits) {
/* 660 */     StringJoiner sb = new StringJoiner(", ");
/* 661 */     for (int ndx = 0; ndx < RESET_STATES.length; ndx++) {
/* 662 */       if ((bits & 1 << ndx) != 0) {
/* 663 */         sb.add(RESET_STATES[ndx]);
/*     */       }
/*     */     } 
/*     */     
/* 667 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private Credentials getCredentials() {
/* 672 */     Credentials credentials = this.config.getCredentials();
/* 673 */     if (LEGACY_USERPASS_DS_OVERRIDE) {
/* 674 */       credentials = Credentials.of(this.config.getUsername(), this.config.getPassword());
/*     */     }
/* 676 */     return credentials;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class ConnectionSetupException
/*     */     extends Exception
/*     */   {
/*     */     private static final long serialVersionUID = 929872118275916521L;
/*     */ 
/*     */ 
/*     */     
/*     */     ConnectionSetupException(Throwable t) {
/* 689 */       super(t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SynchronousExecutor
/*     */     implements Executor
/*     */   {
/*     */     public void execute(Runnable command) {
/*     */       try {
/* 705 */         command.run();
/*     */       }
/* 707 */       catch (Exception t) {
/* 708 */         LoggerFactory.getLogger(PoolBase.class).debug("Failed to execute: {}", command, t);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static interface IMetricsTrackerDelegate
/*     */     extends AutoCloseable
/*     */   {
/*     */     default void recordConnectionUsage(PoolEntry poolEntry) {}
/*     */ 
/*     */     
/*     */     default void recordConnectionCreated(long connectionCreatedMillis) {}
/*     */ 
/*     */     
/*     */     default void recordBorrowTimeoutStats(long startTime) {}
/*     */ 
/*     */     
/*     */     default void recordBorrowStats(PoolEntry poolEntry, long startTime) {}
/*     */ 
/*     */     
/*     */     default void recordConnectionTimeout() {}
/*     */     
/*     */     default void close() {}
/*     */   }
/*     */   
/*     */   static class MetricsTrackerDelegate
/*     */     implements IMetricsTrackerDelegate
/*     */   {
/*     */     final IMetricsTracker tracker;
/*     */     
/*     */     MetricsTrackerDelegate(IMetricsTracker tracker) {
/* 740 */       this.tracker = tracker;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void recordConnectionUsage(PoolEntry poolEntry) {
/* 746 */       this.tracker.recordConnectionUsageMillis(poolEntry.getMillisSinceBorrowed());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void recordConnectionCreated(long connectionCreatedMillis) {
/* 752 */       this.tracker.recordConnectionCreatedMillis(connectionCreatedMillis);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void recordBorrowTimeoutStats(long startTime) {
/* 758 */       this.tracker.recordConnectionAcquiredNanos(ClockSource.elapsedNanos(startTime));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void recordBorrowStats(PoolEntry poolEntry, long startTime) {
/* 764 */       long now = ClockSource.currentTime();
/* 765 */       poolEntry.lastBorrowed = now;
/* 766 */       this.tracker.recordConnectionAcquiredNanos(ClockSource.elapsedNanos(startTime, now));
/*     */     }
/*     */ 
/*     */     
/*     */     public void recordConnectionTimeout() {
/* 771 */       this.tracker.recordConnectionTimeout();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() {
/* 777 */       this.tracker.close();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class NopMetricsTrackerDelegate implements IMetricsTrackerDelegate {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikari\pool\PoolBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */