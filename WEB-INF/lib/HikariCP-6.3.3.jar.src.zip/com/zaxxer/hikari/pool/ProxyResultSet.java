/*     */ package com.zaxxer.hikari.pool;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ProxyResultSet
/*     */   implements ResultSet
/*     */ {
/*     */   protected final ProxyConnection connection;
/*     */   protected final ProxyStatement statement;
/*     */   final ResultSet delegate;
/*     */   
/*     */   protected ProxyResultSet(ProxyConnection connection, ProxyStatement statement, ResultSet resultSet) {
/*  37 */     this.connection = connection;
/*  38 */     this.statement = statement;
/*  39 */     this.delegate = resultSet;
/*     */   }
/*     */ 
/*     */   
/*     */   final SQLException checkException(SQLException e) {
/*  44 */     return this.connection.checkException(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  51 */     return getClass().getSimpleName() + "@" + getClass().getSimpleName() + " wrapping " + System.identityHashCode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Statement getStatement() throws SQLException {
/*  62 */     return this.statement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateRow() throws SQLException {
/*  69 */     this.connection.markCommitStateDirty();
/*  70 */     this.delegate.updateRow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertRow() throws SQLException {
/*  77 */     this.connection.markCommitStateDirty();
/*  78 */     this.delegate.insertRow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteRow() throws SQLException {
/*  85 */     this.connection.markCommitStateDirty();
/*  86 */     this.delegate.deleteRow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isWrapperFor(Class<?> iface) throws SQLException {
/*  93 */     return (iface.isInstance(this.delegate) || (this.delegate != null && this.delegate.isWrapperFor(iface)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T unwrap(Class<T> iface) throws SQLException {
/* 101 */     if (iface.isInstance(this.delegate)) {
/* 102 */       return (T)this.delegate;
/*     */     }
/* 104 */     if (this.delegate != null) {
/* 105 */       return this.delegate.unwrap(iface);
/*     */     }
/*     */     
/* 108 */     throw new SQLException("Wrapped ResultSet is not an instance of " + iface);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikari\pool\ProxyResultSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */