/*     */ package com.zaxxer.hikari.pool;
/*     */ 
/*     */ import com.zaxxer.hikari.HikariConfig;
/*     */ import com.zaxxer.hikari.HikariPoolMXBean;
/*     */ import com.zaxxer.hikari.metrics.MetricsTrackerFactory;
/*     */ import com.zaxxer.hikari.metrics.PoolStats;
/*     */ import com.zaxxer.hikari.util.ClockSource;
/*     */ import com.zaxxer.hikari.util.ConcurrentBag;
/*     */ import com.zaxxer.hikari.util.SuspendResumeLock;
/*     */ import com.zaxxer.hikari.util.UtilityElf;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLTransientConnectionException;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import javax.sql.DataSource;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HikariPool
/*     */   extends PoolBase
/*     */   implements HikariPoolMXBean, ConcurrentBag.IBagStateListener
/*     */ {
/*  54 */   private final Logger logger = LoggerFactory.getLogger(HikariPool.class);
/*     */   
/*     */   public static final int POOL_NORMAL = 0;
/*     */   
/*     */   public static final int POOL_SUSPENDED = 1;
/*     */   
/*     */   public static final int POOL_SHUTDOWN = 2;
/*     */   public volatile int poolState;
/*  62 */   private final long aliveBypassWindowMs = Long.getLong("com.zaxxer.hikari.aliveBypassWindowMs", TimeUnit.MILLISECONDS.toMillis(500L)).longValue();
/*  63 */   private final long housekeepingPeriodMs = Long.getLong("com.zaxxer.hikari.housekeeping.periodMs", TimeUnit.SECONDS.toMillis(30L)).longValue();
/*  64 */   private final long lifeTimeVarianceFactor = Math.min(40L, Math.max(2L, Long.getLong("com.zaxxer.hikari.lifeTimeVarianceFactor", 4L).longValue()));
/*  65 */   private final boolean isRequestBoundariesEnabled = Boolean.getBoolean("com.zaxxer.hikari.enableRequestBoundaries");
/*     */   
/*     */   private static final String EVICTED_CONNECTION_MESSAGE = "(connection was evicted)";
/*     */   
/*     */   private static final String DEAD_CONNECTION_MESSAGE = "(connection is dead)";
/*  70 */   private final PoolEntryCreator poolEntryCreator = new PoolEntryCreator();
/*  71 */   private final PoolEntryCreator postFillPoolEntryCreator = new PoolEntryCreator("After adding ");
/*     */ 
/*     */   
/*     */   private final ThreadPoolExecutor addConnectionExecutor;
/*     */   
/*     */   private final ThreadPoolExecutor closeConnectionExecutor;
/*     */   
/*     */   private final ConcurrentBag<PoolEntry> connectionBag;
/*     */   
/*     */   private final ProxyLeakTaskFactory leakTaskFactory;
/*     */   
/*     */   private final SuspendResumeLock suspendResumeLock;
/*     */   
/*     */   private final ScheduledExecutorService houseKeepingExecutorService;
/*     */   
/*     */   private ScheduledFuture<?> houseKeeperTask;
/*     */ 
/*     */   
/*     */   public HikariPool(HikariConfig config) {
/*  90 */     super(config);
/*     */     
/*  92 */     this.connectionBag = new ConcurrentBag(this);
/*  93 */     this.suspendResumeLock = config.isAllowPoolSuspension() ? new SuspendResumeLock() : SuspendResumeLock.FAUX_LOCK;
/*     */     
/*  95 */     this.houseKeepingExecutorService = initializeHouseKeepingExecutorService();
/*     */     
/*  97 */     checkFailFast();
/*     */     
/*  99 */     if (config.getMetricsTrackerFactory() != null) {
/* 100 */       setMetricsTrackerFactory(config.getMetricsTrackerFactory());
/*     */     } else {
/*     */       
/* 103 */       setMetricRegistry(config.getMetricRegistry());
/*     */     } 
/*     */     
/* 106 */     setHealthCheckRegistry(config.getHealthCheckRegistry());
/*     */     
/* 108 */     handleMBeans(this, true);
/*     */     
/* 110 */     ThreadFactory threadFactory = config.getThreadFactory();
/*     */     
/* 112 */     int maxPoolSize = config.getMaximumPoolSize();
/* 113 */     this.addConnectionExecutor = UtilityElf.createThreadPoolExecutor(maxPoolSize, this.poolName + ":connection-adder", threadFactory, (RejectedExecutionHandler)new UtilityElf.CustomDiscardPolicy());
/* 114 */     this.closeConnectionExecutor = UtilityElf.createThreadPoolExecutor(maxPoolSize, this.poolName + ":connection-closer", threadFactory, new ThreadPoolExecutor.CallerRunsPolicy());
/*     */     
/* 116 */     this.leakTaskFactory = new ProxyLeakTaskFactory(config.getLeakDetectionThreshold(), this.houseKeepingExecutorService);
/*     */     
/* 118 */     this.houseKeeperTask = this.houseKeepingExecutorService.scheduleWithFixedDelay(new HouseKeeper(), 100L, this.housekeepingPeriodMs, TimeUnit.MILLISECONDS);
/*     */     
/* 120 */     if (Boolean.getBoolean("com.zaxxer.hikari.blockUntilFilled") && config.getInitializationFailTimeout() > 1L) {
/* 121 */       this.addConnectionExecutor.setMaximumPoolSize(Math.min(16, Runtime.getRuntime().availableProcessors()));
/* 122 */       this.addConnectionExecutor.setCorePoolSize(Math.min(16, Runtime.getRuntime().availableProcessors()));
/*     */       
/* 124 */       long startTime = ClockSource.currentTime();
/* 125 */       while (ClockSource.elapsedMillis(startTime) < config.getInitializationFailTimeout() && getTotalConnections() < config.getMinimumIdle()) {
/* 126 */         UtilityElf.quietlySleep(TimeUnit.MILLISECONDS.toMillis(100L));
/*     */       }
/*     */       
/* 129 */       this.addConnectionExecutor.setCorePoolSize(1);
/* 130 */       this.addConnectionExecutor.setMaximumPoolSize(1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 142 */     return getConnection(this.connectionTimeout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection(long hardTimeout) throws SQLException {
/* 154 */     this.suspendResumeLock.acquire();
/* 155 */     long startTime = ClockSource.currentTime();
/*     */     
/*     */     try {
/* 158 */       long timeout = hardTimeout;
/*     */       do {
/* 160 */         PoolEntry poolEntry = (PoolEntry)this.connectionBag.borrow(timeout, TimeUnit.MILLISECONDS);
/* 161 */         if (poolEntry == null) {
/*     */           break;
/*     */         }
/*     */         
/* 165 */         long now = ClockSource.currentTime();
/* 166 */         if (poolEntry.isMarkedEvicted() || (ClockSource.elapsedMillis(poolEntry.lastAccessed, now) > this.aliveBypassWindowMs && isConnectionDead(poolEntry.connection))) {
/* 167 */           closeConnection(poolEntry, poolEntry.isMarkedEvicted() ? "(connection was evicted)" : "(connection is dead)");
/* 168 */           timeout = hardTimeout - ClockSource.elapsedMillis(startTime);
/*     */         } else {
/*     */           
/* 171 */           this.metricsTracker.recordBorrowStats(poolEntry, startTime);
/* 172 */           if (this.isRequestBoundariesEnabled) {
/*     */             try {
/* 174 */               poolEntry.connection.beginRequest();
/* 175 */             } catch (SQLException e) {
/* 176 */               this.logger.warn("beginRequest Failed for: {}, ({})", poolEntry.connection, e.getMessage());
/*     */             } 
/*     */           }
/* 179 */           return poolEntry.createProxyConnection(this.leakTaskFactory.schedule(poolEntry));
/*     */         } 
/* 181 */       } while (timeout > 0L);
/*     */       
/* 183 */       this.metricsTracker.recordBorrowTimeoutStats(startTime);
/* 184 */       throw createTimeoutException(startTime);
/*     */     }
/* 186 */     catch (InterruptedException e) {
/* 187 */       Thread.currentThread().interrupt();
/* 188 */       throw new SQLException(this.poolName + " - Interrupted during connection acquisition", e);
/*     */     } finally {
/*     */       
/* 191 */       this.suspendResumeLock.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void shutdown() throws InterruptedException {
/*     */     try {
/* 204 */       this.poolState = 2;
/*     */       
/* 206 */       if (this.addConnectionExecutor == null) {
/*     */         return;
/*     */       }
/*     */       
/* 210 */       logPoolState(new String[] { "Before shutdown " });
/*     */       
/* 212 */       if (this.houseKeeperTask != null) {
/* 213 */         this.houseKeeperTask.cancel(false);
/* 214 */         this.houseKeeperTask = null;
/*     */       } 
/*     */       
/* 217 */       softEvictConnections();
/*     */       
/* 219 */       this.addConnectionExecutor.shutdown();
/* 220 */       if (!this.addConnectionExecutor.awaitTermination(getLoginTimeout(), TimeUnit.SECONDS)) {
/* 221 */         this.logger.warn("Timed-out waiting for add connection executor to shutdown");
/*     */       }
/*     */       
/* 224 */       destroyHouseKeepingExecutorService();
/*     */       
/* 226 */       this.connectionBag.close();
/*     */       
/* 228 */       ThreadPoolExecutor assassinExecutor = UtilityElf.createThreadPoolExecutor(this.config.getMaximumPoolSize(), this.poolName + ":connection-assassinator", this.config
/* 229 */           .getThreadFactory(), new ThreadPoolExecutor.CallerRunsPolicy());
/*     */       try {
/* 231 */         long start = ClockSource.currentTime();
/*     */         do {
/* 233 */           abortActiveConnections(assassinExecutor);
/* 234 */           softEvictConnections();
/* 235 */         } while (getTotalConnections() > 0 && ClockSource.elapsedMillis(start) < TimeUnit.SECONDS.toMillis(10L));
/*     */       } finally {
/*     */         
/* 238 */         assassinExecutor.shutdown();
/* 239 */         if (!assassinExecutor.awaitTermination(10L, TimeUnit.SECONDS)) {
/* 240 */           this.logger.warn("Timed-out waiting for connection assassin to shutdown");
/*     */         }
/*     */       } 
/*     */       
/* 244 */       shutdownNetworkTimeoutExecutor();
/* 245 */       this.closeConnectionExecutor.shutdown();
/* 246 */       if (!this.closeConnectionExecutor.awaitTermination(10L, TimeUnit.SECONDS)) {
/* 247 */         this.logger.warn("Timed-out waiting for close connection executor to shutdown");
/*     */       }
/*     */     } finally {
/*     */       
/* 251 */       logPoolState(new String[] { "After  shutdown " });
/* 252 */       handleMBeans(this, false);
/* 253 */       this.metricsTracker.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void evictConnection(Connection connection) {
/* 264 */     ProxyConnection proxyConnection = (ProxyConnection)connection;
/* 265 */     proxyConnection.cancelLeakTask();
/*     */     
/*     */     try {
/* 268 */       softEvictConnection(proxyConnection.getPoolEntry(), "(connection evicted by user)", !connection.isClosed());
/*     */     }
/* 270 */     catch (SQLException sQLException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMetricRegistry(Object metricRegistry) {
/* 283 */     if (metricRegistry != null && UtilityElf.safeIsAssignableFrom(metricRegistry, "com.codahale.metrics.MetricRegistry")) {
/* 284 */       setMetricsTrackerFactory((MetricsTrackerFactory)UtilityElf.createInstance("com.zaxxer.hikari.metrics.dropwizard.CodahaleMetricsTrackerFactory", MetricsTrackerFactory.class, new Object[] { metricRegistry }));
/*     */     
/*     */     }
/* 287 */     else if (metricRegistry != null && UtilityElf.safeIsAssignableFrom(metricRegistry, "io.dropwizard.metrics5.MetricRegistry")) {
/* 288 */       setMetricsTrackerFactory((MetricsTrackerFactory)UtilityElf.createInstance("com.zaxxer.hikari.metrics.dropwizard.Dropwizard5MetricsTrackerFactory", MetricsTrackerFactory.class, new Object[] { metricRegistry }));
/*     */     
/*     */     }
/* 291 */     else if (metricRegistry != null && UtilityElf.safeIsAssignableFrom(metricRegistry, "io.micrometer.core.instrument.MeterRegistry")) {
/* 292 */       setMetricsTrackerFactory((MetricsTrackerFactory)UtilityElf.createInstance("com.zaxxer.hikari.metrics.micrometer.MicrometerMetricsTrackerFactory", MetricsTrackerFactory.class, new Object[] { metricRegistry }));
/*     */     }
/*     */     else {
/*     */       
/* 296 */       setMetricsTrackerFactory((MetricsTrackerFactory)null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMetricsTrackerFactory(MetricsTrackerFactory metricsTrackerFactory) {
/* 307 */     if (metricsTrackerFactory != null) {
/* 308 */       this.metricsTracker = new PoolBase.MetricsTrackerDelegate(metricsTrackerFactory.create(this.config.getPoolName(), getPoolStats()));
/*     */     } else {
/*     */       
/* 311 */       this.metricsTracker = new PoolBase.NopMetricsTrackerDelegate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHealthCheckRegistry(Object healthCheckRegistry) {
/* 323 */     if (healthCheckRegistry != null) {
/*     */       try {
/* 325 */         Class<?> checkerClazz = HikariPool.class.getClassLoader().loadClass("com.zaxxer.hikari.metrics.dropwizard.CodahaleHealthChecker");
/* 326 */         Class<?> healthCheckRegistryClazz = HikariPool.class.getClassLoader().loadClass("com.codahale.metrics.health.HealthCheckRegistry");
/* 327 */         checkerClazz.getMethod("registerHealthChecks", new Class[] { HikariPool.class, HikariConfig.class, healthCheckRegistryClazz
/* 328 */             }).invoke(null, new Object[] { this, this.config, healthCheckRegistry });
/* 329 */       } catch (ClassNotFoundException|NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 330 */         throw new RuntimeException(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBagItem(int waiting) {
/* 343 */     if (waiting > this.addConnectionExecutor.getQueue().size()) {
/* 344 */       this.addConnectionExecutor.submit(this.poolEntryCreator);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getActiveConnections() {
/* 355 */     return this.connectionBag.getCount(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIdleConnections() {
/* 362 */     return this.connectionBag.getCount(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTotalConnections() {
/* 369 */     return this.connectionBag.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getThreadsAwaitingConnection() {
/* 376 */     return this.connectionBag.getWaitingThreadCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void softEvictConnections() {
/* 383 */     this.connectionBag.values().forEach(poolEntry -> softEvictConnection(poolEntry, "(connection evicted)", false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void suspendPool() {
/* 390 */     if (this.suspendResumeLock == SuspendResumeLock.FAUX_LOCK) {
/* 391 */       throw new IllegalStateException(this.poolName + " - is not suspendable");
/*     */     }
/* 393 */     if (this.poolState != 1) {
/* 394 */       this.suspendResumeLock.suspend();
/* 395 */       this.poolState = 1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void resumePool() {
/* 403 */     if (this.poolState == 1) {
/* 404 */       this.poolState = 0;
/* 405 */       fillPool(false);
/* 406 */       this.suspendResumeLock.resume();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void logPoolState(String... prefix) {
/* 421 */     if (this.logger.isDebugEnabled()) {
/* 422 */       this.logger.debug("{} - {}stats (total={}/{}, idle={}/{}, active={}, waiting={})", new Object[] { this.poolName, 
/* 423 */             (prefix.length > 0) ? prefix[0] : "", 
/* 424 */             Integer.valueOf(getTotalConnections()), Integer.valueOf(this.config.getMaximumPoolSize()), Integer.valueOf(getIdleConnections()), Integer.valueOf(this.config.getMinimumIdle()), Integer.valueOf(getActiveConnections()), Integer.valueOf(getThreadsAwaitingConnection()) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void recycle(PoolEntry poolEntry) {
/* 436 */     this.metricsTracker.recordConnectionUsage(poolEntry);
/* 437 */     if (poolEntry.isMarkedEvicted()) {
/* 438 */       closeConnection(poolEntry, "(connection was evicted)");
/*     */     } else {
/* 440 */       if (this.isRequestBoundariesEnabled) {
/*     */         try {
/* 442 */           poolEntry.connection.endRequest();
/* 443 */         } catch (SQLException e) {
/* 444 */           this.logger.warn("endRequest Failed for: {},({})", poolEntry.connection, e.getMessage());
/*     */         } 
/*     */       }
/* 447 */       this.connectionBag.requite(poolEntry);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void closeConnection(PoolEntry poolEntry, String closureReason) {
/* 459 */     if (this.connectionBag.remove(poolEntry)) {
/* 460 */       Connection connection = poolEntry.close();
/* 461 */       this.closeConnectionExecutor.execute(() -> {
/*     */             quietlyCloseConnection(connection, closureReason);
/*     */             if (this.poolState == 0) {
/*     */               fillPool(false);
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int[] getPoolStateCounts() {
/* 473 */     return this.connectionBag.getStateCounts();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PoolEntry createPoolEntry() {
/*     */     try {
/* 488 */       PoolEntry poolEntry = newPoolEntry((getTotalConnections() == 0));
/*     */       
/* 490 */       long maxLifetime = this.config.getMaxLifetime();
/* 491 */       if (maxLifetime > 0L) {
/*     */         
/* 493 */         long variance = (maxLifetime > 10000L) ? ThreadLocalRandom.current().nextLong(maxLifetime / this.lifeTimeVarianceFactor) : 0L;
/* 494 */         long lifetime = maxLifetime - variance;
/* 495 */         poolEntry.setFutureEol(this.houseKeepingExecutorService.schedule(new MaxLifetimeTask(poolEntry), lifetime, TimeUnit.MILLISECONDS));
/*     */       } 
/*     */       
/* 498 */       long keepaliveTime = this.config.getKeepaliveTime();
/* 499 */       if (keepaliveTime > 0L) {
/*     */         
/* 501 */         long variance = ThreadLocalRandom.current().nextLong(keepaliveTime / 5L);
/* 502 */         long heartbeatTime = keepaliveTime - variance;
/* 503 */         poolEntry.setKeepalive(this.houseKeepingExecutorService.scheduleWithFixedDelay(new KeepaliveTask(poolEntry), heartbeatTime, heartbeatTime, TimeUnit.MILLISECONDS));
/*     */       } 
/*     */       
/* 506 */       return poolEntry;
/*     */     }
/* 508 */     catch (ConnectionSetupException e) {
/* 509 */       if (this.poolState == 0) {
/* 510 */         this.logger.debug("{} - Error thrown while acquiring connection from data source", this.poolName, e.getCause());
/*     */       }
/*     */     }
/* 513 */     catch (Throwable e) {
/* 514 */       if (this.poolState == 0) {
/* 515 */         this.logger.debug("{} - Cannot acquire connection from data source", this.poolName, e);
/*     */       }
/*     */     } 
/*     */     
/* 519 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void fillPool(boolean isAfterAdd) {
/* 527 */     int idle = getIdleConnections();
/* 528 */     boolean shouldAdd = (getTotalConnections() < this.config.getMaximumPoolSize() && idle < this.config.getMinimumIdle());
/*     */     
/* 530 */     if (shouldAdd) {
/* 531 */       int countToAdd = this.config.getMinimumIdle() - idle;
/* 532 */       for (int i = 0; i < countToAdd; i++) {
/* 533 */         this.addConnectionExecutor.submit(isAfterAdd ? this.postFillPoolEntryCreator : this.poolEntryCreator);
/*     */       }
/* 535 */     } else if (isAfterAdd) {
/* 536 */       this.logger.debug("{} - Fill pool skipped, pool has sufficient level or currently being filled.", this.poolName);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void abortActiveConnections(ExecutorService assassinExecutor) {
/* 547 */     for (PoolEntry poolEntry : this.connectionBag.values(1)) {
/* 548 */       Connection connection = poolEntry.close();
/*     */       try {
/* 550 */         connection.abort(assassinExecutor);
/*     */       }
/* 552 */       catch (Throwable e) {
/* 553 */         quietlyCloseConnection(connection, "(connection aborted during shutdown)");
/*     */       } finally {
/*     */         
/* 556 */         this.connectionBag.remove(poolEntry);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkFailFast() {
/* 569 */     long initializationFailTimeout = this.config.getInitializationFailTimeout();
/* 570 */     if (initializationFailTimeout < 0L) {
/*     */       return;
/*     */     }
/*     */     
/* 574 */     long startTime = ClockSource.currentTime();
/*     */     do {
/* 576 */       PoolEntry poolEntry = createPoolEntry();
/* 577 */       if (poolEntry != null) {
/* 578 */         if (this.config.getMinimumIdle() > 0) {
/* 579 */           this.connectionBag.add(poolEntry);
/* 580 */           this.logger.info("{} - Added connection {}", this.poolName, poolEntry.connection);
/*     */         } else {
/*     */           
/* 583 */           quietlyCloseConnection(poolEntry.close(), "(initialization check complete and minimumIdle is zero)");
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 589 */       if (getLastConnectionFailure() instanceof PoolBase.ConnectionSetupException) {
/* 590 */         throwPoolInitializationException(getLastConnectionFailure().getCause());
/*     */       }
/*     */       
/* 593 */       UtilityElf.quietlySleep(TimeUnit.SECONDS.toMillis(1L));
/* 594 */     } while (ClockSource.elapsedMillis(startTime) < initializationFailTimeout);
/*     */     
/* 596 */     if (initializationFailTimeout > 0L) {
/* 597 */       throwPoolInitializationException(getLastConnectionFailure());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void throwPoolInitializationException(Throwable t) {
/* 609 */     destroyHouseKeepingExecutorService();
/* 610 */     throw new PoolInitializationException(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean softEvictConnection(PoolEntry poolEntry, String reason, boolean owner) {
/* 628 */     poolEntry.markEvicted();
/* 629 */     if (owner || this.connectionBag.reserve(poolEntry)) {
/* 630 */       closeConnection(poolEntry, reason);
/* 631 */       return true;
/*     */     } 
/*     */     
/* 634 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ScheduledExecutorService initializeHouseKeepingExecutorService() {
/* 646 */     if (this.config.getScheduledExecutor() == null) {
/* 647 */       ThreadFactory threadFactory = Optional.<ThreadFactory>ofNullable(this.config.getThreadFactory()).orElseGet(() -> new UtilityElf.DefaultThreadFactory(this.poolName + ":housekeeper"));
/* 648 */       ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(1, threadFactory, new ThreadPoolExecutor.DiscardPolicy());
/* 649 */       executor.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
/* 650 */       executor.setRemoveOnCancelPolicy(true);
/* 651 */       return executor;
/*     */     } 
/*     */     
/* 654 */     return this.config.getScheduledExecutor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void destroyHouseKeepingExecutorService() {
/* 663 */     if (this.config.getScheduledExecutor() == null) {
/* 664 */       this.houseKeepingExecutorService.shutdownNow();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PoolStats getPoolStats() {
/* 675 */     return new PoolStats(TimeUnit.SECONDS.toMillis(1L))
/*     */       {
/*     */         protected void update() {
/* 678 */           this.pendingThreads = HikariPool.this.getThreadsAwaitingConnection();
/* 679 */           this.idleConnections = HikariPool.this.getIdleConnections();
/* 680 */           this.totalConnections = HikariPool.this.getTotalConnections();
/* 681 */           this.activeConnections = HikariPool.this.getActiveConnections();
/* 682 */           this.maxConnections = HikariPool.this.config.getMaximumPoolSize();
/* 683 */           this.minConnections = HikariPool.this.config.getMinimumIdle();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SQLException createTimeoutException(long startTime) {
/* 702 */     logPoolState(new String[] { "Timeout failure " });
/* 703 */     this.metricsTracker.recordConnectionTimeout();
/*     */     
/* 705 */     String sqlState = null;
/* 706 */     int errorCode = 0;
/* 707 */     Throwable originalException = getLastConnectionFailure();
/* 708 */     if (originalException instanceof SQLException) {
/* 709 */       sqlState = ((SQLException)originalException).getSQLState();
/* 710 */       errorCode = ((SQLException)originalException).getErrorCode();
/*     */     } 
/*     */ 
/*     */     
/* 714 */     SQLTransientConnectionException connectionException = new SQLTransientConnectionException(this.poolName + " - Connection is not available, request timed out after " + this.poolName + "ms (total=" + ClockSource.elapsedMillis(startTime) + ", active=" + getTotalConnections() + ", idle=" + getActiveConnections() + ", waiting=" + getIdleConnections() + ")", sqlState, errorCode, originalException);
/*     */     
/* 716 */     if (originalException instanceof SQLException) {
/* 717 */       connectionException.setNextException((SQLException)originalException);
/*     */     }
/*     */     
/* 720 */     return connectionException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class PoolEntryCreator
/*     */     implements Callable<Boolean>
/*     */   {
/*     */     private final String loggingPrefix;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     PoolEntryCreator() {
/* 737 */       this(null);
/*     */     }
/*     */ 
/*     */     
/*     */     PoolEntryCreator(String loggingPrefix) {
/* 742 */       this.loggingPrefix = loggingPrefix;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean call() {
/* 748 */       long backoffMs = 10L;
/* 749 */       boolean added = false;
/*     */       try {
/* 751 */         while (shouldContinueCreating()) {
/* 752 */           PoolEntry poolEntry = HikariPool.this.createPoolEntry();
/* 753 */           if (poolEntry != null) {
/* 754 */             added = true;
/* 755 */             HikariPool.this.connectionBag.add(poolEntry);
/* 756 */             HikariPool.this.logger.debug("{} - Added connection {}", HikariPool.this.poolName, poolEntry.connection);
/* 757 */             UtilityElf.quietlySleep(30L);
/*     */             break;
/*     */           } 
/* 760 */           if (this.loggingPrefix != null && backoffMs % 50L == 0L)
/* 761 */             HikariPool.this.logger.debug("{} - Connection add failed, sleeping with backoff: {}ms", HikariPool.this.poolName, Long.valueOf(backoffMs)); 
/* 762 */           UtilityElf.quietlySleep(backoffMs);
/* 763 */           backoffMs = Math.min(TimeUnit.SECONDS.toMillis(5L), backoffMs * 2L);
/*     */         }
/*     */       
/*     */       } finally {
/*     */         
/* 768 */         if (added && this.loggingPrefix != null) {
/* 769 */           HikariPool.this.logPoolState(new String[] { this.loggingPrefix });
/* 770 */         } else if (!added) {
/* 771 */           HikariPool.this.logPoolState(new String[] { "Connection not added, " });
/*     */         } 
/*     */       } 
/*     */       
/* 775 */       return Boolean.FALSE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private synchronized boolean shouldContinueCreating() {
/* 785 */       return (HikariPool.this.poolState == 0 && HikariPool.this.getTotalConnections() < HikariPool.this.config.getMaximumPoolSize() && (HikariPool.this
/* 786 */         .getIdleConnections() < HikariPool.this.config.getMinimumIdle() || HikariPool.this.connectionBag.getWaitingThreadCount() > HikariPool.this.getIdleConnections()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class HouseKeeper
/*     */     implements Runnable
/*     */   {
/* 795 */     private volatile long previous = ClockSource.plusMillis(ClockSource.currentTime(), -HikariPool.this.housekeepingPeriodMs);
/*     */     
/* 797 */     private final AtomicReferenceFieldUpdater<PoolBase, String> catalogUpdater = AtomicReferenceFieldUpdater.newUpdater(PoolBase.class, String.class, "catalog");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 804 */         HikariPool.this.connectionTimeout = HikariPool.this.config.getConnectionTimeout();
/* 805 */         HikariPool.this.validationTimeout = HikariPool.this.config.getValidationTimeout();
/* 806 */         HikariPool.this.leakTaskFactory.updateLeakDetectionThreshold(HikariPool.this.config.getLeakDetectionThreshold());
/*     */         
/* 808 */         if (HikariPool.this.config.getCatalog() != null && !HikariPool.this.config.getCatalog().equals(HikariPool.this.catalog)) {
/* 809 */           this.catalogUpdater.set(HikariPool.this, HikariPool.this.config.getCatalog());
/*     */         }
/*     */         
/* 812 */         long idleTimeout = HikariPool.this.config.getIdleTimeout();
/* 813 */         long now = ClockSource.currentTime();
/*     */ 
/*     */         
/* 816 */         if (ClockSource.plusMillis(now, 128L) < ClockSource.plusMillis(this.previous, HikariPool.this.housekeepingPeriodMs)) {
/* 817 */           HikariPool.this.logger.warn("{} - Retrograde clock change detected (housekeeper delta={}), soft-evicting connections from pool.", HikariPool.this.poolName, 
/* 818 */               ClockSource.elapsedDisplayString(this.previous, now));
/* 819 */           this.previous = now;
/* 820 */           HikariPool.this.softEvictConnections();
/*     */           return;
/*     */         } 
/* 823 */         if (now > ClockSource.plusMillis(this.previous, 3L * HikariPool.this.housekeepingPeriodMs / 2L))
/*     */         {
/* 825 */           HikariPool.this.logger.warn("{} - Thread starvation or clock leap detected (housekeeper delta={}).", HikariPool.this.poolName, ClockSource.elapsedDisplayString(this.previous, now));
/*     */         }
/*     */         
/* 828 */         this.previous = now;
/*     */         
/* 830 */         if (idleTimeout > 0L && HikariPool.this.config.getMinimumIdle() < HikariPool.this.config.getMaximumPoolSize()) {
/* 831 */           HikariPool.this.logPoolState(new String[] { "Before cleanup " });
/* 832 */           List<PoolEntry> notInUse = HikariPool.this.connectionBag.values(0);
/* 833 */           int maxToRemove = notInUse.size() - HikariPool.this.config.getMinimumIdle();
/* 834 */           for (PoolEntry entry : notInUse) {
/* 835 */             if (maxToRemove > 0 && ClockSource.elapsedMillis(entry.lastAccessed, now) > idleTimeout && HikariPool.this.connectionBag.reserve(entry)) {
/* 836 */               HikariPool.this.closeConnection(entry, "(connection has passed idleTimeout)");
/* 837 */               maxToRemove--;
/*     */             } 
/*     */           } 
/* 840 */           HikariPool.this.logPoolState(new String[] { "After  cleanup " });
/*     */         } else {
/*     */           
/* 843 */           HikariPool.this.logPoolState(new String[] { "Pool " });
/*     */         } 
/* 845 */         HikariPool.this.fillPool(true);
/*     */       }
/* 847 */       catch (Exception e) {
/* 848 */         HikariPool.this.logger.error("Unexpected exception in housekeeping task", e);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private final class MaxLifetimeTask
/*     */     implements Runnable
/*     */   {
/*     */     private final PoolEntry poolEntry;
/*     */     
/*     */     MaxLifetimeTask(PoolEntry poolEntry) {
/* 859 */       this.poolEntry = poolEntry;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 864 */       if (HikariPool.this.softEvictConnection(this.poolEntry, "(connection has passed maxLifetime)", false)) {
/* 865 */         HikariPool.this.addBagItem(HikariPool.this.connectionBag.getWaitingThreadCount());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private final class KeepaliveTask
/*     */     implements Runnable
/*     */   {
/*     */     private final PoolEntry poolEntry;
/*     */     
/*     */     KeepaliveTask(PoolEntry poolEntry) {
/* 876 */       this.poolEntry = poolEntry;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 881 */       if (HikariPool.this.connectionBag.reserve(this.poolEntry)) {
/* 882 */         if (HikariPool.this.isConnectionDead(this.poolEntry.connection)) {
/* 883 */           HikariPool.this.softEvictConnection(this.poolEntry, "(connection is dead)", true);
/* 884 */           HikariPool.this.addBagItem(HikariPool.this.connectionBag.getWaitingThreadCount());
/*     */         } else {
/*     */           
/* 887 */           HikariPool.this.connectionBag.unreserve(this.poolEntry);
/* 888 */           HikariPool.this.logger.debug("{} - keepalive: connection {} is alive", HikariPool.this.poolName, this.poolEntry.connection);
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PoolInitializationException
/*     */     extends RuntimeException
/*     */   {
/*     */     private static final long serialVersionUID = 929872118275916520L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PoolInitializationException(Throwable t) {
/* 908 */       super("Failed to initialize pool: " + t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikari\pool\HikariPool.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */