/*     */ package com.zaxxer.hikari.pool;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ProxyDatabaseMetaData
/*     */   implements DatabaseMetaData
/*     */ {
/*     */   protected final ProxyConnection connection;
/*     */   protected final DatabaseMetaData delegate;
/*     */   
/*     */   ProxyDatabaseMetaData(ProxyConnection connection, DatabaseMetaData metaData) {
/*  39 */     this.connection = connection;
/*  40 */     this.delegate = metaData;
/*     */   }
/*     */ 
/*     */   
/*     */   final SQLException checkException(SQLException e) {
/*  45 */     return this.connection.checkException(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/*  52 */     String delegateToString = this.delegate.toString();
/*  53 */     return getClass().getSimpleName() + "@" + getClass().getSimpleName() + " wrapping " + System.identityHashCode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Connection getConnection() {
/*  64 */     return this.connection;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern) throws SQLException {
/*  69 */     ResultSet resultSet = this.delegate.getProcedures(catalog, schemaPattern, procedureNamePattern);
/*  70 */     Statement statement = resultSet.getStatement();
/*  71 */     if (statement != null) {
/*  72 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/*  74 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getProcedureColumns(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern) throws SQLException {
/*  79 */     ResultSet resultSet = this.delegate.getProcedureColumns(catalog, schemaPattern, procedureNamePattern, columnNamePattern);
/*  80 */     Statement statement = resultSet.getStatement();
/*  81 */     if (statement != null) {
/*  82 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/*  84 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, String[] types) throws SQLException {
/*  89 */     ResultSet resultSet = this.delegate.getTables(catalog, schemaPattern, tableNamePattern, types);
/*  90 */     Statement statement = resultSet.getStatement();
/*  91 */     if (statement != null) {
/*  92 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/*  94 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getSchemas() throws SQLException {
/*  99 */     ResultSet resultSet = this.delegate.getSchemas();
/* 100 */     Statement statement = resultSet.getStatement();
/* 101 */     if (statement != null) {
/* 102 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 104 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getCatalogs() throws SQLException {
/* 109 */     ResultSet resultSet = this.delegate.getCatalogs();
/* 110 */     Statement statement = resultSet.getStatement();
/* 111 */     if (statement != null) {
/* 112 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 114 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getTableTypes() throws SQLException {
/* 119 */     ResultSet resultSet = this.delegate.getTableTypes();
/* 120 */     Statement statement = resultSet.getStatement();
/* 121 */     if (statement != null) {
/* 122 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 124 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern) throws SQLException {
/* 129 */     ResultSet resultSet = this.delegate.getColumns(catalog, schemaPattern, tableNamePattern, columnNamePattern);
/* 130 */     Statement statement = resultSet.getStatement();
/* 131 */     if (statement != null) {
/* 132 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 134 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern) throws SQLException {
/* 139 */     ResultSet resultSet = this.delegate.getColumnPrivileges(catalog, schema, table, columnNamePattern);
/* 140 */     Statement statement = resultSet.getStatement();
/* 141 */     if (statement != null) {
/* 142 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 144 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getTablePrivileges(String catalog, String schemaPattern, String tableNamePattern) throws SQLException {
/* 149 */     ResultSet resultSet = this.delegate.getTablePrivileges(catalog, schemaPattern, tableNamePattern);
/* 150 */     Statement statement = resultSet.getStatement();
/* 151 */     if (statement != null) {
/* 152 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 154 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getBestRowIdentifier(String catalog, String schema, String table, int scope, boolean nullable) throws SQLException {
/* 159 */     ResultSet resultSet = this.delegate.getBestRowIdentifier(catalog, schema, table, scope, nullable);
/* 160 */     Statement statement = resultSet.getStatement();
/* 161 */     if (statement != null) {
/* 162 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 164 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getVersionColumns(String catalog, String schema, String table) throws SQLException {
/* 169 */     ResultSet resultSet = this.delegate.getVersionColumns(catalog, schema, table);
/* 170 */     Statement statement = resultSet.getStatement();
/* 171 */     if (statement != null) {
/* 172 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 174 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getPrimaryKeys(String catalog, String schema, String table) throws SQLException {
/* 179 */     ResultSet resultSet = this.delegate.getPrimaryKeys(catalog, schema, table);
/* 180 */     Statement statement = resultSet.getStatement();
/* 181 */     if (statement != null) {
/* 182 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 184 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getImportedKeys(String catalog, String schema, String table) throws SQLException {
/* 189 */     ResultSet resultSet = this.delegate.getImportedKeys(catalog, schema, table);
/* 190 */     Statement statement = resultSet.getStatement();
/* 191 */     if (statement != null) {
/* 192 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 194 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getExportedKeys(String catalog, String schema, String table) throws SQLException {
/* 199 */     ResultSet resultSet = this.delegate.getExportedKeys(catalog, schema, table);
/* 200 */     Statement statement = resultSet.getStatement();
/* 201 */     if (statement != null) {
/* 202 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 204 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getCrossReference(String parentCatalog, String parentSchema, String parentTable, String foreignCatalog, String foreignSchema, String foreignTable) throws SQLException {
/* 209 */     ResultSet resultSet = this.delegate.getCrossReference(parentCatalog, parentSchema, parentTable, foreignCatalog, foreignSchema, foreignTable);
/* 210 */     Statement statement = resultSet.getStatement();
/* 211 */     if (statement != null) {
/* 212 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 214 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getTypeInfo() throws SQLException {
/* 219 */     ResultSet resultSet = this.delegate.getTypeInfo();
/* 220 */     Statement statement = resultSet.getStatement();
/* 221 */     if (statement != null) {
/* 222 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 224 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getIndexInfo(String catalog, String schema, String table, boolean unique, boolean approximate) throws SQLException {
/* 229 */     ResultSet resultSet = this.delegate.getIndexInfo(catalog, schema, table, unique, approximate);
/* 230 */     Statement statement = resultSet.getStatement();
/* 231 */     if (statement != null) {
/* 232 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 234 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern, int[] types) throws SQLException {
/* 239 */     ResultSet resultSet = this.delegate.getUDTs(catalog, schemaPattern, typeNamePattern, types);
/* 240 */     Statement statement = resultSet.getStatement();
/* 241 */     if (statement != null) {
/* 242 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 244 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getSuperTypes(String catalog, String schemaPattern, String typeNamePattern) throws SQLException {
/* 249 */     ResultSet resultSet = this.delegate.getSuperTypes(catalog, schemaPattern, typeNamePattern);
/* 250 */     Statement statement = resultSet.getStatement();
/* 251 */     if (statement != null) {
/* 252 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 254 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getSuperTables(String catalog, String schemaPattern, String tableNamePattern) throws SQLException {
/* 259 */     ResultSet resultSet = this.delegate.getSuperTables(catalog, schemaPattern, tableNamePattern);
/* 260 */     Statement statement = resultSet.getStatement();
/* 261 */     if (statement != null) {
/* 262 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 264 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getAttributes(String catalog, String schemaPattern, String typeNamePattern, String attributeNamePattern) throws SQLException {
/* 269 */     ResultSet resultSet = this.delegate.getAttributes(catalog, schemaPattern, typeNamePattern, attributeNamePattern);
/* 270 */     Statement statement = resultSet.getStatement();
/* 271 */     if (statement != null) {
/* 272 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 274 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getSchemas(String catalog, String schemaPattern) throws SQLException {
/* 279 */     ResultSet resultSet = this.delegate.getSchemas(catalog, schemaPattern);
/* 280 */     Statement statement = resultSet.getStatement();
/* 281 */     if (statement != null) {
/* 282 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 284 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getClientInfoProperties() throws SQLException {
/* 289 */     ResultSet resultSet = this.delegate.getClientInfoProperties();
/* 290 */     Statement statement = resultSet.getStatement();
/* 291 */     if (statement != null) {
/* 292 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 294 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getFunctions(String catalog, String schemaPattern, String functionNamePattern) throws SQLException {
/* 299 */     ResultSet resultSet = this.delegate.getFunctions(catalog, schemaPattern, functionNamePattern);
/* 300 */     Statement statement = resultSet.getStatement();
/* 301 */     if (statement != null) {
/* 302 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 304 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getFunctionColumns(String catalog, String schemaPattern, String functionNamePattern, String columnNamePattern) throws SQLException {
/* 309 */     ResultSet resultSet = this.delegate.getFunctionColumns(catalog, schemaPattern, functionNamePattern, columnNamePattern);
/* 310 */     Statement statement = resultSet.getStatement();
/* 311 */     if (statement != null) {
/* 312 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 314 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSet getPseudoColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern) throws SQLException {
/* 319 */     ResultSet resultSet = this.delegate.getPseudoColumns(catalog, schemaPattern, tableNamePattern, columnNamePattern);
/* 320 */     Statement statement = resultSet.getStatement();
/* 321 */     if (statement != null) {
/* 322 */       statement = ProxyFactory.getProxyStatement(this.connection, statement);
/*     */     }
/* 324 */     return ProxyFactory.getProxyResultSet(this.connection, (ProxyStatement)statement, resultSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 331 */     return (iface.isInstance(this.delegate) || (this.delegate != null && this.delegate.isWrapperFor(iface)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T unwrap(Class<T> iface) throws SQLException {
/* 339 */     if (iface.isInstance(this.delegate)) {
/* 340 */       return (T)this.delegate;
/*     */     }
/* 342 */     if (this.delegate != null) {
/* 343 */       return this.delegate.unwrap(iface);
/*     */     }
/*     */     
/* 346 */     throw new SQLException("Wrapped DatabaseMetaData is not an instance of " + iface);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\HikariCP-6.3.3.jar!\com\zaxxer\hikari\pool\ProxyDatabaseMetaData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */