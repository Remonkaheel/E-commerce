package org.springframework.cache;

import java.util.Collection;
import org.springframework.lang.Nullable;

public interface CacheManager {
  @Nullable
  Cache getCache(String paramString);
  
  Collection<String> getCacheNames();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\CacheManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */