/*     */ package org.springframework.cache.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.springframework.cache.interceptor.AbstractFallbackCacheOperationSource;
/*     */ import org.springframework.cache.interceptor.CacheOperation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationCacheOperationSource
/*     */   extends AbstractFallbackCacheOperationSource
/*     */   implements Serializable
/*     */ {
/*     */   private final Set<CacheAnnotationParser> annotationParsers;
/*     */   private boolean publicMethodsOnly = true;
/*     */   
/*     */   public AnnotationCacheOperationSource() {
/*  58 */     this.annotationParsers = Collections.singleton(new SpringCacheAnnotationParser());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationCacheOperationSource(boolean publicMethodsOnly) {
/*  70 */     this();
/*  71 */     this.publicMethodsOnly = publicMethodsOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationCacheOperationSource(CacheAnnotationParser annotationParser) {
/*  79 */     Assert.notNull(annotationParser, "CacheAnnotationParser must not be null");
/*  80 */     this.annotationParsers = Collections.singleton(annotationParser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationCacheOperationSource(CacheAnnotationParser... annotationParsers) {
/*  88 */     Assert.notEmpty((Object[])annotationParsers, "At least one CacheAnnotationParser needs to be specified");
/*  89 */     this.annotationParsers = Set.of(annotationParsers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationCacheOperationSource(Set<CacheAnnotationParser> annotationParsers) {
/*  97 */     Assert.notEmpty(annotationParsers, "At least one CacheAnnotationParser needs to be specified");
/*  98 */     this.annotationParsers = annotationParsers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPublicMethodsOnly(boolean publicMethodsOnly) {
/* 108 */     this.publicMethodsOnly = publicMethodsOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCandidateClass(Class<?> targetClass) {
/* 114 */     for (CacheAnnotationParser parser : this.annotationParsers) {
/* 115 */       if (parser.isCandidateClass(targetClass)) {
/* 116 */         return true;
/*     */       }
/*     */     } 
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Collection<CacheOperation> findCacheOperations(Class<?> clazz) {
/* 125 */     return determineCacheOperations(parser -> parser.parseCacheAnnotations(clazz));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Collection<CacheOperation> findCacheOperations(Method method) {
/* 131 */     return determineCacheOperations(parser -> parser.parseCacheAnnotations(method));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Collection<CacheOperation> determineCacheOperations(CacheOperationProvider provider) {
/* 145 */     Collection<CacheOperation> ops = null;
/* 146 */     for (CacheAnnotationParser parser : this.annotationParsers) {
/* 147 */       Collection<CacheOperation> annOps = provider.getCacheOperations(parser);
/* 148 */       if (annOps != null) {
/* 149 */         if (ops == null) {
/* 150 */           ops = annOps;
/*     */           continue;
/*     */         } 
/* 153 */         Collection<CacheOperation> combined = new ArrayList<>(ops.size() + annOps.size());
/* 154 */         combined.addAll(ops);
/* 155 */         combined.addAll(annOps);
/* 156 */         ops = combined;
/*     */       } 
/*     */     } 
/*     */     
/* 160 */     return ops;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean allowPublicMethodsOnly() {
/* 169 */     return this.publicMethodsOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 175 */     if (this != other) { if (other instanceof AnnotationCacheOperationSource) { AnnotationCacheOperationSource otherCos = (AnnotationCacheOperationSource)other; if (this.annotationParsers
/* 176 */           .equals(otherCos.annotationParsers) && this.publicMethodsOnly == otherCos.publicMethodsOnly); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   }
/*     */   public int hashCode() {
/* 182 */     return this.annotationParsers.hashCode();
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   protected static interface CacheOperationProvider {
/*     */     @Nullable
/*     */     Collection<CacheOperation> getCacheOperations(CacheAnnotationParser param1CacheAnnotationParser);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\annotation\AnnotationCacheOperationSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */