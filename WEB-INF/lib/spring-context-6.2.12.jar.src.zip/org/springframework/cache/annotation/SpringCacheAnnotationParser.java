/*     */ package org.springframework.cache.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.springframework.cache.interceptor.CacheEvictOperation;
/*     */ import org.springframework.cache.interceptor.CacheOperation;
/*     */ import org.springframework.cache.interceptor.CachePutOperation;
/*     */ import org.springframework.cache.interceptor.CacheableOperation;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringCacheAnnotationParser
/*     */   implements CacheAnnotationParser, Serializable
/*     */ {
/*  52 */   private static final Set<Class<? extends Annotation>> CACHE_OPERATION_ANNOTATIONS = (Set)Set.of(Cacheable.class, CacheEvict.class, CachePut.class, Caching.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCandidateClass(Class<?> targetClass) {
/*  57 */     return AnnotationUtils.isCandidateClass(targetClass, CACHE_OPERATION_ANNOTATIONS);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Collection<CacheOperation> parseCacheAnnotations(Class<?> type) {
/*  63 */     DefaultCacheConfig defaultConfig = new DefaultCacheConfig(type);
/*  64 */     return parseCacheAnnotations(defaultConfig, type);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Collection<CacheOperation> parseCacheAnnotations(Method method) {
/*  70 */     DefaultCacheConfig defaultConfig = new DefaultCacheConfig(method.getDeclaringClass());
/*  71 */     return parseCacheAnnotations(defaultConfig, method);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Collection<CacheOperation> parseCacheAnnotations(DefaultCacheConfig cachingConfig, AnnotatedElement ae) {
/*  76 */     Collection<CacheOperation> ops = parseCacheAnnotations(cachingConfig, ae, false);
/*  77 */     if (ops != null && ops.size() > 1) {
/*     */       
/*  79 */       Collection<CacheOperation> localOps = parseCacheAnnotations(cachingConfig, ae, true);
/*  80 */       if (localOps != null) {
/*  81 */         return localOps;
/*     */       }
/*     */     } 
/*  84 */     return ops;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Collection<CacheOperation> parseCacheAnnotations(DefaultCacheConfig cachingConfig, AnnotatedElement ae, boolean localOnly) {
/*  93 */     Collection<? extends Annotation> annotations = localOnly ? AnnotatedElementUtils.getAllMergedAnnotations(ae, CACHE_OPERATION_ANNOTATIONS) : AnnotatedElementUtils.findAllMergedAnnotations(ae, CACHE_OPERATION_ANNOTATIONS);
/*  94 */     if (annotations.isEmpty()) {
/*  95 */       return null;
/*     */     }
/*     */     
/*  98 */     Collection<CacheOperation> ops = new ArrayList<>(1);
/*  99 */     Objects.requireNonNull(Cacheable.class); Objects.requireNonNull(Cacheable.class); annotations.stream().filter(Cacheable.class::isInstance).map(Cacheable.class::cast).forEach(cacheable -> ops.add(parseCacheableAnnotation(ae, cachingConfig, cacheable)));
/*     */     
/* 101 */     Objects.requireNonNull(CacheEvict.class); Objects.requireNonNull(CacheEvict.class); annotations.stream().filter(CacheEvict.class::isInstance).map(CacheEvict.class::cast).forEach(cacheEvict -> ops.add(parseEvictAnnotation(ae, cachingConfig, cacheEvict)));
/*     */     
/* 103 */     Objects.requireNonNull(CachePut.class); Objects.requireNonNull(CachePut.class); annotations.stream().filter(CachePut.class::isInstance).map(CachePut.class::cast).forEach(cachePut -> ops.add(parsePutAnnotation(ae, cachingConfig, cachePut)));
/*     */     
/* 105 */     Objects.requireNonNull(Caching.class); Objects.requireNonNull(Caching.class); annotations.stream().filter(Caching.class::isInstance).map(Caching.class::cast).forEach(caching -> parseCachingAnnotation(ae, cachingConfig, caching, ops));
/*     */     
/* 107 */     return ops;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CacheableOperation parseCacheableAnnotation(AnnotatedElement ae, DefaultCacheConfig defaultConfig, Cacheable cacheable) {
/* 113 */     CacheableOperation.Builder builder = new CacheableOperation.Builder();
/*     */     
/* 115 */     builder.setName(ae.toString());
/* 116 */     builder.setCacheNames(cacheable.cacheNames());
/* 117 */     builder.setCondition(cacheable.condition());
/* 118 */     builder.setUnless(cacheable.unless());
/* 119 */     builder.setKey(cacheable.key());
/* 120 */     builder.setKeyGenerator(cacheable.keyGenerator());
/* 121 */     builder.setCacheManager(cacheable.cacheManager());
/* 122 */     builder.setCacheResolver(cacheable.cacheResolver());
/* 123 */     builder.setSync(cacheable.sync());
/*     */     
/* 125 */     defaultConfig.applyDefault((CacheOperation.Builder)builder);
/* 126 */     CacheableOperation op = builder.build();
/* 127 */     validateCacheOperation(ae, (CacheOperation)op);
/*     */     
/* 129 */     return op;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CacheEvictOperation parseEvictAnnotation(AnnotatedElement ae, DefaultCacheConfig defaultConfig, CacheEvict cacheEvict) {
/* 135 */     CacheEvictOperation.Builder builder = new CacheEvictOperation.Builder();
/*     */     
/* 137 */     builder.setName(ae.toString());
/* 138 */     builder.setCacheNames(cacheEvict.cacheNames());
/* 139 */     builder.setCondition(cacheEvict.condition());
/* 140 */     builder.setKey(cacheEvict.key());
/* 141 */     builder.setKeyGenerator(cacheEvict.keyGenerator());
/* 142 */     builder.setCacheManager(cacheEvict.cacheManager());
/* 143 */     builder.setCacheResolver(cacheEvict.cacheResolver());
/* 144 */     builder.setCacheWide(cacheEvict.allEntries());
/* 145 */     builder.setBeforeInvocation(cacheEvict.beforeInvocation());
/*     */     
/* 147 */     defaultConfig.applyDefault((CacheOperation.Builder)builder);
/* 148 */     CacheEvictOperation op = builder.build();
/* 149 */     validateCacheOperation(ae, (CacheOperation)op);
/*     */     
/* 151 */     return op;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CacheOperation parsePutAnnotation(AnnotatedElement ae, DefaultCacheConfig defaultConfig, CachePut cachePut) {
/* 157 */     CachePutOperation.Builder builder = new CachePutOperation.Builder();
/*     */     
/* 159 */     builder.setName(ae.toString());
/* 160 */     builder.setCacheNames(cachePut.cacheNames());
/* 161 */     builder.setCondition(cachePut.condition());
/* 162 */     builder.setUnless(cachePut.unless());
/* 163 */     builder.setKey(cachePut.key());
/* 164 */     builder.setKeyGenerator(cachePut.keyGenerator());
/* 165 */     builder.setCacheManager(cachePut.cacheManager());
/* 166 */     builder.setCacheResolver(cachePut.cacheResolver());
/*     */     
/* 168 */     defaultConfig.applyDefault((CacheOperation.Builder)builder);
/* 169 */     CachePutOperation op = builder.build();
/* 170 */     validateCacheOperation(ae, (CacheOperation)op);
/*     */     
/* 172 */     return (CacheOperation)op;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseCachingAnnotation(AnnotatedElement ae, DefaultCacheConfig defaultConfig, Caching caching, Collection<CacheOperation> ops) {
/* 178 */     Cacheable[] cacheables = caching.cacheable();
/* 179 */     for (Cacheable cacheable : cacheables) {
/* 180 */       ops.add(parseCacheableAnnotation(ae, defaultConfig, cacheable));
/*     */     }
/* 182 */     CacheEvict[] cacheEvicts = caching.evict();
/* 183 */     for (CacheEvict cacheEvict : cacheEvicts) {
/* 184 */       ops.add(parseEvictAnnotation(ae, defaultConfig, cacheEvict));
/*     */     }
/* 186 */     CachePut[] cachePuts = caching.put();
/* 187 */     for (CachePut cachePut : cachePuts) {
/* 188 */       ops.add(parsePutAnnotation(ae, defaultConfig, cachePut));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateCacheOperation(AnnotatedElement ae, CacheOperation operation) {
/* 202 */     if (StringUtils.hasText(operation.getKey()) && StringUtils.hasText(operation.getKeyGenerator())) {
/* 203 */       throw new IllegalStateException("Invalid cache annotation configuration on '" + ae
/* 204 */           .toString() + "'. Both 'key' and 'keyGenerator' attributes have been set. These attributes are mutually exclusive: either set the SpEL expression used tocompute the key at runtime or set the name of the KeyGenerator bean to use.");
/*     */     }
/*     */ 
/*     */     
/* 208 */     if (StringUtils.hasText(operation.getCacheManager()) && StringUtils.hasText(operation.getCacheResolver())) {
/* 209 */       throw new IllegalStateException("Invalid cache annotation configuration on '" + ae
/* 210 */           .toString() + "'. Both 'cacheManager' and 'cacheResolver' attributes have been set. These attributes are mutually exclusive: the cache manager is used to configure adefault cache resolver if none is set. If a cache resolver is set, the cache managerwon't be used.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 219 */     return other instanceof SpringCacheAnnotationParser;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 224 */     return SpringCacheAnnotationParser.class.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DefaultCacheConfig
/*     */   {
/*     */     private final Class<?> target;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private String[] cacheNames;
/*     */     
/*     */     @Nullable
/*     */     private String keyGenerator;
/*     */     
/*     */     @Nullable
/*     */     private String cacheManager;
/*     */     
/*     */     @Nullable
/*     */     private String cacheResolver;
/*     */     
/*     */     private boolean initialized = false;
/*     */ 
/*     */     
/*     */     public DefaultCacheConfig(Class<?> target) {
/* 250 */       this.target = target;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void applyDefault(CacheOperation.Builder builder) {
/* 258 */       if (!this.initialized) {
/* 259 */         CacheConfig annotation = (CacheConfig)AnnotatedElementUtils.findMergedAnnotation(this.target, CacheConfig.class);
/* 260 */         if (annotation != null) {
/* 261 */           this.cacheNames = annotation.cacheNames();
/* 262 */           this.keyGenerator = annotation.keyGenerator();
/* 263 */           this.cacheManager = annotation.cacheManager();
/* 264 */           this.cacheResolver = annotation.cacheResolver();
/*     */         } 
/* 266 */         this.initialized = true;
/*     */       } 
/*     */       
/* 269 */       if (builder.getCacheNames().isEmpty() && this.cacheNames != null) {
/* 270 */         builder.setCacheNames(this.cacheNames);
/*     */       }
/* 272 */       if (!StringUtils.hasText(builder.getKey()) && !StringUtils.hasText(builder.getKeyGenerator()) && 
/* 273 */         StringUtils.hasText(this.keyGenerator)) {
/* 274 */         builder.setKeyGenerator(this.keyGenerator);
/*     */       }
/*     */       
/* 277 */       if (!StringUtils.hasText(builder.getCacheManager()) && !StringUtils.hasText(builder.getCacheResolver()))
/*     */       {
/*     */         
/* 280 */         if (StringUtils.hasText(this.cacheResolver)) {
/* 281 */           builder.setCacheResolver(this.cacheResolver);
/*     */         }
/* 283 */         else if (StringUtils.hasText(this.cacheManager)) {
/* 284 */           builder.setCacheManager(this.cacheManager);
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\annotation\SpringCacheAnnotationParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */