/*     */ package org.springframework.cache.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.context.annotation.AdviceMode;
/*     */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*     */ import org.springframework.context.annotation.AutoProxyRegistrar;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachingConfigurationSelector
/*     */   extends AdviceModeImportSelector<EnableCaching>
/*     */ {
/*     */   private static final String PROXY_JCACHE_CONFIGURATION_CLASS = "org.springframework.cache.jcache.config.ProxyJCacheConfiguration";
/*     */   private static final String CACHE_ASPECT_CONFIGURATION_CLASS_NAME = "org.springframework.cache.aspectj.AspectJCachingConfiguration";
/*     */   private static final String JCACHE_ASPECT_CONFIGURATION_CLASS_NAME = "org.springframework.cache.aspectj.AspectJJCacheConfiguration";
/*     */   private static final boolean jsr107Present;
/*     */   private static final boolean jcacheImplPresent;
/*     */   
/*     */   static {
/*  58 */     ClassLoader classLoader = CachingConfigurationSelector.class.getClassLoader();
/*  59 */     jsr107Present = ClassUtils.isPresent("javax.cache.Cache", classLoader);
/*  60 */     jcacheImplPresent = ClassUtils.isPresent("org.springframework.cache.jcache.config.ProxyJCacheConfiguration", classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] selectImports(AdviceMode adviceMode) {
/*  71 */     switch (adviceMode) { default: throw new IncompatibleClassChangeError();case PROXY: case ASPECTJ: break; }  return 
/*     */       
/*  73 */       getAspectJImports();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getProxyImports() {
/*  82 */     List<String> result = new ArrayList<>(3);
/*  83 */     result.add(AutoProxyRegistrar.class.getName());
/*  84 */     result.add(ProxyCachingConfiguration.class.getName());
/*  85 */     if (jsr107Present && jcacheImplPresent) {
/*  86 */       result.add("org.springframework.cache.jcache.config.ProxyJCacheConfiguration");
/*     */     }
/*  88 */     return StringUtils.toStringArray(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getAspectJImports() {
/*  96 */     List<String> result = new ArrayList<>(2);
/*  97 */     result.add("org.springframework.cache.aspectj.AspectJCachingConfiguration");
/*  98 */     if (jsr107Present && jcacheImplPresent) {
/*  99 */       result.add("org.springframework.cache.aspectj.AspectJJCacheConfiguration");
/*     */     }
/* 101 */     return StringUtils.toStringArray(result);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\annotation\CachingConfigurationSelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */