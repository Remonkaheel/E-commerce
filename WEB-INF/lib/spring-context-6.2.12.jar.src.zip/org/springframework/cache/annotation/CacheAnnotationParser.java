/*    */ package org.springframework.cache.annotation;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Collection;
/*    */ import org.springframework.cache.interceptor.CacheOperation;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface CacheAnnotationParser
/*    */ {
/*    */   default boolean isCandidateClass(Class<?> targetClass) {
/* 55 */     return true;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   Collection<CacheOperation> parseCacheAnnotations(Class<?> paramClass);
/*    */   
/*    */   @Nullable
/*    */   Collection<CacheOperation> parseCacheAnnotations(Method paramMethod);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\annotation\CacheAnnotationParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */