/*    */ package org.springframework.cache.annotation;
/*    */ 
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.cache.interceptor.CacheErrorHandler;
/*    */ import org.springframework.cache.interceptor.CacheResolver;
/*    */ import org.springframework.cache.interceptor.KeyGenerator;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.0")
/*    */ public class CachingConfigurerSupport
/*    */   implements CachingConfigurer
/*    */ {
/*    */   @Nullable
/*    */   public CacheManager cacheManager() {
/* 40 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public CacheResolver cacheResolver() {
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public KeyGenerator keyGenerator() {
/* 52 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public CacheErrorHandler errorHandler() {
/* 58 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\annotation\CachingConfigurerSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */