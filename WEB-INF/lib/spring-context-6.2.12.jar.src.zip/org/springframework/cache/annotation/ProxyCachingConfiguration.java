/*    */ package org.springframework.cache.annotation;
/*    */ 
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.springframework.cache.interceptor.BeanFactoryCacheOperationSourceAdvisor;
/*    */ import org.springframework.cache.interceptor.CacheInterceptor;
/*    */ import org.springframework.cache.interceptor.CacheOperationSource;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Role(2)
/*    */ public class ProxyCachingConfiguration
/*    */   extends AbstractCachingConfiguration
/*    */ {
/*    */   @Bean(name = {"org.springframework.cache.config.internalCacheAdvisor"})
/*    */   @Role(2)
/*    */   public BeanFactoryCacheOperationSourceAdvisor cacheAdvisor(CacheOperationSource cacheOperationSource, CacheInterceptor cacheInterceptor) {
/* 47 */     BeanFactoryCacheOperationSourceAdvisor advisor = new BeanFactoryCacheOperationSourceAdvisor();
/* 48 */     advisor.setCacheOperationSource(cacheOperationSource);
/* 49 */     advisor.setAdvice((Advice)cacheInterceptor);
/* 50 */     if (this.enableCaching != null) {
/* 51 */       advisor.setOrder(((Integer)this.enableCaching.getNumber("order")).intValue());
/*    */     }
/* 53 */     return advisor;
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   public CacheOperationSource cacheOperationSource() {
/* 60 */     return (CacheOperationSource)new AnnotationCacheOperationSource(false);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   public CacheInterceptor cacheInterceptor(CacheOperationSource cacheOperationSource) {
/* 66 */     CacheInterceptor interceptor = new CacheInterceptor();
/* 67 */     interceptor.configure(this.errorHandler, this.keyGenerator, this.cacheResolver, this.cacheManager);
/* 68 */     interceptor.setCacheOperationSource(cacheOperationSource);
/* 69 */     return interceptor;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\annotation\ProxyCachingConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */