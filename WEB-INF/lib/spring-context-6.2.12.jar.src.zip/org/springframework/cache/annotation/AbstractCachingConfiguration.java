/*     */ package org.springframework.cache.annotation;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.cache.interceptor.CacheErrorHandler;
/*     */ import org.springframework.cache.interceptor.CacheResolver;
/*     */ import org.springframework.cache.interceptor.KeyGenerator;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ImportAware;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ public abstract class AbstractCachingConfiguration
/*     */   implements ImportAware
/*     */ {
/*     */   @Nullable
/*     */   protected AnnotationAttributes enableCaching;
/*     */   @Nullable
/*     */   protected Supplier<CacheManager> cacheManager;
/*     */   @Nullable
/*     */   protected Supplier<CacheResolver> cacheResolver;
/*     */   @Nullable
/*     */   protected Supplier<KeyGenerator> keyGenerator;
/*     */   @Nullable
/*     */   protected Supplier<CacheErrorHandler> errorHandler;
/*     */   
/*     */   public void setImportMetadata(AnnotationMetadata importMetadata) {
/*  68 */     this.enableCaching = AnnotationAttributes.fromMap(importMetadata
/*  69 */         .getAnnotationAttributes(EnableCaching.class.getName()));
/*  70 */     if (this.enableCaching == null) {
/*  71 */       throw new IllegalArgumentException("@EnableCaching is not present on importing class " + importMetadata
/*  72 */           .getClassName());
/*     */     }
/*     */   }
/*     */   
/*     */   @Autowired
/*     */   void setConfigurers(ObjectProvider<CachingConfigurer> configurers) {
/*  78 */     Supplier<CachingConfigurer> configurer = () -> {
/*     */         List<CachingConfigurer> candidates = configurers.stream().toList();
/*     */         
/*     */         if (CollectionUtils.isEmpty(candidates)) {
/*     */           return null;
/*     */         }
/*     */         
/*     */         if (candidates.size() > 1) {
/*     */           throw new IllegalStateException("" + candidates.size() + " implementations of CachingConfigurer were found when only 1 was expected. Refactor the configuration such that CachingConfigurer is implemented only once or not at all.");
/*     */         }
/*     */         
/*     */         return candidates.get(0);
/*     */       };
/*  91 */     useCachingConfigurer(new CachingConfigurerSupplier(configurer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void useCachingConfigurer(CachingConfigurerSupplier cachingConfigurerSupplier) {
/*  98 */     this.cacheManager = cachingConfigurerSupplier.adapt(CachingConfigurer::cacheManager);
/*  99 */     this.cacheResolver = cachingConfigurerSupplier.adapt(CachingConfigurer::cacheResolver);
/* 100 */     this.keyGenerator = cachingConfigurerSupplier.adapt(CachingConfigurer::keyGenerator);
/* 101 */     this.errorHandler = cachingConfigurerSupplier.adapt(CachingConfigurer::errorHandler);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static class CachingConfigurerSupplier
/*     */   {
/*     */     private final Supplier<CachingConfigurer> supplier;
/*     */     
/*     */     public CachingConfigurerSupplier(Supplier<CachingConfigurer> supplier) {
/* 110 */       this.supplier = (Supplier<CachingConfigurer>)SingletonSupplier.of(supplier);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public <T> Supplier<T> adapt(Function<CachingConfigurer, T> provider) {
/* 124 */       return () -> {
/*     */           CachingConfigurer cachingConfigurer = this.supplier.get();
/*     */           return (cachingConfigurer != null) ? provider.apply(cachingConfigurer) : null;
/*     */         };
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\annotation\AbstractCachingConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */