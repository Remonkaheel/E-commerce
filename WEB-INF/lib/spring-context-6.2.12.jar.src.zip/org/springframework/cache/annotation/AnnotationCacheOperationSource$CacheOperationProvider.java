package org.springframework.cache.annotation;

import java.util.Collection;
import org.springframework.cache.interceptor.CacheOperation;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface CacheOperationProvider {
  @Nullable
  Collection<CacheOperation> getCacheOperations(CacheAnnotationParser paramCacheAnnotationParser);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\annotation\AnnotationCacheOperationSource$CacheOperationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */