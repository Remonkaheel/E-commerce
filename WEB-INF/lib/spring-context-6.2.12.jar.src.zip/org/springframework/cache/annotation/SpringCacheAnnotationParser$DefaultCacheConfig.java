/*     */ package org.springframework.cache.annotation;
/*     */ 
/*     */ import org.springframework.cache.interceptor.CacheOperation;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultCacheConfig
/*     */ {
/*     */   private final Class<?> target;
/*     */   @Nullable
/*     */   private String[] cacheNames;
/*     */   @Nullable
/*     */   private String keyGenerator;
/*     */   @Nullable
/*     */   private String cacheManager;
/*     */   @Nullable
/*     */   private String cacheResolver;
/*     */   private boolean initialized = false;
/*     */   
/*     */   public DefaultCacheConfig(Class<?> target) {
/* 250 */     this.target = target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyDefault(CacheOperation.Builder builder) {
/* 258 */     if (!this.initialized) {
/* 259 */       CacheConfig annotation = (CacheConfig)AnnotatedElementUtils.findMergedAnnotation(this.target, CacheConfig.class);
/* 260 */       if (annotation != null) {
/* 261 */         this.cacheNames = annotation.cacheNames();
/* 262 */         this.keyGenerator = annotation.keyGenerator();
/* 263 */         this.cacheManager = annotation.cacheManager();
/* 264 */         this.cacheResolver = annotation.cacheResolver();
/*     */       } 
/* 266 */       this.initialized = true;
/*     */     } 
/*     */     
/* 269 */     if (builder.getCacheNames().isEmpty() && this.cacheNames != null) {
/* 270 */       builder.setCacheNames(this.cacheNames);
/*     */     }
/* 272 */     if (!StringUtils.hasText(builder.getKey()) && !StringUtils.hasText(builder.getKeyGenerator()) && 
/* 273 */       StringUtils.hasText(this.keyGenerator)) {
/* 274 */       builder.setKeyGenerator(this.keyGenerator);
/*     */     }
/*     */     
/* 277 */     if (!StringUtils.hasText(builder.getCacheManager()) && !StringUtils.hasText(builder.getCacheResolver()))
/*     */     {
/*     */       
/* 280 */       if (StringUtils.hasText(this.cacheResolver)) {
/* 281 */         builder.setCacheResolver(this.cacheResolver);
/*     */       }
/* 283 */       else if (StringUtils.hasText(this.cacheManager)) {
/* 284 */         builder.setCacheManager(this.cacheManager);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\annotation\SpringCacheAnnotationParser$DefaultCacheConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */