/*     */ package org.springframework.cache.config;
/*     */ 
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JCacheCachingConfigurer
/*     */ {
/*     */   private static void registerCacheAdvisor(Element element, ParserContext parserContext) {
/* 209 */     if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.cache.config.internalJCacheAdvisor")) {
/* 210 */       Object source = parserContext.extractSource(element);
/*     */ 
/*     */       
/* 213 */       RootBeanDefinition rootBeanDefinition1 = createJCacheOperationSourceBeanDefinition(element, source);
/* 214 */       String sourceName = parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)rootBeanDefinition1);
/*     */ 
/*     */       
/* 217 */       RootBeanDefinition interceptorDef = new RootBeanDefinition("org.springframework.cache.jcache.interceptor.JCacheInterceptor");
/*     */       
/* 219 */       interceptorDef.setSource(source);
/* 220 */       interceptorDef.setRole(2);
/* 221 */       interceptorDef.getPropertyValues().add("cacheOperationSource", new RuntimeBeanReference(sourceName));
/* 222 */       AnnotationDrivenCacheBeanDefinitionParser.parseErrorHandler(element, (BeanDefinition)interceptorDef);
/* 223 */       String interceptorName = parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)interceptorDef);
/*     */ 
/*     */       
/* 226 */       RootBeanDefinition advisorDef = new RootBeanDefinition("org.springframework.cache.jcache.interceptor.BeanFactoryJCacheOperationSourceAdvisor");
/*     */       
/* 228 */       advisorDef.setSource(source);
/* 229 */       advisorDef.setRole(2);
/* 230 */       advisorDef.getPropertyValues().add("cacheOperationSource", new RuntimeBeanReference(sourceName));
/* 231 */       advisorDef.getPropertyValues().add("adviceBeanName", interceptorName);
/* 232 */       if (element.hasAttribute("order")) {
/* 233 */         advisorDef.getPropertyValues().add("order", element.getAttribute("order"));
/*     */       }
/* 235 */       parserContext.getRegistry().registerBeanDefinition("org.springframework.cache.config.internalJCacheAdvisor", (BeanDefinition)advisorDef);
/*     */       
/* 237 */       CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), source);
/* 238 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)rootBeanDefinition1, sourceName));
/* 239 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)interceptorDef, interceptorName));
/* 240 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)advisorDef, "org.springframework.cache.config.internalJCacheAdvisor"));
/* 241 */       parserContext.registerComponent((ComponentDefinition)compositeDef);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void registerCacheAspect(Element element, ParserContext parserContext) {
/* 246 */     if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.cache.config.internalJCacheAspect")) {
/* 247 */       Object source = parserContext.extractSource(element);
/*     */       
/* 249 */       RootBeanDefinition rootBeanDefinition1 = createJCacheOperationSourceBeanDefinition(element, source);
/* 250 */       String cacheOperationSourceName = parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)rootBeanDefinition1);
/*     */       
/* 252 */       RootBeanDefinition jcacheAspectDef = new RootBeanDefinition();
/* 253 */       jcacheAspectDef.setBeanClassName("org.springframework.cache.aspectj.JCacheCacheAspect");
/* 254 */       jcacheAspectDef.setFactoryMethodName("aspectOf");
/* 255 */       jcacheAspectDef.getPropertyValues().add("cacheOperationSource", new RuntimeBeanReference(cacheOperationSourceName));
/* 256 */       parserContext.getRegistry().registerBeanDefinition("org.springframework.cache.config.internalJCacheAspect", (BeanDefinition)jcacheAspectDef);
/*     */       
/* 258 */       CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), source);
/* 259 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)rootBeanDefinition1, cacheOperationSourceName));
/* 260 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)jcacheAspectDef, "org.springframework.cache.config.internalJCacheAspect"));
/* 261 */       parserContext.registerComponent((ComponentDefinition)compositeDef);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static RootBeanDefinition createJCacheOperationSourceBeanDefinition(Element element, @Nullable Object eleSource) {
/* 266 */     RootBeanDefinition sourceDef = new RootBeanDefinition("org.springframework.cache.jcache.interceptor.DefaultJCacheOperationSource");
/*     */     
/* 268 */     sourceDef.setSource(eleSource);
/* 269 */     sourceDef.setRole(2);
/*     */ 
/*     */     
/* 272 */     AnnotationDrivenCacheBeanDefinitionParser.parseCacheResolution(element, (BeanDefinition)sourceDef, true);
/* 273 */     CacheNamespaceHandler.parseKeyGenerator(element, (BeanDefinition)sourceDef);
/* 274 */     return sourceDef;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\config\AnnotationDrivenCacheBeanDefinitionParser$JCacheCachingConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */