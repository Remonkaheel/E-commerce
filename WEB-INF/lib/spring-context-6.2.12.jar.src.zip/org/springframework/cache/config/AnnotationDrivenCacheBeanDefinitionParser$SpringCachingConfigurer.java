/*     */ package org.springframework.cache.config;
/*     */ 
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.cache.interceptor.BeanFactoryCacheOperationSourceAdvisor;
/*     */ import org.springframework.cache.interceptor.CacheInterceptor;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringCachingConfigurer
/*     */ {
/*     */   private static void registerCacheAdvisor(Element element, ParserContext parserContext) {
/* 143 */     if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.cache.config.internalCacheAdvisor")) {
/* 144 */       Object eleSource = parserContext.extractSource(element);
/*     */ 
/*     */       
/* 147 */       RootBeanDefinition sourceDef = new RootBeanDefinition("org.springframework.cache.annotation.AnnotationCacheOperationSource");
/* 148 */       sourceDef.setSource(eleSource);
/* 149 */       sourceDef.setRole(2);
/* 150 */       String sourceName = parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)sourceDef);
/*     */ 
/*     */       
/* 153 */       RootBeanDefinition interceptorDef = new RootBeanDefinition(CacheInterceptor.class);
/* 154 */       interceptorDef.setSource(eleSource);
/* 155 */       interceptorDef.setRole(2);
/* 156 */       AnnotationDrivenCacheBeanDefinitionParser.parseCacheResolution(element, (BeanDefinition)interceptorDef, false);
/* 157 */       AnnotationDrivenCacheBeanDefinitionParser.parseErrorHandler(element, (BeanDefinition)interceptorDef);
/* 158 */       CacheNamespaceHandler.parseKeyGenerator(element, (BeanDefinition)interceptorDef);
/* 159 */       interceptorDef.getPropertyValues().add("cacheOperationSources", new RuntimeBeanReference(sourceName));
/* 160 */       String interceptorName = parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)interceptorDef);
/*     */ 
/*     */       
/* 163 */       RootBeanDefinition advisorDef = new RootBeanDefinition(BeanFactoryCacheOperationSourceAdvisor.class);
/* 164 */       advisorDef.setSource(eleSource);
/* 165 */       advisorDef.setRole(2);
/* 166 */       advisorDef.getPropertyValues().add("cacheOperationSource", new RuntimeBeanReference(sourceName));
/* 167 */       advisorDef.getPropertyValues().add("adviceBeanName", interceptorName);
/* 168 */       if (element.hasAttribute("order")) {
/* 169 */         advisorDef.getPropertyValues().add("order", element.getAttribute("order"));
/*     */       }
/* 171 */       parserContext.getRegistry().registerBeanDefinition("org.springframework.cache.config.internalCacheAdvisor", (BeanDefinition)advisorDef);
/*     */       
/* 173 */       CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), eleSource);
/* 174 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)sourceDef, sourceName));
/* 175 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)interceptorDef, interceptorName));
/* 176 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)advisorDef, "org.springframework.cache.config.internalCacheAdvisor"));
/* 177 */       parserContext.registerComponent((ComponentDefinition)compositeDef);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registerCacheAspect(Element element, ParserContext parserContext) {
/* 191 */     if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.cache.config.internalCacheAspect")) {
/* 192 */       RootBeanDefinition def = new RootBeanDefinition();
/* 193 */       def.setBeanClassName("org.springframework.cache.aspectj.AnnotationCacheAspect");
/* 194 */       def.setFactoryMethodName("aspectOf");
/* 195 */       AnnotationDrivenCacheBeanDefinitionParser.parseCacheResolution(element, (BeanDefinition)def, false);
/* 196 */       CacheNamespaceHandler.parseKeyGenerator(element, (BeanDefinition)def);
/* 197 */       parserContext.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)def, "org.springframework.cache.config.internalCacheAspect"));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\config\AnnotationDrivenCacheBeanDefinitionParser$SpringCachingConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */