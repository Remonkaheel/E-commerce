package org.springframework.cache.config;

public abstract class CacheManagementConfigUtils {
  public static final String CACHE_ADVISOR_BEAN_NAME = "org.springframework.cache.config.internalCacheAdvisor";
  
  public static final String CACHE_ASPECT_BEAN_NAME = "org.springframework.cache.config.internalCacheAspect";
  
  public static final String JCACHE_ADVISOR_BEAN_NAME = "org.springframework.cache.config.internalJCacheAdvisor";
  
  public static final String JCACHE_ASPECT_BEAN_NAME = "org.springframework.cache.config.internalJCacheAspect";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\config\CacheManagementConfigUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */