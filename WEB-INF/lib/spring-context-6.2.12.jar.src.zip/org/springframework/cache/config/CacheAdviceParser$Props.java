/*     */ package org.springframework.cache.config;
/*     */ 
/*     */ import org.springframework.beans.factory.parsing.ReaderContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Props
/*     */ {
/*     */   private final String key;
/*     */   private final String keyGenerator;
/*     */   private final String cacheManager;
/*     */   private final String condition;
/*     */   private final String method;
/*     */   @Nullable
/*     */   private String[] caches;
/*     */   
/*     */   Props(Element root) {
/* 192 */     String defaultCache = root.getAttribute("cache");
/* 193 */     this.key = root.getAttribute("key");
/* 194 */     this.keyGenerator = root.getAttribute("key-generator");
/* 195 */     this.cacheManager = root.getAttribute("cache-manager");
/* 196 */     this.condition = root.getAttribute("condition");
/* 197 */     this.method = root.getAttribute("method");
/*     */     
/* 199 */     if (StringUtils.hasText(defaultCache)) {
/* 200 */       this.caches = StringUtils.commaDelimitedListToStringArray(defaultCache.trim());
/*     */     }
/*     */   }
/*     */   
/*     */   <T extends org.springframework.cache.interceptor.CacheOperation.Builder> T merge(Element element, ReaderContext readerCtx, T builder) {
/* 205 */     String cache = element.getAttribute("cache");
/*     */ 
/*     */     
/* 208 */     String[] localCaches = this.caches;
/* 209 */     if (StringUtils.hasText(cache)) {
/* 210 */       localCaches = StringUtils.commaDelimitedListToStringArray(cache.trim());
/*     */     }
/* 212 */     if (localCaches != null) {
/* 213 */       builder.setCacheNames(localCaches);
/*     */     } else {
/*     */       
/* 216 */       readerCtx.error("No cache specified for " + element.getNodeName(), element);
/*     */     } 
/*     */     
/* 219 */     builder.setKey(CacheAdviceParser.getAttributeValue(element, "key", this.key));
/* 220 */     builder.setKeyGenerator(CacheAdviceParser.getAttributeValue(element, "key-generator", this.keyGenerator));
/* 221 */     builder.setCacheManager(CacheAdviceParser.getAttributeValue(element, "cache-manager", this.cacheManager));
/* 222 */     builder.setCondition(CacheAdviceParser.getAttributeValue(element, "condition", this.condition));
/*     */     
/* 224 */     if (StringUtils.hasText(builder.getKey()) && StringUtils.hasText(builder.getKeyGenerator())) {
/* 225 */       throw new IllegalStateException("Invalid cache advice configuration on '" + element
/* 226 */           .toString() + "'. Both 'key' and 'keyGenerator' attributes have been set. These attributes are mutually exclusive: either set the SpEL expression used tocompute the key at runtime or set the name of the KeyGenerator bean to use.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 231 */     return builder;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   String merge(Element element, ReaderContext readerCtx) {
/* 236 */     String method = element.getAttribute("method");
/* 237 */     if (StringUtils.hasText(method)) {
/* 238 */       return method.trim();
/*     */     }
/* 240 */     if (StringUtils.hasText(this.method)) {
/* 241 */       return this.method;
/*     */     }
/* 243 */     readerCtx.error("No method specified for " + element.getNodeName(), element);
/* 244 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\config\CacheAdviceParser$Props.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */