/*     */ package org.springframework.cache.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.beans.factory.parsing.ReaderContext;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.cache.interceptor.CacheEvictOperation;
/*     */ import org.springframework.cache.interceptor.CacheInterceptor;
/*     */ import org.springframework.cache.interceptor.CacheOperation;
/*     */ import org.springframework.cache.interceptor.CachePutOperation;
/*     */ import org.springframework.cache.interceptor.CacheableOperation;
/*     */ import org.springframework.cache.interceptor.NameMatchCacheOperationSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CacheAdviceParser
/*     */   extends AbstractSingleBeanDefinitionParser
/*     */ {
/*     */   private static final String CACHEABLE_ELEMENT = "cacheable";
/*     */   private static final String CACHE_EVICT_ELEMENT = "cache-evict";
/*     */   private static final String CACHE_PUT_ELEMENT = "cache-put";
/*     */   private static final String METHOD_ATTRIBUTE = "method";
/*     */   private static final String DEFS_ELEMENT = "caching";
/*     */   
/*     */   protected Class<?> getBeanClass(Element element) {
/*  66 */     return CacheInterceptor.class;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
/*  71 */     builder.addPropertyReference("cacheManager", CacheNamespaceHandler.extractCacheManager(element));
/*  72 */     CacheNamespaceHandler.parseKeyGenerator(element, (BeanDefinition)builder.getBeanDefinition());
/*     */     
/*  74 */     List<Element> cacheDefs = DomUtils.getChildElementsByTagName(element, "caching");
/*  75 */     if (!cacheDefs.isEmpty()) {
/*     */       
/*  77 */       List<RootBeanDefinition> attributeSourceDefinitions = parseDefinitionsSources(cacheDefs, parserContext);
/*  78 */       builder.addPropertyValue("cacheOperationSources", attributeSourceDefinitions);
/*     */     }
/*     */     else {
/*     */       
/*  82 */       builder.addPropertyValue("cacheOperationSources", new RootBeanDefinition("org.springframework.cache.annotation.AnnotationCacheOperationSource"));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private List<RootBeanDefinition> parseDefinitionsSources(List<Element> definitions, ParserContext parserContext) {
/*  88 */     ManagedList<RootBeanDefinition> defs = new ManagedList(definitions.size());
/*     */ 
/*     */     
/*  91 */     for (Element element : definitions) {
/*  92 */       defs.add(parseDefinitionSource(element, parserContext));
/*     */     }
/*     */     
/*  95 */     return (List<RootBeanDefinition>)defs;
/*     */   }
/*     */   
/*     */   private RootBeanDefinition parseDefinitionSource(Element definition, ParserContext parserContext) {
/*  99 */     Props prop = new Props(definition);
/*     */ 
/*     */     
/* 102 */     ManagedMap<TypedStringValue, Collection<CacheOperation>> cacheOpMap = new ManagedMap();
/* 103 */     cacheOpMap.setSource(parserContext.extractSource(definition));
/*     */     
/* 105 */     List<Element> cacheableCacheMethods = DomUtils.getChildElementsByTagName(definition, "cacheable");
/*     */     
/* 107 */     for (Element opElement : cacheableCacheMethods) {
/* 108 */       String name = prop.merge(opElement, (ReaderContext)parserContext.getReaderContext());
/* 109 */       TypedStringValue nameHolder = new TypedStringValue(name);
/* 110 */       nameHolder.setSource(parserContext.extractSource(opElement));
/* 111 */       CacheableOperation.Builder builder = prop.<CacheableOperation.Builder>merge(opElement, (ReaderContext)parserContext
/* 112 */           .getReaderContext(), new CacheableOperation.Builder());
/* 113 */       builder.setUnless(getAttributeValue(opElement, "unless", ""));
/* 114 */       builder.setSync(Boolean.parseBoolean(getAttributeValue(opElement, "sync", "false")));
/*     */       
/* 116 */       Collection<CacheOperation> col = (Collection<CacheOperation>)cacheOpMap.computeIfAbsent(nameHolder, k -> new ArrayList(2));
/* 117 */       col.add(builder.build());
/*     */     } 
/*     */     
/* 120 */     List<Element> evictCacheMethods = DomUtils.getChildElementsByTagName(definition, "cache-evict");
/*     */     
/* 122 */     for (Element opElement : evictCacheMethods) {
/* 123 */       String name = prop.merge(opElement, (ReaderContext)parserContext.getReaderContext());
/* 124 */       TypedStringValue nameHolder = new TypedStringValue(name);
/* 125 */       nameHolder.setSource(parserContext.extractSource(opElement));
/* 126 */       CacheEvictOperation.Builder builder = prop.<CacheEvictOperation.Builder>merge(opElement, (ReaderContext)parserContext
/* 127 */           .getReaderContext(), new CacheEvictOperation.Builder());
/*     */       
/* 129 */       String wide = opElement.getAttribute("all-entries");
/* 130 */       if (StringUtils.hasText(wide)) {
/* 131 */         builder.setCacheWide(Boolean.parseBoolean(wide.trim()));
/*     */       }
/*     */       
/* 134 */       String after = opElement.getAttribute("before-invocation");
/* 135 */       if (StringUtils.hasText(after)) {
/* 136 */         builder.setBeforeInvocation(Boolean.parseBoolean(after.trim()));
/*     */       }
/*     */       
/* 139 */       Collection<CacheOperation> col = (Collection<CacheOperation>)cacheOpMap.computeIfAbsent(nameHolder, k -> new ArrayList(2));
/* 140 */       col.add(builder.build());
/*     */     } 
/*     */     
/* 143 */     List<Element> putCacheMethods = DomUtils.getChildElementsByTagName(definition, "cache-put");
/*     */     
/* 145 */     for (Element opElement : putCacheMethods) {
/* 146 */       String name = prop.merge(opElement, (ReaderContext)parserContext.getReaderContext());
/* 147 */       TypedStringValue nameHolder = new TypedStringValue(name);
/* 148 */       nameHolder.setSource(parserContext.extractSource(opElement));
/* 149 */       CachePutOperation.Builder builder = prop.<CachePutOperation.Builder>merge(opElement, (ReaderContext)parserContext
/* 150 */           .getReaderContext(), new CachePutOperation.Builder());
/* 151 */       builder.setUnless(getAttributeValue(opElement, "unless", ""));
/*     */       
/* 153 */       Collection<CacheOperation> col = (Collection<CacheOperation>)cacheOpMap.computeIfAbsent(nameHolder, k -> new ArrayList(2));
/* 154 */       col.add(builder.build());
/*     */     } 
/*     */     
/* 157 */     RootBeanDefinition attributeSourceDefinition = new RootBeanDefinition(NameMatchCacheOperationSource.class);
/* 158 */     attributeSourceDefinition.setSource(parserContext.extractSource(definition));
/* 159 */     attributeSourceDefinition.getPropertyValues().add("nameMap", cacheOpMap);
/* 160 */     return attributeSourceDefinition;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getAttributeValue(Element element, String attributeName, String defaultValue) {
/* 165 */     String attribute = element.getAttribute(attributeName);
/* 166 */     if (StringUtils.hasText(attribute)) {
/* 167 */       return attribute.trim();
/*     */     }
/* 169 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Props
/*     */   {
/*     */     private final String key;
/*     */ 
/*     */     
/*     */     private final String keyGenerator;
/*     */     
/*     */     private final String cacheManager;
/*     */     
/*     */     private final String condition;
/*     */     
/*     */     private final String method;
/*     */     
/*     */     @Nullable
/*     */     private String[] caches;
/*     */ 
/*     */     
/*     */     Props(Element root) {
/* 192 */       String defaultCache = root.getAttribute("cache");
/* 193 */       this.key = root.getAttribute("key");
/* 194 */       this.keyGenerator = root.getAttribute("key-generator");
/* 195 */       this.cacheManager = root.getAttribute("cache-manager");
/* 196 */       this.condition = root.getAttribute("condition");
/* 197 */       this.method = root.getAttribute("method");
/*     */       
/* 199 */       if (StringUtils.hasText(defaultCache)) {
/* 200 */         this.caches = StringUtils.commaDelimitedListToStringArray(defaultCache.trim());
/*     */       }
/*     */     }
/*     */     
/*     */     <T extends CacheOperation.Builder> T merge(Element element, ReaderContext readerCtx, T builder) {
/* 205 */       String cache = element.getAttribute("cache");
/*     */ 
/*     */       
/* 208 */       String[] localCaches = this.caches;
/* 209 */       if (StringUtils.hasText(cache)) {
/* 210 */         localCaches = StringUtils.commaDelimitedListToStringArray(cache.trim());
/*     */       }
/* 212 */       if (localCaches != null) {
/* 213 */         builder.setCacheNames(localCaches);
/*     */       } else {
/*     */         
/* 216 */         readerCtx.error("No cache specified for " + element.getNodeName(), element);
/*     */       } 
/*     */       
/* 219 */       builder.setKey(CacheAdviceParser.getAttributeValue(element, "key", this.key));
/* 220 */       builder.setKeyGenerator(CacheAdviceParser.getAttributeValue(element, "key-generator", this.keyGenerator));
/* 221 */       builder.setCacheManager(CacheAdviceParser.getAttributeValue(element, "cache-manager", this.cacheManager));
/* 222 */       builder.setCondition(CacheAdviceParser.getAttributeValue(element, "condition", this.condition));
/*     */       
/* 224 */       if (StringUtils.hasText(builder.getKey()) && StringUtils.hasText(builder.getKeyGenerator())) {
/* 225 */         throw new IllegalStateException("Invalid cache advice configuration on '" + element
/* 226 */             .toString() + "'. Both 'key' and 'keyGenerator' attributes have been set. These attributes are mutually exclusive: either set the SpEL expression used tocompute the key at runtime or set the name of the KeyGenerator bean to use.");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 231 */       return builder;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     String merge(Element element, ReaderContext readerCtx) {
/* 236 */       String method = element.getAttribute("method");
/* 237 */       if (StringUtils.hasText(method)) {
/* 238 */         return method.trim();
/*     */       }
/* 240 */       if (StringUtils.hasText(this.method)) {
/* 241 */         return this.method;
/*     */       }
/* 243 */       readerCtx.error("No method specified for " + element.getNodeName(), element);
/* 244 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\config\CacheAdviceParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */