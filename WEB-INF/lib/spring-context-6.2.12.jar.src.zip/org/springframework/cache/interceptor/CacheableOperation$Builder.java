/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Builder
/*    */   extends CacheOperation.Builder
/*    */ {
/*    */   @Nullable
/*    */   private String unless;
/*    */   private boolean sync;
/*    */   
/*    */   public void setUnless(String unless) {
/* 70 */     this.unless = unless;
/*    */   }
/*    */   
/*    */   public void setSync(boolean sync) {
/* 74 */     this.sync = sync;
/*    */   }
/*    */ 
/*    */   
/*    */   protected StringBuilder getOperationDescription() {
/* 79 */     StringBuilder sb = super.getOperationDescription();
/* 80 */     sb.append(" | unless='");
/* 81 */     sb.append(this.unless);
/* 82 */     sb.append('\'');
/* 83 */     sb.append(" | sync='");
/* 84 */     sb.append(this.sync);
/* 85 */     sb.append('\'');
/* 86 */     return sb;
/*    */   }
/*    */ 
/*    */   
/*    */   public CacheableOperation build() {
/* 91 */     return new CacheableOperation(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheableOperation$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */