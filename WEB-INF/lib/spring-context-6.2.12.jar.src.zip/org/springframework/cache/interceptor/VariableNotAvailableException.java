/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import org.springframework.expression.EvaluationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class VariableNotAvailableException
/*    */   extends EvaluationException
/*    */ {
/*    */   public VariableNotAvailableException(String name) {
/* 32 */     super("Variable '" + name + "' not available");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\VariableNotAvailableException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */