/*      */ package org.springframework.cache.interceptor;
/*      */ 
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.concurrent.CompletableFuture;
/*      */ import java.util.concurrent.CompletionStage;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.function.Supplier;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import org.springframework.aop.framework.AopProxyUtils;
/*      */ import org.springframework.aop.support.AopUtils;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryAware;
/*      */ import org.springframework.beans.factory.InitializingBean;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*      */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*      */ import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
/*      */ import org.springframework.cache.Cache;
/*      */ import org.springframework.cache.CacheManager;
/*      */ import org.springframework.context.expression.AnnotatedElementKey;
/*      */ import org.springframework.context.expression.BeanFactoryResolver;
/*      */ import org.springframework.core.BridgeMethodResolver;
/*      */ import org.springframework.core.KotlinDetector;
/*      */ import org.springframework.core.ReactiveAdapter;
/*      */ import org.springframework.core.ReactiveAdapterRegistry;
/*      */ import org.springframework.core.SpringProperties;
/*      */ import org.springframework.expression.BeanResolver;
/*      */ import org.springframework.expression.EvaluationContext;
/*      */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.LinkedMultiValueMap;
/*      */ import org.springframework.util.MultiValueMap;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.util.function.SingletonSupplier;
/*      */ import org.springframework.util.function.SupplierUtils;
/*      */ import reactor.core.publisher.Flux;
/*      */ import reactor.core.publisher.Mono;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class CacheAspectSupport
/*      */   extends AbstractCacheInvoker
/*      */   implements BeanFactoryAware, InitializingBean, SmartInitializingSingleton
/*      */ {
/*      */   public static final String IGNORE_REACTIVESTREAMS_PROPERTY_NAME = "spring.cache.reactivestreams.ignore";
/*  118 */   private static final boolean shouldIgnoreReactiveStreams = SpringProperties.getFlag("spring.cache.reactivestreams.ignore");
/*      */   
/*  120 */   private static final boolean reactiveStreamsPresent = ClassUtils.isPresent("org.reactivestreams.Publisher", CacheAspectSupport.class
/*  121 */       .getClassLoader());
/*      */ 
/*      */   
/*  124 */   protected final Log logger = LogFactory.getLog(getClass());
/*      */   
/*  126 */   private final Map<CacheOperationCacheKey, CacheOperationMetadata> metadataCache = new ConcurrentHashMap<>(1024);
/*      */   
/*  128 */   private final StandardEvaluationContext originalEvaluationContext = new StandardEvaluationContext();
/*      */   
/*  130 */   private final CacheOperationExpressionEvaluator evaluator = new CacheOperationExpressionEvaluator(new CacheEvaluationContextFactory(this.originalEvaluationContext));
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private final ReactiveCachingHandler reactiveCachingHandler;
/*      */   
/*      */   @Nullable
/*      */   private CacheOperationSource cacheOperationSource;
/*      */   
/*  139 */   private SingletonSupplier<KeyGenerator> keyGenerator = SingletonSupplier.of(SimpleKeyGenerator::new);
/*      */   
/*      */   @Nullable
/*      */   private SingletonSupplier<CacheResolver> cacheResolver;
/*      */   
/*      */   @Nullable
/*      */   private BeanFactory beanFactory;
/*      */   
/*      */   private boolean initialized = false;
/*      */ 
/*      */   
/*      */   protected CacheAspectSupport() {
/*  151 */     this
/*  152 */       .reactiveCachingHandler = (reactiveStreamsPresent && !shouldIgnoreReactiveStreams) ? new ReactiveCachingHandler() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void configure(@Nullable Supplier<CacheErrorHandler> errorHandler, @Nullable Supplier<KeyGenerator> keyGenerator, @Nullable Supplier<CacheResolver> cacheResolver, @Nullable Supplier<CacheManager> cacheManager) {
/*  165 */     this.errorHandler = new SingletonSupplier(errorHandler, SimpleCacheErrorHandler::new);
/*  166 */     this.keyGenerator = new SingletonSupplier(keyGenerator, SimpleKeyGenerator::new);
/*  167 */     this.cacheResolver = new SingletonSupplier(cacheResolver, () -> SimpleCacheResolver.of((CacheManager)SupplierUtils.resolve(cacheManager)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCacheOperationSources(CacheOperationSource... cacheOperationSources) {
/*  179 */     Assert.notEmpty((Object[])cacheOperationSources, "At least 1 CacheOperationSource needs to be specified");
/*  180 */     this
/*  181 */       .cacheOperationSource = (cacheOperationSources.length > 1) ? new CompositeCacheOperationSource(cacheOperationSources) : cacheOperationSources[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCacheOperationSource(@Nullable CacheOperationSource cacheOperationSource) {
/*  190 */     this.cacheOperationSource = cacheOperationSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public CacheOperationSource getCacheOperationSource() {
/*  198 */     return this.cacheOperationSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyGenerator(KeyGenerator keyGenerator) {
/*  207 */     this.keyGenerator = SingletonSupplier.of(keyGenerator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public KeyGenerator getKeyGenerator() {
/*  214 */     return (KeyGenerator)this.keyGenerator.obtain();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCacheResolver(@Nullable CacheResolver cacheResolver) {
/*  226 */     this.cacheResolver = SingletonSupplier.ofNullable(cacheResolver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public CacheResolver getCacheResolver() {
/*  234 */     return (CacheResolver)SupplierUtils.resolve((Supplier)this.cacheResolver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCacheManager(CacheManager cacheManager) {
/*  244 */     this.cacheResolver = SingletonSupplier.of(new SimpleCacheResolver(cacheManager));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBeanFactory(BeanFactory beanFactory) {
/*  254 */     this.beanFactory = beanFactory;
/*  255 */     this.originalEvaluationContext.setBeanResolver((BeanResolver)new BeanFactoryResolver(beanFactory));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterPropertiesSet() {
/*  261 */     Assert.state((getCacheOperationSource() != null), "The 'cacheOperationSources' property is required: If there are no cacheable methods, then don't use a cache aspect.");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterSingletonsInstantiated() {
/*  267 */     if (getCacheResolver() == null) {
/*      */       
/*  269 */       Assert.state((this.beanFactory != null), "CacheResolver or BeanFactory must be set on cache aspect");
/*      */       try {
/*  271 */         setCacheManager((CacheManager)this.beanFactory.getBean(CacheManager.class));
/*      */       }
/*  273 */       catch (NoUniqueBeanDefinitionException ex) {
/*  274 */         int numberOfBeansFound = ex.getNumberOfBeansFound();
/*  275 */         Collection<String> beanNamesFound = ex.getBeanNamesFound();
/*      */         
/*  277 */         StringBuilder message = new StringBuilder("no CacheResolver specified and expected single matching CacheManager but found ");
/*  278 */         message.append(numberOfBeansFound);
/*  279 */         if (beanNamesFound != null) {
/*  280 */           message.append(": ").append(StringUtils.collectionToCommaDelimitedString(beanNamesFound));
/*      */         }
/*  282 */         String exceptionMessage = message.toString();
/*      */         
/*  284 */         if (beanNamesFound != null) {
/*  285 */           throw new NoUniqueBeanDefinitionException(CacheManager.class, beanNamesFound, exceptionMessage);
/*      */         }
/*      */         
/*  288 */         throw new NoUniqueBeanDefinitionException(CacheManager.class, numberOfBeansFound, exceptionMessage);
/*      */       
/*      */       }
/*  291 */       catch (NoSuchBeanDefinitionException ex) {
/*  292 */         throw new NoSuchBeanDefinitionException(CacheManager.class, "no CacheResolver specified - register a CacheManager bean or remove the @EnableCaching annotation from your configuration.");
/*      */       } 
/*      */     } 
/*      */     
/*  296 */     this.initialized = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String methodIdentification(Method method, Class<?> targetClass) {
/*  310 */     Method specificMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/*  311 */     return ClassUtils.getQualifiedMethodName(specificMethod);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Collection<? extends Cache> getCaches(CacheOperationInvocationContext<CacheOperation> context, CacheResolver cacheResolver) {
/*  317 */     Collection<? extends Cache> caches = cacheResolver.resolveCaches(context);
/*  318 */     if (caches.isEmpty()) {
/*  319 */       throw new IllegalStateException("No cache could be resolved for '" + 
/*  320 */           String.valueOf(context.getOperation()) + "' using resolver '" + String.valueOf(cacheResolver) + "'. At least one cache should be provided per cache operation.");
/*      */     }
/*      */     
/*  323 */     return caches;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected CacheOperationContext getOperationContext(CacheOperation operation, Method method, Object[] args, Object target, Class<?> targetClass) {
/*  329 */     CacheOperationMetadata metadata = getCacheOperationMetadata(operation, method, targetClass);
/*  330 */     return new CacheOperationContext(metadata, args, target);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CacheOperationMetadata getCacheOperationMetadata(CacheOperation operation, Method method, Class<?> targetClass) {
/*  345 */     CacheOperationCacheKey cacheKey = new CacheOperationCacheKey(operation, method, targetClass);
/*  346 */     CacheOperationMetadata metadata = this.metadataCache.get(cacheKey);
/*  347 */     if (metadata == null) {
/*      */       KeyGenerator operationKeyGenerator; CacheResolver operationCacheResolver;
/*  349 */       if (StringUtils.hasText(operation.getKeyGenerator())) {
/*  350 */         operationKeyGenerator = getBean(operation.getKeyGenerator(), KeyGenerator.class);
/*      */       } else {
/*      */         
/*  353 */         operationKeyGenerator = getKeyGenerator();
/*      */       } 
/*      */       
/*  356 */       if (StringUtils.hasText(operation.getCacheResolver())) {
/*  357 */         operationCacheResolver = getBean(operation.getCacheResolver(), CacheResolver.class);
/*      */       }
/*  359 */       else if (StringUtils.hasText(operation.getCacheManager())) {
/*  360 */         CacheManager cacheManager = getBean(operation.getCacheManager(), CacheManager.class);
/*  361 */         operationCacheResolver = new SimpleCacheResolver(cacheManager);
/*      */       } else {
/*      */         
/*  364 */         operationCacheResolver = getCacheResolver();
/*  365 */         Assert.state((operationCacheResolver != null), "No CacheResolver/CacheManager set");
/*      */       } 
/*  367 */       metadata = new CacheOperationMetadata(operation, method, targetClass, operationKeyGenerator, operationCacheResolver);
/*      */       
/*  369 */       this.metadataCache.put(cacheKey, metadata);
/*      */     } 
/*  371 */     return metadata;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T> T getBean(String name, Class<T> serviceType) {
/*  386 */     if (this.beanFactory == null) {
/*  387 */       throw new IllegalStateException("BeanFactory must be set on cache aspect for " + serviceType
/*  388 */           .getSimpleName() + " retrieval");
/*      */     }
/*  390 */     return (T)BeanFactoryAnnotationUtils.qualifiedBeanOfType(this.beanFactory, serviceType, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clearMetadataCache() {
/*  397 */     this.metadataCache.clear();
/*  398 */     this.evaluator.clear();
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object execute(CacheOperationInvoker invoker, Object target, Method method, Object[] args) {
/*  404 */     if (this.initialized) {
/*  405 */       Class<?> targetClass = AopProxyUtils.ultimateTargetClass(target);
/*  406 */       CacheOperationSource cacheOperationSource = getCacheOperationSource();
/*  407 */       if (cacheOperationSource != null) {
/*  408 */         Collection<CacheOperation> operations = cacheOperationSource.getCacheOperations(method, targetClass);
/*  409 */         if (!CollectionUtils.isEmpty(operations)) {
/*  410 */           return execute(invoker, method, new CacheOperationContexts(operations, method, args, target, targetClass));
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  416 */     return invokeOperation(invoker);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object invokeOperation(CacheOperationInvoker invoker) {
/*  431 */     return invoker.invoke();
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private Object execute(CacheOperationInvoker invoker, Method method, CacheOperationContexts contexts) {
/*  436 */     if (contexts.isSynchronized())
/*      */     {
/*  438 */       return executeSynchronized(invoker, method, contexts);
/*      */     }
/*      */ 
/*      */     
/*  442 */     processCacheEvicts(contexts.get((Class)CacheEvictOperation.class), true, CacheOperationExpressionEvaluator.NO_RESULT);
/*      */ 
/*      */ 
/*      */     
/*  446 */     Object cacheHit = findCachedValue(invoker, method, contexts);
/*  447 */     if (cacheHit == null || cacheHit instanceof Cache.ValueWrapper) {
/*  448 */       return evaluate(cacheHit, invoker, method, contexts);
/*      */     }
/*  450 */     return cacheHit;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object executeSynchronized(CacheOperationInvoker invoker, Method method, CacheOperationContexts contexts) {
/*  456 */     CacheOperationContext context = contexts.get((Class)CacheableOperation.class).iterator().next();
/*  457 */     if (isConditionPassing(context, CacheOperationExpressionEvaluator.NO_RESULT)) {
/*  458 */       Object key = generateKey(context, CacheOperationExpressionEvaluator.NO_RESULT);
/*  459 */       Cache cache = context.getCaches().iterator().next();
/*  460 */       if (CompletableFuture.class.isAssignableFrom(method.getReturnType())) {
/*  461 */         AtomicBoolean invokeFailure = new AtomicBoolean(false);
/*  462 */         CompletableFuture<?> result = doRetrieve(cache, key, () -> {
/*      */               CompletableFuture<?> invokeResult = (CompletableFuture)invokeOperation(invoker);
/*      */ 
/*      */               
/*      */               if (invokeResult == null) {
/*      */                 throw new IllegalStateException("Returned CompletableFuture must not be null: " + String.valueOf(method));
/*      */               }
/*      */               
/*      */               return invokeResult.exceptionallyCompose(());
/*      */             });
/*      */         
/*  473 */         return result.exceptionallyCompose(ex -> {
/*      */               RuntimeException rex;
/*      */               
/*      */               if (ex instanceof RuntimeException) {
/*      */                 rex = (RuntimeException)ex;
/*      */               } else {
/*      */                 return CompletableFuture.failedFuture(ex);
/*      */               } 
/*      */               try {
/*      */                 getErrorHandler().handleCacheGetError(rex, cache, key);
/*      */                 return invokeFailure.get() ? CompletableFuture.failedFuture(ex) : (CompletableFuture)invokeOperation(invoker);
/*  484 */               } catch (Throwable ex2) {
/*      */                 return CompletableFuture.failedFuture(ex2);
/*      */               } 
/*      */             });
/*      */       } 
/*  489 */       if (this.reactiveCachingHandler != null) {
/*  490 */         Object returnValue = this.reactiveCachingHandler.executeSynchronized(invoker, method, cache, key);
/*  491 */         if (returnValue != ReactiveCachingHandler.NOT_HANDLED) {
/*  492 */           return returnValue;
/*      */         }
/*      */       } 
/*      */       try {
/*  496 */         return wrapCacheValue(method, doGet(cache, key, () -> unwrapReturnValue(invokeOperation(invoker))));
/*      */       }
/*  498 */       catch (org.springframework.cache.Cache.ValueRetrievalException ex) {
/*      */ 
/*      */         
/*  501 */         ReflectionUtils.rethrowRuntimeException(ex.getCause());
/*      */         
/*  503 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  508 */     return invokeOperation(invoker);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object findCachedValue(CacheOperationInvoker invoker, Method method, CacheOperationContexts contexts) {
/*  520 */     for (CacheOperationContext context : contexts.get((Class)CacheableOperation.class)) {
/*  521 */       if (isConditionPassing(context, CacheOperationExpressionEvaluator.NO_RESULT)) {
/*  522 */         Object key = generateKey(context, CacheOperationExpressionEvaluator.NO_RESULT);
/*  523 */         Object cached = findInCaches(context, key, invoker, method, contexts);
/*  524 */         if (cached != null) {
/*  525 */           if (this.logger.isTraceEnabled()) {
/*  526 */             this.logger.trace("Cache entry for key '" + String.valueOf(key) + "' found in cache(s) " + String.valueOf(context.getCacheNames()));
/*      */           }
/*  528 */           return cached;
/*      */         } 
/*      */         
/*  531 */         if (this.logger.isTraceEnabled()) {
/*  532 */           this.logger.trace("No cache entry for key '" + String.valueOf(key) + "' in cache(s) " + String.valueOf(context.getCacheNames()));
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  537 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object findInCaches(CacheOperationContext context, Object key, CacheOperationInvoker invoker, Method method, CacheOperationContexts contexts) {
/*  544 */     for (Cache cache : context.getCaches()) {
/*  545 */       if (CompletableFuture.class.isAssignableFrom(context.getMethod().getReturnType())) {
/*  546 */         CompletableFuture<?> completableFuture = doRetrieve(cache, key);
/*  547 */         if (completableFuture != null) {
/*  548 */           return completableFuture.exceptionallyCompose(ex -> {
/*      */                 RuntimeException rex; if (ex instanceof RuntimeException) {
/*      */                   rex = (RuntimeException)ex;
/*      */                 } else {
/*      */                   return CompletableFuture.failedFuture(ex);
/*      */                 }  try {
/*      */                   getErrorHandler().handleCacheGetError(rex, cache, key);
/*      */                   return CompletableFuture.completedFuture(null);
/*  556 */                 } catch (Throwable ex2) {
/*      */                   return CompletableFuture.failedFuture(ex2);
/*      */                 } 
/*  559 */               }).thenCompose(value -> (CompletableFuture)evaluate((value != null) ? CompletableFuture.<Object>completedFuture(unwrapCacheValue(value)) : null, invoker, method, contexts));
/*      */         }
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */ 
/*      */       
/*  567 */       if (this.reactiveCachingHandler != null) {
/*  568 */         Object returnValue = this.reactiveCachingHandler.findInCaches(context, cache, key, invoker, method, contexts);
/*      */         
/*  570 */         if (returnValue != ReactiveCachingHandler.NOT_HANDLED) {
/*  571 */           return returnValue;
/*      */         }
/*      */       } 
/*  574 */       Cache.ValueWrapper result = doGet(cache, key);
/*  575 */       if (result != null) {
/*  576 */         return result;
/*      */       }
/*      */     } 
/*  579 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object evaluate(@Nullable Object cacheHit, CacheOperationInvoker invoker, Method method, CacheOperationContexts contexts) {
/*      */     Object cacheValue, object1;
/*  587 */     if (contexts.processed) {
/*  588 */       return cacheHit;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  594 */     if (cacheHit != null && !hasCachePut(contexts)) {
/*      */       
/*  596 */       cacheValue = unwrapCacheValue(cacheHit);
/*  597 */       object1 = wrapCacheValue(method, cacheValue);
/*      */     }
/*      */     else {
/*      */       
/*  601 */       object1 = invokeOperation(invoker);
/*  602 */       cacheValue = unwrapReturnValue(object1);
/*      */     } 
/*      */ 
/*      */     
/*  606 */     List<CachePutRequest> cachePutRequests = new ArrayList<>(1);
/*  607 */     if (cacheHit == null) {
/*  608 */       collectPutRequests(contexts.get((Class)CacheableOperation.class), cacheValue, cachePutRequests);
/*      */     }
/*      */ 
/*      */     
/*  612 */     collectPutRequests(contexts.get((Class)CachePutOperation.class), cacheValue, cachePutRequests);
/*      */ 
/*      */     
/*  615 */     for (CachePutRequest cachePutRequest : cachePutRequests) {
/*  616 */       Object object = cachePutRequest.apply(cacheValue);
/*  617 */       if (object != null) {
/*  618 */         object1 = object;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  623 */     Object returnOverride = processCacheEvicts(contexts
/*  624 */         .get((Class)CacheEvictOperation.class), false, object1);
/*  625 */     if (returnOverride != null) {
/*  626 */       object1 = returnOverride;
/*      */     }
/*      */ 
/*      */     
/*  630 */     contexts.processed = true;
/*      */     
/*  632 */     return object1;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private Object unwrapCacheValue(@Nullable Object cacheValue) {
/*  637 */     Cache.ValueWrapper wrapper = (Cache.ValueWrapper)cacheValue; return (cacheValue instanceof Cache.ValueWrapper) ? wrapper.get() : cacheValue;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private Object wrapCacheValue(Method method, @Nullable Object cacheValue) {
/*  642 */     if (method.getReturnType() == Optional.class && (cacheValue == null || cacheValue
/*  643 */       .getClass() != Optional.class)) {
/*  644 */       return Optional.ofNullable(cacheValue);
/*      */     }
/*  646 */     return cacheValue;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private Object unwrapReturnValue(@Nullable Object returnValue) {
/*  651 */     return ObjectUtils.unwrapOptional(returnValue);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean hasCachePut(CacheOperationContexts contexts) {
/*  656 */     Collection<CacheOperationContext> cachePutContexts = contexts.get((Class)CachePutOperation.class);
/*  657 */     Collection<CacheOperationContext> excluded = new ArrayList<>(1);
/*  658 */     for (CacheOperationContext context : cachePutContexts) {
/*      */       try {
/*  660 */         if (!context.isConditionPassing(CacheOperationExpressionEvaluator.RESULT_UNAVAILABLE)) {
/*  661 */           excluded.add(context);
/*      */         }
/*      */       }
/*  664 */       catch (VariableNotAvailableException variableNotAvailableException) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  669 */     return (cachePutContexts.size() != excluded.size());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object processCacheEvicts(Collection<CacheOperationContext> contexts, boolean beforeInvocation, @Nullable Object result) {
/*  676 */     if (contexts.isEmpty()) {
/*  677 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  681 */     List<CacheOperationContext> applicable = contexts.stream().filter(context -> { CacheOperation patt26151$temp = context.metadata.operation; if (patt26151$temp instanceof CacheEvictOperation) { CacheEvictOperation evict = (CacheEvictOperation)patt26151$temp; if (beforeInvocation == evict.isBeforeInvocation()); }  return false; }).toList();
/*  682 */     if (applicable.isEmpty()) {
/*  683 */       return null;
/*      */     }
/*      */     
/*  686 */     if (result instanceof CompletableFuture) { CompletableFuture<?> future = (CompletableFuture)result;
/*  687 */       return future.whenComplete((value, ex) -> {
/*      */             if (ex == null) {
/*      */               performCacheEvicts(applicable, value);
/*      */             }
/*      */           }); }
/*      */     
/*  693 */     if (this.reactiveCachingHandler != null) {
/*  694 */       Object returnValue = this.reactiveCachingHandler.processCacheEvicts(applicable, result);
/*  695 */       if (returnValue != ReactiveCachingHandler.NOT_HANDLED) {
/*  696 */         return returnValue;
/*      */       }
/*      */     } 
/*  699 */     performCacheEvicts(applicable, result);
/*  700 */     return null;
/*      */   }
/*      */   
/*      */   private void performCacheEvicts(List<CacheOperationContext> contexts, @Nullable Object result) {
/*  704 */     for (CacheOperationContext context : contexts) {
/*  705 */       CacheEvictOperation operation = (CacheEvictOperation)context.metadata.operation;
/*  706 */       if (isConditionPassing(context, result)) {
/*  707 */         Object key = context.getGeneratedKey();
/*  708 */         for (Cache cache : context.getCaches()) {
/*  709 */           if (operation.isCacheWide()) {
/*  710 */             logInvalidating(context, operation, (Object)null);
/*  711 */             doClear(cache, operation.isBeforeInvocation());
/*      */             continue;
/*      */           } 
/*  714 */           if (key == null) {
/*  715 */             key = generateKey(context, result);
/*      */           }
/*  717 */           logInvalidating(context, operation, key);
/*  718 */           doEvict(cache, key, operation.isBeforeInvocation());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void logInvalidating(CacheOperationContext context, CacheEvictOperation operation, @Nullable Object key) {
/*  726 */     if (this.logger.isTraceEnabled()) {
/*  727 */       this.logger.trace("Invalidating " + ((key != null) ? ("cache key [" + String.valueOf(key) + "]") : "entire cache") + " for operation " + String.valueOf(operation) + " on method " + String.valueOf(context.metadata.method));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void collectPutRequests(Collection<CacheOperationContext> contexts, @Nullable Object result, Collection<CachePutRequest> putRequests) {
/*  742 */     for (CacheOperationContext context : contexts) {
/*  743 */       if (isConditionPassing(context, result)) {
/*  744 */         putRequests.add(new CachePutRequest(context));
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isConditionPassing(CacheOperationContext context, @Nullable Object result) {
/*  750 */     boolean passing = context.isConditionPassing(result);
/*  751 */     if (!passing && this.logger.isTraceEnabled()) {
/*  752 */       this.logger.trace("Cache condition failed on method " + String.valueOf(context.metadata.method) + " for operation " + String.valueOf(context.metadata.operation));
/*      */     }
/*      */     
/*  755 */     return passing;
/*      */   }
/*      */   
/*      */   private Object generateKey(CacheOperationContext context, @Nullable Object result) {
/*  759 */     Object key = context.generateKey(result);
/*  760 */     if (key == null) {
/*  761 */       throw new IllegalArgumentException("Null key returned for cache operation [%s]. If you are using named parameters, ensure that the compiler uses the '-parameters' flag."
/*      */ 
/*      */           
/*  764 */           .formatted(new Object[] { context.metadata.operation }));
/*      */     }
/*  766 */     if (this.logger.isTraceEnabled()) {
/*  767 */       this.logger.trace("Computed cache key '" + String.valueOf(key) + "' for operation " + String.valueOf(context.metadata.operation));
/*      */     }
/*  769 */     return key;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class CacheOperationContexts
/*      */   {
/*      */     private final MultiValueMap<Class<? extends CacheOperation>, CacheAspectSupport.CacheOperationContext> contexts;
/*      */     
/*      */     private final boolean sync;
/*      */     
/*      */     boolean processed;
/*      */ 
/*      */     
/*      */     public CacheOperationContexts(Collection<? extends CacheOperation> operations, Method method, Object[] args, Object target, Class<?> targetClass) {
/*  784 */       this.contexts = (MultiValueMap<Class<? extends CacheOperation>, CacheAspectSupport.CacheOperationContext>)new LinkedMultiValueMap(operations.size());
/*  785 */       for (CacheOperation op : operations) {
/*  786 */         this.contexts.add(op.getClass(), CacheAspectSupport.this.getOperationContext(op, method, args, target, targetClass));
/*      */       }
/*  788 */       this.sync = determineSyncFlag(method);
/*      */     }
/*      */     
/*      */     public Collection<CacheAspectSupport.CacheOperationContext> get(Class<? extends CacheOperation> operationClass) {
/*  792 */       Collection<CacheAspectSupport.CacheOperationContext> result = (Collection<CacheAspectSupport.CacheOperationContext>)this.contexts.get(operationClass);
/*  793 */       return (result != null) ? result : Collections.<CacheAspectSupport.CacheOperationContext>emptyList();
/*      */     }
/*      */     
/*      */     public boolean isSynchronized() {
/*  797 */       return this.sync;
/*      */     }
/*      */     
/*      */     private boolean determineSyncFlag(Method method) {
/*  801 */       List<CacheAspectSupport.CacheOperationContext> cacheableContexts = (List<CacheAspectSupport.CacheOperationContext>)this.contexts.get(CacheableOperation.class);
/*  802 */       if (cacheableContexts == null) {
/*  803 */         return false;
/*      */       }
/*  805 */       boolean syncEnabled = false;
/*  806 */       for (CacheAspectSupport.CacheOperationContext context : cacheableContexts) {
/*  807 */         CacheOperation cacheOperation = context.getOperation(); if (cacheOperation instanceof CacheableOperation) { CacheableOperation cacheable = (CacheableOperation)cacheOperation; if (cacheable.isSync()) {
/*  808 */             syncEnabled = true; break;
/*      */           }  }
/*      */       
/*      */       } 
/*  812 */       if (syncEnabled) {
/*  813 */         if (this.contexts.size() > 1) {
/*  814 */           throw new IllegalStateException("A sync=true operation cannot be combined with other cache operations on '" + String.valueOf(method) + "'");
/*      */         }
/*      */         
/*  817 */         if (cacheableContexts.size() > 1) {
/*  818 */           throw new IllegalStateException("Only one sync=true operation is allowed on '" + String.valueOf(method) + "'");
/*      */         }
/*      */         
/*  821 */         CacheAspectSupport.CacheOperationContext cacheableContext = cacheableContexts.iterator().next();
/*  822 */         CacheOperation operation = cacheableContext.getOperation();
/*  823 */         if (cacheableContext.getCaches().size() > 1) {
/*  824 */           throw new IllegalStateException("A sync=true operation is restricted to a single cache on '" + String.valueOf(operation) + "'");
/*      */         }
/*      */         
/*  827 */         if (operation instanceof CacheableOperation) { CacheableOperation cacheable = (CacheableOperation)operation; if (StringUtils.hasText(cacheable.getUnless())) {
/*  828 */             throw new IllegalStateException("A sync=true operation does not support the unless attribute on '" + String.valueOf(operation) + "'");
/*      */           } }
/*      */         
/*  831 */         return true;
/*      */       } 
/*  833 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class CacheOperationMetadata
/*      */   {
/*      */     private final CacheOperation operation;
/*      */ 
/*      */     
/*      */     private final Method method;
/*      */ 
/*      */     
/*      */     private final Class<?> targetClass;
/*      */ 
/*      */     
/*      */     private final Method targetMethod;
/*      */ 
/*      */     
/*      */     private final AnnotatedElementKey methodKey;
/*      */     
/*      */     private final KeyGenerator keyGenerator;
/*      */     
/*      */     private final CacheResolver cacheResolver;
/*      */ 
/*      */     
/*      */     public CacheOperationMetadata(CacheOperation operation, Method method, Class<?> targetClass, KeyGenerator keyGenerator, CacheResolver cacheResolver) {
/*  861 */       this.operation = operation;
/*  862 */       this.method = BridgeMethodResolver.findBridgedMethod(method);
/*  863 */       this.targetClass = targetClass;
/*  864 */       this
/*  865 */         .targetMethod = !Proxy.isProxyClass(targetClass) ? AopUtils.getMostSpecificMethod(method, targetClass) : this.method;
/*  866 */       this.methodKey = new AnnotatedElementKey(this.targetMethod, targetClass);
/*  867 */       this.keyGenerator = keyGenerator;
/*  868 */       this.cacheResolver = cacheResolver;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected class CacheOperationContext
/*      */     implements CacheOperationInvocationContext<CacheOperation>
/*      */   {
/*      */     private final CacheAspectSupport.CacheOperationMetadata metadata;
/*      */     
/*      */     private final Object[] args;
/*      */     
/*      */     private final Object target;
/*      */     
/*      */     private final Collection<? extends Cache> caches;
/*      */     
/*      */     private final Collection<String> cacheNames;
/*      */     
/*      */     @Nullable
/*      */     private Boolean conditionPassing;
/*      */     
/*      */     @Nullable
/*      */     private Object key;
/*      */ 
/*      */     
/*      */     public CacheOperationContext(CacheAspectSupport.CacheOperationMetadata metadata, Object[] args, Object target) {
/*  895 */       this.metadata = metadata;
/*  896 */       this.args = extractArgs(metadata.method, args);
/*  897 */       this.target = target;
/*  898 */       this.caches = CacheAspectSupport.this.getCaches(this, metadata.cacheResolver);
/*  899 */       this.cacheNames = prepareCacheNames(this.caches);
/*      */     }
/*      */ 
/*      */     
/*      */     public CacheOperation getOperation() {
/*  904 */       return this.metadata.operation;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getTarget() {
/*  909 */       return this.target;
/*      */     }
/*      */ 
/*      */     
/*      */     public Method getMethod() {
/*  914 */       return this.metadata.method;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] getArgs() {
/*  919 */       return this.args;
/*      */     }
/*      */     
/*      */     private Object[] extractArgs(Method method, Object[] args) {
/*  923 */       if (!method.isVarArgs()) {
/*  924 */         return args;
/*      */       }
/*  926 */       Object[] varArgs = ObjectUtils.toObjectArray(args[args.length - 1]);
/*  927 */       Object[] combinedArgs = new Object[args.length - 1 + varArgs.length];
/*  928 */       System.arraycopy(args, 0, combinedArgs, 0, args.length - 1);
/*  929 */       System.arraycopy(varArgs, 0, combinedArgs, args.length - 1, varArgs.length);
/*  930 */       return combinedArgs;
/*      */     }
/*      */     
/*      */     protected boolean isConditionPassing(@Nullable Object result) {
/*  934 */       if (this.conditionPassing == null) {
/*  935 */         if (StringUtils.hasText(this.metadata.operation.getCondition())) {
/*  936 */           EvaluationContext evaluationContext = createEvaluationContext(result);
/*  937 */           this.conditionPassing = Boolean.valueOf(CacheAspectSupport.this.evaluator.condition(this.metadata.operation.getCondition(), this.metadata.methodKey, evaluationContext));
/*      */         }
/*      */         else {
/*      */           
/*  941 */           this.conditionPassing = Boolean.valueOf(true);
/*      */         } 
/*      */       }
/*  944 */       return this.conditionPassing.booleanValue();
/*      */     }
/*      */     
/*      */     protected boolean canPutToCache(@Nullable Object value) {
/*  948 */       String unless = "";
/*  949 */       CacheOperation cacheOperation = this.metadata.operation; if (cacheOperation instanceof CacheableOperation) { CacheableOperation cacheableOperation = (CacheableOperation)cacheOperation;
/*  950 */         unless = cacheableOperation.getUnless(); }
/*      */       else
/*  952 */       { cacheOperation = this.metadata.operation; if (cacheOperation instanceof CachePutOperation) { CachePutOperation cachePutOperation = (CachePutOperation)cacheOperation;
/*  953 */           unless = cachePutOperation.getUnless(); }
/*      */          }
/*  955 */        if (StringUtils.hasText(unless)) {
/*  956 */         EvaluationContext evaluationContext = createEvaluationContext(value);
/*  957 */         return !CacheAspectSupport.this.evaluator.unless(unless, this.metadata.methodKey, evaluationContext);
/*      */       } 
/*  959 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     protected Object generateKey(@Nullable Object result) {
/*  967 */       if (StringUtils.hasText(this.metadata.operation.getKey())) {
/*  968 */         EvaluationContext evaluationContext = createEvaluationContext(result);
/*  969 */         this.key = CacheAspectSupport.this.evaluator.key(this.metadata.operation.getKey(), this.metadata.methodKey, evaluationContext);
/*      */       } else {
/*      */         
/*  972 */         this.key = this.metadata.keyGenerator.generate(this.target, this.metadata.method, this.args);
/*      */       } 
/*  974 */       return this.key;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     protected Object getGeneratedKey() {
/*  984 */       return this.key;
/*      */     }
/*      */     
/*      */     private EvaluationContext createEvaluationContext(@Nullable Object result) {
/*  988 */       return CacheAspectSupport.this.evaluator.createEvaluationContext(this.caches, this.metadata.method, this.args, this.target, this.metadata.targetClass, this.metadata.targetMethod, result);
/*      */     }
/*      */ 
/*      */     
/*      */     protected Collection<? extends Cache> getCaches() {
/*  993 */       return this.caches;
/*      */     }
/*      */     
/*      */     protected Collection<String> getCacheNames() {
/*  997 */       return this.cacheNames;
/*      */     }
/*      */     
/*      */     private Collection<String> prepareCacheNames(Collection<? extends Cache> caches) {
/* 1001 */       Collection<String> names = new ArrayList<>(caches.size());
/* 1002 */       for (Cache cache : caches) {
/* 1003 */         names.add(cache.getName());
/*      */       }
/* 1005 */       return names;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class CacheOperationCacheKey
/*      */     implements Comparable<CacheOperationCacheKey>
/*      */   {
/*      */     private final CacheOperation cacheOperation;
/*      */     private final AnnotatedElementKey methodCacheKey;
/*      */     
/*      */     private CacheOperationCacheKey(CacheOperation cacheOperation, Method method, Class<?> targetClass) {
/* 1017 */       this.cacheOperation = cacheOperation;
/* 1018 */       this.methodCacheKey = new AnnotatedElementKey(method, targetClass);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(@Nullable Object other) {
/* 1023 */       if (this != other) { if (other instanceof CacheOperationCacheKey) { CacheOperationCacheKey that = (CacheOperationCacheKey)other; if (this.cacheOperation
/* 1024 */             .equals(that.cacheOperation) && this.methodCacheKey
/* 1025 */             .equals(that.methodCacheKey)); }
/*      */         
/*      */         return false; }
/*      */     
/*      */     } public int hashCode() {
/* 1030 */       return this.cacheOperation.hashCode() * 31 + this.methodCacheKey.hashCode();
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1035 */       return String.valueOf(this.cacheOperation) + " on " + String.valueOf(this.cacheOperation);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(CacheOperationCacheKey other) {
/* 1040 */       int result = this.cacheOperation.getName().compareTo(other.cacheOperation.getName());
/* 1041 */       if (result == 0) {
/* 1042 */         result = this.methodCacheKey.compareTo(other.methodCacheKey);
/*      */       }
/* 1044 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class CachePutRequest
/*      */   {
/*      */     private final CacheAspectSupport.CacheOperationContext context;
/*      */     
/*      */     public CachePutRequest(CacheAspectSupport.CacheOperationContext context) {
/* 1054 */       this.context = context;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Object apply(@Nullable Object result) {
/* 1059 */       if (result instanceof CompletableFuture) { CompletableFuture<?> future = (CompletableFuture)result;
/* 1060 */         return future.whenComplete((value, ex) -> {
/*      */               if (ex == null) {
/*      */                 performCachePut(value);
/*      */               }
/*      */             }); }
/*      */       
/* 1066 */       if (CacheAspectSupport.this.reactiveCachingHandler != null) {
/* 1067 */         Object returnValue = CacheAspectSupport.this.reactiveCachingHandler.processPutRequest(this, result);
/* 1068 */         if (returnValue != CacheAspectSupport.ReactiveCachingHandler.NOT_HANDLED) {
/* 1069 */           return returnValue;
/*      */         }
/*      */       } 
/* 1072 */       performCachePut(result);
/* 1073 */       return null;
/*      */     }
/*      */     
/*      */     public void performCachePut(@Nullable Object value) {
/* 1077 */       if (this.context.canPutToCache(value)) {
/* 1078 */         Object key = this.context.getGeneratedKey();
/* 1079 */         if (key == null) {
/* 1080 */           key = CacheAspectSupport.this.generateKey(this.context, value);
/*      */         }
/* 1082 */         if (CacheAspectSupport.this.logger.isTraceEnabled()) {
/* 1083 */           CacheAspectSupport.this.logger.trace("Creating cache entry for key '" + String.valueOf(key) + "' in cache(s) " + 
/* 1084 */               String.valueOf(this.context.getCacheNames()));
/*      */         }
/* 1086 */         for (Cache cache : this.context.getCaches()) {
/* 1087 */           CacheAspectSupport.this.doPut(cache, key, value);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class CachePutListSubscriber
/*      */     implements Subscriber<Object>
/*      */   {
/*      */     private final CacheAspectSupport.CachePutRequest request;
/*      */ 
/*      */     
/* 1102 */     private final List<Object> cacheValue = new ArrayList();
/*      */     
/*      */     public CachePutListSubscriber(CacheAspectSupport.CachePutRequest request) {
/* 1105 */       this.request = request;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/* 1110 */       s.request(2147483647L);
/*      */     }
/*      */     
/*      */     public void onNext(Object o) {
/* 1114 */       this.cacheValue.add(o);
/*      */     }
/*      */     
/*      */     public void onError(Throwable t) {
/* 1118 */       this.cacheValue.clear();
/*      */     }
/*      */     
/*      */     public void onComplete() {
/* 1122 */       this.request.performCachePut(this.cacheValue);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class ReactiveCachingHandler
/*      */   {
/* 1132 */     public static final Object NOT_HANDLED = new Object();
/*      */     
/* 1134 */     private final ReactiveAdapterRegistry registry = ReactiveAdapterRegistry.getSharedInstance();
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object executeSynchronized(CacheOperationInvoker invoker, Method method, Cache cache, Object key) {
/* 1139 */       AtomicBoolean invokeFailure = new AtomicBoolean(false);
/* 1140 */       ReactiveAdapter adapter = this.registry.getAdapter(method.getReturnType());
/* 1141 */       if (adapter != null) {
/* 1142 */         if (adapter.isMultiValue())
/*      */         {
/* 1144 */           return adapter.fromPublisher((Publisher)Flux.from((Publisher)Mono.fromFuture(CacheAspectSupport.this
/* 1145 */                   .doRetrieve(cache, key, () -> Flux.from(adapter.toPublisher(CacheAspectSupport.this.invokeOperation(invoker))).collectList().doOnError(()).toFuture())))
/*      */               
/* 1147 */               .flatMap(Flux::fromIterable)
/* 1148 */               .onErrorResume(RuntimeException.class, ex -> {
/*      */                   try {
/*      */                     CacheAspectSupport.this.getErrorHandler().handleCacheGetError(ex, cache, key);
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/*      */                     return (Publisher)(invokeFailure.get() ? Flux.error(ex) : Flux.from(adapter.toPublisher(CacheAspectSupport.this.invokeOperation(invoker))));
/* 1156 */                   } catch (RuntimeException exception) {
/*      */                     return (Publisher)Flux.error(exception);
/*      */                   } 
/*      */                 }));
/*      */         }
/*      */ 
/*      */         
/* 1163 */         return adapter.fromPublisher((Publisher)Mono.fromFuture(CacheAspectSupport.this
/* 1164 */               .doRetrieve(cache, key, () -> Mono.from(adapter.toPublisher(CacheAspectSupport.this.invokeOperation(invoker))).doOnError(()).toFuture()))
/*      */             
/* 1166 */             .onErrorResume(RuntimeException.class, ex -> {
/*      */                 try {
/*      */                   CacheAspectSupport.this.getErrorHandler().handleCacheGetError(ex, cache, key);
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*      */                   return invokeFailure.get() ? Mono.error(ex) : Mono.from(adapter.toPublisher(CacheAspectSupport.this.invokeOperation(invoker)));
/* 1174 */                 } catch (RuntimeException exception) {
/*      */                   return Mono.error(exception);
/*      */                 } 
/*      */               }));
/*      */       } 
/*      */       
/* 1180 */       if (KotlinDetector.isKotlinReflectPresent() && KotlinDetector.isSuspendingFunction(method)) {
/* 1181 */         return Mono.fromFuture(CacheAspectSupport.this.doRetrieve(cache, key, () -> {
/*      */                 Mono<?> mono = (Mono)CacheAspectSupport.this.invokeOperation(invoker);
/*      */                 
/*      */                 if (mono != null) {
/*      */                   mono = mono.doOnError(());
/*      */                 } else {
/*      */                   mono = Mono.empty();
/*      */                 } 
/*      */                 return mono.toFuture();
/* 1190 */               })).onErrorResume(RuntimeException.class, ex -> {
/*      */               try {
/*      */                 CacheAspectSupport.this.getErrorHandler().handleCacheGetError(ex, cache, key);
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 return invokeFailure.get() ? Mono.error(ex) : (Mono)CacheAspectSupport.this.invokeOperation(invoker);
/* 1198 */               } catch (RuntimeException exception) {
/*      */                 return Mono.error(exception);
/*      */               } 
/*      */             });
/*      */       }
/* 1203 */       return NOT_HANDLED;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Object processCacheEvicts(List<CacheAspectSupport.CacheOperationContext> contexts, @Nullable Object result) {
/* 1208 */       ReactiveAdapter adapter = (result != null) ? this.registry.getAdapter(result.getClass()) : null;
/* 1209 */       if (adapter != null) {
/* 1210 */         return adapter.fromPublisher((Publisher)Mono.from(adapter.toPublisher(result))
/* 1211 */             .doOnSuccess(value -> CacheAspectSupport.this.performCacheEvicts(contexts, value)));
/*      */       }
/* 1213 */       return NOT_HANDLED;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object findInCaches(CacheAspectSupport.CacheOperationContext context, Cache cache, Object key, CacheOperationInvoker invoker, Method method, CacheAspectSupport.CacheOperationContexts contexts) {
/* 1221 */       ReactiveAdapter adapter = this.registry.getAdapter(context.getMethod().getReturnType());
/* 1222 */       if (adapter != null) {
/* 1223 */         CompletableFuture<?> cachedFuture = CacheAspectSupport.this.doRetrieve(cache, key);
/* 1224 */         if (cachedFuture == null) {
/* 1225 */           return null;
/*      */         }
/* 1227 */         if (adapter.isMultiValue()) {
/* 1228 */           return adapter.fromPublisher((Publisher)Flux.from((Publisher)Mono.fromFuture(cachedFuture))
/* 1229 */               .switchIfEmpty((Publisher)Flux.defer(() -> (Publisher)CacheAspectSupport.this.evaluate(null, invoker, method, contexts)))
/* 1230 */               .flatMap(v -> CacheAspectSupport.this.evaluate(valueToFlux(v, contexts), invoker, method, contexts))
/* 1231 */               .onErrorResume(RuntimeException.class, ex -> {
/*      */                   try {
/*      */                     CacheAspectSupport.this.getErrorHandler().handleCacheGetError((RuntimeException)ex, cache, key);
/*      */                     
/*      */                     Object e = CacheAspectSupport.this.evaluate(null, invoker, method, contexts);
/*      */                     return (e != null) ? e : Flux.error((RuntimeException)ex);
/* 1237 */                   } catch (RuntimeException exception) {
/*      */                     return Flux.error(exception);
/*      */                   } 
/*      */                 }));
/*      */         }
/*      */         
/* 1243 */         return adapter.fromPublisher((Publisher)Mono.fromFuture(cachedFuture)
/* 1244 */             .switchIfEmpty(Mono.defer(() -> (Mono)CacheAspectSupport.this.evaluate(null, invoker, method, contexts)))
/* 1245 */             .flatMap(v -> CacheAspectSupport.this.evaluate(Mono.justOrEmpty(CacheAspectSupport.this.unwrapCacheValue(v)), invoker, method, contexts))
/* 1246 */             .onErrorResume(RuntimeException.class, ex -> {
/*      */                 try {
/*      */                   CacheAspectSupport.this.getErrorHandler().handleCacheGetError((RuntimeException)ex, cache, key);
/*      */                   
/*      */                   Object e = CacheAspectSupport.this.evaluate(null, invoker, method, contexts);
/*      */                   return (e != null) ? e : Mono.error((RuntimeException)ex);
/* 1252 */                 } catch (RuntimeException exception) {
/*      */                   return Mono.error(exception);
/*      */                 } 
/*      */               }));
/*      */       } 
/*      */       
/* 1258 */       return NOT_HANDLED;
/*      */     }
/*      */     
/*      */     private Flux<?> valueToFlux(Object value, CacheAspectSupport.CacheOperationContexts contexts) {
/* 1262 */       Object data = CacheAspectSupport.this.unwrapCacheValue(value);
/* 1263 */       Iterable<?> iterable = (Iterable)data; return (!contexts.processed && data instanceof Iterable) ? Flux.fromIterable(iterable) : (
/* 1264 */         (data != null) ? Flux.just(data) : Flux.empty());
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Object processPutRequest(CacheAspectSupport.CachePutRequest request, @Nullable Object result) {
/* 1269 */       ReactiveAdapter adapter = (result != null) ? this.registry.getAdapter(result.getClass()) : null;
/* 1270 */       if (adapter != null) {
/* 1271 */         if (adapter.isMultiValue()) {
/*      */           
/* 1273 */           Flux<?> source = Flux.from(adapter.toPublisher(result)).publish().refCount(2);
/* 1274 */           source.subscribe(new CacheAspectSupport.CachePutListSubscriber(request));
/* 1275 */           return adapter.fromPublisher((Publisher)source);
/*      */         } 
/*      */ 
/*      */         
/* 1279 */         Objects.requireNonNull(request); return adapter.fromPublisher((Publisher)Mono.from(adapter.toPublisher(result)).doOnSuccess(request::performCachePut));
/*      */       } 
/*      */       
/* 1282 */       return NOT_HANDLED;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheAspectSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */