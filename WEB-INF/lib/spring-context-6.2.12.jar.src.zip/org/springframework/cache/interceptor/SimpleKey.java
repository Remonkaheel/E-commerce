/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleKey
/*    */   implements Serializable
/*    */ {
/* 41 */   public static final SimpleKey EMPTY = new SimpleKey(new Object[0]);
/*    */ 
/*    */ 
/*    */   
/*    */   private final Object[] params;
/*    */ 
/*    */ 
/*    */   
/*    */   private transient int hashCode;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SimpleKey(Object... elements) {
/* 55 */     Assert.notNull(elements, "Elements must not be null");
/* 56 */     this.params = (Object[])elements.clone();
/*    */     
/* 58 */     this.hashCode = Arrays.deepHashCode(this.params);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 64 */     if (this != other) { if (other instanceof SimpleKey) { SimpleKey that = (SimpleKey)other; if (Arrays.deepEquals(this.params, that.params)); }  return false; }
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   public final int hashCode() {
/* 70 */     return this.hashCode;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 75 */     return getClass().getSimpleName() + " " + getClass().getSimpleName();
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 79 */     ois.defaultReadObject();
/*    */     
/* 81 */     this.hashCode = Arrays.deepHashCode(this.params);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\SimpleKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */