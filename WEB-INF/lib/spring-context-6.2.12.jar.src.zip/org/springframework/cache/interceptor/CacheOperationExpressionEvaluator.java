/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.context.expression.AnnotatedElementKey;
/*     */ import org.springframework.context.expression.CachedExpressionEvaluator;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CacheOperationExpressionEvaluator
/*     */   extends CachedExpressionEvaluator
/*     */ {
/*  49 */   public static final Object NO_RESULT = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final Object RESULT_UNAVAILABLE = new Object();
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String RESULT_VARIABLE = "result";
/*     */ 
/*     */ 
/*     */   
/*  62 */   private final Map<CachedExpressionEvaluator.ExpressionKey, Expression> keyCache = new ConcurrentHashMap<>(64);
/*     */   
/*  64 */   private final Map<CachedExpressionEvaluator.ExpressionKey, Expression> conditionCache = new ConcurrentHashMap<>(64);
/*     */   
/*  66 */   private final Map<CachedExpressionEvaluator.ExpressionKey, Expression> unlessCache = new ConcurrentHashMap<>(64);
/*     */   
/*     */   private final CacheEvaluationContextFactory evaluationContextFactory;
/*     */ 
/*     */   
/*     */   public CacheOperationExpressionEvaluator(CacheEvaluationContextFactory evaluationContextFactory) {
/*  72 */     this.evaluationContextFactory = evaluationContextFactory;
/*  73 */     this.evaluationContextFactory.setParameterNameDiscoverer(() -> rec$.getParameterNameDiscoverer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EvaluationContext createEvaluationContext(Collection<? extends Cache> caches, Method method, Object[] args, Object target, Class<?> targetClass, Method targetMethod, @Nullable Object result) {
/*  91 */     CacheExpressionRootObject rootObject = new CacheExpressionRootObject(caches, method, args, target, targetClass);
/*     */ 
/*     */     
/*  94 */     CacheEvaluationContext evaluationContext = this.evaluationContextFactory.forOperation(rootObject, targetMethod, args);
/*  95 */     if (result == RESULT_UNAVAILABLE) {
/*  96 */       evaluationContext.addUnavailableVariable("result");
/*     */     }
/*  98 */     else if (result != NO_RESULT) {
/*  99 */       evaluationContext.setVariable("result", result);
/*     */     } 
/* 101 */     return (EvaluationContext)evaluationContext;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Object key(String keyExpression, AnnotatedElementKey methodKey, EvaluationContext evalContext) {
/* 106 */     return getExpression(this.keyCache, methodKey, keyExpression).getValue(evalContext);
/*     */   }
/*     */   
/*     */   public boolean condition(String conditionExpression, AnnotatedElementKey methodKey, EvaluationContext evalContext) {
/* 110 */     return Boolean.TRUE.equals(getExpression(this.conditionCache, methodKey, conditionExpression).getValue(evalContext, Boolean.class));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean unless(String unlessExpression, AnnotatedElementKey methodKey, EvaluationContext evalContext) {
/* 115 */     return Boolean.TRUE.equals(getExpression(this.unlessCache, methodKey, unlessExpression).getValue(evalContext, Boolean.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear() {
/* 123 */     this.keyCache.clear();
/* 124 */     this.conditionCache.clear();
/* 125 */     this.unlessCache.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheOperationExpressionEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */