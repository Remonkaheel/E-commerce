/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamedCacheResolver
/*    */   extends AbstractCacheResolver
/*    */ {
/*    */   @Nullable
/*    */   private Collection<String> cacheNames;
/*    */   
/*    */   public NamedCacheResolver() {}
/*    */   
/*    */   public NamedCacheResolver(CacheManager cacheManager, String... cacheNames) {
/* 42 */     super(cacheManager);
/* 43 */     this.cacheNames = List.of(cacheNames);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCacheNames(Collection<String> cacheNames) {
/* 51 */     this.cacheNames = cacheNames;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   protected Collection<String> getCacheNames(CacheOperationInvocationContext<?> context) {
/* 57 */     return this.cacheNames;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\NamedCacheResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */