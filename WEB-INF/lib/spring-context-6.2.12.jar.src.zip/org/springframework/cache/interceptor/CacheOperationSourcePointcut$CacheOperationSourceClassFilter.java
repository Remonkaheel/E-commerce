/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CacheOperationSourceClassFilter
/*     */   implements ClassFilter
/*     */ {
/*     */   public boolean matches(Class<?> clazz) {
/*  84 */     if (CacheManager.class.isAssignableFrom(clazz)) {
/*  85 */       return false;
/*     */     }
/*  87 */     return (CacheOperationSourcePointcut.this.cacheOperationSource == null || CacheOperationSourcePointcut.this.cacheOperationSource.isCandidateClass(clazz));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private CacheOperationSource getCacheOperationSource() {
/*  92 */     return CacheOperationSourcePointcut.this.cacheOperationSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  97 */     if (this != other) { if (other instanceof CacheOperationSourceClassFilter) { CacheOperationSourceClassFilter that = (CacheOperationSourceClassFilter)other;
/*  98 */         if (ObjectUtils.nullSafeEquals(getCacheOperationSource(), that.getCacheOperationSource())); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 103 */     return CacheOperationSourceClassFilter.class.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 108 */     return CacheOperationSourceClassFilter.class.getName() + ": " + CacheOperationSourceClassFilter.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheOperationSourcePointcut$CacheOperationSourceClassFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */