/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface CacheOperationInvoker
/*    */ {
/*    */   @Nullable
/*    */   Object invoke() throws ThrowableWrapper;
/*    */   
/*    */   public static class ThrowableWrapper
/*    */     extends RuntimeException
/*    */   {
/*    */     private final Throwable original;
/*    */     
/*    */     public ThrowableWrapper(Throwable original) {
/* 54 */       super(original.getMessage(), original);
/* 55 */       this.original = original;
/*    */     }
/*    */     
/*    */     public Throwable getOriginal() {
/* 59 */       return this.original;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheOperationInvoker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */