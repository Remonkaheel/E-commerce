/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Builder
/*     */ {
/* 136 */   private String name = "";
/*     */   
/* 138 */   private Set<String> cacheNames = Collections.emptySet();
/*     */   
/* 140 */   private String key = "";
/*     */   
/* 142 */   private String keyGenerator = "";
/*     */   
/* 144 */   private String cacheManager = "";
/*     */   
/* 146 */   private String cacheResolver = "";
/*     */   
/* 148 */   private String condition = "";
/*     */   
/*     */   public void setName(String name) {
/* 151 */     Assert.hasText(name, "Name must not be empty");
/* 152 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setCacheName(String cacheName) {
/* 156 */     Assert.hasText(cacheName, "Cache name must not be empty");
/* 157 */     this.cacheNames = Collections.singleton(cacheName);
/*     */   }
/*     */   
/*     */   public void setCacheNames(String... cacheNames) {
/* 161 */     this.cacheNames = CollectionUtils.newLinkedHashSet(cacheNames.length);
/* 162 */     for (String cacheName : cacheNames) {
/* 163 */       Assert.hasText(cacheName, "Cache name must be non-empty if specified");
/* 164 */       this.cacheNames.add(cacheName);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Set<String> getCacheNames() {
/* 169 */     return this.cacheNames;
/*     */   }
/*     */   
/*     */   public void setKey(String key) {
/* 173 */     Assert.notNull(key, "Key must not be null");
/* 174 */     this.key = key;
/*     */   }
/*     */   
/*     */   public String getKey() {
/* 178 */     return this.key;
/*     */   }
/*     */   
/*     */   public String getKeyGenerator() {
/* 182 */     return this.keyGenerator;
/*     */   }
/*     */   
/*     */   public String getCacheManager() {
/* 186 */     return this.cacheManager;
/*     */   }
/*     */   
/*     */   public String getCacheResolver() {
/* 190 */     return this.cacheResolver;
/*     */   }
/*     */   
/*     */   public void setKeyGenerator(String keyGenerator) {
/* 194 */     Assert.notNull(keyGenerator, "KeyGenerator name must not be null");
/* 195 */     this.keyGenerator = keyGenerator;
/*     */   }
/*     */   
/*     */   public void setCacheManager(String cacheManager) {
/* 199 */     Assert.notNull(cacheManager, "CacheManager name must not be null");
/* 200 */     this.cacheManager = cacheManager;
/*     */   }
/*     */   
/*     */   public void setCacheResolver(String cacheResolver) {
/* 204 */     Assert.notNull(cacheResolver, "CacheResolver name must not be null");
/* 205 */     this.cacheResolver = cacheResolver;
/*     */   }
/*     */   
/*     */   public void setCondition(String condition) {
/* 209 */     Assert.notNull(condition, "Condition must not be null");
/* 210 */     this.condition = condition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringBuilder getOperationDescription() {
/* 218 */     StringBuilder result = new StringBuilder(getClass().getSimpleName());
/* 219 */     result.append('[').append(this.name);
/* 220 */     result.append("] caches=").append(this.cacheNames);
/* 221 */     result.append(" | key='").append(this.key);
/* 222 */     result.append("' | keyGenerator='").append(this.keyGenerator);
/* 223 */     result.append("' | cacheManager='").append(this.cacheManager);
/* 224 */     result.append("' | cacheResolver='").append(this.cacheResolver);
/* 225 */     result.append("' | condition='").append(this.condition).append('\'');
/* 226 */     return result;
/*     */   }
/*     */   
/*     */   public abstract CacheOperation build();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheOperation$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */