/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Arrays;
/*    */ import org.springframework.core.KotlinDetector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleKeyGenerator
/*    */   implements KeyGenerator
/*    */ {
/*    */   public Object generate(Object target, Method method, Object... params) {
/* 45 */     return generateKey(KotlinDetector.isSuspendingFunction(method) ? 
/* 46 */         Arrays.<Object>copyOf(params, params.length - 1) : params);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Object generateKey(Object... params) {
/* 53 */     if (params.length == 0) {
/* 54 */       return SimpleKey.EMPTY;
/*    */     }
/* 56 */     if (params.length == 1) {
/* 57 */       Object param = params[0];
/* 58 */       if (param != null && !param.getClass().isArray()) {
/* 59 */         return param;
/*    */       }
/*    */     } 
/* 62 */     return new SimpleKey(params);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\SimpleKeyGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */