/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggingCacheErrorHandler
/*     */   implements CacheErrorHandler
/*     */ {
/*     */   private final Log logger;
/*     */   private final boolean logStackTraces;
/*     */   
/*     */   public LoggingCacheErrorHandler() {
/*  53 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggingCacheErrorHandler(boolean logStackTraces) {
/*  65 */     this(LogFactory.getLog(LoggingCacheErrorHandler.class), logStackTraces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggingCacheErrorHandler(Log logger, boolean logStackTraces) {
/*  75 */     Assert.notNull(logger, "'logger' must not be null");
/*  76 */     this.logger = logger;
/*  77 */     this.logStackTraces = logStackTraces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggingCacheErrorHandler(String loggerName, boolean logStackTraces) {
/*  92 */     Assert.notNull(loggerName, "'loggerName' must not be null");
/*  93 */     this.logger = LogFactory.getLog(loggerName);
/*  94 */     this.logStackTraces = logStackTraces;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleCacheGetError(RuntimeException exception, Cache cache, Object key) {
/* 100 */     logCacheError(() -> String.format("Cache '%s' failed to get entry with key '%s'", new Object[] { cache.getName(), key }), exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleCachePutError(RuntimeException exception, Cache cache, Object key, @Nullable Object value) {
/* 107 */     logCacheError(() -> String.format("Cache '%s' failed to put entry with key '%s'", new Object[] { cache.getName(), key }), exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleCacheEvictError(RuntimeException exception, Cache cache, Object key) {
/* 114 */     logCacheError(() -> String.format("Cache '%s' failed to evict entry with key '%s'", new Object[] { cache.getName(), key }), exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleCacheClearError(RuntimeException exception, Cache cache) {
/* 121 */     logCacheError(() -> String.format("Cache '%s' failed to clear entries", new Object[] { cache.getName() }), exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Log getLogger() {
/* 133 */     return this.logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isLogStackTraces() {
/* 142 */     return this.logStackTraces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logCacheError(Supplier<String> messageSupplier, RuntimeException exception) {
/* 157 */     if (getLogger().isWarnEnabled())
/* 158 */       if (isLogStackTraces()) {
/* 159 */         getLogger().warn(messageSupplier.get(), exception);
/*     */       } else {
/*     */         
/* 162 */         getLogger().warn(messageSupplier.get());
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\LoggingCacheErrorHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */