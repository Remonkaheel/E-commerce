/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.core.MethodClassKey;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFallbackCacheOperationSource
/*     */   implements CacheOperationSource
/*     */ {
/*  57 */   private static final Collection<CacheOperation> NULL_CACHING_MARKER = Collections.emptyList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private final Map<Object, Collection<CacheOperation>> operationCache = new ConcurrentHashMap<>(1024);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasCacheOperations(Method method, @Nullable Class<?> targetClass) {
/*  77 */     return !CollectionUtils.isEmpty(getCacheOperations(method, targetClass, false));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Collection<CacheOperation> getCacheOperations(Method method, @Nullable Class<?> targetClass) {
/*  83 */     return getCacheOperations(method, targetClass, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Collection<CacheOperation> getCacheOperations(Method method, @Nullable Class<?> targetClass, boolean cacheNull) {
/*  99 */     if (ReflectionUtils.isObjectMethod(method)) {
/* 100 */       return null;
/*     */     }
/*     */     
/* 103 */     Object cacheKey = getCacheKey(method, targetClass);
/* 104 */     Collection<CacheOperation> cached = this.operationCache.get(cacheKey);
/*     */     
/* 106 */     if (cached != null) {
/* 107 */       return (cached != NULL_CACHING_MARKER) ? cached : null;
/*     */     }
/*     */     
/* 110 */     Collection<CacheOperation> cacheOps = computeCacheOperations(method, targetClass);
/* 111 */     if (cacheOps != null) {
/* 112 */       if (this.logger.isTraceEnabled()) {
/* 113 */         this.logger.trace("Adding cacheable method '" + method.getName() + "' with operations: " + String.valueOf(cacheOps));
/*     */       }
/* 115 */       this.operationCache.put(cacheKey, cacheOps);
/*     */     }
/* 117 */     else if (cacheNull) {
/* 118 */       this.operationCache.put(cacheKey, NULL_CACHING_MARKER);
/*     */     } 
/* 120 */     return cacheOps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getCacheKey(Method method, @Nullable Class<?> targetClass) {
/* 133 */     return new MethodClassKey(method, targetClass);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Collection<CacheOperation> computeCacheOperations(Method method, @Nullable Class<?> targetClass) {
/* 139 */     if (allowPublicMethodsOnly() && !Modifier.isPublic(method.getModifiers())) {
/* 140 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 145 */     Method specificMethod = AopUtils.getMostSpecificMethod(method, targetClass);
/*     */ 
/*     */     
/* 148 */     Collection<CacheOperation> opDef = findCacheOperations(specificMethod);
/* 149 */     if (opDef != null) {
/* 150 */       return opDef;
/*     */     }
/*     */ 
/*     */     
/* 154 */     opDef = findCacheOperations(specificMethod.getDeclaringClass());
/* 155 */     if (opDef != null && ClassUtils.isUserLevelMethod(method)) {
/* 156 */       return opDef;
/*     */     }
/*     */     
/* 159 */     if (specificMethod != method) {
/*     */       
/* 161 */       opDef = findCacheOperations(method);
/* 162 */       if (opDef != null) {
/* 163 */         return opDef;
/*     */       }
/*     */       
/* 166 */       opDef = findCacheOperations(method.getDeclaringClass());
/* 167 */       if (opDef != null && ClassUtils.isUserLevelMethod(method)) {
/* 168 */         return opDef;
/*     */       }
/*     */     } 
/*     */     
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Collection<CacheOperation> findCacheOperations(Class<?> paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Collection<CacheOperation> findCacheOperations(Method paramMethod);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean allowPublicMethodsOnly() {
/* 199 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\AbstractFallbackCacheOperationSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */