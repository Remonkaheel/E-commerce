package org.springframework.cache.interceptor;

import java.lang.reflect.Method;

public interface CacheOperationInvocationContext<O extends BasicOperation> {
  O getOperation();
  
  Object getTarget();
  
  Method getMethod();
  
  Object[] getArgs();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheOperationInvocationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */