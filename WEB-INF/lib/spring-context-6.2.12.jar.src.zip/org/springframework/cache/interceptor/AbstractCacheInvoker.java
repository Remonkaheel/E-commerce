/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCacheInvoker
/*     */ {
/*     */   protected SingletonSupplier<CacheErrorHandler> errorHandler;
/*     */   
/*     */   protected AbstractCacheInvoker() {
/*  43 */     this.errorHandler = SingletonSupplier.of(SimpleCacheErrorHandler::new);
/*     */   }
/*     */   
/*     */   protected AbstractCacheInvoker(CacheErrorHandler errorHandler) {
/*  47 */     this.errorHandler = SingletonSupplier.of(errorHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setErrorHandler(CacheErrorHandler errorHandler) {
/*  57 */     this.errorHandler = SingletonSupplier.of(errorHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheErrorHandler getErrorHandler() {
/*  64 */     return (CacheErrorHandler)this.errorHandler.obtain();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Cache.ValueWrapper doGet(Cache cache, Object key) {
/*     */     try {
/*  78 */       return cache.get(key);
/*     */     }
/*  80 */     catch (RuntimeException ex) {
/*  81 */       getErrorHandler().handleCacheGetError(ex, cache, key);
/*  82 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected <T> T doGet(Cache cache, Object key, Callable<T> valueLoader) {
/*     */     try {
/*  97 */       return (T)cache.get(key, valueLoader);
/*     */     }
/*  99 */     catch (org.springframework.cache.Cache.ValueRetrievalException ex) {
/* 100 */       throw ex;
/*     */     }
/* 102 */     catch (RuntimeException ex) {
/* 103 */       getErrorHandler().handleCacheGetError(ex, cache, key);
/*     */       try {
/* 105 */         return valueLoader.call();
/*     */       }
/* 107 */       catch (Exception ex2) {
/* 108 */         throw new Cache.ValueRetrievalException(key, valueLoader, ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected CompletableFuture<?> doRetrieve(Cache cache, Object key) {
/*     */     try {
/* 125 */       return cache.retrieve(key);
/*     */     }
/* 127 */     catch (RuntimeException ex) {
/* 128 */       getErrorHandler().handleCacheGetError(ex, cache, key);
/* 129 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> CompletableFuture<T> doRetrieve(Cache cache, Object key, Supplier<CompletableFuture<T>> valueLoader) {
/*     */     try {
/* 143 */       return cache.retrieve(key, valueLoader);
/*     */     }
/* 145 */     catch (RuntimeException ex) {
/* 146 */       getErrorHandler().handleCacheGetError(ex, cache, key);
/* 147 */       return valueLoader.get();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doPut(Cache cache, Object key, @Nullable Object value) {
/*     */     try {
/* 157 */       cache.put(key, value);
/*     */     }
/* 159 */     catch (RuntimeException ex) {
/* 160 */       getErrorHandler().handleCachePutError(ex, cache, key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doEvict(Cache cache, Object key, boolean immediate) {
/*     */     try {
/* 170 */       if (immediate) {
/* 171 */         cache.evictIfPresent(key);
/*     */       } else {
/*     */         
/* 174 */         cache.evict(key);
/*     */       }
/*     */     
/* 177 */     } catch (RuntimeException ex) {
/* 178 */       getErrorHandler().handleCacheEvictError(ex, cache, key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doClear(Cache cache, boolean immediate) {
/*     */     try {
/* 188 */       if (immediate) {
/* 189 */         cache.invalidate();
/*     */       } else {
/*     */         
/* 192 */         cache.clear();
/*     */       }
/*     */     
/* 195 */     } catch (RuntimeException ex) {
/* 196 */       getErrorHandler().handleCacheClearError(ex, cache);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\AbstractCacheInvoker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */