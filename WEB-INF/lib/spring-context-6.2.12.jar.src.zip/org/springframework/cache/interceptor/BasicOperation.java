package org.springframework.cache.interceptor;

import java.util.Set;

public interface BasicOperation {
  Set<String> getCacheNames();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\BasicOperation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */