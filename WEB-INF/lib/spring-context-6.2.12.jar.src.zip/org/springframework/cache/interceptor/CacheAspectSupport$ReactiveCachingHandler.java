/*      */ package org.springframework.cache.interceptor;
/*      */ 
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.concurrent.CompletableFuture;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.springframework.cache.Cache;
/*      */ import org.springframework.core.KotlinDetector;
/*      */ import org.springframework.core.ReactiveAdapter;
/*      */ import org.springframework.core.ReactiveAdapterRegistry;
/*      */ import org.springframework.lang.Nullable;
/*      */ import reactor.core.publisher.Flux;
/*      */ import reactor.core.publisher.Mono;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class ReactiveCachingHandler
/*      */ {
/* 1132 */   public static final Object NOT_HANDLED = new Object();
/*      */   
/* 1134 */   private final ReactiveAdapterRegistry registry = ReactiveAdapterRegistry.getSharedInstance();
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object executeSynchronized(CacheOperationInvoker invoker, Method method, Cache cache, Object key) {
/* 1139 */     AtomicBoolean invokeFailure = new AtomicBoolean(false);
/* 1140 */     ReactiveAdapter adapter = this.registry.getAdapter(method.getReturnType());
/* 1141 */     if (adapter != null) {
/* 1142 */       if (adapter.isMultiValue())
/*      */       {
/* 1144 */         return adapter.fromPublisher((Publisher)Flux.from((Publisher)Mono.fromFuture(CacheAspectSupport.this
/* 1145 */                 .doRetrieve(cache, key, () -> Flux.from(adapter.toPublisher(CacheAspectSupport.this.invokeOperation(invoker))).collectList().doOnError(()).toFuture())))
/*      */             
/* 1147 */             .flatMap(Flux::fromIterable)
/* 1148 */             .onErrorResume(RuntimeException.class, ex -> {
/*      */                 try {
/*      */                   CacheAspectSupport.this.getErrorHandler().handleCacheGetError(ex, cache, key);
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*      */                   return (Publisher)(invokeFailure.get() ? Flux.error(ex) : Flux.from(adapter.toPublisher(CacheAspectSupport.this.invokeOperation(invoker))));
/* 1156 */                 } catch (RuntimeException exception) {
/*      */                   return (Publisher)Flux.error(exception);
/*      */                 } 
/*      */               }));
/*      */       }
/*      */ 
/*      */       
/* 1163 */       return adapter.fromPublisher((Publisher)Mono.fromFuture(CacheAspectSupport.this
/* 1164 */             .doRetrieve(cache, key, () -> Mono.from(adapter.toPublisher(CacheAspectSupport.this.invokeOperation(invoker))).doOnError(()).toFuture()))
/*      */           
/* 1166 */           .onErrorResume(RuntimeException.class, ex -> {
/*      */               try {
/*      */                 CacheAspectSupport.this.getErrorHandler().handleCacheGetError(ex, cache, key);
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 return invokeFailure.get() ? Mono.error(ex) : Mono.from(adapter.toPublisher(CacheAspectSupport.this.invokeOperation(invoker)));
/* 1174 */               } catch (RuntimeException exception) {
/*      */                 return Mono.error(exception);
/*      */               } 
/*      */             }));
/*      */     } 
/*      */     
/* 1180 */     if (KotlinDetector.isKotlinReflectPresent() && KotlinDetector.isSuspendingFunction(method)) {
/* 1181 */       return Mono.fromFuture(CacheAspectSupport.this.doRetrieve(cache, key, () -> {
/*      */               Mono<?> mono = (Mono)CacheAspectSupport.this.invokeOperation(invoker);
/*      */               
/*      */               if (mono != null) {
/*      */                 mono = mono.doOnError(());
/*      */               } else {
/*      */                 mono = Mono.empty();
/*      */               } 
/*      */               return mono.toFuture();
/* 1190 */             })).onErrorResume(RuntimeException.class, ex -> {
/*      */             try {
/*      */               CacheAspectSupport.this.getErrorHandler().handleCacheGetError(ex, cache, key);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               return invokeFailure.get() ? Mono.error(ex) : (Mono)CacheAspectSupport.this.invokeOperation(invoker);
/* 1198 */             } catch (RuntimeException exception) {
/*      */               return Mono.error(exception);
/*      */             } 
/*      */           });
/*      */     }
/* 1203 */     return NOT_HANDLED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Object processCacheEvicts(List<CacheAspectSupport.CacheOperationContext> contexts, @Nullable Object result) {
/* 1208 */     ReactiveAdapter adapter = (result != null) ? this.registry.getAdapter(result.getClass()) : null;
/* 1209 */     if (adapter != null) {
/* 1210 */       return adapter.fromPublisher((Publisher)Mono.from(adapter.toPublisher(result))
/* 1211 */           .doOnSuccess(value -> CacheAspectSupport.this.performCacheEvicts(contexts, value)));
/*      */     }
/* 1213 */     return NOT_HANDLED;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object findInCaches(CacheAspectSupport.CacheOperationContext context, Cache cache, Object key, CacheOperationInvoker invoker, Method method, CacheAspectSupport.CacheOperationContexts contexts) {
/* 1221 */     ReactiveAdapter adapter = this.registry.getAdapter(context.getMethod().getReturnType());
/* 1222 */     if (adapter != null) {
/* 1223 */       CompletableFuture<?> cachedFuture = CacheAspectSupport.this.doRetrieve(cache, key);
/* 1224 */       if (cachedFuture == null) {
/* 1225 */         return null;
/*      */       }
/* 1227 */       if (adapter.isMultiValue()) {
/* 1228 */         return adapter.fromPublisher((Publisher)Flux.from((Publisher)Mono.fromFuture(cachedFuture))
/* 1229 */             .switchIfEmpty((Publisher)Flux.defer(() -> (Publisher)CacheAspectSupport.this.evaluate(null, invoker, method, contexts)))
/* 1230 */             .flatMap(v -> CacheAspectSupport.this.evaluate(valueToFlux(v, contexts), invoker, method, contexts))
/* 1231 */             .onErrorResume(RuntimeException.class, ex -> {
/*      */                 try {
/*      */                   CacheAspectSupport.this.getErrorHandler().handleCacheGetError((RuntimeException)ex, cache, key);
/*      */                   
/*      */                   Object e = CacheAspectSupport.this.evaluate(null, invoker, method, contexts);
/*      */                   return (e != null) ? e : Flux.error((RuntimeException)ex);
/* 1237 */                 } catch (RuntimeException exception) {
/*      */                   return Flux.error(exception);
/*      */                 } 
/*      */               }));
/*      */       }
/*      */       
/* 1243 */       return adapter.fromPublisher((Publisher)Mono.fromFuture(cachedFuture)
/* 1244 */           .switchIfEmpty(Mono.defer(() -> (Mono)CacheAspectSupport.this.evaluate(null, invoker, method, contexts)))
/* 1245 */           .flatMap(v -> CacheAspectSupport.this.evaluate(Mono.justOrEmpty(CacheAspectSupport.this.unwrapCacheValue(v)), invoker, method, contexts))
/* 1246 */           .onErrorResume(RuntimeException.class, ex -> {
/*      */               try {
/*      */                 CacheAspectSupport.this.getErrorHandler().handleCacheGetError((RuntimeException)ex, cache, key);
/*      */                 
/*      */                 Object e = CacheAspectSupport.this.evaluate(null, invoker, method, contexts);
/*      */                 return (e != null) ? e : Mono.error((RuntimeException)ex);
/* 1252 */               } catch (RuntimeException exception) {
/*      */                 return Mono.error(exception);
/*      */               } 
/*      */             }));
/*      */     } 
/*      */     
/* 1258 */     return NOT_HANDLED;
/*      */   }
/*      */   
/*      */   private Flux<?> valueToFlux(Object value, CacheAspectSupport.CacheOperationContexts contexts) {
/* 1262 */     Object data = CacheAspectSupport.this.unwrapCacheValue(value);
/* 1263 */     Iterable<?> iterable = (Iterable)data; return (!contexts.processed && data instanceof Iterable) ? Flux.fromIterable(iterable) : (
/* 1264 */       (data != null) ? Flux.just(data) : Flux.empty());
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Object processPutRequest(CacheAspectSupport.CachePutRequest request, @Nullable Object result) {
/* 1269 */     ReactiveAdapter adapter = (result != null) ? this.registry.getAdapter(result.getClass()) : null;
/* 1270 */     if (adapter != null) {
/* 1271 */       if (adapter.isMultiValue()) {
/*      */         
/* 1273 */         Flux<?> source = Flux.from(adapter.toPublisher(result)).publish().refCount(2);
/* 1274 */         source.subscribe(new CacheAspectSupport.CachePutListSubscriber(CacheAspectSupport.this, request));
/* 1275 */         return adapter.fromPublisher((Publisher)source);
/*      */       } 
/*      */ 
/*      */       
/* 1279 */       Objects.requireNonNull(request); return adapter.fromPublisher((Publisher)Mono.from(adapter.toPublisher(result)).doOnSuccess(request::performCachePut));
/*      */     } 
/*      */     
/* 1282 */     return NOT_HANDLED;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheAspectSupport$ReactiveCachingHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */