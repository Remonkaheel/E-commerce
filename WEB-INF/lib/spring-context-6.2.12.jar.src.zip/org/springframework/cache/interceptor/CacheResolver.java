package org.springframework.cache.interceptor;

import java.util.Collection;
import org.springframework.cache.Cache;

@FunctionalInterface
public interface CacheResolver {
  Collection<? extends Cache> resolveCaches(CacheOperationInvocationContext<?> paramCacheOperationInvocationContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */