/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Builder
/*    */   extends CacheOperation.Builder
/*    */ {
/*    */   private boolean cacheWide = false;
/*    */   private boolean beforeInvocation = false;
/*    */   
/*    */   public void setCacheWide(boolean cacheWide) {
/* 64 */     this.cacheWide = cacheWide;
/*    */   }
/*    */   
/*    */   public void setBeforeInvocation(boolean beforeInvocation) {
/* 68 */     this.beforeInvocation = beforeInvocation;
/*    */   }
/*    */ 
/*    */   
/*    */   protected StringBuilder getOperationDescription() {
/* 73 */     StringBuilder sb = super.getOperationDescription();
/* 74 */     sb.append(',');
/* 75 */     sb.append(this.cacheWide);
/* 76 */     sb.append(',');
/* 77 */     sb.append(this.beforeInvocation);
/* 78 */     return sb;
/*    */   }
/*    */ 
/*    */   
/*    */   public CacheEvictOperation build() {
/* 83 */     return new CacheEvictOperation(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheEvictOperation$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */