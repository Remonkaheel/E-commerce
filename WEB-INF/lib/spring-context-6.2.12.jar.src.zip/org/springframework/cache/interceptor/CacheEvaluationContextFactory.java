/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*    */ import org.springframework.core.ParameterNameDiscoverer;
/*    */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.function.SingletonSupplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CacheEvaluationContextFactory
/*    */ {
/*    */   private final StandardEvaluationContext originalContext;
/*    */   @Nullable
/*    */   private Supplier<ParameterNameDiscoverer> parameterNameDiscoverer;
/*    */   
/*    */   CacheEvaluationContextFactory(StandardEvaluationContext originalContext) {
/* 43 */     this.originalContext = originalContext;
/*    */   }
/*    */   
/*    */   public void setParameterNameDiscoverer(Supplier<ParameterNameDiscoverer> parameterNameDiscoverer) {
/* 47 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*    */   }
/*    */   
/*    */   public ParameterNameDiscoverer getParameterNameDiscoverer() {
/* 51 */     if (this.parameterNameDiscoverer == null) {
/* 52 */       this.parameterNameDiscoverer = (Supplier<ParameterNameDiscoverer>)SingletonSupplier.of(new DefaultParameterNameDiscoverer());
/*    */     }
/* 54 */     return this.parameterNameDiscoverer.get();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CacheEvaluationContext forOperation(CacheExpressionRootObject rootObject, Method targetMethod, Object[] args) {
/* 68 */     CacheEvaluationContext evaluationContext = new CacheEvaluationContext(rootObject, targetMethod, args, getParameterNameDiscoverer());
/* 69 */     this.originalContext.applyDelegatesTo((StandardEvaluationContext)evaluationContext);
/* 70 */     return evaluationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheEvaluationContextFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */