/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleCacheResolver
/*    */   extends AbstractCacheResolver
/*    */ {
/*    */   public SimpleCacheResolver() {}
/*    */   
/*    */   public SimpleCacheResolver(CacheManager cacheManager) {
/* 49 */     super(cacheManager);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Collection<String> getCacheNames(CacheOperationInvocationContext<?> context) {
/* 55 */     return context.getOperation().getCacheNames();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   static SimpleCacheResolver of(@Nullable CacheManager cacheManager) {
/* 67 */     return (cacheManager != null) ? new SimpleCacheResolver(cacheManager) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\SimpleCacheResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */