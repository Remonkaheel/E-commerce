package org.springframework.cache.interceptor;

import org.springframework.cache.Cache;
import org.springframework.lang.Nullable;

public interface CacheErrorHandler {
  void handleCacheGetError(RuntimeException paramRuntimeException, Cache paramCache, Object paramObject);
  
  void handleCachePutError(RuntimeException paramRuntimeException, Cache paramCache, Object paramObject1, @Nullable Object paramObject2);
  
  void handleCacheEvictError(RuntimeException paramRuntimeException, Cache paramCache, Object paramObject);
  
  void handleCacheClearError(RuntimeException paramRuntimeException, Cache paramCache);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheErrorHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */