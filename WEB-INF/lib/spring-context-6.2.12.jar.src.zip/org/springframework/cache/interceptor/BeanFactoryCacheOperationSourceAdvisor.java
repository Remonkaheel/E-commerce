/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.support.AbstractBeanFactoryPointcutAdvisor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanFactoryCacheOperationSourceAdvisor
/*    */   extends AbstractBeanFactoryPointcutAdvisor
/*    */ {
/* 36 */   private final CacheOperationSourcePointcut pointcut = new CacheOperationSourcePointcut();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCacheOperationSource(CacheOperationSource cacheOperationSource) {
/* 46 */     this.pointcut.setCacheOperationSource(cacheOperationSource);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setClassFilter(ClassFilter classFilter) {
/* 54 */     this.pointcut.setClassFilter(classFilter);
/*    */   }
/*    */ 
/*    */   
/*    */   public Pointcut getPointcut() {
/* 59 */     return (Pointcut)this.pointcut;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\BeanFactoryCacheOperationSourceAdvisor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */