/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameMatchCacheOperationSource
/*     */   implements CacheOperationSource, Serializable
/*     */ {
/*  46 */   protected static final Log logger = LogFactory.getLog(NameMatchCacheOperationSource.class);
/*     */ 
/*     */ 
/*     */   
/*  50 */   private final Map<String, Collection<CacheOperation>> nameMap = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNameMap(Map<String, Collection<CacheOperation>> nameMap) {
/*  60 */     nameMap.forEach(this::addCacheMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCacheMethod(String methodName, Collection<CacheOperation> ops) {
/*  71 */     if (logger.isDebugEnabled()) {
/*  72 */       logger.debug("Adding method [" + methodName + "] with cache operations [" + String.valueOf(ops) + "]");
/*     */     }
/*  74 */     this.nameMap.put(methodName, ops);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Collection<CacheOperation> getCacheOperations(Method method, @Nullable Class<?> targetClass) {
/*  81 */     String methodName = method.getName();
/*  82 */     Collection<CacheOperation> ops = this.nameMap.get(methodName);
/*     */     
/*  84 */     if (ops == null) {
/*     */       
/*  86 */       String bestNameMatch = null;
/*  87 */       for (String mappedName : this.nameMap.keySet()) {
/*  88 */         if (isMatch(methodName, mappedName) && (bestNameMatch == null || bestNameMatch
/*  89 */           .length() <= mappedName.length())) {
/*  90 */           ops = this.nameMap.get(mappedName);
/*  91 */           bestNameMatch = mappedName;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  96 */     return ops;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMatch(String methodName, String mappedName) {
/* 109 */     return PatternMatchUtils.simpleMatch(mappedName, methodName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 114 */     if (this != other) { if (other instanceof NameMatchCacheOperationSource) { NameMatchCacheOperationSource otherCos = (NameMatchCacheOperationSource)other;
/* 115 */         if (ObjectUtils.nullSafeEquals(this.nameMap, otherCos.nameMap)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 120 */     return NameMatchCacheOperationSource.class.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 125 */     return getClass().getName() + ": " + getClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\NameMatchCacheOperationSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */