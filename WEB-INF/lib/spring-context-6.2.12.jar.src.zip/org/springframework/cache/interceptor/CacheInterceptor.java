/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheInterceptor
/*    */   extends CacheAspectSupport
/*    */   implements MethodInterceptor, Serializable
/*    */ {
/*    */   @Nullable
/*    */   public Object invoke(MethodInvocation invocation) throws Throwable {
/* 51 */     Method method = invocation.getMethod();
/*    */     
/* 53 */     CacheOperationInvoker aopAllianceInvoker = () -> {
/*    */         
/*    */         try {
/*    */           return invocation.proceed();
/* 57 */         } catch (Throwable ex) {
/*    */           throw new CacheOperationInvoker.ThrowableWrapper(ex);
/*    */         } 
/*    */       };
/*    */     
/* 62 */     Object target = invocation.getThis();
/* 63 */     Assert.state((target != null), "Target must not be null");
/*    */     try {
/* 65 */       return execute(aopAllianceInvoker, target, method, invocation.getArguments());
/*    */     }
/* 67 */     catch (ThrowableWrapper th) {
/* 68 */       throw th.getOriginal();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CacheInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */