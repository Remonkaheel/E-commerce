package org.springframework.cache.interceptor;

import java.lang.reflect.Method;

@FunctionalInterface
public interface KeyGenerator {
  Object generate(Object paramObject, Method paramMethod, Object... paramVarArgs);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\KeyGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */