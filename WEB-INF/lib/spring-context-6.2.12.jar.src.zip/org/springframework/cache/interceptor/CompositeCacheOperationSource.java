/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeCacheOperationSource
/*    */   implements CacheOperationSource, Serializable
/*    */ {
/*    */   private final CacheOperationSource[] cacheOperationSources;
/*    */   
/*    */   public CompositeCacheOperationSource(CacheOperationSource... cacheOperationSources) {
/* 46 */     Assert.notEmpty((Object[])cacheOperationSources, "CacheOperationSource array must not be empty");
/* 47 */     this.cacheOperationSources = cacheOperationSources;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final CacheOperationSource[] getCacheOperationSources() {
/* 55 */     return this.cacheOperationSources;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCandidateClass(Class<?> targetClass) {
/* 61 */     for (CacheOperationSource source : this.cacheOperationSources) {
/* 62 */       if (source.isCandidateClass(targetClass)) {
/* 63 */         return true;
/*    */       }
/*    */     } 
/* 66 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasCacheOperations(Method method, @Nullable Class<?> targetClass) {
/* 71 */     for (CacheOperationSource source : this.cacheOperationSources) {
/* 72 */       if (source.hasCacheOperations(method, targetClass)) {
/* 73 */         return true;
/*    */       }
/*    */     } 
/* 76 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Collection<CacheOperation> getCacheOperations(Method method, @Nullable Class<?> targetClass) {
/* 82 */     Collection<CacheOperation> ops = null;
/* 83 */     for (CacheOperationSource source : this.cacheOperationSources) {
/* 84 */       Collection<CacheOperation> cacheOperations = source.getCacheOperations(method, targetClass);
/* 85 */       if (cacheOperations != null) {
/* 86 */         if (ops == null) {
/* 87 */           ops = new ArrayList<>();
/*    */         }
/* 89 */         ops.addAll(cacheOperations);
/*    */       } 
/*    */     } 
/* 92 */     return ops;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\interceptor\CompositeCacheOperationSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */