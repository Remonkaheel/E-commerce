/*    */ package org.springframework.cache;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000\022\n\000\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\000\032\027\020\000\032\004\030\0010\001*\0020\0022\006\020\003\032\0020\004H\002¨\006\005"}, d2 = {"get", "Lorg/springframework/cache/Cache;", "Lorg/springframework/cache/CacheManager;", "name", "", "spring-context"})
/*    */ public final class CacheManagerExtensionsKt
/*    */ {
/*    */   @Nullable
/*    */   public static final Cache get(@NotNull CacheManager $this$get, @NotNull String name) {
/* 25 */     Intrinsics.checkNotNullParameter($this$get, "<this>"); Intrinsics.checkNotNullParameter(name, "name"); return $this$get.getCache(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\CacheManagerExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */