/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleValueWrapper
/*    */   implements Cache.ValueWrapper
/*    */ {
/*    */   @Nullable
/*    */   private final Object value;
/*    */   
/*    */   public SimpleValueWrapper(@Nullable Object value) {
/* 42 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object get() {
/* 52 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 57 */     if (this != other) { if (other instanceof Cache.ValueWrapper) { Cache.ValueWrapper wrapper = (Cache.ValueWrapper)other; if (Objects.equals(get(), wrapper.get())); }  return false; }
/*    */   
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 62 */     return Objects.hashCode(this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return "ValueWrapper for [" + String.valueOf(this.value) + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\support\SimpleValueWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */