/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NullValue
/*    */   implements Serializable
/*    */ {
/* 39 */   public static final Object INSTANCE = new NullValue();
/*    */ 
/*    */ 
/*    */   
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */ 
/*    */   
/*    */   private Object readResolve() {
/* 48 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 54 */     return (this == other || other == null);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 59 */     return NullValue.class.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 64 */     return "null";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\support\NullValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */