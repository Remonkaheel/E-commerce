/*     */ package org.springframework.cache.support;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCacheManager
/*     */   implements CacheManager, InitializingBean
/*     */ {
/*  43 */   private final ConcurrentMap<String, Cache> cacheMap = new ConcurrentHashMap<>(16);
/*     */   
/*  45 */   private volatile Set<String> cacheNames = Collections.emptySet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  52 */     initializeCaches();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeCaches() {
/*  63 */     Collection<? extends Cache> caches = loadCaches();
/*     */     
/*  65 */     synchronized (this.cacheMap) {
/*  66 */       this.cacheNames = Collections.emptySet();
/*  67 */       this.cacheMap.clear();
/*  68 */       Set<String> cacheNames = CollectionUtils.newLinkedHashSet(caches.size());
/*  69 */       for (Cache cache : caches) {
/*  70 */         String name = cache.getName();
/*  71 */         this.cacheMap.put(name, decorateCache(cache));
/*  72 */         cacheNames.add(name);
/*     */       } 
/*  74 */       this.cacheNames = Collections.unmodifiableSet(cacheNames);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Collection<? extends Cache> loadCaches();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Cache getCache(String name) {
/*  92 */     Cache cache = this.cacheMap.get(name);
/*  93 */     if (cache != null) {
/*  94 */       return cache;
/*     */     }
/*     */ 
/*     */     
/*  98 */     Cache missingCache = getMissingCache(name);
/*  99 */     if (missingCache != null)
/*     */     {
/* 101 */       synchronized (this.cacheMap) {
/* 102 */         cache = this.cacheMap.get(name);
/* 103 */         if (cache == null) {
/* 104 */           cache = decorateCache(missingCache);
/* 105 */           this.cacheMap.put(name, cache);
/* 106 */           updateCacheNames(name);
/*     */         } 
/*     */       } 
/*     */     }
/* 110 */     return cache;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getCacheNames() {
/* 115 */     return this.cacheNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected final Cache lookupCache(String name) {
/* 133 */     return this.cacheMap.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateCacheNames(String name) {
/* 144 */     Set<String> cacheNames = new LinkedHashSet<>(this.cacheNames);
/* 145 */     cacheNames.add(name);
/* 146 */     this.cacheNames = Collections.unmodifiableSet(cacheNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Cache decorateCache(Cache cache) {
/* 159 */     return cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Cache getMissingCache(String name) {
/* 177 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\support\AbstractCacheManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */