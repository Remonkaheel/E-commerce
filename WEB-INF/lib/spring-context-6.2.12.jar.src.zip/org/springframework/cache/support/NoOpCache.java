/*     */ package org.springframework.cache.support;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoOpCache
/*     */   implements Cache
/*     */ {
/*     */   private final String name;
/*     */   
/*     */   public NoOpCache(String name) {
/*  47 */     Assert.notNull(name, "Cache name must not be null");
/*  48 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  54 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getNativeCache() {
/*  59 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Cache.ValueWrapper get(Object key) {
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T get(Object key, @Nullable Class<T> type) {
/*  71 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T get(Object key, Callable<T> valueLoader) {
/*     */     try {
/*  78 */       return valueLoader.call();
/*     */     }
/*  80 */     catch (Exception ex) {
/*  81 */       throw new Cache.ValueRetrievalException(key, valueLoader, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CompletableFuture<?> retrieve(Object key) {
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> CompletableFuture<T> retrieve(Object key, Supplier<CompletableFuture<T>> valueLoader) {
/*  93 */     return valueLoader.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Object key, @Nullable Object value) {}
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Cache.ValueWrapper putIfAbsent(Object key, @Nullable Object value) {
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void evict(Object key) {}
/*     */ 
/*     */   
/*     */   public boolean evictIfPresent(Object key) {
/* 112 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {}
/*     */ 
/*     */   
/*     */   public boolean invalidate() {
/* 121 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\support\NoOpCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */