/*     */ package org.springframework.cache.support;
/*     */ 
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractValueAdaptingCache
/*     */   implements Cache
/*     */ {
/*     */   private final boolean allowNullValues;
/*     */   
/*     */   protected AbstractValueAdaptingCache(boolean allowNullValues) {
/*  44 */     this.allowNullValues = allowNullValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isAllowNullValues() {
/*  52 */     return this.allowNullValues;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Cache.ValueWrapper get(Object key) {
/*  58 */     return toValueWrapper(lookup(key));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T get(Object key, @Nullable Class<T> type) {
/*  65 */     Object value = fromStoreValue(lookup(key));
/*  66 */     if (value != null && type != null && !type.isInstance(value)) {
/*  67 */       throw new IllegalStateException("Cached value is not of required type [" + type
/*  68 */           .getName() + "]: " + String.valueOf(value));
/*     */     }
/*  70 */     return (T)value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Object lookup(Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object fromStoreValue(@Nullable Object storeValue) {
/*  90 */     if (this.allowNullValues && storeValue == NullValue.INSTANCE) {
/*  91 */       return null;
/*     */     }
/*  93 */     return storeValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toStoreValue(@Nullable Object userValue) {
/* 103 */     if (userValue == null) {
/* 104 */       if (this.allowNullValues) {
/* 105 */         return NullValue.INSTANCE;
/*     */       }
/* 107 */       throw new IllegalArgumentException("Cache '" + 
/* 108 */           getName() + "' is configured to not allow null values but null was provided");
/*     */     } 
/* 110 */     return userValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Cache.ValueWrapper toValueWrapper(@Nullable Object storeValue) {
/* 122 */     return (storeValue != null) ? new SimpleValueWrapper(fromStoreValue(storeValue)) : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\support\AbstractValueAdaptingCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */