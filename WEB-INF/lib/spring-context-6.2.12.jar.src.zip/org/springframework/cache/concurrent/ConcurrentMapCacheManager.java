/*     */ package org.springframework.cache.concurrent;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.core.serializer.support.SerializationDelegate;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConcurrentMapCacheManager
/*     */   implements CacheManager, BeanClassLoaderAware
/*     */ {
/*  55 */   private final ConcurrentMap<String, Cache> cacheMap = new ConcurrentHashMap<>(16);
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean dynamic = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean allowNullValues = true;
/*     */ 
/*     */   
/*     */   private boolean storeByValue = false;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private SerializationDelegate serialization;
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentMapCacheManager() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentMapCacheManager(String... cacheNames) {
/*  79 */     setCacheNames(Arrays.asList(cacheNames));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCacheNames(@Nullable Collection<String> cacheNames) {
/*  91 */     if (cacheNames != null) {
/*  92 */       for (String name : cacheNames) {
/*  93 */         this.cacheMap.put(name, createConcurrentMapCache(name));
/*     */       }
/*  95 */       this.dynamic = false;
/*     */     } else {
/*     */       
/*  98 */       this.dynamic = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowNullValues(boolean allowNullValues) {
/* 111 */     if (allowNullValues != this.allowNullValues) {
/* 112 */       this.allowNullValues = allowNullValues;
/*     */       
/* 114 */       recreateCaches();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowNullValues() {
/* 123 */     return this.allowNullValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStoreByValue(boolean storeByValue) {
/* 136 */     if (storeByValue != this.storeByValue) {
/* 137 */       this.storeByValue = storeByValue;
/*     */       
/* 139 */       recreateCaches();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStoreByValue() {
/* 150 */     return this.storeByValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 155 */     this.serialization = new SerializationDelegate(classLoader);
/*     */     
/* 157 */     if (isStoreByValue()) {
/* 158 */       recreateCaches();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getCacheNames() {
/* 165 */     return Collections.unmodifiableSet(this.cacheMap.keySet());
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Cache getCache(String name) {
/* 171 */     Cache cache = this.cacheMap.get(name);
/* 172 */     if (cache == null && this.dynamic) {
/* 173 */       cache = this.cacheMap.computeIfAbsent(name, this::createConcurrentMapCache);
/*     */     }
/* 175 */     return cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeCache(String name) {
/* 184 */     this.cacheMap.remove(name);
/*     */   }
/*     */   
/*     */   private void recreateCaches() {
/* 188 */     for (Map.Entry<String, Cache> entry : this.cacheMap.entrySet()) {
/* 189 */       entry.setValue(createConcurrentMapCache(entry.getKey()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Cache createConcurrentMapCache(String name) {
/* 199 */     SerializationDelegate actualSerialization = isStoreByValue() ? this.serialization : null;
/* 200 */     return (Cache)new ConcurrentMapCache(name, new ConcurrentHashMap<>(256), isAllowNullValues(), actualSerialization);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\concurrent\ConcurrentMapCacheManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */