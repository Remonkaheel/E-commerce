/*     */ package org.springframework.cache.concurrent;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.support.AbstractValueAdaptingCache;
/*     */ import org.springframework.core.serializer.support.SerializationDelegate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConcurrentMapCache
/*     */   extends AbstractValueAdaptingCache
/*     */ {
/*     */   private final String name;
/*     */   private final ConcurrentMap<Object, Object> store;
/*     */   @Nullable
/*     */   private final SerializationDelegate serialization;
/*     */   
/*     */   public ConcurrentMapCache(String name) {
/*  69 */     this(name, new ConcurrentHashMap<>(256), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentMapCache(String name, boolean allowNullValues) {
/*  79 */     this(name, new ConcurrentHashMap<>(256), allowNullValues);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentMapCache(String name, ConcurrentMap<Object, Object> store, boolean allowNullValues) {
/*  91 */     this(name, store, allowNullValues, (SerializationDelegate)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConcurrentMapCache(String name, ConcurrentMap<Object, Object> store, boolean allowNullValues, @Nullable SerializationDelegate serialization) {
/* 110 */     super(allowNullValues);
/* 111 */     Assert.notNull(name, "Name must not be null");
/* 112 */     Assert.notNull(store, "Store must not be null");
/* 113 */     this.name = name;
/* 114 */     this.store = store;
/* 115 */     this.serialization = serialization;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isStoreByValue() {
/* 126 */     return (this.serialization != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getName() {
/* 131 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ConcurrentMap<Object, Object> getNativeCache() {
/* 136 */     return this.store;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object lookup(Object key) {
/* 142 */     return this.store.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T get(Object key, Callable<T> valueLoader) {
/* 149 */     return (T)fromStoreValue(this.store.computeIfAbsent(key, k -> {
/*     */             
/*     */             try {
/*     */               return toStoreValue(valueLoader.call());
/* 153 */             } catch (Throwable ex) {
/*     */               throw new Cache.ValueRetrievalException(key, valueLoader, ex);
/*     */             } 
/*     */           }));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CompletableFuture<?> retrieve(Object key) {
/* 162 */     Object value = lookup(key);
/* 163 */     return (value != null) ? CompletableFuture.completedFuture(
/* 164 */         isAllowNullValues() ? toValueWrapper(value) : fromStoreValue(value)) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> CompletableFuture<T> retrieve(Object key, Supplier<CompletableFuture<T>> valueLoader) {
/* 170 */     return CompletableFuture.supplyAsync(() -> fromStoreValue(this.store.computeIfAbsent(key, ())));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Object key, @Nullable Object value) {
/* 176 */     this.store.put(key, toStoreValue(value));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Cache.ValueWrapper putIfAbsent(Object key, @Nullable Object value) {
/* 182 */     Object existing = this.store.putIfAbsent(key, toStoreValue(value));
/* 183 */     return toValueWrapper(existing);
/*     */   }
/*     */ 
/*     */   
/*     */   public void evict(Object key) {
/* 188 */     this.store.remove(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean evictIfPresent(Object key) {
/* 193 */     return (this.store.remove(key) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 198 */     this.store.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean invalidate() {
/* 203 */     boolean notEmpty = !this.store.isEmpty();
/* 204 */     this.store.clear();
/* 205 */     return notEmpty;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object toStoreValue(@Nullable Object userValue) {
/* 210 */     Object storeValue = super.toStoreValue(userValue);
/* 211 */     if (this.serialization != null) {
/*     */       try {
/* 213 */         return this.serialization.serializeToByteArray(storeValue);
/*     */       }
/* 215 */       catch (Throwable ex) {
/* 216 */         throw new IllegalArgumentException("Failed to serialize cache value '" + String.valueOf(userValue) + "'. Does it implement Serializable?", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 221 */     return storeValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object fromStoreValue(@Nullable Object storeValue) {
/* 228 */     if (storeValue != null && this.serialization != null) {
/*     */       try {
/* 230 */         return super.fromStoreValue(this.serialization.deserializeFromByteArray((byte[])storeValue));
/*     */       }
/* 232 */       catch (Throwable ex) {
/* 233 */         throw new IllegalArgumentException("Failed to deserialize cache value '" + String.valueOf(storeValue) + "'", ex);
/*     */       } 
/*     */     }
/*     */     
/* 237 */     return super.fromStoreValue(storeValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\concurrent\ConcurrentMapCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */