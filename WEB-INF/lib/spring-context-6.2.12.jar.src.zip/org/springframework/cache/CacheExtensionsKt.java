/*    */ package org.springframework.cache;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000\034\n\000\n\002\030\002\n\002\030\002\n\000\n\002\020\000\n\002\b\003\n\002\020\002\n\002\b\002\032\027\020\000\032\004\030\0010\001*\0020\0022\006\020\003\032\0020\004H\002\032(\020\000\032\004\030\001H\005\"\n\b\000\020\005\030\001*\0020\004*\0020\0022\006\020\003\032\0020\004H\b¢\006\002\020\006\032\037\020\007\032\0020\b*\0020\0022\006\020\003\032\0020\0042\b\020\t\032\004\030\0010\004H\002¨\006\n"}, d2 = {"get", "Lorg/springframework/cache/Cache$ValueWrapper;", "Lorg/springframework/cache/Cache;", "key", "", "T", "(Lorg/springframework/cache/Cache;Ljava/lang/Object;)Ljava/lang/Object;", "set", "", "value", "spring-context"})
/*    */ public final class CacheExtensionsKt
/*    */ {
/*    */   @Nullable
/*    */   public static final Cache.ValueWrapper get(@NotNull Cache $this$get, @NotNull Object key) {
/* 36 */     Intrinsics.checkNotNullParameter($this$get, "<this>"); Intrinsics.checkNotNullParameter(key, "key"); return $this$get.get(key);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final void set(@NotNull Cache $this$set, @NotNull Object key, @Nullable Object value) {
/* 44 */     Intrinsics.checkNotNullParameter($this$set, "<this>"); Intrinsics.checkNotNullParameter(key, "key"); $this$set.put(key, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\CacheExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */