package org.springframework.cache;

import org.springframework.lang.Nullable;

@FunctionalInterface
public interface ValueWrapper {
  @Nullable
  Object get();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\cache\Cache$ValueWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */