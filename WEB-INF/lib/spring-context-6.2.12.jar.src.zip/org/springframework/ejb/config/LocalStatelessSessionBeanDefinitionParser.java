/*    */ package org.springframework.ejb.config;
/*    */ 
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.jndi.JndiObjectFactoryBean;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LocalStatelessSessionBeanDefinitionParser
/*    */   extends AbstractJndiLocatingBeanDefinitionParser
/*    */ {
/*    */   protected Class<?> getBeanClass(Element element) {
/* 37 */     return JndiObjectFactoryBean.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isEligibleAttribute(String attributeName) {
/* 42 */     return (super.isEligibleAttribute(attributeName) && 
/* 43 */       BeanUtils.getPropertyDescriptor(JndiObjectFactoryBean.class, extractPropertyName(attributeName)) != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\ejb\config\LocalStatelessSessionBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */