/*     */ package org.springframework.context.weaving;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.ReflectiveLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.glassfish.GlassFishLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.jboss.JBossLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.tomcat.TomcatLoadTimeWeaver;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultContextLoadTimeWeaver
/*     */   implements LoadTimeWeaver, BeanClassLoaderAware, DisposableBean
/*     */ {
/*  58 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private LoadTimeWeaver loadTimeWeaver;
/*     */ 
/*     */   
/*     */   public DefaultContextLoadTimeWeaver() {}
/*     */ 
/*     */   
/*     */   public DefaultContextLoadTimeWeaver(ClassLoader beanClassLoader) {
/*  68 */     setBeanClassLoader(beanClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/*  74 */     LoadTimeWeaver serverSpecificLoadTimeWeaver = createServerSpecificLoadTimeWeaver(classLoader);
/*  75 */     if (serverSpecificLoadTimeWeaver != null) {
/*  76 */       if (this.logger.isDebugEnabled()) {
/*  77 */         this.logger.debug("Determined server-specific load-time weaver: " + serverSpecificLoadTimeWeaver
/*  78 */             .getClass().getName());
/*     */       }
/*  80 */       this.loadTimeWeaver = serverSpecificLoadTimeWeaver;
/*     */     }
/*  82 */     else if (InstrumentationLoadTimeWeaver.isInstrumentationAvailable()) {
/*  83 */       this.logger.debug("Found Spring's JVM agent for instrumentation");
/*  84 */       this.loadTimeWeaver = (LoadTimeWeaver)new InstrumentationLoadTimeWeaver(classLoader);
/*     */     } else {
/*     */       
/*     */       try {
/*  88 */         this.loadTimeWeaver = (LoadTimeWeaver)new ReflectiveLoadTimeWeaver(classLoader);
/*  89 */         if (this.logger.isDebugEnabled()) {
/*  90 */           this.logger.debug("Using reflective load-time weaver for class loader: " + this.loadTimeWeaver
/*  91 */               .getInstrumentableClassLoader().getClass().getName());
/*     */         }
/*     */       }
/*  94 */       catch (IllegalStateException ex) {
/*  95 */         throw new IllegalStateException(ex.getMessage() + " Specify a custom LoadTimeWeaver or start your Java virtual machine with Spring's agent: -javaagent:spring-instrument-{version}.jar");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected LoadTimeWeaver createServerSpecificLoadTimeWeaver(ClassLoader classLoader) {
/* 109 */     String name = classLoader.getClass().getName();
/*     */     try {
/* 111 */       if (name.startsWith("org.apache.catalina")) {
/* 112 */         return (LoadTimeWeaver)new TomcatLoadTimeWeaver(classLoader);
/*     */       }
/* 114 */       if (name.startsWith("org.glassfish")) {
/* 115 */         return (LoadTimeWeaver)new GlassFishLoadTimeWeaver(classLoader);
/*     */       }
/* 117 */       if (name.startsWith("org.jboss.modules")) {
/* 118 */         return (LoadTimeWeaver)new JBossLoadTimeWeaver(classLoader);
/*     */       }
/*     */     }
/* 121 */     catch (Exception ex) {
/* 122 */       if (this.logger.isInfoEnabled()) {
/* 123 */         this.logger.info("Could not obtain server-specific LoadTimeWeaver: " + ex.getMessage());
/*     */       }
/*     */     } 
/* 126 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 131 */     LoadTimeWeaver loadTimeWeaver = this.loadTimeWeaver; if (loadTimeWeaver instanceof InstrumentationLoadTimeWeaver) { InstrumentationLoadTimeWeaver iltw = (InstrumentationLoadTimeWeaver)loadTimeWeaver;
/* 132 */       if (this.logger.isDebugEnabled()) {
/* 133 */         this.logger.debug("Removing all registered transformers for class loader: " + this.loadTimeWeaver
/* 134 */             .getInstrumentableClassLoader().getClass().getName());
/*     */       }
/* 136 */       iltw.removeTransformers(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTransformer(ClassFileTransformer transformer) {
/* 143 */     Assert.state((this.loadTimeWeaver != null), "Not initialized");
/* 144 */     this.loadTimeWeaver.addTransformer(transformer);
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassLoader getInstrumentableClassLoader() {
/* 149 */     Assert.state((this.loadTimeWeaver != null), "Not initialized");
/* 150 */     return this.loadTimeWeaver.getInstrumentableClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassLoader getThrowawayClassLoader() {
/* 155 */     Assert.state((this.loadTimeWeaver != null), "Not initialized");
/* 156 */     return this.loadTimeWeaver.getThrowawayClassLoader();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\weaving\DefaultContextLoadTimeWeaver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */