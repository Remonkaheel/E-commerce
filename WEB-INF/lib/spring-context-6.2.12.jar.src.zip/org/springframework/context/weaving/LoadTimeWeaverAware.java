package org.springframework.context.weaving;

import org.springframework.beans.factory.Aware;
import org.springframework.instrument.classloading.LoadTimeWeaver;

public interface LoadTimeWeaverAware extends Aware {
  void setLoadTimeWeaver(LoadTimeWeaver paramLoadTimeWeaver);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\weaving\LoadTimeWeaverAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */