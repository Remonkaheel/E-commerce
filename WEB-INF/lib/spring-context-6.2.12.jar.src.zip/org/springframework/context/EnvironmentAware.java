package org.springframework.context;

import org.springframework.beans.factory.Aware;
import org.springframework.core.env.Environment;

public interface EnvironmentAware extends Aware {
  void setEnvironment(Environment paramEnvironment);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\EnvironmentAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */