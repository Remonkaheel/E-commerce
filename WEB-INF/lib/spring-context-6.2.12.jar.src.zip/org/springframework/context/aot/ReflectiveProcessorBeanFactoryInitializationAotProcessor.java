/*    */ package org.springframework.context.aot;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotProcessor;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.RegisteredBean;
/*    */ import org.springframework.context.annotation.ReflectiveScan;
/*    */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReflectiveProcessorBeanFactoryInitializationAotProcessor
/*    */   implements BeanFactoryInitializationAotProcessor
/*    */ {
/*    */   @Nullable
/*    */   public BeanFactoryInitializationAotContribution processAheadOfTime(ConfigurableListableBeanFactory beanFactory) {
/* 50 */     Class<?>[] beanClasses = (Class[])Arrays.<String>stream(beanFactory.getBeanDefinitionNames()).map(beanName -> RegisteredBean.of(beanFactory, beanName).getBeanClass()).toArray(x$0 -> new Class[x$0]);
/* 51 */     String[] packagesToScan = findBasePackagesToScan(beanClasses);
/* 52 */     return (new ReflectiveProcessorAotContributionBuilder()).withClasses(beanClasses)
/* 53 */       .scan(beanFactory.getBeanClassLoader(), packagesToScan).build();
/*    */   }
/*    */   
/*    */   protected String[] findBasePackagesToScan(Class<?>[] beanClasses) {
/* 57 */     Set<String> basePackages = new LinkedHashSet<>();
/* 58 */     for (Class<?> beanClass : beanClasses) {
/* 59 */       ReflectiveScan reflectiveScan = (ReflectiveScan)AnnotatedElementUtils.getMergedAnnotation(beanClass, ReflectiveScan.class);
/* 60 */       if (reflectiveScan != null) {
/* 61 */         basePackages.addAll(extractBasePackages(reflectiveScan, beanClass));
/*    */       }
/*    */     } 
/* 64 */     return basePackages.<String>toArray(new String[0]);
/*    */   }
/*    */   
/*    */   private Set<String> extractBasePackages(ReflectiveScan annotation, Class<?> declaringClass) {
/* 68 */     Set<String> basePackages = new LinkedHashSet<>();
/* 69 */     Collections.addAll(basePackages, annotation.basePackages());
/* 70 */     for (Class<?> clazz : annotation.basePackageClasses()) {
/* 71 */       basePackages.add(ClassUtils.getPackageName(clazz));
/*    */     }
/* 73 */     if (basePackages.isEmpty()) {
/* 74 */       basePackages.add(ClassUtils.getPackageName(declaringClass));
/*    */     }
/* 76 */     return basePackages;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\ReflectiveProcessorBeanFactoryInitializationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */