/*    */ package org.springframework.context.aot;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.BeanInstantiationException;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.context.ApplicationContextInitializer;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface AotApplicationContextInitializer<C extends ConfigurableApplicationContext>
/*    */   extends ApplicationContextInitializer<C>
/*    */ {
/*    */   static <C extends ConfigurableApplicationContext> AotApplicationContextInitializer<C> forInitializerClasses(String... initializerClassNames) {
/* 60 */     Assert.noNullElements((Object[])initializerClassNames, "'initializerClassNames' must not contain null elements");
/* 61 */     return applicationContext -> initialize(applicationContext, initializerClassNames);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static <C extends ConfigurableApplicationContext> void initialize(C applicationContext, String... initializerClassNames) {
/* 67 */     Log logger = LogFactory.getLog(AotApplicationContextInitializer.class);
/* 68 */     ClassLoader classLoader = applicationContext.getClassLoader();
/* 69 */     logger.debug("Initializing ApplicationContext with AOT");
/* 70 */     for (String initializerClassName : initializerClassNames) {
/* 71 */       logger.trace(LogMessage.format("Applying %s", initializerClassName));
/* 72 */       instantiateInitializer(initializerClassName, classLoader).initialize((ConfigurableApplicationContext)applicationContext);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static <C extends ConfigurableApplicationContext> ApplicationContextInitializer<C> instantiateInitializer(String initializerClassName, @Nullable ClassLoader classLoader) {
/*    */     try {
/* 80 */       Class<?> initializerClass = ClassUtils.resolveClassName(initializerClassName, classLoader);
/* 81 */       Assert.isAssignable(ApplicationContextInitializer.class, initializerClass);
/* 82 */       return (ApplicationContextInitializer<C>)BeanUtils.instantiateClass(initializerClass);
/*    */     }
/* 84 */     catch (BeanInstantiationException ex) {
/* 85 */       throw new IllegalArgumentException("Failed to instantiate ApplicationContextInitializer: " + initializerClassName, ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\AotApplicationContextInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */