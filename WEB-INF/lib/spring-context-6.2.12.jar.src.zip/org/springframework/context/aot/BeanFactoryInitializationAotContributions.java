/*    */ package org.springframework.context.aot;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.beans.factory.aot.AotException;
/*    */ import org.springframework.beans.factory.aot.AotProcessingException;
/*    */ import org.springframework.beans.factory.aot.AotServices;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotProcessor;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BeanFactoryInitializationAotContributions
/*    */ {
/*    */   private final List<BeanFactoryInitializationAotContribution> contributions;
/*    */   
/*    */   BeanFactoryInitializationAotContributions(DefaultListableBeanFactory beanFactory) {
/* 46 */     this(beanFactory, AotServices.factoriesAndBeans((ListableBeanFactory)beanFactory));
/*    */   }
/*    */   
/*    */   BeanFactoryInitializationAotContributions(DefaultListableBeanFactory beanFactory, AotServices.Loader loader) {
/* 50 */     this.contributions = getContributions(beanFactory, getProcessors(loader));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static List<BeanFactoryInitializationAotProcessor> getProcessors(AotServices.Loader loader) {
/* 56 */     List<BeanFactoryInitializationAotProcessor> processors = new ArrayList<>(loader.load(BeanFactoryInitializationAotProcessor.class).asList());
/* 57 */     processors.add(new RuntimeHintsBeanFactoryInitializationAotProcessor());
/* 58 */     return Collections.unmodifiableList(processors);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private List<BeanFactoryInitializationAotContribution> getContributions(DefaultListableBeanFactory beanFactory, List<BeanFactoryInitializationAotProcessor> processors) {
/* 64 */     List<BeanFactoryInitializationAotContribution> contributions = new ArrayList<>();
/* 65 */     for (BeanFactoryInitializationAotProcessor processor : processors) {
/* 66 */       BeanFactoryInitializationAotContribution contribution = processAheadOfTime(processor, beanFactory);
/* 67 */       if (contribution != null) {
/* 68 */         contributions.add(contribution);
/*    */       }
/*    */     } 
/* 71 */     return Collections.unmodifiableList(contributions);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private BeanFactoryInitializationAotContribution processAheadOfTime(BeanFactoryInitializationAotProcessor processor, DefaultListableBeanFactory beanFactory) {
/*    */     try {
/* 79 */       return processor.processAheadOfTime((ConfigurableListableBeanFactory)beanFactory);
/*    */     }
/* 81 */     catch (AotException ex) {
/* 82 */       throw ex;
/*    */     }
/* 84 */     catch (Exception ex) {
/* 85 */       throw new AotProcessingException("Error executing '" + processor
/* 86 */           .getClass().getName() + "': " + ex.getMessage(), ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 93 */     for (BeanFactoryInitializationAotContribution contribution : this.contributions)
/* 94 */       contribution.applyTo(generationContext, beanFactoryInitializationCode); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\BeanFactoryInitializationAotContributions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */