/*     */ package org.springframework.context.aot;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.annotation.ReflectiveRuntimeHintsRegistrar;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectiveProcessorAotContributionBuilder
/*     */ {
/*  54 */   private static final ReflectiveRuntimeHintsRegistrar registrar = new ReflectiveRuntimeHintsRegistrar();
/*     */   
/*  56 */   private final Set<Class<?>> classes = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectiveProcessorAotContributionBuilder withClasses(Iterable<Class<?>> classes) {
/*  68 */     Objects.requireNonNull(registrar); this.classes.addAll(StreamSupport.<Class<?>>stream(classes.spliterator(), false).filter(registrar::isCandidate).toList());
/*  69 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectiveProcessorAotContributionBuilder withClasses(Class<?>[] classes) {
/*  80 */     return withClasses(Arrays.asList(classes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectiveProcessorAotContributionBuilder scan(@Nullable ClassLoader classLoader, String... packageNames) {
/*  94 */     ReflectiveClassPathScanner scanner = new ReflectiveClassPathScanner(classLoader);
/*  95 */     return withClasses(scanner.scan(packageNames));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public BeanFactoryInitializationAotContribution build() {
/* 100 */     return !this.classes.isEmpty() ? new AotContribution(this.classes) : null;
/*     */   }
/*     */   
/*     */   private static class AotContribution
/*     */     implements BeanFactoryInitializationAotContribution
/*     */   {
/*     */     private final Class<?>[] classes;
/*     */     
/*     */     public AotContribution(Set<Class<?>> classes) {
/* 109 */       this.classes = (Class[])classes.toArray(x$0 -> new Class[x$0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 114 */       RuntimeHints runtimeHints = generationContext.getRuntimeHints();
/* 115 */       ReflectiveProcessorAotContributionBuilder.registrar.registerRuntimeHints(runtimeHints, this.classes);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ReflectiveClassPathScanner
/*     */     extends ClassPathScanningCandidateComponentProvider
/*     */   {
/*     */     @Nullable
/*     */     private final ClassLoader classLoader;
/*     */     
/*     */     ReflectiveClassPathScanner(@Nullable ClassLoader classLoader) {
/* 126 */       super(false);
/* 127 */       this.classLoader = classLoader;
/* 128 */       addIncludeFilter((metadataReader, metadataReaderFactory) -> true);
/*     */     }
/*     */     
/*     */     Class<?>[] scan(String... packageNames) {
/* 132 */       if (this.logger.isDebugEnabled()) {
/* 133 */         this.logger.debug("Scanning all types for reflective usage from " + Arrays.toString((Object[])packageNames));
/*     */       }
/* 135 */       Set<BeanDefinition> candidates = new HashSet<>();
/* 136 */       for (String packageName : packageNames) {
/* 137 */         candidates.addAll(findCandidateComponents(packageName));
/*     */       }
/* 139 */       return (Class[])candidates.stream().map(c -> (Class)c.getAttribute("type")).toArray(x$0 -> new Class[x$0]);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition) {
/* 144 */       String className = beanDefinition.getBeanClassName();
/* 145 */       if (className != null) {
/*     */         try {
/* 147 */           Class<?> type = ClassUtils.forName(className, this.classLoader);
/* 148 */           beanDefinition.setAttribute("type", type);
/* 149 */           return ReflectiveProcessorAotContributionBuilder.registrar.isCandidate(type);
/*     */         }
/* 151 */         catch (Exception ex) {
/* 152 */           if (this.logger.isTraceEnabled()) {
/* 153 */             this.logger.trace("Ignoring '%s' for reflective usage: %s".formatted(new Object[] { className, ex.getMessage() }));
/*     */           }
/*     */         } 
/*     */       }
/* 157 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\ReflectiveProcessorAotContributionBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */