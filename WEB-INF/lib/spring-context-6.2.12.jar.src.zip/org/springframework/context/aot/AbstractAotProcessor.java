/*     */ package org.springframework.context.aot;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.nio.file.Path;
/*     */ import org.springframework.aot.generate.FileSystemGeneratedFiles;
/*     */ import org.springframework.aot.generate.GeneratedFiles;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.nativex.FileNativeConfigurationWriter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileSystemUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAotProcessor<T>
/*     */ {
/*     */   public static final String AOT_PROCESSING = "spring.aot.processing";
/*     */   private final Settings settings;
/*     */   
/*     */   protected AbstractAotProcessor(Settings settings) {
/*  65 */     this.settings = settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Settings getSettings() {
/*  73 */     return this.settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T process() {
/*     */     try {
/*  82 */       System.setProperty("spring.aot.processing", "true");
/*  83 */       return doProcess();
/*     */     } finally {
/*     */       
/*  86 */       System.clearProperty("spring.aot.processing");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T doProcess();
/*     */ 
/*     */   
/*     */   protected void deleteExistingOutput() {
/*  96 */     deleteExistingOutput(new Path[] { getSettings().getSourceOutput(), 
/*  97 */           getSettings().getResourceOutput(), getSettings().getClassOutput() });
/*     */   }
/*     */   
/*     */   private void deleteExistingOutput(Path... paths) {
/* 101 */     for (Path path : paths) {
/*     */       try {
/* 103 */         FileSystemUtils.deleteRecursively(path);
/*     */       }
/* 105 */       catch (IOException ex) {
/* 106 */         throw new UncheckedIOException("Failed to delete existing output in '" + String.valueOf(path) + "'", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected FileSystemGeneratedFiles createFileSystemGeneratedFiles() {
/* 112 */     return new FileSystemGeneratedFiles(this::getRoot);
/*     */   }
/*     */   
/*     */   private Path getRoot(GeneratedFiles.Kind kind) {
/* 116 */     switch (kind) { default: throw new IncompatibleClassChangeError();case SOURCE: case RESOURCE: case CLASS: break; }  return 
/*     */ 
/*     */       
/* 119 */       getSettings().getClassOutput();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeHints(RuntimeHints hints) {
/* 125 */     FileNativeConfigurationWriter writer = new FileNativeConfigurationWriter(getSettings().getResourceOutput(), getSettings().getGroupId(), getSettings().getArtifactId());
/* 126 */     writer.write(hints);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Settings
/*     */   {
/*     */     private final Path sourceOutput;
/*     */ 
/*     */     
/*     */     private final Path resourceOutput;
/*     */     
/*     */     private final Path classOutput;
/*     */     
/*     */     private final String groupId;
/*     */     
/*     */     private final String artifactId;
/*     */ 
/*     */     
/*     */     private Settings(Path sourceOutput, Path resourceOutput, Path classOutput, String groupId, String artifactId) {
/* 146 */       this.sourceOutput = sourceOutput;
/* 147 */       this.resourceOutput = resourceOutput;
/* 148 */       this.classOutput = classOutput;
/* 149 */       this.groupId = groupId;
/* 150 */       this.artifactId = artifactId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Builder builder() {
/* 157 */       return new Builder();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Path getSourceOutput() {
/* 164 */       return this.sourceOutput;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Path getResourceOutput() {
/* 171 */       return this.resourceOutput;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Path getClassOutput() {
/* 178 */       return this.classOutput;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getGroupId() {
/* 185 */       return this.groupId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getArtifactId() {
/* 192 */       return this.artifactId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Builder
/*     */     {
/*     */       @Nullable
/*     */       private Path sourceOutput;
/*     */ 
/*     */ 
/*     */       
/*     */       @Nullable
/*     */       private Path resourceOutput;
/*     */ 
/*     */ 
/*     */       
/*     */       @Nullable
/*     */       private Path classOutput;
/*     */ 
/*     */ 
/*     */       
/*     */       @Nullable
/*     */       private String groupId;
/*     */ 
/*     */ 
/*     */       
/*     */       @Nullable
/*     */       private String artifactId;
/*     */ 
/*     */ 
/*     */       
/*     */       public Builder sourceOutput(Path sourceOutput) {
/* 226 */         this.sourceOutput = sourceOutput;
/* 227 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Builder resourceOutput(Path resourceOutput) {
/* 236 */         this.resourceOutput = resourceOutput;
/* 237 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Builder classOutput(Path classOutput) {
/* 246 */         this.classOutput = classOutput;
/* 247 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Builder groupId(String groupId) {
/* 257 */         Assert.hasText(groupId, "'groupId' must not be empty");
/* 258 */         this.groupId = groupId;
/* 259 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Builder artifactId(String artifactId) {
/* 269 */         Assert.hasText(artifactId, "'artifactId' must not be empty");
/* 270 */         this.artifactId = artifactId;
/* 271 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public AbstractAotProcessor.Settings build()
/*     */       {
/* 278 */         Assert.notNull(this.sourceOutput, "'sourceOutput' must not be null");
/* 279 */         Assert.notNull(this.resourceOutput, "'resourceOutput' must not be null");
/* 280 */         Assert.notNull(this.classOutput, "'classOutput' must not be null");
/* 281 */         Assert.notNull(this.groupId, "'groupId' must not be null");
/* 282 */         Assert.notNull(this.artifactId, "'artifactId' must not be null");
/* 283 */         return new AbstractAotProcessor.Settings(this.sourceOutput, this.resourceOutput, this.classOutput, this.groupId, this.artifactId); } } } public static final class Builder { public AbstractAotProcessor.Settings build() { Assert.notNull(this.sourceOutput, "'sourceOutput' must not be null"); Assert.notNull(this.resourceOutput, "'resourceOutput' must not be null"); Assert.notNull(this.classOutput, "'classOutput' must not be null"); Assert.notNull(this.groupId, "'groupId' must not be null"); Assert.notNull(this.artifactId, "'artifactId' must not be null"); return new AbstractAotProcessor.Settings(this.sourceOutput, this.resourceOutput, this.classOutput, this.groupId, this.artifactId); }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Path sourceOutput;
/*     */     @Nullable
/*     */     private Path resourceOutput;
/*     */     @Nullable
/*     */     private Path classOutput;
/*     */     @Nullable
/*     */     private String groupId;
/*     */     @Nullable
/*     */     private String artifactId;
/*     */     
/*     */     public Builder sourceOutput(Path sourceOutput) {
/*     */       this.sourceOutput = sourceOutput;
/*     */       return this;
/*     */     }
/*     */     
/*     */     public Builder resourceOutput(Path resourceOutput) {
/*     */       this.resourceOutput = resourceOutput;
/*     */       return this;
/*     */     }
/*     */     
/*     */     public Builder classOutput(Path classOutput) {
/*     */       this.classOutput = classOutput;
/*     */       return this;
/*     */     }
/*     */     
/*     */     public Builder groupId(String groupId) {
/*     */       Assert.hasText(groupId, "'groupId' must not be empty");
/*     */       this.groupId = groupId;
/*     */       return this;
/*     */     }
/*     */     
/*     */     public Builder artifactId(String artifactId) {
/*     */       Assert.hasText(artifactId, "'artifactId' must not be empty");
/*     */       this.artifactId = artifactId;
/*     */       return this;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\AbstractAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */