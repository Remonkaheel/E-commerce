/*     */ package org.springframework.context.aot;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.aot.AotServices;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotProcessor;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.annotation.ImportRuntimeHints;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RuntimeHintsBeanFactoryInitializationAotProcessor
/*     */   implements BeanFactoryInitializationAotProcessor
/*     */ {
/*  55 */   private static final Log logger = LogFactory.getLog(RuntimeHintsBeanFactoryInitializationAotProcessor.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanFactoryInitializationAotContribution processAheadOfTime(ConfigurableListableBeanFactory beanFactory) {
/*  62 */     Map<Class<? extends RuntimeHintsRegistrar>, RuntimeHintsRegistrar> registrars = (Map<Class<? extends RuntimeHintsRegistrar>, RuntimeHintsRegistrar>)AotServices.factories(beanFactory.getBeanClassLoader()).load(RuntimeHintsRegistrar.class).stream().collect(LinkedHashMap::new, (map, item) -> map.put(item.getClass(), item), Map::putAll);
/*  63 */     extractFromBeanFactory(beanFactory).forEach(registrarClass -> registrars.computeIfAbsent(registrarClass, BeanUtils::instantiateClass));
/*     */     
/*  65 */     return new RuntimeHintsRegistrarContribution(registrars.values(), beanFactory.getBeanClassLoader());
/*     */   }
/*     */   
/*     */   private Set<Class<? extends RuntimeHintsRegistrar>> extractFromBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/*  69 */     Set<Class<? extends RuntimeHintsRegistrar>> registrarClasses = new LinkedHashSet<>();
/*  70 */     for (String beanName : beanFactory.getBeanDefinitionNames()) {
/*  71 */       beanFactory.findAllAnnotationsOnBean(beanName, ImportRuntimeHints.class, true)
/*  72 */         .forEach(annotation -> registrarClasses.addAll(extractFromBeanDefinition(beanName, annotation)));
/*     */     }
/*  74 */     return registrarClasses;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<Class<? extends RuntimeHintsRegistrar>> extractFromBeanDefinition(String beanName, ImportRuntimeHints annotation) {
/*  80 */     Class[] arrayOfClass = annotation.value();
/*  81 */     Set<Class<? extends RuntimeHintsRegistrar>> registrars = CollectionUtils.newLinkedHashSet(arrayOfClass.length);
/*  82 */     for (Class<? extends RuntimeHintsRegistrar> registrarClass : arrayOfClass) {
/*  83 */       if (logger.isTraceEnabled()) {
/*  84 */         logger.trace(LogMessage.format("Loaded [%s] registrar from annotated bean [%s]", registrarClass
/*  85 */               .getCanonicalName(), beanName));
/*     */       }
/*  87 */       registrars.add(registrarClass);
/*     */     } 
/*  89 */     return registrars;
/*     */   }
/*     */ 
/*     */   
/*     */   static class RuntimeHintsRegistrarContribution
/*     */     implements BeanFactoryInitializationAotContribution
/*     */   {
/*     */     private final Iterable<RuntimeHintsRegistrar> registrars;
/*     */     
/*     */     @Nullable
/*     */     private final ClassLoader beanClassLoader;
/*     */ 
/*     */     
/*     */     RuntimeHintsRegistrarContribution(Iterable<RuntimeHintsRegistrar> registrars, @Nullable ClassLoader beanClassLoader) {
/* 103 */       this.registrars = registrars;
/* 104 */       this.beanClassLoader = beanClassLoader;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 111 */       RuntimeHints hints = generationContext.getRuntimeHints();
/* 112 */       this.registrars.forEach(registrar -> {
/*     */             if (RuntimeHintsBeanFactoryInitializationAotProcessor.logger.isTraceEnabled())
/*     */               RuntimeHintsBeanFactoryInitializationAotProcessor.logger.trace(LogMessage.format("Processing RuntimeHints contribution from [%s]", registrar.getClass().getCanonicalName())); 
/*     */             registrar.registerHints(hints, this.beanClassLoader);
/*     */           });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\RuntimeHintsBeanFactoryInitializationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */