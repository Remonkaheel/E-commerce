/*     */ package org.springframework.context.aot;
/*     */ 
/*     */ import java.util.function.Function;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.TypeName;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InitializerMethodArgumentCodeGenerator
/*     */   implements Function<TypeName, CodeBlock>
/*     */ {
/*     */   @Nullable
/*     */   public CodeBlock apply(TypeName typeName) {
/* 147 */     ClassName className = (ClassName)typeName; return (typeName instanceof ClassName) ? apply(className) : null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private CodeBlock apply(ClassName className) {
/* 152 */     String name = className.canonicalName();
/* 153 */     if (name.equals(DefaultListableBeanFactory.class.getName()) || name
/* 154 */       .equals(ConfigurableListableBeanFactory.class.getName())) {
/* 155 */       return CodeBlock.of("beanFactory", new Object[0]);
/*     */     }
/* 157 */     if (name.equals(ConfigurableEnvironment.class.getName()) || name
/* 158 */       .equals(Environment.class.getName())) {
/* 159 */       return CodeBlock.of("$L.getEnvironment()", new Object[] { "applicationContext" });
/*     */     }
/* 161 */     if (name.equals(ResourceLoader.class.getName())) {
/* 162 */       return CodeBlock.of("applicationContext", new Object[0]);
/*     */     }
/* 164 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\ApplicationContextInitializationCodeGenerator$InitializerMethodArgumentCodeGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */