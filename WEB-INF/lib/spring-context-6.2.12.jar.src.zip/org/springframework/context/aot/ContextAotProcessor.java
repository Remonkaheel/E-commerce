/*     */ package org.springframework.context.aot;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.aot.generate.ClassNameGenerator;
/*     */ import org.springframework.aot.generate.DefaultGenerationContext;
/*     */ import org.springframework.aot.generate.FileSystemGeneratedFiles;
/*     */ import org.springframework.aot.generate.GeneratedFiles;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.ReflectionHints;
/*     */ import org.springframework.aot.hint.TypeHint;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ import org.springframework.context.support.GenericApplicationContext;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ContextAotProcessor
/*     */   extends AbstractAotProcessor<ClassName>
/*     */ {
/*     */   private final Class<?> applicationClass;
/*     */   
/*     */   protected ContextAotProcessor(Class<?> applicationClass, AbstractAotProcessor.Settings settings) {
/*  61 */     super(settings);
/*  62 */     this.applicationClass = applicationClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> getApplicationClass() {
/*  70 */     return this.applicationClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassName doProcess() {
/*  82 */     deleteExistingOutput();
/*  83 */     GenericApplicationContext applicationContext = prepareApplicationContext(getApplicationClass()); try {
/*  84 */       ClassName className = performAotProcessing(applicationContext);
/*  85 */       if (applicationContext != null) applicationContext.close();
/*     */       
/*     */       return className;
/*     */     } catch (Throwable throwable) {
/*     */       if (applicationContext != null) {
/*     */         try {
/*     */           applicationContext.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         } 
/*     */       }
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassName performAotProcessing(GenericApplicationContext applicationContext) {
/* 103 */     FileSystemGeneratedFiles generatedFiles = createFileSystemGeneratedFiles();
/*     */     
/* 105 */     DefaultGenerationContext generationContext = new DefaultGenerationContext(createClassNameGenerator(), (GeneratedFiles)generatedFiles);
/* 106 */     ApplicationContextAotGenerator generator = new ApplicationContextAotGenerator();
/* 107 */     ClassName generatedInitializerClassName = generator.processAheadOfTime(applicationContext, (GenerationContext)generationContext);
/* 108 */     registerEntryPointHint(generationContext, generatedInitializerClassName);
/* 109 */     generationContext.writeGeneratedContent();
/* 110 */     writeHints(generationContext.getRuntimeHints());
/* 111 */     writeNativeImageProperties(getDefaultNativeImageArguments(getApplicationClass().getName()));
/* 112 */     return generatedInitializerClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassNameGenerator createClassNameGenerator() {
/* 123 */     return new ClassNameGenerator(ClassName.get(getApplicationClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> getDefaultNativeImageArguments(String applicationClassName) {
/* 137 */     List<String> args = new ArrayList<>();
/* 138 */     args.add("-H:Class=" + applicationClassName);
/* 139 */     args.add("--report-unsupported-elements-at-runtime");
/* 140 */     args.add("--no-fallback");
/* 141 */     args.add("--install-exit-handlers");
/* 142 */     return args;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerEntryPointHint(DefaultGenerationContext generationContext, ClassName generatedInitializerClassName) {
/* 148 */     TypeReference generatedType = TypeReference.of(generatedInitializerClassName.canonicalName());
/* 149 */     TypeReference applicationType = TypeReference.of(getApplicationClass());
/* 150 */     ReflectionHints reflection = generationContext.getRuntimeHints().reflection();
/* 151 */     reflection.registerType(applicationType, new org.springframework.aot.hint.MemberCategory[0]);
/* 152 */     reflection.registerType(generatedType, typeHint -> typeHint.onReachableType(applicationType).withConstructor(Collections.emptyList(), ExecutableMode.INVOKE));
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeNativeImageProperties(List<String> args) {
/* 157 */     if (CollectionUtils.isEmpty(args)) {
/*     */       return;
/*     */     }
/* 160 */     StringBuilder sb = new StringBuilder();
/* 161 */     sb.append("Args = ");
/* 162 */     sb.append(String.join(String.format(" \\%n", new Object[0]), (Iterable)args));
/* 163 */     Path file = getSettings().getResourceOutput().resolve("META-INF/native-image/" + 
/* 164 */         getSettings().getGroupId() + "/" + getSettings().getArtifactId() + "/native-image.properties");
/*     */     try {
/* 166 */       if (!Files.exists(file, new java.nio.file.LinkOption[0])) {
/* 167 */         Files.createDirectories(file.getParent(), (FileAttribute<?>[])new FileAttribute[0]);
/* 168 */         Files.createFile(file, (FileAttribute<?>[])new FileAttribute[0]);
/*     */       } 
/* 170 */       Files.writeString(file, sb.toString(), new java.nio.file.OpenOption[0]);
/*     */     }
/* 172 */     catch (IOException ex) {
/* 173 */       throw new IllegalStateException("Failed to write native-image.properties", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract GenericApplicationContext prepareApplicationContext(Class<?> paramClass);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\ContextAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */