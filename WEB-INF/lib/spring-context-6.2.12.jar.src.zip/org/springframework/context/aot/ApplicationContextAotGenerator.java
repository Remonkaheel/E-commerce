/*    */ package org.springframework.context.aot;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*    */ import org.springframework.cglib.core.ReflectUtils;
/*    */ import org.springframework.context.support.GenericApplicationContext;
/*    */ import org.springframework.javapoet.ClassName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationContextAotGenerator
/*    */ {
/*    */   public ClassName processAheadOfTime(GenericApplicationContext applicationContext, GenerationContext generationContext) {
/* 54 */     return withCglibClassHandler(new CglibClassHandler(generationContext), () -> {
/*    */           applicationContext.refreshForAotProcessing(generationContext.getRuntimeHints());
/*    */           ApplicationContextInitializationCodeGenerator codeGenerator = new ApplicationContextInitializationCodeGenerator(applicationContext, generationContext);
/*    */           DefaultListableBeanFactory beanFactory = applicationContext.getDefaultListableBeanFactory();
/*    */           (new BeanFactoryInitializationAotContributions(beanFactory)).applyTo(generationContext, codeGenerator);
/*    */           return codeGenerator.getGeneratedClass().getName();
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   private <T> T withCglibClassHandler(CglibClassHandler cglibClassHandler, Supplier<T> task) {
/*    */     try {
/* 66 */       Objects.requireNonNull(cglibClassHandler); ReflectUtils.setLoadedClassHandler(cglibClassHandler::handleLoadedClass);
/* 67 */       Objects.requireNonNull(cglibClassHandler); ReflectUtils.setGeneratedClassHandler(cglibClassHandler::handleGeneratedClass);
/* 68 */       return task.get();
/*    */     } finally {
/*    */       
/* 71 */       ReflectUtils.setLoadedClassHandler(null);
/* 72 */       ReflectUtils.setGeneratedClassHandler(null);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\ApplicationContextAotGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */