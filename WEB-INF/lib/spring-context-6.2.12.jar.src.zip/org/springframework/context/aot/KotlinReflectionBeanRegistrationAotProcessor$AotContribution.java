/*    */ package org.springframework.context.aot;
/*    */ 
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*    */ import org.springframework.core.KotlinDetector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AotContribution
/*    */   implements BeanRegistrationAotContribution
/*    */ {
/*    */   private final Class<?> beanClass;
/*    */   
/*    */   public AotContribution(Class<?> beanClass) {
/* 54 */     this.beanClass = beanClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 59 */     registerHints(this.beanClass, generationContext.getRuntimeHints());
/*    */   }
/*    */   
/*    */   private void registerHints(Class<?> type, RuntimeHints runtimeHints) {
/* 63 */     if (KotlinDetector.isKotlinType(type)) {
/* 64 */       runtimeHints.reflection().registerType(type, new MemberCategory[] { MemberCategory.INTROSPECT_DECLARED_METHODS });
/*    */     }
/* 66 */     Class<?> superClass = type.getSuperclass();
/* 67 */     if (superClass != null) {
/* 68 */       registerHints(superClass, runtimeHints);
/*    */     }
/* 70 */     Class<?> enclosingClass = type.getEnclosingClass();
/* 71 */     if (enclosingClass != null)
/* 72 */       runtimeHints.reflection().registerType(enclosingClass, new MemberCategory[0]); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\KotlinReflectionBeanRegistrationAotProcessor$AotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */