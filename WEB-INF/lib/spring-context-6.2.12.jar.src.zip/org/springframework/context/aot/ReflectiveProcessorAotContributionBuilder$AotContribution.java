/*     */ package org.springframework.context.aot;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AotContribution
/*     */   implements BeanFactoryInitializationAotContribution
/*     */ {
/*     */   private final Class<?>[] classes;
/*     */   
/*     */   public AotContribution(Set<Class<?>> classes) {
/* 109 */     this.classes = (Class[])classes.toArray(x$0 -> new Class[x$0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 114 */     RuntimeHints runtimeHints = generationContext.getRuntimeHints();
/* 115 */     ReflectiveProcessorAotContributionBuilder.registrar.registerRuntimeHints(runtimeHints, this.classes);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\ReflectiveProcessorAotContributionBuilder$AotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */