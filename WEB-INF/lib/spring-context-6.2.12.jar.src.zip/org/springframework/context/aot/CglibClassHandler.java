/*    */ package org.springframework.context.aot;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.aot.generate.GeneratedFiles;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.TypeHint;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.core.io.ByteArrayResource;
/*    */ import org.springframework.core.io.InputStreamSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CglibClassHandler
/*    */ {
/*    */   private static final Consumer<TypeHint.Builder> instantiateCglibProxy;
/*    */   private final RuntimeHints runtimeHints;
/*    */   private final GeneratedFiles generatedFiles;
/*    */   
/*    */   static {
/* 44 */     instantiateCglibProxy = (hint -> hint.withMembers(new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   CglibClassHandler(GenerationContext generationContext) {
/* 53 */     this.runtimeHints = generationContext.getRuntimeHints();
/* 54 */     this.generatedFiles = generationContext.getGeneratedFiles();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void handleGeneratedClass(String cglibClassName, byte[] content) {
/* 64 */     registerHints(TypeReference.of(cglibClassName));
/* 65 */     String path = cglibClassName.replace(".", "/") + ".class";
/* 66 */     this.generatedFiles.addFile(GeneratedFiles.Kind.CLASS, path, (InputStreamSource)new ByteArrayResource(content));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void handleLoadedClass(Class<?> cglibClass) {
/* 74 */     registerHints(TypeReference.of(cglibClass));
/*    */   }
/*    */   
/*    */   private void registerHints(TypeReference cglibTypeReference) {
/* 78 */     this.runtimeHints.reflection().registerType(cglibTypeReference, instantiateCglibProxy);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\CglibClassHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */