/*     */ package org.springframework.context.aot;
/*     */ 
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RuntimeHintsRegistrarContribution
/*     */   implements BeanFactoryInitializationAotContribution
/*     */ {
/*     */   private final Iterable<RuntimeHintsRegistrar> registrars;
/*     */   @Nullable
/*     */   private final ClassLoader beanClassLoader;
/*     */   
/*     */   RuntimeHintsRegistrarContribution(Iterable<RuntimeHintsRegistrar> registrars, @Nullable ClassLoader beanClassLoader) {
/* 103 */     this.registrars = registrars;
/* 104 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 111 */     RuntimeHints hints = generationContext.getRuntimeHints();
/* 112 */     this.registrars.forEach(registrar -> {
/*     */           if (RuntimeHintsBeanFactoryInitializationAotProcessor.logger.isTraceEnabled())
/*     */             RuntimeHintsBeanFactoryInitializationAotProcessor.logger.trace(LogMessage.format("Processing RuntimeHints contribution from [%s]", registrar.getClass().getCanonicalName())); 
/*     */           registrar.registerHints(hints, this.beanClassLoader);
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\RuntimeHintsBeanFactoryInitializationAotProcessor$RuntimeHintsRegistrarContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */