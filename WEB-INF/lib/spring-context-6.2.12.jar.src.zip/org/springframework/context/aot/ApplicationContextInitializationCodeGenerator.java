/*     */ package org.springframework.context.aot;
/*     */ 
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.GeneratedClass;
/*     */ import org.springframework.aot.generate.GeneratedMethods;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.generate.MethodReference;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.annotation.ContextAnnotationAutowireCandidateResolver;
/*     */ import org.springframework.context.support.GenericApplicationContext;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.ParameterizedTypeName;
/*     */ import org.springframework.javapoet.TypeName;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ApplicationContextInitializationCodeGenerator
/*     */   implements BeanFactoryInitializationCode
/*     */ {
/*     */   private static final String INITIALIZE_METHOD = "initialize";
/*     */   private static final String APPLICATION_CONTEXT_VARIABLE = "applicationContext";
/*     */   private final GenericApplicationContext applicationContext;
/*     */   private final GeneratedClass generatedClass;
/*  66 */   private final List<MethodReference> initializers = new ArrayList<>();
/*     */ 
/*     */   
/*     */   ApplicationContextInitializationCodeGenerator(GenericApplicationContext applicationContext, GenerationContext generationContext) {
/*  70 */     this.applicationContext = applicationContext;
/*  71 */     this
/*  72 */       .generatedClass = generationContext.getGeneratedClasses().addForFeature("ApplicationContextInitializer", this::generateType);
/*  73 */     this.generatedClass.reserveMethodNames(new String[] { "initialize" });
/*     */   }
/*     */ 
/*     */   
/*     */   private void generateType(TypeSpec.Builder type) {
/*  78 */     type.addJavadoc("{@link $T} to restore an application context based on previous AOT processing.", new Object[] { ApplicationContextInitializer.class });
/*     */ 
/*     */     
/*  81 */     type.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*  82 */     type.addSuperinterface((TypeName)ParameterizedTypeName.get(ApplicationContextInitializer.class, new Type[] { GenericApplicationContext.class }));
/*     */     
/*  84 */     type.addMethod(generateInitializeMethod());
/*     */   }
/*     */   
/*     */   private MethodSpec generateInitializeMethod() {
/*  88 */     MethodSpec.Builder method = MethodSpec.methodBuilder("initialize");
/*  89 */     method.addAnnotation(Override.class);
/*  90 */     method.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*  91 */     method.addParameter(GenericApplicationContext.class, "applicationContext", new Modifier[0]);
/*  92 */     method.addCode(generateInitializeCode());
/*  93 */     return method.build();
/*     */   }
/*     */   
/*     */   private CodeBlock generateInitializeCode() {
/*  97 */     CodeBlock.Builder code = CodeBlock.builder();
/*  98 */     code.addStatement("$T $L = $L.getDefaultListableBeanFactory()", new Object[] { DefaultListableBeanFactory.class, "beanFactory", "applicationContext" });
/*     */ 
/*     */     
/* 101 */     code.addStatement("$L.setAutowireCandidateResolver(new $T())", new Object[] { "beanFactory", ContextAnnotationAutowireCandidateResolver.class });
/*     */     
/* 103 */     code.addStatement("$L.setDependencyComparator($T.INSTANCE)", new Object[] { "beanFactory", AnnotationAwareOrderComparator.class });
/*     */     
/* 105 */     code.add(generateActiveProfilesInitializeCode());
/* 106 */     MethodReference.ArgumentCodeGenerator argCodeGenerator = createInitializerMethodArgumentCodeGenerator();
/* 107 */     for (MethodReference initializer : this.initializers) {
/* 108 */       code.addStatement(initializer.toInvokeCodeBlock(argCodeGenerator, this.generatedClass.getName()));
/*     */     }
/* 110 */     return code.build();
/*     */   }
/*     */   
/*     */   private CodeBlock generateActiveProfilesInitializeCode() {
/* 114 */     CodeBlock.Builder code = CodeBlock.builder();
/* 115 */     ConfigurableEnvironment environment = this.applicationContext.getEnvironment();
/* 116 */     if (!Arrays.equals((Object[])environment.getActiveProfiles(), (Object[])environment.getDefaultProfiles())) {
/* 117 */       for (String activeProfile : environment.getActiveProfiles()) {
/* 118 */         code.addStatement("$L.getEnvironment().addActiveProfile($S)", new Object[] { "applicationContext", activeProfile });
/*     */       } 
/*     */     }
/* 121 */     return code.build();
/*     */   }
/*     */   
/*     */   static MethodReference.ArgumentCodeGenerator createInitializerMethodArgumentCodeGenerator() {
/* 125 */     return MethodReference.ArgumentCodeGenerator.from(new InitializerMethodArgumentCodeGenerator());
/*     */   }
/*     */   
/*     */   GeneratedClass getGeneratedClass() {
/* 129 */     return this.generatedClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public GeneratedMethods getMethods() {
/* 134 */     return this.generatedClass.getMethods();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addInitializer(MethodReference methodReference) {
/* 139 */     this.initializers.add(methodReference);
/*     */   }
/*     */   
/*     */   private static class InitializerMethodArgumentCodeGenerator
/*     */     implements Function<TypeName, CodeBlock>
/*     */   {
/*     */     @Nullable
/*     */     public CodeBlock apply(TypeName typeName) {
/* 147 */       ClassName className = (ClassName)typeName; return (typeName instanceof ClassName) ? apply(className) : null;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private CodeBlock apply(ClassName className) {
/* 152 */       String name = className.canonicalName();
/* 153 */       if (name.equals(DefaultListableBeanFactory.class.getName()) || name
/* 154 */         .equals(ConfigurableListableBeanFactory.class.getName())) {
/* 155 */         return CodeBlock.of("beanFactory", new Object[0]);
/*     */       }
/* 157 */       if (name.equals(ConfigurableEnvironment.class.getName()) || name
/* 158 */         .equals(Environment.class.getName())) {
/* 159 */         return CodeBlock.of("$L.getEnvironment()", new Object[] { "applicationContext" });
/*     */       }
/* 161 */       if (name.equals(ResourceLoader.class.getName())) {
/* 162 */         return CodeBlock.of("applicationContext", new Object[0]);
/*     */       }
/* 164 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\aot\ApplicationContextInitializationCodeGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */