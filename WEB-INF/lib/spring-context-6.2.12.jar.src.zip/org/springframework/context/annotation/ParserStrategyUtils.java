/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ParserStrategyUtils
/*     */ {
/*     */   static <T> T instantiateClass(Class<?> clazz, Class<T> assignableTo, Environment environment, ResourceLoader resourceLoader, BeanDefinitionRegistry registry) {
/*  58 */     Assert.notNull(clazz, "Class must not be null");
/*  59 */     Assert.isAssignable(assignableTo, clazz);
/*  60 */     if (clazz.isInterface()) {
/*  61 */       throw new BeanInstantiationException(clazz, "Specified class is an interface");
/*     */     }
/*  63 */     ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)registry;
/*  64 */     ClassLoader classLoader = (registry instanceof ConfigurableBeanFactory) ? cbf.getBeanClassLoader() : resourceLoader.getClassLoader();
/*  65 */     T instance = (T)createInstance(clazz, environment, resourceLoader, registry, classLoader);
/*  66 */     invokeAwareMethods(instance, environment, resourceLoader, registry, classLoader);
/*  67 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object createInstance(Class<?> clazz, Environment environment, ResourceLoader resourceLoader, BeanDefinitionRegistry registry, @Nullable ClassLoader classLoader) {
/*  74 */     Constructor[] arrayOfConstructor = (Constructor[])clazz.getDeclaredConstructors();
/*  75 */     if (arrayOfConstructor.length == 1 && arrayOfConstructor[0].getParameterCount() > 0) {
/*     */       try {
/*  77 */         Constructor<?> constructor = arrayOfConstructor[0];
/*  78 */         Object[] args = resolveArgs(constructor.getParameterTypes(), environment, resourceLoader, registry, classLoader);
/*     */         
/*  80 */         return BeanUtils.instantiateClass(constructor, args);
/*     */       }
/*  82 */       catch (Exception ex) {
/*  83 */         throw new BeanInstantiationException(clazz, "No suitable constructor found", ex);
/*     */       } 
/*     */     }
/*  86 */     return BeanUtils.instantiateClass(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object[] resolveArgs(Class<?>[] parameterTypes, Environment environment, ResourceLoader resourceLoader, BeanDefinitionRegistry registry, @Nullable ClassLoader classLoader) {
/*  93 */     Object[] parameters = new Object[parameterTypes.length];
/*  94 */     for (int i = 0; i < parameterTypes.length; i++) {
/*  95 */       parameters[i] = resolveParameter(parameterTypes[i], environment, resourceLoader, registry, classLoader);
/*     */     }
/*     */     
/*  98 */     return parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Object resolveParameter(Class<?> parameterType, Environment environment, ResourceLoader resourceLoader, BeanDefinitionRegistry registry, @Nullable ClassLoader classLoader) {
/* 106 */     if (parameterType == Environment.class) {
/* 107 */       return environment;
/*     */     }
/* 109 */     if (parameterType == ResourceLoader.class) {
/* 110 */       return resourceLoader;
/*     */     }
/* 112 */     if (parameterType == BeanFactory.class) {
/* 113 */       return (registry instanceof BeanFactory) ? registry : null;
/*     */     }
/* 115 */     if (parameterType == ClassLoader.class) {
/* 116 */       return classLoader;
/*     */     }
/* 118 */     throw new IllegalStateException("Illegal method parameter type: " + parameterType.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void invokeAwareMethods(Object parserStrategyBean, Environment environment, ResourceLoader resourceLoader, BeanDefinitionRegistry registry, @Nullable ClassLoader classLoader) {
/* 124 */     if (parserStrategyBean instanceof org.springframework.beans.factory.Aware) {
/* 125 */       if (parserStrategyBean instanceof BeanClassLoaderAware) { BeanClassLoaderAware beanClassLoaderAware = (BeanClassLoaderAware)parserStrategyBean; if (classLoader != null)
/* 126 */           beanClassLoaderAware.setBeanClassLoader(classLoader);  }
/*     */       
/* 128 */       if (parserStrategyBean instanceof BeanFactoryAware) { BeanFactoryAware beanFactoryAware = (BeanFactoryAware)parserStrategyBean; if (registry instanceof BeanFactory) {
/* 129 */           BeanFactory beanFactory = (BeanFactory)registry;
/* 130 */           beanFactoryAware.setBeanFactory(beanFactory);
/*     */         }  }
/* 132 */        if (parserStrategyBean instanceof EnvironmentAware) { EnvironmentAware environmentAware = (EnvironmentAware)parserStrategyBean;
/* 133 */         environmentAware.setEnvironment(environment); }
/*     */       
/* 135 */       if (parserStrategyBean instanceof ResourceLoaderAware) { ResourceLoaderAware resourceLoaderAware = (ResourceLoaderAware)parserStrategyBean;
/* 136 */         resourceLoaderAware.setResourceLoader(resourceLoader); }
/*     */     
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ParserStrategyUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */