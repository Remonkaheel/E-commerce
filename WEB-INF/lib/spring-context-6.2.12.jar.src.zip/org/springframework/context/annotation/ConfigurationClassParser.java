/*      */ package org.springframework.context.annotation;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Deque;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import java.util.StringJoiner;
/*      */ import java.util.function.Predicate;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*      */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*      */ import org.springframework.beans.factory.parsing.Location;
/*      */ import org.springframework.beans.factory.parsing.Problem;
/*      */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*      */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionReader;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*      */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*      */ import org.springframework.context.ApplicationContextException;
/*      */ import org.springframework.core.OrderComparator;
/*      */ import org.springframework.core.Ordered;
/*      */ import org.springframework.core.annotation.AnnotationAttributes;
/*      */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*      */ import org.springframework.core.annotation.AnnotationUtils;
/*      */ import org.springframework.core.annotation.MergedAnnotation;
/*      */ import org.springframework.core.env.ConfigurableEnvironment;
/*      */ import org.springframework.core.env.Environment;
/*      */ import org.springframework.core.io.ResourceLoader;
/*      */ import org.springframework.core.io.support.PropertySourceDescriptor;
/*      */ import org.springframework.core.io.support.PropertySourceProcessor;
/*      */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*      */ import org.springframework.core.type.AnnotationMetadata;
/*      */ import org.springframework.core.type.MethodMetadata;
/*      */ import org.springframework.core.type.StandardAnnotationMetadata;
/*      */ import org.springframework.core.type.classreading.MetadataReader;
/*      */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*      */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.stereotype.Component;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.LinkedMultiValueMap;
/*      */ import org.springframework.util.MultiValueMap;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class ConfigurationClassParser
/*      */ {
/*      */   private static final Predicate<String> DEFAULT_EXCLUSION_FILTER;
/*      */   private static final Predicate<Condition> REGISTER_BEAN_CONDITION_FILTER;
/*      */   private static final Comparator<DeferredImportSelectorHolder> DEFERRED_IMPORT_COMPARATOR;
/*      */   
/*      */   static {
/*  104 */     DEFAULT_EXCLUSION_FILTER = (className -> 
/*  105 */       (className.startsWith("java.lang.annotation.") || className.startsWith("org.springframework.stereotype.")));
/*      */     
/*  107 */     REGISTER_BEAN_CONDITION_FILTER = (condition -> {
/*      */         if (condition instanceof ConfigurationCondition) {
/*      */           ConfigurationCondition configurationCondition = (ConfigurationCondition)condition; if (ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN.equals(configurationCondition.getConfigurationPhase()));
/*      */         }  return false;
/*  111 */       }); DEFERRED_IMPORT_COMPARATOR = ((o1, o2) -> AnnotationAwareOrderComparator.INSTANCE.compare(o1.getImportSelector(), o2.getImportSelector()));
/*      */   }
/*      */ 
/*      */   
/*  115 */   private final Log logger = LogFactory.getLog(getClass());
/*      */   
/*      */   private final MetadataReaderFactory metadataReaderFactory;
/*      */   
/*      */   private final ProblemReporter problemReporter;
/*      */   
/*      */   private final Environment environment;
/*      */   
/*      */   private final ResourceLoader resourceLoader;
/*      */   
/*      */   @Nullable
/*      */   private final PropertySourceRegistry propertySourceRegistry;
/*      */   
/*      */   private final BeanDefinitionRegistry registry;
/*      */   
/*      */   private final ComponentScanAnnotationParser componentScanParser;
/*      */   
/*      */   private final ConditionEvaluator conditionEvaluator;
/*      */   
/*  134 */   private final Map<ConfigurationClass, ConfigurationClass> configurationClasses = new LinkedHashMap<>();
/*      */   
/*  136 */   private final MultiValueMap<String, ConfigurationClass> knownSuperclasses = (MultiValueMap<String, ConfigurationClass>)new LinkedMultiValueMap();
/*      */   
/*  138 */   private final ImportStack importStack = new ImportStack();
/*      */   
/*  140 */   private final DeferredImportSelectorHandler deferredImportSelectorHandler = new DeferredImportSelectorHandler();
/*      */   
/*  142 */   private final SourceClass objectSourceClass = new SourceClass(Object.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConfigurationClassParser(MetadataReaderFactory metadataReaderFactory, ProblemReporter problemReporter, Environment environment, ResourceLoader resourceLoader, BeanNameGenerator componentScanBeanNameGenerator, BeanDefinitionRegistry registry) {
/*  153 */     this.metadataReaderFactory = metadataReaderFactory;
/*  154 */     this.problemReporter = problemReporter;
/*  155 */     this.environment = environment;
/*  156 */     this.resourceLoader = resourceLoader;
/*  157 */     Environment environment1 = this.environment; ConfigurableEnvironment ce = (ConfigurableEnvironment)environment1; this
/*  158 */       .propertySourceRegistry = (environment1 instanceof ConfigurableEnvironment) ? new PropertySourceRegistry(new PropertySourceProcessor(ce, this.resourceLoader)) : null;
/*  159 */     this.registry = registry;
/*  160 */     this.componentScanParser = new ComponentScanAnnotationParser(environment, resourceLoader, componentScanBeanNameGenerator, registry);
/*      */     
/*  162 */     this.conditionEvaluator = new ConditionEvaluator(registry, environment, resourceLoader);
/*      */   }
/*      */ 
/*      */   
/*      */   public void parse(Set<BeanDefinitionHolder> configCandidates) {
/*  167 */     Iterator<BeanDefinitionHolder> iterator = configCandidates.iterator(); label25: while (true) { BeanDefinition bd; while (true) { if (iterator.hasNext()) { BeanDefinitionHolder holder = iterator.next();
/*  168 */           bd = holder.getBeanDefinition();
/*      */ 
/*      */           
/*  171 */           try { if (bd instanceof AnnotatedBeanDefinition) { AnnotatedBeanDefinition annotatedBeanDef = (AnnotatedBeanDefinition)bd;
/*  172 */               ConfigurationClass configurationClass = parse(annotatedBeanDef, holder.getBeanName()); break; }
/*      */             
/*  174 */             if (bd instanceof AbstractBeanDefinition) { AbstractBeanDefinition abstractBeanDef = (AbstractBeanDefinition)bd; if (abstractBeanDef.hasBeanClass()) {
/*  175 */                 ConfigurationClass configurationClass = parse(abstractBeanDef.getBeanClass(), holder.getBeanName()); break;
/*      */               }  }
/*      */             
/*  178 */             ConfigurationClass configClass = parse(bd.getBeanClassName(), holder.getBeanName());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */              }
/*      */           
/*  189 */           catch (BeanDefinitionStoreException beanDefinitionStoreException)
/*  190 */           { throw beanDefinitionStoreException; }
/*      */           
/*  192 */           catch (Throwable ex)
/*  193 */           { throw new BeanDefinitionStoreException("Failed to parse configuration class [" + bd
/*  194 */                 .getBeanClassName() + "]", ex); }  break; }
/*      */          break label25; }
/*      */        if (!ex.getMetadata().isAbstract() && !ex.hasNonStaticBeanMethods() && "full".equals(bd.getAttribute(ConfigurationClassUtils.CONFIGURATION_CLASS_ATTRIBUTE)))
/*      */         bd.setAttribute(ConfigurationClassUtils.CONFIGURATION_CLASS_ATTRIBUTE, "lite");  }
/*  198 */      this.deferredImportSelectorHandler.process();
/*      */   }
/*      */ 
/*      */   
/*      */   private ConfigurationClass parse(AnnotatedBeanDefinition beanDef, String beanName) {
/*  203 */     ConfigurationClass configClass = new ConfigurationClass(beanDef.getMetadata(), beanName, beanDef instanceof ScannedGenericBeanDefinition);
/*  204 */     processConfigurationClass(configClass, DEFAULT_EXCLUSION_FILTER);
/*  205 */     return configClass;
/*      */   }
/*      */   
/*      */   private ConfigurationClass parse(Class<?> clazz, String beanName) {
/*  209 */     ConfigurationClass configClass = new ConfigurationClass(clazz, beanName);
/*  210 */     processConfigurationClass(configClass, DEFAULT_EXCLUSION_FILTER);
/*  211 */     return configClass;
/*      */   }
/*      */   
/*      */   final ConfigurationClass parse(@Nullable String className, String beanName) throws IOException {
/*  215 */     Assert.notNull(className, "No bean class name for configuration class bean definition");
/*  216 */     MetadataReader reader = this.metadataReaderFactory.getMetadataReader(className);
/*  217 */     ConfigurationClass configClass = new ConfigurationClass(reader, beanName);
/*  218 */     processConfigurationClass(configClass, DEFAULT_EXCLUSION_FILTER);
/*  219 */     return configClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void validate() {
/*  227 */     for (ConfigurationClass configClass : this.configurationClasses.keySet()) {
/*  228 */       configClass.validate(this.problemReporter);
/*      */     }
/*      */   }
/*      */   
/*      */   Set<ConfigurationClass> getConfigurationClasses() {
/*  233 */     return this.configurationClasses.keySet();
/*      */   }
/*      */   
/*      */   List<PropertySourceDescriptor> getPropertySourceDescriptors() {
/*  237 */     return (this.propertySourceRegistry != null) ? this.propertySourceRegistry.getDescriptors() : 
/*  238 */       Collections.<PropertySourceDescriptor>emptyList();
/*      */   }
/*      */   
/*      */   ImportRegistry getImportRegistry() {
/*  242 */     return this.importStack;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void processConfigurationClass(ConfigurationClass configClass, Predicate<String> filter) {
/*  247 */     if (this.conditionEvaluator.shouldSkip((AnnotatedTypeMetadata)configClass.getMetadata(), ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION)) {
/*      */       return;
/*      */     }
/*      */     
/*  251 */     ConfigurationClass existingClass = this.configurationClasses.get(configClass);
/*  252 */     if (existingClass != null) {
/*  253 */       if (configClass.isImported()) {
/*  254 */         if (existingClass.isImported()) {
/*  255 */           existingClass.mergeImportedBy(configClass);
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/*  260 */       if (configClass.isScanned()) {
/*  261 */         String beanName = configClass.getBeanName();
/*  262 */         if (StringUtils.hasLength(beanName) && this.registry.containsBeanDefinition(beanName)) {
/*  263 */           this.registry.removeBeanDefinition(beanName);
/*      */         }
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/*  271 */       this.configurationClasses.remove(configClass);
/*  272 */       removeKnownSuperclass(configClass.getMetadata().getClassName(), false);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  277 */     SourceClass sourceClass = null;
/*      */     try {
/*  279 */       sourceClass = asSourceClass(configClass, filter);
/*      */       do {
/*  281 */         sourceClass = doProcessConfigurationClass(configClass, sourceClass, filter);
/*      */       }
/*  283 */       while (sourceClass != null);
/*      */     }
/*  285 */     catch (IOException ex) {
/*  286 */       throw new BeanDefinitionStoreException("I/O failure while processing configuration class [" + String.valueOf(sourceClass) + "]", ex);
/*      */     } 
/*      */ 
/*      */     
/*  290 */     this.configurationClasses.put(configClass, configClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected final SourceClass doProcessConfigurationClass(ConfigurationClass configClass, SourceClass sourceClass, Predicate<String> filter) throws IOException {
/*  306 */     if (configClass.getMetadata().isAnnotated(Component.class.getName()))
/*      */     {
/*  308 */       processMemberClasses(configClass, sourceClass, filter);
/*      */     }
/*      */ 
/*      */     
/*  312 */     for (AnnotationAttributes propertySource : AnnotationConfigUtils.attributesForRepeatable(sourceClass
/*  313 */         .getMetadata(), (Class)PropertySource.class, (Class)PropertySources.class, true)) {
/*      */       
/*  315 */       if (this.propertySourceRegistry != null) {
/*  316 */         this.propertySourceRegistry.processPropertySource(propertySource);
/*      */         continue;
/*      */       } 
/*  319 */       this.logger.info("Ignoring @PropertySource annotation on [" + sourceClass.getMetadata().getClassName() + "]. Reason: Environment must implement ConfigurableEnvironment");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  325 */     Set<AnnotationAttributes> componentScans = AnnotationConfigUtils.attributesForRepeatable(sourceClass
/*  326 */         .getMetadata(), (Class)ComponentScan.class, (Class)ComponentScans.class, MergedAnnotation::isDirectlyPresent);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  331 */     if (componentScans.isEmpty()) {
/*  332 */       componentScans = AnnotationConfigUtils.attributesForRepeatable(sourceClass.getMetadata(), (Class)ComponentScan.class, (Class)ComponentScans.class, MergedAnnotation::isMetaPresent);
/*      */     }
/*      */ 
/*      */     
/*  336 */     if (!componentScans.isEmpty()) {
/*  337 */       List<Condition> registerBeanConditions = collectRegisterBeanConditions(configClass);
/*  338 */       if (!registerBeanConditions.isEmpty()) {
/*  339 */         throw new ApplicationContextException("Component scan for configuration class [%s] could not be used with conditions in REGISTER_BEAN phase: %s"
/*      */             
/*  341 */             .formatted(new Object[] { configClass.getMetadata().getClassName(), registerBeanConditions }));
/*      */       }
/*  343 */       for (AnnotationAttributes componentScan : componentScans) {
/*      */ 
/*      */         
/*  346 */         Set<BeanDefinitionHolder> scannedBeanDefinitions = this.componentScanParser.parse(componentScan, sourceClass.getMetadata().getClassName());
/*      */         
/*  348 */         for (BeanDefinitionHolder holder : scannedBeanDefinitions) {
/*  349 */           BeanDefinition bdCand = holder.getBeanDefinition().getOriginatingBeanDefinition();
/*  350 */           if (bdCand == null) {
/*  351 */             bdCand = holder.getBeanDefinition();
/*      */           }
/*  353 */           if (ConfigurationClassUtils.checkConfigurationClassCandidate(bdCand, this.metadataReaderFactory)) {
/*  354 */             parse(bdCand.getBeanClassName(), holder.getBeanName());
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  361 */     processImports(configClass, sourceClass, getImports(sourceClass), filter, true);
/*      */ 
/*      */ 
/*      */     
/*  365 */     AnnotationAttributes importResource = AnnotationConfigUtils.attributesFor((AnnotatedTypeMetadata)sourceClass.getMetadata(), ImportResource.class);
/*  366 */     if (importResource != null) {
/*  367 */       String[] resources = importResource.getStringArray("locations");
/*  368 */       Class<? extends BeanDefinitionReader> readerClass = importResource.getClass("reader");
/*  369 */       for (String resource : resources) {
/*  370 */         String resolvedResource = this.environment.resolveRequiredPlaceholders(resource);
/*  371 */         configClass.addImportedResource(resolvedResource, readerClass);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  376 */     Set<MethodMetadata> beanMethods = retrieveBeanMethodMetadata(sourceClass);
/*  377 */     for (MethodMetadata methodMetadata : beanMethods) {
/*  378 */       if (methodMetadata.isAnnotated("kotlin.jvm.JvmStatic") && !methodMetadata.isStatic()) {
/*      */         continue;
/*      */       }
/*  381 */       configClass.addBeanMethod(new BeanMethod(methodMetadata, configClass));
/*      */     } 
/*      */ 
/*      */     
/*  385 */     processInterfaces(configClass, sourceClass);
/*      */ 
/*      */     
/*  388 */     if (sourceClass.getMetadata().hasSuperClass()) {
/*  389 */       String superclass = sourceClass.getMetadata().getSuperClassName();
/*  390 */       if (superclass != null && !superclass.startsWith("java")) {
/*  391 */         boolean superclassKnown = this.knownSuperclasses.containsKey(superclass);
/*  392 */         this.knownSuperclasses.add(superclass, configClass);
/*  393 */         if (!superclassKnown)
/*      */         {
/*  395 */           return sourceClass.getSuperClass();
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  401 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processMemberClasses(ConfigurationClass configClass, SourceClass sourceClass, Predicate<String> filter) throws IOException {
/*  410 */     Collection<SourceClass> memberClasses = sourceClass.getMemberClasses();
/*  411 */     if (!memberClasses.isEmpty()) {
/*  412 */       List<SourceClass> candidates = new ArrayList<>(memberClasses.size());
/*  413 */       for (SourceClass memberClass : memberClasses) {
/*  414 */         if (ConfigurationClassUtils.isConfigurationCandidate(memberClass.getMetadata()) && 
/*  415 */           !memberClass.getMetadata().getClassName().equals(configClass.getMetadata().getClassName())) {
/*  416 */           candidates.add(memberClass);
/*      */         }
/*      */       } 
/*  419 */       OrderComparator.sort(candidates);
/*  420 */       for (SourceClass candidate : candidates) {
/*  421 */         if (this.importStack.contains(configClass)) {
/*  422 */           this.problemReporter.error(new CircularImportProblem(configClass, this.importStack));
/*      */           continue;
/*      */         } 
/*  425 */         this.importStack.push(configClass);
/*      */         try {
/*  427 */           processConfigurationClass(candidate.asConfigClass(configClass), filter);
/*      */         } finally {
/*      */           
/*  430 */           this.importStack.pop();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processInterfaces(ConfigurationClass configClass, SourceClass sourceClass) throws IOException {
/*  441 */     for (SourceClass ifc : sourceClass.getInterfaces()) {
/*  442 */       Set<MethodMetadata> beanMethods = retrieveBeanMethodMetadata(ifc);
/*  443 */       for (MethodMetadata methodMetadata : beanMethods) {
/*  444 */         if (!methodMetadata.isAbstract())
/*      */         {
/*  446 */           configClass.addBeanMethod(new BeanMethod(methodMetadata, configClass));
/*      */         }
/*      */       } 
/*  449 */       processInterfaces(configClass, ifc);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Set<MethodMetadata> retrieveBeanMethodMetadata(SourceClass sourceClass) {
/*  457 */     AnnotationMetadata original = sourceClass.getMetadata();
/*  458 */     Set<MethodMetadata> beanMethods = original.getAnnotatedMethods(Bean.class.getName());
/*  459 */     if (beanMethods.size() > 1 && original instanceof StandardAnnotationMetadata) {
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */         
/*  465 */         AnnotationMetadata asm = this.metadataReaderFactory.getMetadataReader(original.getClassName()).getAnnotationMetadata();
/*  466 */         Set<MethodMetadata> asmMethods = asm.getAnnotatedMethods(Bean.class.getName());
/*  467 */         if (asmMethods.size() >= beanMethods.size()) {
/*  468 */           Set<MethodMetadata> candidateMethods = new LinkedHashSet<>(beanMethods);
/*  469 */           Set<MethodMetadata> selectedMethods = CollectionUtils.newLinkedHashSet(asmMethods.size());
/*  470 */           for (MethodMetadata asmMethod : asmMethods) {
/*  471 */             Iterator<MethodMetadata> it; for (it = candidateMethods.iterator(); it.hasNext(); ) {
/*  472 */               MethodMetadata beanMethod = it.next();
/*  473 */               if (beanMethod.getMethodName().equals(asmMethod.getMethodName())) {
/*  474 */                 selectedMethods.add(beanMethod);
/*  475 */                 it.remove();
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           
/*  480 */           if (selectedMethods.size() == beanMethods.size())
/*      */           {
/*  482 */             beanMethods = selectedMethods;
/*      */           }
/*      */         }
/*      */       
/*  486 */       } catch (IOException ex) {
/*  487 */         this.logger.debug("Failed to read class file via ASM for determining @Bean method order", ex);
/*      */       } 
/*      */     }
/*      */     
/*  491 */     return beanMethods;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeKnownSuperclass(String removedClass, boolean replace) {
/*  499 */     String replacedSuperclass = null;
/*  500 */     ConfigurationClass replacingClass = null;
/*      */     
/*  502 */     Iterator<Map.Entry<String, List<ConfigurationClass>>> it = this.knownSuperclasses.entrySet().iterator();
/*  503 */     while (it.hasNext()) {
/*  504 */       Map.Entry<String, List<ConfigurationClass>> entry = it.next();
/*  505 */       if (((List)entry.getValue()).removeIf(configClass -> configClass.getMetadata().getClassName().equals(removedClass))) {
/*  506 */         if (((List)entry.getValue()).isEmpty()) {
/*  507 */           it.remove(); continue;
/*      */         } 
/*  509 */         if (replace && replacingClass == null) {
/*  510 */           replacedSuperclass = entry.getKey();
/*  511 */           replacingClass = ((List<ConfigurationClass>)entry.getValue()).get(0);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  516 */     if (replacingClass != null) {
/*      */       try {
/*  518 */         SourceClass sourceClass = asSourceClass(replacingClass, DEFAULT_EXCLUSION_FILTER).getSuperClass();
/*  519 */         while (!sourceClass.getMetadata().getClassName().equals(replacedSuperclass) && sourceClass
/*  520 */           .getMetadata().getSuperClassName() != null) {
/*  521 */           sourceClass = sourceClass.getSuperClass();
/*      */         }
/*      */         do {
/*  524 */           sourceClass = doProcessConfigurationClass(replacingClass, sourceClass, DEFAULT_EXCLUSION_FILTER);
/*      */         }
/*  526 */         while (sourceClass != null);
/*      */       }
/*  528 */       catch (IOException ex) {
/*  529 */         throw new BeanDefinitionStoreException("I/O failure while removing configuration class [" + removedClass + "]", ex);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Set<SourceClass> getImports(SourceClass sourceClass) throws IOException {
/*  539 */     Set<SourceClass> imports = new LinkedHashSet<>();
/*  540 */     collectImports(sourceClass, imports, new HashSet<>());
/*  541 */     return imports;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void collectImports(SourceClass sourceClass, Set<SourceClass> imports, Set<SourceClass> visited) throws IOException {
/*  560 */     if (visited.add(sourceClass)) {
/*  561 */       for (SourceClass annotation : sourceClass.getAnnotations()) {
/*  562 */         String annName = annotation.getMetadata().getClassName();
/*  563 */         if (!annName.equals(Import.class.getName())) {
/*  564 */           collectImports(annotation, imports, visited);
/*      */         }
/*      */       } 
/*  567 */       imports.addAll(sourceClass.getAnnotationAttributes(Import.class.getName(), "value"));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void processImports(ConfigurationClass configClass, SourceClass currentSourceClass, Collection<SourceClass> importCandidates, Predicate<String> filter, boolean checkForCircularImports) {
/*  574 */     if (importCandidates.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/*  578 */     if (checkForCircularImports && isChainedImportOnStack(configClass)) {
/*  579 */       this.problemReporter.error(new CircularImportProblem(configClass, this.importStack));
/*      */     } else {
/*      */       
/*  582 */       this.importStack.push(configClass);
/*      */       try {
/*  584 */         for (SourceClass candidate : importCandidates) {
/*  585 */           if (candidate.isAssignable(ImportSelector.class)) {
/*      */             
/*  587 */             Class<?> candidateClass = candidate.loadClass();
/*  588 */             ImportSelector selector = ParserStrategyUtils.<ImportSelector>instantiateClass(candidateClass, ImportSelector.class, this.environment, this.resourceLoader, this.registry);
/*      */             
/*  590 */             Predicate<String> selectorFilter = selector.getExclusionFilter();
/*  591 */             if (selectorFilter != null) {
/*  592 */               filter = filter.or(selectorFilter);
/*      */             }
/*  594 */             if (selector instanceof DeferredImportSelector) { DeferredImportSelector deferredImportSelector = (DeferredImportSelector)selector;
/*  595 */               this.deferredImportSelectorHandler.handle(configClass, deferredImportSelector);
/*      */               continue; }
/*      */             
/*  598 */             String[] importClassNames = selector.selectImports(currentSourceClass.getMetadata());
/*  599 */             Collection<SourceClass> importSourceClasses = asSourceClasses(importClassNames, filter);
/*  600 */             processImports(configClass, currentSourceClass, importSourceClasses, filter, false);
/*      */             continue;
/*      */           } 
/*  603 */           if (candidate.isAssignable(ImportBeanDefinitionRegistrar.class)) {
/*      */ 
/*      */             
/*  606 */             Class<?> candidateClass = candidate.loadClass();
/*      */             
/*  608 */             ImportBeanDefinitionRegistrar registrar = ParserStrategyUtils.<ImportBeanDefinitionRegistrar>instantiateClass(candidateClass, ImportBeanDefinitionRegistrar.class, this.environment, this.resourceLoader, this.registry);
/*      */             
/*  610 */             configClass.addImportBeanDefinitionRegistrar(registrar, currentSourceClass.getMetadata());
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  615 */           this.importStack.registerImport(currentSourceClass
/*  616 */               .getMetadata(), candidate.getMetadata().getClassName());
/*  617 */           processConfigurationClass(candidate.asConfigClass(configClass), filter);
/*      */         }
/*      */       
/*      */       }
/*  621 */       catch (BeanDefinitionStoreException ex) {
/*  622 */         throw ex;
/*      */       }
/*  624 */       catch (Throwable ex) {
/*  625 */         throw new BeanDefinitionStoreException("Failed to process import candidates for configuration class [" + configClass
/*      */             
/*  627 */             .getMetadata().getClassName() + "]: " + ex.getMessage(), ex);
/*      */       } finally {
/*      */         
/*  630 */         this.importStack.pop();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isChainedImportOnStack(ConfigurationClass configClass) {
/*  636 */     if (this.importStack.contains(configClass)) {
/*  637 */       String configClassName = configClass.getMetadata().getClassName();
/*  638 */       AnnotationMetadata importingClass = this.importStack.getImportingClassFor(configClassName);
/*  639 */       while (importingClass != null) {
/*  640 */         if (configClassName.equals(importingClass.getClassName())) {
/*  641 */           return true;
/*      */         }
/*  643 */         importingClass = this.importStack.getImportingClassFor(importingClass.getClassName());
/*      */       } 
/*      */     } 
/*  646 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SourceClass asSourceClass(ConfigurationClass configurationClass, Predicate<String> filter) throws IOException {
/*  653 */     AnnotationMetadata metadata = configurationClass.getMetadata();
/*  654 */     if (metadata instanceof StandardAnnotationMetadata) { StandardAnnotationMetadata standardAnnotationMetadata = (StandardAnnotationMetadata)metadata;
/*  655 */       return asSourceClass(standardAnnotationMetadata.getIntrospectedClass(), filter); }
/*      */     
/*  657 */     return asSourceClass(metadata.getClassName(), filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SourceClass asSourceClass(@Nullable Class<?> classType, Predicate<String> filter) throws IOException {
/*  664 */     if (classType == null || filter.test(classType.getName())) {
/*  665 */       return this.objectSourceClass;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  670 */       for (Annotation ann : classType.getDeclaredAnnotations()) {
/*  671 */         AnnotationUtils.validateAnnotation(ann);
/*      */       }
/*  673 */       return new SourceClass(classType);
/*      */     }
/*  675 */     catch (Throwable ex) {
/*      */       
/*  677 */       return asSourceClass(classType.getName(), filter);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Collection<SourceClass> asSourceClasses(String[] classNames, Predicate<String> filter) throws IOException {
/*  685 */     List<SourceClass> annotatedClasses = new ArrayList<>(classNames.length);
/*  686 */     for (String className : classNames) {
/*  687 */       SourceClass sourceClass = asSourceClass(className, filter);
/*  688 */       if (this.objectSourceClass != sourceClass) {
/*  689 */         annotatedClasses.add(sourceClass);
/*      */       }
/*      */     } 
/*  692 */     return annotatedClasses;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SourceClass asSourceClass(@Nullable String className, Predicate<String> filter) throws IOException {
/*  699 */     if (className == null || filter.test(className)) {
/*  700 */       return this.objectSourceClass;
/*      */     }
/*  702 */     if (className.startsWith("java")) {
/*      */       
/*      */       try {
/*  705 */         return new SourceClass(ClassUtils.forName(className, this.resourceLoader.getClassLoader()));
/*      */       }
/*  707 */       catch (ClassNotFoundException ex) {
/*  708 */         throw new IOException("Failed to load class [" + className + "]", ex);
/*      */       } 
/*      */     }
/*  711 */     return new SourceClass(this.metadataReaderFactory.getMetadataReader(className));
/*      */   }
/*      */   
/*      */   private List<Condition> collectRegisterBeanConditions(ConfigurationClass configurationClass) {
/*  715 */     AnnotationMetadata metadata = configurationClass.getMetadata();
/*  716 */     List<Condition> allConditions = new ArrayList<>(this.conditionEvaluator.collectConditions((AnnotatedTypeMetadata)metadata));
/*  717 */     ConfigurationClass enclosingConfigurationClass = getEnclosingConfigurationClass(configurationClass);
/*  718 */     if (enclosingConfigurationClass != null) {
/*  719 */       allConditions.addAll(this.conditionEvaluator.collectConditions((AnnotatedTypeMetadata)enclosingConfigurationClass.getMetadata()));
/*      */     }
/*  721 */     return allConditions.stream().filter(REGISTER_BEAN_CONDITION_FILTER).toList();
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private ConfigurationClass getEnclosingConfigurationClass(ConfigurationClass configurationClass) {
/*  726 */     String enclosingClassName = configurationClass.getMetadata().getEnclosingClassName();
/*  727 */     if (enclosingClassName != null) {
/*  728 */       return configurationClass.getImportedBy().stream()
/*  729 */         .filter(candidate -> enclosingClassName.equals(candidate.getMetadata().getClassName()))
/*  730 */         .findFirst().orElse(null);
/*      */     }
/*  732 */     return null;
/*      */   }
/*      */   
/*      */   private class ImportStack
/*      */     extends ArrayDeque<ConfigurationClass>
/*      */     implements ImportRegistry
/*      */   {
/*  739 */     private final MultiValueMap<String, AnnotationMetadata> imports = (MultiValueMap<String, AnnotationMetadata>)new LinkedMultiValueMap();
/*      */     
/*      */     void registerImport(AnnotationMetadata importingClass, String importedClass) {
/*  742 */       this.imports.add(importedClass, importingClass);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public AnnotationMetadata getImportingClassFor(String importedClass) {
/*  748 */       return (AnnotationMetadata)CollectionUtils.lastElement((List)this.imports.get(importedClass));
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeImportingClass(String importingClass) {
/*  753 */       for (List<AnnotationMetadata> list : (Iterable<List<AnnotationMetadata>>)this.imports.values()) {
/*  754 */         Iterator<AnnotationMetadata> iterator; for (iterator = list.iterator(); iterator.hasNext();) {
/*  755 */           if (((AnnotationMetadata)iterator.next()).getClassName().equals(importingClass)) {
/*  756 */             iterator.remove();
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  761 */       ConfigurationClassParser.this.removeKnownSuperclass(importingClass, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  775 */       StringJoiner joiner = new StringJoiner("->", "[", "]");
/*  776 */       for (ConfigurationClass configurationClass : this) {
/*  777 */         joiner.add(configurationClass.getSimpleName());
/*      */       }
/*  779 */       return joiner.toString();
/*      */     } }
/*      */   
/*      */   private class DeferredImportSelectorHandler { @Nullable
/*      */     private List<ConfigurationClassParser.DeferredImportSelectorHolder> deferredImportSelectors;
/*      */     
/*      */     private DeferredImportSelectorHandler() {
/*  786 */       this.deferredImportSelectors = new ArrayList<>();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void handle(ConfigurationClass configClass, DeferredImportSelector importSelector) {
/*  798 */       ConfigurationClassParser.DeferredImportSelectorHolder holder = new ConfigurationClassParser.DeferredImportSelectorHolder(configClass, importSelector);
/*  799 */       if (this.deferredImportSelectors == null) {
/*  800 */         ConfigurationClassParser.DeferredImportSelectorGroupingHandler handler = new ConfigurationClassParser.DeferredImportSelectorGroupingHandler();
/*  801 */         handler.register(holder);
/*  802 */         handler.processGroupImports();
/*      */       } else {
/*      */         
/*  805 */         this.deferredImportSelectors.add(holder);
/*      */       } 
/*      */     }
/*      */     
/*      */     void process() {
/*  810 */       List<ConfigurationClassParser.DeferredImportSelectorHolder> deferredImports = this.deferredImportSelectors;
/*  811 */       this.deferredImportSelectors = null;
/*      */       try {
/*  813 */         if (deferredImports != null) {
/*  814 */           ConfigurationClassParser.DeferredImportSelectorGroupingHandler handler = new ConfigurationClassParser.DeferredImportSelectorGroupingHandler();
/*  815 */           deferredImports.sort(ConfigurationClassParser.DEFERRED_IMPORT_COMPARATOR);
/*  816 */           Objects.requireNonNull(handler); deferredImports.forEach(handler::register);
/*  817 */           handler.processGroupImports();
/*      */         } 
/*      */       } finally {
/*      */         
/*  821 */         this.deferredImportSelectors = new ArrayList<>();
/*      */       } 
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   private class DeferredImportSelectorGroupingHandler
/*      */   {
/*  829 */     private final Map<Object, ConfigurationClassParser.DeferredImportSelectorGrouping> groupings = new LinkedHashMap<>();
/*      */     
/*  831 */     private final Map<AnnotationMetadata, ConfigurationClass> configurationClasses = new HashMap<>();
/*      */     
/*      */     void register(ConfigurationClassParser.DeferredImportSelectorHolder deferredImport) {
/*  834 */       Class<? extends DeferredImportSelector.Group> group = deferredImport.getImportSelector().getImportGroup();
/*  835 */       ConfigurationClassParser.DeferredImportSelectorGrouping grouping = this.groupings.computeIfAbsent(
/*  836 */           (group != null) ? group : deferredImport, key -> new ConfigurationClassParser.DeferredImportSelectorGrouping(createGroup(group)));
/*      */       
/*  838 */       grouping.add(deferredImport);
/*  839 */       this.configurationClasses.put(deferredImport.getConfigurationClass().getMetadata(), deferredImport
/*  840 */           .getConfigurationClass());
/*      */     }
/*      */ 
/*      */     
/*      */     void processGroupImports() {
/*  845 */       for (Iterator<ConfigurationClassParser.DeferredImportSelectorGrouping> iterator = this.groupings.values().iterator(); iterator.hasNext(); ) { ConfigurationClassParser.DeferredImportSelectorGrouping grouping = iterator.next();
/*  846 */         Predicate<String> filter = grouping.getCandidateFilter();
/*  847 */         grouping.getImports().forEach(entry -> {
/*      */               ConfigurationClass configurationClass = this.configurationClasses.get(entry.getMetadata());
/*      */ 
/*      */ 
/*      */               
/*      */               try {
/*      */                 ConfigurationClassParser.this.processImports(configurationClass, ConfigurationClassParser.this.asSourceClass(configurationClass, filter), Collections.singleton(ConfigurationClassParser.this.asSourceClass(entry.getImportClassName(), filter)), filter, false);
/*  854 */               } catch (BeanDefinitionStoreException ex) {
/*      */                 
/*      */                 throw ex;
/*  857 */               } catch (Throwable ex) {
/*      */                 throw new BeanDefinitionStoreException("Failed to process import candidates for configuration class [" + configurationClass.getMetadata().getClassName() + "]", ex);
/*      */               } 
/*      */             }); }
/*      */     
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private DeferredImportSelector.Group createGroup(@Nullable Class<? extends DeferredImportSelector.Group> type) {
/*  867 */       Class<? extends DeferredImportSelector.Group> effectiveType = (type != null) ? type : (Class)ConfigurationClassParser.DefaultDeferredImportSelectorGroup.class;
/*  868 */       return ParserStrategyUtils.<DeferredImportSelector.Group>instantiateClass(effectiveType, DeferredImportSelector.Group.class, ConfigurationClassParser.this.environment, ConfigurationClassParser.this.resourceLoader, ConfigurationClassParser.this.registry);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class DeferredImportSelectorHolder
/*      */   {
/*      */     private final ConfigurationClass configurationClass;
/*      */ 
/*      */     
/*      */     private final DeferredImportSelector importSelector;
/*      */ 
/*      */     
/*      */     DeferredImportSelectorHolder(ConfigurationClass configClass, DeferredImportSelector selector) {
/*  883 */       this.configurationClass = configClass;
/*  884 */       this.importSelector = selector;
/*      */     }
/*      */     
/*      */     ConfigurationClass getConfigurationClass() {
/*  888 */       return this.configurationClass;
/*      */     }
/*      */     
/*      */     DeferredImportSelector getImportSelector() {
/*  892 */       return this.importSelector;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class DeferredImportSelectorGrouping
/*      */   {
/*      */     private final DeferredImportSelector.Group group;
/*      */     
/*  901 */     private final List<ConfigurationClassParser.DeferredImportSelectorHolder> deferredImports = new ArrayList<>();
/*      */     
/*      */     DeferredImportSelectorGrouping(DeferredImportSelector.Group group) {
/*  904 */       this.group = group;
/*      */     }
/*      */     
/*      */     void add(ConfigurationClassParser.DeferredImportSelectorHolder deferredImport) {
/*  908 */       this.deferredImports.add(deferredImport);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Iterable<DeferredImportSelector.Group.Entry> getImports() {
/*  916 */       for (ConfigurationClassParser.DeferredImportSelectorHolder deferredImport : this.deferredImports) {
/*  917 */         this.group.process(deferredImport.getConfigurationClass().getMetadata(), deferredImport
/*  918 */             .getImportSelector());
/*      */       }
/*  920 */       return this.group.selectImports();
/*      */     }
/*      */     
/*      */     Predicate<String> getCandidateFilter() {
/*  924 */       Predicate<String> mergedFilter = ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER;
/*  925 */       for (ConfigurationClassParser.DeferredImportSelectorHolder deferredImport : this.deferredImports) {
/*  926 */         Predicate<String> selectorFilter = deferredImport.getImportSelector().getExclusionFilter();
/*  927 */         if (selectorFilter != null) {
/*  928 */           mergedFilter = mergedFilter.or(selectorFilter);
/*      */         }
/*      */       } 
/*  931 */       return mergedFilter;
/*      */     } }
/*      */   
/*      */   private static class DefaultDeferredImportSelectorGroup implements DeferredImportSelector.Group {
/*      */     private final List<DeferredImportSelector.Group.Entry> imports;
/*      */     
/*      */     private DefaultDeferredImportSelectorGroup() {
/*  938 */       this.imports = new ArrayList<>();
/*      */     }
/*      */     
/*      */     public void process(AnnotationMetadata metadata, DeferredImportSelector selector) {
/*  942 */       for (String importClassName : selector.selectImports(metadata)) {
/*  943 */         this.imports.add(new DeferredImportSelector.Group.Entry(metadata, importClassName));
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterable<DeferredImportSelector.Group.Entry> selectImports() {
/*  949 */       return this.imports;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class SourceClass
/*      */     implements Ordered
/*      */   {
/*      */     private final Object source;
/*      */ 
/*      */     
/*      */     private final AnnotationMetadata metadata;
/*      */ 
/*      */     
/*      */     public SourceClass(Object source) {
/*  965 */       this.source = source;
/*  966 */       if (source instanceof Class) { Class<?> sourceClass = (Class)source;
/*  967 */         this.metadata = AnnotationMetadata.introspect(sourceClass); }
/*      */       else
/*      */       
/*  970 */       { this.metadata = ((MetadataReader)source).getAnnotationMetadata(); }
/*      */     
/*      */     }
/*      */     
/*      */     public final AnnotationMetadata getMetadata() {
/*  975 */       return this.metadata;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getOrder() {
/*  980 */       Integer order = ConfigurationClassUtils.getOrder(this.metadata);
/*  981 */       return (order != null) ? order.intValue() : Integer.MAX_VALUE;
/*      */     }
/*      */     
/*      */     public Class<?> loadClass() throws ClassNotFoundException {
/*  985 */       Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/*  986 */         return sourceClass; }
/*      */       
/*  988 */       String className = ((MetadataReader)this.source).getClassMetadata().getClassName();
/*  989 */       return ClassUtils.forName(className, ConfigurationClassParser.this.resourceLoader.getClassLoader());
/*      */     }
/*      */     
/*      */     public boolean isAssignable(Class<?> clazz) throws IOException {
/*  993 */       Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/*  994 */         return clazz.isAssignableFrom(sourceClass); }
/*      */       
/*  996 */       return (new AssignableTypeFilter(clazz)).match((MetadataReader)this.source, ConfigurationClassParser.this.metadataReaderFactory);
/*      */     }
/*      */     
/*      */     public ConfigurationClass asConfigClass(ConfigurationClass importedBy) {
/* 1000 */       Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/* 1001 */         return new ConfigurationClass(sourceClass, importedBy); }
/*      */       
/* 1003 */       return new ConfigurationClass((MetadataReader)this.source, importedBy);
/*      */     }
/*      */     
/*      */     public Collection<SourceClass> getMemberClasses() throws IOException {
/* 1007 */       Object sourceToProcess = this.source;
/* 1008 */       if (sourceToProcess instanceof Class) { Class<?> sourceClass = (Class)sourceToProcess;
/*      */         try {
/* 1010 */           Class<?>[] declaredClasses = sourceClass.getDeclaredClasses();
/* 1011 */           List<SourceClass> list = new ArrayList<>(declaredClasses.length);
/* 1012 */           for (Class<?> declaredClass : declaredClasses) {
/* 1013 */             list.add(ConfigurationClassParser.this.asSourceClass(declaredClass, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER));
/*      */           }
/* 1015 */           return list;
/*      */         }
/* 1017 */         catch (NoClassDefFoundError err) {
/*      */ 
/*      */           
/* 1020 */           sourceToProcess = ConfigurationClassParser.this.metadataReaderFactory.getMetadataReader(sourceClass.getName());
/*      */         }  }
/*      */ 
/*      */ 
/*      */       
/* 1025 */       MetadataReader sourceReader = (MetadataReader)sourceToProcess;
/* 1026 */       String[] memberClassNames = sourceReader.getClassMetadata().getMemberClassNames();
/* 1027 */       List<SourceClass> members = new ArrayList<>(memberClassNames.length);
/* 1028 */       for (String memberClassName : memberClassNames) {
/*      */         try {
/* 1030 */           members.add(ConfigurationClassParser.this.asSourceClass(memberClassName, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER));
/*      */         }
/* 1032 */         catch (IOException ex) {
/*      */           
/* 1034 */           if (ConfigurationClassParser.this.logger.isDebugEnabled()) {
/* 1035 */             ConfigurationClassParser.this.logger.debug("Failed to resolve member class [" + memberClassName + "] - not considering it as a configuration class candidate");
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/* 1040 */       return members;
/*      */     }
/*      */     
/*      */     public SourceClass getSuperClass() throws IOException {
/* 1044 */       Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/* 1045 */         return ConfigurationClassParser.this.asSourceClass(sourceClass.getSuperclass(), ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER); }
/*      */       
/* 1047 */       return ConfigurationClassParser.this.asSourceClass(((MetadataReader)this.source)
/* 1048 */           .getClassMetadata().getSuperClassName(), ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER);
/*      */     }
/*      */     
/*      */     public Set<SourceClass> getInterfaces() throws IOException {
/* 1052 */       Set<SourceClass> result = new LinkedHashSet<>();
/* 1053 */       Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/* 1054 */         for (Class<?> clazz : sourceClass.getInterfaces()) {
/* 1055 */           result.add(ConfigurationClassParser.this.asSourceClass(clazz, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER));
/*      */         } }
/*      */       else
/*      */       
/* 1059 */       { for (String str : this.metadata.getInterfaceNames()) {
/* 1060 */           result.add(ConfigurationClassParser.this.asSourceClass(str, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER));
/*      */         } }
/*      */       
/* 1063 */       return result;
/*      */     }
/*      */     
/*      */     public Set<SourceClass> getAnnotations() {
/* 1067 */       Set<SourceClass> result = new LinkedHashSet<>();
/* 1068 */       Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/* 1069 */         for (Annotation annotation : sourceClass.getDeclaredAnnotations()) {
/* 1070 */           Class<?> annType = annotation.annotationType();
/* 1071 */           if (!annType.getName().startsWith("java")) {
/*      */             try {
/* 1073 */               result.add(ConfigurationClassParser.this.asSourceClass(annType, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER));
/*      */             }
/* 1075 */             catch (Throwable throwable) {}
/*      */           
/*      */           }
/*      */         }
/*      */          }
/*      */       
/*      */       else
/*      */       
/* 1083 */       { for (String className : this.metadata.getAnnotationTypes()) {
/* 1084 */           if (!className.startsWith("java")) {
/*      */             try {
/* 1086 */               result.add(getRelated(className));
/*      */             }
/* 1088 */             catch (Throwable throwable) {}
/*      */           }
/*      */         }  }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1095 */       return result;
/*      */     }
/*      */     
/*      */     public Collection<SourceClass> getAnnotationAttributes(String annType, String attribute) throws IOException {
/* 1099 */       Map<String, Object> annotationAttributes = this.metadata.getAnnotationAttributes(annType, true);
/* 1100 */       if (annotationAttributes == null || !annotationAttributes.containsKey(attribute)) {
/* 1101 */         return Collections.emptySet();
/*      */       }
/* 1103 */       String[] classNames = (String[])annotationAttributes.get(attribute);
/* 1104 */       Set<SourceClass> result = CollectionUtils.newLinkedHashSet(classNames.length);
/* 1105 */       for (String className : classNames) {
/* 1106 */         result.add(getRelated(className));
/*      */       }
/* 1108 */       return result;
/*      */     }
/*      */     
/*      */     private SourceClass getRelated(String className) throws IOException {
/* 1112 */       Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/*      */         try {
/* 1114 */           Class<?> clazz = ClassUtils.forName(className, sourceClass.getClassLoader());
/* 1115 */           return ConfigurationClassParser.this.asSourceClass(clazz, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER);
/*      */         }
/* 1117 */         catch (ClassNotFoundException ex) {
/*      */           
/* 1119 */           if (className.startsWith("java")) {
/* 1120 */             throw new IOException("Failed to load class [" + className + "]", ex);
/*      */           }
/* 1122 */           return new SourceClass(ConfigurationClassParser.this.metadataReaderFactory.getMetadataReader(className));
/*      */         }  }
/*      */       
/* 1125 */       return ConfigurationClassParser.this.asSourceClass(className, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(@Nullable Object other) {
/* 1130 */       if (this != other) { if (other instanceof SourceClass) { SourceClass that = (SourceClass)other; if (this.metadata
/* 1131 */             .getClassName().equals(that.metadata.getClassName())); }
/*      */         
/*      */         return false; }
/*      */     
/*      */     } public int hashCode() {
/* 1136 */       return this.metadata.getClassName().hashCode();
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1141 */       return this.metadata.getClassName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class CircularImportProblem
/*      */     extends Problem
/*      */   {
/*      */     public CircularImportProblem(ConfigurationClass attemptedImport, Deque<ConfigurationClass> importStack) {
/* 1152 */       super(String.format("A circular @Import has been detected: Illegal attempt by @Configuration class '%s' to import class '%s' as '%s' is already present in the current import stack %s", new Object[] { ((ConfigurationClass)importStack
/*      */               
/* 1154 */               .element()).getSimpleName(), attemptedImport
/* 1155 */               .getSimpleName(), attemptedImport.getSimpleName(), importStack
/* 1156 */             }), new Location(((ConfigurationClass)importStack.element()).getResource(), attemptedImport.getMetadata()));
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConfigurationClassParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */