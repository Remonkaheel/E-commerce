package org.springframework.context.annotation;

import java.lang.reflect.Method;
import org.springframework.cglib.proxy.Callback;

interface ConditionalCallback extends Callback {
  boolean isMatch(Method paramMethod);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConfigurationClassEnhancer$ConditionalCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */