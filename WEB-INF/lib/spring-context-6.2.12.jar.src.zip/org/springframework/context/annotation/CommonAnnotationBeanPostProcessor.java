/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import jakarta.annotation.Resource;
/*     */ import jakarta.ejb.EJB;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.annotation.Resource;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aot.generate.AccessControl;
/*     */ import org.springframework.aot.generate.GeneratedClass;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.support.ClassHintUtils;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.annotation.InitDestroyAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.annotation.InjectionMetadata;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.config.EmbeddedValueResolver;
/*     */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ import org.springframework.jndi.support.SimpleJndiBeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonAnnotationBeanPostProcessor
/*     */   extends InitDestroyAnnotationBeanPostProcessor
/*     */   implements InstantiationAwareBeanPostProcessor, BeanFactoryAware, Serializable
/*     */ {
/* 149 */   private static final boolean jndiPresent = ClassUtils.isPresent("javax.naming.InitialContext", CommonAnnotationBeanPostProcessor.class
/* 150 */       .getClassLoader());
/*     */   
/* 152 */   private static final Set<Class<? extends Annotation>> resourceAnnotationTypes = CollectionUtils.newLinkedHashSet(3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/* 164 */   private static final Class<? extends Annotation> jakartaResourceType = loadAnnotationType("jakarta.annotation.Resource"); static {
/* 165 */     if (jakartaResourceType != null)
/* 166 */       resourceAnnotationTypes.add(jakartaResourceType); 
/*     */   }
/*     */   @Nullable
/* 169 */   private static final Class<? extends Annotation> javaxResourceType = loadAnnotationType("javax.annotation.Resource"); static {
/* 170 */     if (javaxResourceType != null)
/* 171 */       resourceAnnotationTypes.add(javaxResourceType); 
/*     */   }
/*     */   @Nullable
/* 174 */   private static final Class<? extends Annotation> ejbAnnotationType = loadAnnotationType("jakarta.ejb.EJB"); static {
/* 175 */     if (ejbAnnotationType != null) {
/* 176 */       resourceAnnotationTypes.add(ejbAnnotationType);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 181 */   private final Set<String> ignoredResourceTypes = new HashSet<>(1);
/*     */   
/*     */   private boolean fallbackToDefaultTypeMatch = true;
/*     */   
/*     */   private boolean alwaysUseJndiLookup = false;
/*     */   
/*     */   @Nullable
/*     */   private transient BeanFactory jndiFactory;
/*     */   
/*     */   @Nullable
/*     */   private transient BeanFactory resourceFactory;
/*     */   
/*     */   @Nullable
/*     */   private transient BeanFactory beanFactory;
/*     */   
/*     */   @Nullable
/*     */   private transient StringValueResolver embeddedValueResolver;
/*     */   
/* 199 */   private final transient Map<String, InjectionMetadata> injectionMetadataCache = new ConcurrentHashMap<>(256);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonAnnotationBeanPostProcessor() {
/* 209 */     setOrder(2147483644);
/*     */ 
/*     */     
/* 212 */     addInitAnnotationType(loadAnnotationType("jakarta.annotation.PostConstruct"));
/* 213 */     addDestroyAnnotationType(loadAnnotationType("jakarta.annotation.PreDestroy"));
/*     */ 
/*     */     
/* 216 */     addInitAnnotationType(loadAnnotationType("javax.annotation.PostConstruct"));
/* 217 */     addDestroyAnnotationType(loadAnnotationType("javax.annotation.PreDestroy"));
/*     */ 
/*     */     
/* 220 */     if (jndiPresent) {
/* 221 */       this.jndiFactory = (BeanFactory)new SimpleJndiBeanFactory();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ignoreResourceType(String resourceType) {
/* 231 */     Assert.notNull(resourceType, "Ignored resource type must not be null");
/* 232 */     this.ignoredResourceTypes.add(resourceType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFallbackToDefaultTypeMatch(boolean fallbackToDefaultTypeMatch) {
/* 246 */     this.fallbackToDefaultTypeMatch = fallbackToDefaultTypeMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlwaysUseJndiLookup(boolean alwaysUseJndiLookup) {
/* 260 */     this.alwaysUseJndiLookup = alwaysUseJndiLookup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJndiFactory(BeanFactory jndiFactory) {
/* 275 */     Assert.notNull(jndiFactory, "BeanFactory must not be null");
/* 276 */     this.jndiFactory = jndiFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceFactory(BeanFactory resourceFactory) {
/* 293 */     Assert.notNull(resourceFactory, "BeanFactory must not be null");
/* 294 */     this.resourceFactory = resourceFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 299 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 300 */     this.beanFactory = beanFactory;
/* 301 */     if (this.resourceFactory == null) {
/* 302 */       this.resourceFactory = beanFactory;
/*     */     }
/* 304 */     if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory configurableBeanFactory = (ConfigurableBeanFactory)beanFactory;
/* 305 */       this.embeddedValueResolver = (StringValueResolver)new EmbeddedValueResolver(configurableBeanFactory); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName) {
/* 312 */     super.postProcessMergedBeanDefinition(beanDefinition, beanType, beanName);
/* 313 */     InjectionMetadata metadata = findResourceMetadata(beanName, beanType, (PropertyValues)null);
/* 314 */     metadata.checkConfigMembers(beanDefinition);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/* 320 */     BeanRegistrationAotContribution parentAotContribution = super.processAheadOfTime(registeredBean);
/* 321 */     Class<?> beanClass = registeredBean.getBeanClass();
/* 322 */     String beanName = registeredBean.getBeanName();
/* 323 */     RootBeanDefinition beanDefinition = registeredBean.getMergedBeanDefinition();
/* 324 */     InjectionMetadata metadata = findResourceMetadata(beanName, beanClass, (PropertyValues)beanDefinition
/* 325 */         .getPropertyValues());
/* 326 */     Collection<LookupElement> injectedElements = getInjectedElements(metadata, (PropertyValues)beanDefinition
/* 327 */         .getPropertyValues());
/* 328 */     if (!ObjectUtils.isEmpty(injectedElements)) {
/*     */       
/* 330 */       AotContribution aotContribution = new AotContribution(beanClass, injectedElements, getAutowireCandidateResolver(registeredBean));
/* 331 */       return BeanRegistrationAotContribution.concat(parentAotContribution, aotContribution);
/*     */     } 
/* 333 */     return parentAotContribution;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private AutowireCandidateResolver getAutowireCandidateResolver(RegisteredBean registeredBean) {
/* 338 */     ConfigurableListableBeanFactory configurableListableBeanFactory = registeredBean.getBeanFactory(); if (configurableListableBeanFactory instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory lbf = (DefaultListableBeanFactory)configurableListableBeanFactory;
/* 339 */       return lbf.getAutowireCandidateResolver(); }
/*     */     
/* 341 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private Collection<LookupElement> getInjectedElements(InjectionMetadata metadata, PropertyValues propertyValues) {
/* 346 */     return metadata.getInjectedElements(propertyValues);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetBeanDefinition(String beanName) {
/* 351 */     this.injectionMetadataCache.remove(beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) {
/* 357 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean postProcessAfterInstantiation(Object bean, String beanName) {
/* 362 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName) {
/* 367 */     InjectionMetadata metadata = findResourceMetadata(beanName, bean.getClass(), pvs);
/*     */     try {
/* 369 */       metadata.inject(bean, beanName, pvs);
/*     */     }
/* 371 */     catch (Throwable ex) {
/* 372 */       throw new BeanCreationException(beanName, "Injection of resource dependencies failed", ex);
/*     */     } 
/* 374 */     return pvs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processInjection(Object bean) throws BeanCreationException {
/* 386 */     Class<?> clazz = bean.getClass();
/* 387 */     InjectionMetadata metadata = findResourceMetadata(clazz.getName(), clazz, (PropertyValues)null);
/*     */     try {
/* 389 */       metadata.inject(bean, null, null);
/*     */     }
/* 391 */     catch (BeanCreationException ex) {
/* 392 */       throw ex;
/*     */     }
/* 394 */     catch (Throwable ex) {
/* 395 */       throw new BeanCreationException("Injection of resource dependencies failed for class [" + String.valueOf(clazz) + "]", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InjectionMetadata findResourceMetadata(String beanName, Class<?> clazz, @Nullable PropertyValues pvs) {
/* 403 */     String cacheKey = StringUtils.hasLength(beanName) ? beanName : clazz.getName();
/*     */     
/* 405 */     InjectionMetadata metadata = this.injectionMetadataCache.get(cacheKey);
/* 406 */     if (InjectionMetadata.needsRefresh(metadata, clazz)) {
/* 407 */       synchronized (this.injectionMetadataCache) {
/* 408 */         metadata = this.injectionMetadataCache.get(cacheKey);
/* 409 */         if (InjectionMetadata.needsRefresh(metadata, clazz)) {
/* 410 */           if (metadata != null) {
/* 411 */             metadata.clear(pvs);
/*     */           }
/* 413 */           metadata = buildResourceMetadata(clazz);
/* 414 */           this.injectionMetadataCache.put(cacheKey, metadata);
/*     */         } 
/*     */       } 
/*     */     }
/* 418 */     return metadata;
/*     */   }
/*     */   
/*     */   private InjectionMetadata buildResourceMetadata(Class<?> clazz) {
/* 422 */     if (!AnnotationUtils.isCandidateClass(clazz, resourceAnnotationTypes)) {
/* 423 */       return InjectionMetadata.EMPTY;
/*     */     }
/*     */     
/* 426 */     List<InjectionMetadata.InjectedElement> elements = new ArrayList<>();
/* 427 */     Class<?> targetClass = clazz;
/*     */     
/*     */     do {
/* 430 */       List<InjectionMetadata.InjectedElement> currElements = new ArrayList<>();
/*     */       
/* 432 */       ReflectionUtils.doWithLocalFields(targetClass, field -> {
/*     */             if (ejbAnnotationType != null && field.isAnnotationPresent(ejbAnnotationType)) {
/*     */               if (Modifier.isStatic(field.getModifiers())) {
/*     */                 throw new IllegalStateException("@EJB annotation is not supported on static fields");
/*     */               }
/*     */               
/*     */               currElements.add(new EjbRefElement(field, field, null));
/*     */             } else if (jakartaResourceType != null && field.isAnnotationPresent(jakartaResourceType)) {
/*     */               if (Modifier.isStatic(field.getModifiers())) {
/*     */                 throw new IllegalStateException("@Resource annotation is not supported on static fields");
/*     */               }
/*     */               
/*     */               if (!this.ignoredResourceTypes.contains(field.getType().getName())) {
/*     */                 currElements.add(new ResourceElement(field, field, null));
/*     */               }
/*     */             } else if (javaxResourceType != null && field.isAnnotationPresent(javaxResourceType)) {
/*     */               if (Modifier.isStatic(field.getModifiers())) {
/*     */                 throw new IllegalStateException("@Resource annotation is not supported on static fields");
/*     */               }
/*     */               
/*     */               if (!this.ignoredResourceTypes.contains(field.getType().getName())) {
/*     */                 currElements.add(new LegacyResourceElement(field, field, null));
/*     */               }
/*     */             } 
/*     */           });
/* 457 */       ReflectionUtils.doWithLocalMethods(targetClass, method -> {
/*     */             Method bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*     */             
/*     */             if (!BridgeMethodResolver.isVisibilityBridgeMethodPair(method, bridgedMethod)) {
/*     */               return;
/*     */             }
/*     */             
/*     */             if (ejbAnnotationType != null && bridgedMethod.isAnnotationPresent(ejbAnnotationType)) {
/*     */               if (method.equals(ClassUtils.getMostSpecificMethod(method, clazz))) {
/*     */                 if (Modifier.isStatic(method.getModifiers())) {
/*     */                   throw new IllegalStateException("@EJB annotation is not supported on static methods");
/*     */                 }
/*     */                 
/*     */                 if (method.getParameterCount() != 1) {
/*     */                   throw new IllegalStateException("@EJB annotation requires a single-arg method: " + String.valueOf(method));
/*     */                 }
/*     */                 
/*     */                 PropertyDescriptor pd = BeanUtils.findPropertyForMethod(bridgedMethod, clazz);
/*     */                 
/*     */                 currElements.add(new EjbRefElement(method, bridgedMethod, pd));
/*     */               } 
/*     */             } else if (jakartaResourceType != null && bridgedMethod.isAnnotationPresent(jakartaResourceType)) {
/*     */               if (method.equals(ClassUtils.getMostSpecificMethod(method, clazz))) {
/*     */                 if (Modifier.isStatic(method.getModifiers())) {
/*     */                   throw new IllegalStateException("@Resource annotation is not supported on static methods");
/*     */                 }
/*     */                 Class<?>[] paramTypes = method.getParameterTypes();
/*     */                 if (paramTypes.length != 1) {
/*     */                   throw new IllegalStateException("@Resource annotation requires a single-arg method: " + String.valueOf(method));
/*     */                 }
/*     */                 if (!this.ignoredResourceTypes.contains(paramTypes[0].getName())) {
/*     */                   PropertyDescriptor pd = BeanUtils.findPropertyForMethod(bridgedMethod, clazz);
/*     */                   currElements.add(new ResourceElement(method, bridgedMethod, pd));
/*     */                 } 
/*     */               } 
/*     */             } else if (javaxResourceType != null && bridgedMethod.isAnnotationPresent(javaxResourceType) && method.equals(ClassUtils.getMostSpecificMethod(method, clazz))) {
/*     */               if (Modifier.isStatic(method.getModifiers())) {
/*     */                 throw new IllegalStateException("@Resource annotation is not supported on static methods");
/*     */               }
/*     */               Class<?>[] paramTypes = method.getParameterTypes();
/*     */               if (paramTypes.length != 1) {
/*     */                 throw new IllegalStateException("@Resource annotation requires a single-arg method: " + String.valueOf(method));
/*     */               }
/*     */               if (!this.ignoredResourceTypes.contains(paramTypes[0].getName())) {
/*     */                 PropertyDescriptor pd = BeanUtils.findPropertyForMethod(bridgedMethod, clazz);
/*     */                 currElements.add(new LegacyResourceElement(method, bridgedMethod, pd));
/*     */               } 
/*     */             } 
/*     */           });
/* 506 */       elements.addAll(0, currElements);
/* 507 */       targetClass = targetClass.getSuperclass();
/*     */     }
/* 509 */     while (targetClass != null && targetClass != Object.class);
/*     */     
/* 511 */     return InjectionMetadata.forElements(elements, clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object buildLazyResourceProxy(final LookupElement element, @Nullable final String requestingBeanName) {
/* 525 */     TargetSource ts = new TargetSource()
/*     */       {
/*     */         public Class<?> getTargetClass() {
/* 528 */           return element.lookupType;
/*     */         }
/*     */         
/*     */         public Object getTarget() {
/* 532 */           return CommonAnnotationBeanPostProcessor.this.getResource(element, requestingBeanName);
/*     */         }
/*     */       };
/*     */     
/* 536 */     ProxyFactory pf = new ProxyFactory();
/* 537 */     pf.setTargetSource(ts);
/* 538 */     if (element.lookupType.isInterface()) {
/* 539 */       pf.addInterface(element.lookupType);
/*     */     }
/* 541 */     BeanFactory beanFactory = this.beanFactory; ConfigurableBeanFactory configurableBeanFactory = (ConfigurableBeanFactory)beanFactory;
/* 542 */     ClassLoader classLoader = (beanFactory instanceof ConfigurableBeanFactory) ? configurableBeanFactory.getBeanClassLoader() : null;
/* 543 */     return pf.getProxy(classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getResource(LookupElement element, @Nullable String requestingBeanName) throws NoSuchBeanDefinitionException {
/* 557 */     String jndiName = null;
/* 558 */     if (StringUtils.hasLength(element.mappedName)) {
/* 559 */       jndiName = element.mappedName;
/*     */     }
/* 561 */     else if (this.alwaysUseJndiLookup) {
/* 562 */       jndiName = element.name;
/*     */     } 
/* 564 */     if (jndiName != null) {
/* 565 */       if (this.jndiFactory == null) {
/* 566 */         throw new NoSuchBeanDefinitionException(element.lookupType, "No JNDI factory configured - specify the 'jndiFactory' property");
/*     */       }
/*     */       
/* 569 */       return this.jndiFactory.getBean(jndiName, element.lookupType);
/*     */     } 
/*     */ 
/*     */     
/* 573 */     if (this.resourceFactory == null) {
/* 574 */       throw new NoSuchBeanDefinitionException(element.lookupType, "No resource factory configured - specify the 'resourceFactory' property");
/*     */     }
/*     */     
/* 577 */     return autowireResource(this.resourceFactory, element, requestingBeanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object autowireResource(BeanFactory factory, LookupElement element, @Nullable String requestingBeanName) throws NoSuchBeanDefinitionException {
/*     */     Object resource;
/*     */     Set<String> autowiredBeanNames;
/* 594 */     String name = element.name;
/*     */     
/* 596 */     if (factory instanceof AutowireCapableBeanFactory) { AutowireCapableBeanFactory autowireCapableBeanFactory = (AutowireCapableBeanFactory)factory;
/* 597 */       if (this.fallbackToDefaultTypeMatch && element.isDefaultName && !factory.containsBean(name)) {
/* 598 */         autowiredBeanNames = new LinkedHashSet<>();
/* 599 */         resource = autowireCapableBeanFactory.resolveDependency(element
/* 600 */             .getDependencyDescriptor(), requestingBeanName, autowiredBeanNames, null);
/* 601 */         if (resource == null) {
/* 602 */           throw new NoSuchBeanDefinitionException(element.getLookupType(), "No resolvable resource object");
/*     */         }
/*     */       } else {
/*     */         
/* 606 */         resource = autowireCapableBeanFactory.resolveBeanByName(name, element.getDependencyDescriptor());
/* 607 */         autowiredBeanNames = Collections.singleton(name);
/*     */       }  }
/*     */     else
/*     */     
/* 611 */     { resource = factory.getBean(name, element.lookupType);
/* 612 */       autowiredBeanNames = Collections.singleton(name); }
/*     */ 
/*     */     
/* 615 */     if (factory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory configurableBeanFactory = (ConfigurableBeanFactory)factory;
/* 616 */       for (String autowiredBeanName : autowiredBeanNames) {
/* 617 */         if (requestingBeanName != null && configurableBeanFactory.containsBean(autowiredBeanName)) {
/* 618 */           configurableBeanFactory.registerDependentBean(autowiredBeanName, requestingBeanName);
/*     */         }
/*     */       }  }
/*     */ 
/*     */     
/* 623 */     return resource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Class<? extends Annotation> loadAnnotationType(String name) {
/*     */     try {
/* 631 */       return 
/* 632 */         ClassUtils.forName(name, CommonAnnotationBeanPostProcessor.class.getClassLoader());
/*     */     }
/* 634 */     catch (ClassNotFoundException ex) {
/* 635 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static abstract class LookupElement
/*     */     extends InjectionMetadata.InjectedElement
/*     */   {
/* 646 */     protected String name = "";
/*     */     
/*     */     protected boolean isDefaultName = false;
/*     */     
/* 650 */     protected Class<?> lookupType = Object.class;
/*     */     
/*     */     @Nullable
/*     */     protected String mappedName;
/*     */     
/*     */     public LookupElement(Member member, @Nullable PropertyDescriptor pd) {
/* 656 */       super(member, pd);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getName() {
/* 663 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Class<?> getLookupType() {
/* 670 */       return this.lookupType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final DependencyDescriptor getDependencyDescriptor() {
/* 677 */       if (this.isField) {
/* 678 */         return new ResourceElementResolver.LookupDependencyDescriptor((Field)this.member, this.lookupType, 
/* 679 */             isLazyLookup());
/*     */       }
/*     */       
/* 682 */       return new ResourceElementResolver.LookupDependencyDescriptor((Method)this.member, this.lookupType, 
/* 683 */           isLazyLookup());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isLazyLookup() {
/* 693 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class ResourceElement
/*     */     extends LookupElement
/*     */   {
/*     */     private final boolean lazyLookup;
/*     */ 
/*     */ 
/*     */     
/*     */     public ResourceElement(Member member, @Nullable AnnotatedElement ae, PropertyDescriptor pd) {
/* 707 */       super(member, pd);
/* 708 */       Resource resource = ae.<Resource>getAnnotation(Resource.class);
/* 709 */       String resourceName = resource.name();
/* 710 */       Class<?> resourceType = resource.type();
/* 711 */       this.isDefaultName = !StringUtils.hasLength(resourceName);
/* 712 */       if (this.isDefaultName) {
/* 713 */         resourceName = this.member.getName();
/* 714 */         if (this.member instanceof Method && resourceName.startsWith("set") && resourceName.length() > 3) {
/* 715 */           resourceName = StringUtils.uncapitalizeAsProperty(resourceName.substring(3));
/*     */         }
/*     */       }
/* 718 */       else if (CommonAnnotationBeanPostProcessor.this.embeddedValueResolver != null) {
/* 719 */         resourceName = CommonAnnotationBeanPostProcessor.this.embeddedValueResolver.resolveStringValue(resourceName);
/*     */       } 
/* 721 */       if (Object.class != resourceType) {
/* 722 */         checkResourceType(resourceType);
/*     */       }
/*     */       else {
/*     */         
/* 726 */         resourceType = getResourceType();
/*     */       } 
/* 728 */       this.name = (resourceName != null) ? resourceName : "";
/* 729 */       this.lookupType = resourceType;
/* 730 */       String lookupValue = resource.lookup();
/* 731 */       this.mappedName = StringUtils.hasLength(lookupValue) ? lookupValue : resource.mappedName();
/* 732 */       Lazy lazy = ae.<Lazy>getAnnotation(Lazy.class);
/* 733 */       this.lazyLookup = (lazy != null && lazy.value());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object getResourceToInject(Object target, @Nullable String requestingBeanName) {
/* 738 */       return this.lazyLookup ? CommonAnnotationBeanPostProcessor.this.buildLazyResourceProxy(this, requestingBeanName) : 
/* 739 */         CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isLazyLookup() {
/* 744 */       return this.lazyLookup;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class LegacyResourceElement
/*     */     extends LookupElement
/*     */   {
/*     */     private final boolean lazyLookup;
/*     */ 
/*     */ 
/*     */     
/*     */     public LegacyResourceElement(Member member, @Nullable AnnotatedElement ae, PropertyDescriptor pd) {
/* 758 */       super(member, pd);
/* 759 */       Resource resource = ae.<Resource>getAnnotation(Resource.class);
/* 760 */       String resourceName = resource.name();
/* 761 */       Class<?> resourceType = resource.type();
/* 762 */       this.isDefaultName = !StringUtils.hasLength(resourceName);
/* 763 */       if (this.isDefaultName) {
/* 764 */         resourceName = this.member.getName();
/* 765 */         if (this.member instanceof Method && resourceName.startsWith("set") && resourceName.length() > 3) {
/* 766 */           resourceName = StringUtils.uncapitalizeAsProperty(resourceName.substring(3));
/*     */         }
/*     */       }
/* 769 */       else if (CommonAnnotationBeanPostProcessor.this.embeddedValueResolver != null) {
/* 770 */         resourceName = CommonAnnotationBeanPostProcessor.this.embeddedValueResolver.resolveStringValue(resourceName);
/*     */       } 
/* 772 */       if (Object.class != resourceType) {
/* 773 */         checkResourceType(resourceType);
/*     */       }
/*     */       else {
/*     */         
/* 777 */         resourceType = getResourceType();
/*     */       } 
/* 779 */       this.name = (resourceName != null) ? resourceName : "";
/* 780 */       this.lookupType = resourceType;
/* 781 */       String lookupValue = resource.lookup();
/* 782 */       this.mappedName = StringUtils.hasLength(lookupValue) ? lookupValue : resource.mappedName();
/* 783 */       Lazy lazy = ae.<Lazy>getAnnotation(Lazy.class);
/* 784 */       this.lazyLookup = (lazy != null && lazy.value());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object getResourceToInject(Object target, @Nullable String requestingBeanName) {
/* 789 */       return this.lazyLookup ? CommonAnnotationBeanPostProcessor.this.buildLazyResourceProxy(this, requestingBeanName) : 
/* 790 */         CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isLazyLookup() {
/* 795 */       return this.lazyLookup;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class EjbRefElement
/*     */     extends LookupElement
/*     */   {
/*     */     private final String beanName;
/*     */ 
/*     */ 
/*     */     
/*     */     public EjbRefElement(Member member, @Nullable AnnotatedElement ae, PropertyDescriptor pd) {
/* 809 */       super(member, pd);
/* 810 */       EJB resource = ae.<EJB>getAnnotation(EJB.class);
/* 811 */       String resourceBeanName = resource.beanName();
/* 812 */       String resourceName = resource.name();
/* 813 */       this.isDefaultName = !StringUtils.hasLength(resourceName);
/* 814 */       if (this.isDefaultName) {
/* 815 */         resourceName = this.member.getName();
/* 816 */         if (this.member instanceof Method && resourceName.startsWith("set") && resourceName.length() > 3) {
/* 817 */           resourceName = StringUtils.uncapitalizeAsProperty(resourceName.substring(3));
/*     */         }
/*     */       } 
/* 820 */       Class<?> resourceType = resource.beanInterface();
/* 821 */       if (Object.class != resourceType) {
/* 822 */         checkResourceType(resourceType);
/*     */       }
/*     */       else {
/*     */         
/* 826 */         resourceType = getResourceType();
/*     */       } 
/* 828 */       this.beanName = resourceBeanName;
/* 829 */       this.name = resourceName;
/* 830 */       this.lookupType = resourceType;
/* 831 */       this.mappedName = resource.mappedName();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object getResourceToInject(Object target, @Nullable String requestingBeanName) {
/* 836 */       if (StringUtils.hasLength(this.beanName)) {
/* 837 */         if (CommonAnnotationBeanPostProcessor.this.beanFactory != null && CommonAnnotationBeanPostProcessor.this.beanFactory.containsBean(this.beanName)) {
/*     */           
/* 839 */           Object bean = CommonAnnotationBeanPostProcessor.this.beanFactory.getBean(this.beanName, this.lookupType);
/* 840 */           if (requestingBeanName != null) { BeanFactory beanFactory = CommonAnnotationBeanPostProcessor.this.beanFactory; if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory configurableBeanFactory = (ConfigurableBeanFactory)beanFactory;
/* 841 */               configurableBeanFactory.registerDependentBean(this.beanName, requestingBeanName); }
/*     */              }
/* 843 */            return bean;
/*     */         } 
/* 845 */         if (this.isDefaultName && !StringUtils.hasLength(this.mappedName)) {
/* 846 */           throw new NoSuchBeanDefinitionException(this.beanName, "Cannot resolve 'beanName' in local BeanFactory. Consider specifying a general 'name' value instead.");
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 851 */       return CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AotContribution
/*     */     implements BeanRegistrationAotContribution
/*     */   {
/*     */     private static final String REGISTERED_BEAN_PARAMETER = "registeredBean";
/*     */ 
/*     */     
/*     */     private static final String INSTANCE_PARAMETER = "instance";
/*     */ 
/*     */     
/*     */     private final Class<?> target;
/*     */     
/*     */     private final Collection<CommonAnnotationBeanPostProcessor.LookupElement> lookupElements;
/*     */     
/*     */     @Nullable
/*     */     private final AutowireCandidateResolver candidateResolver;
/*     */ 
/*     */     
/*     */     AotContribution(Class<?> target, Collection<CommonAnnotationBeanPostProcessor.LookupElement> lookupElements, @Nullable AutowireCandidateResolver candidateResolver) {
/* 875 */       this.target = target;
/* 876 */       this.lookupElements = lookupElements;
/* 877 */       this.candidateResolver = candidateResolver;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 883 */       GeneratedClass generatedClass = generationContext.getGeneratedClasses().addForFeatureComponent("ResourceAutowiring", this.target, type -> {
/*     */             type.addJavadoc("Resource autowiring for {@link $T}.", new Object[] { this.target });
/*     */             type.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */           });
/* 887 */       GeneratedMethod generateMethod = generatedClass.getMethods().add("apply", method -> {
/*     */             method.addJavadoc("Apply resource autowiring.", new Object[0]);
/*     */             
/*     */             method.addModifiers(new Modifier[] { Modifier.PUBLIC, Modifier.STATIC });
/*     */             
/*     */             method.addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]);
/*     */             method.addParameter(this.target, "instance", new Modifier[0]);
/*     */             method.returns(this.target);
/*     */             method.addCode(generateMethodCode(generatedClass.getName(), generationContext.getRuntimeHints()));
/*     */           });
/* 897 */       beanRegistrationCode.addInstancePostProcessor(generateMethod.toMethodReference());
/*     */       
/* 899 */       registerHints(generationContext.getRuntimeHints());
/*     */     }
/*     */     
/*     */     private CodeBlock generateMethodCode(ClassName targetClassName, RuntimeHints hints) {
/* 903 */       CodeBlock.Builder code = CodeBlock.builder();
/* 904 */       for (CommonAnnotationBeanPostProcessor.LookupElement lookupElement : this.lookupElements) {
/* 905 */         code.addStatement(generateMethodStatementForElement(targetClassName, lookupElement, hints));
/*     */       }
/*     */       
/* 908 */       code.addStatement("return $L", new Object[] { "instance" });
/* 909 */       return code.build();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private CodeBlock generateMethodStatementForElement(ClassName targetClassName, CommonAnnotationBeanPostProcessor.LookupElement lookupElement, RuntimeHints hints) {
/* 915 */       Member member = lookupElement.getMember();
/* 916 */       if (member instanceof Field) { Field field = (Field)member;
/* 917 */         return generateMethodStatementForField(targetClassName, field, lookupElement, hints); }
/*     */ 
/*     */       
/* 920 */       if (member instanceof Method) { Method method = (Method)member;
/* 921 */         return generateMethodStatementForMethod(targetClassName, method, lookupElement, hints); }
/*     */ 
/*     */       
/* 924 */       throw new IllegalStateException("Unsupported member type " + member
/* 925 */           .getClass().getName());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private CodeBlock generateMethodStatementForField(ClassName targetClassName, Field field, CommonAnnotationBeanPostProcessor.LookupElement lookupElement, RuntimeHints hints) {
/* 931 */       hints.reflection().registerField(field);
/* 932 */       CodeBlock resolver = generateFieldResolverCode(field, lookupElement);
/* 933 */       AccessControl accessControl = AccessControl.forMember(field);
/* 934 */       if (!accessControl.isAccessibleFrom(targetClassName)) {
/* 935 */         return CodeBlock.of("$L.resolveAndSet($L, $L)", new Object[] { resolver, "registeredBean", "instance" });
/*     */       }
/*     */       
/* 938 */       return CodeBlock.of("$L.$L = $L.resolve($L)", new Object[] { "instance", field
/* 939 */             .getName(), resolver, "registeredBean" });
/*     */     }
/*     */     
/*     */     private CodeBlock generateFieldResolverCode(Field field, CommonAnnotationBeanPostProcessor.LookupElement lookupElement) {
/* 943 */       if (lookupElement.isDefaultName) {
/* 944 */         return CodeBlock.of("$T.$L($S)", new Object[] { ResourceElementResolver.class, "forField", field
/* 945 */               .getName() });
/*     */       }
/*     */       
/* 948 */       return CodeBlock.of("$T.$L($S, $S)", new Object[] { ResourceElementResolver.class, "forField", field
/* 949 */             .getName(), lookupElement.getName() });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private CodeBlock generateMethodStatementForMethod(ClassName targetClassName, Method method, CommonAnnotationBeanPostProcessor.LookupElement lookupElement, RuntimeHints hints) {
/* 956 */       CodeBlock resolver = generateMethodResolverCode(method, lookupElement);
/* 957 */       AccessControl accessControl = AccessControl.forMember(method);
/* 958 */       if (!accessControl.isAccessibleFrom(targetClassName)) {
/* 959 */         hints.reflection().registerMethod(method, ExecutableMode.INVOKE);
/* 960 */         return CodeBlock.of("$L.resolveAndSet($L, $L)", new Object[] { resolver, "registeredBean", "instance" });
/*     */       } 
/*     */       
/* 963 */       hints.reflection().registerMethod(method, ExecutableMode.INTROSPECT);
/* 964 */       return CodeBlock.of("$L.$L($L.resolve($L))", new Object[] { "instance", method
/* 965 */             .getName(), resolver, "registeredBean" });
/*     */     }
/*     */ 
/*     */     
/*     */     private CodeBlock generateMethodResolverCode(Method method, CommonAnnotationBeanPostProcessor.LookupElement lookupElement) {
/* 970 */       if (lookupElement.isDefaultName) {
/* 971 */         return CodeBlock.of("$T.$L($S, $T.class)", new Object[] { ResourceElementResolver.class, "forMethod", method
/* 972 */               .getName(), lookupElement.getLookupType() });
/*     */       }
/*     */       
/* 975 */       return CodeBlock.of("$T.$L($S, $T.class, $S)", new Object[] { ResourceElementResolver.class, "forMethod", method
/* 976 */             .getName(), lookupElement.getLookupType(), lookupElement.getName() });
/*     */     }
/*     */ 
/*     */     
/*     */     private void registerHints(RuntimeHints runtimeHints) {
/* 981 */       this.lookupElements.forEach(lookupElement -> registerProxyIfNecessary(runtimeHints, lookupElement.getDependencyDescriptor()));
/*     */     }
/*     */ 
/*     */     
/*     */     private void registerProxyIfNecessary(RuntimeHints runtimeHints, DependencyDescriptor dependencyDescriptor) {
/* 986 */       if (this.candidateResolver != null) {
/*     */         
/* 988 */         Class<?> proxyClass = this.candidateResolver.getLazyResolutionProxyClass(dependencyDescriptor, null);
/* 989 */         if (proxyClass != null)
/* 990 */           ClassHintUtils.registerProxyIfNecessary(proxyClass, runtimeHints); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\CommonAnnotationBeanPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */