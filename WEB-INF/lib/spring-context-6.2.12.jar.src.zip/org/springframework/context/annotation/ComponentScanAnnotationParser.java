/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.filter.AbstractTypeHierarchyTraversingFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ComponentScanAnnotationParser
/*     */ {
/*     */   private final Environment environment;
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final BeanNameGenerator beanNameGenerator;
/*     */   private final BeanDefinitionRegistry registry;
/*     */   
/*     */   public ComponentScanAnnotationParser(Environment environment, ResourceLoader resourceLoader, BeanNameGenerator beanNameGenerator, BeanDefinitionRegistry registry) {
/*  61 */     this.environment = environment;
/*  62 */     this.resourceLoader = resourceLoader;
/*  63 */     this.beanNameGenerator = beanNameGenerator;
/*  64 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<BeanDefinitionHolder> parse(AnnotationAttributes componentScan, final String declaringClass) {
/*  70 */     ClassPathBeanDefinitionScanner scanner = new ClassPathBeanDefinitionScanner(this.registry, componentScan.getBoolean("useDefaultFilters"), this.environment, this.resourceLoader);
/*     */     
/*  72 */     Class<? extends BeanNameGenerator> generatorClass = componentScan.getClass("nameGenerator");
/*  73 */     boolean useInheritedGenerator = (BeanNameGenerator.class == generatorClass);
/*  74 */     scanner.setBeanNameGenerator(useInheritedGenerator ? this.beanNameGenerator : 
/*  75 */         (BeanNameGenerator)BeanUtils.instantiateClass(generatorClass));
/*     */     
/*  77 */     ScopedProxyMode scopedProxyMode = (ScopedProxyMode)componentScan.getEnum("scopedProxy");
/*  78 */     if (scopedProxyMode != ScopedProxyMode.DEFAULT) {
/*  79 */       scanner.setScopedProxyMode(scopedProxyMode);
/*     */     } else {
/*     */       
/*  82 */       Class<? extends ScopeMetadataResolver> resolverClass = componentScan.getClass("scopeResolver");
/*  83 */       scanner.setScopeMetadataResolver((ScopeMetadataResolver)BeanUtils.instantiateClass(resolverClass));
/*     */     } 
/*     */     
/*  86 */     scanner.setResourcePattern(componentScan.getString("resourcePattern"));
/*     */     
/*  88 */     for (AnnotationAttributes includeFilterAttributes : componentScan.getAnnotationArray("includeFilters")) {
/*  89 */       List<TypeFilter> typeFilters = TypeFilterUtils.createTypeFiltersFor(includeFilterAttributes, this.environment, this.resourceLoader, this.registry);
/*     */       
/*  91 */       for (TypeFilter typeFilter : typeFilters) {
/*  92 */         scanner.addIncludeFilter(typeFilter);
/*     */       }
/*     */     } 
/*  95 */     for (AnnotationAttributes excludeFilterAttributes : componentScan.getAnnotationArray("excludeFilters")) {
/*  96 */       List<TypeFilter> typeFilters = TypeFilterUtils.createTypeFiltersFor(excludeFilterAttributes, this.environment, this.resourceLoader, this.registry);
/*     */       
/*  98 */       for (TypeFilter typeFilter : typeFilters) {
/*  99 */         scanner.addExcludeFilter(typeFilter);
/*     */       }
/*     */     } 
/*     */     
/* 103 */     boolean lazyInit = componentScan.getBoolean("lazyInit");
/* 104 */     if (lazyInit) {
/* 105 */       scanner.getBeanDefinitionDefaults().setLazyInit(true);
/*     */     }
/*     */     
/* 108 */     Set<String> basePackages = new LinkedHashSet<>();
/* 109 */     String[] basePackagesArray = componentScan.getStringArray("basePackages");
/* 110 */     for (String pkg : basePackagesArray) {
/* 111 */       String[] tokenized = StringUtils.tokenizeToStringArray(this.environment.resolvePlaceholders(pkg), ",; \t\n");
/*     */       
/* 113 */       Collections.addAll(basePackages, tokenized);
/*     */     } 
/* 115 */     for (Class<?> clazz : componentScan.getClassArray("basePackageClasses")) {
/* 116 */       basePackages.add(ClassUtils.getPackageName(clazz));
/*     */     }
/* 118 */     if (basePackages.isEmpty()) {
/* 119 */       basePackages.add(ClassUtils.getPackageName(declaringClass));
/*     */     }
/*     */     
/* 122 */     scanner.addExcludeFilter((TypeFilter)new AbstractTypeHierarchyTraversingFilter(false, false)
/*     */         {
/*     */           protected boolean matchClassName(String className) {
/* 125 */             return declaringClass.equals(className);
/*     */           }
/*     */         });
/* 128 */     return scanner.doScan(StringUtils.toStringArray(basePackages));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ComponentScanAnnotationParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */