/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.groovy.GroovyBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionOverrideException;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.StandardAnnotationMetadata;
/*     */ import org.springframework.core.type.StandardMethodMetadata;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationClassBeanDefinitionReader
/*     */ {
/*  76 */   private static final Log logger = LogFactory.getLog(ConfigurationClassBeanDefinitionReader.class);
/*     */   
/*  78 */   private static final ScopeMetadataResolver scopeMetadataResolver = new AnnotationScopeMetadataResolver();
/*     */ 
/*     */   
/*     */   private final BeanDefinitionRegistry registry;
/*     */ 
/*     */   
/*     */   private final SourceExtractor sourceExtractor;
/*     */ 
/*     */   
/*     */   private final ResourceLoader resourceLoader;
/*     */ 
/*     */   
/*     */   private final Environment environment;
/*     */ 
/*     */   
/*     */   private final BeanNameGenerator importBeanNameGenerator;
/*     */ 
/*     */   
/*     */   private final ImportRegistry importRegistry;
/*     */ 
/*     */   
/*     */   private final ConditionEvaluator conditionEvaluator;
/*     */ 
/*     */   
/*     */   ConfigurationClassBeanDefinitionReader(BeanDefinitionRegistry registry, SourceExtractor sourceExtractor, ResourceLoader resourceLoader, Environment environment, BeanNameGenerator importBeanNameGenerator, ImportRegistry importRegistry) {
/* 103 */     this.registry = registry;
/* 104 */     this.sourceExtractor = sourceExtractor;
/* 105 */     this.resourceLoader = resourceLoader;
/* 106 */     this.environment = environment;
/* 107 */     this.importBeanNameGenerator = importBeanNameGenerator;
/* 108 */     this.importRegistry = importRegistry;
/* 109 */     this.conditionEvaluator = new ConditionEvaluator(registry, environment, resourceLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadBeanDefinitions(Set<ConfigurationClass> configurationModel) {
/* 118 */     TrackedConditionEvaluator trackedConditionEvaluator = new TrackedConditionEvaluator();
/* 119 */     for (ConfigurationClass configClass : configurationModel) {
/* 120 */       loadBeanDefinitionsForConfigurationClass(configClass, trackedConditionEvaluator);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadBeanDefinitionsForConfigurationClass(ConfigurationClass configClass, TrackedConditionEvaluator trackedConditionEvaluator) {
/* 131 */     if (trackedConditionEvaluator.shouldSkip(configClass)) {
/* 132 */       String beanName = configClass.getBeanName();
/* 133 */       if (StringUtils.hasLength(beanName) && this.registry.containsBeanDefinition(beanName)) {
/* 134 */         this.registry.removeBeanDefinition(beanName);
/*     */       }
/* 136 */       this.importRegistry.removeImportingClass(configClass.getMetadata().getClassName());
/*     */       
/*     */       return;
/*     */     } 
/* 140 */     if (configClass.isImported()) {
/* 141 */       registerBeanDefinitionForImportedConfigurationClass(configClass);
/*     */     }
/* 143 */     for (BeanMethod beanMethod : configClass.getBeanMethods()) {
/* 144 */       loadBeanDefinitionsForBeanMethod(beanMethod);
/*     */     }
/*     */     
/* 147 */     loadBeanDefinitionsFromImportedResources(configClass.getImportedResources());
/* 148 */     loadBeanDefinitionsFromRegistrars(configClass.getImportBeanDefinitionRegistrars());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerBeanDefinitionForImportedConfigurationClass(ConfigurationClass configClass) {
/*     */     String configBeanName;
/* 155 */     AnnotationMetadata metadata = configClass.getMetadata();
/* 156 */     AnnotatedGenericBeanDefinition configBeanDef = new AnnotatedGenericBeanDefinition(metadata);
/*     */     
/* 158 */     ScopeMetadata scopeMetadata = scopeMetadataResolver.resolveScopeMetadata((BeanDefinition)configBeanDef);
/* 159 */     configBeanDef.setScope(scopeMetadata.getScopeName());
/*     */ 
/*     */     
/*     */     try {
/* 163 */       configBeanName = this.importBeanNameGenerator.generateBeanName((BeanDefinition)configBeanDef, this.registry);
/*     */     }
/* 165 */     catch (IllegalArgumentException ex) {
/* 166 */       throw new IllegalStateException("Failed to generate bean name for imported class '" + configClass
/* 167 */           .getMetadata().getClassName() + "'", ex);
/*     */     } 
/*     */     
/* 170 */     AnnotationConfigUtils.processCommonDefinitionAnnotations((AnnotatedBeanDefinition)configBeanDef, (AnnotatedTypeMetadata)metadata);
/* 171 */     BeanDefinitionHolder definitionHolder = new BeanDefinitionHolder((BeanDefinition)configBeanDef, configBeanName);
/* 172 */     definitionHolder = AnnotationConfigUtils.applyScopedProxyMode(scopeMetadata, definitionHolder, this.registry);
/* 173 */     this.registry.registerBeanDefinition(definitionHolder.getBeanName(), definitionHolder.getBeanDefinition());
/* 174 */     configClass.setBeanName(configBeanName);
/*     */     
/* 176 */     if (logger.isTraceEnabled()) {
/* 177 */       logger.trace("Registered bean definition for imported class '" + configBeanName + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadBeanDefinitionsForBeanMethod(BeanMethod beanMethod) {
/*     */     String beanName;
/* 186 */     ConfigurationClass configClass = beanMethod.getConfigurationClass();
/* 187 */     MethodMetadata metadata = beanMethod.getMetadata();
/* 188 */     String methodName = metadata.getMethodName();
/*     */ 
/*     */     
/* 191 */     if (this.conditionEvaluator.shouldSkip((AnnotatedTypeMetadata)metadata, ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN)) {
/* 192 */       configClass.skippedBeanMethods.add(methodName);
/*     */       return;
/*     */     } 
/* 195 */     if (configClass.skippedBeanMethods.contains(methodName)) {
/*     */       return;
/*     */     }
/*     */     
/* 199 */     AnnotationAttributes bean = AnnotationConfigUtils.attributesFor((AnnotatedTypeMetadata)metadata, Bean.class);
/* 200 */     Assert.state((bean != null), "No @Bean annotation attributes");
/*     */ 
/*     */     
/* 203 */     String[] explicitNames = bean.getStringArray("name");
/*     */     
/* 205 */     if (explicitNames.length > 0) {
/* 206 */       beanName = explicitNames[0];
/*     */       
/* 208 */       for (int i = 1; i < explicitNames.length; i++) {
/* 209 */         this.registry.registerAlias(beanName, explicitNames[i]);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 214 */       beanName = methodName;
/*     */     } 
/*     */ 
/*     */     
/* 218 */     if (isOverriddenByExistingDefinition(beanMethod, beanName)) {
/* 219 */       if (beanName.equals(beanMethod.getConfigurationClass().getBeanName())) {
/* 220 */         throw new BeanDefinitionStoreException(beanMethod.getConfigurationClass().getResource().getDescription(), beanName, "Bean name derived from @Bean method '" + beanMethod
/* 221 */             .getMetadata().getMethodName() + "' clashes with bean name for containing configuration class; please make those names unique!");
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 227 */     ConfigurationClassBeanDefinition beanDef = new ConfigurationClassBeanDefinition(configClass, metadata, beanName);
/* 228 */     beanDef.setSource(this.sourceExtractor.extractSource(metadata, configClass.getResource()));
/*     */     
/* 230 */     if (metadata.isStatic()) {
/*     */       
/* 232 */       AnnotationMetadata annotationMetadata = configClass.getMetadata(); if (annotationMetadata instanceof StandardAnnotationMetadata) { StandardAnnotationMetadata sam = (StandardAnnotationMetadata)annotationMetadata;
/* 233 */         beanDef.setBeanClass(sam.getIntrospectedClass()); }
/*     */       else
/*     */       
/* 236 */       { beanDef.setBeanClassName(configClass.getMetadata().getClassName()); }
/*     */       
/* 238 */       beanDef.setUniqueFactoryMethodName(methodName);
/*     */     }
/*     */     else {
/*     */       
/* 242 */       beanDef.setFactoryBeanName(configClass.getBeanName());
/* 243 */       beanDef.setUniqueFactoryMethodName(methodName);
/*     */     } 
/*     */     
/* 246 */     if (metadata instanceof StandardMethodMetadata) { StandardMethodMetadata smm = (StandardMethodMetadata)metadata;
/* 247 */       AnnotationMetadata annotationMetadata = configClass.getMetadata(); if (annotationMetadata instanceof StandardAnnotationMetadata) { StandardAnnotationMetadata sam = (StandardAnnotationMetadata)annotationMetadata;
/* 248 */         Method method = ClassUtils.getMostSpecificMethod(smm.getIntrospectedMethod(), sam.getIntrospectedClass());
/* 249 */         if (method == smm.getIntrospectedMethod()) {
/* 250 */           beanDef.setResolvedFactoryMethod(method);
/*     */         } }
/*     */        }
/*     */     
/* 254 */     beanDef.setAutowireMode(3);
/* 255 */     AnnotationConfigUtils.processCommonDefinitionAnnotations(beanDef, (AnnotatedTypeMetadata)metadata);
/*     */     
/* 257 */     boolean autowireCandidate = bean.getBoolean("autowireCandidate");
/* 258 */     if (!autowireCandidate) {
/* 259 */       beanDef.setAutowireCandidate(false);
/*     */     }
/*     */     
/* 262 */     boolean defaultCandidate = bean.getBoolean("defaultCandidate");
/* 263 */     if (!defaultCandidate) {
/* 264 */       beanDef.setDefaultCandidate(false);
/*     */     }
/*     */     
/* 267 */     Bean.Bootstrap instantiation = (Bean.Bootstrap)bean.getEnum("bootstrap");
/* 268 */     if (instantiation == Bean.Bootstrap.BACKGROUND) {
/* 269 */       beanDef.setBackgroundInit(true);
/*     */     }
/*     */     
/* 272 */     String initMethodName = bean.getString("initMethod");
/* 273 */     if (StringUtils.hasText(initMethodName)) {
/* 274 */       beanDef.setInitMethodName(initMethodName);
/*     */     }
/*     */     
/* 277 */     String destroyMethodName = bean.getString("destroyMethod");
/* 278 */     beanDef.setDestroyMethodName(destroyMethodName);
/*     */ 
/*     */     
/* 281 */     ScopedProxyMode proxyMode = ScopedProxyMode.NO;
/* 282 */     AnnotationAttributes attributes = AnnotationConfigUtils.attributesFor((AnnotatedTypeMetadata)metadata, Scope.class);
/* 283 */     if (attributes != null) {
/* 284 */       beanDef.setScope(attributes.getString("value"));
/* 285 */       proxyMode = (ScopedProxyMode)attributes.getEnum("proxyMode");
/* 286 */       if (proxyMode == ScopedProxyMode.DEFAULT) {
/* 287 */         proxyMode = ScopedProxyMode.NO;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 292 */     ConfigurationClassBeanDefinition configurationClassBeanDefinition1 = beanDef;
/* 293 */     if (proxyMode != ScopedProxyMode.NO) {
/* 294 */       BeanDefinitionHolder proxyDef = ScopedProxyCreator.createScopedProxy(new BeanDefinitionHolder((BeanDefinition)beanDef, beanName), this.registry, (proxyMode == ScopedProxyMode.TARGET_CLASS));
/*     */ 
/*     */ 
/*     */       
/* 298 */       configurationClassBeanDefinition1 = new ConfigurationClassBeanDefinition((RootBeanDefinition)proxyDef.getBeanDefinition(), configClass, metadata, beanName);
/*     */     } 
/*     */     
/* 301 */     if (logger.isTraceEnabled()) {
/* 302 */       logger.trace("Registering bean definition for @Bean method %s.%s()"
/* 303 */           .formatted(new Object[] { configClass.getMetadata().getClassName(), beanName }));
/*     */     }
/* 305 */     this.registry.registerBeanDefinition(beanName, (BeanDefinition)configurationClassBeanDefinition1);
/*     */   }
/*     */   
/*     */   protected boolean isOverriddenByExistingDefinition(BeanMethod beanMethod, String beanName) {
/* 309 */     if (!this.registry.containsBeanDefinition(beanName)) {
/* 310 */       return false;
/*     */     }
/* 312 */     BeanDefinition existingBeanDef = this.registry.getBeanDefinition(beanName);
/* 313 */     ConfigurationClass configClass = beanMethod.getConfigurationClass();
/*     */ 
/*     */ 
/*     */     
/* 317 */     if (existingBeanDef instanceof ConfigurationClassBeanDefinition) { ConfigurationClassBeanDefinition ccbd = (ConfigurationClassBeanDefinition)existingBeanDef;
/* 318 */       if (ccbd.getMetadata().getClassName().equals(configClass.getMetadata().getClassName())) {
/* 319 */         if (ccbd.getFactoryMethodMetadata().getMethodName().equals(beanMethod.getMetadata().getMethodName())) {
/* 320 */           ccbd.setNonUniqueFactoryMethodName(ccbd.getFactoryMethodMetadata().getMethodName());
/*     */         }
/* 322 */         else if (!this.registry.isBeanDefinitionOverridable(beanName)) {
/* 323 */           throw new BeanDefinitionOverrideException(beanName, new ConfigurationClassBeanDefinition(configClass, beanMethod
/* 324 */                 .getMetadata(), beanName), existingBeanDef, "@Bean method override with same bean name but different method name: " + String.valueOf(existingBeanDef));
/*     */         } 
/*     */ 
/*     */         
/* 328 */         return true;
/*     */       } 
/*     */       
/* 331 */       return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 338 */     if (existingBeanDef instanceof ScannedGenericBeanDefinition) { ScannedGenericBeanDefinition scannedBeanDef = (ScannedGenericBeanDefinition)existingBeanDef;
/* 339 */       if (beanMethod.getMetadata().getReturnTypeName().equals(scannedBeanDef.getBeanClassName())) {
/* 340 */         this.registry.removeBeanDefinition(beanName);
/*     */       }
/* 342 */       return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 347 */     if (existingBeanDef.getRole() > 0) {
/* 348 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 353 */     if (!this.registry.isBeanDefinitionOverridable(beanName)) {
/* 354 */       throw new BeanDefinitionOverrideException(beanName, new ConfigurationClassBeanDefinition(configClass, beanMethod
/* 355 */             .getMetadata(), beanName), existingBeanDef, "@Bean definition illegally overridden by existing bean definition: " + String.valueOf(existingBeanDef));
/*     */     }
/*     */ 
/*     */     
/* 359 */     if (logger.isDebugEnabled()) {
/* 360 */       logger.debug("Skipping bean definition for %s: a definition for bean '%s' already exists. " + "This top-level bean definition is considered as an override."
/* 361 */           .formatted(new Object[] { beanMethod, beanName }));
/*     */     }
/* 363 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadBeanDefinitionsFromImportedResources(Map<String, Class<? extends BeanDefinitionReader>> importedResources) {
/* 369 */     Map<Class<?>, BeanDefinitionReader> readerInstanceCache = new HashMap<>();
/*     */     
/* 371 */     importedResources.forEach((resource, readerClass) -> {
/*     */           Class<XmlBeanDefinitionReader> clazz;
/*     */           
/*     */           if (BeanDefinitionReader.class == readerClass) {
/*     */             if (StringUtils.endsWithIgnoreCase(resource, ".groovy")) {
/*     */               Class<GroovyBeanDefinitionReader> clazz1 = GroovyBeanDefinitionReader.class;
/*     */             } else {
/*     */               clazz = XmlBeanDefinitionReader.class;
/*     */             } 
/*     */           }
/*     */           
/*     */           BeanDefinitionReader reader = (BeanDefinitionReader)readerInstanceCache.get(clazz);
/*     */           
/*     */           if (reader == null) {
/*     */             try {
/*     */               Constructor<? extends BeanDefinitionReader> constructor = (Constructor)clazz.getDeclaredConstructor(new Class[] { BeanDefinitionRegistry.class });
/*     */               
/*     */               reader = (BeanDefinitionReader)BeanUtils.instantiateClass(constructor, new Object[] { this.registry });
/*     */               
/*     */               if (reader instanceof AbstractBeanDefinitionReader) {
/*     */                 AbstractBeanDefinitionReader abdr = (AbstractBeanDefinitionReader)reader;
/*     */                 
/*     */                 abdr.setResourceLoader(this.resourceLoader);
/*     */                 
/*     */                 abdr.setEnvironment(this.environment);
/*     */               } 
/*     */               readerInstanceCache.put(clazz, reader);
/* 398 */             } catch (Throwable ex) {
/*     */               throw new IllegalStateException("Could not instantiate BeanDefinitionReader class [" + clazz.getName() + "]", ex);
/*     */             } 
/*     */           }
/*     */           reader.loadBeanDefinitions(resource);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadBeanDefinitionsFromRegistrars(Map<ImportBeanDefinitionRegistrar, AnnotationMetadata> registrars) {
/* 408 */     registrars.forEach((registrar, metadata) -> registrar.registerBeanDefinitions(metadata, this.registry, this.importBeanNameGenerator));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConfigurationClassBeanDefinition
/*     */     extends RootBeanDefinition
/*     */     implements AnnotatedBeanDefinition
/*     */   {
/*     */     private final AnnotationMetadata annotationMetadata;
/*     */ 
/*     */ 
/*     */     
/*     */     private final MethodMetadata factoryMethodMetadata;
/*     */ 
/*     */ 
/*     */     
/*     */     private final String derivedBeanName;
/*     */ 
/*     */ 
/*     */     
/*     */     public ConfigurationClassBeanDefinition(ConfigurationClass configClass, MethodMetadata beanMethodMetadata, String derivedBeanName) {
/* 431 */       this.annotationMetadata = configClass.getMetadata();
/* 432 */       this.factoryMethodMetadata = beanMethodMetadata;
/* 433 */       this.derivedBeanName = derivedBeanName;
/* 434 */       setResource(configClass.getResource());
/* 435 */       setLenientConstructorResolution(false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ConfigurationClassBeanDefinition(RootBeanDefinition original, ConfigurationClass configClass, MethodMetadata beanMethodMetadata, String derivedBeanName) {
/* 441 */       super(original);
/* 442 */       this.annotationMetadata = configClass.getMetadata();
/* 443 */       this.factoryMethodMetadata = beanMethodMetadata;
/* 444 */       this.derivedBeanName = derivedBeanName;
/*     */     }
/*     */     
/*     */     private ConfigurationClassBeanDefinition(ConfigurationClassBeanDefinition original) {
/* 448 */       super(original);
/* 449 */       this.annotationMetadata = original.annotationMetadata;
/* 450 */       this.factoryMethodMetadata = original.factoryMethodMetadata;
/* 451 */       this.derivedBeanName = original.derivedBeanName;
/*     */     }
/*     */ 
/*     */     
/*     */     public AnnotationMetadata getMetadata() {
/* 456 */       return this.annotationMetadata;
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public MethodMetadata getFactoryMethodMetadata() {
/* 462 */       return this.factoryMethodMetadata;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFactoryMethod(Method candidate) {
/* 467 */       return (super.isFactoryMethod(candidate) && BeanAnnotationHelper.isBeanAnnotated(candidate) && 
/* 468 */         BeanAnnotationHelper.determineBeanNameFor(candidate).equals(this.derivedBeanName));
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigurationClassBeanDefinition cloneBeanDefinition() {
/* 473 */       return new ConfigurationClassBeanDefinition(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class TrackedConditionEvaluator
/*     */   {
/* 484 */     private final Map<ConfigurationClass, Boolean> skipped = new HashMap<>();
/*     */     
/*     */     public boolean shouldSkip(ConfigurationClass configClass) {
/* 487 */       Boolean skip = this.skipped.get(configClass);
/* 488 */       if (skip == null) {
/* 489 */         if (configClass.isImported()) {
/* 490 */           boolean allSkipped = true;
/* 491 */           for (ConfigurationClass importedBy : configClass.getImportedBy()) {
/* 492 */             if (!shouldSkip(importedBy)) {
/* 493 */               allSkipped = false;
/*     */               break;
/*     */             } 
/*     */           } 
/* 497 */           if (allSkipped)
/*     */           {
/* 499 */             skip = Boolean.valueOf(true);
/*     */           }
/*     */         } 
/* 502 */         if (skip == null) {
/* 503 */           skip = Boolean.valueOf(ConfigurationClassBeanDefinitionReader.this.conditionEvaluator.shouldSkip((AnnotatedTypeMetadata)configClass.getMetadata(), ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN));
/*     */         }
/* 505 */         this.skipped.put(configClass, skip);
/*     */       } 
/* 507 */       return skip.booleanValue();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConfigurationClassBeanDefinitionReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */