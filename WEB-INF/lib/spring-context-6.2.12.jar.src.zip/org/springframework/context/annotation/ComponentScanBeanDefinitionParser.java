/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.AspectJTypeFilter;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.core.type.filter.RegexPatternTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentScanBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String BASE_PACKAGE_ATTRIBUTE = "base-package";
/*     */   private static final String RESOURCE_PATTERN_ATTRIBUTE = "resource-pattern";
/*     */   private static final String USE_DEFAULT_FILTERS_ATTRIBUTE = "use-default-filters";
/*     */   private static final String ANNOTATION_CONFIG_ATTRIBUTE = "annotation-config";
/*     */   private static final String NAME_GENERATOR_ATTRIBUTE = "name-generator";
/*     */   private static final String SCOPE_RESOLVER_ATTRIBUTE = "scope-resolver";
/*     */   private static final String SCOPED_PROXY_ATTRIBUTE = "scoped-proxy";
/*     */   private static final String EXCLUDE_FILTER_ELEMENT = "exclude-filter";
/*     */   private static final String INCLUDE_FILTER_ELEMENT = "include-filter";
/*     */   private static final String FILTER_TYPE_ATTRIBUTE = "type";
/*     */   private static final String FILTER_EXPRESSION_ATTRIBUTE = "expression";
/*     */   
/*     */   @Nullable
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/*  84 */     String basePackage = element.getAttribute("base-package");
/*  85 */     basePackage = parserContext.getReaderContext().getEnvironment().resolvePlaceholders(basePackage);
/*  86 */     String[] basePackages = StringUtils.tokenizeToStringArray(basePackage, ",; \t\n");
/*     */ 
/*     */ 
/*     */     
/*  90 */     ClassPathBeanDefinitionScanner scanner = configureScanner(parserContext, element);
/*  91 */     Set<BeanDefinitionHolder> beanDefinitions = scanner.doScan(basePackages);
/*  92 */     registerComponents(parserContext.getReaderContext(), beanDefinitions, element);
/*     */     
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   protected ClassPathBeanDefinitionScanner configureScanner(ParserContext parserContext, Element element) {
/*  98 */     boolean useDefaultFilters = true;
/*  99 */     if (element.hasAttribute("use-default-filters")) {
/* 100 */       useDefaultFilters = Boolean.parseBoolean(element.getAttribute("use-default-filters"));
/*     */     }
/*     */ 
/*     */     
/* 104 */     ClassPathBeanDefinitionScanner scanner = createScanner(parserContext.getReaderContext(), useDefaultFilters);
/* 105 */     scanner.setBeanDefinitionDefaults(parserContext.getDelegate().getBeanDefinitionDefaults());
/* 106 */     scanner.setAutowireCandidatePatterns(parserContext.getDelegate().getAutowireCandidatePatterns());
/*     */     
/* 108 */     if (element.hasAttribute("resource-pattern")) {
/* 109 */       scanner.setResourcePattern(element.getAttribute("resource-pattern"));
/*     */     }
/*     */     
/*     */     try {
/* 113 */       parseBeanNameGenerator(element, scanner);
/*     */     }
/* 115 */     catch (Exception ex) {
/* 116 */       String message = ex.getMessage();
/* 117 */       Assert.state((message != null), "Exception message must not be null");
/* 118 */       parserContext.getReaderContext().error(message, parserContext.extractSource(element), ex.getCause());
/*     */     } 
/*     */     
/*     */     try {
/* 122 */       parseScope(element, scanner);
/*     */     }
/* 124 */     catch (Exception ex) {
/* 125 */       String message = ex.getMessage();
/* 126 */       Assert.state((message != null), "Exception message must not be null");
/* 127 */       parserContext.getReaderContext().error(message, parserContext.extractSource(element), ex.getCause());
/*     */     } 
/*     */     
/* 130 */     parseTypeFilters(element, scanner, parserContext);
/*     */     
/* 132 */     return scanner;
/*     */   }
/*     */   
/*     */   protected ClassPathBeanDefinitionScanner createScanner(XmlReaderContext readerContext, boolean useDefaultFilters) {
/* 136 */     return new ClassPathBeanDefinitionScanner(readerContext.getRegistry(), useDefaultFilters, readerContext
/* 137 */         .getEnvironment(), readerContext.getResourceLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerComponents(XmlReaderContext readerContext, Set<BeanDefinitionHolder> beanDefinitions, Element element) {
/* 143 */     Object source = readerContext.extractSource(element);
/* 144 */     CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), source);
/*     */     
/* 146 */     for (BeanDefinitionHolder beanDefHolder : beanDefinitions) {
/* 147 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition(beanDefHolder));
/*     */     }
/*     */ 
/*     */     
/* 151 */     boolean annotationConfig = true;
/* 152 */     if (element.hasAttribute("annotation-config")) {
/* 153 */       annotationConfig = Boolean.parseBoolean(element.getAttribute("annotation-config"));
/*     */     }
/* 155 */     if (annotationConfig) {
/*     */       
/* 157 */       Set<BeanDefinitionHolder> processorDefinitions = AnnotationConfigUtils.registerAnnotationConfigProcessors(readerContext.getRegistry(), source);
/* 158 */       for (BeanDefinitionHolder processorDefinition : processorDefinitions) {
/* 159 */         compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition(processorDefinition));
/*     */       }
/*     */     } 
/*     */     
/* 163 */     readerContext.fireComponentRegistered((ComponentDefinition)compositeDef);
/*     */   }
/*     */   
/*     */   protected void parseBeanNameGenerator(Element element, ClassPathBeanDefinitionScanner scanner) {
/* 167 */     if (element.hasAttribute("name-generator")) {
/* 168 */       BeanNameGenerator beanNameGenerator = (BeanNameGenerator)instantiateUserDefinedStrategy(element
/* 169 */           .getAttribute("name-generator"), BeanNameGenerator.class, scanner
/* 170 */           .getResourceLoader().getClassLoader());
/* 171 */       scanner.setBeanNameGenerator(beanNameGenerator);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parseScope(Element element, ClassPathBeanDefinitionScanner scanner) {
/* 177 */     if (element.hasAttribute("scope-resolver")) {
/* 178 */       if (element.hasAttribute("scoped-proxy")) {
/* 179 */         throw new IllegalArgumentException("Cannot define both 'scope-resolver' and 'scoped-proxy' on <component-scan> tag");
/*     */       }
/*     */       
/* 182 */       ScopeMetadataResolver scopeMetadataResolver = (ScopeMetadataResolver)instantiateUserDefinedStrategy(element
/* 183 */           .getAttribute("scope-resolver"), ScopeMetadataResolver.class, scanner
/* 184 */           .getResourceLoader().getClassLoader());
/* 185 */       scanner.setScopeMetadataResolver(scopeMetadataResolver);
/*     */     } 
/*     */     
/* 188 */     if (element.hasAttribute("scoped-proxy")) {
/* 189 */       String mode = element.getAttribute("scoped-proxy");
/* 190 */       switch (mode) { case "targetClass":
/* 191 */           scanner.setScopedProxyMode(ScopedProxyMode.TARGET_CLASS); return;
/* 192 */         case "interfaces": scanner.setScopedProxyMode(ScopedProxyMode.INTERFACES); return;
/* 193 */         case "no": scanner.setScopedProxyMode(ScopedProxyMode.NO); return; }
/* 194 */        throw new IllegalArgumentException("scoped-proxy only supports 'no', 'interfaces' and 'targetClass'");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseTypeFilters(Element element, ClassPathBeanDefinitionScanner scanner, ParserContext parserContext) {
/* 201 */     ClassLoader classLoader = scanner.getResourceLoader().getClassLoader();
/* 202 */     NodeList nodeList = element.getChildNodes();
/* 203 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 204 */       Node node = nodeList.item(i);
/* 205 */       if (node.getNodeType() == 1) {
/* 206 */         String localName = parserContext.getDelegate().getLocalName(node);
/*     */         try {
/* 208 */           if ("include-filter".equals(localName)) {
/* 209 */             TypeFilter typeFilter = createTypeFilter((Element)node, classLoader, parserContext);
/* 210 */             scanner.addIncludeFilter(typeFilter);
/*     */           }
/* 212 */           else if ("exclude-filter".equals(localName)) {
/* 213 */             TypeFilter typeFilter = createTypeFilter((Element)node, classLoader, parserContext);
/* 214 */             scanner.addExcludeFilter(typeFilter);
/*     */           }
/*     */         
/* 217 */         } catch (ClassNotFoundException ex) {
/* 218 */           parserContext.getReaderContext().warning("Ignoring non-present type filter class: " + String.valueOf(ex), parserContext
/* 219 */               .extractSource(element));
/*     */         }
/* 221 */         catch (Exception ex) {
/* 222 */           String message = ex.getMessage();
/* 223 */           Assert.state((message != null), "Exception message must not be null");
/* 224 */           parserContext.getReaderContext().error(message, parserContext
/* 225 */               .extractSource(element), ex.getCause());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeFilter createTypeFilter(Element element, @Nullable ClassLoader classLoader, ParserContext parserContext) throws ClassNotFoundException {
/*     */     Class<?> filterClass;
/* 235 */     String filterType = element.getAttribute("type");
/* 236 */     String expression = element.getAttribute("expression");
/* 237 */     expression = parserContext.getReaderContext().getEnvironment().resolvePlaceholders(expression);
/* 238 */     switch (filterType) {
/*     */       case "annotation":
/* 240 */         return (TypeFilter)new AnnotationTypeFilter(ClassUtils.forName(expression, classLoader));
/*     */       
/*     */       case "assignable":
/* 243 */         return (TypeFilter)new AssignableTypeFilter(ClassUtils.forName(expression, classLoader));
/*     */       
/*     */       case "aspectj":
/* 246 */         return (TypeFilter)new AspectJTypeFilter(expression, classLoader);
/*     */       
/*     */       case "regex":
/* 249 */         return (TypeFilter)new RegexPatternTypeFilter(Pattern.compile(expression));
/*     */       
/*     */       case "custom":
/* 252 */         filterClass = ClassUtils.forName(expression, classLoader);
/* 253 */         if (!TypeFilter.class.isAssignableFrom(filterClass)) {
/* 254 */           throw new IllegalArgumentException("Class is not assignable to [" + TypeFilter.class
/* 255 */               .getName() + "]: " + expression);
/*     */         }
/* 257 */         return (TypeFilter)BeanUtils.instantiateClass(filterClass);
/*     */     } 
/* 259 */     throw new IllegalArgumentException("Unsupported filter type: " + filterType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object instantiateUserDefinedStrategy(String className, Class<?> strategyType, @Nullable ClassLoader classLoader) {
/*     */     Object result;
/*     */     try {
/* 269 */       result = ReflectionUtils.accessibleConstructor(ClassUtils.forName(className, classLoader), new Class[0]).newInstance(new Object[0]);
/*     */     }
/* 271 */     catch (ClassNotFoundException ex) {
/* 272 */       throw new IllegalArgumentException("Class [" + className + "] for strategy [" + strategyType
/* 273 */           .getName() + "] not found", ex);
/*     */     }
/* 275 */     catch (Throwable ex) {
/* 276 */       throw new IllegalArgumentException("Unable to instantiate class [" + className + "] for strategy [" + strategyType
/* 277 */           .getName() + "]: a zero-argument constructor is required", ex);
/*     */     } 
/*     */     
/* 280 */     if (!strategyType.isAssignableFrom(result.getClass())) {
/* 281 */       throw new IllegalArgumentException("Provided class name must be an implementation of " + String.valueOf(strategyType));
/*     */     }
/* 283 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ComponentScanBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */