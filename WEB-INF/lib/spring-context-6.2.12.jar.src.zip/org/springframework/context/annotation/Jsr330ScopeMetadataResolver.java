/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jsr330ScopeMetadataResolver
/*     */   implements ScopeMetadataResolver
/*     */ {
/*  45 */   private final Map<String, String> scopeMap = new HashMap<>();
/*     */ 
/*     */   
/*     */   public Jsr330ScopeMetadataResolver() {
/*  49 */     registerScope("jakarta.inject.Singleton", "singleton");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void registerScope(Class<?> annotationType, String scopeName) {
/*  60 */     this.scopeMap.put(annotationType.getName(), scopeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void registerScope(String annotationType, String scopeName) {
/*  70 */     this.scopeMap.put(annotationType, scopeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveScopeName(String annotationType) {
/*  82 */     return this.scopeMap.get(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScopeMetadata resolveScopeMetadata(BeanDefinition definition) {
/*  88 */     ScopeMetadata metadata = new ScopeMetadata();
/*  89 */     metadata.setScopeName("prototype");
/*  90 */     if (definition instanceof AnnotatedBeanDefinition) { AnnotatedBeanDefinition annDef = (AnnotatedBeanDefinition)definition;
/*  91 */       Set<String> annTypes = annDef.getMetadata().getAnnotationTypes();
/*  92 */       String found = null;
/*  93 */       for (String annType : annTypes) {
/*  94 */         Set<String> metaAnns = annDef.getMetadata().getMetaAnnotationTypes(annType);
/*  95 */         if (metaAnns.contains("jakarta.inject.Scope")) {
/*  96 */           if (found != null) {
/*  97 */             throw new IllegalStateException("Found ambiguous scope annotations on bean class [" + definition
/*  98 */                 .getBeanClassName() + "]: " + found + ", " + annType);
/*     */           }
/* 100 */           found = annType;
/* 101 */           String scopeName = resolveScopeName(annType);
/* 102 */           if (scopeName == null) {
/* 103 */             throw new IllegalStateException("Unsupported scope annotation - not mapped onto Spring scope name: " + annType);
/*     */           }
/*     */           
/* 106 */           metadata.setScopeName(scopeName);
/*     */         } 
/*     */       }  }
/*     */     
/* 110 */     return metadata;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\Jsr330ScopeMetadataResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */