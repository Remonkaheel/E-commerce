/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionDefaults;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassPathBeanDefinitionScanner
/*     */   extends ClassPathScanningCandidateComponentProvider
/*     */ {
/*     */   private final BeanDefinitionRegistry registry;
/*  68 */   private BeanDefinitionDefaults beanDefinitionDefaults = new BeanDefinitionDefaults();
/*     */   
/*     */   @Nullable
/*     */   private String[] autowireCandidatePatterns;
/*     */   
/*  73 */   private BeanNameGenerator beanNameGenerator = AnnotationBeanNameGenerator.INSTANCE;
/*     */   
/*  75 */   private ScopeMetadataResolver scopeMetadataResolver = new AnnotationScopeMetadataResolver();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean includeAnnotationConfig = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassPathBeanDefinitionScanner(BeanDefinitionRegistry registry) {
/*  86 */     this(registry, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassPathBeanDefinitionScanner(BeanDefinitionRegistry registry, boolean useDefaultFilters) {
/* 114 */     this(registry, useDefaultFilters, getOrCreateEnvironment(registry));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassPathBeanDefinitionScanner(BeanDefinitionRegistry registry, boolean useDefaultFilters, Environment environment) {
/* 141 */     this(registry, useDefaultFilters, environment, 
/* 142 */         (registry instanceof ResourceLoader) ? resourceLoader : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassPathBeanDefinitionScanner(BeanDefinitionRegistry registry, boolean useDefaultFilters, Environment environment, @Nullable ResourceLoader resourceLoader) {
/* 163 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 164 */     this.registry = registry;
/*     */     
/* 166 */     if (useDefaultFilters) {
/* 167 */       registerDefaultFilters();
/*     */     }
/* 169 */     setEnvironment(environment);
/* 170 */     setResourceLoader(resourceLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BeanDefinitionRegistry getRegistry() {
/* 179 */     return this.registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanDefinitionDefaults(@Nullable BeanDefinitionDefaults beanDefinitionDefaults) {
/* 187 */     this
/* 188 */       .beanDefinitionDefaults = (beanDefinitionDefaults != null) ? beanDefinitionDefaults : new BeanDefinitionDefaults();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionDefaults getBeanDefinitionDefaults() {
/* 196 */     return this.beanDefinitionDefaults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutowireCandidatePatterns(@Nullable String... autowireCandidatePatterns) {
/* 204 */     this.autowireCandidatePatterns = autowireCandidatePatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanNameGenerator(@Nullable BeanNameGenerator beanNameGenerator) {
/* 212 */     this
/* 213 */       .beanNameGenerator = (beanNameGenerator != null) ? beanNameGenerator : AnnotationBeanNameGenerator.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScopeMetadataResolver(@Nullable ScopeMetadataResolver scopeMetadataResolver) {
/* 223 */     this
/* 224 */       .scopeMetadataResolver = (scopeMetadataResolver != null) ? scopeMetadataResolver : new AnnotationScopeMetadataResolver();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScopedProxyMode(ScopedProxyMode scopedProxyMode) {
/* 234 */     this.scopeMetadataResolver = new AnnotationScopeMetadataResolver(scopedProxyMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncludeAnnotationConfig(boolean includeAnnotationConfig) {
/* 243 */     this.includeAnnotationConfig = includeAnnotationConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int scan(String... basePackages) {
/* 253 */     int beanCountAtScanStart = this.registry.getBeanDefinitionCount();
/*     */     
/* 255 */     doScan(basePackages);
/*     */ 
/*     */     
/* 258 */     if (this.includeAnnotationConfig) {
/* 259 */       AnnotationConfigUtils.registerAnnotationConfigProcessors(this.registry);
/*     */     }
/*     */     
/* 262 */     return this.registry.getBeanDefinitionCount() - beanCountAtScanStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<BeanDefinitionHolder> doScan(String... basePackages) {
/* 274 */     Assert.notEmpty((Object[])basePackages, "At least one base package must be specified");
/* 275 */     Set<BeanDefinitionHolder> beanDefinitions = new LinkedHashSet<>();
/* 276 */     for (String basePackage : basePackages) {
/* 277 */       Set<BeanDefinition> candidates = findCandidateComponents(basePackage);
/* 278 */       for (BeanDefinition candidate : candidates) {
/* 279 */         ScopeMetadata scopeMetadata = this.scopeMetadataResolver.resolveScopeMetadata(candidate);
/* 280 */         candidate.setScope(scopeMetadata.getScopeName());
/* 281 */         String beanName = this.beanNameGenerator.generateBeanName(candidate, this.registry);
/* 282 */         if (candidate instanceof AbstractBeanDefinition) { AbstractBeanDefinition abstractBeanDefinition = (AbstractBeanDefinition)candidate;
/* 283 */           postProcessBeanDefinition(abstractBeanDefinition, beanName); }
/*     */         
/* 285 */         if (candidate instanceof AnnotatedBeanDefinition) { AnnotatedBeanDefinition annotatedBeanDefinition = (AnnotatedBeanDefinition)candidate;
/* 286 */           AnnotationConfigUtils.processCommonDefinitionAnnotations(annotatedBeanDefinition); }
/*     */         
/* 288 */         if (checkCandidate(beanName, candidate)) {
/* 289 */           BeanDefinitionHolder definitionHolder = new BeanDefinitionHolder(candidate, beanName);
/*     */           
/* 291 */           definitionHolder = AnnotationConfigUtils.applyScopedProxyMode(scopeMetadata, definitionHolder, this.registry);
/* 292 */           beanDefinitions.add(definitionHolder);
/* 293 */           registerBeanDefinition(definitionHolder, this.registry);
/*     */         } 
/*     */       } 
/*     */     } 
/* 297 */     return beanDefinitions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessBeanDefinition(AbstractBeanDefinition beanDefinition, String beanName) {
/* 307 */     beanDefinition.applyDefaults(this.beanDefinitionDefaults);
/* 308 */     if (this.autowireCandidatePatterns != null) {
/* 309 */       beanDefinition.setAutowireCandidate(PatternMatchUtils.simpleMatch(this.autowireCandidatePatterns, beanName));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerBeanDefinition(BeanDefinitionHolder definitionHolder, BeanDefinitionRegistry registry) {
/* 321 */     BeanDefinitionReaderUtils.registerBeanDefinition(definitionHolder, registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkCandidate(String beanName, BeanDefinition beanDefinition) throws IllegalStateException {
/* 337 */     if (!this.registry.containsBeanDefinition(beanName)) {
/* 338 */       return true;
/*     */     }
/*     */     
/* 341 */     BeanDefinition existingDef = this.registry.getBeanDefinition(beanName);
/* 342 */     BeanDefinition originatingDef = existingDef.getOriginatingBeanDefinition();
/* 343 */     if (originatingDef != null) {
/* 344 */       existingDef = originatingDef;
/*     */     }
/*     */ 
/*     */     
/* 348 */     if (!(existingDef instanceof ScannedGenericBeanDefinition) && (this.registry
/* 349 */       .isBeanDefinitionOverridable(beanName) || ObjectUtils.nullSafeEquals(beanDefinition
/* 350 */         .getBeanClassName(), existingDef.getBeanClassName()))) {
/* 351 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 355 */     if (isCompatible(beanDefinition, existingDef)) {
/* 356 */       return false;
/*     */     }
/*     */     
/* 359 */     throw new ConflictingBeanDefinitionException("Annotation-specified bean name '" + beanName + "' for bean class [" + beanDefinition
/* 360 */         .getBeanClassName() + "] conflicts with existing, non-compatible bean definition of same name and class [" + existingDef
/* 361 */         .getBeanClassName() + "]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isCompatible(BeanDefinition newDef, BeanDefinition existingDef) {
/* 376 */     return ((newDef.getSource() != null && newDef.getSource().equals(existingDef.getSource())) || newDef
/* 377 */       .equals(existingDef));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Environment getOrCreateEnvironment(BeanDefinitionRegistry registry) {
/* 386 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 387 */     if (registry instanceof EnvironmentCapable) { EnvironmentCapable environmentCapable = (EnvironmentCapable)registry;
/* 388 */       return environmentCapable.getEnvironment(); }
/*     */     
/* 390 */     return (Environment)new StandardEnvironment();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ClassPathBeanDefinitionScanner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */