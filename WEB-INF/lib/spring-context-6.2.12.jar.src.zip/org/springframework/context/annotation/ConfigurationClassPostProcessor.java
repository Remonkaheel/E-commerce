/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.framework.autoproxy.AutoProxyUtils;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.ResourceHints;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotProcessor;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragments;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragmentsDecorator;
/*     */ import org.springframework.beans.factory.aot.InstanceSupplierCodeGenerator;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.SingletonBeanRegistry;
/*     */ import org.springframework.beans.factory.parsing.FailFastProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.PassThroughSourceExtractor;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.ApplicationStartupAware;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PropertySourceDescriptor;
/*     */ import org.springframework.core.io.support.PropertySourceProcessor;
/*     */ import org.springframework.core.metrics.ApplicationStartup;
/*     */ import org.springframework.core.metrics.StartupStep;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.ParameterizedTypeName;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationClassPostProcessor
/*     */   implements BeanDefinitionRegistryPostProcessor, BeanRegistrationAotProcessor, BeanFactoryInitializationAotProcessor, PriorityOrdered, ResourceLoaderAware, ApplicationStartupAware, BeanClassLoaderAware, EnvironmentAware
/*     */ {
/* 143 */   public static final AnnotationBeanNameGenerator IMPORT_BEAN_NAME_GENERATOR = FullyQualifiedAnnotationBeanNameGenerator.INSTANCE;
/*     */ 
/*     */   
/* 146 */   private static final String IMPORT_REGISTRY_BEAN_NAME = ConfigurationClassPostProcessor.class
/* 147 */     .getName() + ".importRegistry";
/*     */ 
/*     */   
/* 150 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/* 152 */   private SourceExtractor sourceExtractor = (SourceExtractor)new PassThroughSourceExtractor();
/*     */   
/* 154 */   private ProblemReporter problemReporter = (ProblemReporter)new FailFastProblemReporter();
/*     */   
/*     */   @Nullable
/*     */   private Environment environment;
/*     */   
/* 159 */   private ResourceLoader resourceLoader = (ResourceLoader)new DefaultResourceLoader();
/*     */   
/*     */   @Nullable
/* 162 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   
/* 164 */   private MetadataReaderFactory metadataReaderFactory = (MetadataReaderFactory)new CachingMetadataReaderFactory();
/*     */   
/*     */   private boolean setMetadataReaderFactoryCalled = false;
/*     */   
/* 168 */   private final Set<Integer> registriesPostProcessed = new HashSet<>();
/*     */   
/* 170 */   private final Set<Integer> factoriesPostProcessed = new HashSet<>();
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ConfigurationClassBeanDefinitionReader reader;
/*     */   
/*     */   private boolean localBeanNameGeneratorSet = false;
/*     */   
/* 178 */   private BeanNameGenerator componentScanBeanNameGenerator = AnnotationBeanNameGenerator.INSTANCE;
/*     */ 
/*     */   
/* 181 */   private BeanNameGenerator importBeanNameGenerator = IMPORT_BEAN_NAME_GENERATOR;
/*     */   
/* 183 */   private ApplicationStartup applicationStartup = ApplicationStartup.DEFAULT;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private List<PropertySourceDescriptor> propertySourceDescriptors;
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 191 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceExtractor(@Nullable SourceExtractor sourceExtractor) {
/* 199 */     this.sourceExtractor = (sourceExtractor != null) ? sourceExtractor : (SourceExtractor)new PassThroughSourceExtractor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProblemReporter(@Nullable ProblemReporter problemReporter) {
/* 209 */     this.problemReporter = (problemReporter != null) ? problemReporter : (ProblemReporter)new FailFastProblemReporter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMetadataReaderFactory(MetadataReaderFactory metadataReaderFactory) {
/* 218 */     Assert.notNull(metadataReaderFactory, "MetadataReaderFactory must not be null");
/* 219 */     this.metadataReaderFactory = metadataReaderFactory;
/* 220 */     this.setMetadataReaderFactoryCalled = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator) {
/* 240 */     Assert.notNull(beanNameGenerator, "BeanNameGenerator must not be null");
/* 241 */     this.localBeanNameGeneratorSet = true;
/* 242 */     this.componentScanBeanNameGenerator = beanNameGenerator;
/* 243 */     this.importBeanNameGenerator = beanNameGenerator;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/* 248 */     Assert.notNull(environment, "Environment must not be null");
/* 249 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 254 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 255 */     this.resourceLoader = resourceLoader;
/* 256 */     if (!this.setMetadataReaderFactoryCalled) {
/* 257 */       this.metadataReaderFactory = (MetadataReaderFactory)new CachingMetadataReaderFactory(resourceLoader);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader) {
/* 263 */     this.beanClassLoader = beanClassLoader;
/* 264 */     if (!this.setMetadataReaderFactoryCalled) {
/* 265 */       this.metadataReaderFactory = (MetadataReaderFactory)new CachingMetadataReaderFactory(beanClassLoader);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationStartup(ApplicationStartup applicationStartup) {
/* 271 */     this.applicationStartup = applicationStartup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) {
/* 279 */     int registryId = System.identityHashCode(registry);
/* 280 */     if (this.registriesPostProcessed.contains(Integer.valueOf(registryId))) {
/* 281 */       throw new IllegalStateException("postProcessBeanDefinitionRegistry already called on this post-processor against " + String.valueOf(registry));
/*     */     }
/*     */     
/* 284 */     if (this.factoriesPostProcessed.contains(Integer.valueOf(registryId))) {
/* 285 */       throw new IllegalStateException("postProcessBeanFactory already called on this post-processor against " + String.valueOf(registry));
/*     */     }
/*     */     
/* 288 */     this.registriesPostProcessed.add(Integer.valueOf(registryId));
/*     */     
/* 290 */     processConfigBeanDefinitions(registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/* 299 */     int factoryId = System.identityHashCode(beanFactory);
/* 300 */     if (this.factoriesPostProcessed.contains(Integer.valueOf(factoryId))) {
/* 301 */       throw new IllegalStateException("postProcessBeanFactory already called on this post-processor against " + String.valueOf(beanFactory));
/*     */     }
/*     */     
/* 304 */     this.factoriesPostProcessed.add(Integer.valueOf(factoryId));
/* 305 */     if (!this.registriesPostProcessed.contains(Integer.valueOf(factoryId)))
/*     */     {
/*     */       
/* 308 */       processConfigBeanDefinitions((BeanDefinitionRegistry)beanFactory);
/*     */     }
/*     */     
/* 311 */     enhanceConfigurationClasses(beanFactory);
/* 312 */     beanFactory.addBeanPostProcessor((BeanPostProcessor)new ImportAwareBeanPostProcessor((BeanFactory)beanFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/* 319 */     Object configClassAttr = registeredBean.getMergedBeanDefinition().getAttribute(ConfigurationClassUtils.CONFIGURATION_CLASS_ATTRIBUTE);
/* 320 */     if ("full".equals(configClassAttr)) {
/* 321 */       return BeanRegistrationAotContribution.withCustomCodeFragments(codeFragments -> new ConfigurationClassProxyBeanRegistrationCodeFragments(codeFragments, registeredBean));
/*     */     }
/*     */     
/* 324 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanFactoryInitializationAotContribution processAheadOfTime(ConfigurableListableBeanFactory beanFactory) {
/* 331 */     boolean hasPropertySourceDescriptors = !CollectionUtils.isEmpty(this.propertySourceDescriptors);
/* 332 */     boolean hasImportRegistry = beanFactory.containsBean(IMPORT_REGISTRY_BEAN_NAME);
/* 333 */     if (hasPropertySourceDescriptors || hasImportRegistry) {
/* 334 */       return (generationContext, code) -> {
/*     */           if (hasPropertySourceDescriptors) {
/*     */             (new PropertySourcesAotContribution(this.propertySourceDescriptors, this::resolvePropertySourceLocation)).applyTo(generationContext, code);
/*     */           }
/*     */           
/*     */           if (hasImportRegistry) {
/*     */             (new ImportAwareAotContribution(beanFactory)).applyTo(generationContext, code);
/*     */           }
/*     */         };
/*     */     }
/* 344 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Resource resolvePropertySourceLocation(String location) {
/*     */     try {
/* 351 */       String resolvedLocation = (this.environment != null) ? this.environment.resolveRequiredPlaceholders(location) : location;
/* 352 */       return this.resourceLoader.getResource(resolvedLocation);
/*     */     }
/* 354 */     catch (Exception ex) {
/* 355 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processConfigBeanDefinitions(BeanDefinitionRegistry registry) {
/* 364 */     List<BeanDefinitionHolder> configCandidates = new ArrayList<>();
/* 365 */     String[] candidateNames = registry.getBeanDefinitionNames();
/*     */     
/* 367 */     for (String beanName : candidateNames) {
/* 368 */       BeanDefinition beanDef = registry.getBeanDefinition(beanName);
/* 369 */       if (beanDef.getAttribute(ConfigurationClassUtils.CONFIGURATION_CLASS_ATTRIBUTE) != null) {
/* 370 */         if (this.logger.isDebugEnabled()) {
/* 371 */           this.logger.debug("Bean definition has already been processed as a configuration class: " + String.valueOf(beanDef));
/*     */         }
/*     */       }
/* 374 */       else if (ConfigurationClassUtils.checkConfigurationClassCandidate(beanDef, this.metadataReaderFactory)) {
/* 375 */         configCandidates.add(new BeanDefinitionHolder(beanDef, beanName));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 380 */     if (configCandidates.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 385 */     configCandidates.sort((bd1, bd2) -> {
/*     */           int i1 = ConfigurationClassUtils.getOrder(bd1.getBeanDefinition());
/*     */           
/*     */           int i2 = ConfigurationClassUtils.getOrder(bd2.getBeanDefinition());
/*     */           
/*     */           return Integer.compare(i1, i2);
/*     */         });
/* 392 */     SingletonBeanRegistry singletonRegistry = null;
/* 393 */     if (registry instanceof SingletonBeanRegistry) { SingletonBeanRegistry sbr = (SingletonBeanRegistry)registry;
/* 394 */       singletonRegistry = sbr;
/* 395 */       if (!this.localBeanNameGeneratorSet) {
/* 396 */         BeanNameGenerator generator = (BeanNameGenerator)singletonRegistry.getSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator");
/*     */         
/* 398 */         if (generator != null) {
/* 399 */           this.componentScanBeanNameGenerator = generator;
/* 400 */           this.importBeanNameGenerator = generator;
/*     */         } 
/*     */       }  }
/*     */ 
/*     */     
/* 405 */     if (this.environment == null) {
/* 406 */       this.environment = (Environment)new StandardEnvironment();
/*     */     }
/*     */ 
/*     */     
/* 410 */     ConfigurationClassParser parser = new ConfigurationClassParser(this.metadataReaderFactory, this.problemReporter, this.environment, this.resourceLoader, this.componentScanBeanNameGenerator, registry);
/*     */ 
/*     */ 
/*     */     
/* 414 */     Set<BeanDefinitionHolder> candidates = new LinkedHashSet<>(configCandidates);
/* 415 */     Set<ConfigurationClass> alreadyParsed = CollectionUtils.newHashSet(configCandidates.size());
/*     */     do {
/* 417 */       StartupStep processConfig = this.applicationStartup.start("spring.context.config-classes.parse");
/* 418 */       parser.parse(candidates);
/* 419 */       parser.validate();
/*     */       
/* 421 */       Set<ConfigurationClass> configClasses = new LinkedHashSet<>(parser.getConfigurationClasses());
/* 422 */       configClasses.removeAll(alreadyParsed);
/*     */ 
/*     */       
/* 425 */       if (this.reader == null) {
/* 426 */         this
/*     */           
/* 428 */           .reader = new ConfigurationClassBeanDefinitionReader(registry, this.sourceExtractor, this.resourceLoader, this.environment, this.importBeanNameGenerator, parser.getImportRegistry());
/*     */       }
/* 430 */       this.reader.loadBeanDefinitions(configClasses);
/* 431 */       alreadyParsed.addAll(configClasses);
/* 432 */       processConfig.tag("classCount", () -> String.valueOf(configClasses.size())).end();
/*     */       
/* 434 */       candidates.clear();
/* 435 */       if (registry.getBeanDefinitionCount() <= candidateNames.length)
/* 436 */         continue;  String[] newCandidateNames = registry.getBeanDefinitionNames();
/* 437 */       Set<String> oldCandidateNames = Set.of(candidateNames);
/* 438 */       Set<String> alreadyParsedClasses = CollectionUtils.newHashSet(alreadyParsed.size());
/* 439 */       for (ConfigurationClass configurationClass : alreadyParsed) {
/* 440 */         alreadyParsedClasses.add(configurationClass.getMetadata().getClassName());
/*     */       }
/* 442 */       for (String candidateName : newCandidateNames) {
/* 443 */         if (!oldCandidateNames.contains(candidateName)) {
/* 444 */           BeanDefinition bd = registry.getBeanDefinition(candidateName);
/* 445 */           if (ConfigurationClassUtils.checkConfigurationClassCandidate(bd, this.metadataReaderFactory) && 
/* 446 */             !alreadyParsedClasses.contains(bd.getBeanClassName())) {
/* 447 */             candidates.add(new BeanDefinitionHolder(bd, candidateName));
/*     */           }
/*     */         } 
/*     */       } 
/* 451 */       candidateNames = newCandidateNames;
/*     */     
/*     */     }
/* 454 */     while (!candidates.isEmpty());
/*     */ 
/*     */     
/* 457 */     if (singletonRegistry != null && !singletonRegistry.containsSingleton(IMPORT_REGISTRY_BEAN_NAME)) {
/* 458 */       singletonRegistry.registerSingleton(IMPORT_REGISTRY_BEAN_NAME, parser.getImportRegistry());
/*     */     }
/*     */ 
/*     */     
/* 462 */     this.propertySourceDescriptors = parser.getPropertySourceDescriptors();
/*     */     
/* 464 */     MetadataReaderFactory metadataReaderFactory = this.metadataReaderFactory; if (metadataReaderFactory instanceof CachingMetadataReaderFactory) { CachingMetadataReaderFactory cachingMetadataReaderFactory = (CachingMetadataReaderFactory)metadataReaderFactory;
/*     */ 
/*     */       
/* 467 */       cachingMetadataReaderFactory.clearCache(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enhanceConfigurationClasses(ConfigurableListableBeanFactory beanFactory) {
/* 478 */     StartupStep enhanceConfigClasses = this.applicationStartup.start("spring.context.config-classes.enhance");
/* 479 */     Map<String, AbstractBeanDefinition> configBeanDefs = new LinkedHashMap<>();
/* 480 */     for (String beanName : beanFactory.getBeanDefinitionNames()) {
/* 481 */       BeanDefinition beanDef = beanFactory.getBeanDefinition(beanName);
/* 482 */       Object configClassAttr = beanDef.getAttribute(ConfigurationClassUtils.CONFIGURATION_CLASS_ATTRIBUTE);
/* 483 */       AnnotationMetadata annotationMetadata = null;
/* 484 */       MethodMetadata methodMetadata = null;
/* 485 */       if (beanDef instanceof AnnotatedBeanDefinition) { AnnotatedBeanDefinition annotatedBeanDefinition = (AnnotatedBeanDefinition)beanDef;
/* 486 */         annotationMetadata = annotatedBeanDefinition.getMetadata();
/* 487 */         methodMetadata = annotatedBeanDefinition.getFactoryMethodMetadata(); }
/*     */       
/* 489 */       if ((configClassAttr != null || methodMetadata != null) && beanDef instanceof AbstractBeanDefinition) {
/* 490 */         AbstractBeanDefinition abd = (AbstractBeanDefinition)beanDef; if (!abd.hasBeanClass()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 496 */           boolean liteConfigurationCandidateWithoutBeanMethods = ("lite".equals(configClassAttr) && annotationMetadata != null && !ConfigurationClassUtils.hasBeanMethods(annotationMetadata));
/* 497 */           if (!liteConfigurationCandidateWithoutBeanMethods)
/*     */             try {
/* 499 */               abd.resolveBeanClass(this.beanClassLoader);
/*     */             }
/* 501 */             catch (Throwable ex) {
/* 502 */               throw new IllegalStateException("Cannot load configuration class: " + beanDef
/* 503 */                   .getBeanClassName(), ex);
/*     */             }  
/*     */         } 
/*     */       } 
/* 507 */       if ("full".equals(configClassAttr)) {
/* 508 */         AbstractBeanDefinition abd; if (beanDef instanceof AbstractBeanDefinition) { abd = (AbstractBeanDefinition)beanDef; }
/* 509 */         else { throw new BeanDefinitionStoreException("Cannot enhance @Configuration bean definition '" + beanName + "' since it is not stored in an AbstractBeanDefinition subclass"); }
/*     */ 
/*     */         
/* 512 */         if (beanFactory.containsSingleton(beanName)) {
/* 513 */           if (this.logger.isWarnEnabled()) {
/* 514 */             this.logger.warn("Cannot enhance @Configuration bean definition '" + beanName + "' since its singleton instance has been created too early. The typical cause is a non-static @Bean method with a BeanDefinitionRegistryPostProcessor return type: Consider declaring such methods as 'static' and/or marking the containing configuration class as 'proxyBeanMethods=false'.");
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 522 */           configBeanDefs.put(beanName, abd);
/*     */         } 
/*     */       } 
/*     */     } 
/* 526 */     if (configBeanDefs.isEmpty()) {
/*     */       
/* 528 */       enhanceConfigClasses.end();
/*     */       
/*     */       return;
/*     */     } 
/* 532 */     ConfigurationClassEnhancer enhancer = new ConfigurationClassEnhancer();
/* 533 */     for (Map.Entry<String, AbstractBeanDefinition> entry : configBeanDefs.entrySet()) {
/* 534 */       AbstractBeanDefinition beanDef = entry.getValue();
/*     */       
/* 536 */       beanDef.setAttribute(AutoProxyUtils.PRESERVE_TARGET_CLASS_ATTRIBUTE, Boolean.TRUE);
/*     */       
/* 538 */       Class<?> configClass = beanDef.getBeanClass();
/* 539 */       Class<?> enhancedClass = enhancer.enhance(configClass, this.beanClassLoader);
/* 540 */       if (configClass != enhancedClass) {
/* 541 */         if (this.logger.isTraceEnabled()) {
/* 542 */           this.logger.trace(String.format("Replacing bean definition '%s' existing class '%s' with enhanced class '%s'", new Object[] { entry
/* 543 */                   .getKey(), configClass.getName(), enhancedClass.getName() }));
/*     */         }
/* 545 */         beanDef.setBeanClass(enhancedClass);
/*     */       } 
/*     */     } 
/* 548 */     enhanceConfigClasses.tag("classCount", () -> String.valueOf(configBeanDefs.keySet().size())).end();
/*     */   }
/*     */   
/*     */   private static class ImportAwareBeanPostProcessor
/*     */     implements InstantiationAwareBeanPostProcessor
/*     */   {
/*     */     private final BeanFactory beanFactory;
/*     */     
/*     */     public ImportAwareBeanPostProcessor(BeanFactory beanFactory) {
/* 557 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public PropertyValues postProcessProperties(@Nullable PropertyValues pvs, Object bean, String beanName) {
/* 565 */       if (bean instanceof ConfigurationClassEnhancer.EnhancedConfiguration) { ConfigurationClassEnhancer.EnhancedConfiguration enhancedConfiguration = (ConfigurationClassEnhancer.EnhancedConfiguration)bean;
/* 566 */         enhancedConfiguration.setBeanFactory(this.beanFactory); }
/*     */       
/* 568 */       return pvs;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName) {
/* 573 */       if (bean instanceof ImportAware) { ImportAware importAware = (ImportAware)bean;
/* 574 */         ImportRegistry ir = (ImportRegistry)this.beanFactory.getBean(ConfigurationClassPostProcessor.IMPORT_REGISTRY_BEAN_NAME, ImportRegistry.class);
/* 575 */         AnnotationMetadata importingClass = ir.getImportingClassFor(ClassUtils.getUserClass(bean).getName());
/* 576 */         if (importingClass != null) {
/* 577 */           importAware.setImportMetadata(importingClass);
/*     */         } }
/*     */       
/* 580 */       return bean;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ImportAwareAotContribution
/*     */     implements BeanFactoryInitializationAotContribution
/*     */   {
/*     */     private static final String BEAN_FACTORY_VARIABLE = "beanFactory";
/*     */     
/* 590 */     private static final ParameterizedTypeName STRING_STRING_MAP = ParameterizedTypeName.get(Map.class, new Type[] { String.class, String.class });
/*     */     
/*     */     private static final String MAPPINGS_VARIABLE = "mappings";
/*     */     
/*     */     private static final String BEAN_DEFINITION_VARIABLE = "beanDefinition";
/*     */     
/*     */     private static final String BEAN_NAME = "org.springframework.context.annotation.internalImportAwareAotProcessor";
/*     */     
/*     */     private final ConfigurableListableBeanFactory beanFactory;
/*     */     
/*     */     public ImportAwareAotContribution(ConfigurableListableBeanFactory beanFactory) {
/* 601 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 608 */       Map<String, String> mappings = buildImportAwareMappings();
/* 609 */       if (!mappings.isEmpty()) {
/* 610 */         GeneratedMethod generatedMethod = beanFactoryInitializationCode.getMethods().add("addImportAwareBeanPostProcessors", method -> generateAddPostProcessorMethod(method, mappings));
/*     */         
/* 612 */         beanFactoryInitializationCode.addInitializer(generatedMethod.toMethodReference());
/* 613 */         ResourceHints hints = generationContext.getRuntimeHints().resources();
/* 614 */         mappings.forEach((target, from) -> hints.registerType(TypeReference.of(from)));
/*     */       } 
/*     */     }
/*     */     
/*     */     private void generateAddPostProcessorMethod(MethodSpec.Builder method, Map<String, String> mappings) {
/* 619 */       method.addJavadoc("Add ImportAwareBeanPostProcessor to support ImportAware beans.", new Object[0]);
/* 620 */       method.addModifiers(new Modifier[] { Modifier.PRIVATE });
/* 621 */       method.addParameter(DefaultListableBeanFactory.class, "beanFactory", new Modifier[0]);
/* 622 */       method.addCode(generateAddPostProcessorCode(mappings));
/*     */     }
/*     */     
/*     */     private CodeBlock generateAddPostProcessorCode(Map<String, String> mappings) {
/* 626 */       CodeBlock.Builder code = CodeBlock.builder();
/* 627 */       code.addStatement("$T $L = new $T<>()", new Object[] { STRING_STRING_MAP, "mappings", HashMap.class });
/*     */       
/* 629 */       mappings.forEach((type, from) -> code.addStatement("$L.put($S, $S)", new Object[] { "mappings", type, from }));
/*     */       
/* 631 */       code.addStatement("$T $L = new $T($T.class)", new Object[] { RootBeanDefinition.class, "beanDefinition", RootBeanDefinition.class, ImportAwareAotBeanPostProcessor.class });
/*     */       
/* 633 */       code.addStatement("$L.setRole($T.ROLE_INFRASTRUCTURE)", new Object[] { "beanDefinition", BeanDefinition.class });
/*     */       
/* 635 */       code.addStatement("$L.setInstanceSupplier(() -> new $T($L))", new Object[] { "beanDefinition", ImportAwareAotBeanPostProcessor.class, "mappings" });
/*     */       
/* 637 */       code.addStatement("$L.registerBeanDefinition($S, $L)", new Object[] { "beanFactory", "org.springframework.context.annotation.internalImportAwareAotProcessor", "beanDefinition" });
/*     */       
/* 639 */       return code.build();
/*     */     }
/*     */     
/*     */     private Map<String, String> buildImportAwareMappings() {
/* 643 */       ImportRegistry importRegistry = (ImportRegistry)this.beanFactory.getBean(ConfigurationClassPostProcessor.IMPORT_REGISTRY_BEAN_NAME, ImportRegistry.class);
/* 644 */       Map<String, String> mappings = new LinkedHashMap<>();
/* 645 */       for (String name : this.beanFactory.getBeanDefinitionNames()) {
/* 646 */         Class<?> beanType = this.beanFactory.getType(name);
/* 647 */         if (beanType != null && ImportAware.class.isAssignableFrom(beanType)) {
/* 648 */           String target = ClassUtils.getUserClass(beanType).getName();
/* 649 */           AnnotationMetadata from = importRegistry.getImportingClassFor(target);
/* 650 */           if (from != null) {
/* 651 */             mappings.put(target, from.getClassName());
/*     */           }
/*     */         } 
/*     */       } 
/* 655 */       return mappings;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class PropertySourcesAotContribution
/*     */     implements BeanFactoryInitializationAotContribution
/*     */   {
/*     */     private static final String ENVIRONMENT_VARIABLE = "environment";
/*     */     
/*     */     private static final String RESOURCE_LOADER_VARIABLE = "resourceLoader";
/* 666 */     private final Log logger = LogFactory.getLog(getClass());
/*     */     
/*     */     private final List<PropertySourceDescriptor> descriptors;
/*     */     
/*     */     private final Function<String, Resource> resourceResolver;
/*     */     
/*     */     PropertySourcesAotContribution(List<PropertySourceDescriptor> descriptors, Function<String, Resource> resourceResolver) {
/* 673 */       this.descriptors = descriptors;
/* 674 */       this.resourceResolver = resourceResolver;
/*     */     }
/*     */ 
/*     */     
/*     */     public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 679 */       registerRuntimeHints(generationContext.getRuntimeHints());
/*     */       
/* 681 */       GeneratedMethod generatedMethod = beanFactoryInitializationCode.getMethods().add("processPropertySources", this::generateAddPropertySourceProcessorMethod);
/* 682 */       beanFactoryInitializationCode.addInitializer(generatedMethod.toMethodReference());
/*     */     }
/*     */     
/*     */     private void registerRuntimeHints(RuntimeHints hints) {
/* 686 */       for (PropertySourceDescriptor descriptor : this.descriptors) {
/* 687 */         Class<?> factoryClass = descriptor.propertySourceFactory();
/* 688 */         if (factoryClass != null) {
/* 689 */           hints.reflection().registerType(factoryClass, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*     */         }
/* 691 */         for (String location : descriptor.locations()) {
/* 692 */           if (location.startsWith("classpath*:") || (location
/* 693 */             .startsWith("classpath:") && (location
/* 694 */             .contains("*") || location.contains("?")))) {
/*     */             
/* 696 */             if (this.logger.isWarnEnabled()) {
/* 697 */               this.logger.warn("Runtime hint registration is not supported for the 'classpath*:' prefix or wildcards in @PropertySource locations. Please manually register a resource hint for each property source location represented by '%s'."
/*     */ 
/*     */ 
/*     */                   
/* 701 */                   .formatted(new Object[] { location }));
/*     */             }
/*     */             continue;
/*     */           } 
/* 705 */           Resource resource = this.resourceResolver.apply(location);
/* 706 */           if (resource instanceof ClassPathResource) { ClassPathResource classPathResource = (ClassPathResource)resource; if (classPathResource.exists()) {
/* 707 */               hints.resources().registerPattern(classPathResource.getPath());
/*     */             } }
/*     */         
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void generateAddPropertySourceProcessorMethod(MethodSpec.Builder method) {
/* 715 */       method.addJavadoc("Apply known @PropertySources to the environment.", new Object[0]);
/* 716 */       method.addModifiers(new Modifier[] { Modifier.PRIVATE });
/* 717 */       method.addParameter(ConfigurableEnvironment.class, "environment", new Modifier[0]);
/* 718 */       method.addParameter(ResourceLoader.class, "resourceLoader", new Modifier[0]);
/* 719 */       method.addCode(generateAddPropertySourceProcessorCode());
/*     */     }
/*     */     
/*     */     private CodeBlock generateAddPropertySourceProcessorCode() {
/* 723 */       CodeBlock.Builder code = CodeBlock.builder();
/* 724 */       String processorVariable = "processor";
/* 725 */       code.addStatement("$T $L = new $T($L, $L)", new Object[] { PropertySourceProcessor.class, processorVariable, PropertySourceProcessor.class, "environment", "resourceLoader" });
/*     */ 
/*     */       
/* 728 */       code.beginControlFlow("try", new Object[0]);
/* 729 */       for (PropertySourceDescriptor descriptor : this.descriptors) {
/* 730 */         code.addStatement("$L.processPropertySource($L)", new Object[] { processorVariable, 
/* 731 */               generatePropertySourceDescriptorCode(descriptor) });
/*     */       } 
/* 733 */       code.nextControlFlow("catch ($T ex)", new Object[] { IOException.class });
/* 734 */       code.addStatement("throw new $T(ex)", new Object[] { UncheckedIOException.class });
/* 735 */       code.endControlFlow();
/* 736 */       return code.build();
/*     */     }
/*     */     
/*     */     private CodeBlock generatePropertySourceDescriptorCode(PropertySourceDescriptor descriptor) {
/* 740 */       CodeBlock.Builder code = CodeBlock.builder();
/* 741 */       code.add("new $T(", new Object[] { PropertySourceDescriptor.class });
/*     */       
/* 743 */       CodeBlock values = (CodeBlock)descriptor.locations().stream().map(value -> CodeBlock.of("$S", new Object[] { value })).collect(CodeBlock.joining(", "));
/* 744 */       if (descriptor.name() == null && descriptor.propertySourceFactory() == null && descriptor
/* 745 */         .encoding() == null && !descriptor.ignoreResourceNotFound()) {
/* 746 */         code.add("$L)", new Object[] { values });
/*     */       } else {
/*     */         
/* 749 */         List<CodeBlock> arguments = new ArrayList<>();
/* 750 */         arguments.add(CodeBlock.of("$T.of($L)", new Object[] { List.class, values }));
/* 751 */         arguments.add(CodeBlock.of("$L", new Object[] { Boolean.valueOf(descriptor.ignoreResourceNotFound()) }));
/* 752 */         arguments.add(handleNull(descriptor.name(), () -> CodeBlock.of("$S", new Object[] { descriptor.name() })));
/* 753 */         arguments.add(handleNull(descriptor.propertySourceFactory(), () -> CodeBlock.of("$T.class", new Object[] { descriptor.propertySourceFactory() })));
/*     */         
/* 755 */         arguments.add(handleNull(descriptor.encoding(), () -> CodeBlock.of("$S", new Object[] { descriptor.encoding() })));
/*     */         
/* 757 */         code.add(CodeBlock.join(arguments, ", "));
/* 758 */         code.add(")", new Object[0]);
/*     */       } 
/* 760 */       return code.build();
/*     */     }
/*     */     
/*     */     private CodeBlock handleNull(@Nullable Object value, Supplier<CodeBlock> nonNull) {
/* 764 */       return (value == null) ? CodeBlock.of("null", new Object[0]) : nonNull.get();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ConfigurationClassProxyBeanRegistrationCodeFragments
/*     */     extends BeanRegistrationCodeFragmentsDecorator
/*     */   {
/*     */     private final RegisteredBean registeredBean;
/*     */     
/*     */     private final Class<?> proxyClass;
/*     */ 
/*     */     
/*     */     public ConfigurationClassProxyBeanRegistrationCodeFragments(BeanRegistrationCodeFragments codeFragments, RegisteredBean registeredBean) {
/* 778 */       super(codeFragments);
/* 779 */       this.registeredBean = registeredBean;
/* 780 */       this.proxyClass = registeredBean.getBeanType().toClass();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CodeBlock generateSetBeanDefinitionPropertiesCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, RootBeanDefinition beanDefinition, Predicate<String> attributeFilter) {
/* 788 */       CodeBlock.Builder code = CodeBlock.builder();
/* 789 */       code.add(super.generateSetBeanDefinitionPropertiesCode(generationContext, beanRegistrationCode, beanDefinition, attributeFilter));
/*     */       
/* 791 */       code.addStatement("$T.initializeConfigurationClass($T.class)", new Object[] { ConfigurationClassUtils.class, 
/* 792 */             ClassUtils.getUserClass(this.proxyClass) });
/* 793 */       return code.build();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CodeBlock generateInstanceSupplierCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, boolean allowDirectSupplierShortcut) {
/* 801 */       RegisteredBean.InstantiationDescriptor instantiationDescriptor = proxyInstantiationDescriptor(generationContext
/* 802 */           .getRuntimeHints(), this.registeredBean.resolveInstantiationDescriptor());
/*     */       
/* 804 */       return (new InstanceSupplierCodeGenerator(generationContext, beanRegistrationCode
/* 805 */           .getClassName(), beanRegistrationCode.getMethods(), allowDirectSupplierShortcut))
/* 806 */         .generateCode(this.registeredBean, instantiationDescriptor);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private RegisteredBean.InstantiationDescriptor proxyInstantiationDescriptor(RuntimeHints runtimeHints, RegisteredBean.InstantiationDescriptor instantiationDescriptor) {
/* 812 */       Executable userExecutable = instantiationDescriptor.executable();
/* 813 */       if (userExecutable instanceof Constructor) { Constructor<?> userConstructor = (Constructor)userExecutable;
/*     */         try {
/* 815 */           runtimeHints.reflection().registerConstructor(userConstructor, ExecutableMode.INTROSPECT);
/* 816 */           Constructor<?> constructor = this.proxyClass.getConstructor(userExecutable.getParameterTypes());
/* 817 */           return new RegisteredBean.InstantiationDescriptor(constructor);
/*     */         }
/* 819 */         catch (NoSuchMethodException ex) {
/* 820 */           throw new IllegalStateException("No matching constructor found on proxy " + String.valueOf(this.proxyClass), ex);
/*     */         }  }
/*     */       
/* 823 */       return instantiationDescriptor;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConfigurationClassPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */