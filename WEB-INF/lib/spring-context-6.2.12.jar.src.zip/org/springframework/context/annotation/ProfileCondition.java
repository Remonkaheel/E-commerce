/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ProfileCondition
/*    */   implements Condition
/*    */ {
/*    */   public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 36 */     MultiValueMap<String, Object> attrs = metadata.getAllAnnotationAttributes(Profile.class.getName());
/* 37 */     if (attrs != null) {
/* 38 */       for (Object value : attrs.get("value")) {
/* 39 */         if (context.getEnvironment().matchesProfiles((String[])value)) {
/* 40 */           return true;
/*    */         }
/*    */       } 
/* 43 */       return false;
/*    */     } 
/* 45 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ProfileCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */