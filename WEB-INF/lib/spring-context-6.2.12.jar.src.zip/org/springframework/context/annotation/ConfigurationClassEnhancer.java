/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.AotDetector;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.support.SimpleInstantiationStrategy;
/*     */ import org.springframework.cglib.core.ClassGenerator;
/*     */ import org.springframework.cglib.core.ClassLoaderAwareGeneratorStrategy;
/*     */ import org.springframework.cglib.core.ClassTransformer;
/*     */ import org.springframework.cglib.core.CodeGenerationException;
/*     */ import org.springframework.cglib.core.GeneratorStrategy;
/*     */ import org.springframework.cglib.core.NamingPolicy;
/*     */ import org.springframework.cglib.core.SpringNamingPolicy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.CallbackFilter;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.Factory;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.cglib.proxy.NoOp;
/*     */ import org.springframework.cglib.transform.ClassEmitterTransformer;
/*     */ import org.springframework.cglib.transform.TransformingClassGenerator;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.objenesis.ObjenesisException;
/*     */ import org.springframework.objenesis.SpringObjenesis;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationClassEnhancer
/*     */ {
/*  81 */   static final Callback[] CALLBACKS = new Callback[] { new BeanMethodInterceptor(), new BeanFactoryAwareMethodInterceptor(), (Callback)NoOp.INSTANCE };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private static final ConditionalCallbackFilter CALLBACK_FILTER = new ConditionalCallbackFilter(CALLBACKS);
/*     */ 
/*     */   
/*     */   private static final String BEAN_FACTORY_FIELD = "$$beanFactory";
/*     */   
/*  92 */   private static final Log logger = LogFactory.getLog(ConfigurationClassEnhancer.class);
/*     */   
/*  94 */   private static final SpringObjenesis objenesis = new SpringObjenesis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> enhance(Class<?> configClass, @Nullable ClassLoader classLoader) {
/* 103 */     if (EnhancedConfiguration.class.isAssignableFrom(configClass)) {
/* 104 */       if (logger.isDebugEnabled()) {
/* 105 */         logger.debug(String.format("Ignoring request to enhance %s as it has already been enhanced. This usually indicates that more than one ConfigurationClassPostProcessor has been registered (for example, via <context:annotation-config>). This is harmless, but you may want check your configuration and remove one CCPP if possible", new Object[] { configClass
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 110 */                 .getName() }));
/*     */       }
/* 112 */       return configClass;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 117 */       boolean classLoaderMismatch = (classLoader != null && classLoader != configClass.getClassLoader());
/* 118 */       if (classLoaderMismatch && classLoader instanceof SmartClassLoader) { SmartClassLoader smartClassLoader = (SmartClassLoader)classLoader;
/* 119 */         classLoader = smartClassLoader.getOriginalClassLoader();
/* 120 */         classLoaderMismatch = (classLoader != configClass.getClassLoader()); }
/*     */ 
/*     */       
/* 123 */       if (classLoaderMismatch && reliesOnPackageVisibility(configClass)) {
/* 124 */         classLoader = configClass.getClassLoader();
/* 125 */         classLoaderMismatch = false;
/*     */       } 
/* 127 */       Enhancer enhancer = newEnhancer(configClass, classLoader);
/* 128 */       Class<?> enhancedClass = createClass(enhancer, classLoaderMismatch);
/* 129 */       if (logger.isTraceEnabled()) {
/* 130 */         logger.trace(String.format("Successfully enhanced %s; enhanced class name is: %s", new Object[] { configClass
/* 131 */                 .getName(), enhancedClass.getName() }));
/*     */       }
/* 133 */       return enhancedClass;
/*     */     }
/* 135 */     catch (CodeGenerationException ex) {
/* 136 */       throw new BeanDefinitionStoreException("Could not enhance configuration class [" + configClass.getName() + "]. Consider declaring @Configuration(proxyBeanMethods=false) without inter-bean references between @Bean methods on the configuration class, avoiding the need for CGLIB enhancement.", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean reliesOnPackageVisibility(Class<?> configSuperClass) {
/* 147 */     int mod = configSuperClass.getModifiers();
/* 148 */     if (!Modifier.isPublic(mod) && !Modifier.isProtected(mod)) {
/* 149 */       return true;
/*     */     }
/* 151 */     for (Constructor<?> ctor : configSuperClass.getDeclaredConstructors()) {
/* 152 */       mod = ctor.getModifiers();
/* 153 */       if (!Modifier.isPublic(mod) && !Modifier.isProtected(mod)) {
/* 154 */         return true;
/*     */       }
/*     */     } 
/* 157 */     for (Method method : ReflectionUtils.getDeclaredMethods(configSuperClass)) {
/* 158 */       if (BeanAnnotationHelper.isBeanAnnotated(method)) {
/* 159 */         mod = method.getModifiers();
/* 160 */         if (!Modifier.isPublic(mod) && !Modifier.isProtected(mod)) {
/* 161 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 165 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Enhancer newEnhancer(Class<?> configSuperClass, @Nullable ClassLoader classLoader) {
/* 172 */     Enhancer enhancer = new Enhancer();
/* 173 */     if (classLoader != null) {
/* 174 */       enhancer.setClassLoader(classLoader);
/* 175 */       if (classLoader instanceof SmartClassLoader) { SmartClassLoader smartClassLoader = (SmartClassLoader)classLoader; if (smartClassLoader
/* 176 */           .isClassReloadable(configSuperClass))
/* 177 */           enhancer.setUseCache(false);  }
/*     */     
/*     */     } 
/* 180 */     enhancer.setSuperclass(configSuperClass);
/* 181 */     enhancer.setInterfaces(new Class[] { EnhancedConfiguration.class });
/* 182 */     enhancer.setUseFactory(false);
/* 183 */     enhancer.setNamingPolicy((NamingPolicy)SpringNamingPolicy.INSTANCE);
/* 184 */     enhancer.setAttemptLoad((enhancer.getUseCache() && AotDetector.useGeneratedArtifacts()));
/* 185 */     enhancer.setStrategy((GeneratorStrategy)new BeanFactoryAwareGeneratorStrategy(classLoader));
/* 186 */     enhancer.setCallbackFilter(CALLBACK_FILTER);
/* 187 */     enhancer.setCallbackTypes(CALLBACK_FILTER.getCallbackTypes());
/* 188 */     return enhancer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> createClass(Enhancer enhancer, boolean fallback) {
/*     */     Class<?> subclass;
/*     */     try {
/* 198 */       subclass = enhancer.createClass();
/*     */     }
/* 200 */     catch (Throwable ex) {
/* 201 */       if (!fallback) {
/* 202 */         CodeGenerationException cgex = (CodeGenerationException)ex; throw (ex instanceof CodeGenerationException) ? cgex : new CodeGenerationException(ex);
/*     */       } 
/*     */ 
/*     */       
/* 206 */       enhancer.setClassLoader(null);
/* 207 */       subclass = enhancer.createClass();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 212 */     Enhancer.registerStaticCallbacks(subclass, CALLBACKS);
/* 213 */     return subclass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConditionalCallbackFilter
/*     */     implements CallbackFilter
/*     */   {
/*     */     private final Callback[] callbacks;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Class<?>[] callbackTypes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionalCallbackFilter(Callback[] callbacks) {
/* 252 */       this.callbacks = callbacks;
/* 253 */       this.callbackTypes = new Class[callbacks.length];
/* 254 */       for (int i = 0; i < callbacks.length; i++) {
/* 255 */         this.callbackTypes[i] = callbacks[i].getClass();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public int accept(Method method) {
/* 261 */       for (int i = 0; i < this.callbacks.length; ) {
/* 262 */         Callback callback = this.callbacks[i];
/* 263 */         if (callback instanceof ConfigurationClassEnhancer.ConditionalCallback) { ConfigurationClassEnhancer.ConditionalCallback conditional = (ConfigurationClassEnhancer.ConditionalCallback)callback; if (!conditional.isMatch(method)) { i++; continue; }  }
/* 264 */          return i;
/*     */       } 
/*     */       
/* 267 */       throw new IllegalStateException("No callback available for method " + method.getName());
/*     */     }
/*     */     
/*     */     public Class<?>[] getCallbackTypes() {
/* 271 */       return this.callbackTypes;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BeanFactoryAwareGeneratorStrategy
/*     */     extends ClassLoaderAwareGeneratorStrategy
/*     */   {
/*     */     public BeanFactoryAwareGeneratorStrategy(@Nullable ClassLoader classLoader) {
/* 284 */       super(classLoader);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ClassGenerator transform(ClassGenerator cg) throws Exception {
/* 289 */       ClassEmitterTransformer transformer = new ClassEmitterTransformer()
/*     */         {
/*     */           public void end_class() {
/* 292 */             declare_field(1, "$$beanFactory", Type.getType(BeanFactory.class), null);
/* 293 */             super.end_class();
/*     */           }
/*     */         };
/* 296 */       return (ClassGenerator)new TransformingClassGenerator(cg, (ClassTransformer)transformer);
/*     */     }
/*     */   }
/*     */   
/*     */   class null
/*     */     extends ClassEmitterTransformer {
/*     */     public void end_class() {
/*     */       declare_field(1, "$$beanFactory", Type.getType(BeanFactory.class), null);
/*     */       super.end_class();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class BeanFactoryAwareMethodInterceptor implements MethodInterceptor, ConditionalCallback {
/*     */     @Nullable
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
/* 311 */       Field field = ReflectionUtils.findField(obj.getClass(), "$$beanFactory");
/* 312 */       Assert.state((field != null), "Unable to find generated BeanFactory field");
/* 313 */       field.set(obj, args[0]);
/*     */ 
/*     */ 
/*     */       
/* 317 */       if (BeanFactoryAware.class.isAssignableFrom(ClassUtils.getUserClass(obj.getClass().getSuperclass()))) {
/* 318 */         return proxy.invokeSuper(obj, args);
/*     */       }
/* 320 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isMatch(Method candidateMethod) {
/* 325 */       return isSetBeanFactory(candidateMethod);
/*     */     }
/*     */     
/*     */     public static boolean isSetBeanFactory(Method candidateMethod) {
/* 329 */       return (candidateMethod.getName().equals("setBeanFactory") && candidateMethod
/* 330 */         .getParameterCount() == 1 && BeanFactory.class == candidateMethod
/* 331 */         .getParameterTypes()[0] && BeanFactoryAware.class
/* 332 */         .isAssignableFrom(candidateMethod.getDeclaringClass()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BeanMethodInterceptor
/*     */     implements MethodInterceptor, ConditionalCallback
/*     */   {
/*     */     @Nullable
/*     */     public Object intercept(Object enhancedConfigInstance, Method beanMethod, Object[] beanMethodArgs, MethodProxy cglibMethodProxy) throws Throwable {
/* 356 */       ConfigurableBeanFactory beanFactory = getBeanFactory(enhancedConfigInstance);
/* 357 */       String beanName = BeanAnnotationHelper.determineBeanNameFor(beanMethod);
/*     */ 
/*     */       
/* 360 */       if (BeanAnnotationHelper.isScopedProxy(beanMethod)) {
/* 361 */         String scopedBeanName = ScopedProxyCreator.getTargetBeanName(beanName);
/* 362 */         if (beanFactory.isCurrentlyInCreation(scopedBeanName)) {
/* 363 */           beanName = scopedBeanName;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 374 */       String factoryBeanName = "&" + beanName;
/* 375 */       if (factoryContainsBean(beanFactory, factoryBeanName) && factoryContainsBean(beanFactory, beanName)) {
/* 376 */         Object factoryBean = beanFactory.getBean(factoryBeanName);
/* 377 */         if (!(factoryBean instanceof org.springframework.aop.scope.ScopedProxyFactoryBean))
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 382 */           return enhanceFactoryBean(factoryBean, beanMethod.getReturnType(), beanFactory, beanName);
/*     */         }
/*     */       } 
/*     */       
/* 386 */       if (isCurrentlyInvokedFactoryMethod(beanMethod)) {
/*     */ 
/*     */ 
/*     */         
/* 390 */         if (ConfigurationClassEnhancer.logger.isInfoEnabled() && BeanFactoryPostProcessor.class
/* 391 */           .isAssignableFrom(beanMethod.getReturnType())) {
/* 392 */           ConfigurationClassEnhancer.logger.info(String.format("@Bean method %s.%s is non-static and returns an object assignable to Spring's BeanFactoryPostProcessor interface. This will result in a failure to process annotations such as @Autowired, @Resource and @PostConstruct within the method's declaring @Configuration class. Add the 'static' modifier to this method to avoid these container lifecycle issues; see @Bean javadoc for complete details.", new Object[] { beanMethod
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 398 */                   .getDeclaringClass().getSimpleName(), beanMethod.getName() }));
/*     */         }
/* 400 */         return cglibMethodProxy.invokeSuper(enhancedConfigInstance, beanMethodArgs);
/*     */       } 
/*     */       
/* 403 */       return resolveBeanReference(beanMethod, beanMethodArgs, beanFactory, beanName);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Object resolveBeanReference(Method beanMethod, Object[] beanMethodArgs, ConfigurableBeanFactory beanFactory, String beanName) {
/* 414 */       boolean alreadyInCreation = beanFactory.isCurrentlyInCreation(beanName);
/*     */       try {
/* 416 */         if (alreadyInCreation) {
/* 417 */           beanFactory.setCurrentlyInCreation(beanName, false);
/*     */         }
/* 419 */         boolean useArgs = !ObjectUtils.isEmpty(beanMethodArgs);
/* 420 */         if (useArgs && beanFactory.isSingleton(beanName))
/*     */         {
/*     */ 
/*     */           
/* 424 */           for (Object arg : beanMethodArgs) {
/* 425 */             if (arg == null) {
/* 426 */               useArgs = false;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/* 432 */         Object beanInstance = useArgs ? beanFactory.getBean(beanName, beanMethodArgs) : beanFactory.getBean(beanName);
/* 433 */         if (!ClassUtils.isAssignableValue(beanMethod.getReturnType(), beanInstance))
/*     */         {
/* 435 */           if (beanInstance.equals(null)) {
/* 436 */             if (ConfigurationClassEnhancer.logger.isDebugEnabled()) {
/* 437 */               ConfigurationClassEnhancer.logger.debug(String.format("@Bean method %s.%s called as bean reference for type [%s] returned null bean; resolving to null value.", new Object[] { beanMethod
/*     */                       
/* 439 */                       .getDeclaringClass().getSimpleName(), beanMethod.getName(), beanMethod
/* 440 */                       .getReturnType().getName() }));
/*     */             }
/* 442 */             beanInstance = null;
/*     */           } else {
/*     */             
/* 445 */             String msg = String.format("@Bean method %s.%s called as bean reference for type [%s] but overridden by non-compatible bean instance of type [%s].", new Object[] { beanMethod
/*     */                   
/* 447 */                   .getDeclaringClass().getSimpleName(), beanMethod.getName(), beanMethod
/* 448 */                   .getReturnType().getName(), beanInstance.getClass().getName() });
/*     */             try {
/* 450 */               BeanDefinition beanDefinition = beanFactory.getMergedBeanDefinition(beanName);
/* 451 */               msg = msg + " Overriding bean of same name declared in: " + msg;
/*     */             }
/* 453 */             catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */ 
/*     */             
/* 456 */             throw new IllegalStateException(msg);
/*     */           } 
/*     */         }
/* 459 */         Method currentlyInvoked = SimpleInstantiationStrategy.getCurrentlyInvokedFactoryMethod();
/* 460 */         if (currentlyInvoked != null) {
/* 461 */           String outerBeanName = BeanAnnotationHelper.determineBeanNameFor(currentlyInvoked);
/* 462 */           beanFactory.registerDependentBean(beanName, outerBeanName);
/*     */         } 
/* 464 */         return beanInstance;
/*     */       } finally {
/*     */         
/* 467 */         if (alreadyInCreation) {
/* 468 */           beanFactory.setCurrentlyInCreation(beanName, true);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isMatch(Method candidateMethod) {
/* 475 */       return (candidateMethod.getDeclaringClass() != Object.class && 
/* 476 */         !ConfigurationClassEnhancer.BeanFactoryAwareMethodInterceptor.isSetBeanFactory(candidateMethod) && 
/* 477 */         BeanAnnotationHelper.isBeanAnnotated(candidateMethod));
/*     */     }
/*     */     
/*     */     private ConfigurableBeanFactory getBeanFactory(Object enhancedConfigInstance) {
/* 481 */       Field field = ReflectionUtils.findField(enhancedConfigInstance.getClass(), "$$beanFactory");
/* 482 */       Assert.state((field != null), "Unable to find generated bean factory field");
/* 483 */       Object beanFactory = ReflectionUtils.getField(field, enhancedConfigInstance);
/* 484 */       Assert.state((beanFactory != null), "BeanFactory has not been injected into @Configuration class");
/* 485 */       Assert.state(beanFactory instanceof ConfigurableBeanFactory, "Injected BeanFactory is not a ConfigurableBeanFactory");
/*     */       
/* 487 */       return (ConfigurableBeanFactory)beanFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean factoryContainsBean(ConfigurableBeanFactory beanFactory, String beanName) {
/* 504 */       return (beanFactory.containsBean(beanName) && !beanFactory.isCurrentlyInCreation(beanName));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isCurrentlyInvokedFactoryMethod(Method method) {
/* 514 */       Method currentlyInvoked = SimpleInstantiationStrategy.getCurrentlyInvokedFactoryMethod();
/* 515 */       return (currentlyInvoked != null && method.getName().equals(currentlyInvoked.getName()) && 
/* 516 */         Arrays.equals((Object[])method.getParameterTypes(), (Object[])currentlyInvoked.getParameterTypes()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Object enhanceFactoryBean(Object factoryBean, Class<?> exposedType, ConfigurableBeanFactory beanFactory, String beanName) {
/*     */       try {
/* 530 */         Class<?> clazz = factoryBean.getClass();
/* 531 */         boolean finalClass = Modifier.isFinal(clazz.getModifiers());
/* 532 */         boolean finalMethod = Modifier.isFinal(clazz.getMethod("getObject", new Class[0]).getModifiers());
/* 533 */         if (finalClass || finalMethod) {
/* 534 */           if (exposedType.isInterface()) {
/* 535 */             if (ConfigurationClassEnhancer.logger.isTraceEnabled()) {
/* 536 */               ConfigurationClassEnhancer.logger.trace("Creating interface proxy for FactoryBean '" + beanName + "' of type [" + clazz
/* 537 */                   .getName() + "] for use within another @Bean method because its " + (
/* 538 */                   finalClass ? "implementation class" : "getObject() method") + " is final: Otherwise a getObject() call would not be routed to the factory.");
/*     */             }
/*     */             
/* 541 */             return createInterfaceProxyForFactoryBean(factoryBean, exposedType, beanFactory, beanName);
/*     */           } 
/*     */           
/* 544 */           if (ConfigurationClassEnhancer.logger.isDebugEnabled()) {
/* 545 */             ConfigurationClassEnhancer.logger.debug("Unable to proxy FactoryBean '" + beanName + "' of type [" + clazz
/* 546 */                 .getName() + "] for use within another @Bean method because its " + (
/* 547 */                 finalClass ? "implementation class" : "getObject() method") + " is final: A getObject() call will NOT be routed to the factory. Consider declaring the return type as a FactoryBean interface.");
/*     */           }
/*     */ 
/*     */           
/* 551 */           return factoryBean;
/*     */         }
/*     */       
/*     */       }
/* 555 */       catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */ 
/*     */       
/* 559 */       return createCglibProxyForFactoryBean(factoryBean, beanFactory, beanName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Object createInterfaceProxyForFactoryBean(Object factoryBean, Class<?> interfaceType, ConfigurableBeanFactory beanFactory, String beanName) {
/* 565 */       return Proxy.newProxyInstance(factoryBean
/* 566 */           .getClass().getClassLoader(), new Class[] { interfaceType
/*     */           },
/* 568 */           (proxy, method, args) -> (method.getName().equals("getObject") && args == null) ? beanFactory.getBean(beanName) : ReflectionUtils.invokeMethod(method, factoryBean, args));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Object createCglibProxyForFactoryBean(Object factoryBean, ConfigurableBeanFactory beanFactory, String beanName) {
/* 578 */       Enhancer enhancer = new Enhancer();
/* 579 */       enhancer.setSuperclass(factoryBean.getClass());
/* 580 */       enhancer.setNamingPolicy((NamingPolicy)SpringNamingPolicy.INSTANCE);
/* 581 */       enhancer.setAttemptLoad(AotDetector.useGeneratedArtifacts());
/* 582 */       enhancer.setCallbackType(MethodInterceptor.class);
/*     */ 
/*     */ 
/*     */       
/* 586 */       Class<?> fbClass = enhancer.createClass();
/* 587 */       Object fbProxy = null;
/*     */       
/* 589 */       if (ConfigurationClassEnhancer.objenesis.isWorthTrying()) {
/*     */         try {
/* 591 */           fbProxy = ConfigurationClassEnhancer.objenesis.newInstance(fbClass, enhancer.getUseCache());
/*     */         }
/* 593 */         catch (ObjenesisException ex) {
/* 594 */           ConfigurationClassEnhancer.logger.debug("Unable to instantiate enhanced FactoryBean using Objenesis, falling back to regular construction", (Throwable)ex);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 599 */       if (fbProxy == null) {
/*     */         try {
/* 601 */           fbProxy = ReflectionUtils.accessibleConstructor(fbClass, new Class[0]).newInstance(new Object[0]);
/*     */         }
/* 603 */         catch (Throwable ex) {
/* 604 */           throw new IllegalStateException("Unable to instantiate enhanced FactoryBean using Objenesis, and regular FactoryBean instantiation via default constructor fails as well", ex);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 609 */       ((Factory)fbProxy).setCallback(0, (Callback)((obj, method, args, proxy) -> 
/* 610 */           (method.getName().equals("getObject") && args.length == 0) ? beanFactory.getBean(beanName) : method.invoke(factoryBean, args)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 616 */       return fbProxy;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface EnhancedConfiguration extends BeanFactoryAware {}
/*     */   
/*     */   private static interface ConditionalCallback extends Callback {
/*     */     boolean isMatch(Method param1Method);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConfigurationClassEnhancer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */