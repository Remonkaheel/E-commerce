package org.springframework.context.annotation;

public interface AnnotationConfigRegistry {
  void register(Class<?>... paramVarArgs);
  
  void scan(String... paramVarArgs);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\AnnotationConfigRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */