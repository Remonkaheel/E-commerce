/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServer;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.jmx.export.annotation.AnnotationMBeanExporter;
/*     */ import org.springframework.jmx.support.RegistrationPolicy;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @Role(2)
/*     */ public class MBeanExportConfiguration
/*     */   implements ImportAware, EnvironmentAware, BeanFactoryAware
/*     */ {
/*     */   private static final String MBEAN_EXPORTER_BEAN_NAME = "mbeanExporter";
/*     */   @Nullable
/*     */   private AnnotationAttributes enableMBeanExport;
/*     */   @Nullable
/*     */   private Environment environment;
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   public void setImportMetadata(AnnotationMetadata importMetadata) {
/*  65 */     Map<String, Object> map = importMetadata.getAnnotationAttributes(EnableMBeanExport.class.getName());
/*  66 */     this.enableMBeanExport = AnnotationAttributes.fromMap(map);
/*  67 */     if (this.enableMBeanExport == null) {
/*  68 */       throw new IllegalArgumentException("@EnableMBeanExport is not present on importing class " + importMetadata
/*  69 */           .getClassName());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/*  75 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/*  80 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean(name = {"mbeanExporter"})
/*     */   @Role(2)
/*     */   public AnnotationMBeanExporter mbeanExporter() {
/*  87 */     AnnotationMBeanExporter exporter = new AnnotationMBeanExporter();
/*  88 */     Assert.state((this.enableMBeanExport != null), "No EnableMBeanExport annotation found");
/*  89 */     setupDomain(exporter, this.enableMBeanExport);
/*  90 */     setupServer(exporter, this.enableMBeanExport);
/*  91 */     setupRegistrationPolicy(exporter, this.enableMBeanExport);
/*  92 */     return exporter;
/*     */   }
/*     */   
/*     */   private void setupDomain(AnnotationMBeanExporter exporter, AnnotationAttributes enableMBeanExport) {
/*  96 */     String defaultDomain = enableMBeanExport.getString("defaultDomain");
/*  97 */     if (StringUtils.hasLength(defaultDomain) && this.environment != null) {
/*  98 */       defaultDomain = this.environment.resolvePlaceholders(defaultDomain);
/*     */     }
/* 100 */     if (StringUtils.hasText(defaultDomain)) {
/* 101 */       exporter.setDefaultDomain(defaultDomain);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setupServer(AnnotationMBeanExporter exporter, AnnotationAttributes enableMBeanExport) {
/* 106 */     String server = enableMBeanExport.getString("server");
/* 107 */     if (StringUtils.hasLength(server) && this.environment != null) {
/* 108 */       server = this.environment.resolvePlaceholders(server);
/*     */     }
/* 110 */     if (StringUtils.hasText(server)) {
/* 111 */       Assert.state((this.beanFactory != null), "No BeanFactory set");
/* 112 */       exporter.setServer((MBeanServer)this.beanFactory.getBean(server, MBeanServer.class));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setupRegistrationPolicy(AnnotationMBeanExporter exporter, AnnotationAttributes enableMBeanExport) {
/* 117 */     RegistrationPolicy registrationPolicy = (RegistrationPolicy)enableMBeanExport.getEnum("registration");
/* 118 */     exporter.setRegistrationPolicy(registrationPolicy);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\MBeanExportConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */