/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.Lookup;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.context.index.CandidateComponentsIndex;
/*     */ import org.springframework.context.index.CandidateComponentsIndexLoader;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.ClassFormatException;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.stereotype.Indexed;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassPathScanningCandidateComponentProvider
/*     */   implements EnvironmentCapable, ResourceLoaderAware
/*     */ {
/*     */   static final String DEFAULT_RESOURCE_PATTERN = "**/*.class";
/*     */   public static final String IGNORE_CLASSFORMAT_PROPERTY_NAME = "spring.classformat.ignore";
/* 107 */   private static final boolean shouldIgnoreClassFormatException = SpringProperties.getFlag("spring.classformat.ignore");
/*     */ 
/*     */   
/* 110 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/* 112 */   private String resourcePattern = "**/*.class";
/*     */   
/* 114 */   private final List<TypeFilter> includeFilters = new ArrayList<>();
/*     */   
/* 116 */   private final List<TypeFilter> excludeFilters = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Environment environment;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ConditionEvaluator conditionEvaluator;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ResourcePatternResolver resourcePatternResolver;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private MetadataReaderFactory metadataReaderFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private CandidateComponentsIndex componentsIndex;
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassPathScanningCandidateComponentProvider() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassPathScanningCandidateComponentProvider(boolean useDefaultFilters) {
/* 150 */     this(useDefaultFilters, (Environment)new StandardEnvironment());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassPathScanningCandidateComponentProvider(boolean useDefaultFilters, Environment environment) {
/* 163 */     if (useDefaultFilters) {
/* 164 */       registerDefaultFilters();
/*     */     }
/* 166 */     setEnvironment(environment);
/* 167 */     setResourceLoader(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourcePattern(String resourcePattern) {
/* 178 */     Assert.notNull(resourcePattern, "'resourcePattern' must not be null");
/* 179 */     this.resourcePattern = resourcePattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addIncludeFilter(TypeFilter includeFilter) {
/* 186 */     this.includeFilters.add(includeFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addExcludeFilter(TypeFilter excludeFilter) {
/* 193 */     this.excludeFilters.add(0, excludeFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetFilters(boolean useDefaultFilters) {
/* 205 */     this.includeFilters.clear();
/* 206 */     this.excludeFilters.clear();
/* 207 */     if (useDefaultFilters) {
/* 208 */       registerDefaultFilters();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerDefaultFilters() {
/* 225 */     this.includeFilters.add(new AnnotationTypeFilter(Component.class));
/* 226 */     ClassLoader cl = ClassPathScanningCandidateComponentProvider.class.getClassLoader();
/*     */     try {
/* 228 */       this.includeFilters.add(new AnnotationTypeFilter(
/* 229 */             ClassUtils.forName("jakarta.annotation.ManagedBean", cl), false));
/* 230 */       this.logger.trace("JSR-250 'jakarta.annotation.ManagedBean' found and supported for component scanning");
/*     */     }
/* 232 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/*     */     try {
/* 236 */       this.includeFilters.add(new AnnotationTypeFilter(
/* 237 */             ClassUtils.forName("javax.annotation.ManagedBean", cl), false));
/* 238 */       this.logger.trace("JSR-250 'javax.annotation.ManagedBean' found and supported for component scanning");
/*     */     }
/* 240 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/*     */     try {
/* 244 */       this.includeFilters.add(new AnnotationTypeFilter(
/* 245 */             ClassUtils.forName("jakarta.inject.Named", cl), false));
/* 246 */       this.logger.trace("JSR-330 'jakarta.inject.Named' annotation found and supported for component scanning");
/*     */     }
/* 248 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/*     */     try {
/* 252 */       this.includeFilters.add(new AnnotationTypeFilter(
/* 253 */             ClassUtils.forName("javax.inject.Named", cl), false));
/* 254 */       this.logger.trace("JSR-330 'javax.inject.Named' annotation found and supported for component scanning");
/*     */     }
/* 256 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/* 268 */     Assert.notNull(environment, "Environment must not be null");
/* 269 */     this.environment = environment;
/* 270 */     this.conditionEvaluator = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Environment getEnvironment() {
/* 275 */     if (this.environment == null) {
/* 276 */       this.environment = (Environment)new StandardEnvironment();
/*     */     }
/* 278 */     return this.environment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected BeanDefinitionRegistry getRegistry() {
/* 286 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceLoader(@Nullable ResourceLoader resourceLoader) {
/* 299 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/* 300 */     this.metadataReaderFactory = (MetadataReaderFactory)new CachingMetadataReaderFactory(resourceLoader);
/* 301 */     this.componentsIndex = CandidateComponentsIndexLoader.loadIndex(this.resourcePatternResolver.getClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ResourceLoader getResourceLoader() {
/* 308 */     return (ResourceLoader)getResourcePatternResolver();
/*     */   }
/*     */   
/*     */   private ResourcePatternResolver getResourcePatternResolver() {
/* 312 */     if (this.resourcePatternResolver == null) {
/* 313 */       this.resourcePatternResolver = (ResourcePatternResolver)new PathMatchingResourcePatternResolver();
/*     */     }
/* 315 */     return this.resourcePatternResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMetadataReaderFactory(MetadataReaderFactory metadataReaderFactory) {
/* 326 */     this.metadataReaderFactory = metadataReaderFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MetadataReaderFactory getMetadataReaderFactory() {
/* 333 */     if (this.metadataReaderFactory == null) {
/* 334 */       this.metadataReaderFactory = (MetadataReaderFactory)new CachingMetadataReaderFactory();
/*     */     }
/* 336 */     return this.metadataReaderFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<BeanDefinition> findCandidateComponents(String basePackage) {
/* 346 */     if (this.componentsIndex != null && indexSupportsIncludeFilters()) {
/* 347 */       return addCandidateComponentsFromIndex(this.componentsIndex, basePackage);
/*     */     }
/*     */     
/* 350 */     return scanCandidateComponents(basePackage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean indexSupportsIncludeFilters() {
/* 361 */     for (TypeFilter includeFilter : this.includeFilters) {
/* 362 */       if (!indexSupportsIncludeFilter(includeFilter)) {
/* 363 */         return false;
/*     */       }
/*     */     } 
/* 366 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean indexSupportsIncludeFilter(TypeFilter filter) {
/* 377 */     if (filter instanceof AnnotationTypeFilter) { AnnotationTypeFilter annotationTypeFilter = (AnnotationTypeFilter)filter;
/* 378 */       Class<? extends Annotation> annotationType = annotationTypeFilter.getAnnotationType();
/* 379 */       return (AnnotationUtils.isAnnotationDeclaredLocally(Indexed.class, annotationType) || annotationType
/* 380 */         .getName().startsWith("jakarta.") || annotationType
/* 381 */         .getName().startsWith("javax.")); }
/*     */     
/* 383 */     if (filter instanceof AssignableTypeFilter) { AssignableTypeFilter assignableTypeFilter = (AssignableTypeFilter)filter;
/* 384 */       Class<?> target = assignableTypeFilter.getTargetType();
/* 385 */       return AnnotationUtils.isAnnotationDeclaredLocally(Indexed.class, target); }
/*     */     
/* 387 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String extractStereotype(TypeFilter filter) {
/* 399 */     if (filter instanceof AnnotationTypeFilter) { AnnotationTypeFilter annotationTypeFilter = (AnnotationTypeFilter)filter;
/* 400 */       return annotationTypeFilter.getAnnotationType().getName(); }
/*     */     
/* 402 */     if (filter instanceof AssignableTypeFilter) { AssignableTypeFilter assignableTypeFilter = (AssignableTypeFilter)filter;
/* 403 */       return assignableTypeFilter.getTargetType().getName(); }
/*     */     
/* 405 */     return null;
/*     */   }
/*     */   
/*     */   private Set<BeanDefinition> addCandidateComponentsFromIndex(CandidateComponentsIndex index, String basePackage) {
/* 409 */     Set<BeanDefinition> candidates = new LinkedHashSet<>();
/*     */     try {
/* 411 */       Set<String> types = new HashSet<>();
/* 412 */       for (TypeFilter filter : this.includeFilters) {
/* 413 */         String stereotype = extractStereotype(filter);
/* 414 */         if (stereotype == null) {
/* 415 */           throw new IllegalArgumentException("Failed to extract stereotype from " + String.valueOf(filter));
/*     */         }
/* 417 */         types.addAll(index.getCandidateTypes(basePackage, stereotype));
/*     */       } 
/* 419 */       boolean traceEnabled = this.logger.isTraceEnabled();
/* 420 */       boolean debugEnabled = this.logger.isDebugEnabled();
/* 421 */       for (String type : types) {
/* 422 */         MetadataReader metadataReader = getMetadataReaderFactory().getMetadataReader(type);
/* 423 */         if (isCandidateComponent(metadataReader)) {
/* 424 */           ScannedGenericBeanDefinition sbd = new ScannedGenericBeanDefinition(metadataReader);
/* 425 */           sbd.setSource(metadataReader.getResource());
/* 426 */           if (isCandidateComponent(sbd)) {
/* 427 */             if (debugEnabled) {
/* 428 */               this.logger.debug("Using candidate component class from index: " + type);
/*     */             }
/* 430 */             candidates.add(sbd);
/*     */             continue;
/*     */           } 
/* 433 */           if (debugEnabled) {
/* 434 */             this.logger.debug("Ignored because not a concrete top-level class: " + type);
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/* 439 */         if (traceEnabled) {
/* 440 */           this.logger.trace("Ignored because matching an exclude filter: " + type);
/*     */         }
/*     */       }
/*     */     
/*     */     }
/* 445 */     catch (IOException ex) {
/* 446 */       throw new BeanDefinitionStoreException("I/O failure during classpath scanning", ex);
/*     */     } 
/* 448 */     return candidates;
/*     */   }
/*     */   
/*     */   private Set<BeanDefinition> scanCandidateComponents(String basePackage) {
/* 452 */     Set<BeanDefinition> candidates = new LinkedHashSet<>();
/*     */     
/*     */     try {
/* 455 */       String packageSearchPattern = "classpath*:" + resolveBasePackage(basePackage) + "/" + this.resourcePattern;
/* 456 */       Resource[] resources = getResourcePatternResolver().getResources(packageSearchPattern);
/* 457 */       boolean traceEnabled = this.logger.isTraceEnabled();
/* 458 */       boolean debugEnabled = this.logger.isDebugEnabled();
/* 459 */       for (Resource resource : resources) {
/* 460 */         String filename = resource.getFilename();
/* 461 */         if (filename == null || !filename.contains("$$")) {
/*     */ 
/*     */ 
/*     */           
/* 465 */           if (traceEnabled) {
/* 466 */             this.logger.trace("Scanning " + String.valueOf(resource));
/*     */           }
/*     */           try {
/* 469 */             MetadataReader metadataReader = getMetadataReaderFactory().getMetadataReader(resource);
/* 470 */             if (isCandidateComponent(metadataReader)) {
/* 471 */               ScannedGenericBeanDefinition sbd = new ScannedGenericBeanDefinition(metadataReader);
/* 472 */               sbd.setSource(resource);
/* 473 */               if (isCandidateComponent(sbd)) {
/* 474 */                 if (debugEnabled) {
/* 475 */                   this.logger.debug("Identified candidate component class: " + String.valueOf(resource));
/*     */                 }
/* 477 */                 candidates.add(sbd);
/*     */               
/*     */               }
/* 480 */               else if (debugEnabled) {
/* 481 */                 this.logger.debug("Ignored because not a concrete top-level class: " + String.valueOf(resource));
/*     */               
/*     */               }
/*     */             
/*     */             }
/* 486 */             else if (traceEnabled) {
/* 487 */               this.logger.trace("Ignored because not matching any filter: " + String.valueOf(resource));
/*     */             }
/*     */           
/*     */           }
/* 491 */           catch (FileNotFoundException ex) {
/* 492 */             if (traceEnabled) {
/* 493 */               this.logger.trace("Ignored non-readable " + String.valueOf(resource) + ": " + ex.getMessage());
/*     */             }
/*     */           }
/* 496 */           catch (ClassFormatException ex) {
/* 497 */             if (shouldIgnoreClassFormatException) {
/* 498 */               if (debugEnabled) {
/* 499 */                 this.logger.debug("Ignored incompatible class format in " + String.valueOf(resource) + ": " + ex.getMessage());
/*     */               }
/*     */             } else {
/*     */               
/* 503 */               throw new BeanDefinitionStoreException("Incompatible class format in " + String.valueOf(resource) + ": set system property 'spring.classformat.ignore' to 'true' if you mean to ignore such files during classpath scanning", ex);
/*     */             
/*     */             }
/*     */           
/*     */           }
/* 508 */           catch (Throwable ex) {
/* 509 */             throw new BeanDefinitionStoreException("Failed to read candidate component class: " + String.valueOf(resource), ex);
/*     */           } 
/*     */         } 
/*     */       } 
/* 513 */     } catch (IOException ex) {
/* 514 */       throw new BeanDefinitionStoreException("I/O failure during classpath scanning", ex);
/*     */     } 
/* 516 */     return candidates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String resolveBasePackage(String basePackage) {
/* 529 */     return ClassUtils.convertClassNameToResourcePath(getEnvironment().resolveRequiredPlaceholders(basePackage));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isCandidateComponent(MetadataReader metadataReader) throws IOException {
/* 539 */     for (TypeFilter filter : this.excludeFilters) {
/* 540 */       if (filter.match(metadataReader, getMetadataReaderFactory())) {
/* 541 */         return false;
/*     */       }
/*     */     } 
/* 544 */     for (TypeFilter filter : this.includeFilters) {
/* 545 */       if (filter.match(metadataReader, getMetadataReaderFactory())) {
/* 546 */         return isConditionMatch(metadataReader);
/*     */       }
/*     */     } 
/* 549 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isConditionMatch(MetadataReader metadataReader) {
/* 559 */     if (this.conditionEvaluator == null) {
/* 560 */       this
/* 561 */         .conditionEvaluator = new ConditionEvaluator(getRegistry(), this.environment, (ResourceLoader)this.resourcePatternResolver);
/*     */     }
/* 563 */     return !this.conditionEvaluator.shouldSkip((AnnotatedTypeMetadata)metadataReader.getAnnotationMetadata());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition) {
/* 576 */     AnnotationMetadata metadata = beanDefinition.getMetadata();
/* 577 */     return (metadata.isIndependent() && (metadata.isConcrete() || (metadata
/* 578 */       .isAbstract() && metadata.hasAnnotatedMethods(Lookup.class.getName()))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearCache() {
/* 586 */     MetadataReaderFactory metadataReaderFactory = this.metadataReaderFactory; if (metadataReaderFactory instanceof CachingMetadataReaderFactory) { CachingMetadataReaderFactory cmrf = (CachingMetadataReaderFactory)metadataReaderFactory;
/*     */ 
/*     */       
/* 589 */       cmrf.clearCache(); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ClassPathScanningCandidateComponentProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */