/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConditionContextImpl
/*     */   implements ConditionContext
/*     */ {
/*     */   @Nullable
/*     */   private final BeanDefinitionRegistry registry;
/*     */   @Nullable
/*     */   private final ConfigurableListableBeanFactory beanFactory;
/*     */   private final Environment environment;
/*     */   private final ResourceLoader resourceLoader;
/*     */   @Nullable
/*     */   private final ClassLoader classLoader;
/*     */   
/*     */   public ConditionContextImpl(@Nullable BeanDefinitionRegistry registry, @Nullable Environment environment, @Nullable ResourceLoader resourceLoader) {
/* 163 */     this.registry = registry;
/* 164 */     this.beanFactory = deduceBeanFactory(registry);
/* 165 */     this.environment = (environment != null) ? environment : deduceEnvironment(registry);
/* 166 */     this.resourceLoader = (resourceLoader != null) ? resourceLoader : deduceResourceLoader(registry);
/* 167 */     this.classLoader = deduceClassLoader(resourceLoader, this.beanFactory);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static ConfigurableListableBeanFactory deduceBeanFactory(@Nullable BeanDefinitionRegistry source) {
/* 172 */     if (source instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory configurableListableBeanFactory = (ConfigurableListableBeanFactory)source;
/* 173 */       return configurableListableBeanFactory; }
/*     */     
/* 175 */     if (source instanceof ConfigurableApplicationContext) { ConfigurableApplicationContext configurableApplicationContext = (ConfigurableApplicationContext)source;
/* 176 */       return configurableApplicationContext.getBeanFactory(); }
/*     */     
/* 178 */     return null;
/*     */   }
/*     */   
/*     */   private static Environment deduceEnvironment(@Nullable BeanDefinitionRegistry source) {
/* 182 */     if (source instanceof EnvironmentCapable) { EnvironmentCapable environmentCapable = (EnvironmentCapable)source;
/* 183 */       return environmentCapable.getEnvironment(); }
/*     */     
/* 185 */     return (Environment)new StandardEnvironment();
/*     */   }
/*     */   
/*     */   private static ResourceLoader deduceResourceLoader(@Nullable BeanDefinitionRegistry source) {
/* 189 */     if (source instanceof ResourceLoader) { ResourceLoader resourceLoader = (ResourceLoader)source;
/* 190 */       return resourceLoader; }
/*     */     
/* 192 */     return (ResourceLoader)new DefaultResourceLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static ClassLoader deduceClassLoader(@Nullable ResourceLoader resourceLoader, @Nullable ConfigurableListableBeanFactory beanFactory) {
/* 199 */     if (resourceLoader != null) {
/* 200 */       ClassLoader classLoader = resourceLoader.getClassLoader();
/* 201 */       if (classLoader != null) {
/* 202 */         return classLoader;
/*     */       }
/*     */     } 
/* 205 */     if (beanFactory != null) {
/* 206 */       return beanFactory.getBeanClassLoader();
/*     */     }
/* 208 */     return ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDefinitionRegistry getRegistry() {
/* 213 */     Assert.state((this.registry != null), "No BeanDefinitionRegistry available");
/* 214 */     return this.registry;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ConfigurableListableBeanFactory getBeanFactory() {
/* 220 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public Environment getEnvironment() {
/* 225 */     return this.environment;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceLoader getResourceLoader() {
/* 230 */     return this.resourceLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ClassLoader getClassLoader() {
/* 236 */     return this.classLoader;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConditionEvaluator$ConditionContextImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */