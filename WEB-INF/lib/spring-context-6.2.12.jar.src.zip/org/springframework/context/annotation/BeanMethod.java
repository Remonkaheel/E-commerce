/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BeanMethod
/*     */   extends ConfigurationMethod
/*     */ {
/*     */   BeanMethod(MethodMetadata metadata, ConfigurationClass configurationClass) {
/*  42 */     super(metadata, configurationClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate(ProblemReporter problemReporter) {
/*  49 */     if (getMetadata().getAnnotationAttributes(Autowired.class.getName()) != null)
/*     */     {
/*     */       
/*  52 */       problemReporter.error(new AutowiredDeclaredMethodError());
/*     */     }
/*     */     
/*  55 */     if ("void".equals(getMetadata().getReturnTypeName()))
/*     */     {
/*  57 */       problemReporter.error(new VoidDeclaredMethodError());
/*     */     }
/*     */     
/*  60 */     if (getMetadata().isStatic()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  66 */     Map<String, Object> attributes = getConfigurationClass().getMetadata().getAnnotationAttributes(Configuration.class.getName());
/*  67 */     if (attributes != null && ((Boolean)attributes.get("proxyBeanMethods")).booleanValue() && !getMetadata().isOverridable())
/*     */     {
/*  69 */       problemReporter.error(new NonOverridableMethodError());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  75 */     if (this != other) { if (other instanceof BeanMethod) { BeanMethod that = (BeanMethod)other; if (this.configurationClass
/*  76 */           .equals(that.configurationClass) && 
/*  77 */           getLocalMethodIdentifier(this.metadata).equals(getLocalMethodIdentifier(that.metadata))); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/*  82 */     return this.configurationClass.hashCode() * 31 + getLocalMethodIdentifier(this.metadata).hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  87 */     return "BeanMethod: " + String.valueOf(this.metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getLocalMethodIdentifier(MethodMetadata metadata) {
/*  92 */     String metadataString = metadata.toString();
/*  93 */     int index = metadataString.indexOf(metadata.getDeclaringClassName());
/*  94 */     return (index >= 0) ? metadataString.substring(index + metadata.getDeclaringClassName().length()) : 
/*  95 */       metadataString;
/*     */   }
/*     */   
/*     */   private class AutowiredDeclaredMethodError
/*     */     extends Problem
/*     */   {
/*     */     AutowiredDeclaredMethodError() {
/* 102 */       super("@Bean method '%s' must not be declared as autowired; remove the method-level @Autowired annotation."
/* 103 */           .formatted(new Object[] { this$0.getMetadata().getMethodName() }, ), BeanMethod.this.getResourceLocation());
/*     */     }
/*     */   }
/*     */   
/*     */   private class VoidDeclaredMethodError
/*     */     extends Problem
/*     */   {
/*     */     VoidDeclaredMethodError() {
/* 111 */       super("@Bean method '%s' must not be declared as void; change the method's return type or its annotation."
/* 112 */           .formatted(new Object[] { this$0.getMetadata().getMethodName() }, ), BeanMethod.this.getResourceLocation());
/*     */     }
/*     */   }
/*     */   
/*     */   private class NonOverridableMethodError
/*     */     extends Problem
/*     */   {
/*     */     NonOverridableMethodError() {
/* 120 */       super("@Bean method '%s' must not be private or final; change the method's modifiers to continue."
/* 121 */           .formatted(new Object[] { this$0.getMetadata().getMethodName() }, ), BeanMethod.this.getResourceLocation());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\BeanMethod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */