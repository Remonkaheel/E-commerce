/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionCustomizer;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotatedBeanDefinitionReader
/*     */ {
/*     */   private final BeanDefinitionRegistry registry;
/*  54 */   private BeanNameGenerator beanNameGenerator = AnnotationBeanNameGenerator.INSTANCE;
/*     */   
/*  56 */   private ScopeMetadataResolver scopeMetadataResolver = new AnnotationScopeMetadataResolver();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConditionEvaluator conditionEvaluator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedBeanDefinitionReader(BeanDefinitionRegistry registry) {
/*  72 */     this(registry, getOrCreateEnvironment(registry));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedBeanDefinitionReader(BeanDefinitionRegistry registry, Environment environment) {
/*  85 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*  86 */     Assert.notNull(environment, "Environment must not be null");
/*  87 */     this.registry = registry;
/*  88 */     this.conditionEvaluator = new ConditionEvaluator(registry, environment, null);
/*  89 */     AnnotationConfigUtils.registerAnnotationConfigProcessors(this.registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BeanDefinitionRegistry getRegistry() {
/*  97 */     return this.registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/* 106 */     this.conditionEvaluator = new ConditionEvaluator(this.registry, environment, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanNameGenerator(@Nullable BeanNameGenerator beanNameGenerator) {
/* 114 */     this
/* 115 */       .beanNameGenerator = (beanNameGenerator != null) ? beanNameGenerator : AnnotationBeanNameGenerator.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScopeMetadataResolver(@Nullable ScopeMetadataResolver scopeMetadataResolver) {
/* 123 */     this
/* 124 */       .scopeMetadataResolver = (scopeMetadataResolver != null) ? scopeMetadataResolver : new AnnotationScopeMetadataResolver();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(Class<?>... componentClasses) {
/* 136 */     for (Class<?> componentClass : componentClasses) {
/* 137 */       registerBean(componentClass);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerBean(Class<?> beanClass) {
/* 147 */     doRegisterBean(beanClass, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerBean(Class<?> beanClass, @Nullable String name) {
/* 159 */     doRegisterBean(beanClass, name, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerBean(Class<?> beanClass, Class<? extends Annotation>... qualifiers) {
/* 171 */     doRegisterBean(beanClass, null, qualifiers, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerBean(Class<?> beanClass, @Nullable String name, Class<? extends Annotation>... qualifiers) {
/* 187 */     doRegisterBean(beanClass, name, qualifiers, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void registerBean(Class<T> beanClass, @Nullable Supplier<T> supplier) {
/* 200 */     doRegisterBean(beanClass, null, null, supplier, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void registerBean(Class<T> beanClass, @Nullable String name, @Nullable Supplier<T> supplier) {
/* 215 */     doRegisterBean(beanClass, name, null, supplier, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void registerBean(Class<T> beanClass, @Nullable String name, @Nullable Supplier<T> supplier, BeanDefinitionCustomizer... customizers) {
/* 233 */     doRegisterBean(beanClass, name, null, supplier, customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> void doRegisterBean(Class<T> beanClass, @Nullable String name, @Nullable Class<? extends Annotation>[] qualifiers, @Nullable Supplier<T> supplier, @Nullable BeanDefinitionCustomizer[] customizers) {
/* 253 */     AnnotatedGenericBeanDefinition abd = new AnnotatedGenericBeanDefinition(beanClass);
/* 254 */     if (this.conditionEvaluator.shouldSkip((AnnotatedTypeMetadata)abd.getMetadata())) {
/*     */       return;
/*     */     }
/*     */     
/* 258 */     abd.setAttribute(ConfigurationClassUtils.CANDIDATE_ATTRIBUTE, Boolean.TRUE);
/* 259 */     abd.setInstanceSupplier(supplier);
/* 260 */     ScopeMetadata scopeMetadata = this.scopeMetadataResolver.resolveScopeMetadata((BeanDefinition)abd);
/* 261 */     abd.setScope(scopeMetadata.getScopeName());
/* 262 */     String beanName = (name != null) ? name : this.beanNameGenerator.generateBeanName((BeanDefinition)abd, this.registry);
/*     */     
/* 264 */     AnnotationConfigUtils.processCommonDefinitionAnnotations((AnnotatedBeanDefinition)abd);
/* 265 */     if (qualifiers != null) {
/* 266 */       for (Class<? extends Annotation> qualifier : qualifiers) {
/* 267 */         if (Primary.class == qualifier) {
/* 268 */           abd.setPrimary(true);
/*     */         }
/* 270 */         else if (Fallback.class == qualifier) {
/* 271 */           abd.setFallback(true);
/*     */         }
/* 273 */         else if (Lazy.class == qualifier) {
/* 274 */           abd.setLazyInit(true);
/*     */         } else {
/*     */           
/* 277 */           abd.addQualifier(new AutowireCandidateQualifier(qualifier));
/*     */         } 
/*     */       } 
/*     */     }
/* 281 */     if (customizers != null) {
/* 282 */       for (BeanDefinitionCustomizer customizer : customizers) {
/* 283 */         customizer.customize((BeanDefinition)abd);
/*     */       }
/*     */     }
/*     */     
/* 287 */     BeanDefinitionHolder definitionHolder = new BeanDefinitionHolder((BeanDefinition)abd, beanName);
/* 288 */     definitionHolder = AnnotationConfigUtils.applyScopedProxyMode(scopeMetadata, definitionHolder, this.registry);
/* 289 */     BeanDefinitionReaderUtils.registerBeanDefinition(definitionHolder, this.registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Environment getOrCreateEnvironment(BeanDefinitionRegistry registry) {
/* 298 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 299 */     if (registry instanceof EnvironmentCapable) { EnvironmentCapable environmentCapable = (EnvironmentCapable)registry;
/* 300 */       return environmentCapable.getEnvironment(); }
/*     */     
/* 302 */     return (Environment)new StandardEnvironment();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\AnnotatedBeanDefinitionReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */