/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConditionEvaluator
/*     */ {
/*     */   private final ConditionContextImpl context;
/*     */   
/*     */   public ConditionEvaluator(@Nullable BeanDefinitionRegistry registry, @Nullable Environment environment, @Nullable ResourceLoader resourceLoader) {
/*  59 */     this.context = new ConditionContextImpl(registry, environment, resourceLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldSkip(AnnotatedTypeMetadata metadata) {
/*  71 */     return shouldSkip(metadata, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldSkip(@Nullable AnnotatedTypeMetadata metadata, @Nullable ConfigurationCondition.ConfigurationPhase phase) {
/*  81 */     if (metadata == null || !metadata.isAnnotated(Conditional.class.getName())) {
/*  82 */       return false;
/*     */     }
/*     */     
/*  85 */     if (phase == null) {
/*  86 */       if (metadata instanceof AnnotationMetadata) { AnnotationMetadata annotationMetadata = (AnnotationMetadata)metadata;
/*  87 */         if (ConfigurationClassUtils.isConfigurationCandidate(annotationMetadata))
/*  88 */           return shouldSkip(metadata, ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION);  }
/*     */       
/*  90 */       return shouldSkip(metadata, ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*     */     } 
/*     */     
/*  93 */     List<Condition> conditions = collectConditions(metadata);
/*  94 */     for (Condition condition : conditions) {
/*  95 */       ConfigurationCondition.ConfigurationPhase requiredPhase = null;
/*  96 */       if (condition instanceof ConfigurationCondition) { ConfigurationCondition configurationCondition = (ConfigurationCondition)condition;
/*  97 */         requiredPhase = configurationCondition.getConfigurationPhase(); }
/*     */       
/*  99 */       if ((requiredPhase == null || requiredPhase == phase) && !condition.matches(this.context, metadata)) {
/* 100 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<Condition> collectConditions(@Nullable AnnotatedTypeMetadata metadata) {
/* 114 */     if (metadata == null || !metadata.isAnnotated(Conditional.class.getName())) {
/* 115 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 118 */     List<Condition> conditions = new ArrayList<>();
/* 119 */     for (String[] conditionClasses : getConditionClasses(metadata)) {
/* 120 */       for (String conditionClass : conditionClasses) {
/* 121 */         Condition condition = getCondition(conditionClass, this.context.getClassLoader());
/* 122 */         conditions.add(condition);
/*     */       } 
/*     */     } 
/* 125 */     AnnotationAwareOrderComparator.sort(conditions);
/* 126 */     return conditions;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<String[]> getConditionClasses(AnnotatedTypeMetadata metadata) {
/* 131 */     MultiValueMap<String, Object> attributes = metadata.getAllAnnotationAttributes(Conditional.class.getName(), true);
/* 132 */     Object values = (attributes != null) ? attributes.get("value") : null;
/* 133 */     return (values != null) ? (List<String[]>)values : (List)Collections.<String[]>emptyList();
/*     */   }
/*     */   
/*     */   private Condition getCondition(String conditionClassName, @Nullable ClassLoader classloader) {
/* 137 */     Class<?> conditionClass = ClassUtils.resolveClassName(conditionClassName, classloader);
/* 138 */     return (Condition)BeanUtils.instantiateClass(conditionClass);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConditionContextImpl
/*     */     implements ConditionContext
/*     */   {
/*     */     @Nullable
/*     */     private final BeanDefinitionRegistry registry;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final ConfigurableListableBeanFactory beanFactory;
/*     */ 
/*     */     
/*     */     private final Environment environment;
/*     */     
/*     */     private final ResourceLoader resourceLoader;
/*     */     
/*     */     @Nullable
/*     */     private final ClassLoader classLoader;
/*     */ 
/*     */     
/*     */     public ConditionContextImpl(@Nullable BeanDefinitionRegistry registry, @Nullable Environment environment, @Nullable ResourceLoader resourceLoader) {
/* 163 */       this.registry = registry;
/* 164 */       this.beanFactory = deduceBeanFactory(registry);
/* 165 */       this.environment = (environment != null) ? environment : deduceEnvironment(registry);
/* 166 */       this.resourceLoader = (resourceLoader != null) ? resourceLoader : deduceResourceLoader(registry);
/* 167 */       this.classLoader = deduceClassLoader(resourceLoader, this.beanFactory);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private static ConfigurableListableBeanFactory deduceBeanFactory(@Nullable BeanDefinitionRegistry source) {
/* 172 */       if (source instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory configurableListableBeanFactory = (ConfigurableListableBeanFactory)source;
/* 173 */         return configurableListableBeanFactory; }
/*     */       
/* 175 */       if (source instanceof ConfigurableApplicationContext) { ConfigurableApplicationContext configurableApplicationContext = (ConfigurableApplicationContext)source;
/* 176 */         return configurableApplicationContext.getBeanFactory(); }
/*     */       
/* 178 */       return null;
/*     */     }
/*     */     
/*     */     private static Environment deduceEnvironment(@Nullable BeanDefinitionRegistry source) {
/* 182 */       if (source instanceof EnvironmentCapable) { EnvironmentCapable environmentCapable = (EnvironmentCapable)source;
/* 183 */         return environmentCapable.getEnvironment(); }
/*     */       
/* 185 */       return (Environment)new StandardEnvironment();
/*     */     }
/*     */     
/*     */     private static ResourceLoader deduceResourceLoader(@Nullable BeanDefinitionRegistry source) {
/* 189 */       if (source instanceof ResourceLoader) { ResourceLoader resourceLoader = (ResourceLoader)source;
/* 190 */         return resourceLoader; }
/*     */       
/* 192 */       return (ResourceLoader)new DefaultResourceLoader();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private static ClassLoader deduceClassLoader(@Nullable ResourceLoader resourceLoader, @Nullable ConfigurableListableBeanFactory beanFactory) {
/* 199 */       if (resourceLoader != null) {
/* 200 */         ClassLoader classLoader = resourceLoader.getClassLoader();
/* 201 */         if (classLoader != null) {
/* 202 */           return classLoader;
/*     */         }
/*     */       } 
/* 205 */       if (beanFactory != null) {
/* 206 */         return beanFactory.getBeanClassLoader();
/*     */       }
/* 208 */       return ClassUtils.getDefaultClassLoader();
/*     */     }
/*     */ 
/*     */     
/*     */     public BeanDefinitionRegistry getRegistry() {
/* 213 */       Assert.state((this.registry != null), "No BeanDefinitionRegistry available");
/* 214 */       return this.registry;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public ConfigurableListableBeanFactory getBeanFactory() {
/* 220 */       return this.beanFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     public Environment getEnvironment() {
/* 225 */       return this.environment;
/*     */     }
/*     */ 
/*     */     
/*     */     public ResourceLoader getResourceLoader() {
/* 230 */       return this.resourceLoader;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public ClassLoader getClassLoader() {
/* 236 */       return this.classLoader;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConditionEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */