package org.springframework.context.annotation;

import org.springframework.instrument.classloading.LoadTimeWeaver;

public interface LoadTimeWeavingConfigurer {
  LoadTimeWeaver getLoadTimeWeaver();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\LoadTimeWeavingConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */