/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.aot.AotDetector;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.support.SimpleInstantiationStrategy;
/*     */ import org.springframework.cglib.core.NamingPolicy;
/*     */ import org.springframework.cglib.core.SpringNamingPolicy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.Factory;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.objenesis.ObjenesisException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanMethodInterceptor
/*     */   implements MethodInterceptor, ConfigurationClassEnhancer.ConditionalCallback
/*     */ {
/*     */   @Nullable
/*     */   public Object intercept(Object enhancedConfigInstance, Method beanMethod, Object[] beanMethodArgs, MethodProxy cglibMethodProxy) throws Throwable {
/* 356 */     ConfigurableBeanFactory beanFactory = getBeanFactory(enhancedConfigInstance);
/* 357 */     String beanName = BeanAnnotationHelper.determineBeanNameFor(beanMethod);
/*     */ 
/*     */     
/* 360 */     if (BeanAnnotationHelper.isScopedProxy(beanMethod)) {
/* 361 */       String scopedBeanName = ScopedProxyCreator.getTargetBeanName(beanName);
/* 362 */       if (beanFactory.isCurrentlyInCreation(scopedBeanName)) {
/* 363 */         beanName = scopedBeanName;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 374 */     String factoryBeanName = "&" + beanName;
/* 375 */     if (factoryContainsBean(beanFactory, factoryBeanName) && factoryContainsBean(beanFactory, beanName)) {
/* 376 */       Object factoryBean = beanFactory.getBean(factoryBeanName);
/* 377 */       if (!(factoryBean instanceof org.springframework.aop.scope.ScopedProxyFactoryBean))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 382 */         return enhanceFactoryBean(factoryBean, beanMethod.getReturnType(), beanFactory, beanName);
/*     */       }
/*     */     } 
/*     */     
/* 386 */     if (isCurrentlyInvokedFactoryMethod(beanMethod)) {
/*     */ 
/*     */ 
/*     */       
/* 390 */       if (ConfigurationClassEnhancer.logger.isInfoEnabled() && BeanFactoryPostProcessor.class
/* 391 */         .isAssignableFrom(beanMethod.getReturnType())) {
/* 392 */         ConfigurationClassEnhancer.logger.info(String.format("@Bean method %s.%s is non-static and returns an object assignable to Spring's BeanFactoryPostProcessor interface. This will result in a failure to process annotations such as @Autowired, @Resource and @PostConstruct within the method's declaring @Configuration class. Add the 'static' modifier to this method to avoid these container lifecycle issues; see @Bean javadoc for complete details.", new Object[] { beanMethod
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 398 */                 .getDeclaringClass().getSimpleName(), beanMethod.getName() }));
/*     */       }
/* 400 */       return cglibMethodProxy.invokeSuper(enhancedConfigInstance, beanMethodArgs);
/*     */     } 
/*     */     
/* 403 */     return resolveBeanReference(beanMethod, beanMethodArgs, beanFactory, beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object resolveBeanReference(Method beanMethod, Object[] beanMethodArgs, ConfigurableBeanFactory beanFactory, String beanName) {
/* 414 */     boolean alreadyInCreation = beanFactory.isCurrentlyInCreation(beanName);
/*     */     try {
/* 416 */       if (alreadyInCreation) {
/* 417 */         beanFactory.setCurrentlyInCreation(beanName, false);
/*     */       }
/* 419 */       boolean useArgs = !ObjectUtils.isEmpty(beanMethodArgs);
/* 420 */       if (useArgs && beanFactory.isSingleton(beanName))
/*     */       {
/*     */ 
/*     */         
/* 424 */         for (Object arg : beanMethodArgs) {
/* 425 */           if (arg == null) {
/* 426 */             useArgs = false;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 432 */       Object beanInstance = useArgs ? beanFactory.getBean(beanName, beanMethodArgs) : beanFactory.getBean(beanName);
/* 433 */       if (!ClassUtils.isAssignableValue(beanMethod.getReturnType(), beanInstance))
/*     */       {
/* 435 */         if (beanInstance.equals(null)) {
/* 436 */           if (ConfigurationClassEnhancer.logger.isDebugEnabled()) {
/* 437 */             ConfigurationClassEnhancer.logger.debug(String.format("@Bean method %s.%s called as bean reference for type [%s] returned null bean; resolving to null value.", new Object[] { beanMethod
/*     */                     
/* 439 */                     .getDeclaringClass().getSimpleName(), beanMethod.getName(), beanMethod
/* 440 */                     .getReturnType().getName() }));
/*     */           }
/* 442 */           beanInstance = null;
/*     */         } else {
/*     */           
/* 445 */           String msg = String.format("@Bean method %s.%s called as bean reference for type [%s] but overridden by non-compatible bean instance of type [%s].", new Object[] { beanMethod
/*     */                 
/* 447 */                 .getDeclaringClass().getSimpleName(), beanMethod.getName(), beanMethod
/* 448 */                 .getReturnType().getName(), beanInstance.getClass().getName() });
/*     */           try {
/* 450 */             BeanDefinition beanDefinition = beanFactory.getMergedBeanDefinition(beanName);
/* 451 */             msg = msg + " Overriding bean of same name declared in: " + msg;
/*     */           }
/* 453 */           catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */ 
/*     */           
/* 456 */           throw new IllegalStateException(msg);
/*     */         } 
/*     */       }
/* 459 */       Method currentlyInvoked = SimpleInstantiationStrategy.getCurrentlyInvokedFactoryMethod();
/* 460 */       if (currentlyInvoked != null) {
/* 461 */         String outerBeanName = BeanAnnotationHelper.determineBeanNameFor(currentlyInvoked);
/* 462 */         beanFactory.registerDependentBean(beanName, outerBeanName);
/*     */       } 
/* 464 */       return beanInstance;
/*     */     } finally {
/*     */       
/* 467 */       if (alreadyInCreation) {
/* 468 */         beanFactory.setCurrentlyInCreation(beanName, true);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMatch(Method candidateMethod) {
/* 475 */     return (candidateMethod.getDeclaringClass() != Object.class && 
/* 476 */       !ConfigurationClassEnhancer.BeanFactoryAwareMethodInterceptor.isSetBeanFactory(candidateMethod) && 
/* 477 */       BeanAnnotationHelper.isBeanAnnotated(candidateMethod));
/*     */   }
/*     */   
/*     */   private ConfigurableBeanFactory getBeanFactory(Object enhancedConfigInstance) {
/* 481 */     Field field = ReflectionUtils.findField(enhancedConfigInstance.getClass(), "$$beanFactory");
/* 482 */     Assert.state((field != null), "Unable to find generated bean factory field");
/* 483 */     Object beanFactory = ReflectionUtils.getField(field, enhancedConfigInstance);
/* 484 */     Assert.state((beanFactory != null), "BeanFactory has not been injected into @Configuration class");
/* 485 */     Assert.state(beanFactory instanceof ConfigurableBeanFactory, "Injected BeanFactory is not a ConfigurableBeanFactory");
/*     */     
/* 487 */     return (ConfigurableBeanFactory)beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean factoryContainsBean(ConfigurableBeanFactory beanFactory, String beanName) {
/* 504 */     return (beanFactory.containsBean(beanName) && !beanFactory.isCurrentlyInCreation(beanName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isCurrentlyInvokedFactoryMethod(Method method) {
/* 514 */     Method currentlyInvoked = SimpleInstantiationStrategy.getCurrentlyInvokedFactoryMethod();
/* 515 */     return (currentlyInvoked != null && method.getName().equals(currentlyInvoked.getName()) && 
/* 516 */       Arrays.equals((Object[])method.getParameterTypes(), (Object[])currentlyInvoked.getParameterTypes()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object enhanceFactoryBean(Object factoryBean, Class<?> exposedType, ConfigurableBeanFactory beanFactory, String beanName) {
/*     */     try {
/* 530 */       Class<?> clazz = factoryBean.getClass();
/* 531 */       boolean finalClass = Modifier.isFinal(clazz.getModifiers());
/* 532 */       boolean finalMethod = Modifier.isFinal(clazz.getMethod("getObject", new Class[0]).getModifiers());
/* 533 */       if (finalClass || finalMethod) {
/* 534 */         if (exposedType.isInterface()) {
/* 535 */           if (ConfigurationClassEnhancer.logger.isTraceEnabled()) {
/* 536 */             ConfigurationClassEnhancer.logger.trace("Creating interface proxy for FactoryBean '" + beanName + "' of type [" + clazz
/* 537 */                 .getName() + "] for use within another @Bean method because its " + (
/* 538 */                 finalClass ? "implementation class" : "getObject() method") + " is final: Otherwise a getObject() call would not be routed to the factory.");
/*     */           }
/*     */           
/* 541 */           return createInterfaceProxyForFactoryBean(factoryBean, exposedType, beanFactory, beanName);
/*     */         } 
/*     */         
/* 544 */         if (ConfigurationClassEnhancer.logger.isDebugEnabled()) {
/* 545 */           ConfigurationClassEnhancer.logger.debug("Unable to proxy FactoryBean '" + beanName + "' of type [" + clazz
/* 546 */               .getName() + "] for use within another @Bean method because its " + (
/* 547 */               finalClass ? "implementation class" : "getObject() method") + " is final: A getObject() call will NOT be routed to the factory. Consider declaring the return type as a FactoryBean interface.");
/*     */         }
/*     */ 
/*     */         
/* 551 */         return factoryBean;
/*     */       }
/*     */     
/*     */     }
/* 555 */     catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */ 
/*     */     
/* 559 */     return createCglibProxyForFactoryBean(factoryBean, beanFactory, beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object createInterfaceProxyForFactoryBean(Object factoryBean, Class<?> interfaceType, ConfigurableBeanFactory beanFactory, String beanName) {
/* 565 */     return Proxy.newProxyInstance(factoryBean
/* 566 */         .getClass().getClassLoader(), new Class[] { interfaceType
/*     */         },
/* 568 */         (proxy, method, args) -> (method.getName().equals("getObject") && args == null) ? beanFactory.getBean(beanName) : ReflectionUtils.invokeMethod(method, factoryBean, args));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object createCglibProxyForFactoryBean(Object factoryBean, ConfigurableBeanFactory beanFactory, String beanName) {
/* 578 */     Enhancer enhancer = new Enhancer();
/* 579 */     enhancer.setSuperclass(factoryBean.getClass());
/* 580 */     enhancer.setNamingPolicy((NamingPolicy)SpringNamingPolicy.INSTANCE);
/* 581 */     enhancer.setAttemptLoad(AotDetector.useGeneratedArtifacts());
/* 582 */     enhancer.setCallbackType(MethodInterceptor.class);
/*     */ 
/*     */ 
/*     */     
/* 586 */     Class<?> fbClass = enhancer.createClass();
/* 587 */     Object fbProxy = null;
/*     */     
/* 589 */     if (ConfigurationClassEnhancer.objenesis.isWorthTrying()) {
/*     */       try {
/* 591 */         fbProxy = ConfigurationClassEnhancer.objenesis.newInstance(fbClass, enhancer.getUseCache());
/*     */       }
/* 593 */       catch (ObjenesisException ex) {
/* 594 */         ConfigurationClassEnhancer.logger.debug("Unable to instantiate enhanced FactoryBean using Objenesis, falling back to regular construction", (Throwable)ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 599 */     if (fbProxy == null) {
/*     */       try {
/* 601 */         fbProxy = ReflectionUtils.accessibleConstructor(fbClass, new Class[0]).newInstance(new Object[0]);
/*     */       }
/* 603 */       catch (Throwable ex) {
/* 604 */         throw new IllegalStateException("Unable to instantiate enhanced FactoryBean using Objenesis, and regular FactoryBean instantiation via default constructor fails as well", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 609 */     ((Factory)fbProxy).setCallback(0, (Callback)((obj, method, args, proxy) -> 
/* 610 */         (method.getName().equals("getObject") && args.length == 0) ? beanFactory.getBean(beanName) : method.invoke(factoryBean, args)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 616 */     return fbProxy;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConfigurationClassEnhancer$BeanMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */