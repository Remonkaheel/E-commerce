/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum FilterType
/*    */ {
/* 38 */   ANNOTATION,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   ASSIGNABLE_TYPE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   ASPECTJ,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   REGEX,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   CUSTOM;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\FilterType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */