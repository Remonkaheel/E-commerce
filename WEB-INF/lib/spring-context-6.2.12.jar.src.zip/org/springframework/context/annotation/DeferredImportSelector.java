/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface DeferredImportSelector
/*     */   extends ImportSelector
/*     */ {
/*     */   @Nullable
/*     */   default Class<? extends Group> getImportGroup() {
/*  48 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Group
/*     */   {
/*     */     void process(AnnotationMetadata param1AnnotationMetadata, DeferredImportSelector param1DeferredImportSelector);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Iterable<Entry> selectImports();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class Entry
/*     */     {
/*     */       private final AnnotationMetadata metadata;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final String importClassName;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Entry(AnnotationMetadata metadata, String importClassName) {
/*  82 */         this.metadata = metadata;
/*  83 */         this.importClassName = importClassName;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public AnnotationMetadata getMetadata() {
/*  91 */         return this.metadata;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getImportClassName() {
/*  98 */         return this.importClassName;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(@Nullable Object other) {
/* 103 */         if (this == other) {
/* 104 */           return true;
/*     */         }
/* 106 */         if (other == null || getClass() != other.getClass()) {
/* 107 */           return false;
/*     */         }
/* 109 */         Entry entry = (Entry)other;
/* 110 */         return (this.metadata.equals(entry.metadata) && this.importClassName.equals(entry.importClassName));
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/* 115 */         return this.metadata.hashCode() * 31 + this.importClassName.hashCode();
/*     */       }
/*     */       
/*     */       public String toString()
/*     */       {
/* 120 */         return this.importClassName; } } } public static class Entry { public String toString() { return this.importClassName; }
/*     */ 
/*     */     
/*     */     private final AnnotationMetadata metadata;
/*     */     private final String importClassName;
/*     */     
/*     */     public Entry(AnnotationMetadata metadata, String importClassName) {
/*     */       this.metadata = metadata;
/*     */       this.importClassName = importClassName;
/*     */     }
/*     */     
/*     */     public AnnotationMetadata getMetadata() {
/*     */       return this.metadata;
/*     */     }
/*     */     
/*     */     public String getImportClassName() {
/*     */       return this.importClassName;
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/*     */       if (this == other)
/*     */         return true; 
/*     */       if (other == null || getClass() != other.getClass())
/*     */         return false; 
/*     */       Entry entry = (Entry)other;
/*     */       return (this.metadata.equals(entry.metadata) && this.importClassName.equals(entry.importClassName));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return this.metadata.hashCode() * 31 + this.importClassName.hashCode();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\DeferredImportSelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */