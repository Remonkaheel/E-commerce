/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*    */ import org.springframework.core.PriorityOrdered;
/*    */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*    */ import org.springframework.core.type.classreading.MetadataReader;
/*    */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ImportAwareAotBeanPostProcessor
/*    */   implements BeanPostProcessor, PriorityOrdered
/*    */ {
/*    */   private final MetadataReaderFactory metadataReaderFactory;
/*    */   private final Map<String, String> importsMapping;
/*    */   
/*    */   public ImportAwareAotBeanPostProcessor(Map<String, String> importsMapping) {
/* 46 */     this.metadataReaderFactory = (MetadataReaderFactory)new CachingMetadataReaderFactory();
/* 47 */     this.importsMapping = Map.copyOf(importsMapping);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object postProcessBeforeInitialization(Object bean, String beanName) {
/* 53 */     if (bean instanceof ImportAware) { ImportAware importAware = (ImportAware)bean;
/* 54 */       setAnnotationMetadata(importAware); }
/*    */     
/* 56 */     return bean;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 61 */     return Integer.MAX_VALUE;
/*    */   }
/*    */   
/*    */   private void setAnnotationMetadata(ImportAware instance) {
/* 65 */     String importingClass = getImportingClassFor(instance);
/* 66 */     if (importingClass == null) {
/*    */       return;
/*    */     }
/*    */     try {
/* 70 */       MetadataReader metadataReader = this.metadataReaderFactory.getMetadataReader(importingClass);
/* 71 */       instance.setImportMetadata(metadataReader.getAnnotationMetadata());
/*    */     }
/* 73 */     catch (IOException ex) {
/* 74 */       throw new IllegalStateException(String.format("Failed to read metadata for '%s'", new Object[] { importingClass }), ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   private String getImportingClassFor(ImportAware instance) {
/* 80 */     String target = ClassUtils.getUserClass(instance).getName();
/* 81 */     return this.importsMapping.get(target);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ImportAwareAotBeanPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */