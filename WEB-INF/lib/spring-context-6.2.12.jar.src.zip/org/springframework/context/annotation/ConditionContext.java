package org.springframework.context.annotation;

import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ResourceLoader;
import org.springframework.lang.Nullable;

public interface ConditionContext {
  BeanDefinitionRegistry getRegistry();
  
  @Nullable
  ConfigurableListableBeanFactory getBeanFactory();
  
  Environment getEnvironment();
  
  ResourceLoader getResourceLoader();
  
  @Nullable
  ClassLoader getClassLoader();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConditionContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */