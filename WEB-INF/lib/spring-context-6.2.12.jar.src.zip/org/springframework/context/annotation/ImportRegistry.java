package org.springframework.context.annotation;

import org.springframework.core.type.AnnotationMetadata;
import org.springframework.lang.Nullable;

interface ImportRegistry {
  @Nullable
  AnnotationMetadata getImportingClassFor(String paramString);
  
  void removeImportingClass(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ImportRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */