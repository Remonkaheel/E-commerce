/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import org.springframework.aop.config.AopConfigUtils;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AspectJAutoProxyRegistrar
/*    */   implements ImportBeanDefinitionRegistrar
/*    */ {
/*    */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 45 */     AopConfigUtils.registerAspectJAnnotationAutoProxyCreatorIfNecessary(registry);
/*    */ 
/*    */     
/* 48 */     AnnotationAttributes enableAspectJAutoProxy = AnnotationConfigUtils.attributesFor((AnnotatedTypeMetadata)importingClassMetadata, EnableAspectJAutoProxy.class);
/* 49 */     if (enableAspectJAutoProxy != null) {
/* 50 */       if (enableAspectJAutoProxy.getBoolean("proxyTargetClass")) {
/* 51 */         AopConfigUtils.forceAutoProxyCreatorToUseClassProxying(registry);
/*    */       }
/* 53 */       if (enableAspectJAutoProxy.getBoolean("exposeProxy"))
/* 54 */         AopConfigUtils.forceAutoProxyCreatorToExposeProxy(registry); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\AspectJAutoProxyRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */