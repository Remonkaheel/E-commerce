/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReader;
/*     */ import org.springframework.core.io.DescriptiveResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ConfigurationClass
/*     */ {
/*     */   private final AnnotationMetadata metadata;
/*     */   private final Resource resource;
/*     */   @Nullable
/*     */   private String beanName;
/*     */   private boolean scanned = false;
/*  61 */   private final Set<ConfigurationClass> importedBy = new LinkedHashSet<>(1);
/*     */   
/*  63 */   private final Set<BeanMethod> beanMethods = new LinkedHashSet<>();
/*     */   
/*  65 */   private final Map<String, Class<? extends BeanDefinitionReader>> importedResources = new LinkedHashMap<>();
/*     */ 
/*     */   
/*  68 */   private final Map<ImportBeanDefinitionRegistrar, AnnotationMetadata> importBeanDefinitionRegistrars = new LinkedHashMap<>();
/*     */ 
/*     */   
/*  71 */   final Set<String> skippedBeanMethods = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigurationClass(MetadataReader metadataReader, String beanName) {
/*  80 */     Assert.notNull(beanName, "Bean name must not be null");
/*  81 */     this.metadata = metadataReader.getAnnotationMetadata();
/*  82 */     this.resource = metadataReader.getResource();
/*  83 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigurationClass(MetadataReader metadataReader, ConfigurationClass importedBy) {
/*  95 */     this.metadata = metadataReader.getAnnotationMetadata();
/*  96 */     this.resource = metadataReader.getResource();
/*  97 */     this.importedBy.add(importedBy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigurationClass(Class<?> clazz, String beanName) {
/* 106 */     Assert.notNull(beanName, "Bean name must not be null");
/* 107 */     this.metadata = AnnotationMetadata.introspect(clazz);
/* 108 */     this.resource = (Resource)new DescriptiveResource(clazz.getName());
/* 109 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigurationClass(Class<?> clazz, ConfigurationClass importedBy) {
/* 121 */     this.metadata = AnnotationMetadata.introspect(clazz);
/* 122 */     this.resource = (Resource)new DescriptiveResource(clazz.getName());
/* 123 */     this.importedBy.add(importedBy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigurationClass(AnnotationMetadata metadata, String beanName, boolean scanned) {
/* 134 */     Assert.notNull(beanName, "Bean name must not be null");
/* 135 */     this.metadata = metadata;
/* 136 */     this.resource = (Resource)new DescriptiveResource(metadata.getClassName());
/* 137 */     this.beanName = beanName;
/* 138 */     this.scanned = scanned;
/*     */   }
/*     */ 
/*     */   
/*     */   AnnotationMetadata getMetadata() {
/* 143 */     return this.metadata;
/*     */   }
/*     */   
/*     */   Resource getResource() {
/* 147 */     return this.resource;
/*     */   }
/*     */   
/*     */   String getSimpleName() {
/* 151 */     return ClassUtils.getShortName(getMetadata().getClassName());
/*     */   }
/*     */   
/*     */   void setBeanName(@Nullable String beanName) {
/* 155 */     this.beanName = beanName;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   String getBeanName() {
/* 160 */     return this.beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isScanned() {
/* 168 */     return this.scanned;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isImported() {
/* 178 */     return !this.importedBy.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void mergeImportedBy(ConfigurationClass otherConfigClass) {
/* 186 */     this.importedBy.addAll(otherConfigClass.importedBy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Set<ConfigurationClass> getImportedBy() {
/* 196 */     return this.importedBy;
/*     */   }
/*     */   
/*     */   void addBeanMethod(BeanMethod method) {
/* 200 */     this.beanMethods.add(method);
/*     */   }
/*     */   
/*     */   Set<BeanMethod> getBeanMethods() {
/* 204 */     return this.beanMethods;
/*     */   }
/*     */   
/*     */   boolean hasNonStaticBeanMethods() {
/* 208 */     for (BeanMethod beanMethod : this.beanMethods) {
/* 209 */       if (!beanMethod.getMetadata().isStatic()) {
/* 210 */         return true;
/*     */       }
/*     */     } 
/* 213 */     return false;
/*     */   }
/*     */   
/*     */   void addImportedResource(String importedResource, Class<? extends BeanDefinitionReader> readerClass) {
/* 217 */     this.importedResources.put(importedResource, readerClass);
/*     */   }
/*     */   
/*     */   Map<String, Class<? extends BeanDefinitionReader>> getImportedResources() {
/* 221 */     return this.importedResources;
/*     */   }
/*     */   
/*     */   void addImportBeanDefinitionRegistrar(ImportBeanDefinitionRegistrar registrar, AnnotationMetadata importingClassMetadata) {
/* 225 */     this.importBeanDefinitionRegistrars.put(registrar, importingClassMetadata);
/*     */   }
/*     */   
/*     */   Map<ImportBeanDefinitionRegistrar, AnnotationMetadata> getImportBeanDefinitionRegistrars() {
/* 229 */     return this.importBeanDefinitionRegistrars;
/*     */   }
/*     */ 
/*     */   
/*     */   void validate(ProblemReporter problemReporter) {
/* 234 */     Map<String, Object> attributes = this.metadata.getAnnotationAttributes(Configuration.class.getName());
/*     */ 
/*     */     
/* 237 */     if (attributes != null && ((Boolean)attributes.get("proxyBeanMethods")).booleanValue() && hasNonStaticBeanMethods() && this.metadata
/* 238 */       .isFinal()) {
/* 239 */       problemReporter.error(new FinalConfigurationProblem());
/*     */     }
/*     */     
/* 242 */     for (BeanMethod beanMethod : this.beanMethods) {
/* 243 */       beanMethod.validate(problemReporter);
/*     */     }
/*     */ 
/*     */     
/* 247 */     if (attributes != null && ((Boolean)attributes.get("enforceUniqueMethods")).booleanValue()) {
/* 248 */       Map<String, MethodMetadata> beanMethodsByName = new LinkedHashMap<>();
/* 249 */       for (BeanMethod beanMethod : this.beanMethods) {
/* 250 */         MethodMetadata current = beanMethod.getMetadata();
/* 251 */         MethodMetadata existing = beanMethodsByName.put(current.getMethodName(), current);
/* 252 */         if (existing != null && existing.getDeclaringClassName().equals(current.getDeclaringClassName())) {
/* 253 */           problemReporter.error(new BeanMethodOverloadingProblem(existing.getMethodName()));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 261 */     if (this != other) { if (other instanceof ConfigurationClass) { ConfigurationClass that = (ConfigurationClass)other;
/* 262 */         if (getMetadata().getClassName().equals(that.getMetadata().getClassName())); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 267 */     return getMetadata().getClassName().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 272 */     return "ConfigurationClass: beanName '" + this.beanName + "', " + String.valueOf(this.resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class FinalConfigurationProblem
/*     */     extends Problem
/*     */   {
/*     */     FinalConfigurationProblem() {
/* 282 */       super(String.format("@Configuration class '%s' may not be final. Remove the final modifier to continue.", new Object[] { this$0
/* 283 */               .getSimpleName() }), new Location(ConfigurationClass.this.getResource(), ConfigurationClass.this.getMetadata()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class BeanMethodOverloadingProblem
/*     */     extends Problem
/*     */   {
/*     */     BeanMethodOverloadingProblem(String methodName) {
/* 295 */       super(String.format("@Configuration class '%s' contains overloaded @Bean methods with name '%s'. Use unique method names for separate bean definitions (with individual conditions etc) or switch '@Configuration.enforceUniqueMethods' to 'false'.", new Object[] { this$0
/*     */ 
/*     */               
/* 298 */               .getSimpleName(), methodName }), new Location(ConfigurationClass.this.getResource(), ConfigurationClass.this.getMetadata()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConfigurationClass.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */