/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PropertySourceDescriptor;
/*     */ import org.springframework.core.io.support.PropertySourceProcessor;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PropertySourcesAotContribution
/*     */   implements BeanFactoryInitializationAotContribution
/*     */ {
/*     */   private static final String ENVIRONMENT_VARIABLE = "environment";
/*     */   private static final String RESOURCE_LOADER_VARIABLE = "resourceLoader";
/* 666 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final List<PropertySourceDescriptor> descriptors;
/*     */   
/*     */   private final Function<String, Resource> resourceResolver;
/*     */   
/*     */   PropertySourcesAotContribution(List<PropertySourceDescriptor> descriptors, Function<String, Resource> resourceResolver) {
/* 673 */     this.descriptors = descriptors;
/* 674 */     this.resourceResolver = resourceResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 679 */     registerRuntimeHints(generationContext.getRuntimeHints());
/*     */     
/* 681 */     GeneratedMethod generatedMethod = beanFactoryInitializationCode.getMethods().add("processPropertySources", this::generateAddPropertySourceProcessorMethod);
/* 682 */     beanFactoryInitializationCode.addInitializer(generatedMethod.toMethodReference());
/*     */   }
/*     */   
/*     */   private void registerRuntimeHints(RuntimeHints hints) {
/* 686 */     for (PropertySourceDescriptor descriptor : this.descriptors) {
/* 687 */       Class<?> factoryClass = descriptor.propertySourceFactory();
/* 688 */       if (factoryClass != null) {
/* 689 */         hints.reflection().registerType(factoryClass, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*     */       }
/* 691 */       for (String location : descriptor.locations()) {
/* 692 */         if (location.startsWith("classpath*:") || (location
/* 693 */           .startsWith("classpath:") && (location
/* 694 */           .contains("*") || location.contains("?")))) {
/*     */           
/* 696 */           if (this.logger.isWarnEnabled()) {
/* 697 */             this.logger.warn("Runtime hint registration is not supported for the 'classpath*:' prefix or wildcards in @PropertySource locations. Please manually register a resource hint for each property source location represented by '%s'."
/*     */ 
/*     */ 
/*     */                 
/* 701 */                 .formatted(new Object[] { location }));
/*     */           }
/*     */           continue;
/*     */         } 
/* 705 */         Resource resource = this.resourceResolver.apply(location);
/* 706 */         if (resource instanceof ClassPathResource) { ClassPathResource classPathResource = (ClassPathResource)resource; if (classPathResource.exists()) {
/* 707 */             hints.resources().registerPattern(classPathResource.getPath());
/*     */           } }
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void generateAddPropertySourceProcessorMethod(MethodSpec.Builder method) {
/* 715 */     method.addJavadoc("Apply known @PropertySources to the environment.", new Object[0]);
/* 716 */     method.addModifiers(new Modifier[] { Modifier.PRIVATE });
/* 717 */     method.addParameter(ConfigurableEnvironment.class, "environment", new Modifier[0]);
/* 718 */     method.addParameter(ResourceLoader.class, "resourceLoader", new Modifier[0]);
/* 719 */     method.addCode(generateAddPropertySourceProcessorCode());
/*     */   }
/*     */   
/*     */   private CodeBlock generateAddPropertySourceProcessorCode() {
/* 723 */     CodeBlock.Builder code = CodeBlock.builder();
/* 724 */     String processorVariable = "processor";
/* 725 */     code.addStatement("$T $L = new $T($L, $L)", new Object[] { PropertySourceProcessor.class, processorVariable, PropertySourceProcessor.class, "environment", "resourceLoader" });
/*     */ 
/*     */     
/* 728 */     code.beginControlFlow("try", new Object[0]);
/* 729 */     for (PropertySourceDescriptor descriptor : this.descriptors) {
/* 730 */       code.addStatement("$L.processPropertySource($L)", new Object[] { processorVariable, 
/* 731 */             generatePropertySourceDescriptorCode(descriptor) });
/*     */     } 
/* 733 */     code.nextControlFlow("catch ($T ex)", new Object[] { IOException.class });
/* 734 */     code.addStatement("throw new $T(ex)", new Object[] { UncheckedIOException.class });
/* 735 */     code.endControlFlow();
/* 736 */     return code.build();
/*     */   }
/*     */   
/*     */   private CodeBlock generatePropertySourceDescriptorCode(PropertySourceDescriptor descriptor) {
/* 740 */     CodeBlock.Builder code = CodeBlock.builder();
/* 741 */     code.add("new $T(", new Object[] { PropertySourceDescriptor.class });
/*     */     
/* 743 */     CodeBlock values = (CodeBlock)descriptor.locations().stream().map(value -> CodeBlock.of("$S", new Object[] { value })).collect(CodeBlock.joining(", "));
/* 744 */     if (descriptor.name() == null && descriptor.propertySourceFactory() == null && descriptor
/* 745 */       .encoding() == null && !descriptor.ignoreResourceNotFound()) {
/* 746 */       code.add("$L)", new Object[] { values });
/*     */     } else {
/*     */       
/* 749 */       List<CodeBlock> arguments = new ArrayList<>();
/* 750 */       arguments.add(CodeBlock.of("$T.of($L)", new Object[] { List.class, values }));
/* 751 */       arguments.add(CodeBlock.of("$L", new Object[] { Boolean.valueOf(descriptor.ignoreResourceNotFound()) }));
/* 752 */       arguments.add(handleNull(descriptor.name(), () -> CodeBlock.of("$S", new Object[] { descriptor.name() })));
/* 753 */       arguments.add(handleNull(descriptor.propertySourceFactory(), () -> CodeBlock.of("$T.class", new Object[] { descriptor.propertySourceFactory() })));
/*     */       
/* 755 */       arguments.add(handleNull(descriptor.encoding(), () -> CodeBlock.of("$S", new Object[] { descriptor.encoding() })));
/*     */       
/* 757 */       code.add(CodeBlock.join(arguments, ", "));
/* 758 */       code.add(")", new Object[0]);
/*     */     } 
/* 760 */     return code.build();
/*     */   }
/*     */   
/*     */   private CodeBlock handleNull(@Nullable Object value, Supplier<CodeBlock> nonNull) {
/* 764 */     return (value == null) ? CodeBlock.of("null", new Object[0]) : nonNull.get();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConfigurationClassPostProcessor$PropertySourcesAotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */