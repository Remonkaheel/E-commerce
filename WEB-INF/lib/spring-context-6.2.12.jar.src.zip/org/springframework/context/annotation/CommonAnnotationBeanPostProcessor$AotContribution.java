/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.AccessControl;
/*     */ import org.springframework.aot.generate.GeneratedClass;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.support.ClassHintUtils;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AotContribution
/*     */   implements BeanRegistrationAotContribution
/*     */ {
/*     */   private static final String REGISTERED_BEAN_PARAMETER = "registeredBean";
/*     */   private static final String INSTANCE_PARAMETER = "instance";
/*     */   private final Class<?> target;
/*     */   private final Collection<CommonAnnotationBeanPostProcessor.LookupElement> lookupElements;
/*     */   @Nullable
/*     */   private final AutowireCandidateResolver candidateResolver;
/*     */   
/*     */   AotContribution(Class<?> target, Collection<CommonAnnotationBeanPostProcessor.LookupElement> lookupElements, @Nullable AutowireCandidateResolver candidateResolver) {
/* 875 */     this.target = target;
/* 876 */     this.lookupElements = lookupElements;
/* 877 */     this.candidateResolver = candidateResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 883 */     GeneratedClass generatedClass = generationContext.getGeneratedClasses().addForFeatureComponent("ResourceAutowiring", this.target, type -> {
/*     */           type.addJavadoc("Resource autowiring for {@link $T}.", new Object[] { this.target });
/*     */           type.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */         });
/* 887 */     GeneratedMethod generateMethod = generatedClass.getMethods().add("apply", method -> {
/*     */           method.addJavadoc("Apply resource autowiring.", new Object[0]);
/*     */           
/*     */           method.addModifiers(new Modifier[] { Modifier.PUBLIC, Modifier.STATIC });
/*     */           
/*     */           method.addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]);
/*     */           method.addParameter(this.target, "instance", new Modifier[0]);
/*     */           method.returns(this.target);
/*     */           method.addCode(generateMethodCode(generatedClass.getName(), generationContext.getRuntimeHints()));
/*     */         });
/* 897 */     beanRegistrationCode.addInstancePostProcessor(generateMethod.toMethodReference());
/*     */     
/* 899 */     registerHints(generationContext.getRuntimeHints());
/*     */   }
/*     */   
/*     */   private CodeBlock generateMethodCode(ClassName targetClassName, RuntimeHints hints) {
/* 903 */     CodeBlock.Builder code = CodeBlock.builder();
/* 904 */     for (CommonAnnotationBeanPostProcessor.LookupElement lookupElement : this.lookupElements) {
/* 905 */       code.addStatement(generateMethodStatementForElement(targetClassName, lookupElement, hints));
/*     */     }
/*     */     
/* 908 */     code.addStatement("return $L", new Object[] { "instance" });
/* 909 */     return code.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateMethodStatementForElement(ClassName targetClassName, CommonAnnotationBeanPostProcessor.LookupElement lookupElement, RuntimeHints hints) {
/* 915 */     Member member = lookupElement.getMember();
/* 916 */     if (member instanceof Field) { Field field = (Field)member;
/* 917 */       return generateMethodStatementForField(targetClassName, field, lookupElement, hints); }
/*     */ 
/*     */     
/* 920 */     if (member instanceof Method) { Method method = (Method)member;
/* 921 */       return generateMethodStatementForMethod(targetClassName, method, lookupElement, hints); }
/*     */ 
/*     */     
/* 924 */     throw new IllegalStateException("Unsupported member type " + member
/* 925 */         .getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateMethodStatementForField(ClassName targetClassName, Field field, CommonAnnotationBeanPostProcessor.LookupElement lookupElement, RuntimeHints hints) {
/* 931 */     hints.reflection().registerField(field);
/* 932 */     CodeBlock resolver = generateFieldResolverCode(field, lookupElement);
/* 933 */     AccessControl accessControl = AccessControl.forMember(field);
/* 934 */     if (!accessControl.isAccessibleFrom(targetClassName)) {
/* 935 */       return CodeBlock.of("$L.resolveAndSet($L, $L)", new Object[] { resolver, "registeredBean", "instance" });
/*     */     }
/*     */     
/* 938 */     return CodeBlock.of("$L.$L = $L.resolve($L)", new Object[] { "instance", field
/* 939 */           .getName(), resolver, "registeredBean" });
/*     */   }
/*     */   
/*     */   private CodeBlock generateFieldResolverCode(Field field, CommonAnnotationBeanPostProcessor.LookupElement lookupElement) {
/* 943 */     if (lookupElement.isDefaultName) {
/* 944 */       return CodeBlock.of("$T.$L($S)", new Object[] { ResourceElementResolver.class, "forField", field
/* 945 */             .getName() });
/*     */     }
/*     */     
/* 948 */     return CodeBlock.of("$T.$L($S, $S)", new Object[] { ResourceElementResolver.class, "forField", field
/* 949 */           .getName(), lookupElement.getName() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateMethodStatementForMethod(ClassName targetClassName, Method method, CommonAnnotationBeanPostProcessor.LookupElement lookupElement, RuntimeHints hints) {
/* 956 */     CodeBlock resolver = generateMethodResolverCode(method, lookupElement);
/* 957 */     AccessControl accessControl = AccessControl.forMember(method);
/* 958 */     if (!accessControl.isAccessibleFrom(targetClassName)) {
/* 959 */       hints.reflection().registerMethod(method, ExecutableMode.INVOKE);
/* 960 */       return CodeBlock.of("$L.resolveAndSet($L, $L)", new Object[] { resolver, "registeredBean", "instance" });
/*     */     } 
/*     */     
/* 963 */     hints.reflection().registerMethod(method, ExecutableMode.INTROSPECT);
/* 964 */     return CodeBlock.of("$L.$L($L.resolve($L))", new Object[] { "instance", method
/* 965 */           .getName(), resolver, "registeredBean" });
/*     */   }
/*     */ 
/*     */   
/*     */   private CodeBlock generateMethodResolverCode(Method method, CommonAnnotationBeanPostProcessor.LookupElement lookupElement) {
/* 970 */     if (lookupElement.isDefaultName) {
/* 971 */       return CodeBlock.of("$T.$L($S, $T.class)", new Object[] { ResourceElementResolver.class, "forMethod", method
/* 972 */             .getName(), lookupElement.getLookupType() });
/*     */     }
/*     */     
/* 975 */     return CodeBlock.of("$T.$L($S, $T.class, $S)", new Object[] { ResourceElementResolver.class, "forMethod", method
/* 976 */           .getName(), lookupElement.getLookupType(), lookupElement.getName() });
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerHints(RuntimeHints runtimeHints) {
/* 981 */     this.lookupElements.forEach(lookupElement -> registerProxyIfNecessary(runtimeHints, lookupElement.getDependencyDescriptor()));
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerProxyIfNecessary(RuntimeHints runtimeHints, DependencyDescriptor dependencyDescriptor) {
/* 986 */     if (this.candidateResolver != null) {
/*     */       
/* 988 */       Class<?> proxyClass = this.candidateResolver.getLazyResolutionProxyClass(dependencyDescriptor, null);
/* 989 */       if (proxyClass != null)
/* 990 */         ClassHintUtils.registerProxyIfNecessary(proxyClass, runtimeHints); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\CommonAnnotationBeanPostProcessor$AotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */