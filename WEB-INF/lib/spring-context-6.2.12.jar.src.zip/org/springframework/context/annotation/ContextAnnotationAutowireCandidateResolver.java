/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.annotation.QualifierAnnotationAutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextAnnotationAutowireCandidateResolver
/*     */   extends QualifierAnnotationAutowireCandidateResolver
/*     */ {
/*     */   @Nullable
/*     */   public Object getLazyResolutionProxyIfNecessary(DependencyDescriptor descriptor, @Nullable String beanName) {
/*  53 */     return isLazy(descriptor) ? buildLazyResolutionProxy(descriptor, beanName) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getLazyResolutionProxyClass(DependencyDescriptor descriptor, @Nullable String beanName) {
/*  59 */     return isLazy(descriptor) ? (Class)buildLazyResolutionProxy(descriptor, beanName, true) : null;
/*     */   }
/*     */   
/*     */   protected boolean isLazy(DependencyDescriptor descriptor) {
/*  63 */     for (Annotation ann : descriptor.getAnnotations()) {
/*  64 */       Lazy lazy = (Lazy)AnnotationUtils.getAnnotation(ann, Lazy.class);
/*  65 */       if (lazy != null && lazy.value()) {
/*  66 */         return true;
/*     */       }
/*     */     } 
/*  69 */     MethodParameter methodParam = descriptor.getMethodParameter();
/*  70 */     if (methodParam != null) {
/*  71 */       Method method = methodParam.getMethod();
/*  72 */       if (method == null || void.class == method.getReturnType()) {
/*  73 */         Lazy lazy = (Lazy)AnnotationUtils.getAnnotation(methodParam.getAnnotatedElement(), Lazy.class);
/*  74 */         if (lazy != null && lazy.value()) {
/*  75 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*  79 */     return false;
/*     */   }
/*     */   
/*     */   protected Object buildLazyResolutionProxy(DependencyDescriptor descriptor, @Nullable String beanName) {
/*  83 */     return buildLazyResolutionProxy(descriptor, beanName, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private Object buildLazyResolutionProxy(DependencyDescriptor descriptor, @Nullable String beanName, boolean classOnly) {
/*     */     DefaultListableBeanFactory dlbf;
/*  89 */     BeanFactory beanFactory = getBeanFactory(); if (beanFactory instanceof DefaultListableBeanFactory) { dlbf = (DefaultListableBeanFactory)beanFactory; }
/*  90 */     else { throw new IllegalStateException("Lazy resolution only supported with DefaultListableBeanFactory"); }
/*     */ 
/*     */     
/*  93 */     TargetSource ts = new LazyDependencyTargetSource(dlbf, descriptor, beanName);
/*     */     
/*  95 */     ProxyFactory pf = new ProxyFactory();
/*  96 */     pf.setTargetSource(ts);
/*  97 */     Class<?> dependencyType = descriptor.getDependencyType();
/*  98 */     if (dependencyType.isInterface()) {
/*  99 */       pf.addInterface(dependencyType);
/*     */     }
/* 101 */     ClassLoader classLoader = dlbf.getBeanClassLoader();
/* 102 */     return classOnly ? pf.getProxyClass(classLoader) : pf.getProxy(classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LazyDependencyTargetSource
/*     */     implements TargetSource, Serializable
/*     */   {
/*     */     private final DefaultListableBeanFactory beanFactory;
/*     */     
/*     */     private final DependencyDescriptor descriptor;
/*     */     
/*     */     @Nullable
/*     */     private final String beanName;
/*     */     
/*     */     @Nullable
/*     */     private volatile transient Object cachedTarget;
/*     */ 
/*     */     
/*     */     public LazyDependencyTargetSource(DefaultListableBeanFactory beanFactory, DependencyDescriptor descriptor, @Nullable String beanName) {
/* 122 */       this.beanFactory = beanFactory;
/* 123 */       this.descriptor = descriptor;
/* 124 */       this.beanName = beanName;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getTargetClass() {
/* 129 */       return this.descriptor.getDependencyType();
/*     */     }
/*     */     
/*     */     public Object getTarget() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: getfield cachedTarget : Ljava/lang/Object;
/*     */       //   4: astore_1
/*     */       //   5: aload_1
/*     */       //   6: ifnull -> 11
/*     */       //   9: aload_1
/*     */       //   10: areturn
/*     */       //   11: new java/util/LinkedHashSet
/*     */       //   14: dup
/*     */       //   15: iconst_2
/*     */       //   16: invokespecial <init> : (I)V
/*     */       //   19: astore_2
/*     */       //   20: aload_0
/*     */       //   21: getfield beanFactory : Lorg/springframework/beans/factory/support/DefaultListableBeanFactory;
/*     */       //   24: aload_0
/*     */       //   25: getfield descriptor : Lorg/springframework/beans/factory/config/DependencyDescriptor;
/*     */       //   28: aload_0
/*     */       //   29: getfield beanName : Ljava/lang/String;
/*     */       //   32: aload_2
/*     */       //   33: aconst_null
/*     */       //   34: invokevirtual doResolveDependency : (Lorg/springframework/beans/factory/config/DependencyDescriptor;Ljava/lang/String;Ljava/util/Set;Lorg/springframework/beans/TypeConverter;)Ljava/lang/Object;
/*     */       //   37: astore_3
/*     */       //   38: aload_3
/*     */       //   39: ifnonnull -> 117
/*     */       //   42: aload_0
/*     */       //   43: invokevirtual getTargetClass : ()Ljava/lang/Class;
/*     */       //   46: astore #4
/*     */       //   48: ldc java/util/Map
/*     */       //   50: aload #4
/*     */       //   52: if_acmpne -> 62
/*     */       //   55: invokestatic emptyMap : ()Ljava/util/Map;
/*     */       //   58: astore_3
/*     */       //   59: goto -> 114
/*     */       //   62: ldc java/util/List
/*     */       //   64: aload #4
/*     */       //   66: if_acmpne -> 76
/*     */       //   69: invokestatic emptyList : ()Ljava/util/List;
/*     */       //   72: astore_3
/*     */       //   73: goto -> 114
/*     */       //   76: ldc java/util/Set
/*     */       //   78: aload #4
/*     */       //   80: if_acmpeq -> 90
/*     */       //   83: ldc java/util/Collection
/*     */       //   85: aload #4
/*     */       //   87: if_acmpne -> 97
/*     */       //   90: invokestatic emptySet : ()Ljava/util/Set;
/*     */       //   93: astore_3
/*     */       //   94: goto -> 114
/*     */       //   97: new org/springframework/beans/factory/NoSuchBeanDefinitionException
/*     */       //   100: dup
/*     */       //   101: aload_0
/*     */       //   102: getfield descriptor : Lorg/springframework/beans/factory/config/DependencyDescriptor;
/*     */       //   105: invokevirtual getResolvableType : ()Lorg/springframework/core/ResolvableType;
/*     */       //   108: ldc 'Optional dependency not present for lazy injection point'
/*     */       //   110: invokespecial <init> : (Lorg/springframework/core/ResolvableType;Ljava/lang/String;)V
/*     */       //   113: athrow
/*     */       //   114: goto -> 238
/*     */       //   117: aload_3
/*     */       //   118: instanceof java/util/Map
/*     */       //   121: ifeq -> 148
/*     */       //   124: aload_3
/*     */       //   125: checkcast java/util/Map
/*     */       //   128: astore #4
/*     */       //   130: ldc java/util/Map
/*     */       //   132: aload_0
/*     */       //   133: invokevirtual getTargetClass : ()Ljava/lang/Class;
/*     */       //   136: if_acmpne -> 148
/*     */       //   139: aload #4
/*     */       //   141: invokestatic unmodifiableMap : (Ljava/util/Map;)Ljava/util/Map;
/*     */       //   144: astore_3
/*     */       //   145: goto -> 238
/*     */       //   148: aload_3
/*     */       //   149: instanceof java/util/List
/*     */       //   152: ifeq -> 179
/*     */       //   155: aload_3
/*     */       //   156: checkcast java/util/List
/*     */       //   159: astore #5
/*     */       //   161: ldc java/util/List
/*     */       //   163: aload_0
/*     */       //   164: invokevirtual getTargetClass : ()Ljava/lang/Class;
/*     */       //   167: if_acmpne -> 179
/*     */       //   170: aload #5
/*     */       //   172: invokestatic unmodifiableList : (Ljava/util/List;)Ljava/util/List;
/*     */       //   175: astore_3
/*     */       //   176: goto -> 238
/*     */       //   179: aload_3
/*     */       //   180: instanceof java/util/Set
/*     */       //   183: ifeq -> 210
/*     */       //   186: aload_3
/*     */       //   187: checkcast java/util/Set
/*     */       //   190: astore #6
/*     */       //   192: ldc java/util/Set
/*     */       //   194: aload_0
/*     */       //   195: invokevirtual getTargetClass : ()Ljava/lang/Class;
/*     */       //   198: if_acmpne -> 210
/*     */       //   201: aload #6
/*     */       //   203: invokestatic unmodifiableSet : (Ljava/util/Set;)Ljava/util/Set;
/*     */       //   206: astore_3
/*     */       //   207: goto -> 238
/*     */       //   210: aload_3
/*     */       //   211: instanceof java/util/Collection
/*     */       //   214: ifeq -> 238
/*     */       //   217: aload_3
/*     */       //   218: checkcast java/util/Collection
/*     */       //   221: astore #7
/*     */       //   223: ldc java/util/Collection
/*     */       //   225: aload_0
/*     */       //   226: invokevirtual getTargetClass : ()Ljava/lang/Class;
/*     */       //   229: if_acmpne -> 238
/*     */       //   232: aload #7
/*     */       //   234: invokestatic unmodifiableCollection : (Ljava/util/Collection;)Ljava/util/Collection;
/*     */       //   237: astore_3
/*     */       //   238: iconst_1
/*     */       //   239: istore #4
/*     */       //   241: aload_2
/*     */       //   242: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */       //   247: astore #5
/*     */       //   249: aload #5
/*     */       //   251: invokeinterface hasNext : ()Z
/*     */       //   256: ifeq -> 337
/*     */       //   259: aload #5
/*     */       //   261: invokeinterface next : ()Ljava/lang/Object;
/*     */       //   266: checkcast java/lang/String
/*     */       //   269: astore #6
/*     */       //   271: aload_0
/*     */       //   272: getfield beanFactory : Lorg/springframework/beans/factory/support/DefaultListableBeanFactory;
/*     */       //   275: aload #6
/*     */       //   277: invokevirtual containsBean : (Ljava/lang/String;)Z
/*     */       //   280: ifne -> 289
/*     */       //   283: iconst_0
/*     */       //   284: istore #4
/*     */       //   286: goto -> 324
/*     */       //   289: aload_0
/*     */       //   290: getfield beanName : Ljava/lang/String;
/*     */       //   293: ifnull -> 309
/*     */       //   296: aload_0
/*     */       //   297: getfield beanFactory : Lorg/springframework/beans/factory/support/DefaultListableBeanFactory;
/*     */       //   300: aload #6
/*     */       //   302: aload_0
/*     */       //   303: getfield beanName : Ljava/lang/String;
/*     */       //   306: invokevirtual registerDependentBean : (Ljava/lang/String;Ljava/lang/String;)V
/*     */       //   309: aload_0
/*     */       //   310: getfield beanFactory : Lorg/springframework/beans/factory/support/DefaultListableBeanFactory;
/*     */       //   313: aload #6
/*     */       //   315: invokevirtual isSingleton : (Ljava/lang/String;)Z
/*     */       //   318: ifne -> 324
/*     */       //   321: iconst_0
/*     */       //   322: istore #4
/*     */       //   324: iload #4
/*     */       //   326: ifeq -> 334
/*     */       //   329: aload_0
/*     */       //   330: aload_3
/*     */       //   331: putfield cachedTarget : Ljava/lang/Object;
/*     */       //   334: goto -> 249
/*     */       //   337: aload_3
/*     */       //   338: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #135	-> 0
/*     */       //   #136	-> 5
/*     */       //   #137	-> 9
/*     */       //   #140	-> 11
/*     */       //   #141	-> 20
/*     */       //   #144	-> 38
/*     */       //   #145	-> 42
/*     */       //   #146	-> 48
/*     */       //   #147	-> 55
/*     */       //   #149	-> 62
/*     */       //   #150	-> 69
/*     */       //   #152	-> 76
/*     */       //   #153	-> 90
/*     */       //   #156	-> 97
/*     */       //   #159	-> 114
/*     */       //   #161	-> 117
/*     */       //   #162	-> 139
/*     */       //   #164	-> 148
/*     */       //   #165	-> 170
/*     */       //   #167	-> 179
/*     */       //   #168	-> 201
/*     */       //   #170	-> 210
/*     */       //   #171	-> 232
/*     */       //   #175	-> 238
/*     */       //   #176	-> 241
/*     */       //   #177	-> 271
/*     */       //   #178	-> 283
/*     */       //   #181	-> 289
/*     */       //   #182	-> 296
/*     */       //   #184	-> 309
/*     */       //   #185	-> 321
/*     */       //   #188	-> 324
/*     */       //   #189	-> 329
/*     */       //   #191	-> 334
/*     */       //   #193	-> 337
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   48	66	4	type	Ljava/lang/Class;
/*     */       //   130	18	4	map	Ljava/util/Map;
/*     */       //   161	18	5	list	Ljava/util/List;
/*     */       //   192	18	6	set	Ljava/util/Set;
/*     */       //   223	15	7	coll	Ljava/util/Collection;
/*     */       //   271	63	6	autowiredBeanName	Ljava/lang/String;
/*     */       //   0	339	0	this	Lorg/springframework/context/annotation/ContextAnnotationAutowireCandidateResolver$LazyDependencyTargetSource;
/*     */       //   5	334	1	cachedTarget	Ljava/lang/Object;
/*     */       //   20	319	2	autowiredBeanNames	Ljava/util/Set;
/*     */       //   38	301	3	target	Ljava/lang/Object;
/*     */       //   241	98	4	cacheable	Z
/*     */       // Local variable type table:
/*     */       //   start	length	slot	name	signature
/*     */       //   48	66	4	type	Ljava/lang/Class<*>;
/*     */       //   130	18	4	map	Ljava/util/Map<**>;
/*     */       //   161	18	5	list	Ljava/util/List<*>;
/*     */       //   192	18	6	set	Ljava/util/Set<*>;
/*     */       //   223	15	7	coll	Ljava/util/Collection<*>;
/*     */       //   20	319	2	autowiredBeanNames	Ljava/util/Set<Ljava/lang/String;>;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ContextAnnotationAutowireCandidateResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */