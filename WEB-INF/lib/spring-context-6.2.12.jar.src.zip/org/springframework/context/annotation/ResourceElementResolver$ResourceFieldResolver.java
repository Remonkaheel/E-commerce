/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Field;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ResourceFieldResolver
/*     */   extends ResourceElementResolver
/*     */ {
/*     */   private final String fieldName;
/*     */   
/*     */   public ResourceFieldResolver(String name, boolean defaultName, String fieldName) {
/* 209 */     super(name, defaultName);
/* 210 */     this.fieldName = fieldName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolveAndSet(RegisteredBean registeredBean, Object instance) {
/* 215 */     Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 216 */     Assert.notNull(instance, "'instance' must not be null");
/* 217 */     Field field = getField(registeredBean);
/* 218 */     Object resolved = resolve(registeredBean);
/* 219 */     ReflectionUtils.makeAccessible(field);
/* 220 */     ReflectionUtils.setField(field, instance, resolved);
/*     */   }
/*     */ 
/*     */   
/*     */   protected DependencyDescriptor createDependencyDescriptor(RegisteredBean registeredBean) {
/* 225 */     Field field = getField(registeredBean);
/* 226 */     return new ResourceElementResolver.LookupDependencyDescriptor(field, field.getType(), isLazyLookup(registeredBean));
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<?> getLookupType(RegisteredBean registeredBean) {
/* 231 */     return getField(registeredBean).getType();
/*     */   }
/*     */ 
/*     */   
/*     */   protected AnnotatedElement getAnnotatedElement(RegisteredBean registeredBean) {
/* 236 */     return getField(registeredBean);
/*     */   }
/*     */   
/*     */   private Field getField(RegisteredBean registeredBean) {
/* 240 */     Field field = ReflectionUtils.findField(registeredBean.getBeanClass(), this.fieldName);
/* 241 */     Assert.notNull(field, () -> "No field '" + this.fieldName + "' found on " + registeredBean.getBeanClass().getName());
/*     */     
/* 243 */     return field;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ResourceElementResolver$ResourceFieldResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */