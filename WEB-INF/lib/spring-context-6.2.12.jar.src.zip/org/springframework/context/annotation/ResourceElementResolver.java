/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceElementResolver
/*     */ {
/*     */   private final String name;
/*     */   private final boolean defaultName;
/*     */   
/*     */   ResourceElementResolver(String name, boolean defaultName) {
/*  57 */     this.name = name;
/*  58 */     this.defaultName = defaultName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceElementResolver forField(String fieldName) {
/*  68 */     return new ResourceFieldResolver(fieldName, true, fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceElementResolver forField(String fieldName, String resourceName) {
/*  78 */     return new ResourceFieldResolver(resourceName, false, fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceElementResolver forMethod(String methodName, Class<?> parameterType) {
/*  89 */     return new ResourceMethodResolver(defaultResourceNameForMethod(methodName), true, methodName, parameterType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceElementResolver forMethod(String methodName, Class<?> parameterType, String resourceName) {
/* 102 */     return new ResourceMethodResolver(resourceName, false, methodName, parameterType);
/*     */   }
/*     */   
/*     */   private static String defaultResourceNameForMethod(String methodName) {
/* 106 */     if (methodName.startsWith("set") && methodName.length() > 3) {
/* 107 */       return StringUtils.uncapitalizeAsProperty(methodName.substring(3));
/*     */     }
/* 109 */     return methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T resolve(RegisteredBean registeredBean) {
/* 121 */     Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 122 */     return isLazyLookup(registeredBean) ? (T)buildLazyResourceProxy(registeredBean) : 
/* 123 */       (T)resolveValue(registeredBean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void resolveAndSet(RegisteredBean paramRegisteredBean, Object paramObject);
/*     */ 
/*     */ 
/*     */   
/*     */   abstract DependencyDescriptor createDependencyDescriptor(RegisteredBean paramRegisteredBean);
/*     */ 
/*     */ 
/*     */   
/*     */   abstract Class<?> getLookupType(RegisteredBean paramRegisteredBean);
/*     */ 
/*     */ 
/*     */   
/*     */   abstract AnnotatedElement getAnnotatedElement(RegisteredBean paramRegisteredBean);
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isLazyLookup(RegisteredBean registeredBean) {
/* 145 */     AnnotatedElement ae = getAnnotatedElement(registeredBean);
/* 146 */     Lazy lazy = ae.<Lazy>getAnnotation(Lazy.class);
/* 147 */     return (lazy != null && lazy.value());
/*     */   }
/*     */   
/*     */   private Object buildLazyResourceProxy(final RegisteredBean registeredBean) {
/* 151 */     final Class<?> lookupType = getLookupType(registeredBean);
/*     */     
/* 153 */     TargetSource ts = new TargetSource()
/*     */       {
/*     */         public Class<?> getTargetClass() {
/* 156 */           return lookupType;
/*     */         }
/*     */         
/*     */         public Object getTarget() {
/* 160 */           return ResourceElementResolver.this.resolveValue(registeredBean);
/*     */         }
/*     */       };
/*     */     
/* 164 */     ProxyFactory pf = new ProxyFactory();
/* 165 */     pf.setTargetSource(ts);
/* 166 */     if (lookupType.isInterface()) {
/* 167 */       pf.addInterface(lookupType);
/*     */     }
/* 169 */     return pf.getProxy(registeredBean.getBeanFactory().getBeanClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object resolveValue(RegisteredBean registeredBean) {
/*     */     Object resource;
/*     */     Set<String> autowiredBeanNames;
/* 178 */     ConfigurableListableBeanFactory factory = registeredBean.getBeanFactory();
/*     */ 
/*     */ 
/*     */     
/* 182 */     DependencyDescriptor descriptor = createDependencyDescriptor(registeredBean);
/* 183 */     if (this.defaultName && !factory.containsBean(this.name)) {
/* 184 */       autowiredBeanNames = new LinkedHashSet<>();
/* 185 */       resource = factory.resolveDependency(descriptor, registeredBean.getBeanName(), autowiredBeanNames, null);
/* 186 */       if (resource == null) {
/* 187 */         throw new NoSuchBeanDefinitionException(descriptor.getDependencyType(), "No resolvable resource object");
/*     */       }
/*     */     } else {
/*     */       
/* 191 */       resource = factory.resolveBeanByName(this.name, descriptor);
/* 192 */       autowiredBeanNames = Collections.singleton(this.name);
/*     */     } 
/*     */     
/* 195 */     for (String autowiredBeanName : autowiredBeanNames) {
/* 196 */       if (factory.containsBean(autowiredBeanName)) {
/* 197 */         factory.registerDependentBean(autowiredBeanName, registeredBean.getBeanName());
/*     */       }
/*     */     } 
/* 200 */     return resource;
/*     */   }
/*     */   
/*     */   private static final class ResourceFieldResolver
/*     */     extends ResourceElementResolver
/*     */   {
/*     */     private final String fieldName;
/*     */     
/*     */     public ResourceFieldResolver(String name, boolean defaultName, String fieldName) {
/* 209 */       super(name, defaultName);
/* 210 */       this.fieldName = fieldName;
/*     */     }
/*     */ 
/*     */     
/*     */     public void resolveAndSet(RegisteredBean registeredBean, Object instance) {
/* 215 */       Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 216 */       Assert.notNull(instance, "'instance' must not be null");
/* 217 */       Field field = getField(registeredBean);
/* 218 */       Object resolved = resolve(registeredBean);
/* 219 */       ReflectionUtils.makeAccessible(field);
/* 220 */       ReflectionUtils.setField(field, instance, resolved);
/*     */     }
/*     */ 
/*     */     
/*     */     protected DependencyDescriptor createDependencyDescriptor(RegisteredBean registeredBean) {
/* 225 */       Field field = getField(registeredBean);
/* 226 */       return new ResourceElementResolver.LookupDependencyDescriptor(field, field.getType(), isLazyLookup(registeredBean));
/*     */     }
/*     */ 
/*     */     
/*     */     protected Class<?> getLookupType(RegisteredBean registeredBean) {
/* 231 */       return getField(registeredBean).getType();
/*     */     }
/*     */ 
/*     */     
/*     */     protected AnnotatedElement getAnnotatedElement(RegisteredBean registeredBean) {
/* 236 */       return getField(registeredBean);
/*     */     }
/*     */     
/*     */     private Field getField(RegisteredBean registeredBean) {
/* 240 */       Field field = ReflectionUtils.findField(registeredBean.getBeanClass(), this.fieldName);
/* 241 */       Assert.notNull(field, () -> "No field '" + this.fieldName + "' found on " + registeredBean.getBeanClass().getName());
/*     */       
/* 243 */       return field;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class ResourceMethodResolver
/*     */     extends ResourceElementResolver
/*     */   {
/*     */     private final String methodName;
/*     */     private final Class<?> lookupType;
/*     */     
/*     */     private ResourceMethodResolver(String name, boolean defaultName, String methodName, Class<?> lookupType) {
/* 255 */       super(name, defaultName);
/* 256 */       this.methodName = methodName;
/* 257 */       this.lookupType = lookupType;
/*     */     }
/*     */ 
/*     */     
/*     */     public void resolveAndSet(RegisteredBean registeredBean, Object instance) {
/* 262 */       Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 263 */       Assert.notNull(instance, "'instance' must not be null");
/* 264 */       Method method = getMethod(registeredBean);
/* 265 */       Object resolved = resolve(registeredBean);
/* 266 */       ReflectionUtils.makeAccessible(method);
/* 267 */       ReflectionUtils.invokeMethod(method, instance, new Object[] { resolved });
/*     */     }
/*     */ 
/*     */     
/*     */     protected DependencyDescriptor createDependencyDescriptor(RegisteredBean registeredBean) {
/* 272 */       return new ResourceElementResolver.LookupDependencyDescriptor(
/* 273 */           getMethod(registeredBean), this.lookupType, isLazyLookup(registeredBean));
/*     */     }
/*     */ 
/*     */     
/*     */     protected Class<?> getLookupType(RegisteredBean bean) {
/* 278 */       return this.lookupType;
/*     */     }
/*     */ 
/*     */     
/*     */     protected AnnotatedElement getAnnotatedElement(RegisteredBean registeredBean) {
/* 283 */       return getMethod(registeredBean);
/*     */     }
/*     */     
/*     */     private Method getMethod(RegisteredBean registeredBean) {
/* 287 */       Method method = ReflectionUtils.findMethod(registeredBean.getBeanClass(), this.methodName, new Class[] { this.lookupType });
/* 288 */       Assert.notNull(method, () -> "Method '%s' with parameter type '%s' declared on %s could not be found.".formatted(new Object[] { this.methodName, this.lookupType.getName(), registeredBean.getBeanClass().getName() }));
/*     */ 
/*     */       
/* 291 */       return method;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class LookupDependencyDescriptor
/*     */     extends DependencyDescriptor
/*     */   {
/*     */     private final Class<?> lookupType;
/*     */ 
/*     */     
/*     */     private final boolean lazyLookup;
/*     */ 
/*     */ 
/*     */     
/*     */     public LookupDependencyDescriptor(Field field, Class<?> lookupType, boolean lazyLookup) {
/* 308 */       super(field, true);
/* 309 */       this.lookupType = lookupType;
/* 310 */       this.lazyLookup = lazyLookup;
/*     */     }
/*     */     
/*     */     public LookupDependencyDescriptor(Method method, Class<?> lookupType, boolean lazyLookup) {
/* 314 */       super(new MethodParameter(method, 0), true);
/* 315 */       this.lookupType = lookupType;
/* 316 */       this.lazyLookup = lazyLookup;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getDependencyType() {
/* 321 */       return this.lookupType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean supportsLazyResolution() {
/* 326 */       return !this.lazyLookup;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ResourceElementResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */