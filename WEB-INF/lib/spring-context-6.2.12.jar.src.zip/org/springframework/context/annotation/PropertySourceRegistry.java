/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.io.support.PropertySourceDescriptor;
/*    */ import org.springframework.core.io.support.PropertySourceFactory;
/*    */ import org.springframework.core.io.support.PropertySourceProcessor;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PropertySourceRegistry
/*    */ {
/*    */   private final PropertySourceProcessor propertySourceProcessor;
/*    */   private final List<PropertySourceDescriptor> descriptors;
/*    */   
/*    */   public PropertySourceRegistry(PropertySourceProcessor propertySourceProcessor) {
/* 47 */     this.propertySourceProcessor = propertySourceProcessor;
/* 48 */     this.descriptors = new ArrayList<>();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void processPropertySource(AnnotationAttributes propertySource) throws IOException {
/* 58 */     String name = propertySource.getString("name");
/* 59 */     if (!StringUtils.hasLength(name)) {
/* 60 */       name = null;
/*    */     }
/* 62 */     String encoding = propertySource.getString("encoding");
/* 63 */     if (!StringUtils.hasLength(encoding)) {
/* 64 */       encoding = null;
/*    */     }
/* 66 */     String[] locations = propertySource.getStringArray("value");
/* 67 */     Assert.isTrue((locations.length > 0), "At least one @PropertySource(value) location is required");
/* 68 */     boolean ignoreResourceNotFound = propertySource.getBoolean("ignoreResourceNotFound");
/*    */     
/* 70 */     Class<? extends PropertySourceFactory> factoryClass = propertySource.getClass("factory");
/*    */     
/* 72 */     Class<? extends PropertySourceFactory> factoryClassToUse = (factoryClass != PropertySourceFactory.class) ? factoryClass : null;
/* 73 */     PropertySourceDescriptor descriptor = new PropertySourceDescriptor(Arrays.asList(locations), ignoreResourceNotFound, name, factoryClassToUse, encoding);
/*    */     
/* 75 */     this.propertySourceProcessor.processPropertySource(descriptor);
/* 76 */     this.descriptors.add(descriptor);
/*    */   }
/*    */   
/*    */   public List<PropertySourceDescriptor> getDescriptors() {
/* 80 */     return Collections.unmodifiableList(this.descriptors);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\PropertySourceRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */