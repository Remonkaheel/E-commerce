/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.weaving.AspectJWeavingEnabler;
/*     */ import org.springframework.context.weaving.DefaultContextLoadTimeWeaver;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @Role(2)
/*     */ public class LoadTimeWeavingConfiguration
/*     */   implements ImportAware, BeanClassLoaderAware
/*     */ {
/*     */   @Nullable
/*     */   private AnnotationAttributes enableLTW;
/*     */   @Nullable
/*     */   private LoadTimeWeavingConfigurer ltwConfigurer;
/*     */   @Nullable
/*     */   private ClassLoader beanClassLoader;
/*     */   
/*     */   public void setImportMetadata(AnnotationMetadata importMetadata) {
/*  60 */     this.enableLTW = AnnotationConfigUtils.attributesFor((AnnotatedTypeMetadata)importMetadata, EnableLoadTimeWeaving.class);
/*  61 */     if (this.enableLTW == null) {
/*  62 */       throw new IllegalArgumentException("@EnableLoadTimeWeaving is not present on importing class " + importMetadata
/*  63 */           .getClassName());
/*     */     }
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setLoadTimeWeavingConfigurer(LoadTimeWeavingConfigurer ltwConfigurer) {
/*  69 */     this.ltwConfigurer = ltwConfigurer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader) {
/*  74 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */   
/*     */   @Bean(name = {"loadTimeWeaver"})
/*     */   @Role(2)
/*     */   public LoadTimeWeaver loadTimeWeaver() {
/*     */     DefaultContextLoadTimeWeaver defaultContextLoadTimeWeaver;
/*  81 */     Assert.state((this.beanClassLoader != null), "No ClassLoader set");
/*  82 */     LoadTimeWeaver loadTimeWeaver = null;
/*     */     
/*  84 */     if (this.ltwConfigurer != null)
/*     */     {
/*  86 */       loadTimeWeaver = this.ltwConfigurer.getLoadTimeWeaver();
/*     */     }
/*     */     
/*  89 */     if (loadTimeWeaver == null)
/*     */     {
/*  91 */       defaultContextLoadTimeWeaver = new DefaultContextLoadTimeWeaver(this.beanClassLoader);
/*     */     }
/*     */     
/*  94 */     if (this.enableLTW != null) {
/*  95 */       EnableLoadTimeWeaving.AspectJWeaving aspectJWeaving = (EnableLoadTimeWeaving.AspectJWeaving)this.enableLTW.getEnum("aspectjWeaving");
/*  96 */       switch (aspectJWeaving) {
/*     */ 
/*     */ 
/*     */         
/*     */         case AUTODETECT:
/* 101 */           if (this.beanClassLoader.getResource("META-INF/aop.xml") == null) {
/*     */             break;
/*     */           }
/*     */ 
/*     */           
/* 106 */           AspectJWeavingEnabler.enableAspectJWeaving((LoadTimeWeaver)defaultContextLoadTimeWeaver, this.beanClassLoader);
/*     */           break;
/*     */         case ENABLED:
/* 109 */           AspectJWeavingEnabler.enableAspectJWeaving((LoadTimeWeaver)defaultContextLoadTimeWeaver, this.beanClassLoader);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 114 */     return (LoadTimeWeaver)defaultContextLoadTimeWeaver;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\LoadTimeWeavingConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */