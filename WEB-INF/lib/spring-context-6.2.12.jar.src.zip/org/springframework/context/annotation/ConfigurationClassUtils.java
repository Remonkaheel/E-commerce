/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.stereotype.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConfigurationClassUtils
/*     */ {
/*     */   static final String CONFIGURATION_CLASS_FULL = "full";
/*     */   static final String CONFIGURATION_CLASS_LITE = "lite";
/*  68 */   static final String CANDIDATE_ATTRIBUTE = Conventions.getQualifiedAttributeName(ConfigurationClassPostProcessor.class, "candidate");
/*     */ 
/*     */   
/*  71 */   static final String CONFIGURATION_CLASS_ATTRIBUTE = Conventions.getQualifiedAttributeName(ConfigurationClassPostProcessor.class, "configurationClass");
/*     */ 
/*     */   
/*  74 */   static final String ORDER_ATTRIBUTE = Conventions.getQualifiedAttributeName(ConfigurationClassPostProcessor.class, "order");
/*     */ 
/*     */   
/*  77 */   private static final Log logger = LogFactory.getLog(ConfigurationClassUtils.class);
/*     */   
/*  79 */   private static final Set<String> candidateIndicators = Set.of(Component.class
/*  80 */       .getName(), ComponentScan.class
/*  81 */       .getName(), Import.class
/*  82 */       .getName(), ImportResource.class
/*  83 */       .getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> initializeConfigurationClass(Class<?> userClass) {
/*  92 */     Class<?> configurationClass = (new ConfigurationClassEnhancer()).enhance(userClass, null);
/*  93 */     Enhancer.registerStaticCallbacks(configurationClass, ConfigurationClassEnhancer.CALLBACKS);
/*  94 */     return configurationClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean checkConfigurationClassCandidate(BeanDefinition beanDef, MetadataReaderFactory metadataReaderFactory) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokeinterface getBeanClassName : ()Ljava/lang/String;
/*     */     //   6: astore_2
/*     */     //   7: aload_2
/*     */     //   8: ifnull -> 20
/*     */     //   11: aload_0
/*     */     //   12: invokeinterface getFactoryMethodName : ()Ljava/lang/String;
/*     */     //   17: ifnull -> 22
/*     */     //   20: iconst_0
/*     */     //   21: ireturn
/*     */     //   22: aload_0
/*     */     //   23: instanceof org/springframework/beans/factory/annotation/AnnotatedBeanDefinition
/*     */     //   26: ifeq -> 65
/*     */     //   29: aload_0
/*     */     //   30: checkcast org/springframework/beans/factory/annotation/AnnotatedBeanDefinition
/*     */     //   33: astore #4
/*     */     //   35: aload_2
/*     */     //   36: aload #4
/*     */     //   38: invokeinterface getMetadata : ()Lorg/springframework/core/type/AnnotationMetadata;
/*     */     //   43: invokeinterface getClassName : ()Ljava/lang/String;
/*     */     //   48: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   51: ifeq -> 65
/*     */     //   54: aload #4
/*     */     //   56: invokeinterface getMetadata : ()Lorg/springframework/core/type/AnnotationMetadata;
/*     */     //   61: astore_3
/*     */     //   62: goto -> 195
/*     */     //   65: aload_0
/*     */     //   66: instanceof org/springframework/beans/factory/support/AbstractBeanDefinition
/*     */     //   69: ifeq -> 144
/*     */     //   72: aload_0
/*     */     //   73: checkcast org/springframework/beans/factory/support/AbstractBeanDefinition
/*     */     //   76: astore #5
/*     */     //   78: aload #5
/*     */     //   80: invokevirtual hasBeanClass : ()Z
/*     */     //   83: ifeq -> 144
/*     */     //   86: aload #5
/*     */     //   88: invokevirtual getBeanClass : ()Ljava/lang/Class;
/*     */     //   91: astore #6
/*     */     //   93: ldc org/springframework/beans/factory/config/BeanFactoryPostProcessor
/*     */     //   95: aload #6
/*     */     //   97: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*     */     //   100: ifne -> 133
/*     */     //   103: ldc org/springframework/beans/factory/config/BeanPostProcessor
/*     */     //   105: aload #6
/*     */     //   107: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*     */     //   110: ifne -> 133
/*     */     //   113: ldc org/springframework/aop/framework/AopInfrastructureBean
/*     */     //   115: aload #6
/*     */     //   117: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*     */     //   120: ifne -> 133
/*     */     //   123: ldc org/springframework/context/event/EventListenerFactory
/*     */     //   125: aload #6
/*     */     //   127: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*     */     //   130: ifeq -> 135
/*     */     //   133: iconst_0
/*     */     //   134: ireturn
/*     */     //   135: aload #6
/*     */     //   137: invokestatic introspect : (Ljava/lang/Class;)Lorg/springframework/core/type/AnnotationMetadata;
/*     */     //   140: astore_3
/*     */     //   141: goto -> 195
/*     */     //   144: aload_1
/*     */     //   145: aload_2
/*     */     //   146: invokeinterface getMetadataReader : (Ljava/lang/String;)Lorg/springframework/core/type/classreading/MetadataReader;
/*     */     //   151: astore #6
/*     */     //   153: aload #6
/*     */     //   155: invokeinterface getAnnotationMetadata : ()Lorg/springframework/core/type/AnnotationMetadata;
/*     */     //   160: astore_3
/*     */     //   161: goto -> 195
/*     */     //   164: astore #6
/*     */     //   166: getstatic org/springframework/context/annotation/ConfigurationClassUtils.logger : Lorg/apache/commons/logging/Log;
/*     */     //   169: invokeinterface isDebugEnabled : ()Z
/*     */     //   174: ifeq -> 193
/*     */     //   177: getstatic org/springframework/context/annotation/ConfigurationClassUtils.logger : Lorg/apache/commons/logging/Log;
/*     */     //   180: aload_2
/*     */     //   181: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   186: aload #6
/*     */     //   188: invokeinterface debug : (Ljava/lang/Object;Ljava/lang/Throwable;)V
/*     */     //   193: iconst_0
/*     */     //   194: ireturn
/*     */     //   195: aload_3
/*     */     //   196: ldc org/springframework/context/annotation/Configuration
/*     */     //   198: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   201: invokeinterface getAnnotationAttributes : (Ljava/lang/String;)Ljava/util/Map;
/*     */     //   206: astore #4
/*     */     //   208: aload #4
/*     */     //   210: ifnull -> 245
/*     */     //   213: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
/*     */     //   216: aload #4
/*     */     //   218: ldc 'proxyBeanMethods'
/*     */     //   220: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   225: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   228: ifne -> 245
/*     */     //   231: aload_0
/*     */     //   232: getstatic org/springframework/context/annotation/ConfigurationClassUtils.CONFIGURATION_CLASS_ATTRIBUTE : Ljava/lang/String;
/*     */     //   235: ldc 'full'
/*     */     //   237: invokeinterface setAttribute : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   242: goto -> 291
/*     */     //   245: aload #4
/*     */     //   247: ifnonnull -> 275
/*     */     //   250: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   253: aload_0
/*     */     //   254: getstatic org/springframework/context/annotation/ConfigurationClassUtils.CANDIDATE_ATTRIBUTE : Ljava/lang/String;
/*     */     //   257: invokeinterface getAttribute : (Ljava/lang/String;)Ljava/lang/Object;
/*     */     //   262: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   265: ifne -> 275
/*     */     //   268: aload_3
/*     */     //   269: invokestatic isConfigurationCandidate : (Lorg/springframework/core/type/AnnotationMetadata;)Z
/*     */     //   272: ifeq -> 289
/*     */     //   275: aload_0
/*     */     //   276: getstatic org/springframework/context/annotation/ConfigurationClassUtils.CONFIGURATION_CLASS_ATTRIBUTE : Ljava/lang/String;
/*     */     //   279: ldc 'lite'
/*     */     //   281: invokeinterface setAttribute : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   286: goto -> 291
/*     */     //   289: iconst_0
/*     */     //   290: ireturn
/*     */     //   291: aload_3
/*     */     //   292: invokestatic getOrder : (Lorg/springframework/core/type/AnnotationMetadata;)Ljava/lang/Integer;
/*     */     //   295: astore #5
/*     */     //   297: aload #5
/*     */     //   299: ifnull -> 313
/*     */     //   302: aload_0
/*     */     //   303: getstatic org/springframework/context/annotation/ConfigurationClassUtils.ORDER_ATTRIBUTE : Ljava/lang/String;
/*     */     //   306: aload #5
/*     */     //   308: invokeinterface setAttribute : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   313: iconst_1
/*     */     //   314: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #109	-> 0
/*     */     //   #110	-> 7
/*     */     //   #111	-> 20
/*     */     //   #115	-> 22
/*     */     //   #116	-> 38
/*     */     //   #118	-> 54
/*     */     //   #120	-> 65
/*     */     //   #123	-> 86
/*     */     //   #124	-> 93
/*     */     //   #125	-> 107
/*     */     //   #126	-> 117
/*     */     //   #127	-> 127
/*     */     //   #128	-> 133
/*     */     //   #130	-> 135
/*     */     //   #131	-> 141
/*     */     //   #134	-> 144
/*     */     //   #135	-> 153
/*     */     //   #143	-> 161
/*     */     //   #137	-> 164
/*     */     //   #138	-> 166
/*     */     //   #139	-> 177
/*     */     //   #142	-> 193
/*     */     //   #146	-> 195
/*     */     //   #147	-> 208
/*     */     //   #148	-> 231
/*     */     //   #150	-> 245
/*     */     //   #151	-> 269
/*     */     //   #152	-> 275
/*     */     //   #155	-> 289
/*     */     //   #159	-> 291
/*     */     //   #160	-> 297
/*     */     //   #161	-> 302
/*     */     //   #164	-> 313
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   62	3	3	metadata	Lorg/springframework/core/type/AnnotationMetadata;
/*     */     //   35	30	4	annotatedBd	Lorg/springframework/beans/factory/annotation/AnnotatedBeanDefinition;
/*     */     //   93	48	6	beanClass	Ljava/lang/Class;
/*     */     //   141	3	3	metadata	Lorg/springframework/core/type/AnnotationMetadata;
/*     */     //   78	66	5	abstractBd	Lorg/springframework/beans/factory/support/AbstractBeanDefinition;
/*     */     //   153	8	6	metadataReader	Lorg/springframework/core/type/classreading/MetadataReader;
/*     */     //   161	3	3	metadata	Lorg/springframework/core/type/AnnotationMetadata;
/*     */     //   166	29	6	ex	Ljava/io/IOException;
/*     */     //   0	315	0	beanDef	Lorg/springframework/beans/factory/config/BeanDefinition;
/*     */     //   0	315	1	metadataReaderFactory	Lorg/springframework/core/type/classreading/MetadataReaderFactory;
/*     */     //   7	308	2	className	Ljava/lang/String;
/*     */     //   195	120	3	metadata	Lorg/springframework/core/type/AnnotationMetadata;
/*     */     //   208	107	4	config	Ljava/util/Map;
/*     */     //   297	18	5	order	Ljava/lang/Integer;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   93	48	6	beanClass	Ljava/lang/Class<*>;
/*     */     //   208	107	4	config	Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   144	161	164	java/io/IOException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isConfigurationCandidate(AnnotationMetadata metadata) {
/* 176 */     if (metadata.isInterface()) {
/* 177 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 181 */     for (String indicator : candidateIndicators) {
/* 182 */       if (metadata.isAnnotated(indicator)) {
/* 183 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 188 */     return hasBeanMethods(metadata);
/*     */   }
/*     */   
/*     */   static boolean hasBeanMethods(AnnotationMetadata metadata) {
/*     */     try {
/* 193 */       return metadata.hasAnnotatedMethods(Bean.class.getName());
/*     */     }
/* 195 */     catch (Throwable ex) {
/* 196 */       if (logger.isDebugEnabled()) {
/* 197 */         logger.debug("Failed to introspect @Bean methods on class [" + metadata.getClassName() + "]: " + String.valueOf(ex));
/*     */       }
/* 199 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Integer getOrder(AnnotationMetadata metadata) {
/* 212 */     Map<String, Object> orderAttributes = metadata.getAnnotationAttributes(Order.class.getName());
/* 213 */     return (orderAttributes != null) ? (Integer)orderAttributes.get("value") : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getOrder(BeanDefinition beanDef) {
/* 225 */     Integer order = (Integer)beanDef.getAttribute(ORDER_ATTRIBUTE);
/* 226 */     return (order != null) ? order.intValue() : Integer.MAX_VALUE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConfigurationClassUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */