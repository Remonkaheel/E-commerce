/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Comparator;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.AutowiredAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.event.DefaultEventListenerFactory;
/*     */ import org.springframework.context.event.EventListenerMethodProcessor;
/*     */ import org.springframework.context.support.GenericApplicationContext;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnnotationConfigUtils
/*     */ {
/*     */   public static final String CONFIGURATION_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalConfigurationAnnotationProcessor";
/*     */   public static final String CONFIGURATION_BEAN_NAME_GENERATOR = "org.springframework.context.annotation.internalConfigurationBeanNameGenerator";
/*     */   public static final String AUTOWIRED_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalAutowiredAnnotationProcessor";
/*     */   public static final String COMMON_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalCommonAnnotationProcessor";
/*     */   public static final String PERSISTENCE_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalPersistenceAnnotationProcessor";
/*     */   private static final String PERSISTENCE_ANNOTATION_PROCESSOR_CLASS_NAME = "org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor";
/*     */   public static final String EVENT_LISTENER_PROCESSOR_BEAN_NAME = "org.springframework.context.event.internalEventListenerProcessor";
/*     */   public static final String EVENT_LISTENER_FACTORY_BEAN_NAME = "org.springframework.context.event.internalEventListenerFactory";
/* 115 */   private static final ClassLoader classLoader = AnnotationConfigUtils.class.getClassLoader();
/*     */ 
/*     */   
/* 118 */   private static final boolean jakartaAnnotationsPresent = ClassUtils.isPresent("jakarta.annotation.PostConstruct", classLoader);
/*     */ 
/*     */   
/* 121 */   private static final boolean jsr250Present = ClassUtils.isPresent("javax.annotation.PostConstruct", classLoader);
/*     */   
/* 123 */   private static final boolean jpaPresent = (
/* 124 */     ClassUtils.isPresent("jakarta.persistence.EntityManagerFactory", classLoader) && 
/* 125 */     ClassUtils.isPresent("org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor", classLoader));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerAnnotationConfigProcessors(BeanDefinitionRegistry registry) {
/* 133 */     registerAnnotationConfigProcessors(registry, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<BeanDefinitionHolder> registerAnnotationConfigProcessors(BeanDefinitionRegistry registry, @Nullable Object source) {
/* 147 */     DefaultListableBeanFactory beanFactory = unwrapDefaultListableBeanFactory(registry);
/* 148 */     if (beanFactory != null) {
/* 149 */       if (!(beanFactory.getDependencyComparator() instanceof AnnotationAwareOrderComparator)) {
/* 150 */         beanFactory.setDependencyComparator((Comparator)AnnotationAwareOrderComparator.INSTANCE);
/*     */       }
/* 152 */       if (!(beanFactory.getAutowireCandidateResolver() instanceof ContextAnnotationAutowireCandidateResolver)) {
/* 153 */         beanFactory.setAutowireCandidateResolver((AutowireCandidateResolver)new ContextAnnotationAutowireCandidateResolver());
/*     */       }
/*     */     } 
/*     */     
/* 157 */     Set<BeanDefinitionHolder> beanDefs = CollectionUtils.newLinkedHashSet(6);
/*     */     
/* 159 */     if (!registry.containsBeanDefinition("org.springframework.context.annotation.internalConfigurationAnnotationProcessor")) {
/* 160 */       RootBeanDefinition def = new RootBeanDefinition(ConfigurationClassPostProcessor.class);
/* 161 */       def.setSource(source);
/* 162 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalConfigurationAnnotationProcessor"));
/*     */     } 
/*     */     
/* 165 */     if (!registry.containsBeanDefinition("org.springframework.context.annotation.internalAutowiredAnnotationProcessor")) {
/* 166 */       RootBeanDefinition def = new RootBeanDefinition(AutowiredAnnotationBeanPostProcessor.class);
/* 167 */       def.setSource(source);
/* 168 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalAutowiredAnnotationProcessor"));
/*     */     } 
/*     */ 
/*     */     
/* 172 */     if ((jakartaAnnotationsPresent || jsr250Present) && 
/* 173 */       !registry.containsBeanDefinition("org.springframework.context.annotation.internalCommonAnnotationProcessor")) {
/* 174 */       RootBeanDefinition def = new RootBeanDefinition(CommonAnnotationBeanPostProcessor.class);
/* 175 */       def.setSource(source);
/* 176 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalCommonAnnotationProcessor"));
/*     */     } 
/*     */ 
/*     */     
/* 180 */     if (jpaPresent && !registry.containsBeanDefinition("org.springframework.context.annotation.internalPersistenceAnnotationProcessor")) {
/* 181 */       RootBeanDefinition def = new RootBeanDefinition();
/*     */       try {
/* 183 */         def.setBeanClass(ClassUtils.forName("org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor", AnnotationConfigUtils.class
/* 184 */               .getClassLoader()));
/*     */       }
/* 186 */       catch (ClassNotFoundException ex) {
/* 187 */         throw new IllegalStateException("Cannot load optional framework class: org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor", ex);
/*     */       } 
/*     */       
/* 190 */       def.setSource(source);
/* 191 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalPersistenceAnnotationProcessor"));
/*     */     } 
/*     */     
/* 194 */     if (!registry.containsBeanDefinition("org.springframework.context.event.internalEventListenerProcessor")) {
/* 195 */       RootBeanDefinition def = new RootBeanDefinition(EventListenerMethodProcessor.class);
/* 196 */       def.setSource(source);
/* 197 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.event.internalEventListenerProcessor"));
/*     */     } 
/*     */     
/* 200 */     if (!registry.containsBeanDefinition("org.springframework.context.event.internalEventListenerFactory")) {
/* 201 */       RootBeanDefinition def = new RootBeanDefinition(DefaultEventListenerFactory.class);
/* 202 */       def.setSource(source);
/* 203 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.event.internalEventListenerFactory"));
/*     */     } 
/*     */     
/* 206 */     return beanDefs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static BeanDefinitionHolder registerPostProcessor(BeanDefinitionRegistry registry, RootBeanDefinition definition, String beanName) {
/* 212 */     definition.setRole(2);
/* 213 */     registry.registerBeanDefinition(beanName, (BeanDefinition)definition);
/* 214 */     return new BeanDefinitionHolder((BeanDefinition)definition, beanName);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static DefaultListableBeanFactory unwrapDefaultListableBeanFactory(BeanDefinitionRegistry registry) {
/* 219 */     if (registry instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory dlbf = (DefaultListableBeanFactory)registry;
/* 220 */       return dlbf; }
/*     */     
/* 222 */     if (registry instanceof GenericApplicationContext) { GenericApplicationContext gac = (GenericApplicationContext)registry;
/* 223 */       return gac.getDefaultListableBeanFactory(); }
/*     */ 
/*     */     
/* 226 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void processCommonDefinitionAnnotations(AnnotatedBeanDefinition abd) {
/* 231 */     processCommonDefinitionAnnotations(abd, (AnnotatedTypeMetadata)abd.getMetadata());
/*     */   }
/*     */   
/*     */   static void processCommonDefinitionAnnotations(AnnotatedBeanDefinition abd, AnnotatedTypeMetadata metadata) {
/* 235 */     AnnotationAttributes lazy = attributesFor(metadata, Lazy.class);
/* 236 */     if (lazy != null) {
/* 237 */       abd.setLazyInit(lazy.getBoolean("value"));
/*     */     }
/* 239 */     else if (abd.getMetadata() != metadata) {
/* 240 */       lazy = attributesFor((AnnotatedTypeMetadata)abd.getMetadata(), Lazy.class);
/* 241 */       if (lazy != null) {
/* 242 */         abd.setLazyInit(lazy.getBoolean("value"));
/*     */       }
/*     */     } 
/*     */     
/* 246 */     if (metadata.isAnnotated(Primary.class.getName())) {
/* 247 */       abd.setPrimary(true);
/*     */     }
/* 249 */     if (metadata.isAnnotated(Fallback.class.getName())) {
/* 250 */       abd.setFallback(true);
/*     */     }
/* 252 */     AnnotationAttributes dependsOn = attributesFor(metadata, DependsOn.class);
/* 253 */     if (dependsOn != null) {
/* 254 */       abd.setDependsOn(dependsOn.getStringArray("value"));
/*     */     }
/*     */     
/* 257 */     AnnotationAttributes role = attributesFor(metadata, Role.class);
/* 258 */     if (role != null) {
/* 259 */       abd.setRole(role.getNumber("value").intValue());
/*     */     }
/* 261 */     AnnotationAttributes description = attributesFor(metadata, Description.class);
/* 262 */     if (description != null) {
/* 263 */       abd.setDescription(description.getString("value"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static BeanDefinitionHolder applyScopedProxyMode(ScopeMetadata metadata, BeanDefinitionHolder definition, BeanDefinitionRegistry registry) {
/* 270 */     ScopedProxyMode scopedProxyMode = metadata.getScopedProxyMode();
/* 271 */     if (scopedProxyMode.equals(ScopedProxyMode.NO)) {
/* 272 */       return definition;
/*     */     }
/* 274 */     boolean proxyTargetClass = scopedProxyMode.equals(ScopedProxyMode.TARGET_CLASS);
/* 275 */     return ScopedProxyCreator.createScopedProxy(definition, registry, proxyTargetClass);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   static AnnotationAttributes attributesFor(AnnotatedTypeMetadata metadata, Class<?> annotationType) {
/* 280 */     return attributesFor(metadata, annotationType.getName());
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   static AnnotationAttributes attributesFor(AnnotatedTypeMetadata metadata, String annotationTypeName) {
/* 285 */     return AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(annotationTypeName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Set<AnnotationAttributes> attributesForRepeatable(AnnotationMetadata metadata, Class<? extends Annotation> annotationType, Class<? extends Annotation> containerType, Predicate<MergedAnnotation<? extends Annotation>> predicate) {
/* 292 */     return metadata.getMergedRepeatableAnnotationAttributes(annotationType, containerType, predicate, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Set<AnnotationAttributes> attributesForRepeatable(AnnotationMetadata metadata, Class<? extends Annotation> annotationType, Class<? extends Annotation> containerType, boolean sortByReversedMetaDistance) {
/* 299 */     return metadata.getMergedRepeatableAnnotationAttributes(annotationType, containerType, false, sortByReversedMetaDistance);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\AnnotationConfigUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */