/*      */ package org.springframework.context.annotation;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.springframework.core.Ordered;
/*      */ import org.springframework.core.type.AnnotationMetadata;
/*      */ import org.springframework.core.type.classreading.MetadataReader;
/*      */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class SourceClass
/*      */   implements Ordered
/*      */ {
/*      */   private final Object source;
/*      */   private final AnnotationMetadata metadata;
/*      */   
/*      */   public SourceClass(Object source) {
/*  965 */     this.source = source;
/*  966 */     if (source instanceof Class) { Class<?> sourceClass = (Class)source;
/*  967 */       this.metadata = AnnotationMetadata.introspect(sourceClass); }
/*      */     else
/*      */     
/*  970 */     { this.metadata = ((MetadataReader)source).getAnnotationMetadata(); }
/*      */   
/*      */   }
/*      */   
/*      */   public final AnnotationMetadata getMetadata() {
/*  975 */     return this.metadata;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getOrder() {
/*  980 */     Integer order = ConfigurationClassUtils.getOrder(this.metadata);
/*  981 */     return (order != null) ? order.intValue() : Integer.MAX_VALUE;
/*      */   }
/*      */   
/*      */   public Class<?> loadClass() throws ClassNotFoundException {
/*  985 */     Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/*  986 */       return sourceClass; }
/*      */     
/*  988 */     String className = ((MetadataReader)this.source).getClassMetadata().getClassName();
/*  989 */     return ClassUtils.forName(className, ConfigurationClassParser.this.resourceLoader.getClassLoader());
/*      */   }
/*      */   
/*      */   public boolean isAssignable(Class<?> clazz) throws IOException {
/*  993 */     Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/*  994 */       return clazz.isAssignableFrom(sourceClass); }
/*      */     
/*  996 */     return (new AssignableTypeFilter(clazz)).match((MetadataReader)this.source, ConfigurationClassParser.this.metadataReaderFactory);
/*      */   }
/*      */   
/*      */   public ConfigurationClass asConfigClass(ConfigurationClass importedBy) {
/* 1000 */     Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/* 1001 */       return new ConfigurationClass(sourceClass, importedBy); }
/*      */     
/* 1003 */     return new ConfigurationClass((MetadataReader)this.source, importedBy);
/*      */   }
/*      */   
/*      */   public Collection<SourceClass> getMemberClasses() throws IOException {
/* 1007 */     Object sourceToProcess = this.source;
/* 1008 */     if (sourceToProcess instanceof Class) { Class<?> sourceClass = (Class)sourceToProcess;
/*      */       try {
/* 1010 */         Class<?>[] declaredClasses = sourceClass.getDeclaredClasses();
/* 1011 */         List<SourceClass> list = new ArrayList<>(declaredClasses.length);
/* 1012 */         for (Class<?> declaredClass : declaredClasses) {
/* 1013 */           list.add(ConfigurationClassParser.this.asSourceClass(declaredClass, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER));
/*      */         }
/* 1015 */         return list;
/*      */       }
/* 1017 */       catch (NoClassDefFoundError err) {
/*      */ 
/*      */         
/* 1020 */         sourceToProcess = ConfigurationClassParser.this.metadataReaderFactory.getMetadataReader(sourceClass.getName());
/*      */       }  }
/*      */ 
/*      */ 
/*      */     
/* 1025 */     MetadataReader sourceReader = (MetadataReader)sourceToProcess;
/* 1026 */     String[] memberClassNames = sourceReader.getClassMetadata().getMemberClassNames();
/* 1027 */     List<SourceClass> members = new ArrayList<>(memberClassNames.length);
/* 1028 */     for (String memberClassName : memberClassNames) {
/*      */       try {
/* 1030 */         members.add(ConfigurationClassParser.this.asSourceClass(memberClassName, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER));
/*      */       }
/* 1032 */       catch (IOException ex) {
/*      */         
/* 1034 */         if (ConfigurationClassParser.this.logger.isDebugEnabled()) {
/* 1035 */           ConfigurationClassParser.this.logger.debug("Failed to resolve member class [" + memberClassName + "] - not considering it as a configuration class candidate");
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1040 */     return members;
/*      */   }
/*      */   
/*      */   public SourceClass getSuperClass() throws IOException {
/* 1044 */     Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/* 1045 */       return ConfigurationClassParser.this.asSourceClass(sourceClass.getSuperclass(), ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER); }
/*      */     
/* 1047 */     return ConfigurationClassParser.this.asSourceClass(((MetadataReader)this.source)
/* 1048 */         .getClassMetadata().getSuperClassName(), ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER);
/*      */   }
/*      */   
/*      */   public Set<SourceClass> getInterfaces() throws IOException {
/* 1052 */     Set<SourceClass> result = new LinkedHashSet<>();
/* 1053 */     Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/* 1054 */       for (Class<?> clazz : sourceClass.getInterfaces()) {
/* 1055 */         result.add(ConfigurationClassParser.this.asSourceClass(clazz, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER));
/*      */       } }
/*      */     else
/*      */     
/* 1059 */     { for (String str : this.metadata.getInterfaceNames()) {
/* 1060 */         result.add(ConfigurationClassParser.this.asSourceClass(str, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER));
/*      */       } }
/*      */     
/* 1063 */     return result;
/*      */   }
/*      */   
/*      */   public Set<SourceClass> getAnnotations() {
/* 1067 */     Set<SourceClass> result = new LinkedHashSet<>();
/* 1068 */     Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/* 1069 */       for (Annotation annotation : sourceClass.getDeclaredAnnotations()) {
/* 1070 */         Class<?> annType = annotation.annotationType();
/* 1071 */         if (!annType.getName().startsWith("java")) {
/*      */           try {
/* 1073 */             result.add(ConfigurationClassParser.this.asSourceClass(annType, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER));
/*      */           }
/* 1075 */           catch (Throwable throwable) {}
/*      */         
/*      */         }
/*      */       }
/*      */        }
/*      */     
/*      */     else
/*      */     
/* 1083 */     { for (String className : this.metadata.getAnnotationTypes()) {
/* 1084 */         if (!className.startsWith("java")) {
/*      */           try {
/* 1086 */             result.add(getRelated(className));
/*      */           }
/* 1088 */           catch (Throwable throwable) {}
/*      */         }
/*      */       }  }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1095 */     return result;
/*      */   }
/*      */   
/*      */   public Collection<SourceClass> getAnnotationAttributes(String annType, String attribute) throws IOException {
/* 1099 */     Map<String, Object> annotationAttributes = this.metadata.getAnnotationAttributes(annType, true);
/* 1100 */     if (annotationAttributes == null || !annotationAttributes.containsKey(attribute)) {
/* 1101 */       return Collections.emptySet();
/*      */     }
/* 1103 */     String[] classNames = (String[])annotationAttributes.get(attribute);
/* 1104 */     Set<SourceClass> result = CollectionUtils.newLinkedHashSet(classNames.length);
/* 1105 */     for (String className : classNames) {
/* 1106 */       result.add(getRelated(className));
/*      */     }
/* 1108 */     return result;
/*      */   }
/*      */   
/*      */   private SourceClass getRelated(String className) throws IOException {
/* 1112 */     Object object = this.source; if (object instanceof Class) { Class<?> sourceClass = (Class)object;
/*      */       try {
/* 1114 */         Class<?> clazz = ClassUtils.forName(className, sourceClass.getClassLoader());
/* 1115 */         return ConfigurationClassParser.this.asSourceClass(clazz, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER);
/*      */       }
/* 1117 */       catch (ClassNotFoundException ex) {
/*      */         
/* 1119 */         if (className.startsWith("java")) {
/* 1120 */           throw new IOException("Failed to load class [" + className + "]", ex);
/*      */         }
/* 1122 */         return new SourceClass(ConfigurationClassParser.this.metadataReaderFactory.getMetadataReader(className));
/*      */       }  }
/*      */     
/* 1125 */     return ConfigurationClassParser.this.asSourceClass(className, ConfigurationClassParser.DEFAULT_EXCLUSION_FILTER);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(@Nullable Object other) {
/* 1130 */     if (this != other) { if (other instanceof SourceClass) { SourceClass that = (SourceClass)other; if (this.metadata
/* 1131 */           .getClassName().equals(that.metadata.getClassName())); }
/*      */       
/*      */       return false; }
/*      */   
/*      */   } public int hashCode() {
/* 1136 */     return this.metadata.getClassName().hashCode();
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1141 */     return this.metadata.getClassName();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ConfigurationClassParser$SourceClass.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */