/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.AspectJTypeFilter;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.core.type.filter.RegexPatternTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TypeFilterUtils
/*     */ {
/*     */   public static List<TypeFilter> createTypeFiltersFor(AnnotationAttributes filterAttributes, Environment environment, ResourceLoader resourceLoader, BeanDefinitionRegistry registry) {
/*  76 */     List<TypeFilter> typeFilters = new ArrayList<>();
/*  77 */     FilterType filterType = (FilterType)filterAttributes.getEnum("type");
/*     */     
/*  79 */     for (Class<?> filterClass : filterAttributes.getClassArray("classes")) {
/*  80 */       Class<Annotation> annotationType; TypeFilter filter; switch (filterType) {
/*     */         case ANNOTATION:
/*  82 */           Assert.isAssignable(Annotation.class, filterClass, "@ComponentScan ANNOTATION type filter requires an annotation type");
/*     */ 
/*     */           
/*  85 */           annotationType = (Class)filterClass;
/*  86 */           typeFilters.add(new AnnotationTypeFilter(annotationType)); break;
/*     */         case ASSIGNABLE_TYPE:
/*  88 */           typeFilters.add(new AssignableTypeFilter(filterClass)); break;
/*     */         case CUSTOM:
/*  90 */           Assert.isAssignable(TypeFilter.class, filterClass, "@ComponentScan CUSTOM type filter requires a TypeFilter implementation");
/*     */           
/*  92 */           filter = ParserStrategyUtils.<TypeFilter>instantiateClass(filterClass, TypeFilter.class, environment, resourceLoader, registry);
/*     */           
/*  94 */           typeFilters.add(filter);
/*     */           break;
/*     */         default:
/*  97 */           throw new IllegalArgumentException("Filter type not supported with Class value: " + String.valueOf(filterType));
/*     */       } 
/*     */     
/*     */     } 
/* 101 */     for (String expression : filterAttributes.getStringArray("pattern")) {
/* 102 */       switch (filterType) { case ASPECTJ:
/* 103 */           typeFilters.add(new AspectJTypeFilter(expression, resourceLoader.getClassLoader())); break;
/* 104 */         case REGEX: typeFilters.add(new RegexPatternTypeFilter(Pattern.compile(expression))); break;
/*     */         default:
/* 106 */           throw new IllegalArgumentException("Filter type not supported with String pattern: " + String.valueOf(filterType)); }
/*     */ 
/*     */     
/*     */     } 
/* 110 */     return typeFilters;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\TypeFilterUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */