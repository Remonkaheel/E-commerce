/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.annotation.AliasFor;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationBeanNameGenerator
/*     */   implements BeanNameGenerator
/*     */ {
/*  88 */   public static final AnnotationBeanNameGenerator INSTANCE = new AnnotationBeanNameGenerator();
/*     */   
/*     */   private static final String COMPONENT_ANNOTATION_CLASSNAME = "org.springframework.stereotype.Component";
/*     */   
/*  92 */   private static final MergedAnnotation.Adapt[] ADAPTATIONS = MergedAnnotation.Adapt.values(false, true);
/*     */ 
/*     */   
/*  95 */   private static final Log logger = LogFactory.getLog(AnnotationBeanNameGenerator.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   private static final Set<String> conventionBasedStereotypeCheckCache = ConcurrentHashMap.newKeySet();
/*     */   
/* 106 */   private final Map<String, Set<String>> metaAnnotationTypesCache = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateBeanName(BeanDefinition definition, BeanDefinitionRegistry registry) {
/* 112 */     if (definition instanceof AnnotatedBeanDefinition) { AnnotatedBeanDefinition annotatedBeanDefinition = (AnnotatedBeanDefinition)definition;
/* 113 */       String beanName = determineBeanNameFromAnnotation(annotatedBeanDefinition);
/* 114 */       if (StringUtils.hasText(beanName))
/*     */       {
/* 116 */         return beanName;
/*     */       } }
/*     */ 
/*     */     
/* 120 */     return buildDefaultBeanName(definition, registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String determineBeanNameFromAnnotation(AnnotatedBeanDefinition annotatedDef) {
/* 130 */     AnnotationMetadata metadata = annotatedDef.getMetadata();
/*     */     
/* 132 */     String beanName = getExplicitBeanName(metadata);
/* 133 */     if (beanName != null) {
/* 134 */       return beanName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     List<MergedAnnotation<Annotation>> mergedAnnotations = metadata.getAnnotations().stream().filter(MergedAnnotation::isDirectlyPresent).toList();
/*     */     
/* 144 */     Set<AnnotationAttributes> visited = new HashSet<>();
/*     */     
/* 146 */     for (MergedAnnotation<Annotation> mergedAnnotation : mergedAnnotations) {
/* 147 */       AnnotationAttributes attributes = mergedAnnotation.asAnnotationAttributes(ADAPTATIONS);
/* 148 */       if (visited.add(attributes)) {
/* 149 */         String annotationType = mergedAnnotation.getType().getName();
/* 150 */         Set<String> metaAnnotationTypes = this.metaAnnotationTypesCache.computeIfAbsent(annotationType, key -> getMetaAnnotationTypes(mergedAnnotation));
/*     */         
/* 152 */         if (isStereotypeWithNameValue(annotationType, metaAnnotationTypes, (Map<String, Object>)attributes)) {
/* 153 */           Object value = attributes.get("value");
/* 154 */           if (value instanceof String) { String currentName = (String)value; if (!currentName.isBlank()) {
/* 155 */               if (conventionBasedStereotypeCheckCache.add(annotationType) && metaAnnotationTypes
/* 156 */                 .contains("org.springframework.stereotype.Component") && logger.isWarnEnabled()) {
/* 157 */                 if (hasExplicitlyAliasedValueAttribute(mergedAnnotation.getType())) {
/* 158 */                   logger.warn("Although the 'value' attribute in @%s declares @AliasFor for an attribute other than @Component's 'value' attribute, the value is still used as the @Component name based on convention. As of Spring Framework 7.0, such a 'value' attribute will no longer be used as the @Component name."
/*     */ 
/*     */ 
/*     */ 
/*     */                       
/* 163 */                       .formatted(new Object[] { annotationType }));
/*     */                 } else {
/*     */                   
/* 166 */                   logger.warn("Support for convention-based @Component names is deprecated and will be removed in a future version of the framework. Please annotate the 'value' attribute in @%s with @AliasFor(annotation=Component.class) to declare an explicit alias for @Component's 'value' attribute."
/*     */ 
/*     */ 
/*     */ 
/*     */                       
/* 171 */                       .formatted(new Object[] { annotationType }));
/*     */                 } 
/*     */               }
/* 174 */               if (beanName != null && !currentName.equals(beanName)) {
/* 175 */                 throw new IllegalStateException("Stereotype annotations suggest inconsistent component names: '" + beanName + "' versus '" + currentName + "'");
/*     */               }
/*     */               
/* 178 */               beanName = currentName;
/*     */             }  }
/*     */         
/*     */         } 
/*     */       } 
/* 183 */     }  return beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<String> getMetaAnnotationTypes(MergedAnnotation<Annotation> mergedAnnotation) {
/* 189 */     Set<String> result = (Set<String>)MergedAnnotations.from(mergedAnnotation.getType()).stream().map(metaAnnotation -> metaAnnotation.getType().getName()).collect(Collectors.toCollection(java.util.LinkedHashSet::new));
/* 190 */     return result.isEmpty() ? Collections.<String>emptySet() : result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String getExplicitBeanName(AnnotationMetadata metadata) {
/* 211 */     List<String> names = metadata.getAnnotations().stream("org.springframework.stereotype.Component").map(annotation -> annotation.getString("value")).filter(StringUtils::hasText).map(String::trim).distinct().toList();
/*     */     
/* 213 */     if (names.size() == 1) {
/* 214 */       return names.get(0);
/*     */     }
/* 216 */     if (names.size() > 1) {
/* 217 */       throw new IllegalStateException("Stereotype annotations suggest inconsistent component names: " + String.valueOf(names));
/*     */     }
/*     */     
/* 220 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isStereotypeWithNameValue(String annotationType, Set<String> metaAnnotationTypes, Map<String, Object> attributes) {
/* 238 */     boolean isStereotype = (metaAnnotationTypes.contains("org.springframework.stereotype.Component") || annotationType.equals("jakarta.annotation.ManagedBean") || annotationType.equals("javax.annotation.ManagedBean") || annotationType.equals("jakarta.inject.Named") || annotationType.equals("javax.inject.Named"));
/*     */     
/* 240 */     return (isStereotype && attributes.containsKey("value"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String buildDefaultBeanName(BeanDefinition definition, BeanDefinitionRegistry registry) {
/* 251 */     return buildDefaultBeanName(definition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String buildDefaultBeanName(BeanDefinition definition) {
/* 265 */     String beanClassName = definition.getBeanClassName();
/* 266 */     Assert.state((beanClassName != null), "No bean class name set");
/* 267 */     String shortClassName = ClassUtils.getShortName(beanClassName);
/* 268 */     return StringUtils.uncapitalizeAsProperty(shortClassName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasExplicitlyAliasedValueAttribute(Class<? extends Annotation> annotationType) {
/* 277 */     Method valueAttribute = ReflectionUtils.findMethod(annotationType, "value");
/* 278 */     return (valueAttribute != null && valueAttribute.isAnnotationPresent((Class)AliasFor.class));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\AnnotationBeanNameGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */