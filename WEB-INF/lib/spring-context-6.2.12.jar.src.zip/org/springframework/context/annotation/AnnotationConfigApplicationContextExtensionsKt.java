/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import kotlin.Deprecated;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.ReplaceWith;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000\026\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\002\030\002\n\000\032!\020\000\032\0020\0012\027\020\002\032\023\022\004\022\0020\001\022\004\022\0020\0040\003¢\006\002\b\005H\007¨\006\006"}, d2 = {"AnnotationConfigApplicationContext", "Lorg/springframework/context/annotation/AnnotationConfigApplicationContext;", "configure", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "spring-context"})
/*    */ public final class AnnotationConfigApplicationContextExtensionsKt
/*    */ {
/*    */   @Deprecated(message = "Use regular apply method instead.", replaceWith = @ReplaceWith(expression = "AnnotationConfigApplicationContext().apply(configure)", imports = {}))
/*    */   @NotNull
/*    */   public static final AnnotationConfigApplicationContext AnnotationConfigApplicationContext(@NotNull Function1 configure) {
/* 28 */     Intrinsics.checkNotNullParameter(configure, "configure"); AnnotationConfigApplicationContext annotationConfigApplicationContext = new AnnotationConfigApplicationContext(); configure.invoke(annotationConfigApplicationContext); return annotationConfigApplicationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\AnnotationConfigApplicationContextExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */