package org.springframework.context.annotation;

import org.springframework.beans.factory.config.BeanDefinition;

@FunctionalInterface
public interface ScopeMetadataResolver {
  ScopeMetadata resolveScopeMetadata(BeanDefinition paramBeanDefinition);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ScopeMetadataResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */