/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.aop.config.AopConfigUtils;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoProxyRegistrar
/*    */   implements ImportBeanDefinitionRegistrar
/*    */ {
/* 41 */   private final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 60 */     boolean candidateFound = false;
/* 61 */     Set<String> annTypes = importingClassMetadata.getAnnotationTypes();
/* 62 */     for (String annType : annTypes) {
/* 63 */       AnnotationAttributes candidate = AnnotationConfigUtils.attributesFor((AnnotatedTypeMetadata)importingClassMetadata, annType);
/* 64 */       if (candidate == null) {
/*    */         continue;
/*    */       }
/* 67 */       Object mode = candidate.get("mode");
/* 68 */       Object proxyTargetClass = candidate.get("proxyTargetClass");
/* 69 */       if (mode != null && proxyTargetClass != null && AdviceMode.class == mode.getClass() && Boolean.class == proxyTargetClass
/* 70 */         .getClass()) {
/* 71 */         candidateFound = true;
/* 72 */         if (mode == AdviceMode.PROXY) {
/* 73 */           AopConfigUtils.registerAutoProxyCreatorIfNecessary(registry);
/* 74 */           if (((Boolean)proxyTargetClass).booleanValue()) {
/* 75 */             AopConfigUtils.forceAutoProxyCreatorToUseClassProxying(registry);
/*    */             return;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/* 81 */     if (!candidateFound && this.logger.isInfoEnabled()) {
/* 82 */       String name = getClass().getSimpleName();
/* 83 */       this.logger.info(String.format("%s was imported but no annotations were found having both 'mode' and 'proxyTargetClass' attributes of type AdviceMode and boolean respectively. This means that auto proxy creator registration and configuration may not have occurred as intended, and components may not be proxied as expected. Check to ensure that %s has been @Import'ed on the same class where these annotations are declared; otherwise remove the import of %s altogether.", new Object[] { name, name, name }));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\AutoProxyRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */