/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ScopedProxyMode
/*    */ {
/* 36 */   DEFAULT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   NO,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   INTERFACES,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   TARGET_CLASS;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ScopedProxyMode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */