/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ResourceMethodResolver
/*     */   extends ResourceElementResolver
/*     */ {
/*     */   private final String methodName;
/*     */   private final Class<?> lookupType;
/*     */   
/*     */   private ResourceMethodResolver(String name, boolean defaultName, String methodName, Class<?> lookupType) {
/* 255 */     super(name, defaultName);
/* 256 */     this.methodName = methodName;
/* 257 */     this.lookupType = lookupType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolveAndSet(RegisteredBean registeredBean, Object instance) {
/* 262 */     Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 263 */     Assert.notNull(instance, "'instance' must not be null");
/* 264 */     Method method = getMethod(registeredBean);
/* 265 */     Object resolved = resolve(registeredBean);
/* 266 */     ReflectionUtils.makeAccessible(method);
/* 267 */     ReflectionUtils.invokeMethod(method, instance, new Object[] { resolved });
/*     */   }
/*     */ 
/*     */   
/*     */   protected DependencyDescriptor createDependencyDescriptor(RegisteredBean registeredBean) {
/* 272 */     return new ResourceElementResolver.LookupDependencyDescriptor(
/* 273 */         getMethod(registeredBean), this.lookupType, isLazyLookup(registeredBean));
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<?> getLookupType(RegisteredBean bean) {
/* 278 */     return this.lookupType;
/*     */   }
/*     */ 
/*     */   
/*     */   protected AnnotatedElement getAnnotatedElement(RegisteredBean registeredBean) {
/* 283 */     return getMethod(registeredBean);
/*     */   }
/*     */   
/*     */   private Method getMethod(RegisteredBean registeredBean) {
/* 287 */     Method method = ReflectionUtils.findMethod(registeredBean.getBeanClass(), this.methodName, new Class[] { this.lookupType });
/* 288 */     Assert.notNull(method, () -> "Method '%s' with parameter type '%s' declared on %s could not be found.".formatted(new Object[] { this.methodName, this.lookupType.getName(), registeredBean.getBeanClass().getName() }));
/*     */ 
/*     */     
/* 291 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\annotation\ResourceElementResolver$ResourceMethodResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */