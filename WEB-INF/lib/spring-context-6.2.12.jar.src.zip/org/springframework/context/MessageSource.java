package org.springframework.context;

import java.util.Locale;
import org.springframework.lang.Nullable;

public interface MessageSource {
  @Nullable
  String getMessage(String paramString1, @Nullable Object[] paramArrayOfObject, @Nullable String paramString2, @Nullable Locale paramLocale);
  
  String getMessage(String paramString, @Nullable Object[] paramArrayOfObject, @Nullable Locale paramLocale) throws NoSuchMessageException;
  
  String getMessage(MessageSourceResolvable paramMessageSourceResolvable, @Nullable Locale paramLocale) throws NoSuchMessageException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\MessageSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */