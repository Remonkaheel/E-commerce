/*    */ package org.springframework.context.expression;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*    */ import org.springframework.expression.AccessException;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.PropertyAccessor;
/*    */ import org.springframework.expression.TypedValue;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanExpressionContextAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public Class<?>[] getSpecificTargetClasses() {
/* 39 */     return new Class[] { BeanExpressionContext.class };
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canRead(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 44 */     if (target instanceof BeanExpressionContext) { BeanExpressionContext bec = (BeanExpressionContext)target; if (bec.containsObject(name)); }  return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public TypedValue read(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 49 */     Assert.state(target instanceof BeanExpressionContext, "Target must be of type BeanExpressionContext");
/* 50 */     return new TypedValue(((BeanExpressionContext)target).getObject(name));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canWrite(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 55 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(EvaluationContext context, @Nullable Object target, String name, @Nullable Object newValue) throws AccessException {
/* 62 */     throw new AccessException("Beans in a BeanFactory are read-only");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\expression\BeanExpressionContextAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */