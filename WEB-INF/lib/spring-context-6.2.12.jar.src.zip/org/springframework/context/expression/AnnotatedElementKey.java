/*    */ package org.springframework.context.expression;
/*    */ 
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AnnotatedElementKey
/*    */   implements Comparable<AnnotatedElementKey>
/*    */ {
/*    */   private final AnnotatedElement element;
/*    */   @Nullable
/*    */   private final Class<?> targetClass;
/*    */   
/*    */   public AnnotatedElementKey(AnnotatedElement element, @Nullable Class<?> targetClass) {
/* 47 */     Assert.notNull(element, "AnnotatedElement must not be null");
/* 48 */     this.element = element;
/* 49 */     this.targetClass = targetClass;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 55 */     if (this != other) { if (other instanceof AnnotatedElementKey) { AnnotatedElementKey that = (AnnotatedElementKey)other; if (this.element
/* 56 */           .equals(that.element) && 
/* 57 */           ObjectUtils.nullSafeEquals(this.targetClass, that.targetClass)); }
/*    */       
/*    */       return false; }
/*    */   
/*    */   } public int hashCode() {
/* 62 */     return this.element.hashCode() + ((this.targetClass != null) ? (this.targetClass.hashCode() * 29) : 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return String.valueOf(this.element) + String.valueOf(this.element);
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(AnnotatedElementKey other) {
/* 72 */     int result = this.element.toString().compareTo(other.element.toString());
/* 73 */     if (result == 0 && this.targetClass != null) {
/* 74 */       if (other.targetClass == null) {
/* 75 */         return 1;
/*    */       }
/* 77 */       result = this.targetClass.getName().compareTo(other.targetClass.getName());
/*    */     } 
/* 79 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\expression\AnnotatedElementKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */