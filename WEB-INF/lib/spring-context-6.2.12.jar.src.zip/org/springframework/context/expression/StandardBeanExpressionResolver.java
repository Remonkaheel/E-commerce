/*     */ package org.springframework.context.expression;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanExpressionException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*     */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.ParserContext;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypeLocator;
/*     */ import org.springframework.expression.spel.SpelParserConfiguration;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.expression.spel.support.StandardTypeConverter;
/*     */ import org.springframework.expression.spel.support.StandardTypeLocator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardBeanExpressionResolver
/*     */   implements BeanExpressionResolver
/*     */ {
/*     */   public static final String MAX_SPEL_EXPRESSION_LENGTH_PROPERTY_NAME = "spring.context.expression.maxLength";
/*     */   public static final String DEFAULT_EXPRESSION_PREFIX = "#{";
/*     */   public static final String DEFAULT_EXPRESSION_SUFFIX = "}";
/*  77 */   private String expressionPrefix = "#{";
/*     */   
/*  79 */   private String expressionSuffix = "}";
/*     */   
/*     */   private ExpressionParser expressionParser;
/*     */   
/*  83 */   private final Map<String, Expression> expressionCache = new ConcurrentHashMap<>(256);
/*     */   
/*  85 */   private final Map<BeanExpressionContext, StandardEvaluationContext> evaluationCache = new ConcurrentHashMap<>(8);
/*     */   
/*  87 */   private final ParserContext beanExpressionParserContext = new ParserContext()
/*     */     {
/*     */       public boolean isTemplate() {
/*  90 */         return true;
/*     */       }
/*     */       
/*     */       public String getExpressionPrefix() {
/*  94 */         return StandardBeanExpressionResolver.this.expressionPrefix;
/*     */       }
/*     */       
/*     */       public String getExpressionSuffix() {
/*  98 */         return StandardBeanExpressionResolver.this.expressionSuffix;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardBeanExpressionResolver() {
/* 109 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardBeanExpressionResolver(@Nullable ClassLoader beanClassLoader) {
/* 121 */     SpelParserConfiguration parserConfig = new SpelParserConfiguration(null, beanClassLoader, false, false, 2147483647, retrieveMaxExpressionLength());
/* 122 */     this.expressionParser = (ExpressionParser)new SpelExpressionParser(parserConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpressionPrefix(String expressionPrefix) {
/* 132 */     Assert.hasText(expressionPrefix, "Expression prefix must not be empty");
/* 133 */     this.expressionPrefix = expressionPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpressionSuffix(String expressionSuffix) {
/* 142 */     Assert.hasText(expressionSuffix, "Expression suffix must not be empty");
/* 143 */     this.expressionSuffix = expressionSuffix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpressionParser(ExpressionParser expressionParser) {
/* 152 */     Assert.notNull(expressionParser, "ExpressionParser must not be null");
/* 153 */     this.expressionParser = expressionParser;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object evaluate(@Nullable String value, BeanExpressionContext beanExpressionContext) throws BeansException {
/* 160 */     if (!StringUtils.hasLength(value)) {
/* 161 */       return value;
/*     */     }
/*     */     try {
/* 164 */       Expression expr = this.expressionCache.computeIfAbsent(value, expression -> this.expressionParser.parseExpression(expression, this.beanExpressionParserContext));
/*     */       
/* 166 */       EvaluationContext evalContext = (EvaluationContext)this.evaluationCache.computeIfAbsent(beanExpressionContext, bec -> {
/*     */             ConfigurableBeanFactory beanFactory = bec.getBeanFactory();
/*     */             
/*     */             StandardEvaluationContext sec = new StandardEvaluationContext(bec);
/*     */             
/*     */             sec.addPropertyAccessor(new BeanExpressionContextAccessor());
/*     */             
/*     */             sec.addPropertyAccessor(new BeanFactoryAccessor());
/*     */             sec.addPropertyAccessor((PropertyAccessor)new MapAccessor());
/*     */             sec.addPropertyAccessor(new EnvironmentAccessor());
/*     */             sec.setBeanResolver(new BeanFactoryResolver((BeanFactory)beanFactory));
/*     */             sec.setTypeLocator((TypeLocator)new StandardTypeLocator(beanFactory.getBeanClassLoader()));
/*     */             sec.setTypeConverter((TypeConverter)new StandardTypeConverter(()));
/*     */             customizeEvaluationContext(sec);
/*     */             return sec;
/*     */           });
/* 182 */       return expr.getValue(evalContext);
/*     */     }
/* 184 */     catch (Throwable ex) {
/* 185 */       throw new BeanExpressionException("Expression parsing failed", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void customizeEvaluationContext(StandardEvaluationContext evalContext) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private static int retrieveMaxExpressionLength() {
/* 197 */     String value = SpringProperties.getProperty("spring.context.expression.maxLength");
/* 198 */     if (!StringUtils.hasText(value)) {
/* 199 */       return 10000;
/*     */     }
/*     */     
/*     */     try {
/* 203 */       int maxLength = Integer.parseInt(value.trim());
/* 204 */       Assert.isTrue((maxLength > 0), () -> "Value [" + maxLength + "] for system property [spring.context.expression.maxLength] must be positive");
/*     */       
/* 206 */       return maxLength;
/*     */     }
/* 208 */     catch (NumberFormatException ex) {
/* 209 */       throw new IllegalArgumentException("Failed to parse value for system property [spring.context.expression.maxLength]: " + ex
/* 210 */           .getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\expression\StandardBeanExpressionResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */