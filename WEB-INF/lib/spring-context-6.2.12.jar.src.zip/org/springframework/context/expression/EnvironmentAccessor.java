/*    */ package org.springframework.context.expression;
/*    */ 
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.expression.AccessException;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.PropertyAccessor;
/*    */ import org.springframework.expression.TypedValue;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnvironmentAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public Class<?>[] getSpecificTargetClasses() {
/* 38 */     return new Class[] { Environment.class };
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canRead(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 43 */     return target instanceof Environment;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypedValue read(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 52 */     Assert.state(target instanceof Environment, "Target must be of type Environment");
/* 53 */     return new TypedValue(((Environment)target).getProperty(name));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canWrite(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 61 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(EvaluationContext context, @Nullable Object target, String name, @Nullable Object newValue) throws AccessException {
/* 68 */     throw new AccessException("The Environment is read-only");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\expression\EnvironmentAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */