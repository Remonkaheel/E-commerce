/*     */ package org.springframework.context.expression;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.CompilablePropertyAccessor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapAccessor
/*     */   implements CompilablePropertyAccessor
/*     */ {
/*     */   private final boolean allowWrite;
/*     */   
/*     */   public MapAccessor() {
/*  49 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapAccessor(boolean allowWrite) {
/*  59 */     this.allowWrite = allowWrite;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?>[] getSpecificTargetClasses() {
/*  65 */     return new Class[] { Map.class };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/*  70 */     if (target instanceof Map) { Map<?, ?> map = (Map<?, ?>)target; if (map.containsKey(name)); }  return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue read(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/*  75 */     Assert.state(target instanceof Map, "Target must be of type Map");
/*  76 */     Map<?, ?> map = (Map<?, ?>)target;
/*  77 */     Object value = map.get(name);
/*  78 */     if (value == null && !map.containsKey(name)) {
/*  79 */       throw new MapAccessException(name);
/*     */     }
/*  81 */     return new TypedValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/*  86 */     return (this.allowWrite && target instanceof Map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(EvaluationContext context, @Nullable Object target, String name, @Nullable Object newValue) throws AccessException {
/*  94 */     Assert.state(target instanceof Map, "Target must be of type Map");
/*  95 */     Map<Object, Object> map = (Map<Object, Object>)target;
/*  96 */     map.put(name, newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/* 101 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getPropertyType() {
/* 106 */     return Object.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(String propertyName, MethodVisitor mv, CodeFlow cf) {
/* 111 */     String descriptor = cf.lastDescriptor();
/* 112 */     if (descriptor == null || !descriptor.equals("Ljava/util/Map")) {
/* 113 */       if (descriptor == null) {
/* 114 */         cf.loadTarget(mv);
/*     */       }
/* 116 */       CodeFlow.insertCheckCast(mv, "Ljava/util/Map");
/*     */     } 
/* 118 */     mv.visitLdcInsn(propertyName);
/* 119 */     mv.visitMethodInsn(185, "java/util/Map", "get", "(Ljava/lang/Object;)Ljava/lang/Object;", true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MapAccessException
/*     */     extends AccessException
/*     */   {
/*     */     private final String key;
/*     */ 
/*     */ 
/*     */     
/*     */     public MapAccessException(String key) {
/* 133 */       super("");
/* 134 */       this.key = key;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getMessage() {
/* 139 */       return "Map does not contain a value for key '" + this.key + "'";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\expression\MapAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */