/*    */ package org.springframework.context.expression;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.expression.AccessException;
/*    */ import org.springframework.expression.BeanResolver;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanFactoryResolver
/*    */   implements BeanResolver
/*    */ {
/*    */   private final BeanFactory beanFactory;
/*    */   
/*    */   public BeanFactoryResolver(BeanFactory beanFactory) {
/* 42 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 43 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object resolve(EvaluationContext context, String beanName) throws AccessException {
/*    */     try {
/* 50 */       return this.beanFactory.getBean(beanName);
/*    */     }
/* 52 */     catch (BeansException ex) {
/* 53 */       throw new AccessException("Could not resolve bean reference against BeanFactory", ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\expression\BeanFactoryResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */