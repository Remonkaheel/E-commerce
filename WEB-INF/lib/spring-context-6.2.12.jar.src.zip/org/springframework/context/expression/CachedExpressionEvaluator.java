/*     */ package org.springframework.context.expression;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CachedExpressionEvaluator
/*     */ {
/*     */   private final SpelExpressionParser parser;
/*  40 */   private final ParameterNameDiscoverer parameterNameDiscoverer = (ParameterNameDiscoverer)new DefaultParameterNameDiscoverer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CachedExpressionEvaluator() {
/*  47 */     this(new SpelExpressionParser());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CachedExpressionEvaluator(SpelExpressionParser parser) {
/*  54 */     Assert.notNull(parser, "SpelExpressionParser must not be null");
/*  55 */     this.parser = parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpelExpressionParser getParser() {
/*  63 */     return this.parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParameterNameDiscoverer getParameterNameDiscoverer() {
/*  71 */     return this.parameterNameDiscoverer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Expression getExpression(Map<ExpressionKey, Expression> cache, AnnotatedElementKey elementKey, String expression) {
/*  86 */     ExpressionKey expressionKey = createKey(elementKey, expression);
/*  87 */     return cache.computeIfAbsent(expressionKey, key -> parseExpression(expression));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Expression parseExpression(String expression) {
/*  96 */     return getParser().parseExpression(expression);
/*     */   }
/*     */   
/*     */   private ExpressionKey createKey(AnnotatedElementKey elementKey, String expression) {
/* 100 */     return new ExpressionKey(elementKey, expression);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class ExpressionKey
/*     */     implements Comparable<ExpressionKey>
/*     */   {
/*     */     private final AnnotatedElementKey element;
/*     */     
/*     */     private final String expression;
/*     */ 
/*     */     
/*     */     protected ExpressionKey(AnnotatedElementKey element, String expression) {
/* 114 */       Assert.notNull(element, "AnnotatedElementKey must not be null");
/* 115 */       Assert.notNull(expression, "Expression must not be null");
/* 116 */       this.element = element;
/* 117 */       this.expression = expression;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 122 */       if (this != other) { if (other instanceof ExpressionKey) { ExpressionKey that = (ExpressionKey)other; if (this.element
/* 123 */             .equals(that.element) && this.expression.equals(that.expression)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 128 */       return this.element.hashCode() * 29 + this.expression.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 133 */       return String.valueOf(this.element) + " with expression \"" + String.valueOf(this.element) + "\"";
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(ExpressionKey other) {
/* 138 */       int result = this.element.toString().compareTo(other.element.toString());
/* 139 */       if (result == 0) {
/* 140 */         result = this.expression.compareTo(other.expression);
/*     */       }
/* 142 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\expression\CachedExpressionEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */