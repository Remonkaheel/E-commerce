/*     */ package org.springframework.context.expression;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodBasedEvaluationContext
/*     */   extends StandardEvaluationContext
/*     */ {
/*     */   private final Method method;
/*     */   private final Object[] arguments;
/*     */   private final ParameterNameDiscoverer parameterNameDiscoverer;
/*     */   private boolean argumentsLoaded = false;
/*     */   
/*     */   public MethodBasedEvaluationContext(Object rootObject, Method method, Object[] arguments, ParameterNameDiscoverer parameterNameDiscoverer) {
/*  58 */     super(rootObject);
/*  59 */     this.method = method;
/*  60 */     this
/*  61 */       .arguments = KotlinDetector.isSuspendingFunction(method) ? Arrays.<Object>copyOf(arguments, arguments.length - 1) : arguments;
/*  62 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object lookupVariable(String name) {
/*  69 */     Object variable = super.lookupVariable(name);
/*  70 */     if (variable != null) {
/*  71 */       return variable;
/*     */     }
/*  73 */     if (!this.argumentsLoaded) {
/*  74 */       lazyLoadArguments();
/*  75 */       this.argumentsLoaded = true;
/*  76 */       variable = super.lookupVariable(name);
/*     */     } 
/*  78 */     return variable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void lazyLoadArguments() {
/*  86 */     if (ObjectUtils.isEmpty(this.arguments)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  91 */     String[] paramNames = this.parameterNameDiscoverer.getParameterNames(this.method);
/*  92 */     int paramCount = (paramNames != null) ? paramNames.length : this.method.getParameterCount();
/*  93 */     int argsCount = this.arguments.length;
/*     */     
/*  95 */     for (int i = 0; i < paramCount; i++) {
/*  96 */       Object value = null;
/*  97 */       if (argsCount > paramCount && i == paramCount - 1) {
/*     */         
/*  99 */         value = Arrays.copyOfRange(this.arguments, i, argsCount);
/*     */       }
/* 101 */       else if (argsCount > i) {
/*     */         
/* 103 */         value = this.arguments[i];
/*     */       } 
/* 105 */       setVariable("a" + i, value);
/* 106 */       setVariable("p" + i, value);
/* 107 */       if (paramNames != null && paramNames[i] != null)
/* 108 */         setVariable(paramNames[i], value); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\expression\MethodBasedEvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */