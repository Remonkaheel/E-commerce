/*    */ package org.springframework.context.config;
/*    */ 
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.AbstractBeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.jmx.support.MBeanServerFactoryBean;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MBeanServerBeanDefinitionParser
/*    */   extends AbstractBeanDefinitionParser
/*    */ {
/*    */   private static final String MBEAN_SERVER_BEAN_NAME = "mbeanServer";
/*    */   private static final String AGENT_ID_ATTRIBUTE = "agent-id";
/*    */   
/*    */   protected String resolveId(Element element, AbstractBeanDefinition definition, ParserContext parserContext) {
/* 50 */     String id = element.getAttribute("id");
/* 51 */     return StringUtils.hasText(id) ? id : "mbeanServer";
/*    */   }
/*    */ 
/*    */   
/*    */   protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext) {
/* 56 */     String agentId = element.getAttribute("agent-id");
/* 57 */     if (StringUtils.hasText(agentId)) {
/* 58 */       RootBeanDefinition rootBeanDefinition = new RootBeanDefinition(MBeanServerFactoryBean.class);
/* 59 */       rootBeanDefinition.getPropertyValues().add("agentId", agentId);
/* 60 */       return (AbstractBeanDefinition)rootBeanDefinition;
/*    */     } 
/*    */     
/* 63 */     RootBeanDefinition bd = new RootBeanDefinition(MBeanServerFactoryBean.class);
/* 64 */     bd.getPropertyValues().add("locateExistingServerIfPossible", Boolean.TRUE);
/*    */ 
/*    */     
/* 67 */     bd.setRole(2);
/* 68 */     bd.setSource(parserContext.extractSource(element));
/* 69 */     return (AbstractBeanDefinition)bd;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\config\MBeanServerBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */