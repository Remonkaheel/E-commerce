package org.springframework.context;

import org.springframework.beans.factory.Aware;
import org.springframework.core.io.ResourceLoader;

public interface ResourceLoaderAware extends Aware {
  void setResourceLoader(ResourceLoader paramResourceLoader);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\ResourceLoaderAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */