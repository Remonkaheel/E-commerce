package org.springframework.context;

import org.springframework.beans.factory.Aware;

public interface MessageSourceAware extends Aware {
  void setMessageSource(MessageSource paramMessageSource);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\MessageSourceAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */