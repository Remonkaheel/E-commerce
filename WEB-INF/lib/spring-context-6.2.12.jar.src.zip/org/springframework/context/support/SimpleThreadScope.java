/*    */ package org.springframework.context.support;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.function.Supplier;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.ObjectFactory;
/*    */ import org.springframework.beans.factory.config.Scope;
/*    */ import org.springframework.core.NamedThreadLocal;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleThreadScope
/*    */   implements Scope
/*    */ {
/* 56 */   private static final Log logger = LogFactory.getLog(SimpleThreadScope.class);
/*    */   
/* 58 */   private final ThreadLocal<Map<String, Object>> threadScope = NamedThreadLocal.withInitial("SimpleThreadScope", java.util.HashMap::new);
/*    */ 
/*    */ 
/*    */   
/*    */   public Object get(String name, ObjectFactory<?> objectFactory) {
/* 63 */     Map<String, Object> scope = this.threadScope.get();
/*    */ 
/*    */     
/* 66 */     Object scopedObject = scope.get(name);
/* 67 */     if (scopedObject == null) {
/* 68 */       scopedObject = objectFactory.getObject();
/* 69 */       scope.put(name, scopedObject);
/*    */     } 
/* 71 */     return scopedObject;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object remove(String name) {
/* 77 */     Map<String, Object> scope = this.threadScope.get();
/* 78 */     return scope.remove(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void registerDestructionCallback(String name, Runnable callback) {
/* 83 */     logger.warn("SimpleThreadScope does not support destruction callbacks. Consider using RequestScope in a web environment.");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object resolveContextualObject(String key) {
/* 90 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConversationId() {
/* 95 */     return Thread.currentThread().getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\SimpleThreadScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */