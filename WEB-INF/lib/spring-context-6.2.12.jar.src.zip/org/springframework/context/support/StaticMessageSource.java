/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StaticMessageSource
/*     */   extends AbstractMessageSource
/*     */ {
/*  39 */   private final Map<String, Map<Locale, MessageHolder>> messageMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale) {
/*  45 */     Map<Locale, MessageHolder> localeMap = this.messageMap.get(code);
/*  46 */     if (localeMap == null) {
/*  47 */       return null;
/*     */     }
/*  49 */     MessageHolder holder = localeMap.get(locale);
/*  50 */     if (holder == null) {
/*  51 */       return null;
/*     */     }
/*  53 */     return holder.getMessage();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected MessageFormat resolveCode(String code, Locale locale) {
/*  59 */     Map<Locale, MessageHolder> localeMap = this.messageMap.get(code);
/*  60 */     if (localeMap == null) {
/*  61 */       return null;
/*     */     }
/*  63 */     MessageHolder holder = localeMap.get(locale);
/*  64 */     if (holder == null) {
/*  65 */       return null;
/*     */     }
/*  67 */     return holder.getMessageFormat();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMessage(String code, Locale locale, String msg) {
/*  77 */     Assert.notNull(code, "Code must not be null");
/*  78 */     Assert.notNull(locale, "Locale must not be null");
/*  79 */     Assert.notNull(msg, "Message must not be null");
/*  80 */     ((Map<Locale, MessageHolder>)this.messageMap.computeIfAbsent(code, key -> new HashMap<>(4))).put(locale, new MessageHolder(msg, locale));
/*  81 */     if (this.logger.isDebugEnabled()) {
/*  82 */       this.logger.debug("Added message [" + msg + "] for code [" + code + "] and Locale [" + String.valueOf(locale) + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMessages(Map<String, String> messages, Locale locale) {
/*  93 */     Assert.notNull(messages, "Messages Map must not be null");
/*  94 */     messages.forEach((code, msg) -> addMessage(code, locale, msg));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 100 */     return getClass().getName() + ": " + getClass().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   private class MessageHolder
/*     */   {
/*     */     private final String message;
/*     */     
/*     */     private final Locale locale;
/*     */     
/*     */     @Nullable
/*     */     private volatile MessageFormat cachedFormat;
/*     */     
/*     */     public MessageHolder(String message, Locale locale) {
/* 114 */       this.message = message;
/* 115 */       this.locale = locale;
/*     */     }
/*     */     
/*     */     public String getMessage() {
/* 119 */       return this.message;
/*     */     }
/*     */     
/*     */     public MessageFormat getMessageFormat() {
/* 123 */       MessageFormat messageFormat = this.cachedFormat;
/* 124 */       if (messageFormat == null) {
/* 125 */         messageFormat = StaticMessageSource.this.createMessageFormat(this.message, this.locale);
/* 126 */         this.cachedFormat = messageFormat;
/*     */       } 
/* 128 */       return messageFormat;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 133 */       return this.message;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\StaticMessageSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */