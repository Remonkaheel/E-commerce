/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import org.springframework.core.OverridingClassLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ContextOverridingClassLoader
/*     */   extends OverridingClassLoader
/*     */ {
/*     */   public ContextOverridingClassLoader(ClassLoader parent) {
/* 105 */     super(parent);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isEligibleForOverriding(String className) {
/* 110 */     if (isExcluded(className) || ContextTypeMatchClassLoader.access$000(ContextTypeMatchClassLoader.this, className)) {
/* 111 */       return false;
/*     */     }
/* 113 */     if (ContextTypeMatchClassLoader.findLoadedClassMethod != null) {
/* 114 */       ClassLoader parent = getParent();
/* 115 */       while (parent != null) {
/* 116 */         if (ReflectionUtils.invokeMethod(ContextTypeMatchClassLoader.findLoadedClassMethod, parent, new Object[] { className }) != null) {
/* 117 */           return false;
/*     */         }
/* 119 */         parent = parent.getParent();
/*     */       } 
/*     */     } 
/* 122 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Class<?> loadClassForOverriding(String name) throws ClassNotFoundException {
/* 128 */     byte[] bytes = ContextTypeMatchClassLoader.this.bytesCache.get(name);
/* 129 */     if (bytes == null) {
/* 130 */       bytes = loadBytesForClass(name);
/* 131 */       if (bytes != null) {
/* 132 */         ContextTypeMatchClassLoader.this.bytesCache.put(name, bytes);
/*     */       } else {
/*     */         
/* 135 */         return null;
/*     */       } 
/*     */     } 
/* 138 */     return defineClass(name, bytes, 0, bytes.length);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\ContextTypeMatchClassLoader$ContextOverridingClassLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */