/*    */ package org.springframework.context.support;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.function.Supplier;
/*    */ import kotlin.Deprecated;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.ReplaceWith;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.springframework.beans.factory.config.BeanDefinitionCustomizer;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000:\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\002\030\002\n\002\b\002\n\002\020\000\n\000\n\002\020\021\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\004\032!\020\000\032\0020\0012\027\020\002\032\023\022\004\022\0020\001\022\004\022\0020\0040\003¢\006\002\b\005H\007\0322\020\006\032\0020\004\"\n\b\000\020\007\030\001*\0020\b*\0020\0012\022\020\t\032\n\022\006\b\001\022\0020\0130\n\"\0020\013H\b¢\006\002\020\f\032K\020\006\032\0020\004\"\n\b\000\020\007\030\001*\0020\b*\0020\0012\022\020\t\032\n\022\006\b\001\022\0020\0130\n\"\0020\0132\024\b\004\020\r\032\016\022\004\022\0020\016\022\004\022\002H\0070\003H\bø\001\000¢\006\002\020\017\032:\020\006\032\0020\004\"\n\b\000\020\007\030\001*\0020\b*\0020\0012\006\020\020\032\0020\0212\022\020\t\032\n\022\006\b\001\022\0020\0130\n\"\0020\013H\b¢\006\002\020\022\032S\020\006\032\0020\004\"\n\b\000\020\007\030\001*\0020\b*\0020\0012\006\020\023\032\0020\0212\022\020\t\032\n\022\006\b\001\022\0020\0130\n\"\0020\0132\024\b\004\020\r\032\016\022\004\022\0020\016\022\004\022\002H\0070\003H\bø\001\000¢\006\002\020\024\002\007\n\005\b20\001¨\006\025"}, d2 = {"GenericApplicationContext", "Lorg/springframework/context/support/GenericApplicationContext;", "configure", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "registerBean", "T", "", "customizers", "", "Lorg/springframework/beans/factory/config/BeanDefinitionCustomizer;", "(Lorg/springframework/context/support/GenericApplicationContext;[Lorg/springframework/beans/factory/config/BeanDefinitionCustomizer;)V", "function", "Lorg/springframework/context/ApplicationContext;", "(Lorg/springframework/context/support/GenericApplicationContext;[Lorg/springframework/beans/factory/config/BeanDefinitionCustomizer;Lkotlin/jvm/functions/Function1;)V", "beanName", "", "(Lorg/springframework/context/support/GenericApplicationContext;Ljava/lang/String;[Lorg/springframework/beans/factory/config/BeanDefinitionCustomizer;)V", "name", "(Lorg/springframework/context/support/GenericApplicationContext;Ljava/lang/String;[Lorg/springframework/beans/factory/config/BeanDefinitionCustomizer;Lkotlin/jvm/functions/Function1;)V", "spring-context"})
/*    */ public final class GenericApplicationContextExtensionsKt
/*    */ {
/*    */   @Metadata(mv = {1, 7, 0}, k = 3, xi = 176, d1 = {"\000\f\n\002\b\003\n\002\020\000\n\002\b\002\020\000\032\n \002*\004\030\001H\001H\001\"\n\b\000\020\001\030\001*\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "T", "kotlin.jvm.PlatformType", "", "get", "()Ljava/lang/Object;"})
/*    */   @SourceDebugExtension({"SMAP\nGenericApplicationContextExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GenericApplicationContextExtensions.kt\norg/springframework/context/support/GenericApplicationContextExtensionsKt$registerBean$1\n*L\n1#1,80:1\n*E\n"})
/*    */   public static final class GenericApplicationContextExtensionsKt$registerBean$1<T>
/*    */     implements Supplier
/*    */   {
/*    */     public GenericApplicationContextExtensionsKt$registerBean$1(Function1<ApplicationContext, T> $function, GenericApplicationContext $receiver) {}
/*    */     
/*    */     public final T get() {
/* 54 */       return (T)this.$function.invoke(this.$this_registerBean);
/*    */     }
/*    */   }
/*    */   
/*    */   @Metadata(mv = {1, 7, 0}, k = 3, xi = 176, d1 = {"\000\f\n\002\b\003\n\002\020\000\n\002\b\002\020\000\032\n \002*\004\030\001H\001H\001\"\n\b\000\020\001\030\001*\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "T", "kotlin.jvm.PlatformType", "", "get", "()Ljava/lang/Object;"})
/*    */   @SourceDebugExtension({"SMAP\nGenericApplicationContextExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GenericApplicationContextExtensions.kt\norg/springframework/context/support/GenericApplicationContextExtensionsKt$registerBean$2\n*L\n1#1,80:1\n*E\n"})
/*    */   public static final class GenericApplicationContextExtensionsKt$registerBean$2<T>
/*    */     implements Supplier
/*    */   {
/*    */     public GenericApplicationContextExtensionsKt$registerBean$2(Function1<ApplicationContext, T> $function, GenericApplicationContext $receiver) {}
/*    */     
/*    */     public final T get() {
/* 66 */       return (T)this.$function.invoke(this.$this_registerBean);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(message = "Use regular apply method instead.", replaceWith = @ReplaceWith(expression = "GenericApplicationContext().apply(configure)", imports = {}))
/*    */   @NotNull
/*    */   public static final GenericApplicationContext GenericApplicationContext(@NotNull Function1 configure) {
/* 78 */     Intrinsics.checkNotNullParameter(configure, "configure"); GenericApplicationContext genericApplicationContext = new GenericApplicationContext(); configure.invoke(genericApplicationContext); return genericApplicationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\GenericApplicationContextExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */