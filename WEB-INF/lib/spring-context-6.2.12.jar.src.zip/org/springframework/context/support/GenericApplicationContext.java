/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.support.ClassHintUtils;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionCustomizer;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.io.ProtocolResolver;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.metrics.ApplicationStartup;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericApplicationContext
/*     */   extends AbstractApplicationContext
/*     */   implements BeanDefinitionRegistry
/*     */ {
/*     */   private final DefaultListableBeanFactory beanFactory;
/*     */   @Nullable
/*     */   private ResourceLoader resourceLoader;
/*     */   private boolean customClassLoader = false;
/* 115 */   private final AtomicBoolean refreshed = new AtomicBoolean();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericApplicationContext() {
/* 124 */     this.beanFactory = new DefaultListableBeanFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericApplicationContext(DefaultListableBeanFactory beanFactory) {
/* 134 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 135 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericApplicationContext(@Nullable ApplicationContext parent) {
/* 145 */     this();
/* 146 */     setParent(parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericApplicationContext(DefaultListableBeanFactory beanFactory, ApplicationContext parent) {
/* 157 */     this(beanFactory);
/* 158 */     setParent(parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(@Nullable ApplicationContext parent) {
/* 169 */     super.setParent(parent);
/* 170 */     this.beanFactory.setParentBeanFactory(getInternalParentBeanFactory());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationStartup(ApplicationStartup applicationStartup) {
/* 175 */     super.setApplicationStartup(applicationStartup);
/* 176 */     this.beanFactory.setApplicationStartup(applicationStartup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowBeanDefinitionOverriding(boolean allowBeanDefinitionOverriding) {
/* 187 */     this.beanFactory.setAllowBeanDefinitionOverriding(allowBeanDefinitionOverriding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowCircularReferences(boolean allowCircularReferences) {
/* 199 */     this.beanFactory.setAllowCircularReferences(allowCircularReferences);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 221 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Resource getResource(String location) {
/* 240 */     if (this.resourceLoader != null) {
/* 241 */       for (ProtocolResolver protocolResolver : getProtocolResolvers()) {
/* 242 */         Resource resource = protocolResolver.resolve(location, (ResourceLoader)this);
/* 243 */         if (resource != null) {
/* 244 */           return resource;
/*     */         }
/*     */       } 
/* 247 */       return this.resourceLoader.getResource(location);
/*     */     } 
/* 249 */     return super.getResource(location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Resource[] getResources(String locationPattern) throws IOException {
/* 260 */     ResourceLoader resourceLoader = this.resourceLoader; if (resourceLoader instanceof ResourcePatternResolver) { ResourcePatternResolver resourcePatternResolver = (ResourcePatternResolver)resourceLoader;
/* 261 */       return resourcePatternResolver.getResources(locationPattern); }
/*     */     
/* 263 */     return super.getResources(locationPattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClassLoader(@Nullable ClassLoader classLoader) {
/* 268 */     super.setClassLoader(classLoader);
/* 269 */     this.customClassLoader = true;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ClassLoader getClassLoader() {
/* 275 */     if (this.resourceLoader != null && !this.customClassLoader) {
/* 276 */       return this.resourceLoader.getClassLoader();
/*     */     }
/* 278 */     return super.getClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void refreshBeanFactory() throws IllegalStateException {
/* 293 */     if (!this.refreshed.compareAndSet(false, true)) {
/* 294 */       throw new IllegalStateException("GenericApplicationContext does not support multiple refresh attempts: just call 'refresh' once");
/*     */     }
/*     */     
/* 297 */     this.beanFactory.setSerializationId(getId());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void cancelRefresh(Throwable ex) {
/* 302 */     this.beanFactory.setSerializationId(null);
/* 303 */     super.cancelRefresh(ex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void closeBeanFactory() {
/* 312 */     this.beanFactory.setSerializationId(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ConfigurableListableBeanFactory getBeanFactory() {
/* 321 */     return (ConfigurableListableBeanFactory)this.beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DefaultListableBeanFactory getDefaultListableBeanFactory() {
/* 333 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public AutowireCapableBeanFactory getAutowireCapableBeanFactory() throws IllegalStateException {
/* 338 */     assertBeanFactoryActive();
/* 339 */     return (AutowireCapableBeanFactory)this.beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerBeanDefinition(String beanName, BeanDefinition beanDefinition) throws BeanDefinitionStoreException {
/* 351 */     this.beanFactory.registerBeanDefinition(beanName, beanDefinition);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeBeanDefinition(String beanName) throws NoSuchBeanDefinitionException {
/* 356 */     this.beanFactory.removeBeanDefinition(beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDefinition getBeanDefinition(String beanName) throws NoSuchBeanDefinitionException {
/* 361 */     return this.beanFactory.getBeanDefinition(beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBeanDefinitionOverridable(String beanName) {
/* 366 */     return this.beanFactory.isBeanDefinitionOverridable(beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBeanNameInUse(String beanName) {
/* 371 */     return this.beanFactory.isBeanNameInUse(beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerAlias(String beanName, String alias) {
/* 376 */     this.beanFactory.registerAlias(beanName, alias);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAlias(String alias) {
/* 381 */     this.beanFactory.removeAlias(alias);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAlias(String beanName) {
/* 386 */     return this.beanFactory.isAlias(beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refreshForAotProcessing(RuntimeHints runtimeHints) {
/* 409 */     if (this.logger.isDebugEnabled()) {
/* 410 */       this.logger.debug("Preparing bean factory for AOT processing");
/*     */     }
/* 412 */     prepareRefresh();
/* 413 */     obtainFreshBeanFactory();
/* 414 */     prepareBeanFactory((ConfigurableListableBeanFactory)this.beanFactory);
/* 415 */     postProcessBeanFactory((ConfigurableListableBeanFactory)this.beanFactory);
/* 416 */     invokeBeanFactoryPostProcessors((ConfigurableListableBeanFactory)this.beanFactory);
/* 417 */     this.beanFactory.freezeConfiguration();
/* 418 */     PostProcessorRegistrationDelegate.invokeMergedBeanDefinitionPostProcessors(this.beanFactory);
/* 419 */     preDetermineBeanTypes(runtimeHints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void preDetermineBeanTypes(RuntimeHints runtimeHints) {
/* 428 */     List<String> singletons = new ArrayList<>();
/* 429 */     List<String> lazyBeans = new ArrayList<>();
/*     */ 
/*     */     
/* 432 */     for (String beanName : this.beanFactory.getSingletonNames()) {
/* 433 */       Class<?> beanType = this.beanFactory.getType(beanName);
/* 434 */       if (beanType != null) {
/* 435 */         ClassHintUtils.registerProxyIfNecessary(beanType, runtimeHints);
/*     */       }
/* 437 */       singletons.add(beanName);
/*     */     } 
/*     */ 
/*     */     
/* 441 */     List<SmartInstantiationAwareBeanPostProcessor> bpps = PostProcessorRegistrationDelegate.loadBeanPostProcessors((ConfigurableListableBeanFactory)this.beanFactory, SmartInstantiationAwareBeanPostProcessor.class);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 446 */     for (String beanName : this.beanFactory.getBeanDefinitionNames()) {
/* 447 */       if (!singletons.contains(beanName)) {
/* 448 */         BeanDefinition bd = getBeanDefinition(beanName);
/* 449 */         if (bd.isSingleton() && !bd.isLazyInit()) {
/* 450 */           preDetermineBeanType(beanName, bpps, runtimeHints);
/*     */         } else {
/*     */           
/* 453 */           lazyBeans.add(beanName);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 459 */     for (String beanName : lazyBeans) {
/* 460 */       preDetermineBeanType(beanName, bpps, runtimeHints);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void preDetermineBeanType(String beanName, List<SmartInstantiationAwareBeanPostProcessor> bpps, RuntimeHints runtimeHints) {
/* 467 */     Class<?> beanType = this.beanFactory.getType(beanName);
/* 468 */     if (beanType != null) {
/* 469 */       ClassHintUtils.registerProxyIfNecessary(beanType, runtimeHints);
/* 470 */       for (SmartInstantiationAwareBeanPostProcessor bpp : bpps) {
/* 471 */         Class<?> newBeanType = bpp.determineBeanType(beanType, beanName);
/* 472 */         if (newBeanType != beanType) {
/* 473 */           ClassHintUtils.registerProxyIfNecessary(newBeanType, runtimeHints);
/* 474 */           beanType = newBeanType;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void registerBean(Class<T> beanClass, Object... constructorArgs) {
/* 496 */     registerBean((String)null, beanClass, constructorArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void registerBean(@Nullable String beanName, Class<T> beanClass, Object... constructorArgs) {
/* 511 */     registerBean(beanName, beanClass, (Supplier<T>)null, new BeanDefinitionCustomizer[] { bd -> {
/*     */             for (Object arg : constructorArgs) {
/*     */               bd.getConstructorArgumentValues().addGenericArgumentValue(arg);
/*     */             }
/*     */           } });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> void registerBean(Class<T> beanClass, BeanDefinitionCustomizer... customizers) {
/* 530 */     registerBean((String)null, beanClass, (Supplier<T>)null, customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> void registerBean(@Nullable String beanName, Class<T> beanClass, BeanDefinitionCustomizer... customizers) {
/* 547 */     registerBean(beanName, beanClass, (Supplier<T>)null, customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> void registerBean(Class<T> beanClass, Supplier<T> supplier, BeanDefinitionCustomizer... customizers) {
/* 565 */     registerBean((String)null, beanClass, supplier, customizers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void registerBean(@Nullable String beanName, Class<T> beanClass, @Nullable Supplier<T> supplier, BeanDefinitionCustomizer... customizers) {
/* 586 */     ClassDerivedBeanDefinition beanDefinition = new ClassDerivedBeanDefinition(beanClass);
/* 587 */     if (supplier != null) {
/* 588 */       beanDefinition.setInstanceSupplier(supplier);
/*     */     }
/* 590 */     for (BeanDefinitionCustomizer customizer : customizers) {
/* 591 */       customizer.customize((BeanDefinition)beanDefinition);
/*     */     }
/*     */     
/* 594 */     String nameToUse = (beanName != null) ? beanName : beanClass.getName();
/* 595 */     registerBeanDefinition(nameToUse, (BeanDefinition)beanDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ClassDerivedBeanDefinition
/*     */     extends RootBeanDefinition
/*     */   {
/*     */     public ClassDerivedBeanDefinition(Class<?> beanClass) {
/* 607 */       super(beanClass);
/*     */     }
/*     */     
/*     */     public ClassDerivedBeanDefinition(ClassDerivedBeanDefinition original) {
/* 611 */       super(original);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Constructor<?>[] getPreferredConstructors() {
/* 617 */       Constructor[] arrayOfConstructor1 = super.getPreferredConstructors();
/* 618 */       if (arrayOfConstructor1 != null) {
/* 619 */         return (Constructor<?>[])arrayOfConstructor1;
/*     */       }
/* 621 */       Class<?> clazz = getBeanClass();
/* 622 */       Constructor<?> primaryCtor = BeanUtils.findPrimaryConstructor(clazz);
/* 623 */       if (primaryCtor != null) {
/* 624 */         return (Constructor<?>[])new Constructor[] { primaryCtor };
/*     */       }
/* 626 */       Constructor[] arrayOfConstructor2 = (Constructor[])clazz.getConstructors();
/* 627 */       if (arrayOfConstructor2.length > 0) {
/* 628 */         return (Constructor<?>[])arrayOfConstructor2;
/*     */       }
/* 630 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public RootBeanDefinition cloneBeanDefinition() {
/* 635 */       return new ClassDerivedBeanDefinition(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\GenericApplicationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */