/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.PlaceholderConfigurerSupport;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.ConfigurablePropertyResolver;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertiesPropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.core.env.PropertySourcesPropertyResolver;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertySourcesPlaceholderConfigurer
/*     */   extends PlaceholderConfigurerSupport
/*     */   implements EnvironmentAware
/*     */ {
/*     */   public static final String LOCAL_PROPERTIES_PROPERTY_SOURCE_NAME = "localProperties";
/*     */   public static final String ENVIRONMENT_PROPERTIES_PROPERTY_SOURCE_NAME = "environmentProperties";
/*     */   @Nullable
/*     */   private MutablePropertySources propertySources;
/*     */   @Nullable
/*     */   private PropertySources appliedPropertySources;
/*     */   @Nullable
/*     */   private Environment environment;
/*     */   
/*     */   public void setPropertySources(PropertySources propertySources) {
/* 100 */     this.propertySources = new MutablePropertySources(propertySources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/* 112 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
/* 133 */     if (this.propertySources == null) {
/* 134 */       this.propertySources = new MutablePropertySources();
/* 135 */       if (this.environment != null) {
/*     */         
/* 137 */         Environment environment = this.environment; ConfigurableEnvironment configurableEnvironment = (ConfigurableEnvironment)environment;
/*     */         
/* 139 */         PropertySource<?> environmentPropertySource = (environment instanceof ConfigurableEnvironment) ? new ConfigurableEnvironmentPropertySource(configurableEnvironment) : new FallbackEnvironmentPropertySource(this.environment);
/* 140 */         this.propertySources.addLast(environmentPropertySource);
/*     */       } 
/*     */       
/*     */       try {
/* 144 */         PropertiesPropertySource propertiesPropertySource = new PropertiesPropertySource("localProperties", mergeProperties());
/* 145 */         if (this.localOverride) {
/* 146 */           this.propertySources.addFirst((PropertySource)propertiesPropertySource);
/*     */         } else {
/*     */           
/* 149 */           this.propertySources.addLast((PropertySource)propertiesPropertySource);
/*     */         }
/*     */       
/* 152 */       } catch (IOException ex) {
/* 153 */         throw new BeanInitializationException("Could not load properties", ex);
/*     */       } 
/*     */     } 
/*     */     
/* 157 */     processProperties(beanFactory, createPropertyResolver(this.propertySources));
/* 158 */     this.appliedPropertySources = (PropertySources)this.propertySources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConfigurablePropertyResolver createPropertyResolver(MutablePropertySources propertySources) {
/* 168 */     return (ConfigurablePropertyResolver)new PropertySourcesPropertyResolver((PropertySources)propertySources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, ConfigurablePropertyResolver propertyResolver) throws BeansException {
/* 178 */     propertyResolver.setPlaceholderPrefix(this.placeholderPrefix);
/* 179 */     propertyResolver.setPlaceholderSuffix(this.placeholderSuffix);
/* 180 */     propertyResolver.setValueSeparator(this.valueSeparator);
/* 181 */     propertyResolver.setEscapeCharacter(this.escapeCharacter);
/*     */     
/* 183 */     StringValueResolver valueResolver = strVal -> {
/*     */         String resolved = this.ignoreUnresolvablePlaceholders ? propertyResolver.resolvePlaceholders(strVal) : propertyResolver.resolveRequiredPlaceholders(strVal);
/*     */         
/*     */         if (this.trimValues) {
/*     */           resolved = resolved.trim();
/*     */         }
/*     */         
/*     */         return resolved.equals(this.nullValue) ? null : resolved;
/*     */       };
/*     */     
/* 193 */     doProcessProperties(beanFactoryToProcess, valueResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected void processProperties(ConfigurableListableBeanFactory beanFactory, Properties props) {
/* 206 */     throw new UnsupportedOperationException("Call processProperties(ConfigurableListableBeanFactory, ConfigurablePropertyResolver) instead");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertySources getAppliedPropertySources() throws IllegalStateException {
/* 218 */     Assert.state((this.appliedPropertySources != null), "PropertySources have not yet been applied");
/* 219 */     return this.appliedPropertySources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConfigurableEnvironmentPropertySource
/*     */     extends PropertySource<ConfigurableEnvironment>
/*     */   {
/*     */     ConfigurableEnvironmentPropertySource(ConfigurableEnvironment environment) {
/* 232 */       super("environmentProperties", environment);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsProperty(String name) {
/* 237 */       for (PropertySource<?> propertySource : (Iterable<PropertySource<?>>)((ConfigurableEnvironment)this.source).getPropertySources()) {
/* 238 */         if (propertySource.containsProperty(name)) {
/* 239 */           return true;
/*     */         }
/*     */       } 
/* 242 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getProperty(String name) {
/* 249 */       for (PropertySource<?> propertySource : (Iterable<PropertySource<?>>)((ConfigurableEnvironment)this.source).getPropertySources()) {
/* 250 */         Object candidate = propertySource.getProperty(name);
/* 251 */         if (candidate != null) {
/* 252 */           return convertToString(candidate);
/*     */         }
/*     */       } 
/* 255 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private String convertToString(Object value) {
/* 269 */       if (value instanceof String) { String string = (String)value;
/* 270 */         return string; }
/*     */       
/* 272 */       return (String)((ConfigurableEnvironment)this.source).getConversionService().convert(value, String.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 277 */       return "ConfigurableEnvironmentPropertySource {propertySources=" + String.valueOf(((ConfigurableEnvironment)this.source).getPropertySources()) + "}";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class FallbackEnvironmentPropertySource
/*     */     extends PropertySource<Environment>
/*     */   {
/*     */     FallbackEnvironmentPropertySource(Environment environment) {
/* 291 */       super("environmentProperties", environment);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsProperty(String name) {
/* 296 */       return ((Environment)this.source).containsProperty(name);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getProperty(String name) {
/* 303 */       return ((Environment)this.source).getProperty(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 308 */       return "FallbackEnvironmentPropertySource {environment=" + String.valueOf(this.source) + "}";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\PropertySourcesPlaceholderConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */