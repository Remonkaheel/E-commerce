/*      */ package org.springframework.context.support;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.CachedIntrospectionResults;
/*      */ import org.springframework.beans.PropertyEditorRegistrar;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryInitializer;
/*      */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*      */ import org.springframework.beans.factory.ListableBeanFactory;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.ObjectProvider;
/*      */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*      */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*      */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*      */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.beans.support.ResourceEditorRegistrar;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationContextAware;
/*      */ import org.springframework.context.ApplicationEvent;
/*      */ import org.springframework.context.ApplicationEventPublisher;
/*      */ import org.springframework.context.ApplicationEventPublisherAware;
/*      */ import org.springframework.context.ApplicationListener;
/*      */ import org.springframework.context.ApplicationStartupAware;
/*      */ import org.springframework.context.ConfigurableApplicationContext;
/*      */ import org.springframework.context.EmbeddedValueResolverAware;
/*      */ import org.springframework.context.EnvironmentAware;
/*      */ import org.springframework.context.HierarchicalMessageSource;
/*      */ import org.springframework.context.LifecycleProcessor;
/*      */ import org.springframework.context.MessageSource;
/*      */ import org.springframework.context.MessageSourceAware;
/*      */ import org.springframework.context.MessageSourceResolvable;
/*      */ import org.springframework.context.NoSuchMessageException;
/*      */ import org.springframework.context.PayloadApplicationEvent;
/*      */ import org.springframework.context.ResourceLoaderAware;
/*      */ import org.springframework.context.event.ApplicationEventMulticaster;
/*      */ import org.springframework.context.event.ContextClosedEvent;
/*      */ import org.springframework.context.event.ContextRefreshedEvent;
/*      */ import org.springframework.context.event.ContextStartedEvent;
/*      */ import org.springframework.context.event.ContextStoppedEvent;
/*      */ import org.springframework.context.event.SimpleApplicationEventMulticaster;
/*      */ import org.springframework.context.expression.StandardBeanExpressionResolver;
/*      */ import org.springframework.context.weaving.LoadTimeWeaverAware;
/*      */ import org.springframework.context.weaving.LoadTimeWeaverAwareProcessor;
/*      */ import org.springframework.core.NativeDetector;
/*      */ import org.springframework.core.ResolvableType;
/*      */ import org.springframework.core.annotation.AnnotationUtils;
/*      */ import org.springframework.core.convert.ConversionService;
/*      */ import org.springframework.core.env.ConfigurableEnvironment;
/*      */ import org.springframework.core.env.Environment;
/*      */ import org.springframework.core.env.PropertyResolver;
/*      */ import org.springframework.core.env.StandardEnvironment;
/*      */ import org.springframework.core.io.DefaultResourceLoader;
/*      */ import org.springframework.core.io.Resource;
/*      */ import org.springframework.core.io.ResourceLoader;
/*      */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*      */ import org.springframework.core.io.support.ResourcePatternResolver;
/*      */ import org.springframework.core.metrics.ApplicationStartup;
/*      */ import org.springframework.core.metrics.StartupStep;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractApplicationContext
/*      */   extends DefaultResourceLoader
/*      */   implements ConfigurableApplicationContext
/*      */ {
/*      */   public static final String MESSAGE_SOURCE_BEAN_NAME = "messageSource";
/*      */   public static final String APPLICATION_EVENT_MULTICASTER_BEAN_NAME = "applicationEventMulticaster";
/*      */   public static final String LIFECYCLE_PROCESSOR_BEAN_NAME = "lifecycleProcessor";
/*      */   
/*      */   static {
/*  178 */     ContextClosedEvent.class.getName();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  183 */   protected final Log logger = LogFactory.getLog(getClass());
/*      */ 
/*      */   
/*  186 */   private String id = ObjectUtils.identityToString(this);
/*      */ 
/*      */   
/*  189 */   private String displayName = ObjectUtils.identityToString(this);
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private ApplicationContext parent;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private ConfigurableEnvironment environment;
/*      */ 
/*      */   
/*  200 */   private final List<BeanFactoryPostProcessor> beanFactoryPostProcessors = new ArrayList<>();
/*      */ 
/*      */   
/*      */   private long startupDate;
/*      */ 
/*      */   
/*  206 */   private final AtomicBoolean active = new AtomicBoolean();
/*      */ 
/*      */   
/*  209 */   private final AtomicBoolean closed = new AtomicBoolean();
/*      */ 
/*      */   
/*  212 */   private final Lock startupShutdownLock = new ReentrantLock();
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private volatile Thread startupShutdownThread;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Thread shutdownHook;
/*      */ 
/*      */   
/*      */   private final ResourcePatternResolver resourcePatternResolver;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private LifecycleProcessor lifecycleProcessor;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private MessageSource messageSource;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private ApplicationEventMulticaster applicationEventMulticaster;
/*      */ 
/*      */   
/*  238 */   private ApplicationStartup applicationStartup = ApplicationStartup.DEFAULT;
/*      */ 
/*      */   
/*  241 */   private final Set<ApplicationListener<?>> applicationListeners = new LinkedHashSet<>();
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Set<ApplicationListener<?>> earlyApplicationListeners;
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Set<ApplicationEvent> earlyApplicationEvents;
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractApplicationContext() {
/*  256 */     this.resourcePatternResolver = getResourcePatternResolver();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractApplicationContext(@Nullable ApplicationContext parent) {
/*  264 */     this();
/*  265 */     setParent(parent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setId(String id) {
/*  281 */     this.id = id;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getId() {
/*  286 */     return this.id;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getApplicationName() {
/*  291 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplayName(String displayName) {
/*  300 */     Assert.hasLength(displayName, "Display name must not be empty");
/*  301 */     this.displayName = displayName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDisplayName() {
/*  310 */     return this.displayName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public ApplicationContext getParent() {
/*  320 */     return this.parent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnvironment(ConfigurableEnvironment environment) {
/*  333 */     this.environment = environment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConfigurableEnvironment getEnvironment() {
/*  344 */     if (this.environment == null) {
/*  345 */       this.environment = createEnvironment();
/*      */     }
/*  347 */     return this.environment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ConfigurableEnvironment createEnvironment() {
/*  356 */     return (ConfigurableEnvironment)new StandardEnvironment();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AutowireCapableBeanFactory getAutowireCapableBeanFactory() throws IllegalStateException {
/*  366 */     return (AutowireCapableBeanFactory)getBeanFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getStartupDate() {
/*  374 */     return this.startupDate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void publishEvent(ApplicationEvent event) {
/*  387 */     publishEvent(event, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void publishEvent(Object event) {
/*  400 */     publishEvent(event, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void publishEvent(Object event, @Nullable ResolvableType typeHint) {
/*      */     PayloadApplicationEvent payloadApplicationEvent;
/*  421 */     Assert.notNull(event, "Event must not be null");
/*  422 */     ResolvableType eventType = null;
/*      */ 
/*      */ 
/*      */     
/*  426 */     if (event instanceof ApplicationEvent) { ApplicationEvent applEvent = (ApplicationEvent)event;
/*  427 */       ApplicationEvent applicationEvent = applEvent;
/*  428 */       eventType = typeHint; }
/*      */     else
/*      */     
/*  431 */     { ResolvableType payloadType = null;
/*  432 */       if (typeHint != null && ApplicationEvent.class.isAssignableFrom(typeHint.toClass())) {
/*  433 */         eventType = typeHint;
/*      */       } else {
/*      */         
/*  436 */         payloadType = typeHint;
/*      */       } 
/*  438 */       payloadApplicationEvent = new PayloadApplicationEvent(this, event, payloadType); }
/*      */ 
/*      */ 
/*      */     
/*  442 */     if (eventType == null) {
/*  443 */       eventType = ResolvableType.forInstance(payloadApplicationEvent);
/*  444 */       if (typeHint == null) {
/*  445 */         typeHint = eventType;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  450 */     if (this.earlyApplicationEvents != null) {
/*  451 */       this.earlyApplicationEvents.add(payloadApplicationEvent);
/*      */     }
/*  453 */     else if (this.applicationEventMulticaster != null) {
/*  454 */       this.applicationEventMulticaster.multicastEvent((ApplicationEvent)payloadApplicationEvent, eventType);
/*      */     } 
/*      */ 
/*      */     
/*  458 */     if (this.parent != null) {
/*  459 */       ApplicationContext applicationContext = this.parent; if (applicationContext instanceof AbstractApplicationContext) { AbstractApplicationContext abstractApplicationContext = (AbstractApplicationContext)applicationContext;
/*  460 */         abstractApplicationContext.publishEvent(event, typeHint); }
/*      */       else
/*      */       
/*  463 */       { this.parent.publishEvent(event); }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ApplicationEventMulticaster getApplicationEventMulticaster() throws IllegalStateException {
/*  474 */     if (this.applicationEventMulticaster == null) {
/*  475 */       throw new IllegalStateException("ApplicationEventMulticaster not initialized - call 'refresh' before multicasting events via the context: " + String.valueOf(this));
/*      */     }
/*      */     
/*  478 */     return this.applicationEventMulticaster;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setApplicationStartup(ApplicationStartup applicationStartup) {
/*  483 */     Assert.notNull(applicationStartup, "ApplicationStartup must not be null");
/*  484 */     this.applicationStartup = applicationStartup;
/*      */   }
/*      */ 
/*      */   
/*      */   public ApplicationStartup getApplicationStartup() {
/*  489 */     return this.applicationStartup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   LifecycleProcessor getLifecycleProcessor() throws IllegalStateException {
/*  498 */     if (this.lifecycleProcessor == null) {
/*  499 */       throw new IllegalStateException("LifecycleProcessor not initialized - call 'refresh' before invoking lifecycle methods via the context: " + String.valueOf(this));
/*      */     }
/*      */     
/*  502 */     return this.lifecycleProcessor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ResourcePatternResolver getResourcePatternResolver() {
/*  520 */     return (ResourcePatternResolver)new PathMatchingResourcePatternResolver((ResourceLoader)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParent(@Nullable ApplicationContext parent) {
/*  538 */     this.parent = parent;
/*  539 */     if (parent != null) {
/*  540 */       Environment parentEnvironment = parent.getEnvironment();
/*  541 */       if (parentEnvironment instanceof ConfigurableEnvironment) { ConfigurableEnvironment configurableEnvironment = (ConfigurableEnvironment)parentEnvironment;
/*  542 */         getEnvironment().merge(configurableEnvironment); }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addBeanFactoryPostProcessor(BeanFactoryPostProcessor postProcessor) {
/*  549 */     Assert.notNull(postProcessor, "BeanFactoryPostProcessor must not be null");
/*  550 */     this.beanFactoryPostProcessors.add(postProcessor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<BeanFactoryPostProcessor> getBeanFactoryPostProcessors() {
/*  558 */     return this.beanFactoryPostProcessors;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addApplicationListener(ApplicationListener<?> listener) {
/*  563 */     Assert.notNull(listener, "ApplicationListener must not be null");
/*  564 */     if (this.applicationEventMulticaster != null) {
/*  565 */       this.applicationEventMulticaster.addApplicationListener(listener);
/*      */     }
/*  567 */     this.applicationListeners.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeApplicationListener(ApplicationListener<?> listener) {
/*  572 */     Assert.notNull(listener, "ApplicationListener must not be null");
/*  573 */     if (this.applicationEventMulticaster != null) {
/*  574 */       this.applicationEventMulticaster.removeApplicationListener(listener);
/*      */     }
/*  576 */     this.applicationListeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<ApplicationListener<?>> getApplicationListeners() {
/*  583 */     return this.applicationListeners;
/*      */   }
/*      */ 
/*      */   
/*      */   public void refresh() throws BeansException, IllegalStateException {
/*  588 */     this.startupShutdownLock.lock();
/*      */     try {
/*  590 */       this.startupShutdownThread = Thread.currentThread();
/*      */       
/*  592 */       StartupStep contextRefresh = this.applicationStartup.start("spring.context.refresh");
/*      */ 
/*      */       
/*  595 */       prepareRefresh();
/*      */ 
/*      */       
/*  598 */       ConfigurableListableBeanFactory beanFactory = obtainFreshBeanFactory();
/*      */ 
/*      */       
/*  601 */       prepareBeanFactory(beanFactory);
/*      */ 
/*      */       
/*      */       try {
/*  605 */         postProcessBeanFactory(beanFactory);
/*      */         
/*  607 */         StartupStep beanPostProcess = this.applicationStartup.start("spring.context.beans.post-process");
/*      */         
/*  609 */         invokeBeanFactoryPostProcessors(beanFactory);
/*      */         
/*  611 */         registerBeanPostProcessors(beanFactory);
/*  612 */         beanPostProcess.end();
/*      */ 
/*      */         
/*  615 */         initMessageSource();
/*      */ 
/*      */         
/*  618 */         initApplicationEventMulticaster();
/*      */ 
/*      */         
/*  621 */         onRefresh();
/*      */ 
/*      */         
/*  624 */         registerListeners();
/*      */ 
/*      */         
/*  627 */         finishBeanFactoryInitialization(beanFactory);
/*      */ 
/*      */         
/*  630 */         finishRefresh();
/*      */       
/*      */       }
/*  633 */       catch (RuntimeException|Error ex) {
/*  634 */         if (this.logger.isWarnEnabled()) {
/*  635 */           this.logger.warn("Exception encountered during context initialization - cancelling refresh attempt: " + String.valueOf(ex));
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  640 */         destroyBeans();
/*      */ 
/*      */         
/*  643 */         cancelRefresh(ex);
/*      */ 
/*      */         
/*  646 */         throw ex;
/*      */       }
/*      */       finally {
/*      */         
/*  650 */         contextRefresh.end();
/*      */       } 
/*      */     } finally {
/*      */       
/*  654 */       this.startupShutdownThread = null;
/*  655 */       this.startupShutdownLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void prepareRefresh() {
/*  665 */     this.startupDate = System.currentTimeMillis();
/*  666 */     this.closed.set(false);
/*  667 */     this.active.set(true);
/*      */     
/*  669 */     if (this.logger.isDebugEnabled()) {
/*  670 */       if (this.logger.isTraceEnabled()) {
/*  671 */         this.logger.trace("Refreshing " + String.valueOf(this));
/*      */       } else {
/*      */         
/*  674 */         this.logger.debug("Refreshing " + getDisplayName());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  679 */     initPropertySources();
/*      */ 
/*      */ 
/*      */     
/*  683 */     getEnvironment().validateRequiredProperties();
/*      */ 
/*      */     
/*  686 */     if (this.earlyApplicationListeners == null) {
/*  687 */       this.earlyApplicationListeners = new LinkedHashSet<>(this.applicationListeners);
/*      */     }
/*      */     else {
/*      */       
/*  691 */       this.applicationListeners.clear();
/*  692 */       this.applicationListeners.addAll(this.earlyApplicationListeners);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  697 */     this.earlyApplicationEvents = new LinkedHashSet<>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initPropertySources() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ConfigurableListableBeanFactory obtainFreshBeanFactory() {
/*  716 */     refreshBeanFactory();
/*  717 */     return getBeanFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void prepareBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/*  727 */     beanFactory.setBeanClassLoader(getClassLoader());
/*  728 */     beanFactory.setBeanExpressionResolver((BeanExpressionResolver)new StandardBeanExpressionResolver(beanFactory.getBeanClassLoader()));
/*  729 */     beanFactory.addPropertyEditorRegistrar((PropertyEditorRegistrar)new ResourceEditorRegistrar((ResourceLoader)this, (PropertyResolver)getEnvironment()));
/*      */ 
/*      */     
/*  732 */     beanFactory.addBeanPostProcessor(new ApplicationContextAwareProcessor(this));
/*  733 */     beanFactory.ignoreDependencyInterface(EnvironmentAware.class);
/*  734 */     beanFactory.ignoreDependencyInterface(EmbeddedValueResolverAware.class);
/*  735 */     beanFactory.ignoreDependencyInterface(ResourceLoaderAware.class);
/*  736 */     beanFactory.ignoreDependencyInterface(ApplicationEventPublisherAware.class);
/*  737 */     beanFactory.ignoreDependencyInterface(MessageSourceAware.class);
/*  738 */     beanFactory.ignoreDependencyInterface(ApplicationContextAware.class);
/*  739 */     beanFactory.ignoreDependencyInterface(ApplicationStartupAware.class);
/*      */ 
/*      */ 
/*      */     
/*  743 */     beanFactory.registerResolvableDependency(BeanFactory.class, beanFactory);
/*  744 */     beanFactory.registerResolvableDependency(ResourceLoader.class, this);
/*  745 */     beanFactory.registerResolvableDependency(ApplicationEventPublisher.class, this);
/*  746 */     beanFactory.registerResolvableDependency(ApplicationContext.class, this);
/*      */ 
/*      */     
/*  749 */     beanFactory.addBeanPostProcessor((BeanPostProcessor)new ApplicationListenerDetector(this));
/*      */ 
/*      */     
/*  752 */     if (!NativeDetector.inNativeImage() && beanFactory.containsBean("loadTimeWeaver")) {
/*  753 */       beanFactory.addBeanPostProcessor((BeanPostProcessor)new LoadTimeWeaverAwareProcessor((BeanFactory)beanFactory));
/*      */       
/*  755 */       beanFactory.setTempClassLoader((ClassLoader)new ContextTypeMatchClassLoader(beanFactory.getBeanClassLoader()));
/*      */     } 
/*      */ 
/*      */     
/*  759 */     if (!beanFactory.containsLocalBean("environment")) {
/*  760 */       beanFactory.registerSingleton("environment", getEnvironment());
/*      */     }
/*  762 */     if (!beanFactory.containsLocalBean("systemProperties")) {
/*  763 */       beanFactory.registerSingleton("systemProperties", getEnvironment().getSystemProperties());
/*      */     }
/*  765 */     if (!beanFactory.containsLocalBean("systemEnvironment")) {
/*  766 */       beanFactory.registerSingleton("systemEnvironment", getEnvironment().getSystemEnvironment());
/*      */     }
/*  768 */     if (!beanFactory.containsLocalBean("applicationStartup")) {
/*  769 */       beanFactory.registerSingleton("applicationStartup", getApplicationStartup());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void invokeBeanFactoryPostProcessors(ConfigurableListableBeanFactory beanFactory) {
/*  791 */     PostProcessorRegistrationDelegate.invokeBeanFactoryPostProcessors(beanFactory, getBeanFactoryPostProcessors());
/*      */ 
/*      */ 
/*      */     
/*  795 */     if (!NativeDetector.inNativeImage() && beanFactory.getTempClassLoader() == null && beanFactory
/*  796 */       .containsBean("loadTimeWeaver")) {
/*  797 */       beanFactory.addBeanPostProcessor((BeanPostProcessor)new LoadTimeWeaverAwareProcessor((BeanFactory)beanFactory));
/*  798 */       beanFactory.setTempClassLoader((ClassLoader)new ContextTypeMatchClassLoader(beanFactory.getBeanClassLoader()));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void registerBeanPostProcessors(ConfigurableListableBeanFactory beanFactory) {
/*  808 */     PostProcessorRegistrationDelegate.registerBeanPostProcessors(beanFactory, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initMessageSource() {
/*  817 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  818 */     if (beanFactory.containsLocalBean("messageSource")) {
/*  819 */       this.messageSource = (MessageSource)beanFactory.getBean("messageSource", MessageSource.class);
/*      */       
/*  821 */       if (this.parent != null) { MessageSource messageSource = this.messageSource; if (messageSource instanceof HierarchicalMessageSource) { HierarchicalMessageSource hms = (HierarchicalMessageSource)messageSource; if (hms
/*  822 */             .getParentMessageSource() == null)
/*      */           {
/*      */             
/*  825 */             hms.setParentMessageSource(getInternalParentMessageSource()); }  }
/*      */          }
/*  827 */        if (this.logger.isTraceEnabled()) {
/*  828 */         this.logger.trace("Using MessageSource [" + String.valueOf(this.messageSource) + "]");
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  833 */       DelegatingMessageSource dms = new DelegatingMessageSource();
/*  834 */       dms.setParentMessageSource(getInternalParentMessageSource());
/*  835 */       this.messageSource = (MessageSource)dms;
/*  836 */       beanFactory.registerSingleton("messageSource", this.messageSource);
/*  837 */       if (this.logger.isTraceEnabled()) {
/*  838 */         this.logger.trace("No 'messageSource' bean, using [" + String.valueOf(this.messageSource) + "]");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initApplicationEventMulticaster() {
/*  850 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  851 */     if (beanFactory.containsLocalBean("applicationEventMulticaster")) {
/*  852 */       this
/*  853 */         .applicationEventMulticaster = (ApplicationEventMulticaster)beanFactory.getBean("applicationEventMulticaster", ApplicationEventMulticaster.class);
/*  854 */       if (this.logger.isTraceEnabled()) {
/*  855 */         this.logger.trace("Using ApplicationEventMulticaster [" + String.valueOf(this.applicationEventMulticaster) + "]");
/*      */       }
/*      */     } else {
/*      */       
/*  859 */       this.applicationEventMulticaster = (ApplicationEventMulticaster)new SimpleApplicationEventMulticaster((BeanFactory)beanFactory);
/*  860 */       beanFactory.registerSingleton("applicationEventMulticaster", this.applicationEventMulticaster);
/*  861 */       if (this.logger.isTraceEnabled()) {
/*  862 */         this.logger.trace("No 'applicationEventMulticaster' bean, using [" + this.applicationEventMulticaster
/*  863 */             .getClass().getSimpleName() + "]");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initLifecycleProcessor() {
/*  876 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  877 */     if (beanFactory.containsLocalBean("lifecycleProcessor")) {
/*  878 */       this.lifecycleProcessor = (LifecycleProcessor)beanFactory.getBean("lifecycleProcessor", LifecycleProcessor.class);
/*  879 */       if (this.logger.isTraceEnabled()) {
/*  880 */         this.logger.trace("Using LifecycleProcessor [" + String.valueOf(this.lifecycleProcessor) + "]");
/*      */       }
/*      */     } else {
/*      */       
/*  884 */       DefaultLifecycleProcessor defaultProcessor = new DefaultLifecycleProcessor();
/*  885 */       defaultProcessor.setBeanFactory((BeanFactory)beanFactory);
/*  886 */       this.lifecycleProcessor = defaultProcessor;
/*  887 */       beanFactory.registerSingleton("lifecycleProcessor", this.lifecycleProcessor);
/*  888 */       if (this.logger.isTraceEnabled()) {
/*  889 */         this.logger.trace("No 'lifecycleProcessor' bean, using [" + this.lifecycleProcessor
/*  890 */             .getClass().getSimpleName() + "]");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void onRefresh() throws BeansException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void registerListeners() {
/*  912 */     for (ApplicationListener<?> listener : getApplicationListeners()) {
/*  913 */       getApplicationEventMulticaster().addApplicationListener(listener);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  918 */     String[] listenerBeanNames = getBeanNamesForType(ApplicationListener.class, true, false);
/*  919 */     for (String listenerBeanName : listenerBeanNames) {
/*  920 */       getApplicationEventMulticaster().addApplicationListenerBean(listenerBeanName);
/*      */     }
/*      */ 
/*      */     
/*  924 */     Set<ApplicationEvent> earlyEventsToProcess = this.earlyApplicationEvents;
/*  925 */     this.earlyApplicationEvents = null;
/*  926 */     if (!CollectionUtils.isEmpty(earlyEventsToProcess)) {
/*  927 */       for (ApplicationEvent earlyEvent : earlyEventsToProcess) {
/*  928 */         getApplicationEventMulticaster().multicastEvent(earlyEvent);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void finishBeanFactoryInitialization(ConfigurableListableBeanFactory beanFactory) {
/*  940 */     beanFactory.prepareSingletonBootstrap();
/*      */ 
/*      */     
/*  943 */     if (beanFactory.containsBean("bootstrapExecutor") && beanFactory
/*  944 */       .isTypeMatch("bootstrapExecutor", Executor.class)) {
/*  945 */       beanFactory.setBootstrapExecutor((Executor)beanFactory
/*  946 */           .getBean("bootstrapExecutor", Executor.class));
/*      */     }
/*      */ 
/*      */     
/*  950 */     if (beanFactory.containsBean("conversionService") && beanFactory
/*  951 */       .isTypeMatch("conversionService", ConversionService.class)) {
/*  952 */       beanFactory.setConversionService((ConversionService)beanFactory
/*  953 */           .getBean("conversionService", ConversionService.class));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  959 */     if (!beanFactory.hasEmbeddedValueResolver()) {
/*  960 */       beanFactory.addEmbeddedValueResolver(strVal -> getEnvironment().resolvePlaceholders(strVal));
/*      */     }
/*      */ 
/*      */     
/*  964 */     String[] initializerNames = beanFactory.getBeanNamesForType(BeanFactoryInitializer.class, false, false);
/*  965 */     for (String initializerName : initializerNames) {
/*  966 */       ((BeanFactoryInitializer)beanFactory.getBean(initializerName, BeanFactoryInitializer.class)).initialize((ListableBeanFactory)beanFactory);
/*      */     }
/*      */ 
/*      */     
/*  970 */     String[] weaverAwareNames = beanFactory.getBeanNamesForType(LoadTimeWeaverAware.class, false, false);
/*  971 */     for (String weaverAwareName : weaverAwareNames) {
/*      */       try {
/*  973 */         beanFactory.getBean(weaverAwareName, LoadTimeWeaverAware.class);
/*      */       }
/*  975 */       catch (BeanNotOfRequiredTypeException ex) {
/*  976 */         if (this.logger.isDebugEnabled()) {
/*  977 */           this.logger.debug("Failed to initialize LoadTimeWeaverAware bean '" + weaverAwareName + "' due to unexpected type mismatch: " + ex
/*  978 */               .getMessage());
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  984 */     beanFactory.setTempClassLoader(null);
/*      */ 
/*      */     
/*  987 */     beanFactory.freezeConfiguration();
/*      */ 
/*      */     
/*  990 */     beanFactory.preInstantiateSingletons();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void finishRefresh() {
/* 1000 */     resetCommonCaches();
/*      */ 
/*      */     
/* 1003 */     clearResourceCaches();
/*      */ 
/*      */     
/* 1006 */     initLifecycleProcessor();
/*      */ 
/*      */     
/* 1009 */     getLifecycleProcessor().onRefresh();
/*      */ 
/*      */     
/* 1012 */     publishEvent((ApplicationEvent)new ContextRefreshedEvent((ApplicationContext)this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cancelRefresh(Throwable ex) {
/* 1021 */     this.active.set(false);
/*      */ 
/*      */     
/* 1024 */     resetCommonCaches();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void resetCommonCaches() {
/* 1038 */     ReflectionUtils.clearCache();
/* 1039 */     AnnotationUtils.clearCache();
/* 1040 */     ResolvableType.clearCache();
/* 1041 */     CachedIntrospectionResults.clearClassLoader(getClassLoader());
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearResourceCaches() {
/* 1046 */     super.clearResourceCaches();
/* 1047 */     ResourcePatternResolver resourcePatternResolver = this.resourcePatternResolver; if (resourcePatternResolver instanceof PathMatchingResourcePatternResolver) { PathMatchingResourcePatternResolver pmrpr = (PathMatchingResourcePatternResolver)resourcePatternResolver;
/* 1048 */       pmrpr.clearCache(); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerShutdownHook() {
/* 1065 */     if (this.shutdownHook == null) {
/*      */       
/* 1067 */       this.shutdownHook = new Thread("SpringContextShutdownHook")
/*      */         {
/*      */           public void run() {
/* 1070 */             if (AbstractApplicationContext.this.isStartupShutdownThreadStuck()) {
/* 1071 */               AbstractApplicationContext.this.active.set(false);
/*      */               return;
/*      */             } 
/* 1074 */             AbstractApplicationContext.this.startupShutdownLock.lock();
/*      */             try {
/* 1076 */               AbstractApplicationContext.this.doClose();
/*      */             } finally {
/*      */               
/* 1079 */               AbstractApplicationContext.this.startupShutdownLock.unlock();
/*      */             } 
/*      */           }
/*      */         };
/* 1083 */       Runtime.getRuntime().addShutdownHook(this.shutdownHook);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isStartupShutdownThreadStuck() {
/* 1092 */     Thread activeThread = this.startupShutdownThread;
/* 1093 */     if (activeThread != null && activeThread.getState() == Thread.State.WAITING) {
/*      */       
/* 1095 */       activeThread.interrupt();
/*      */       
/*      */       try {
/* 1098 */         Thread.sleep(1L);
/*      */       }
/* 1100 */       catch (InterruptedException ex) {
/* 1101 */         Thread.currentThread().interrupt();
/*      */       } 
/* 1103 */       if (activeThread.getState() == Thread.State.WAITING)
/*      */       {
/* 1105 */         return true;
/*      */       }
/*      */     } 
/* 1108 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() {
/* 1120 */     if (isStartupShutdownThreadStuck()) {
/* 1121 */       this.active.set(false);
/*      */       
/*      */       return;
/*      */     } 
/* 1125 */     this.startupShutdownLock.lock();
/*      */     try {
/* 1127 */       this.startupShutdownThread = Thread.currentThread();
/*      */       
/* 1129 */       doClose();
/*      */ 
/*      */ 
/*      */       
/* 1133 */       if (this.shutdownHook != null) {
/*      */         try {
/* 1135 */           Runtime.getRuntime().removeShutdownHook(this.shutdownHook);
/*      */         }
/* 1137 */         catch (IllegalStateException illegalStateException) {}
/*      */       
/*      */       }
/*      */     }
/*      */     finally {
/*      */       
/* 1143 */       this.startupShutdownThread = null;
/* 1144 */       this.startupShutdownLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doClose() {
/* 1159 */     if (this.active.get() && this.closed.compareAndSet(false, true)) {
/* 1160 */       if (this.logger.isDebugEnabled()) {
/* 1161 */         this.logger.debug("Closing " + String.valueOf(this));
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/* 1166 */         publishEvent((ApplicationEvent)new ContextClosedEvent((ApplicationContext)this));
/*      */       }
/* 1168 */       catch (Throwable ex) {
/* 1169 */         this.logger.warn("Exception thrown from ApplicationListener handling ContextClosedEvent", ex);
/*      */       } 
/*      */ 
/*      */       
/* 1173 */       if (this.lifecycleProcessor != null) {
/*      */         try {
/* 1175 */           this.lifecycleProcessor.onClose();
/*      */         }
/* 1177 */         catch (Throwable ex) {
/* 1178 */           this.logger.warn("Exception thrown from LifecycleProcessor on context close", ex);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 1183 */       destroyBeans();
/*      */ 
/*      */       
/* 1186 */       closeBeanFactory();
/*      */ 
/*      */       
/* 1189 */       onClose();
/*      */ 
/*      */       
/* 1192 */       resetCommonCaches();
/*      */ 
/*      */       
/* 1195 */       if (this.earlyApplicationListeners != null) {
/* 1196 */         this.applicationListeners.clear();
/* 1197 */         this.applicationListeners.addAll(this.earlyApplicationListeners);
/*      */       } 
/*      */ 
/*      */       
/* 1201 */       this.applicationEventMulticaster = null;
/* 1202 */       this.messageSource = null;
/* 1203 */       this.lifecycleProcessor = null;
/*      */ 
/*      */       
/* 1206 */       this.active.set(false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void destroyBeans() {
/* 1222 */     getBeanFactory().destroySingletons();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void onClose() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isClosed() {
/* 1239 */     return this.closed.get();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isActive() {
/* 1244 */     return this.active.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void assertBeanFactoryActive() {
/* 1257 */     if (!this.active.get()) {
/* 1258 */       if (this.closed.get()) {
/* 1259 */         throw new IllegalStateException(getDisplayName() + " has been closed already");
/*      */       }
/*      */       
/* 1262 */       throw new IllegalStateException(getDisplayName() + " has not been refreshed yet");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getBean(String name) throws BeansException {
/* 1274 */     assertBeanFactoryActive();
/* 1275 */     return getBeanFactory().getBean(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getBean(String name, Class<T> requiredType) throws BeansException {
/* 1280 */     assertBeanFactoryActive();
/* 1281 */     return (T)getBeanFactory().getBean(name, requiredType);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getBean(String name, Object... args) throws BeansException {
/* 1286 */     assertBeanFactoryActive();
/* 1287 */     return getBeanFactory().getBean(name, args);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getBean(Class<T> requiredType) throws BeansException {
/* 1292 */     assertBeanFactoryActive();
/* 1293 */     return (T)getBeanFactory().getBean(requiredType);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getBean(Class<T> requiredType, Object... args) throws BeansException {
/* 1298 */     assertBeanFactoryActive();
/* 1299 */     return (T)getBeanFactory().getBean(requiredType, args);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> ObjectProvider<T> getBeanProvider(Class<T> requiredType) {
/* 1304 */     assertBeanFactoryActive();
/* 1305 */     return getBeanFactory().getBeanProvider(requiredType);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> ObjectProvider<T> getBeanProvider(ResolvableType requiredType) {
/* 1310 */     assertBeanFactoryActive();
/* 1311 */     return getBeanFactory().getBeanProvider(requiredType);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsBean(String name) {
/* 1316 */     return getBeanFactory().containsBean(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSingleton(String name) throws NoSuchBeanDefinitionException {
/* 1321 */     assertBeanFactoryActive();
/* 1322 */     return getBeanFactory().isSingleton(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPrototype(String name) throws NoSuchBeanDefinitionException {
/* 1327 */     assertBeanFactoryActive();
/* 1328 */     return getBeanFactory().isPrototype(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTypeMatch(String name, ResolvableType typeToMatch) throws NoSuchBeanDefinitionException {
/* 1333 */     assertBeanFactoryActive();
/* 1334 */     return getBeanFactory().isTypeMatch(name, typeToMatch);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTypeMatch(String name, Class<?> typeToMatch) throws NoSuchBeanDefinitionException {
/* 1339 */     assertBeanFactoryActive();
/* 1340 */     return getBeanFactory().isTypeMatch(name, typeToMatch);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Class<?> getType(String name) throws NoSuchBeanDefinitionException {
/* 1346 */     assertBeanFactoryActive();
/* 1347 */     return getBeanFactory().getType(name);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Class<?> getType(String name, boolean allowFactoryBeanInit) throws NoSuchBeanDefinitionException {
/* 1353 */     assertBeanFactoryActive();
/* 1354 */     return getBeanFactory().getType(name, allowFactoryBeanInit);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getAliases(String name) {
/* 1359 */     return getBeanFactory().getAliases(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsBeanDefinition(String beanName) {
/* 1369 */     return getBeanFactory().containsBeanDefinition(beanName);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getBeanDefinitionCount() {
/* 1374 */     return getBeanFactory().getBeanDefinitionCount();
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getBeanDefinitionNames() {
/* 1379 */     return getBeanFactory().getBeanDefinitionNames();
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> ObjectProvider<T> getBeanProvider(Class<T> requiredType, boolean allowEagerInit) {
/* 1384 */     assertBeanFactoryActive();
/* 1385 */     return getBeanFactory().getBeanProvider(requiredType, allowEagerInit);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> ObjectProvider<T> getBeanProvider(ResolvableType requiredType, boolean allowEagerInit) {
/* 1390 */     assertBeanFactoryActive();
/* 1391 */     return getBeanFactory().getBeanProvider(requiredType, allowEagerInit);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getBeanNamesForType(ResolvableType type) {
/* 1396 */     assertBeanFactoryActive();
/* 1397 */     return getBeanFactory().getBeanNamesForType(type);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getBeanNamesForType(ResolvableType type, boolean includeNonSingletons, boolean allowEagerInit) {
/* 1402 */     assertBeanFactoryActive();
/* 1403 */     return getBeanFactory().getBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getBeanNamesForType(@Nullable Class<?> type) {
/* 1408 */     assertBeanFactoryActive();
/* 1409 */     return getBeanFactory().getBeanNamesForType(type);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getBeanNamesForType(@Nullable Class<?> type, boolean includeNonSingletons, boolean allowEagerInit) {
/* 1414 */     assertBeanFactoryActive();
/* 1415 */     return getBeanFactory().getBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Map<String, T> getBeansOfType(@Nullable Class<T> type) throws BeansException {
/* 1420 */     assertBeanFactoryActive();
/* 1421 */     return getBeanFactory().getBeansOfType(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Map<String, T> getBeansOfType(@Nullable Class<T> type, boolean includeNonSingletons, boolean allowEagerInit) throws BeansException {
/* 1428 */     assertBeanFactoryActive();
/* 1429 */     return getBeanFactory().getBeansOfType(type, includeNonSingletons, allowEagerInit);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getBeanNamesForAnnotation(Class<? extends Annotation> annotationType) {
/* 1434 */     assertBeanFactoryActive();
/* 1435 */     return getBeanFactory().getBeanNamesForAnnotation(annotationType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> getBeansWithAnnotation(Class<? extends Annotation> annotationType) throws BeansException {
/* 1442 */     assertBeanFactoryActive();
/* 1443 */     return getBeanFactory().getBeansWithAnnotation(annotationType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <A extends Annotation> A findAnnotationOnBean(String beanName, Class<A> annotationType) throws NoSuchBeanDefinitionException {
/* 1451 */     assertBeanFactoryActive();
/* 1452 */     return (A)getBeanFactory().findAnnotationOnBean(beanName, annotationType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <A extends Annotation> A findAnnotationOnBean(String beanName, Class<A> annotationType, boolean allowFactoryBeanInit) throws NoSuchBeanDefinitionException {
/* 1461 */     assertBeanFactoryActive();
/* 1462 */     return (A)getBeanFactory().findAnnotationOnBean(beanName, annotationType, allowFactoryBeanInit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <A extends Annotation> Set<A> findAllAnnotationsOnBean(String beanName, Class<A> annotationType, boolean allowFactoryBeanInit) throws NoSuchBeanDefinitionException {
/* 1470 */     assertBeanFactoryActive();
/* 1471 */     return getBeanFactory().findAllAnnotationsOnBean(beanName, annotationType, allowFactoryBeanInit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public BeanFactory getParentBeanFactory() {
/* 1482 */     return (BeanFactory)getParent();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsLocalBean(String name) {
/* 1487 */     return getBeanFactory().containsLocalBean(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected BeanFactory getInternalParentBeanFactory() {
/* 1497 */     ApplicationContext applicationContext = getParent(); ConfigurableApplicationContext cac = (ConfigurableApplicationContext)applicationContext; return (applicationContext instanceof ConfigurableApplicationContext) ? 
/* 1498 */       (BeanFactory)cac.getBeanFactory() : (BeanFactory)getParent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getMessage(String code, @Nullable Object[] args, @Nullable String defaultMessage, @Nullable Locale locale) {
/* 1509 */     return getMessageSource().getMessage(code, args, defaultMessage, locale);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getMessage(String code, @Nullable Object[] args, @Nullable Locale locale) throws NoSuchMessageException {
/* 1514 */     return getMessageSource().getMessage(code, args, locale);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getMessage(MessageSourceResolvable resolvable, @Nullable Locale locale) throws NoSuchMessageException {
/* 1519 */     return getMessageSource().getMessage(resolvable, locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MessageSource getMessageSource() throws IllegalStateException {
/* 1528 */     if (this.messageSource == null) {
/* 1529 */       throw new IllegalStateException("MessageSource not initialized - call 'refresh' before accessing messages via the context: " + String.valueOf(this));
/*      */     }
/*      */     
/* 1532 */     return this.messageSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected MessageSource getInternalParentMessageSource() {
/* 1541 */     ApplicationContext applicationContext = getParent(); AbstractApplicationContext abstractApplicationContext = (AbstractApplicationContext)applicationContext; return (applicationContext instanceof AbstractApplicationContext) ? 
/* 1542 */       abstractApplicationContext.messageSource : (MessageSource)getParent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Resource[] getResources(String locationPattern) throws IOException {
/* 1552 */     return this.resourcePatternResolver.getResources(locationPattern);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void start() {
/* 1562 */     getLifecycleProcessor().start();
/* 1563 */     publishEvent((ApplicationEvent)new ContextStartedEvent((ApplicationContext)this));
/*      */   }
/*      */ 
/*      */   
/*      */   public void stop() {
/* 1568 */     getLifecycleProcessor().stop();
/* 1569 */     publishEvent((ApplicationEvent)new ContextStoppedEvent((ApplicationContext)this));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRunning() {
/* 1574 */     return (this.lifecycleProcessor != null && this.lifecycleProcessor.isRunning());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1623 */     StringBuilder sb = new StringBuilder(getDisplayName());
/* 1624 */     sb.append(", started on ").append(new Date(getStartupDate()));
/* 1625 */     ApplicationContext parent = getParent();
/* 1626 */     if (parent != null) {
/* 1627 */       sb.append(", parent: ").append(parent.getDisplayName());
/*      */     }
/* 1629 */     return sb.toString();
/*      */   }
/*      */   
/*      */   protected abstract void refreshBeanFactory() throws BeansException, IllegalStateException;
/*      */   
/*      */   protected abstract void closeBeanFactory();
/*      */   
/*      */   public abstract ConfigurableListableBeanFactory getBeanFactory() throws IllegalStateException;
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\AbstractApplicationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */