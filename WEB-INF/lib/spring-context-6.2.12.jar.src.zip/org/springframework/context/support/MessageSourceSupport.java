/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MessageSourceSupport
/*     */ {
/*  44 */   private static final MessageFormat INVALID_MESSAGE_FORMAT = new MessageFormat("");
/*     */ 
/*     */   
/*  47 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean alwaysUseMessageFormat = false;
/*     */ 
/*     */ 
/*     */   
/*  56 */   private final Map<String, Map<Locale, MessageFormat>> messageFormatsPerMessage = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlwaysUseMessageFormat(boolean alwaysUseMessageFormat) {
/*  75 */     this.alwaysUseMessageFormat = alwaysUseMessageFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAlwaysUseMessageFormat() {
/*  83 */     return this.alwaysUseMessageFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String renderDefaultMessage(String defaultMessage, @Nullable Object[] args, @Nullable Locale locale) {
/* 102 */     return formatMessage(defaultMessage, args, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String formatMessage(String msg, @Nullable Object[] args, @Nullable Locale locale) {
/* 116 */     if (!isAlwaysUseMessageFormat() && ObjectUtils.isEmpty(args)) {
/* 117 */       return msg;
/*     */     }
/*     */     
/* 120 */     Map<Locale, MessageFormat> messageFormatsPerLocale = this.messageFormatsPerMessage.computeIfAbsent(msg, key -> new ConcurrentHashMap<>());
/* 121 */     MessageFormat messageFormat = messageFormatsPerLocale.computeIfAbsent(locale, key -> {
/*     */           
/*     */           try {
/*     */             return createMessageFormat(msg, locale);
/* 125 */           } catch (IllegalArgumentException ex) {
/*     */             if (isAlwaysUseMessageFormat()) {
/*     */               throw ex;
/*     */             }
/*     */ 
/*     */             
/*     */             return INVALID_MESSAGE_FORMAT;
/*     */           } 
/*     */         });
/*     */     
/* 135 */     if (messageFormat == INVALID_MESSAGE_FORMAT) {
/* 136 */       return msg;
/*     */     }
/* 138 */     synchronized (messageFormat) {
/* 139 */       return messageFormat.format(resolveArguments(args, locale));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MessageFormat createMessageFormat(String msg, @Nullable Locale locale) {
/* 150 */     return new MessageFormat(msg, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object[] resolveArguments(@Nullable Object[] args, @Nullable Locale locale) {
/* 162 */     return (args != null) ? args : new Object[0];
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\MessageSourceSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */