/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.EmbeddedValueResolver;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.context.ApplicationStartupAware;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ApplicationContextAwareProcessor
/*     */   implements BeanPostProcessor
/*     */ {
/*     */   private final ConfigurableApplicationContext applicationContext;
/*     */   private final StringValueResolver embeddedValueResolver;
/*     */   
/*     */   public ApplicationContextAwareProcessor(ConfigurableApplicationContext applicationContext) {
/*  76 */     this.applicationContext = applicationContext;
/*  77 */     this.embeddedValueResolver = (StringValueResolver)new EmbeddedValueResolver((ConfigurableBeanFactory)applicationContext.getBeanFactory());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
/*  84 */     if (bean instanceof org.springframework.beans.factory.Aware) {
/*  85 */       invokeAwareInterfaces(bean);
/*     */     }
/*  87 */     return bean;
/*     */   }
/*     */   
/*     */   private void invokeAwareInterfaces(Object bean) {
/*  91 */     if (bean instanceof EnvironmentAware) { EnvironmentAware environmentAware = (EnvironmentAware)bean;
/*  92 */       environmentAware.setEnvironment((Environment)this.applicationContext.getEnvironment()); }
/*     */     
/*  94 */     if (bean instanceof EmbeddedValueResolverAware) { EmbeddedValueResolverAware embeddedValueResolverAware = (EmbeddedValueResolverAware)bean;
/*  95 */       embeddedValueResolverAware.setEmbeddedValueResolver(this.embeddedValueResolver); }
/*     */     
/*  97 */     if (bean instanceof ResourceLoaderAware) { ResourceLoaderAware resourceLoaderAware = (ResourceLoaderAware)bean;
/*  98 */       resourceLoaderAware.setResourceLoader((ResourceLoader)this.applicationContext); }
/*     */     
/* 100 */     if (bean instanceof ApplicationEventPublisherAware) { ApplicationEventPublisherAware applicationEventPublisherAware = (ApplicationEventPublisherAware)bean;
/* 101 */       applicationEventPublisherAware.setApplicationEventPublisher((ApplicationEventPublisher)this.applicationContext); }
/*     */     
/* 103 */     if (bean instanceof MessageSourceAware) { MessageSourceAware messageSourceAware = (MessageSourceAware)bean;
/* 104 */       messageSourceAware.setMessageSource((MessageSource)this.applicationContext); }
/*     */     
/* 106 */     if (bean instanceof ApplicationStartupAware) { ApplicationStartupAware applicationStartupAware = (ApplicationStartupAware)bean;
/* 107 */       applicationStartupAware.setApplicationStartup(this.applicationContext.getApplicationStartup()); }
/*     */     
/* 109 */     if (bean instanceof ApplicationContextAware) { ApplicationContextAware applicationContextAware = (ApplicationContextAware)bean;
/* 110 */       applicationContextAware.setApplicationContext((ApplicationContext)this.applicationContext); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\ApplicationContextAwareProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */