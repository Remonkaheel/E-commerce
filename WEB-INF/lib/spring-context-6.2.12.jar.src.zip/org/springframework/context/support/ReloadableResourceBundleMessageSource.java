/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.DefaultPropertiesPersister;
/*     */ import org.springframework.util.PropertiesPersister;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReloadableResourceBundleMessageSource
/*     */   extends AbstractResourceBasedMessageSource
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   private static final String XML_EXTENSION = ".xml";
/*  98 */   private List<String> fileExtensions = List.of(".properties", ".xml");
/*     */   
/*     */   @Nullable
/*     */   private Properties fileEncodings;
/*     */   
/*     */   private boolean concurrentRefresh = true;
/*     */   
/* 105 */   private PropertiesPersister propertiesPersister = (PropertiesPersister)DefaultPropertiesPersister.INSTANCE;
/*     */   
/* 107 */   private ResourceLoader resourceLoader = (ResourceLoader)new DefaultResourceLoader();
/*     */ 
/*     */   
/* 110 */   private final ConcurrentMap<String, Map<Locale, List<String>>> cachedFilenames = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/* 113 */   private final ConcurrentMap<String, PropertiesHolder> cachedProperties = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/* 116 */   private final ConcurrentMap<Locale, PropertiesHolder> cachedMergedProperties = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileExtensions(List<String> fileExtensions) {
/* 126 */     Assert.isTrue(!CollectionUtils.isEmpty(fileExtensions), "At least one file extension is required");
/* 127 */     for (String extension : fileExtensions) {
/* 128 */       if (!extension.startsWith(".")) {
/* 129 */         throw new IllegalArgumentException("File extension '" + extension + "' should start with '.'");
/*     */       }
/*     */     } 
/* 132 */     this.fileExtensions = Collections.unmodifiableList(fileExtensions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileEncodings(Properties fileEncodings) {
/* 146 */     this.fileEncodings = fileEncodings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConcurrentRefresh(boolean concurrentRefresh) {
/* 161 */     this.concurrentRefresh = concurrentRefresh;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertiesPersister(@Nullable PropertiesPersister propertiesPersister) {
/* 170 */     this
/* 171 */       .propertiesPersister = (propertiesPersister != null) ? propertiesPersister : (PropertiesPersister)DefaultPropertiesPersister.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceLoader(@Nullable ResourceLoader resourceLoader) {
/* 185 */     this.resourceLoader = (resourceLoader != null) ? resourceLoader : (ResourceLoader)new DefaultResourceLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale) {
/* 196 */     if (getCacheMillis() < 0L) {
/* 197 */       PropertiesHolder propHolder = getMergedProperties(locale);
/* 198 */       String result = propHolder.getProperty(code);
/* 199 */       if (result != null) {
/* 200 */         return result;
/*     */       }
/*     */     } else {
/*     */       
/* 204 */       for (String basename : getBasenameSet()) {
/* 205 */         List<String> filenames = calculateAllFilenames(basename, locale);
/* 206 */         for (String filename : filenames) {
/* 207 */           PropertiesHolder propHolder = getProperties(filename);
/* 208 */           String result = propHolder.getProperty(code);
/* 209 */           if (result != null) {
/* 210 */             return result;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 215 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected MessageFormat resolveCode(String code, Locale locale) {
/* 225 */     if (getCacheMillis() < 0L) {
/* 226 */       PropertiesHolder propHolder = getMergedProperties(locale);
/* 227 */       MessageFormat result = propHolder.getMessageFormat(code, locale);
/* 228 */       if (result != null) {
/* 229 */         return result;
/*     */       }
/*     */     } else {
/*     */       
/* 233 */       for (String basename : getBasenameSet()) {
/* 234 */         List<String> filenames = calculateAllFilenames(basename, locale);
/* 235 */         for (String filename : filenames) {
/* 236 */           PropertiesHolder propHolder = getProperties(filename);
/* 237 */           MessageFormat result = propHolder.getMessageFormat(code, locale);
/* 238 */           if (result != null) {
/* 239 */             return result;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 244 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropertiesHolder getMergedProperties(Locale locale) {
/* 259 */     PropertiesHolder mergedHolder = this.cachedMergedProperties.get(locale);
/* 260 */     if (mergedHolder != null) {
/* 261 */       return mergedHolder;
/*     */     }
/* 263 */     mergedHolder = mergeProperties(collectPropertiesToMerge(locale));
/* 264 */     PropertiesHolder existing = this.cachedMergedProperties.putIfAbsent(locale, mergedHolder);
/* 265 */     if (existing != null) {
/* 266 */       mergedHolder = existing;
/*     */     }
/* 268 */     return mergedHolder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<PropertiesHolder> collectPropertiesToMerge(Locale locale) {
/* 281 */     String[] basenames = StringUtils.toStringArray(getBasenameSet());
/* 282 */     List<PropertiesHolder> holders = new ArrayList<>(basenames.length);
/* 283 */     for (int i = basenames.length - 1; i >= 0; i--) {
/* 284 */       List<String> filenames = calculateAllFilenames(basenames[i], locale);
/* 285 */       for (int j = filenames.size() - 1; j >= 0; j--) {
/* 286 */         String filename = filenames.get(j);
/* 287 */         PropertiesHolder propHolder = getProperties(filename);
/* 288 */         if (propHolder.getProperties() != null) {
/* 289 */           holders.add(propHolder);
/*     */         }
/*     */       } 
/*     */     } 
/* 293 */     return holders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropertiesHolder mergeProperties(List<PropertiesHolder> holders) {
/* 306 */     Properties mergedProps = newProperties();
/* 307 */     long latestTimestamp = -1L;
/* 308 */     for (PropertiesHolder holder : holders) {
/* 309 */       mergedProps.putAll(holder.getProperties());
/* 310 */       if (holder.getFileTimestamp() > latestTimestamp) {
/* 311 */         latestTimestamp = holder.getFileTimestamp();
/*     */       }
/*     */     } 
/* 314 */     return new PropertiesHolder(mergedProps, latestTimestamp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> calculateAllFilenames(String basename, Locale locale) {
/* 328 */     Map<Locale, List<String>> localeMap = this.cachedFilenames.get(basename);
/* 329 */     if (localeMap != null) {
/* 330 */       List<String> list = localeMap.get(locale);
/* 331 */       if (list != null) {
/* 332 */         return list;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 337 */     List<String> filenames = new ArrayList<>(7);
/* 338 */     filenames.addAll(calculateFilenamesForLocale(basename, locale));
/*     */ 
/*     */     
/* 341 */     Locale defaultLocale = getDefaultLocale();
/* 342 */     if (defaultLocale != null && !defaultLocale.equals(locale)) {
/* 343 */       List<String> fallbackFilenames = calculateFilenamesForLocale(basename, defaultLocale);
/* 344 */       for (String fallbackFilename : fallbackFilenames) {
/* 345 */         if (!filenames.contains(fallbackFilename))
/*     */         {
/* 347 */           filenames.add(fallbackFilename);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 353 */     filenames.add(basename);
/*     */     
/* 355 */     if (localeMap == null) {
/* 356 */       localeMap = new ConcurrentHashMap<>();
/* 357 */       Map<Locale, List<String>> existing = this.cachedFilenames.putIfAbsent(basename, localeMap);
/* 358 */       if (existing != null) {
/* 359 */         localeMap = existing;
/*     */       }
/*     */     } 
/* 362 */     localeMap.put(locale, filenames);
/* 363 */     return filenames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> calculateFilenamesForLocale(String basename, Locale locale) {
/* 377 */     List<String> result = new ArrayList<>(3);
/* 378 */     String language = locale.getLanguage();
/* 379 */     String country = locale.getCountry();
/* 380 */     String variant = locale.getVariant();
/* 381 */     StringBuilder temp = new StringBuilder(basename);
/*     */     
/* 383 */     temp.append('_');
/* 384 */     if (language.length() > 0) {
/* 385 */       temp.append(language);
/* 386 */       result.add(0, temp.toString());
/*     */     } 
/*     */     
/* 389 */     temp.append('_');
/* 390 */     if (country.length() > 0) {
/* 391 */       temp.append(country);
/* 392 */       result.add(0, temp.toString());
/*     */     } 
/*     */     
/* 395 */     if (variant.length() > 0 && (language.length() > 0 || country.length() > 0)) {
/* 396 */       temp.append('_').append(variant);
/* 397 */       result.add(0, temp.toString());
/*     */     } 
/*     */     
/* 400 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropertiesHolder getProperties(String filename) {
/* 411 */     PropertiesHolder propHolder = this.cachedProperties.get(filename);
/* 412 */     long originalTimestamp = -2L;
/*     */     
/* 414 */     if (propHolder != null) {
/* 415 */       originalTimestamp = propHolder.getRefreshTimestamp();
/* 416 */       if (originalTimestamp == -1L || originalTimestamp > System.currentTimeMillis() - getCacheMillis())
/*     */       {
/* 418 */         return propHolder;
/*     */       }
/*     */     } else {
/*     */       
/* 422 */       propHolder = new PropertiesHolder();
/* 423 */       PropertiesHolder existingHolder = this.cachedProperties.putIfAbsent(filename, propHolder);
/* 424 */       if (existingHolder != null) {
/* 425 */         propHolder = existingHolder;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 430 */     if (this.concurrentRefresh && propHolder.getRefreshTimestamp() >= 0L) {
/*     */       
/* 432 */       if (!propHolder.refreshLock.tryLock())
/*     */       {
/*     */         
/* 435 */         return propHolder;
/*     */       }
/*     */     } else {
/*     */       
/* 439 */       propHolder.refreshLock.lock();
/*     */     } 
/*     */     try {
/* 442 */       PropertiesHolder existingHolder = this.cachedProperties.get(filename);
/* 443 */       if (existingHolder != null && existingHolder.getRefreshTimestamp() > originalTimestamp) {
/* 444 */         return existingHolder;
/*     */       }
/* 446 */       return refreshProperties(filename, propHolder);
/*     */     } finally {
/*     */       
/* 449 */       propHolder.refreshLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropertiesHolder refreshProperties(String filename, @Nullable PropertiesHolder propHolder) {
/* 462 */     long refreshTimestamp = (getCacheMillis() < 0L) ? -1L : System.currentTimeMillis();
/*     */     
/* 464 */     Resource resource = resolveResource(filename);
/* 465 */     if (resource != null) {
/* 466 */       long fileTimestamp = -1L;
/* 467 */       if (getCacheMillis() >= 0L) {
/*     */         
/*     */         try {
/* 470 */           fileTimestamp = resource.lastModified();
/* 471 */           if (propHolder != null && propHolder.getFileTimestamp() == fileTimestamp) {
/* 472 */             if (this.logger.isDebugEnabled()) {
/* 473 */               this.logger.debug("Re-caching properties for filename [" + filename + "] - file hasn't been modified");
/*     */             }
/* 475 */             propHolder.setRefreshTimestamp(refreshTimestamp);
/* 476 */             return propHolder;
/*     */           }
/*     */         
/* 479 */         } catch (IOException ex) {
/*     */           
/* 481 */           if (this.logger.isDebugEnabled()) {
/* 482 */             this.logger.debug(String.valueOf(resource) + " could not be resolved in the file system - assuming that it hasn't changed", ex);
/*     */           }
/* 484 */           fileTimestamp = -1L;
/*     */         } 
/*     */       }
/*     */       try {
/* 488 */         Properties props = loadProperties(resource, filename);
/* 489 */         propHolder = new PropertiesHolder(props, fileTimestamp);
/*     */       }
/* 491 */       catch (IOException ex) {
/* 492 */         if (this.logger.isWarnEnabled()) {
/* 493 */           this.logger.warn("Could not parse properties file [" + resource.getFilename() + "]", ex);
/*     */         }
/*     */         
/* 496 */         propHolder = new PropertiesHolder();
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 502 */       if (this.logger.isDebugEnabled()) {
/* 503 */         this.logger.debug("No properties file found for [" + filename + "]");
/*     */       }
/*     */       
/* 506 */       propHolder = new PropertiesHolder();
/*     */     } 
/*     */     
/* 509 */     propHolder.setRefreshTimestamp(refreshTimestamp);
/* 510 */     this.cachedProperties.put(filename, propHolder);
/* 511 */     return propHolder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Resource resolveResource(String filename) {
/* 547 */     for (String fileExtension : this.fileExtensions) {
/* 548 */       Resource resource = this.resourceLoader.getResource(filename + filename);
/* 549 */       if (resource.exists()) {
/* 550 */         return resource;
/*     */       }
/*     */     } 
/* 553 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Properties loadProperties(Resource resource, String filename) throws IOException {
/* 564 */     Properties props = newProperties();
/* 565 */     InputStream is = resource.getInputStream(); try {
/* 566 */       String resourceFilename = resource.getFilename();
/* 567 */       if (resourceFilename != null && resourceFilename.endsWith(".xml")) {
/* 568 */         if (this.logger.isDebugEnabled()) {
/* 569 */           this.logger.debug("Loading properties [" + resource.getFilename() + "]");
/*     */         }
/* 571 */         this.propertiesPersister.loadFromXml(props, is);
/*     */       } else {
/*     */         
/* 574 */         String encoding = null;
/* 575 */         if (this.fileEncodings != null) {
/* 576 */           encoding = this.fileEncodings.getProperty(filename);
/*     */         }
/* 578 */         if (encoding == null) {
/* 579 */           encoding = getDefaultEncoding();
/*     */         }
/* 581 */         if (encoding != null) {
/* 582 */           if (this.logger.isDebugEnabled()) {
/* 583 */             this.logger.debug("Loading properties [" + resource.getFilename() + "] with encoding '" + encoding + "'");
/*     */           }
/* 585 */           this.propertiesPersister.load(props, new InputStreamReader(is, encoding));
/*     */         } else {
/*     */           
/* 588 */           if (this.logger.isDebugEnabled()) {
/* 589 */             this.logger.debug("Loading properties [" + resource.getFilename() + "]");
/*     */           }
/* 591 */           this.propertiesPersister.load(props, is);
/*     */         } 
/*     */       } 
/* 594 */       Properties properties = props;
/* 595 */       if (is != null) is.close(); 
/*     */       return properties;
/*     */     } catch (Throwable throwable) {
/*     */       if (is != null)
/*     */         try {
/*     */           is.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         }  
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   protected Properties newProperties() {
/* 608 */     return new Properties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearCache() {
/* 617 */     this.logger.debug("Clearing entire resource bundle cache");
/* 618 */     this.cachedProperties.clear();
/* 619 */     this.cachedMergedProperties.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearCacheIncludingAncestors() {
/* 627 */     clearCache();
/* 628 */     MessageSource messageSource = getParentMessageSource(); if (messageSource instanceof ReloadableResourceBundleMessageSource) { ReloadableResourceBundleMessageSource reloadableMsgSrc = (ReloadableResourceBundleMessageSource)messageSource;
/* 629 */       reloadableMsgSrc.clearCacheIncludingAncestors(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 636 */     return getClass().getName() + ": basenames=" + getClass().getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class PropertiesHolder
/*     */   {
/*     */     @Nullable
/*     */     private final Properties properties;
/*     */ 
/*     */ 
/*     */     
/*     */     private final long fileTimestamp;
/*     */ 
/*     */ 
/*     */     
/* 653 */     private volatile long refreshTimestamp = -2L;
/*     */     
/* 655 */     private final Lock refreshLock = new ReentrantLock();
/*     */ 
/*     */     
/* 658 */     private final ConcurrentMap<String, Map<Locale, MessageFormat>> cachedMessageFormats = new ConcurrentHashMap<>();
/*     */ 
/*     */     
/*     */     public PropertiesHolder() {
/* 662 */       this.properties = null;
/* 663 */       this.fileTimestamp = -1L;
/*     */     }
/*     */     
/*     */     public PropertiesHolder(Properties properties, long fileTimestamp) {
/* 667 */       this.properties = properties;
/* 668 */       this.fileTimestamp = fileTimestamp;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Properties getProperties() {
/* 673 */       return this.properties;
/*     */     }
/*     */     
/*     */     public long getFileTimestamp() {
/* 677 */       return this.fileTimestamp;
/*     */     }
/*     */     
/*     */     public void setRefreshTimestamp(long refreshTimestamp) {
/* 681 */       this.refreshTimestamp = refreshTimestamp;
/*     */     }
/*     */     
/*     */     public long getRefreshTimestamp() {
/* 685 */       return this.refreshTimestamp;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public String getProperty(String code) {
/* 690 */       if (this.properties == null) {
/* 691 */         return null;
/*     */       }
/* 693 */       return this.properties.getProperty(code);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public MessageFormat getMessageFormat(String code, Locale locale) {
/* 698 */       if (this.properties == null) {
/* 699 */         return null;
/*     */       }
/* 701 */       Map<Locale, MessageFormat> localeMap = this.cachedMessageFormats.get(code);
/* 702 */       if (localeMap != null) {
/* 703 */         MessageFormat result = localeMap.get(locale);
/* 704 */         if (result != null) {
/* 705 */           return result;
/*     */         }
/*     */       } 
/* 708 */       String msg = this.properties.getProperty(code);
/* 709 */       if (msg != null) {
/* 710 */         if (localeMap == null) {
/* 711 */           localeMap = new ConcurrentHashMap<>();
/* 712 */           Map<Locale, MessageFormat> existing = this.cachedMessageFormats.putIfAbsent(code, localeMap);
/* 713 */           if (existing != null) {
/* 714 */             localeMap = existing;
/*     */           }
/*     */         } 
/* 717 */         MessageFormat result = ReloadableResourceBundleMessageSource.this.createMessageFormat(msg, locale);
/* 718 */         localeMap.put(locale, result);
/* 719 */         return result;
/*     */       } 
/* 721 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\ReloadableResourceBundleMessageSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */