/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.function.BiConsumer;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.beans.factory.support.AbstractAutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionValueResolver;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.MergedBeanDefinitionPostProcessor;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MergedBeanDefinitionPostProcessorInvoker
/*     */ {
/*     */   private final DefaultListableBeanFactory beanFactory;
/*     */   
/*     */   private MergedBeanDefinitionPostProcessorInvoker(DefaultListableBeanFactory beanFactory) {
/* 463 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */   private void invokeMergedBeanDefinitionPostProcessors() {
/* 467 */     List<MergedBeanDefinitionPostProcessor> postProcessors = PostProcessorRegistrationDelegate.loadBeanPostProcessors((ConfigurableListableBeanFactory)this.beanFactory, MergedBeanDefinitionPostProcessor.class);
/*     */     
/* 469 */     for (String beanName : this.beanFactory.getBeanDefinitionNames()) {
/* 470 */       RootBeanDefinition bd = (RootBeanDefinition)this.beanFactory.getMergedBeanDefinition(beanName);
/* 471 */       Class<?> beanType = resolveBeanType((AbstractBeanDefinition)bd);
/* 472 */       postProcessRootBeanDefinition(postProcessors, beanName, beanType, bd);
/* 473 */       bd.markAsPostProcessed();
/*     */     } 
/* 475 */     PostProcessorRegistrationDelegate.registerBeanPostProcessors((ConfigurableListableBeanFactory)this.beanFactory, (List)postProcessors);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void postProcessRootBeanDefinition(List<MergedBeanDefinitionPostProcessor> postProcessors, String beanName, Class<?> beanType, RootBeanDefinition bd) {
/* 481 */     BeanDefinitionValueResolver valueResolver = new BeanDefinitionValueResolver((AbstractAutowireCapableBeanFactory)this.beanFactory, beanName, (BeanDefinition)bd);
/* 482 */     postProcessors.forEach(postProcessor -> postProcessor.postProcessMergedBeanDefinition(bd, beanType, beanName));
/* 483 */     for (PropertyValue propertyValue : bd.getPropertyValues().getPropertyValueList()) {
/* 484 */       postProcessValue(postProcessors, valueResolver, propertyValue.getValue());
/*     */     }
/* 486 */     for (ConstructorArgumentValues.ValueHolder valueHolder : bd.getConstructorArgumentValues().getIndexedArgumentValues().values()) {
/* 487 */       postProcessValue(postProcessors, valueResolver, valueHolder.getValue());
/*     */     }
/* 489 */     for (ConstructorArgumentValues.ValueHolder valueHolder : bd.getConstructorArgumentValues().getGenericArgumentValues()) {
/* 490 */       postProcessValue(postProcessors, valueResolver, valueHolder.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void postProcessValue(List<MergedBeanDefinitionPostProcessor> postProcessors, BeanDefinitionValueResolver valueResolver, @Nullable Object value) {
/* 496 */     if (value instanceof BeanDefinitionHolder) { BeanDefinitionHolder bdh = (BeanDefinitionHolder)value;
/* 497 */       BeanDefinition beanDefinition = bdh.getBeanDefinition(); if (beanDefinition instanceof AbstractBeanDefinition) { AbstractBeanDefinition innerBd = (AbstractBeanDefinition)beanDefinition;
/*     */         
/* 499 */         Class<?> innerBeanType = resolveBeanType(innerBd);
/* 500 */         resolveInnerBeanDefinition(valueResolver, (BeanDefinition)innerBd, (innerBeanName, innerBeanDefinition) -> postProcessRootBeanDefinition(postProcessors, innerBeanName, innerBeanType, innerBeanDefinition)); return; }
/*     */        }
/*     */     
/* 503 */     if (value instanceof AbstractBeanDefinition) { AbstractBeanDefinition innerBd = (AbstractBeanDefinition)value;
/* 504 */       Class<?> innerBeanType = resolveBeanType(innerBd);
/* 505 */       resolveInnerBeanDefinition(valueResolver, (BeanDefinition)innerBd, (innerBeanName, innerBeanDefinition) -> postProcessRootBeanDefinition(postProcessors, innerBeanName, innerBeanType, innerBeanDefinition));
/*     */        }
/*     */     
/* 508 */     else if (value instanceof TypedStringValue) { TypedStringValue typedStringValue = (TypedStringValue)value;
/* 509 */       resolveTypeStringValue(typedStringValue); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void resolveInnerBeanDefinition(BeanDefinitionValueResolver valueResolver, BeanDefinition innerBeanDefinition, BiConsumer<String, RootBeanDefinition> resolver) {
/* 516 */     valueResolver.resolveInnerBean(null, innerBeanDefinition, (name, rbd) -> {
/*     */           resolver.accept(name, rbd);
/*     */           return Void.class;
/*     */         });
/*     */   }
/*     */   
/*     */   private void resolveTypeStringValue(TypedStringValue typedStringValue) {
/*     */     try {
/* 524 */       typedStringValue.resolveTargetType(this.beanFactory.getBeanClassLoader());
/*     */     }
/* 526 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> resolveBeanType(AbstractBeanDefinition bd) {
/* 532 */     if (!bd.hasBeanClass()) {
/*     */       try {
/* 534 */         bd.resolveBeanClass(this.beanFactory.getBeanClassLoader());
/*     */       }
/* 536 */       catch (ClassNotFoundException classNotFoundException) {}
/*     */     }
/*     */ 
/*     */     
/* 540 */     return bd.getResolvableType().toClass();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\PostProcessorRegistrationDelegate$MergedBeanDefinitionPostProcessorInvoker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */