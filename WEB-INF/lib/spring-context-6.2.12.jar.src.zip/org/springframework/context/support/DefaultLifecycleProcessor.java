/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.CyclicBarrier;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.crac.CheckpointException;
/*     */ import org.crac.Context;
/*     */ import org.crac.Core;
/*     */ import org.crac.Resource;
/*     */ import org.crac.RestoreException;
/*     */ import org.crac.management.CRaCMXBean;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.Lifecycle;
/*     */ import org.springframework.context.LifecycleProcessor;
/*     */ import org.springframework.context.Phased;
/*     */ import org.springframework.context.SmartLifecycle;
/*     */ import org.springframework.core.NativeDetector;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultLifecycleProcessor
/*     */   implements LifecycleProcessor, BeanFactoryAware
/*     */ {
/*     */   public static final String CHECKPOINT_PROPERTY_NAME = "spring.context.checkpoint";
/*     */   public static final String EXIT_PROPERTY_NAME = "spring.context.exit";
/*     */   public static final String ON_REFRESH_VALUE = "onRefresh";
/* 112 */   private static boolean checkpointOnRefresh = "onRefresh"
/* 113 */     .equalsIgnoreCase(SpringProperties.getProperty("spring.context.checkpoint"));
/*     */   
/* 115 */   private static final boolean exitOnRefresh = "onRefresh"
/* 116 */     .equalsIgnoreCase(SpringProperties.getProperty("spring.context.exit"));
/*     */   
/* 118 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/* 120 */   private final Map<Integer, Long> concurrentStartupForPhases = new ConcurrentHashMap<>();
/*     */   
/* 122 */   private final Map<Integer, Long> timeoutsForShutdownPhases = new ConcurrentHashMap<>();
/*     */   
/* 124 */   private volatile long timeoutPerShutdownPhase = 10000L;
/*     */ 
/*     */   
/*     */   private volatile boolean running;
/*     */   
/*     */   @Nullable
/*     */   private volatile ConfigurableListableBeanFactory beanFactory;
/*     */   
/*     */   @Nullable
/*     */   private volatile Set<String> stoppedBeans;
/*     */   
/*     */   @Nullable
/*     */   private Object cracResource;
/*     */ 
/*     */   
/*     */   public DefaultLifecycleProcessor() {
/* 140 */     if (!NativeDetector.inNativeImage() && ClassUtils.isPresent("org.crac.Core", getClass().getClassLoader())) {
/* 141 */       this.cracResource = (new CracDelegate()).registerResource();
/*     */     }
/* 143 */     else if (checkpointOnRefresh) {
/* 144 */       throw new IllegalStateException("Checkpoint on refresh requires a CRaC-enabled JVM and 'org.crac:crac' on the classpath");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConcurrentStartupForPhases(Map<Integer, Long> phasesWithTimeouts) {
/* 167 */     this.concurrentStartupForPhases.putAll(phasesWithTimeouts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConcurrentStartupForPhase(int phase, long timeout) {
/* 186 */     this.concurrentStartupForPhases.put(Integer.valueOf(phase), Long.valueOf(timeout));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeoutsForShutdownPhases(Map<Integer, Long> phasesWithTimeouts) {
/* 202 */     this.timeoutsForShutdownPhases.putAll(phasesWithTimeouts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeoutForShutdownPhase(int phase, long timeout) {
/* 217 */     this.timeoutsForShutdownPhases.put(Integer.valueOf(phase), Long.valueOf(timeout));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeoutPerShutdownPhase(long timeoutPerShutdownPhase) {
/* 227 */     this.timeoutPerShutdownPhase = timeoutPerShutdownPhase;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/*     */     ConfigurableListableBeanFactory clbf;
/* 232 */     if (beanFactory instanceof ConfigurableListableBeanFactory) { clbf = (ConfigurableListableBeanFactory)beanFactory; }
/* 233 */     else { throw new IllegalArgumentException("DefaultLifecycleProcessor requires a ConfigurableListableBeanFactory: " + String.valueOf(beanFactory)); }
/*     */ 
/*     */     
/* 236 */     if (!this.concurrentStartupForPhases.isEmpty() && clbf.getBootstrapExecutor() == null) {
/* 237 */       throw new IllegalStateException("'bootstrapExecutor' needs to be configured for concurrent startup");
/*     */     }
/* 239 */     this.beanFactory = clbf;
/*     */   }
/*     */   
/*     */   private ConfigurableListableBeanFactory getBeanFactory() {
/* 243 */     ConfigurableListableBeanFactory beanFactory = this.beanFactory;
/* 244 */     Assert.state((beanFactory != null), "No BeanFactory available");
/* 245 */     return beanFactory;
/*     */   }
/*     */   
/*     */   private Executor getBootstrapExecutor() {
/* 249 */     Executor executor = getBeanFactory().getBootstrapExecutor();
/* 250 */     Assert.state((executor != null), "No 'bootstrapExecutor' available");
/* 251 */     return executor;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Long determineConcurrentStartup(int phase) {
/* 256 */     return this.concurrentStartupForPhases.get(Integer.valueOf(phase));
/*     */   }
/*     */   
/*     */   private long determineShutdownTimeout(int phase) {
/* 260 */     Long timeout = this.timeoutsForShutdownPhases.get(Integer.valueOf(phase));
/* 261 */     return (timeout != null) ? timeout.longValue() : this.timeoutPerShutdownPhase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 277 */     this.stoppedBeans = null;
/* 278 */     startBeans(false);
/*     */ 
/*     */     
/* 281 */     this.running = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 294 */     stopBeans();
/* 295 */     this.running = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRefresh() {
/* 300 */     if (checkpointOnRefresh) {
/* 301 */       checkpointOnRefresh = false;
/* 302 */       (new CracDelegate()).checkpointRestore();
/*     */     } 
/* 304 */     if (exitOnRefresh) {
/* 305 */       Runtime.getRuntime().halt(0);
/*     */     }
/*     */     
/* 308 */     this.stoppedBeans = null;
/*     */     try {
/* 310 */       startBeans(true);
/*     */     }
/* 312 */     catch (ApplicationContextException ex) {
/*     */ 
/*     */       
/* 315 */       stopBeans();
/* 316 */       throw ex;
/*     */     } 
/* 318 */     this.running = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClose() {
/* 323 */     stopBeans();
/* 324 */     this.running = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRunning() {
/* 329 */     return this.running;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void stopForRestart() {
/* 336 */     if (this.running) {
/* 337 */       this.stoppedBeans = ConcurrentHashMap.newKeySet();
/* 338 */       stopBeans();
/* 339 */       this.running = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   void restartAfterStop() {
/* 344 */     if (this.stoppedBeans != null) {
/* 345 */       startBeans(true);
/* 346 */       this.stoppedBeans = null;
/* 347 */       this.running = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void startBeans(boolean autoStartupOnly) {
/* 352 */     Map<String, Lifecycle> lifecycleBeans = getLifecycleBeans();
/* 353 */     Map<Integer, LifecycleGroup> phases = new TreeMap<>();
/*     */     
/* 355 */     lifecycleBeans.forEach((beanName, bean) -> {
/*     */           if (!autoStartupOnly || isAutoStartupCandidate(beanName, bean)) {
/*     */             int startupPhase = getPhase(bean);
/*     */             
/*     */             ((LifecycleGroup)phases.computeIfAbsent(Integer.valueOf(startupPhase), ())).add(beanName, bean);
/*     */           } 
/*     */         });
/*     */     
/* 363 */     if (!phases.isEmpty()) {
/* 364 */       phases.values().forEach(LifecycleGroup::start);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isAutoStartupCandidate(String beanName, Lifecycle bean) {
/* 369 */     Set<String> stoppedBeans = this.stoppedBeans;
/*     */     
/* 371 */     if (bean instanceof SmartLifecycle) { SmartLifecycle smartLifecycle = (SmartLifecycle)bean; if (smartLifecycle.isAutoStartup()); }
/*     */     
/*     */     return (stoppedBeans != null) ? stoppedBeans.contains(beanName) : false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doStart(Map<String, ? extends Lifecycle> lifecycleBeans, String beanName, boolean autoStartupOnly, @Nullable List<CompletableFuture<?>> futures) {
/* 383 */     Lifecycle bean = lifecycleBeans.remove(beanName);
/* 384 */     if (bean != null && bean != this) {
/* 385 */       String[] dependenciesForBean = getBeanFactory().getDependenciesForBean(beanName);
/* 386 */       for (String dependency : dependenciesForBean) {
/* 387 */         doStart(lifecycleBeans, dependency, autoStartupOnly, futures);
/*     */       }
/* 389 */       if (!bean.isRunning() && (!autoStartupOnly || toBeStarted(beanName, bean))) {
/* 390 */         if (futures != null) {
/* 391 */           futures.add(CompletableFuture.runAsync(() -> doStart(beanName, bean), getBootstrapExecutor()));
/*     */         } else {
/*     */           
/* 394 */           doStart(beanName, bean);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void doStart(String beanName, Lifecycle bean) {
/* 401 */     if (this.logger.isTraceEnabled()) {
/* 402 */       this.logger.trace("Starting bean '" + beanName + "' of type [" + bean.getClass().getName() + "]");
/*     */     }
/*     */     try {
/* 405 */       bean.start();
/*     */     }
/* 407 */     catch (Throwable ex) {
/* 408 */       throw new ApplicationContextException("Failed to start bean '" + beanName + "'", ex);
/*     */     } 
/* 410 */     if (this.logger.isDebugEnabled()) {
/* 411 */       this.logger.debug("Successfully started bean '" + beanName + "'");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean toBeStarted(String beanName, Lifecycle bean) {
/* 416 */     Set<String> stoppedBeans = this.stoppedBeans;
/* 417 */     if (stoppedBeans != null) {  }
/* 418 */     else if (bean instanceof SmartLifecycle) { SmartLifecycle smartLifecycle = (SmartLifecycle)bean; if (smartLifecycle.isAutoStartup());
/*     */       return false; }
/*     */     
/*     */     return true; } private void stopBeans() {
/* 422 */     Map<String, Lifecycle> lifecycleBeans = getLifecycleBeans();
/* 423 */     Map<Integer, LifecycleGroup> phases = new TreeMap<>(Comparator.reverseOrder());
/*     */     
/* 425 */     lifecycleBeans.forEach((beanName, bean) -> {
/*     */           int shutdownPhase = getPhase(bean);
/*     */           
/*     */           ((LifecycleGroup)phases.computeIfAbsent(Integer.valueOf(shutdownPhase), ())).add(beanName, bean);
/*     */         });
/*     */     
/* 431 */     if (!phases.isEmpty()) {
/* 432 */       phases.values().forEach(LifecycleGroup::stop);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doStop(Map<String, ? extends Lifecycle> lifecycleBeans, String beanName, CountDownLatch latch, Set<String> countDownBeanNames) {
/* 445 */     Lifecycle bean = lifecycleBeans.remove(beanName);
/* 446 */     if (bean != null) {
/* 447 */       String[] dependentBeans = getBeanFactory().getDependentBeans(beanName);
/* 448 */       for (String dependentBean : dependentBeans) {
/* 449 */         doStop(lifecycleBeans, dependentBean, latch, countDownBeanNames);
/*     */       }
/*     */       try {
/* 452 */         if (bean.isRunning()) {
/* 453 */           Set<String> stoppedBeans = this.stoppedBeans;
/* 454 */           if (stoppedBeans != null) {
/* 455 */             stoppedBeans.add(beanName);
/*     */           }
/* 457 */           if (bean instanceof SmartLifecycle) { SmartLifecycle smartLifecycle = (SmartLifecycle)bean;
/* 458 */             if (this.logger.isTraceEnabled()) {
/* 459 */               this.logger.trace("Asking bean '" + beanName + "' of type [" + bean
/* 460 */                   .getClass().getName() + "] to stop");
/*     */             }
/* 462 */             countDownBeanNames.add(beanName);
/* 463 */             smartLifecycle.stop(() -> {
/*     */                   latch.countDown();
/*     */                   
/*     */                   countDownBeanNames.remove(beanName);
/*     */                   if (this.logger.isDebugEnabled()) {
/*     */                     this.logger.debug("Bean '" + beanName + "' completed its stop procedure");
/*     */                   }
/*     */                 }); }
/*     */           else
/* 472 */           { if (this.logger.isTraceEnabled()) {
/* 473 */               this.logger.trace("Stopping bean '" + beanName + "' of type [" + bean
/* 474 */                   .getClass().getName() + "]");
/*     */             }
/* 476 */             bean.stop();
/* 477 */             if (this.logger.isDebugEnabled()) {
/* 478 */               this.logger.debug("Successfully stopped bean '" + beanName + "'");
/*     */             } }
/*     */ 
/*     */         
/* 482 */         } else if (bean instanceof SmartLifecycle) {
/*     */           
/* 484 */           latch.countDown();
/*     */         }
/*     */       
/* 487 */       } catch (Throwable ex) {
/* 488 */         if (this.logger.isWarnEnabled()) {
/* 489 */           this.logger.warn("Failed to stop bean '" + beanName + "'", ex);
/*     */         }
/* 491 */         if (bean instanceof SmartLifecycle) {
/* 492 */           latch.countDown();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, Lifecycle> getLifecycleBeans() {
/* 507 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/* 508 */     Map<String, Lifecycle> beans = new LinkedHashMap<>();
/* 509 */     String[] beanNames = beanFactory.getBeanNamesForType(Lifecycle.class, false, false);
/* 510 */     for (String beanName : beanNames) {
/* 511 */       String beanNameToRegister = BeanFactoryUtils.transformedBeanName(beanName);
/* 512 */       boolean isFactoryBean = beanFactory.isFactoryBean(beanNameToRegister);
/* 513 */       String beanNameToCheck = isFactoryBean ? ("&" + beanName) : beanName;
/* 514 */       if ((beanFactory.containsSingleton(beanNameToRegister) && (!isFactoryBean || 
/* 515 */         matchesBeanType(Lifecycle.class, beanNameToCheck, (BeanFactory)beanFactory))) || 
/* 516 */         matchesBeanType(SmartLifecycle.class, beanNameToCheck, (BeanFactory)beanFactory)) {
/* 517 */         Object bean = beanFactory.getBean(beanNameToCheck);
/* 518 */         if (bean != this && bean instanceof Lifecycle) { Lifecycle lifecycle = (Lifecycle)bean;
/* 519 */           beans.put(beanNameToRegister, lifecycle); }
/*     */       
/*     */       } 
/*     */     } 
/* 523 */     return beans;
/*     */   }
/*     */   
/*     */   private boolean matchesBeanType(Class<?> targetType, String beanName, BeanFactory beanFactory) {
/* 527 */     Class<?> beanType = beanFactory.getType(beanName);
/* 528 */     return (beanType != null && targetType.isAssignableFrom(beanType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getPhase(Lifecycle bean) {
/* 541 */     Phased phased = (Phased)bean; return (bean instanceof Phased) ? phased.getPhase() : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class LifecycleGroup
/*     */   {
/*     */     private final int phase;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<String, ? extends Lifecycle> lifecycleBeans;
/*     */ 
/*     */     
/*     */     private final boolean autoStartupOnly;
/*     */ 
/*     */     
/* 559 */     private final List<DefaultLifecycleProcessor.LifecycleGroupMember> members = new ArrayList<>();
/*     */     
/*     */     private int smartMemberCount;
/*     */     
/*     */     public LifecycleGroup(int phase, Map<String, ? extends Lifecycle> lifecycleBeans, boolean autoStartupOnly) {
/* 564 */       this.phase = phase;
/* 565 */       this.lifecycleBeans = lifecycleBeans;
/* 566 */       this.autoStartupOnly = autoStartupOnly;
/*     */     }
/*     */     
/*     */     public void add(String name, Lifecycle bean) {
/* 570 */       this.members.add(new DefaultLifecycleProcessor.LifecycleGroupMember(name, bean));
/* 571 */       if (bean instanceof SmartLifecycle) {
/* 572 */         this.smartMemberCount++;
/*     */       }
/*     */     }
/*     */     
/*     */     public void start() {
/* 577 */       if (this.members.isEmpty()) {
/*     */         return;
/*     */       }
/* 580 */       if (DefaultLifecycleProcessor.this.logger.isDebugEnabled()) {
/* 581 */         DefaultLifecycleProcessor.this.logger.debug("Starting beans in phase " + this.phase);
/*     */       }
/* 583 */       Long concurrentStartup = DefaultLifecycleProcessor.this.determineConcurrentStartup(this.phase);
/* 584 */       List<CompletableFuture<?>> futures = (concurrentStartup != null) ? new ArrayList<>() : null;
/* 585 */       for (DefaultLifecycleProcessor.LifecycleGroupMember member : this.members) {
/* 586 */         DefaultLifecycleProcessor.this.doStart(this.lifecycleBeans, member.name, this.autoStartupOnly, futures);
/*     */       }
/* 588 */       if (concurrentStartup != null && !CollectionUtils.isEmpty(futures)) {
/*     */         try {
/* 590 */           CompletableFuture.allOf((CompletableFuture<?>[])futures.<CompletableFuture>toArray(new CompletableFuture[0]))
/* 591 */             .get(concurrentStartup.longValue(), TimeUnit.MILLISECONDS);
/*     */         }
/* 593 */         catch (Exception ex) {
/* 594 */           if (ex instanceof ExecutionException) { ExecutionException exEx = (ExecutionException)ex;
/* 595 */             Throwable cause = exEx.getCause();
/* 596 */             if (cause instanceof ApplicationContextException) { ApplicationContextException acEx = (ApplicationContextException)cause;
/* 597 */               throw acEx; }
/*     */              }
/*     */           
/* 600 */           throw new ApplicationContextException("Failed to start beans in phase " + this.phase + " within timeout of " + concurrentStartup + "ms", ex);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void stop() {
/* 607 */       if (this.members.isEmpty()) {
/*     */         return;
/*     */       }
/* 610 */       if (DefaultLifecycleProcessor.this.logger.isDebugEnabled()) {
/* 611 */         DefaultLifecycleProcessor.this.logger.debug("Stopping beans in phase " + this.phase);
/*     */       }
/* 613 */       CountDownLatch latch = new CountDownLatch(this.smartMemberCount);
/* 614 */       Set<String> countDownBeanNames = Collections.synchronizedSet(new LinkedHashSet<>());
/* 615 */       Set<String> lifecycleBeanNames = new HashSet<>(this.lifecycleBeans.keySet());
/* 616 */       for (DefaultLifecycleProcessor.LifecycleGroupMember member : this.members) {
/* 617 */         if (lifecycleBeanNames.contains(member.name)) {
/* 618 */           DefaultLifecycleProcessor.this.doStop(this.lifecycleBeans, member.name, latch, countDownBeanNames); continue;
/*     */         } 
/* 620 */         if (member.bean instanceof SmartLifecycle)
/*     */         {
/* 622 */           latch.countDown();
/*     */         }
/*     */       } 
/*     */       try {
/* 626 */         long shutdownTimeout = DefaultLifecycleProcessor.this.determineShutdownTimeout(this.phase);
/* 627 */         if (!latch.await(shutdownTimeout, TimeUnit.MILLISECONDS))
/*     */         {
/* 629 */           if (!countDownBeanNames.isEmpty() && DefaultLifecycleProcessor.this.logger.isInfoEnabled()) {
/* 630 */             DefaultLifecycleProcessor.this.logger.info("Shutdown phase " + this.phase + " ends with " + countDownBeanNames.size() + " bean" + (
/* 631 */                 (countDownBeanNames.size() > 1) ? "s" : "") + " still running after timeout of " + shutdownTimeout + "ms: " + String.valueOf(countDownBeanNames));
/*     */           
/*     */           }
/*     */         }
/*     */       }
/* 636 */       catch (InterruptedException ex) {
/* 637 */         Thread.currentThread().interrupt();
/*     */       } 
/*     */     }
/*     */   } private static final class LifecycleGroupMember extends Record { private final String name; private final Lifecycle bean; public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/context/support/DefaultLifecycleProcessor$LifecycleGroupMember;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #646	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/context/support/DefaultLifecycleProcessor$LifecycleGroupMember;
/*     */     }
/*     */     public final int hashCode() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/context/support/DefaultLifecycleProcessor$LifecycleGroupMember;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #646	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/context/support/DefaultLifecycleProcessor$LifecycleGroupMember;
/*     */     }
/* 646 */     private LifecycleGroupMember(String name, Lifecycle bean) { this.name = name; this.bean = bean; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/context/support/DefaultLifecycleProcessor$LifecycleGroupMember;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #646	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/context/support/DefaultLifecycleProcessor$LifecycleGroupMember;
/* 646 */       //   0	8	1	o	Ljava/lang/Object; } public String name() { return this.name; } public Lifecycle bean() { return this.bean; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class CracDelegate
/*     */   {
/*     */     public Object registerResource() {
/* 657 */       DefaultLifecycleProcessor.this.logger.debug("Registering JVM checkpoint/restore callback for Spring-managed lifecycle beans");
/* 658 */       DefaultLifecycleProcessor.CracResourceAdapter resourceAdapter = new DefaultLifecycleProcessor.CracResourceAdapter();
/* 659 */       Core.getGlobalContext().register(resourceAdapter);
/* 660 */       return resourceAdapter;
/*     */     }
/*     */     
/*     */     public void checkpointRestore() {
/* 664 */       DefaultLifecycleProcessor.this.logger.info("Triggering JVM checkpoint/restore");
/*     */       try {
/* 666 */         Core.checkpointRestore();
/*     */       }
/* 668 */       catch (UnsupportedOperationException ex) {
/* 669 */         throw new ApplicationContextException("CRaC checkpoint not supported on current JVM", ex);
/*     */       }
/* 671 */       catch (CheckpointException ex) {
/* 672 */         throw new ApplicationContextException("Failed to take CRaC checkpoint on refresh", ex);
/*     */       }
/* 674 */       catch (RestoreException ex) {
/* 675 */         throw new ApplicationContextException("Failed to restore CRaC checkpoint on refresh", ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class CracResourceAdapter
/*     */     implements Resource
/*     */   {
/*     */     @Nullable
/*     */     private CyclicBarrier barrier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void beforeCheckpoint(Context<? extends Resource> context) {
/* 696 */       this.barrier = new CyclicBarrier(2);
/*     */       
/* 698 */       Thread thread = new Thread(() -> { awaitPreventShutdownBarrier(); awaitPreventShutdownBarrier(); }"prevent-shutdown");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 704 */       thread.setDaemon(false);
/* 705 */       thread.start();
/* 706 */       awaitPreventShutdownBarrier();
/*     */       
/* 708 */       DefaultLifecycleProcessor.this.logger.debug("Stopping Spring-managed lifecycle beans before JVM checkpoint");
/* 709 */       DefaultLifecycleProcessor.this.stopForRestart();
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterRestore(Context<? extends Resource> context) {
/* 714 */       DefaultLifecycleProcessor.this.logger.info("Restarting Spring-managed lifecycle beans after JVM restore");
/* 715 */       DefaultLifecycleProcessor.this.restartAfterStop();
/*     */ 
/*     */       
/* 718 */       this.barrier = null;
/*     */       
/* 720 */       if (!DefaultLifecycleProcessor.checkpointOnRefresh) {
/* 721 */         DefaultLifecycleProcessor.this.logger.info("Spring-managed lifecycle restart completed (restored JVM running for " + 
/* 722 */             CRaCMXBean.getCRaCMXBean().getUptimeSinceRestore() + " ms)");
/*     */       }
/*     */     }
/*     */     
/*     */     private void awaitPreventShutdownBarrier() {
/*     */       try {
/* 728 */         if (this.barrier != null) {
/* 729 */           this.barrier.await();
/*     */         }
/*     */       }
/* 732 */       catch (Exception ex) {
/* 733 */         DefaultLifecycleProcessor.this.logger.trace("Exception from prevent-shutdown barrier", ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\DefaultLifecycleProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */