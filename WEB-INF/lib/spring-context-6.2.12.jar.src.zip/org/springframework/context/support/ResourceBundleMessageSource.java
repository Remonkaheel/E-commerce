/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.PropertyResourceBundle;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceBundleMessageSource
/*     */   extends AbstractResourceBasedMessageSource
/*     */   implements BeanClassLoaderAware
/*     */ {
/*     */   @Nullable
/*     */   private ClassLoader bundleClassLoader;
/*     */   @Nullable
/*  83 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private final Map<String, Map<Locale, ResourceBundle>> cachedResourceBundles = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   private final Map<ResourceBundle, Map<String, Map<Locale, MessageFormat>>> cachedBundleMessageFormats = new ConcurrentHashMap<>();
/*     */   
/*     */   @Nullable
/* 106 */   private volatile MessageSourceControl control = new MessageSourceControl();
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceBundleMessageSource() {
/* 111 */     setDefaultEncoding("ISO-8859-1");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBundleClassLoader(ClassLoader classLoader) {
/* 124 */     this.bundleClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ClassLoader getBundleClassLoader() {
/* 134 */     return (this.bundleClassLoader != null) ? this.bundleClassLoader : this.beanClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 139 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale) {
/* 150 */     Set<String> basenames = getBasenameSet();
/* 151 */     for (String basename : basenames) {
/* 152 */       ResourceBundle bundle = getResourceBundle(basename, locale);
/* 153 */       if (bundle != null) {
/* 154 */         String result = getStringOrNull(bundle, code);
/* 155 */         if (result != null) {
/* 156 */           return result;
/*     */         }
/*     */       } 
/*     */     } 
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected MessageFormat resolveCode(String code, Locale locale) {
/* 170 */     Set<String> basenames = getBasenameSet();
/* 171 */     for (String basename : basenames) {
/* 172 */       ResourceBundle bundle = getResourceBundle(basename, locale);
/* 173 */       if (bundle != null) {
/* 174 */         MessageFormat messageFormat = getMessageFormat(bundle, code, locale);
/* 175 */         if (messageFormat != null) {
/* 176 */           return messageFormat;
/*     */         }
/*     */       } 
/*     */     } 
/* 180 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResourceBundle getResourceBundle(String basename, Locale locale) {
/* 194 */     if (getCacheMillis() >= 0L)
/*     */     {
/*     */       
/* 197 */       return doGetBundle(basename, locale);
/*     */     }
/*     */ 
/*     */     
/* 201 */     Map<Locale, ResourceBundle> localeMap = this.cachedResourceBundles.get(basename);
/* 202 */     if (localeMap != null) {
/* 203 */       ResourceBundle bundle = localeMap.get(locale);
/* 204 */       if (bundle != null) {
/* 205 */         return bundle;
/*     */       }
/*     */     } 
/*     */     try {
/* 209 */       ResourceBundle bundle = doGetBundle(basename, locale);
/* 210 */       if (localeMap == null) {
/* 211 */         localeMap = this.cachedResourceBundles.computeIfAbsent(basename, bn -> new ConcurrentHashMap<>());
/*     */       }
/* 213 */       localeMap.put(locale, bundle);
/* 214 */       return bundle;
/*     */     }
/* 216 */     catch (MissingResourceException ex) {
/* 217 */       if (this.logger.isWarnEnabled()) {
/* 218 */         this.logger.warn("ResourceBundle [" + basename + "] not found for MessageSource: " + ex.getMessage());
/*     */       }
/*     */ 
/*     */       
/* 222 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceBundle doGetBundle(String basename, Locale locale) throws MissingResourceException {
/* 237 */     ClassLoader classLoader = getBundleClassLoader();
/* 238 */     Assert.state((classLoader != null), "No bundle ClassLoader set");
/*     */     
/* 240 */     MessageSourceControl control = this.control;
/* 241 */     if (control != null) {
/*     */       try {
/* 243 */         return ResourceBundle.getBundle(basename, locale, classLoader, control);
/*     */       }
/* 245 */       catch (UnsupportedOperationException ex) {
/*     */         
/* 247 */         this.control = null;
/* 248 */         String encoding = getDefaultEncoding();
/* 249 */         if (encoding != null && this.logger.isInfoEnabled()) {
/* 250 */           this.logger.info("ResourceBundleMessageSource is configured to read resources with encoding '" + encoding + "' but ResourceBundle.Control is not supported in current system environment: " + ex
/*     */               
/* 252 */               .getMessage() + " - falling back to plain ResourceBundle.getBundle retrieval with the platform default encoding. Consider setting the 'defaultEncoding' property to 'null' for participating in the platform default and therefore avoiding this log message.");
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 260 */     return ResourceBundle.getBundle(basename, locale, classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceBundle loadBundle(Reader reader) throws IOException {
/* 279 */     return new PropertyResourceBundle(reader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceBundle loadBundle(InputStream inputStream) throws IOException {
/* 301 */     return new PropertyResourceBundle(inputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected MessageFormat getMessageFormat(ResourceBundle bundle, String code, Locale locale) throws MissingResourceException {
/* 318 */     Map<String, Map<Locale, MessageFormat>> codeMap = this.cachedBundleMessageFormats.get(bundle);
/* 319 */     Map<Locale, MessageFormat> localeMap = null;
/* 320 */     if (codeMap != null) {
/* 321 */       localeMap = codeMap.get(code);
/* 322 */       if (localeMap != null) {
/* 323 */         MessageFormat result = localeMap.get(locale);
/* 324 */         if (result != null) {
/* 325 */           return result;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 330 */     String msg = getStringOrNull(bundle, code);
/* 331 */     if (msg != null) {
/* 332 */       if (codeMap == null) {
/* 333 */         codeMap = this.cachedBundleMessageFormats.computeIfAbsent(bundle, b -> new ConcurrentHashMap<>());
/*     */       }
/* 335 */       if (localeMap == null) {
/* 336 */         localeMap = codeMap.computeIfAbsent(code, c -> new ConcurrentHashMap<>());
/*     */       }
/* 338 */       MessageFormat result = createMessageFormat(msg, locale);
/* 339 */       localeMap.put(locale, result);
/* 340 */       return result;
/*     */     } 
/*     */     
/* 343 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getStringOrNull(ResourceBundle bundle, String key) {
/* 362 */     if (bundle.containsKey(key)) {
/*     */       try {
/* 364 */         return bundle.getString(key);
/*     */       }
/* 366 */       catch (MissingResourceException missingResourceException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 371 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 379 */     return getClass().getName() + ": basenames=" + getClass().getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MessageSourceControl
/*     */     extends ResourceBundle.Control
/*     */   {
/*     */     @Nullable
/*     */     public ResourceBundle newBundle(String baseName, Locale locale, String format, ClassLoader loader, boolean reload) throws IllegalAccessException, InstantiationException, IOException {
/* 396 */       if (format.equals("java.properties")) {
/* 397 */         String bundleName = toBundleName(baseName, locale);
/* 398 */         String resourceName = toResourceName(bundleName, "properties");
/* 399 */         ClassLoader classLoader = loader;
/* 400 */         boolean reloadFlag = reload;
/* 401 */         InputStream inputStream = null;
/* 402 */         if (reloadFlag) {
/* 403 */           URL url = classLoader.getResource(resourceName);
/* 404 */           if (url != null) {
/* 405 */             URLConnection connection = url.openConnection();
/* 406 */             if (connection != null) {
/* 407 */               connection.setUseCaches(false);
/* 408 */               inputStream = connection.getInputStream();
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           
/* 413 */           inputStream = classLoader.getResourceAsStream(resourceName);
/*     */         } 
/* 415 */         if (inputStream != null) {
/* 416 */           String encoding = ResourceBundleMessageSource.this.getDefaultEncoding();
/* 417 */           if (encoding != null) {
/* 418 */             InputStreamReader bundleReader = new InputStreamReader(inputStream, encoding); 
/* 419 */             try { ResourceBundle resourceBundle = ResourceBundleMessageSource.this.loadBundle(bundleReader);
/* 420 */               bundleReader.close(); return resourceBundle; } catch (Throwable throwable) { try { bundleReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */                throw throwable; }
/*     */           
/* 423 */           }  InputStream bundleStream = inputStream; 
/* 424 */           try { ResourceBundle resourceBundle = ResourceBundleMessageSource.this.loadBundle(bundleStream);
/* 425 */             if (bundleStream != null) bundleStream.close();  return resourceBundle; } catch (Throwable throwable) { if (bundleStream != null)
/*     */               try { bundleStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */                 throw throwable; }
/*     */         
/* 429 */         }  return null;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 434 */       return super.newBundle(baseName, locale, format, loader, reload);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Locale getFallbackLocale(String baseName, Locale locale) {
/* 441 */       Locale defaultLocale = ResourceBundleMessageSource.this.getDefaultLocale();
/* 442 */       return (defaultLocale != null && !defaultLocale.equals(locale)) ? defaultLocale : null;
/*     */     }
/*     */ 
/*     */     
/*     */     public long getTimeToLive(String baseName, Locale locale) {
/* 447 */       long cacheMillis = ResourceBundleMessageSource.this.getCacheMillis();
/* 448 */       return (cacheMillis >= 0L) ? cacheMillis : super.getTimeToLive(baseName, locale);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean needsReload(String baseName, Locale locale, String format, ClassLoader loader, ResourceBundle bundle, long loadTime) {
/* 455 */       if (super.needsReload(baseName, locale, format, loader, bundle, loadTime)) {
/* 456 */         ResourceBundleMessageSource.this.cachedBundleMessageFormats.remove(bundle);
/* 457 */         return true;
/*     */       } 
/*     */       
/* 460 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\ResourceBundleMessageSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */