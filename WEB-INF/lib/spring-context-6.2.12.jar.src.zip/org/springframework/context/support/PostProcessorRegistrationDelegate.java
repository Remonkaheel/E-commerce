/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.beans.factory.support.AbstractAutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionValueResolver;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.MergedBeanDefinitionPostProcessor;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.core.metrics.ApplicationStartup;
/*     */ import org.springframework.core.metrics.StartupStep;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PostProcessorRegistrationDelegate
/*     */ {
/*     */   public static void invokeBeanFactoryPostProcessors(ConfigurableListableBeanFactory beanFactory, List<BeanFactoryPostProcessor> beanFactoryPostProcessors) {
/*  85 */     Set<String> processedBeans = new HashSet<>();
/*     */     
/*  87 */     if (beanFactory instanceof BeanDefinitionRegistry) { BeanDefinitionRegistry registry = (BeanDefinitionRegistry)beanFactory;
/*  88 */       List<BeanFactoryPostProcessor> regularPostProcessors = new ArrayList<>();
/*  89 */       List<BeanDefinitionRegistryPostProcessor> registryProcessors = new ArrayList<>();
/*     */       
/*  91 */       for (BeanFactoryPostProcessor postProcessor : beanFactoryPostProcessors) {
/*  92 */         if (postProcessor instanceof BeanDefinitionRegistryPostProcessor) { BeanDefinitionRegistryPostProcessor registryProcessor = (BeanDefinitionRegistryPostProcessor)postProcessor;
/*  93 */           registryProcessor.postProcessBeanDefinitionRegistry(registry);
/*  94 */           registryProcessors.add(registryProcessor);
/*     */           continue; }
/*     */         
/*  97 */         regularPostProcessors.add(postProcessor);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 105 */       List<BeanDefinitionRegistryPostProcessor> currentRegistryProcessors = new ArrayList<>();
/*     */ 
/*     */ 
/*     */       
/* 109 */       String[] arrayOfString = beanFactory.getBeanNamesForType(BeanDefinitionRegistryPostProcessor.class, true, false);
/* 110 */       for (String ppName : arrayOfString) {
/* 111 */         if (beanFactory.isTypeMatch(ppName, PriorityOrdered.class)) {
/* 112 */           currentRegistryProcessors.add((BeanDefinitionRegistryPostProcessor)beanFactory.getBean(ppName, BeanDefinitionRegistryPostProcessor.class));
/* 113 */           processedBeans.add(ppName);
/*     */         } 
/*     */       } 
/* 116 */       sortPostProcessors(currentRegistryProcessors, beanFactory);
/* 117 */       registryProcessors.addAll(currentRegistryProcessors);
/* 118 */       invokeBeanDefinitionRegistryPostProcessors(currentRegistryProcessors, registry, beanFactory.getApplicationStartup());
/* 119 */       currentRegistryProcessors.clear();
/*     */ 
/*     */       
/* 122 */       arrayOfString = beanFactory.getBeanNamesForType(BeanDefinitionRegistryPostProcessor.class, true, false);
/* 123 */       for (String ppName : arrayOfString) {
/* 124 */         if (!processedBeans.contains(ppName) && beanFactory.isTypeMatch(ppName, Ordered.class)) {
/* 125 */           currentRegistryProcessors.add((BeanDefinitionRegistryPostProcessor)beanFactory.getBean(ppName, BeanDefinitionRegistryPostProcessor.class));
/* 126 */           processedBeans.add(ppName);
/*     */         } 
/*     */       } 
/* 129 */       sortPostProcessors(currentRegistryProcessors, beanFactory);
/* 130 */       registryProcessors.addAll(currentRegistryProcessors);
/* 131 */       invokeBeanDefinitionRegistryPostProcessors(currentRegistryProcessors, registry, beanFactory.getApplicationStartup());
/* 132 */       currentRegistryProcessors.clear();
/*     */ 
/*     */       
/* 135 */       boolean reiterate = true;
/* 136 */       while (reiterate) {
/* 137 */         reiterate = false;
/* 138 */         arrayOfString = beanFactory.getBeanNamesForType(BeanDefinitionRegistryPostProcessor.class, true, false);
/* 139 */         for (String ppName : arrayOfString) {
/* 140 */           if (!processedBeans.contains(ppName)) {
/* 141 */             currentRegistryProcessors.add((BeanDefinitionRegistryPostProcessor)beanFactory.getBean(ppName, BeanDefinitionRegistryPostProcessor.class));
/* 142 */             processedBeans.add(ppName);
/* 143 */             reiterate = true;
/*     */           } 
/*     */         } 
/* 146 */         sortPostProcessors(currentRegistryProcessors, beanFactory);
/* 147 */         registryProcessors.addAll(currentRegistryProcessors);
/* 148 */         invokeBeanDefinitionRegistryPostProcessors(currentRegistryProcessors, registry, beanFactory.getApplicationStartup());
/* 149 */         currentRegistryProcessors.clear();
/*     */       } 
/*     */ 
/*     */       
/* 153 */       invokeBeanFactoryPostProcessors((Collection)registryProcessors, beanFactory);
/* 154 */       invokeBeanFactoryPostProcessors(regularPostProcessors, beanFactory);
/*     */        }
/*     */     
/*     */     else
/*     */     
/* 159 */     { invokeBeanFactoryPostProcessors(beanFactoryPostProcessors, beanFactory); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     String[] postProcessorNames = beanFactory.getBeanNamesForType(BeanFactoryPostProcessor.class, true, false);
/*     */ 
/*     */ 
/*     */     
/* 169 */     List<BeanFactoryPostProcessor> priorityOrderedPostProcessors = new ArrayList<>();
/* 170 */     List<String> orderedPostProcessorNames = new ArrayList<>();
/* 171 */     List<String> nonOrderedPostProcessorNames = new ArrayList<>();
/* 172 */     for (String ppName : postProcessorNames) {
/* 173 */       if (!processedBeans.contains(ppName))
/*     */       {
/*     */         
/* 176 */         if (beanFactory.isTypeMatch(ppName, PriorityOrdered.class)) {
/* 177 */           priorityOrderedPostProcessors.add((BeanFactoryPostProcessor)beanFactory.getBean(ppName, BeanFactoryPostProcessor.class));
/*     */         }
/* 179 */         else if (beanFactory.isTypeMatch(ppName, Ordered.class)) {
/* 180 */           orderedPostProcessorNames.add(ppName);
/*     */         } else {
/*     */           
/* 183 */           nonOrderedPostProcessorNames.add(ppName);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 188 */     sortPostProcessors(priorityOrderedPostProcessors, beanFactory);
/* 189 */     invokeBeanFactoryPostProcessors(priorityOrderedPostProcessors, beanFactory);
/*     */ 
/*     */     
/* 192 */     List<BeanFactoryPostProcessor> orderedPostProcessors = new ArrayList<>(orderedPostProcessorNames.size());
/* 193 */     for (String postProcessorName : orderedPostProcessorNames) {
/* 194 */       orderedPostProcessors.add((BeanFactoryPostProcessor)beanFactory.getBean(postProcessorName, BeanFactoryPostProcessor.class));
/*     */     }
/* 196 */     sortPostProcessors(orderedPostProcessors, beanFactory);
/* 197 */     invokeBeanFactoryPostProcessors(orderedPostProcessors, beanFactory);
/*     */ 
/*     */     
/* 200 */     List<BeanFactoryPostProcessor> nonOrderedPostProcessors = new ArrayList<>(nonOrderedPostProcessorNames.size());
/* 201 */     for (String postProcessorName : nonOrderedPostProcessorNames) {
/* 202 */       nonOrderedPostProcessors.add((BeanFactoryPostProcessor)beanFactory.getBean(postProcessorName, BeanFactoryPostProcessor.class));
/*     */     }
/* 204 */     invokeBeanFactoryPostProcessors(nonOrderedPostProcessors, beanFactory);
/*     */ 
/*     */ 
/*     */     
/* 208 */     beanFactory.clearMetadataCache();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerBeanPostProcessors(ConfigurableListableBeanFactory beanFactory, AbstractApplicationContext applicationContext) {
/* 227 */     String[] postProcessorNames = beanFactory.getBeanNamesForType(BeanPostProcessor.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     int beanProcessorTargetCount = beanFactory.getBeanPostProcessorCount() + 1 + postProcessorNames.length;
/* 233 */     beanFactory.addBeanPostProcessor(new BeanPostProcessorChecker(beanFactory, postProcessorNames, beanProcessorTargetCount));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 238 */     List<BeanPostProcessor> priorityOrderedPostProcessors = new ArrayList<>();
/* 239 */     List<BeanPostProcessor> internalPostProcessors = new ArrayList<>();
/* 240 */     List<String> orderedPostProcessorNames = new ArrayList<>();
/* 241 */     List<String> nonOrderedPostProcessorNames = new ArrayList<>();
/* 242 */     for (String ppName : postProcessorNames) {
/* 243 */       if (beanFactory.isTypeMatch(ppName, PriorityOrdered.class)) {
/* 244 */         BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean(ppName, BeanPostProcessor.class);
/* 245 */         priorityOrderedPostProcessors.add(pp);
/* 246 */         if (pp instanceof MergedBeanDefinitionPostProcessor) {
/* 247 */           internalPostProcessors.add(pp);
/*     */         }
/*     */       }
/* 250 */       else if (beanFactory.isTypeMatch(ppName, Ordered.class)) {
/* 251 */         orderedPostProcessorNames.add(ppName);
/*     */       } else {
/*     */         
/* 254 */         nonOrderedPostProcessorNames.add(ppName);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 259 */     sortPostProcessors(priorityOrderedPostProcessors, beanFactory);
/* 260 */     registerBeanPostProcessors(beanFactory, priorityOrderedPostProcessors);
/*     */ 
/*     */     
/* 263 */     List<BeanPostProcessor> orderedPostProcessors = new ArrayList<>(orderedPostProcessorNames.size());
/* 264 */     for (String ppName : orderedPostProcessorNames) {
/* 265 */       BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean(ppName, BeanPostProcessor.class);
/* 266 */       orderedPostProcessors.add(pp);
/* 267 */       if (pp instanceof MergedBeanDefinitionPostProcessor) {
/* 268 */         internalPostProcessors.add(pp);
/*     */       }
/*     */     } 
/* 271 */     sortPostProcessors(orderedPostProcessors, beanFactory);
/* 272 */     registerBeanPostProcessors(beanFactory, orderedPostProcessors);
/*     */ 
/*     */     
/* 275 */     List<BeanPostProcessor> nonOrderedPostProcessors = new ArrayList<>(nonOrderedPostProcessorNames.size());
/* 276 */     for (String ppName : nonOrderedPostProcessorNames) {
/* 277 */       BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean(ppName, BeanPostProcessor.class);
/* 278 */       nonOrderedPostProcessors.add(pp);
/* 279 */       if (pp instanceof MergedBeanDefinitionPostProcessor) {
/* 280 */         internalPostProcessors.add(pp);
/*     */       }
/*     */     } 
/* 283 */     registerBeanPostProcessors(beanFactory, nonOrderedPostProcessors);
/*     */ 
/*     */     
/* 286 */     sortPostProcessors(internalPostProcessors, beanFactory);
/* 287 */     registerBeanPostProcessors(beanFactory, internalPostProcessors);
/*     */ 
/*     */ 
/*     */     
/* 291 */     beanFactory.addBeanPostProcessor((BeanPostProcessor)new ApplicationListenerDetector(applicationContext));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends BeanPostProcessor> List<T> loadBeanPostProcessors(ConfigurableListableBeanFactory beanFactory, Class<T> beanPostProcessorType) {
/* 304 */     String[] postProcessorNames = beanFactory.getBeanNamesForType(beanPostProcessorType, true, false);
/* 305 */     List<T> postProcessors = new ArrayList<>();
/* 306 */     for (String ppName : postProcessorNames) {
/* 307 */       postProcessors.add((T)beanFactory.getBean(ppName, beanPostProcessorType));
/*     */     }
/* 309 */     sortPostProcessors(postProcessors, beanFactory);
/* 310 */     return postProcessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void invokeMergedBeanDefinitionPostProcessors(DefaultListableBeanFactory beanFactory) {
/* 322 */     (new MergedBeanDefinitionPostProcessorInvoker(beanFactory)).invokeMergedBeanDefinitionPostProcessors();
/*     */   }
/*     */   
/*     */   private static void sortPostProcessors(List<?> postProcessors, ConfigurableListableBeanFactory beanFactory) {
/*     */     OrderComparator orderComparator;
/* 327 */     if (postProcessors.size() <= 1) {
/*     */       return;
/*     */     }
/* 330 */     Comparator<Object> comparatorToUse = null;
/* 331 */     if (beanFactory instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory dlbf = (DefaultListableBeanFactory)beanFactory;
/* 332 */       comparatorToUse = dlbf.getDependencyComparator(); }
/*     */     
/* 334 */     if (comparatorToUse == null) {
/* 335 */       orderComparator = OrderComparator.INSTANCE;
/*     */     }
/* 337 */     postProcessors.sort((Comparator<?>)orderComparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void invokeBeanDefinitionRegistryPostProcessors(Collection<? extends BeanDefinitionRegistryPostProcessor> postProcessors, BeanDefinitionRegistry registry, ApplicationStartup applicationStartup) {
/* 346 */     for (BeanDefinitionRegistryPostProcessor postProcessor : postProcessors) {
/*     */       
/* 348 */       Objects.requireNonNull(postProcessor); StartupStep postProcessBeanDefRegistry = applicationStartup.start("spring.context.beandef-registry.post-process").tag("postProcessor", postProcessor::toString);
/* 349 */       postProcessor.postProcessBeanDefinitionRegistry(registry);
/* 350 */       postProcessBeanDefRegistry.end();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void invokeBeanFactoryPostProcessors(Collection<? extends BeanFactoryPostProcessor> postProcessors, ConfigurableListableBeanFactory beanFactory) {
/* 360 */     for (BeanFactoryPostProcessor postProcessor : postProcessors) {
/*     */       
/* 362 */       Objects.requireNonNull(postProcessor); StartupStep postProcessBeanFactory = beanFactory.getApplicationStartup().start("spring.context.bean-factory.post-process").tag("postProcessor", postProcessor::toString);
/* 363 */       postProcessor.postProcessBeanFactory(beanFactory);
/* 364 */       postProcessBeanFactory.end();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registerBeanPostProcessors(ConfigurableListableBeanFactory beanFactory, List<? extends BeanPostProcessor> postProcessors) {
/* 374 */     if (beanFactory instanceof AbstractBeanFactory) { AbstractBeanFactory abstractBeanFactory = (AbstractBeanFactory)beanFactory;
/*     */       
/* 376 */       abstractBeanFactory.addBeanPostProcessors(postProcessors); }
/*     */     else
/*     */     
/* 379 */     { for (BeanPostProcessor postProcessor : postProcessors) {
/* 380 */         beanFactory.addBeanPostProcessor(postProcessor);
/*     */       } }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class BeanPostProcessorChecker
/*     */     implements BeanPostProcessor
/*     */   {
/* 393 */     private static final Log logger = LogFactory.getLog(BeanPostProcessorChecker.class);
/*     */ 
/*     */     
/*     */     private final ConfigurableListableBeanFactory beanFactory;
/*     */     
/*     */     private final String[] postProcessorNames;
/*     */     
/*     */     private final int beanPostProcessorTargetCount;
/*     */ 
/*     */     
/*     */     public BeanPostProcessorChecker(ConfigurableListableBeanFactory beanFactory, String[] postProcessorNames, int beanPostProcessorTargetCount) {
/* 404 */       this.beanFactory = beanFactory;
/* 405 */       this.postProcessorNames = postProcessorNames;
/* 406 */       this.beanPostProcessorTargetCount = beanPostProcessorTargetCount;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName) {
/* 411 */       return bean;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object postProcessAfterInitialization(Object bean, String beanName) {
/* 416 */       if (!(bean instanceof BeanPostProcessor) && !isInfrastructureBean(beanName) && this.beanFactory
/* 417 */         .getBeanPostProcessorCount() < this.beanPostProcessorTargetCount && 
/* 418 */         logger.isWarnEnabled()) {
/* 419 */         Set<String> bppsInCreation = new LinkedHashSet<>(2);
/* 420 */         for (String bppName : this.postProcessorNames) {
/* 421 */           if (this.beanFactory.isCurrentlyInCreation(bppName)) {
/* 422 */             bppsInCreation.add(bppName);
/*     */           }
/*     */         } 
/* 425 */         if (bppsInCreation.size() == 1) {
/* 426 */           String bppName = bppsInCreation.iterator().next();
/* 427 */           if (this.beanFactory.containsBeanDefinition(bppName) && beanName
/* 428 */             .equals(this.beanFactory.getBeanDefinition(bppName).getFactoryBeanName())) {
/* 429 */             logger.warn("Bean '" + beanName + "' of type [" + bean.getClass().getName() + "] is not eligible for getting processed by all BeanPostProcessors (for example: not eligible for auto-proxying). The currently created BeanPostProcessor " + String.valueOf(bppsInCreation) + " is declared through a non-static factory method on that class; consider declaring it as static instead.");
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 434 */             return bean;
/*     */           } 
/*     */         } 
/* 437 */         logger.warn("Bean '" + beanName + "' of type [" + bean.getClass().getName() + "] is not eligible for getting processed by all BeanPostProcessors (for example: not eligible for auto-proxying). Is this bean getting eagerly injected/applied to a currently created BeanPostProcessor " + String.valueOf(bppsInCreation) + "? Check the corresponding BeanPostProcessor declaration and its dependencies/advisors. If this bean does not have to be post-processed, declare it with ROLE_INFRASTRUCTURE.");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 445 */       return bean;
/*     */     }
/*     */     
/*     */     private boolean isInfrastructureBean(@Nullable String beanName) {
/* 449 */       if (beanName != null && this.beanFactory.containsBeanDefinition(beanName)) {
/* 450 */         BeanDefinition bd = this.beanFactory.getBeanDefinition(beanName);
/* 451 */         return (bd.getRole() == 2);
/*     */       } 
/* 453 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class MergedBeanDefinitionPostProcessorInvoker
/*     */   {
/*     */     private final DefaultListableBeanFactory beanFactory;
/*     */     
/*     */     private MergedBeanDefinitionPostProcessorInvoker(DefaultListableBeanFactory beanFactory) {
/* 463 */       this.beanFactory = beanFactory;
/*     */     }
/*     */     
/*     */     private void invokeMergedBeanDefinitionPostProcessors() {
/* 467 */       List<MergedBeanDefinitionPostProcessor> postProcessors = PostProcessorRegistrationDelegate.loadBeanPostProcessors((ConfigurableListableBeanFactory)this.beanFactory, MergedBeanDefinitionPostProcessor.class);
/*     */       
/* 469 */       for (String beanName : this.beanFactory.getBeanDefinitionNames()) {
/* 470 */         RootBeanDefinition bd = (RootBeanDefinition)this.beanFactory.getMergedBeanDefinition(beanName);
/* 471 */         Class<?> beanType = resolveBeanType((AbstractBeanDefinition)bd);
/* 472 */         postProcessRootBeanDefinition(postProcessors, beanName, beanType, bd);
/* 473 */         bd.markAsPostProcessed();
/*     */       } 
/* 475 */       PostProcessorRegistrationDelegate.registerBeanPostProcessors((ConfigurableListableBeanFactory)this.beanFactory, (List)postProcessors);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void postProcessRootBeanDefinition(List<MergedBeanDefinitionPostProcessor> postProcessors, String beanName, Class<?> beanType, RootBeanDefinition bd) {
/* 481 */       BeanDefinitionValueResolver valueResolver = new BeanDefinitionValueResolver((AbstractAutowireCapableBeanFactory)this.beanFactory, beanName, (BeanDefinition)bd);
/* 482 */       postProcessors.forEach(postProcessor -> postProcessor.postProcessMergedBeanDefinition(bd, beanType, beanName));
/* 483 */       for (PropertyValue propertyValue : bd.getPropertyValues().getPropertyValueList()) {
/* 484 */         postProcessValue(postProcessors, valueResolver, propertyValue.getValue());
/*     */       }
/* 486 */       for (ConstructorArgumentValues.ValueHolder valueHolder : bd.getConstructorArgumentValues().getIndexedArgumentValues().values()) {
/* 487 */         postProcessValue(postProcessors, valueResolver, valueHolder.getValue());
/*     */       }
/* 489 */       for (ConstructorArgumentValues.ValueHolder valueHolder : bd.getConstructorArgumentValues().getGenericArgumentValues()) {
/* 490 */         postProcessValue(postProcessors, valueResolver, valueHolder.getValue());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void postProcessValue(List<MergedBeanDefinitionPostProcessor> postProcessors, BeanDefinitionValueResolver valueResolver, @Nullable Object value) {
/* 496 */       if (value instanceof BeanDefinitionHolder) { BeanDefinitionHolder bdh = (BeanDefinitionHolder)value;
/* 497 */         BeanDefinition beanDefinition = bdh.getBeanDefinition(); if (beanDefinition instanceof AbstractBeanDefinition) { AbstractBeanDefinition innerBd = (AbstractBeanDefinition)beanDefinition;
/*     */           
/* 499 */           Class<?> innerBeanType = resolveBeanType(innerBd);
/* 500 */           resolveInnerBeanDefinition(valueResolver, (BeanDefinition)innerBd, (innerBeanName, innerBeanDefinition) -> postProcessRootBeanDefinition(postProcessors, innerBeanName, innerBeanType, innerBeanDefinition)); return; }
/*     */          }
/*     */       
/* 503 */       if (value instanceof AbstractBeanDefinition) { AbstractBeanDefinition innerBd = (AbstractBeanDefinition)value;
/* 504 */         Class<?> innerBeanType = resolveBeanType(innerBd);
/* 505 */         resolveInnerBeanDefinition(valueResolver, (BeanDefinition)innerBd, (innerBeanName, innerBeanDefinition) -> postProcessRootBeanDefinition(postProcessors, innerBeanName, innerBeanType, innerBeanDefinition));
/*     */          }
/*     */       
/* 508 */       else if (value instanceof TypedStringValue) { TypedStringValue typedStringValue = (TypedStringValue)value;
/* 509 */         resolveTypeStringValue(typedStringValue); }
/*     */     
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void resolveInnerBeanDefinition(BeanDefinitionValueResolver valueResolver, BeanDefinition innerBeanDefinition, BiConsumer<String, RootBeanDefinition> resolver) {
/* 516 */       valueResolver.resolveInnerBean(null, innerBeanDefinition, (name, rbd) -> {
/*     */             resolver.accept(name, rbd);
/*     */             return Void.class;
/*     */           });
/*     */     }
/*     */     
/*     */     private void resolveTypeStringValue(TypedStringValue typedStringValue) {
/*     */       try {
/* 524 */         typedStringValue.resolveTargetType(this.beanFactory.getBeanClassLoader());
/*     */       }
/* 526 */       catch (ClassNotFoundException classNotFoundException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Class<?> resolveBeanType(AbstractBeanDefinition bd) {
/* 532 */       if (!bd.hasBeanClass()) {
/*     */         try {
/* 534 */           bd.resolveBeanClass(this.beanFactory.getBeanClassLoader());
/*     */         }
/* 536 */         catch (ClassNotFoundException classNotFoundException) {}
/*     */       }
/*     */ 
/*     */       
/* 540 */       return bd.getResolvableType().toClass();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\PostProcessorRegistrationDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */