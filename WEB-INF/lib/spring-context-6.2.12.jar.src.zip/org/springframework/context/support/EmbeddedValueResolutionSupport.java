/*    */ package org.springframework.context.support;
/*    */ 
/*    */ import org.springframework.context.EmbeddedValueResolverAware;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.StringValueResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmbeddedValueResolutionSupport
/*    */   implements EmbeddedValueResolverAware
/*    */ {
/*    */   @Nullable
/*    */   private StringValueResolver embeddedValueResolver;
/*    */   
/*    */   public void setEmbeddedValueResolver(StringValueResolver resolver) {
/* 38 */     this.embeddedValueResolver = resolver;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   protected String resolveEmbeddedValue(String value) {
/* 49 */     return (this.embeddedValueResolver != null) ? this.embeddedValueResolver.resolveStringValue(value) : value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\EmbeddedValueResolutionSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */