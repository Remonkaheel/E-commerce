/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MessageHolder
/*     */ {
/*     */   private final String message;
/*     */   private final Locale locale;
/*     */   @Nullable
/*     */   private volatile MessageFormat cachedFormat;
/*     */   
/*     */   public MessageHolder(String message, Locale locale) {
/* 114 */     this.message = message;
/* 115 */     this.locale = locale;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/* 119 */     return this.message;
/*     */   }
/*     */   
/*     */   public MessageFormat getMessageFormat() {
/* 123 */     MessageFormat messageFormat = this.cachedFormat;
/* 124 */     if (messageFormat == null) {
/* 125 */       messageFormat = StaticMessageSource.this.createMessageFormat(this.message, this.locale);
/* 126 */       this.cachedFormat = messageFormat;
/*     */     } 
/* 128 */     return messageFormat;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 133 */     return this.message;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\StaticMessageSource$MessageHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */