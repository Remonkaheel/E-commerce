/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRefreshableApplicationContext
/*     */   extends AbstractApplicationContext
/*     */ {
/*     */   @Nullable
/*     */   private Boolean allowBeanDefinitionOverriding;
/*     */   @Nullable
/*     */   private Boolean allowCircularReferences;
/*     */   @Nullable
/*     */   private volatile DefaultListableBeanFactory beanFactory;
/*     */   
/*     */   public AbstractRefreshableApplicationContext() {}
/*     */   
/*     */   public AbstractRefreshableApplicationContext(@Nullable ApplicationContext parent) {
/*  89 */     super(parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowBeanDefinitionOverriding(boolean allowBeanDefinitionOverriding) {
/* 100 */     this.allowBeanDefinitionOverriding = Boolean.valueOf(allowBeanDefinitionOverriding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowCircularReferences(boolean allowCircularReferences) {
/* 111 */     this.allowCircularReferences = Boolean.valueOf(allowCircularReferences);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void refreshBeanFactory() throws BeansException {
/* 122 */     if (hasBeanFactory()) {
/* 123 */       destroyBeans();
/* 124 */       closeBeanFactory();
/*     */     } 
/*     */     try {
/* 127 */       DefaultListableBeanFactory beanFactory = createBeanFactory();
/* 128 */       beanFactory.setSerializationId(getId());
/* 129 */       beanFactory.setApplicationStartup(getApplicationStartup());
/* 130 */       customizeBeanFactory(beanFactory);
/* 131 */       loadBeanDefinitions(beanFactory);
/* 132 */       this.beanFactory = beanFactory;
/*     */     }
/* 134 */     catch (IOException ex) {
/* 135 */       throw new ApplicationContextException("I/O error parsing bean definition source for " + getDisplayName(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void cancelRefresh(Throwable ex) {
/* 141 */     DefaultListableBeanFactory beanFactory = this.beanFactory;
/* 142 */     if (beanFactory != null) {
/* 143 */       beanFactory.setSerializationId(null);
/*     */     }
/* 145 */     super.cancelRefresh(ex);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void closeBeanFactory() {
/* 150 */     DefaultListableBeanFactory beanFactory = this.beanFactory;
/* 151 */     if (beanFactory != null) {
/* 152 */       beanFactory.setSerializationId(null);
/* 153 */       this.beanFactory = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean hasBeanFactory() {
/* 162 */     return (this.beanFactory != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ConfigurableListableBeanFactory getBeanFactory() {
/* 167 */     DefaultListableBeanFactory beanFactory = this.beanFactory;
/* 168 */     if (beanFactory == null) {
/* 169 */       throw new IllegalStateException("BeanFactory not initialized or already closed - call 'refresh' before accessing beans via the ApplicationContext");
/*     */     }
/*     */     
/* 172 */     return (ConfigurableListableBeanFactory)beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void assertBeanFactoryActive() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultListableBeanFactory createBeanFactory() {
/* 198 */     return new DefaultListableBeanFactory(getInternalParentBeanFactory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void customizeBeanFactory(DefaultListableBeanFactory beanFactory) {
/* 216 */     if (this.allowBeanDefinitionOverriding != null) {
/* 217 */       beanFactory.setAllowBeanDefinitionOverriding(this.allowBeanDefinitionOverriding.booleanValue());
/*     */     }
/* 219 */     if (this.allowCircularReferences != null)
/* 220 */       beanFactory.setAllowCircularReferences(this.allowCircularReferences.booleanValue()); 
/*     */   }
/*     */   
/*     */   protected abstract void loadBeanDefinitions(DefaultListableBeanFactory paramDefaultListableBeanFactory) throws BeansException, IOException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\AbstractRefreshableApplicationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */