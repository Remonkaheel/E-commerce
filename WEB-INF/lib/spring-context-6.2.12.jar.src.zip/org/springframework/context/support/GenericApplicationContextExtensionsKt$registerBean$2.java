/*    */ package org.springframework.context.support;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 176, d1 = {"\000\f\n\002\b\003\n\002\020\000\n\002\b\002\020\000\032\n \002*\004\030\001H\001H\001\"\n\b\000\020\001\030\001*\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "T", "kotlin.jvm.PlatformType", "", "get", "()Ljava/lang/Object;"})
/*    */ @SourceDebugExtension({"SMAP\nGenericApplicationContextExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GenericApplicationContextExtensions.kt\norg/springframework/context/support/GenericApplicationContextExtensionsKt$registerBean$2\n*L\n1#1,80:1\n*E\n"})
/*    */ public final class GenericApplicationContextExtensionsKt$registerBean$2<T>
/*    */   implements Supplier
/*    */ {
/*    */   public GenericApplicationContextExtensionsKt$registerBean$2(Function1<ApplicationContext, T> $function, GenericApplicationContext $receiver) {}
/*    */   
/*    */   public final T get() {
/* 66 */     return (T)this.$function.invoke(this.$this_registerBean);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\GenericApplicationContextExtensionsKt$registerBean$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */