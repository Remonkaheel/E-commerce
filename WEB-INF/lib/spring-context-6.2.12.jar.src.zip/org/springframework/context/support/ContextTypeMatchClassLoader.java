/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.DecoratingClassLoader;
/*     */ import org.springframework.core.OverridingClassLoader;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ContextTypeMatchClassLoader
/*     */   extends DecoratingClassLoader
/*     */   implements SmartClassLoader
/*     */ {
/*     */   @Nullable
/*     */   private static final Method findLoadedClassMethod;
/*     */   
/*     */   static {
/*     */     Method method;
/*  46 */     ClassLoader.registerAsParallelCapable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  60 */       method = ClassLoader.class.getDeclaredMethod("findLoadedClass", new Class[] { String.class });
/*  61 */       ReflectionUtils.makeAccessible(method);
/*     */     }
/*  63 */     catch (Throwable ex) {
/*     */ 
/*     */       
/*  66 */       method = null;
/*  67 */       LogFactory.getLog(ContextTypeMatchClassLoader.class).debug("ClassLoader.findLoadedClass not accessible -> will always override requested class", ex);
/*     */     } 
/*     */     
/*  70 */     findLoadedClassMethod = method;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  75 */   private final Map<String, byte[]> bytesCache = (Map)new ConcurrentHashMap<>(256);
/*     */ 
/*     */   
/*     */   public ContextTypeMatchClassLoader(@Nullable ClassLoader parent) {
/*  79 */     super(parent);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> loadClass(String name) throws ClassNotFoundException {
/*  84 */     return (new ContextOverridingClassLoader(getParent())).loadClass(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClassReloadable(Class<?> clazz) {
/*  89 */     return clazz.getClassLoader() instanceof ContextOverridingClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> publicDefineClass(String name, byte[] b, @Nullable ProtectionDomain protectionDomain) {
/*  94 */     return defineClass(name, b, 0, b.length, protectionDomain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ContextOverridingClassLoader
/*     */     extends OverridingClassLoader
/*     */   {
/*     */     public ContextOverridingClassLoader(ClassLoader parent) {
/* 105 */       super(parent);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isEligibleForOverriding(String className) {
/* 110 */       if (isExcluded(className) || ContextTypeMatchClassLoader.this.isExcluded(className)) {
/* 111 */         return false;
/*     */       }
/* 113 */       if (ContextTypeMatchClassLoader.findLoadedClassMethod != null) {
/* 114 */         ClassLoader parent = getParent();
/* 115 */         while (parent != null) {
/* 116 */           if (ReflectionUtils.invokeMethod(ContextTypeMatchClassLoader.findLoadedClassMethod, parent, new Object[] { className }) != null) {
/* 117 */             return false;
/*     */           }
/* 119 */           parent = parent.getParent();
/*     */         } 
/*     */       } 
/* 122 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected Class<?> loadClassForOverriding(String name) throws ClassNotFoundException {
/* 128 */       byte[] bytes = ContextTypeMatchClassLoader.this.bytesCache.get(name);
/* 129 */       if (bytes == null) {
/* 130 */         bytes = loadBytesForClass(name);
/* 131 */         if (bytes != null) {
/* 132 */           ContextTypeMatchClassLoader.this.bytesCache.put(name, bytes);
/*     */         } else {
/*     */           
/* 135 */           return null;
/*     */         } 
/*     */       } 
/* 138 */       return defineClass(name, bytes, 0, bytes.length);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\ContextTypeMatchClassLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */