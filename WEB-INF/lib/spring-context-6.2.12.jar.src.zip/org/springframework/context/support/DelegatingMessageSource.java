/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.springframework.context.HierarchicalMessageSource;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingMessageSource
/*     */   extends MessageSourceSupport
/*     */   implements HierarchicalMessageSource
/*     */ {
/*     */   @Nullable
/*     */   private MessageSource parentMessageSource;
/*     */   
/*     */   public void setParentMessageSource(@Nullable MessageSource parent) {
/*  46 */     this.parentMessageSource = parent;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MessageSource getParentMessageSource() {
/*  52 */     return this.parentMessageSource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getMessage(String code, @Nullable Object[] args, @Nullable String defaultMessage, @Nullable Locale locale) {
/*  59 */     if (this.parentMessageSource != null) {
/*  60 */       return this.parentMessageSource.getMessage(code, args, defaultMessage, locale);
/*     */     }
/*  62 */     if (defaultMessage != null) {
/*  63 */       return renderDefaultMessage(defaultMessage, args, locale);
/*     */     }
/*     */     
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(String code, @Nullable Object[] args, @Nullable Locale locale) throws NoSuchMessageException {
/*  72 */     if (this.parentMessageSource != null) {
/*  73 */       return this.parentMessageSource.getMessage(code, args, locale);
/*     */     }
/*     */     
/*  76 */     if (locale == null) {
/*  77 */       throw new NoSuchMessageException(code);
/*     */     }
/*     */     
/*  80 */     throw new NoSuchMessageException(code, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(MessageSourceResolvable resolvable, @Nullable Locale locale) throws NoSuchMessageException {
/*  87 */     if (this.parentMessageSource != null) {
/*  88 */       return this.parentMessageSource.getMessage(resolvable, locale);
/*     */     }
/*     */     
/*  91 */     if (resolvable.getDefaultMessage() != null) {
/*  92 */       return renderDefaultMessage(resolvable.getDefaultMessage(), resolvable.getArguments(), locale);
/*     */     }
/*  94 */     String[] codes = resolvable.getCodes();
/*  95 */     String code = (codes != null && codes.length > 0) ? codes[0] : "";
/*  96 */     if (locale == null) {
/*  97 */       throw new NoSuchMessageException(code);
/*     */     }
/*     */     
/* 100 */     throw new NoSuchMessageException(code, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 108 */     return (this.parentMessageSource != null) ? this.parentMessageSource.toString() : "Empty MessageSource";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\DelegatingMessageSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */