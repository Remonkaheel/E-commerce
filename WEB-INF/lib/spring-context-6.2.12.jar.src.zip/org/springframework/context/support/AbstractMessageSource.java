/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import org.springframework.context.HierarchicalMessageSource;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMessageSource
/*     */   extends MessageSourceSupport
/*     */   implements HierarchicalMessageSource
/*     */ {
/*     */   @Nullable
/*     */   private MessageSource parentMessageSource;
/*     */   @Nullable
/*     */   private Properties commonMessages;
/*     */   private boolean useCodeAsDefaultMessage = false;
/*     */   
/*     */   public void setParentMessageSource(@Nullable MessageSource parent) {
/*  78 */     this.parentMessageSource = parent;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MessageSource getParentMessageSource() {
/*  84 */     return this.parentMessageSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommonMessages(@Nullable Properties commonMessages) {
/*  94 */     this.commonMessages = commonMessages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Properties getCommonMessages() {
/* 102 */     return this.commonMessages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseCodeAsDefaultMessage(boolean useCodeAsDefaultMessage) {
/* 123 */     this.useCodeAsDefaultMessage = useCodeAsDefaultMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isUseCodeAsDefaultMessage() {
/* 135 */     return this.useCodeAsDefaultMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final String getMessage(String code, @Nullable Object[] args, @Nullable String defaultMessage, @Nullable Locale locale) {
/* 142 */     String msg = getMessageInternal(code, args, locale);
/* 143 */     if (msg != null) {
/* 144 */       return msg;
/*     */     }
/* 146 */     if (defaultMessage == null) {
/* 147 */       return getDefaultMessage(code);
/*     */     }
/* 149 */     return renderDefaultMessage(defaultMessage, args, locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getMessage(String code, @Nullable Object[] args, @Nullable Locale locale) throws NoSuchMessageException {
/* 154 */     String msg = getMessageInternal(code, args, locale);
/* 155 */     if (msg != null) {
/* 156 */       return msg;
/*     */     }
/* 158 */     String fallback = getDefaultMessage(code);
/* 159 */     if (fallback != null) {
/* 160 */       return fallback;
/*     */     }
/* 162 */     if (locale == null) {
/* 163 */       throw new NoSuchMessageException(code);
/*     */     }
/*     */     
/* 166 */     throw new NoSuchMessageException(code, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getMessage(MessageSourceResolvable resolvable, @Nullable Locale locale) throws NoSuchMessageException {
/* 172 */     String[] codes = resolvable.getCodes();
/* 173 */     if (codes != null) {
/* 174 */       for (String str1 : codes) {
/* 175 */         String message = getMessageInternal(str1, resolvable.getArguments(), locale);
/* 176 */         if (message != null) {
/* 177 */           return message;
/*     */         }
/*     */       } 
/*     */     }
/* 181 */     String defaultMessage = getDefaultMessage(resolvable, locale);
/* 182 */     if (defaultMessage != null) {
/* 183 */       return defaultMessage;
/*     */     }
/* 185 */     String code = !ObjectUtils.isEmpty((Object[])codes) ? codes[codes.length - 1] : "";
/* 186 */     if (locale == null) {
/* 187 */       throw new NoSuchMessageException(code);
/*     */     }
/*     */     
/* 190 */     throw new NoSuchMessageException(code, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getMessageInternal(@Nullable String code, @Nullable Object[] args, @Nullable Locale locale) {
/* 211 */     if (code == null) {
/* 212 */       return null;
/*     */     }
/* 214 */     if (locale == null) {
/* 215 */       locale = Locale.getDefault();
/*     */     }
/* 217 */     Object[] argsToUse = args;
/*     */     
/* 219 */     if (!isAlwaysUseMessageFormat() && ObjectUtils.isEmpty(args)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 224 */       String message = resolveCodeWithoutArguments(code, locale);
/* 225 */       if (message != null) {
/* 226 */         return message;
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 234 */       argsToUse = resolveArguments(args, locale);
/*     */       
/* 236 */       MessageFormat messageFormat = resolveCode(code, locale);
/* 237 */       if (messageFormat != null) {
/* 238 */         synchronized (messageFormat) {
/* 239 */           return messageFormat.format(argsToUse);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 245 */     Properties commonMessages = getCommonMessages();
/* 246 */     if (commonMessages != null) {
/* 247 */       String commonMessage = commonMessages.getProperty(code);
/* 248 */       if (commonMessage != null) {
/* 249 */         return formatMessage(commonMessage, args, locale);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 254 */     return getMessageFromParent(code, argsToUse, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getMessageFromParent(String code, @Nullable Object[] args, Locale locale) {
/* 268 */     MessageSource parent = getParentMessageSource();
/* 269 */     if (parent != null) {
/* 270 */       if (parent instanceof AbstractMessageSource) { AbstractMessageSource abstractMessageSource = (AbstractMessageSource)parent;
/*     */ 
/*     */         
/* 273 */         return abstractMessageSource.getMessageInternal(code, args, locale); }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 278 */       return parent.getMessage(code, args, null, locale);
/*     */     } 
/*     */ 
/*     */     
/* 282 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getDefaultMessage(MessageSourceResolvable resolvable, @Nullable Locale locale) {
/* 299 */     String defaultMessage = resolvable.getDefaultMessage();
/* 300 */     String[] codes = resolvable.getCodes();
/* 301 */     if (defaultMessage != null) {
/* 302 */       if (resolvable instanceof DefaultMessageSourceResolvable) { DefaultMessageSourceResolvable defaultMessageSourceResolvable = (DefaultMessageSourceResolvable)resolvable;
/* 303 */         if (!defaultMessageSourceResolvable.shouldRenderDefaultMessage())
/*     */         {
/*     */           
/* 306 */           return defaultMessage; }  }
/*     */       
/* 308 */       if (!ObjectUtils.isEmpty((Object[])codes) && defaultMessage.equals(codes[0]))
/*     */       {
/* 310 */         return defaultMessage;
/*     */       }
/* 312 */       return renderDefaultMessage(defaultMessage, resolvable.getArguments(), locale);
/*     */     } 
/* 314 */     return !ObjectUtils.isEmpty((Object[])codes) ? getDefaultMessage(codes[0]) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getDefaultMessage(String code) {
/* 329 */     if (isUseCodeAsDefaultMessage()) {
/* 330 */       return code;
/*     */     }
/* 332 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object[] resolveArguments(@Nullable Object[] args, @Nullable Locale locale) {
/* 346 */     if (ObjectUtils.isEmpty(args)) {
/* 347 */       return super.resolveArguments(args, locale);
/*     */     }
/* 349 */     List<Object> resolvedArgs = new ArrayList(args.length);
/* 350 */     for (Object arg : args) {
/* 351 */       if (arg instanceof MessageSourceResolvable) { MessageSourceResolvable messageSourceResolvable = (MessageSourceResolvable)arg;
/* 352 */         resolvedArgs.add(getMessage(messageSourceResolvable, locale)); }
/*     */       else
/*     */       
/* 355 */       { resolvedArgs.add(arg); }
/*     */     
/*     */     } 
/* 358 */     return resolvedArgs.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale) {
/* 380 */     MessageFormat messageFormat = resolveCode(code, locale);
/* 381 */     if (messageFormat != null) {
/* 382 */       synchronized (messageFormat) {
/* 383 */         return messageFormat.format(new Object[0]);
/*     */       } 
/*     */     }
/* 386 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected abstract MessageFormat resolveCode(String paramString, Locale paramLocale);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\support\AbstractMessageSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */