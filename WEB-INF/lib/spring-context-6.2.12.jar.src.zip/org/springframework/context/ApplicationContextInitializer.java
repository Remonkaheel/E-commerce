package org.springframework.context;

@FunctionalInterface
public interface ApplicationContextInitializer<C extends ConfigurableApplicationContext> {
  void initialize(C paramC);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\ApplicationContextInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */