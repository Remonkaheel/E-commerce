/*     */ package org.springframework.context.index;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CandidateComponentsIndex
/*     */ {
/*  51 */   private static final AntPathMatcher pathMatcher = new AntPathMatcher(".");
/*     */   
/*     */   private final MultiValueMap<String, Entry> index;
/*     */ 
/*     */   
/*     */   CandidateComponentsIndex(List<Properties> content) {
/*  57 */     this.index = parseIndex(content);
/*     */   }
/*     */   
/*     */   private static MultiValueMap<String, Entry> parseIndex(List<Properties> content) {
/*  61 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/*  62 */     for (Iterator<Properties> iterator = content.iterator(); iterator.hasNext(); ) { Properties entry = iterator.next();
/*  63 */       entry.forEach((type, values) -> {
/*     */             String[] stereotypes = ((String)values).split(",");
/*     */             for (String stereotype : stereotypes) {
/*     */               index.add(stereotype, new Entry((String)type));
/*     */             }
/*     */           }); }
/*     */     
/*  70 */     return (MultiValueMap<String, Entry>)linkedMultiValueMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getCandidateTypes(String basePackage, String stereotype) {
/*  82 */     List<Entry> candidates = (List<Entry>)this.index.get(stereotype);
/*  83 */     if (candidates != null) {
/*  84 */       return (Set<String>)candidates.stream()
/*  85 */         .filter(t -> t.match(basePackage))
/*  86 */         .map(t -> t.type)
/*  87 */         .collect(Collectors.toSet());
/*     */     }
/*  89 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Entry
/*     */   {
/*     */     final String type;
/*     */     
/*     */     private final String packageName;
/*     */     
/*     */     Entry(String type) {
/* 100 */       this.type = type;
/* 101 */       this.packageName = ClassUtils.getPackageName(type);
/*     */     }
/*     */     
/*     */     public boolean match(String basePackage) {
/* 105 */       if (CandidateComponentsIndex.pathMatcher.isPattern(basePackage)) {
/* 106 */         return CandidateComponentsIndex.pathMatcher.match(basePackage, this.packageName);
/*     */       }
/*     */       
/* 109 */       return this.type.startsWith(basePackage);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\index\CandidateComponentsIndex.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */