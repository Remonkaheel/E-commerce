package org.springframework.context.event;

import java.util.function.Predicate;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.ResolvableType;
import org.springframework.lang.Nullable;

public interface ApplicationEventMulticaster {
  void addApplicationListener(ApplicationListener<?> paramApplicationListener);
  
  void addApplicationListenerBean(String paramString);
  
  void removeApplicationListener(ApplicationListener<?> paramApplicationListener);
  
  void removeApplicationListenerBean(String paramString);
  
  void removeApplicationListeners(Predicate<ApplicationListener<?>> paramPredicate);
  
  void removeApplicationListenerBeans(Predicate<String> paramPredicate);
  
  void removeAllListeners();
  
  void multicastEvent(ApplicationEvent paramApplicationEvent);
  
  void multicastEvent(ApplicationEvent paramApplicationEvent, @Nullable ResolvableType paramResolvableType);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\event\ApplicationEventMulticaster.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */