package org.springframework.context.event;

import java.lang.reflect.Method;
import org.springframework.context.ApplicationListener;

public interface EventListenerFactory {
  boolean supportsMethod(Method paramMethod);
  
  ApplicationListener<?> createApplicationListener(String paramString, Class<?> paramClass, Method paramMethod);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\event\EventListenerFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */