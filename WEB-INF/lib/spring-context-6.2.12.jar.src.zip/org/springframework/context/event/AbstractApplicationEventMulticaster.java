/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.aop.framework.AopProxyUtils;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractApplicationEventMulticaster
/*     */   implements ApplicationEventMulticaster, BeanClassLoaderAware, BeanFactoryAware
/*     */ {
/*  69 */   private final DefaultListenerRetriever defaultRetriever = new DefaultListenerRetriever();
/*     */   
/*  71 */   final Map<ListenerCacheKey, CachedListenerRetriever> retrieverCache = new ConcurrentHashMap<>(64);
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ClassLoader beanClassLoader;
/*     */   
/*     */   @Nullable
/*     */   private ConfigurableBeanFactory beanFactory;
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/*  82 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/*     */     ConfigurableBeanFactory cbf;
/*  87 */     if (beanFactory instanceof ConfigurableBeanFactory) { cbf = (ConfigurableBeanFactory)beanFactory; }
/*  88 */     else { throw new IllegalStateException("Not running in a ConfigurableBeanFactory: " + String.valueOf(beanFactory)); }
/*     */     
/*  90 */     this.beanFactory = cbf;
/*  91 */     if (this.beanClassLoader == null) {
/*  92 */       this.beanClassLoader = this.beanFactory.getBeanClassLoader();
/*     */     }
/*     */   }
/*     */   
/*     */   private ConfigurableBeanFactory getBeanFactory() {
/*  97 */     if (this.beanFactory == null) {
/*  98 */       throw new IllegalStateException("ApplicationEventMulticaster cannot retrieve listener beans because it is not associated with a BeanFactory");
/*     */     }
/*     */     
/* 101 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addApplicationListener(ApplicationListener<?> listener) {
/* 107 */     synchronized (this.defaultRetriever) {
/*     */ 
/*     */       
/* 110 */       Object singletonTarget = AopProxyUtils.getSingletonTarget(listener);
/* 111 */       if (singletonTarget instanceof ApplicationListener) {
/* 112 */         this.defaultRetriever.applicationListeners.remove(singletonTarget);
/*     */       }
/* 114 */       this.defaultRetriever.applicationListeners.add(listener);
/* 115 */       this.retrieverCache.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addApplicationListenerBean(String listenerBeanName) {
/* 121 */     synchronized (this.defaultRetriever) {
/* 122 */       this.defaultRetriever.applicationListenerBeans.add(listenerBeanName);
/* 123 */       this.retrieverCache.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeApplicationListener(ApplicationListener<?> listener) {
/* 129 */     synchronized (this.defaultRetriever) {
/* 130 */       this.defaultRetriever.applicationListeners.remove(listener);
/* 131 */       this.retrieverCache.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeApplicationListenerBean(String listenerBeanName) {
/* 137 */     synchronized (this.defaultRetriever) {
/* 138 */       this.defaultRetriever.applicationListenerBeans.remove(listenerBeanName);
/* 139 */       this.retrieverCache.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeApplicationListeners(Predicate<ApplicationListener<?>> predicate) {
/* 145 */     synchronized (this.defaultRetriever) {
/* 146 */       this.defaultRetriever.applicationListeners.removeIf(predicate);
/* 147 */       this.retrieverCache.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeApplicationListenerBeans(Predicate<String> predicate) {
/* 153 */     synchronized (this.defaultRetriever) {
/* 154 */       this.defaultRetriever.applicationListenerBeans.removeIf(predicate);
/* 155 */       this.retrieverCache.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAllListeners() {
/* 161 */     synchronized (this.defaultRetriever) {
/* 162 */       this.defaultRetriever.applicationListeners.clear();
/* 163 */       this.defaultRetriever.applicationListenerBeans.clear();
/* 164 */       this.retrieverCache.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<ApplicationListener<?>> getApplicationListeners() {
/* 175 */     synchronized (this.defaultRetriever) {
/* 176 */       return this.defaultRetriever.getApplicationListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<ApplicationListener<?>> getApplicationListeners(ApplicationEvent event, ResolvableType eventType) {
/* 192 */     Object source = event.getSource();
/* 193 */     Class<?> sourceType = (source != null) ? source.getClass() : null;
/* 194 */     ListenerCacheKey cacheKey = new ListenerCacheKey(eventType, sourceType);
/*     */ 
/*     */     
/* 197 */     CachedListenerRetriever newRetriever = null;
/*     */ 
/*     */     
/* 200 */     CachedListenerRetriever existingRetriever = this.retrieverCache.get(cacheKey);
/* 201 */     if (existingRetriever == null)
/*     */     {
/* 203 */       if (this.beanClassLoader == null || (
/* 204 */         ClassUtils.isCacheSafe(event.getClass(), this.beanClassLoader) && (sourceType == null || 
/* 205 */         ClassUtils.isCacheSafe(sourceType, this.beanClassLoader)))) {
/* 206 */         newRetriever = new CachedListenerRetriever();
/* 207 */         existingRetriever = this.retrieverCache.putIfAbsent(cacheKey, newRetriever);
/* 208 */         if (existingRetriever != null) {
/* 209 */           newRetriever = null;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 214 */     if (existingRetriever != null) {
/* 215 */       Collection<ApplicationListener<?>> result = existingRetriever.getApplicationListeners();
/* 216 */       if (result != null) {
/* 217 */         return result;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 223 */     return retrieveApplicationListeners(eventType, sourceType, newRetriever);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<ApplicationListener<?>> retrieveApplicationListeners(ResolvableType eventType, @Nullable Class<?> sourceType, @Nullable CachedListenerRetriever retriever) {
/*     */     Set<ApplicationListener<?>> listeners;
/*     */     Set<String> listenerBeans;
/* 237 */     List<ApplicationListener<?>> allListeners = new ArrayList<>();
/* 238 */     Set<ApplicationListener<?>> filteredListeners = (retriever != null) ? new LinkedHashSet<>() : null;
/* 239 */     Set<String> filteredListenerBeans = (retriever != null) ? new LinkedHashSet<>() : null;
/*     */ 
/*     */ 
/*     */     
/* 243 */     synchronized (this.defaultRetriever) {
/* 244 */       listeners = new LinkedHashSet<>(this.defaultRetriever.applicationListeners);
/* 245 */       listenerBeans = new LinkedHashSet<>(this.defaultRetriever.applicationListenerBeans);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 250 */     for (ApplicationListener<?> listener : listeners) {
/* 251 */       if (supportsEvent(listener, eventType, sourceType)) {
/* 252 */         if (retriever != null) {
/* 253 */           filteredListeners.add(listener);
/*     */         }
/* 255 */         allListeners.add(listener);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 261 */     if (!listenerBeans.isEmpty()) {
/* 262 */       ConfigurableBeanFactory beanFactory = getBeanFactory();
/* 263 */       for (String listenerBeanName : listenerBeans) {
/*     */         try {
/* 265 */           if (supportsEvent(beanFactory, listenerBeanName, eventType)) {
/*     */             
/* 267 */             ApplicationListener<?> applicationListener1 = (ApplicationListener)beanFactory.getBean(listenerBeanName, ApplicationListener.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 274 */             ApplicationListener<?> unwrappedListener = (ApplicationListener)AopProxyUtils.getSingletonTarget(applicationListener1);
/* 275 */             if (applicationListener1 != unwrappedListener) {
/* 276 */               if (filteredListeners != null && filteredListeners.contains(unwrappedListener)) {
/* 277 */                 filteredListeners.remove(unwrappedListener);
/* 278 */                 filteredListeners.add(applicationListener1);
/*     */               } 
/* 280 */               if (allListeners.contains(unwrappedListener)) {
/* 281 */                 allListeners.remove(unwrappedListener);
/* 282 */                 allListeners.add(applicationListener1);
/*     */               } 
/*     */             } 
/*     */             
/* 286 */             if (!allListeners.contains(applicationListener1) && supportsEvent(applicationListener1, eventType, sourceType)) {
/* 287 */               if (retriever != null) {
/* 288 */                 if (beanFactory.isSingleton(listenerBeanName)) {
/* 289 */                   filteredListeners.add(applicationListener1);
/*     */                 } else {
/*     */                   
/* 292 */                   filteredListenerBeans.add(listenerBeanName);
/*     */                 } 
/*     */               }
/* 295 */               allListeners.add(applicationListener1);
/*     */             } 
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 302 */           Object listener = beanFactory.getSingleton(listenerBeanName);
/* 303 */           if (retriever != null) {
/* 304 */             filteredListeners.remove(listener);
/*     */           }
/* 306 */           allListeners.remove(listener);
/*     */         
/*     */         }
/* 309 */         catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 316 */     AnnotationAwareOrderComparator.sort(allListeners);
/* 317 */     if (retriever != null) {
/* 318 */       if (CollectionUtils.isEmpty(filteredListenerBeans)) {
/* 319 */         retriever.applicationListeners = new LinkedHashSet<>(allListeners);
/* 320 */         retriever.applicationListenerBeans = filteredListenerBeans;
/*     */       } else {
/*     */         
/* 323 */         retriever.applicationListeners = filteredListeners;
/* 324 */         retriever.applicationListenerBeans = filteredListenerBeans;
/*     */       } 
/*     */     }
/* 327 */     return allListeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean supportsEvent(ConfigurableBeanFactory beanFactory, String listenerBeanName, ResolvableType eventType) {
/* 347 */     Class<?> listenerType = beanFactory.getType(listenerBeanName);
/* 348 */     if (listenerType == null || GenericApplicationListener.class.isAssignableFrom(listenerType) || SmartApplicationListener.class
/* 349 */       .isAssignableFrom(listenerType)) {
/* 350 */       return true;
/*     */     }
/* 352 */     if (!supportsEvent(listenerType, eventType)) {
/* 353 */       return false;
/*     */     }
/*     */     try {
/* 356 */       BeanDefinition bd = beanFactory.getMergedBeanDefinition(listenerBeanName);
/* 357 */       ResolvableType genericEventType = bd.getResolvableType().as(ApplicationListener.class).getGeneric(new int[0]);
/* 358 */       return (genericEventType == ResolvableType.NONE || genericEventType.isAssignableFrom(eventType));
/*     */     }
/* 360 */     catch (NoSuchBeanDefinitionException ex) {
/*     */       
/* 362 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supportsEvent(Class<?> listenerType, ResolvableType eventType) {
/* 378 */     ResolvableType declaredEventType = GenericApplicationListenerAdapter.resolveDeclaredEventType(listenerType);
/* 379 */     return (declaredEventType == null || declaredEventType.isAssignableFrom(eventType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supportsEvent(ApplicationListener<?> listener, ResolvableType eventType, @Nullable Class<?> sourceType) {
/* 397 */     GenericApplicationListener gal = (GenericApplicationListener)listener;
/* 398 */     GenericApplicationListener smartListener = (listener instanceof GenericApplicationListener) ? gal : new GenericApplicationListenerAdapter(listener);
/* 399 */     return (smartListener.supportsEventType(eventType) && smartListener.supportsSourceType(sourceType));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ListenerCacheKey
/*     */     implements Comparable<ListenerCacheKey>
/*     */   {
/*     */     private final ResolvableType eventType;
/*     */     
/*     */     @Nullable
/*     */     private final Class<?> sourceType;
/*     */ 
/*     */     
/*     */     public ListenerCacheKey(ResolvableType eventType, @Nullable Class<?> sourceType) {
/* 414 */       Assert.notNull(eventType, "Event type must not be null");
/* 415 */       this.eventType = eventType;
/* 416 */       this.sourceType = sourceType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 421 */       if (this != other) { if (other instanceof ListenerCacheKey) { ListenerCacheKey that = (ListenerCacheKey)other; if (this.eventType
/* 422 */             .equals(that.eventType) && 
/* 423 */             ObjectUtils.nullSafeEquals(this.sourceType, that.sourceType)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 428 */       return Objects.hash(new Object[] { this.eventType, this.sourceType });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 433 */       return "ListenerCacheKey [eventType = " + String.valueOf(this.eventType) + ", sourceType = " + String.valueOf(this.sourceType) + "]";
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(ListenerCacheKey other) {
/* 438 */       int result = this.eventType.toString().compareTo(other.eventType.toString());
/* 439 */       if (result == 0) {
/* 440 */         if (this.sourceType == null) {
/* 441 */           return (other.sourceType == null) ? 0 : -1;
/*     */         }
/* 443 */         if (other.sourceType == null) {
/* 444 */           return 1;
/*     */         }
/* 446 */         result = this.sourceType.getName().compareTo(other.sourceType.getName());
/*     */       } 
/* 448 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class CachedListenerRetriever
/*     */   {
/*     */     @Nullable
/*     */     public volatile Set<ApplicationListener<?>> applicationListeners;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public volatile Set<String> applicationListenerBeans;
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Collection<ApplicationListener<?>> getApplicationListeners() {
/* 468 */       Set<ApplicationListener<?>> applicationListeners = this.applicationListeners;
/* 469 */       Set<String> applicationListenerBeans = this.applicationListenerBeans;
/* 470 */       if (applicationListeners == null || applicationListenerBeans == null)
/*     */       {
/* 472 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 476 */       List<ApplicationListener<?>> allListeners = new ArrayList<>(applicationListeners.size() + applicationListenerBeans.size());
/* 477 */       allListeners.addAll(applicationListeners);
/* 478 */       if (!applicationListenerBeans.isEmpty()) {
/* 479 */         ConfigurableBeanFactory configurableBeanFactory = AbstractApplicationEventMulticaster.this.getBeanFactory();
/* 480 */         for (String listenerBeanName : applicationListenerBeans) {
/*     */           try {
/* 482 */             allListeners.add((ApplicationListener)configurableBeanFactory.getBean(listenerBeanName, ApplicationListener.class));
/*     */           }
/* 484 */           catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 490 */       if (!applicationListenerBeans.isEmpty()) {
/* 491 */         AnnotationAwareOrderComparator.sort(allListeners);
/*     */       }
/* 493 */       return allListeners;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class DefaultListenerRetriever
/*     */   {
/* 503 */     public final Set<ApplicationListener<?>> applicationListeners = new LinkedHashSet<>();
/*     */     
/* 505 */     public final Set<String> applicationListenerBeans = new LinkedHashSet<>();
/*     */ 
/*     */     
/*     */     public Collection<ApplicationListener<?>> getApplicationListeners() {
/* 509 */       List<ApplicationListener<?>> allListeners = new ArrayList<>(this.applicationListeners.size() + this.applicationListenerBeans.size());
/* 510 */       allListeners.addAll(this.applicationListeners);
/* 511 */       if (!this.applicationListenerBeans.isEmpty()) {
/* 512 */         ConfigurableBeanFactory configurableBeanFactory = AbstractApplicationEventMulticaster.this.getBeanFactory();
/* 513 */         for (String listenerBeanName : this.applicationListenerBeans) {
/*     */           
/*     */           try {
/* 516 */             ApplicationListener<?> listener = (ApplicationListener)configurableBeanFactory.getBean(listenerBeanName, ApplicationListener.class);
/* 517 */             if (!allListeners.contains(listener)) {
/* 518 */               allListeners.add(listener);
/*     */             }
/*     */           }
/* 521 */           catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 527 */       AnnotationAwareOrderComparator.sort(allListeners);
/* 528 */       return allListeners;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\event\AbstractApplicationEventMulticaster.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */