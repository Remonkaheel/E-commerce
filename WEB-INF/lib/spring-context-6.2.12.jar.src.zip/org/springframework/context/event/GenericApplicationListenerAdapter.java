/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericApplicationListenerAdapter
/*     */   implements GenericApplicationListener
/*     */ {
/*  41 */   private static final Map<Class<?>, ResolvableType> eventTypeCache = (Map<Class<?>, ResolvableType>)new ConcurrentReferenceHashMap();
/*     */ 
/*     */ 
/*     */   
/*     */   private final ApplicationListener<ApplicationEvent> delegate;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final ResolvableType declaredEventType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericApplicationListenerAdapter(ApplicationListener<?> delegate) {
/*  56 */     Assert.notNull(delegate, "Delegate listener must not be null");
/*  57 */     this.delegate = (ApplicationListener)delegate;
/*  58 */     this.declaredEventType = resolveDeclaredEventType(this.delegate);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event) {
/*  64 */     this.delegate.onApplicationEvent(event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsEventType(ResolvableType eventType) {
/*  70 */     ApplicationListener<ApplicationEvent> applicationListener = this.delegate; if (applicationListener instanceof GenericApplicationListener) { GenericApplicationListener gal = (GenericApplicationListener)applicationListener;
/*  71 */       return gal.supportsEventType(eventType); }
/*     */     
/*  73 */     applicationListener = this.delegate; if (applicationListener instanceof SmartApplicationListener) { SmartApplicationListener sal = (SmartApplicationListener)applicationListener;
/*  74 */       Class<? extends ApplicationEvent> eventClass = eventType.resolve();
/*  75 */       return (eventClass != null && sal.supportsEventType(eventClass)); }
/*     */ 
/*     */     
/*  78 */     return (this.declaredEventType == null || this.declaredEventType.isAssignableFrom(eventType));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsSourceType(@Nullable Class<?> sourceType) {
/*  84 */     ApplicationListener<ApplicationEvent> applicationListener = this.delegate; if (applicationListener instanceof SmartApplicationListener) { SmartApplicationListener sal = (SmartApplicationListener)applicationListener; if (sal.supportsSourceType(sourceType)); return false; }
/*     */   
/*     */   }
/*     */   
/*     */   public int getOrder() {
/*  89 */     ApplicationListener<ApplicationEvent> applicationListener = this.delegate; Ordered ordered = (Ordered)applicationListener; return (applicationListener instanceof Ordered) ? ordered.getOrder() : Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getListenerId() {
/*  94 */     ApplicationListener<ApplicationEvent> applicationListener = this.delegate; SmartApplicationListener sal = (SmartApplicationListener)applicationListener; return (applicationListener instanceof SmartApplicationListener) ? sal.getListenerId() : "";
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static ResolvableType resolveDeclaredEventType(ApplicationListener<ApplicationEvent> listener) {
/* 100 */     ResolvableType declaredEventType = resolveDeclaredEventType(listener.getClass());
/* 101 */     if (declaredEventType == null || declaredEventType.isAssignableFrom(ApplicationEvent.class)) {
/* 102 */       Class<?> targetClass = AopUtils.getTargetClass(listener);
/* 103 */       if (targetClass != listener.getClass()) {
/* 104 */         declaredEventType = resolveDeclaredEventType(targetClass);
/*     */       }
/*     */     } 
/* 107 */     return declaredEventType;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   static ResolvableType resolveDeclaredEventType(Class<?> listenerType) {
/* 112 */     ResolvableType eventType = eventTypeCache.get(listenerType);
/* 113 */     if (eventType == null) {
/* 114 */       eventType = ResolvableType.forClass(listenerType).as(ApplicationListener.class).getGeneric(new int[0]);
/* 115 */       eventTypeCache.put(listenerType, eventType);
/*     */     } 
/* 117 */     return (eventType != ResolvableType.NONE) ? eventType : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\event\GenericApplicationListenerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */