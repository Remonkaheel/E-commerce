/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SourceFilteringListener
/*     */   implements GenericApplicationListener
/*     */ {
/*     */   private final Object source;
/*     */   @Nullable
/*     */   private GenericApplicationListener delegate;
/*     */   
/*     */   public SourceFilteringListener(Object source, ApplicationListener<?> delegate) {
/*  53 */     this.source = source;
/*  54 */     GenericApplicationListener gal = (GenericApplicationListener)delegate; this
/*  55 */       .delegate = (delegate instanceof GenericApplicationListener) ? gal : new GenericApplicationListenerAdapter(delegate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SourceFilteringListener(Object source) {
/*  66 */     this.source = source;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event) {
/*  72 */     if (event.getSource() == this.source) {
/*  73 */       onApplicationEventInternal(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsEventType(ResolvableType eventType) {
/*  79 */     return (this.delegate == null || this.delegate.supportsEventType(eventType));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsSourceType(@Nullable Class<?> sourceType) {
/*  84 */     return (sourceType != null && sourceType.isInstance(this.source));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  89 */     return (this.delegate != null) ? this.delegate.getOrder() : Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getListenerId() {
/*  94 */     return (this.delegate != null) ? this.delegate.getListenerId() : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onApplicationEventInternal(ApplicationEvent event) {
/* 105 */     if (this.delegate == null) {
/* 106 */       throw new IllegalStateException("Must specify a delegate object or override the onApplicationEventInternal method");
/*     */     }
/*     */     
/* 109 */     this.delegate.onApplicationEvent(event);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\event\SourceFilteringListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */