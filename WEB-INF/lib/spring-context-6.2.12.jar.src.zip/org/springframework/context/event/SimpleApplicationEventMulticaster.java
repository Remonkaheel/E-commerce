/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ErrorHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleApplicationEventMulticaster
/*     */   extends AbstractApplicationEventMulticaster
/*     */ {
/*     */   @Nullable
/*     */   private Executor taskExecutor;
/*     */   @Nullable
/*     */   private ErrorHandler errorHandler;
/*     */   @Nullable
/*     */   private volatile Log lazyLogger;
/*     */   
/*     */   public SimpleApplicationEventMulticaster() {}
/*     */   
/*     */   public SimpleApplicationEventMulticaster(BeanFactory beanFactory) {
/*  74 */     setBeanFactory(beanFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTaskExecutor(@Nullable Executor taskExecutor) {
/*  96 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Executor getTaskExecutor() {
/* 105 */     return this.taskExecutor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setErrorHandler(@Nullable ErrorHandler errorHandler) {
/* 124 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ErrorHandler getErrorHandler() {
/* 133 */     return this.errorHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public void multicastEvent(ApplicationEvent event) {
/* 138 */     multicastEvent(event, (ResolvableType)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void multicastEvent(ApplicationEvent event, @Nullable ResolvableType eventType) {
/* 143 */     ResolvableType type = (eventType != null) ? eventType : ResolvableType.forInstance(event);
/* 144 */     Executor executor = getTaskExecutor();
/* 145 */     for (ApplicationListener<?> listener : getApplicationListeners(event, type)) {
/* 146 */       if (executor != null && listener.supportsAsyncExecution()) {
/*     */         try {
/* 148 */           executor.execute(() -> invokeListener(listener, event));
/*     */         }
/* 150 */         catch (RejectedExecutionException ex) {
/*     */           
/* 152 */           invokeListener(listener, event);
/*     */         } 
/*     */         continue;
/*     */       } 
/* 156 */       invokeListener(listener, event);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeListener(ApplicationListener<?> listener, ApplicationEvent event) {
/* 168 */     ErrorHandler errorHandler = getErrorHandler();
/* 169 */     if (errorHandler != null) {
/*     */       try {
/* 171 */         doInvokeListener(listener, event);
/*     */       }
/* 173 */       catch (Throwable err) {
/* 174 */         errorHandler.handleError(err);
/*     */       } 
/*     */     } else {
/*     */       
/* 178 */       doInvokeListener(listener, event);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doInvokeListener(ApplicationListener listener, ApplicationEvent event) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: aload_2
/*     */     //   2: invokeinterface onApplicationEvent : (Lorg/springframework/context/ApplicationEvent;)V
/*     */     //   7: goto -> 123
/*     */     //   10: astore_3
/*     */     //   11: aload_3
/*     */     //   12: invokevirtual getMessage : ()Ljava/lang/String;
/*     */     //   15: astore #4
/*     */     //   17: aload #4
/*     */     //   19: ifnull -> 65
/*     */     //   22: aload_0
/*     */     //   23: aload #4
/*     */     //   25: aload_2
/*     */     //   26: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   29: invokevirtual matchesClassCastMessage : (Ljava/lang/String;Ljava/lang/Class;)Z
/*     */     //   32: ifne -> 65
/*     */     //   35: aload_2
/*     */     //   36: instanceof org/springframework/context/PayloadApplicationEvent
/*     */     //   39: ifeq -> 121
/*     */     //   42: aload_2
/*     */     //   43: checkcast org/springframework/context/PayloadApplicationEvent
/*     */     //   46: astore #5
/*     */     //   48: aload_0
/*     */     //   49: aload #4
/*     */     //   51: aload #5
/*     */     //   53: invokevirtual getPayload : ()Ljava/lang/Object;
/*     */     //   56: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   59: invokevirtual matchesClassCastMessage : (Ljava/lang/String;Ljava/lang/Class;)Z
/*     */     //   62: ifeq -> 121
/*     */     //   65: aload_0
/*     */     //   66: getfield lazyLogger : Lorg/apache/commons/logging/Log;
/*     */     //   69: astore #6
/*     */     //   71: aload #6
/*     */     //   73: ifnonnull -> 91
/*     */     //   76: aload_0
/*     */     //   77: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   80: invokestatic getLog : (Ljava/lang/Class;)Lorg/apache/commons/logging/Log;
/*     */     //   83: astore #6
/*     */     //   85: aload_0
/*     */     //   86: aload #6
/*     */     //   88: putfield lazyLogger : Lorg/apache/commons/logging/Log;
/*     */     //   91: aload #6
/*     */     //   93: invokeinterface isTraceEnabled : ()Z
/*     */     //   98: ifeq -> 118
/*     */     //   101: aload #6
/*     */     //   103: aload_1
/*     */     //   104: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   107: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   112: aload_3
/*     */     //   113: invokeinterface trace : (Ljava/lang/Object;Ljava/lang/Throwable;)V
/*     */     //   118: goto -> 123
/*     */     //   121: aload_3
/*     */     //   122: athrow
/*     */     //   123: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #185	-> 0
/*     */     //   #206	-> 7
/*     */     //   #187	-> 10
/*     */     //   #188	-> 11
/*     */     //   #189	-> 17
/*     */     //   #190	-> 42
/*     */     //   #191	-> 53
/*     */     //   #194	-> 65
/*     */     //   #195	-> 71
/*     */     //   #196	-> 76
/*     */     //   #197	-> 85
/*     */     //   #199	-> 91
/*     */     //   #200	-> 101
/*     */     //   #202	-> 118
/*     */     //   #204	-> 121
/*     */     //   #207	-> 123
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   48	17	5	payloadEvent	Lorg/springframework/context/PayloadApplicationEvent;
/*     */     //   71	47	6	loggerToUse	Lorg/apache/commons/logging/Log;
/*     */     //   17	106	4	msg	Ljava/lang/String;
/*     */     //   11	112	3	ex	Ljava/lang/ClassCastException;
/*     */     //   0	124	0	this	Lorg/springframework/context/event/SimpleApplicationEventMulticaster;
/*     */     //   0	124	1	listener	Lorg/springframework/context/ApplicationListener;
/*     */     //   0	124	2	event	Lorg/springframework/context/ApplicationEvent;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	7	10	java/lang/ClassCastException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matchesClassCastMessage(String classCastMessage, Class<?> eventClass) {
/* 211 */     if (classCastMessage.startsWith(eventClass.getName())) {
/* 212 */       return true;
/*     */     }
/*     */     
/* 215 */     if (classCastMessage.startsWith(eventClass.toString())) {
/* 216 */       return true;
/*     */     }
/*     */     
/* 219 */     int moduleSeparatorIndex = classCastMessage.indexOf('/');
/* 220 */     if (moduleSeparatorIndex != -1 && classCastMessage.startsWith(eventClass.getName(), moduleSeparatorIndex + 1)) {
/* 221 */       return true;
/*     */     }
/*     */     
/* 224 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\event\SimpleApplicationEventMulticaster.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */