/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.StringJoiner;
/*     */ import java.util.concurrent.CompletionStage;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.PayloadApplicationEvent;
/*     */ import org.springframework.context.expression.AnnotatedElementKey;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.CoroutinesUtils;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationListenerMethodAdapter
/*     */   implements GenericApplicationListener
/*     */ {
/*  76 */   private static final boolean reactiveStreamsPresent = ClassUtils.isPresent("org.reactivestreams.Publisher", ApplicationListenerMethodAdapter.class
/*  77 */       .getClassLoader());
/*     */ 
/*     */   
/*  80 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   private final String beanName;
/*     */ 
/*     */   
/*     */   private final Method method;
/*     */ 
/*     */   
/*     */   private final Method targetMethod;
/*     */ 
/*     */   
/*     */   private final AnnotatedElementKey methodKey;
/*     */ 
/*     */   
/*     */   private final List<ResolvableType> declaredEventTypes;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final String condition;
/*     */   
/*     */   private final boolean defaultExecution;
/*     */   
/*     */   private final int order;
/*     */   
/*     */   @Nullable
/*     */   private volatile String listenerId;
/*     */   
/*     */   @Nullable
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */   @Nullable
/*     */   private EventExpressionEvaluator evaluator;
/*     */ 
/*     */   
/*     */   public ApplicationListenerMethodAdapter(String beanName, Class<?> targetClass, Method method) {
/* 116 */     this.beanName = beanName;
/* 117 */     this.method = BridgeMethodResolver.findBridgedMethod(method);
/* 118 */     this
/* 119 */       .targetMethod = !Proxy.isProxyClass(targetClass) ? AopUtils.getMostSpecificMethod(method, targetClass) : this.method;
/* 120 */     this.methodKey = new AnnotatedElementKey(this.targetMethod, targetClass);
/*     */     
/* 122 */     EventListener ann = (EventListener)AnnotatedElementUtils.findMergedAnnotation(this.targetMethod, EventListener.class);
/* 123 */     this.declaredEventTypes = resolveDeclaredEventTypes(method, ann);
/* 124 */     this.condition = (ann != null) ? ann.condition() : null;
/* 125 */     this.defaultExecution = (ann == null || ann.defaultExecution());
/* 126 */     this.order = resolveOrder(this.targetMethod);
/* 127 */     String id = (ann != null) ? ann.id() : "";
/* 128 */     this.listenerId = !id.isEmpty() ? id : null;
/*     */   }
/*     */   
/*     */   private static List<ResolvableType> resolveDeclaredEventTypes(Method method, @Nullable EventListener ann) {
/* 132 */     int count = KotlinDetector.isSuspendingFunction(method) ? (method.getParameterCount() - 1) : method.getParameterCount();
/* 133 */     if (count > 1) {
/* 134 */       throw new IllegalStateException("Maximum one parameter is allowed for event listener method: " + String.valueOf(method));
/*     */     }
/*     */ 
/*     */     
/* 138 */     if (ann != null) {
/* 139 */       Class<?>[] classes = ann.classes();
/* 140 */       if (classes.length > 0) {
/* 141 */         List<ResolvableType> types = new ArrayList<>(classes.length);
/* 142 */         for (Class<?> eventType : classes) {
/* 143 */           types.add(ResolvableType.forClass(eventType));
/*     */         }
/* 145 */         return types;
/*     */       } 
/*     */     } 
/*     */     
/* 149 */     if (count == 0) {
/* 150 */       throw new IllegalStateException("Event parameter is mandatory for event listener method: " + String.valueOf(method));
/*     */     }
/*     */     
/* 153 */     return Collections.singletonList(ResolvableType.forMethodParameter(method, 0));
/*     */   }
/*     */   
/*     */   private static int resolveOrder(Method method) {
/* 157 */     Order ann = (Order)AnnotatedElementUtils.findMergedAnnotation(method, Order.class);
/* 158 */     return (ann != null) ? ann.value() : Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init(ApplicationContext applicationContext, @Nullable EventExpressionEvaluator evaluator) {
/* 166 */     this.applicationContext = applicationContext;
/* 167 */     this.evaluator = evaluator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event) {
/* 173 */     if (isDefaultExecution()) {
/* 174 */       processEvent(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsEventType(ResolvableType eventType) {
/* 180 */     for (ResolvableType declaredEventType : this.declaredEventTypes) {
/* 181 */       if (eventType.hasUnresolvableGenerics() ? declaredEventType
/* 182 */         .toClass().isAssignableFrom(eventType.toClass()) : declaredEventType
/* 183 */         .isAssignableFrom(eventType)) {
/* 184 */         return true;
/*     */       }
/* 186 */       if (PayloadApplicationEvent.class.isAssignableFrom(eventType.toClass())) {
/* 187 */         ResolvableType payloadType = eventType.as(PayloadApplicationEvent.class).getGeneric(new int[0]);
/* 188 */         if (declaredEventType.isAssignableFrom(payloadType)) {
/* 189 */           return true;
/*     */         }
/* 191 */         if (payloadType.resolve() == null)
/*     */         {
/* 193 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 197 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsSourceType(@Nullable Class<?> sourceType) {
/* 202 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 207 */     return this.order;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getListenerId() {
/* 212 */     String id = this.listenerId;
/* 213 */     if (id == null) {
/* 214 */       id = getDefaultListenerId();
/* 215 */       this.listenerId = id;
/*     */     } 
/* 217 */     return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDefaultListenerId() {
/* 228 */     Method method = getTargetMethod();
/* 229 */     StringJoiner sj = new StringJoiner(",", "(", ")");
/* 230 */     for (Class<?> paramType : method.getParameterTypes()) {
/* 231 */       sj.add(paramType.getName());
/*     */     }
/* 233 */     return ClassUtils.getQualifiedMethodName(method) + ClassUtils.getQualifiedMethodName(method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDefaultExecution() {
/* 243 */     return this.defaultExecution;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processEvent(ApplicationEvent event) {
/* 253 */     Object[] args = resolveArguments(event);
/* 254 */     if (shouldHandle(event, args)) {
/* 255 */       Object result = doInvoke(args);
/* 256 */       if (result != null) {
/* 257 */         handleResult(result);
/*     */       } else {
/*     */         
/* 260 */         this.logger.trace("No result object given - no result to handle");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldHandle(ApplicationEvent event) {
/* 272 */     return shouldHandle(event, resolveArguments(event));
/*     */   }
/*     */   
/*     */   private boolean shouldHandle(ApplicationEvent event, @Nullable Object[] args) {
/* 276 */     if (args == null) {
/* 277 */       return false;
/*     */     }
/* 279 */     String condition = getCondition();
/* 280 */     if (StringUtils.hasText(condition)) {
/* 281 */       Assert.notNull(this.evaluator, "EventExpressionEvaluator must not be null");
/* 282 */       return this.evaluator.condition(condition, event, this.targetMethod, this.methodKey, args);
/*     */     } 
/*     */     
/* 285 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object[] resolveArguments(ApplicationEvent event) {
/* 296 */     ResolvableType declaredEventType = getResolvableType(event);
/* 297 */     if (declaredEventType == null) {
/* 298 */       return null;
/*     */     }
/* 300 */     if (this.method.getParameterCount() == 0) {
/* 301 */       return new Object[0];
/*     */     }
/* 303 */     Class<?> declaredEventClass = declaredEventType.toClass();
/* 304 */     if (!ApplicationEvent.class.isAssignableFrom(declaredEventClass) && event instanceof PayloadApplicationEvent) {
/* 305 */       PayloadApplicationEvent<?> payloadEvent = (PayloadApplicationEvent)event;
/* 306 */       Object payload = payloadEvent.getPayload();
/* 307 */       if (declaredEventClass.isInstance(payload)) {
/* 308 */         return new Object[] { payload };
/*     */       }
/*     */     } 
/* 311 */     return new Object[] { event };
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleResult(Object result) {
/* 316 */     if (reactiveStreamsPresent && (new ReactiveResultHandler()).subscribeToPublisher(result))
/* 317 */     { if (this.logger.isTraceEnabled()) {
/* 318 */         this.logger.trace("Adapted to reactive result: " + String.valueOf(result));
/*     */       } }
/*     */     
/* 321 */     else if (result instanceof CompletionStage) { CompletionStage<?> completionStage = (CompletionStage)result;
/* 322 */       completionStage.whenComplete((event, ex) -> {
/*     */ 
/*     */             
/*     */             if (ex != null) {
/*     */               handleAsyncError(ex);
/*     */             } else if (event != null) {
/*     */               publishEvents(event);
/*     */             } 
/*     */           }); }
/* 331 */     else if (result instanceof ListenableFuture) { ListenableFuture<?> listenableFuture = (ListenableFuture)result;
/* 332 */       listenableFuture.addCallback(this::publishEvents, this::handleAsyncError); }
/*     */     else
/*     */     
/* 335 */     { publishEvents(result); }
/*     */   
/*     */   }
/*     */   
/*     */   private void publishEvents(@Nullable Object result) {
/* 340 */     if (result != null && result.getClass().isArray())
/* 341 */     { Object[] events = ObjectUtils.toObjectArray(result);
/* 342 */       for (Object event : events) {
/* 343 */         publishEvent(event);
/*     */       } }
/*     */     
/* 346 */     else if (result instanceof Collection) { Collection<?> events = (Collection)result;
/* 347 */       for (Object event : events) {
/* 348 */         publishEvent(event);
/*     */       } }
/*     */     else
/*     */     
/* 352 */     { publishEvent(result); }
/*     */   
/*     */   }
/*     */   
/*     */   private void publishEvent(@Nullable Object event) {
/* 357 */     if (event != null) {
/* 358 */       Assert.notNull(this.applicationContext, "ApplicationContext must not be null");
/* 359 */       this.applicationContext.publishEvent(event);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void handleAsyncError(Throwable t) {
/* 364 */     this.logger.error("Unexpected error occurred in asynchronous listener", t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object doInvoke(@Nullable Object... args) {
/* 372 */     Object bean = getTargetBean();
/*     */     
/* 374 */     if (bean.equals(null)) {
/* 375 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 379 */       ReflectionUtils.makeAccessible(this.method);
/* 380 */       if (KotlinDetector.isSuspendingFunction(this.method)) {
/* 381 */         return CoroutinesUtils.invokeSuspendingFunction(this.method, bean, args);
/*     */       }
/* 383 */       return this.method.invoke(bean, args);
/*     */     }
/* 385 */     catch (IllegalArgumentException ex) {
/* 386 */       assertTargetBean(this.method, bean, args);
/* 387 */       throw new IllegalStateException(getInvocationErrorMessage(bean, ex.getMessage(), args), ex);
/*     */     }
/* 389 */     catch (IllegalAccessException|java.lang.reflect.InaccessibleObjectException ex) {
/* 390 */       throw new IllegalStateException(getInvocationErrorMessage(bean, ex.getMessage(), args), ex);
/*     */     }
/* 392 */     catch (InvocationTargetException ex) {
/*     */       
/* 394 */       Throwable targetException = ex.getTargetException();
/* 395 */       if (targetException instanceof RuntimeException) { RuntimeException runtimeException = (RuntimeException)targetException;
/* 396 */         throw runtimeException; }
/*     */ 
/*     */       
/* 399 */       String msg = getInvocationErrorMessage(bean, "Failed to invoke event listener method", args);
/* 400 */       throw new UndeclaredThrowableException(targetException, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getTargetBean() {
/* 409 */     Assert.notNull(this.applicationContext, "ApplicationContext must not be null");
/* 410 */     return this.applicationContext.getBean(this.beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method getTargetMethod() {
/* 418 */     return this.targetMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getCondition() {
/* 429 */     return this.condition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDetailedErrorMessage(Object bean, @Nullable String message) {
/* 438 */     StringBuilder sb = StringUtils.hasLength(message) ? (new StringBuilder(message)).append('\n') : new StringBuilder();
/* 439 */     sb.append("HandlerMethod details: \n");
/* 440 */     sb.append("Bean [").append(bean.getClass().getName()).append("]\n");
/* 441 */     sb.append("Method [").append(this.method.toGenericString()).append("]\n");
/* 442 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void assertTargetBean(Method method, Object targetBean, @Nullable Object[] args) {
/* 453 */     Class<?> methodDeclaringClass = method.getDeclaringClass();
/* 454 */     Class<?> targetBeanClass = targetBean.getClass();
/* 455 */     if (!methodDeclaringClass.isAssignableFrom(targetBeanClass)) {
/*     */ 
/*     */       
/* 458 */       String msg = "The event listener method class '" + methodDeclaringClass.getName() + "' is not an instance of the actual bean class '" + targetBeanClass.getName() + "'. If the bean requires proxying (for example, due to @Transactional), please use class-based proxying.";
/*     */       
/* 460 */       throw new IllegalStateException(getInvocationErrorMessage(targetBean, msg, args));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String getInvocationErrorMessage(Object bean, @Nullable String message, @Nullable Object[] resolvedArgs) {
/* 466 */     StringBuilder sb = new StringBuilder(getDetailedErrorMessage(bean, message));
/* 467 */     sb.append("Resolved arguments: \n");
/* 468 */     for (int i = 0; i < resolvedArgs.length; i++) {
/* 469 */       sb.append('[').append(i).append("] ");
/* 470 */       if (resolvedArgs[i] == null) {
/* 471 */         sb.append("[null] \n");
/*     */       } else {
/*     */         
/* 474 */         sb.append("[type=").append(resolvedArgs[i].getClass().getName()).append("] ");
/* 475 */         sb.append("[value=").append(resolvedArgs[i]).append("]\n");
/*     */       } 
/*     */     } 
/* 478 */     return sb.toString();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private ResolvableType getResolvableType(ApplicationEvent event) {
/* 483 */     ResolvableType payloadType = null;
/* 484 */     if (event instanceof PayloadApplicationEvent) { PayloadApplicationEvent<?> payloadEvent = (PayloadApplicationEvent)event;
/* 485 */       ResolvableType eventType = payloadEvent.getResolvableType();
/* 486 */       if (eventType != null) {
/* 487 */         payloadType = eventType.as(PayloadApplicationEvent.class).getGeneric(new int[0]);
/*     */       } }
/*     */     
/* 490 */     for (ResolvableType declaredEventType : this.declaredEventTypes) {
/* 491 */       Class<?> eventClass = declaredEventType.toClass();
/* 492 */       if (!ApplicationEvent.class.isAssignableFrom(eventClass) && payloadType != null && declaredEventType
/* 493 */         .isAssignableFrom(payloadType)) {
/* 494 */         return declaredEventType;
/*     */       }
/* 496 */       if (eventClass.isInstance(event)) {
/* 497 */         return declaredEventType;
/*     */       }
/*     */     } 
/* 500 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 506 */     return this.method.toGenericString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ReactiveResultHandler
/*     */   {
/*     */     public boolean subscribeToPublisher(Object result) {
/* 516 */       ReactiveAdapter adapter = ReactiveAdapterRegistry.getSharedInstance().getAdapter(result.getClass());
/* 517 */       if (adapter != null) {
/* 518 */         adapter.toPublisher(result).subscribe(new ApplicationListenerMethodAdapter.EventPublicationSubscriber());
/* 519 */         return true;
/*     */       } 
/* 521 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class EventPublicationSubscriber
/*     */     implements Subscriber<Object>
/*     */   {
/*     */     public void onSubscribe(Subscription s) {
/* 533 */       s.request(2147483647L);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Object o) {
/* 538 */       ApplicationListenerMethodAdapter.this.publishEvents(o);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 543 */       ApplicationListenerMethodAdapter.this.handleAsyncError(t);
/*     */     }
/*     */     
/*     */     public void onComplete() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\event\ApplicationListenerMethodAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */