/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.framework.autoproxy.AutoProxyUtils;
/*     */ import org.springframework.aop.scope.ScopedObject;
/*     */ import org.springframework.aop.scope.ScopedProxyUtils;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.expression.BeanFactoryResolver;
/*     */ import org.springframework.core.MethodIntrospector;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventListenerMethodProcessor
/*     */   implements SmartInitializingSingleton, ApplicationContextAware, BeanFactoryPostProcessor
/*     */ {
/*  68 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private ConfigurableApplicationContext applicationContext;
/*     */   
/*     */   @Nullable
/*     */   private ConfigurableListableBeanFactory beanFactory;
/*     */   
/*     */   @Nullable
/*     */   private List<EventListenerFactory> eventListenerFactories;
/*     */   
/*     */   private final StandardEvaluationContext originalEvaluationContext;
/*     */   
/*     */   @Nullable
/*     */   private final EventExpressionEvaluator evaluator;
/*     */   
/*  84 */   private final Set<Class<?>> nonAnnotatedClasses = ConcurrentHashMap.newKeySet(64);
/*     */ 
/*     */   
/*     */   public EventListenerMethodProcessor() {
/*  88 */     this.originalEvaluationContext = new StandardEvaluationContext();
/*  89 */     this.evaluator = new EventExpressionEvaluator(this.originalEvaluationContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) {
/*  94 */     Assert.isTrue(applicationContext instanceof ConfigurableApplicationContext, "ApplicationContext does not implement ConfigurableApplicationContext");
/*     */     
/*  96 */     this.applicationContext = (ConfigurableApplicationContext)applicationContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/* 101 */     this.beanFactory = beanFactory;
/* 102 */     this.originalEvaluationContext.setBeanResolver((BeanResolver)new BeanFactoryResolver((BeanFactory)this.beanFactory));
/*     */     
/* 104 */     Map<String, EventListenerFactory> beans = beanFactory.getBeansOfType(EventListenerFactory.class, false, false);
/* 105 */     List<EventListenerFactory> factories = new ArrayList<>(beans.values());
/* 106 */     AnnotationAwareOrderComparator.sort(factories);
/* 107 */     this.eventListenerFactories = factories;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterSingletonsInstantiated() {
/* 113 */     ConfigurableListableBeanFactory beanFactory = this.beanFactory;
/* 114 */     Assert.state((beanFactory != null), "No ConfigurableListableBeanFactory set");
/* 115 */     String[] beanNames = beanFactory.getBeanNamesForType(Object.class);
/* 116 */     for (String beanName : beanNames) {
/* 117 */       if (!ScopedProxyUtils.isScopedTarget(beanName)) {
/* 118 */         Class<?> type = null;
/*     */         try {
/* 120 */           type = AutoProxyUtils.determineTargetClass(beanFactory, beanName);
/*     */         }
/* 122 */         catch (Throwable ex) {
/*     */           
/* 124 */           if (this.logger.isDebugEnabled()) {
/* 125 */             this.logger.debug("Could not resolve target class for bean with name '" + beanName + "'", ex);
/*     */           }
/*     */         } 
/* 128 */         if (type != null) {
/* 129 */           if (ScopedObject.class.isAssignableFrom(type)) {
/*     */             try {
/* 131 */               Class<?> targetClass = AutoProxyUtils.determineTargetClass(beanFactory, 
/* 132 */                   ScopedProxyUtils.getTargetBeanName(beanName));
/* 133 */               if (targetClass != null) {
/* 134 */                 type = targetClass;
/*     */               }
/*     */             }
/* 137 */             catch (Throwable ex) {
/*     */               
/* 139 */               if (this.logger.isDebugEnabled()) {
/* 140 */                 this.logger.debug("Could not resolve target bean for scoped proxy '" + beanName + "'", ex);
/*     */               }
/*     */             } 
/*     */           }
/*     */           try {
/* 145 */             processBean(beanName, type);
/*     */           }
/* 147 */           catch (Throwable ex) {
/* 148 */             throw new BeanInitializationException("Failed to process @EventListener annotation on bean with name '" + beanName + "': " + ex
/* 149 */                 .getMessage(), ex);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processBean(String beanName, Class<?> targetType) {
/* 157 */     if (!this.nonAnnotatedClasses.contains(targetType) && 
/* 158 */       AnnotationUtils.isCandidateClass(targetType, EventListener.class) && 
/* 159 */       !isSpringContainerClass(targetType)) {
/*     */       
/* 161 */       Map<Method, EventListener> annotatedMethods = null;
/*     */       try {
/* 163 */         annotatedMethods = MethodIntrospector.selectMethods(targetType, method -> (EventListener)AnnotatedElementUtils.findMergedAnnotation(method, EventListener.class));
/*     */ 
/*     */       
/*     */       }
/* 167 */       catch (Throwable ex) {
/*     */         
/* 169 */         if (this.logger.isDebugEnabled()) {
/* 170 */           this.logger.debug("Could not resolve methods for bean with name '" + beanName + "'", ex);
/*     */         }
/*     */       } 
/*     */       
/* 174 */       if (CollectionUtils.isEmpty(annotatedMethods)) {
/* 175 */         this.nonAnnotatedClasses.add(targetType);
/* 176 */         if (this.logger.isTraceEnabled()) {
/* 177 */           this.logger.trace("No @EventListener annotations found on bean class: " + targetType.getName());
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 182 */         ConfigurableApplicationContext context = this.applicationContext;
/* 183 */         Assert.state((context != null), "No ApplicationContext set");
/* 184 */         List<EventListenerFactory> factories = this.eventListenerFactories;
/* 185 */         Assert.state((factories != null), "EventListenerFactory List not initialized");
/* 186 */         for (Method method : annotatedMethods.keySet()) {
/* 187 */           label40: for (EventListenerFactory factory : factories) {
/* 188 */             if (factory.supportsMethod(method)) {
/* 189 */               Method methodToUse = AopUtils.selectInvocableMethod(method, context.getType(beanName));
/*     */               
/* 191 */               ApplicationListener<?> applicationListener = factory.createApplicationListener(beanName, targetType, methodToUse);
/* 192 */               if (applicationListener instanceof ApplicationListenerMethodAdapter) { ApplicationListenerMethodAdapter alma = (ApplicationListenerMethodAdapter)applicationListener;
/* 193 */                 alma.init((ApplicationContext)context, this.evaluator); break label40; }
/*     */               
/* 195 */               context.addApplicationListener(applicationListener);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 200 */         if (this.logger.isDebugEnabled()) {
/* 201 */           this.logger.debug("" + annotatedMethods.size() + " @EventListener methods processed on bean '" + annotatedMethods.size() + "': " + beanName);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSpringContainerClass(Class<?> clazz) {
/* 215 */     return (clazz.getName().startsWith("org.springframework.") && 
/* 216 */       !AnnotatedElementUtils.isAnnotated(ClassUtils.getUserClass(clazz), Component.class));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\event\EventListenerMethodProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */