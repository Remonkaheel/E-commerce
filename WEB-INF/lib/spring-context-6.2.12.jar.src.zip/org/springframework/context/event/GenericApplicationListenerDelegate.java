/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.core.ResolvableType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class GenericApplicationListenerDelegate<E extends ApplicationEvent>
/*    */   implements GenericApplicationListener
/*    */ {
/*    */   private final Class<E> supportedEventType;
/*    */   private final Consumer<E> consumer;
/*    */   
/*    */   GenericApplicationListenerDelegate(Class<E> supportedEventType, Consumer<E> consumer) {
/* 39 */     this.supportedEventType = supportedEventType;
/* 40 */     this.consumer = consumer;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(ApplicationEvent event) {
/* 46 */     this.consumer.accept(this.supportedEventType.cast(event));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supportsEventType(ResolvableType eventType) {
/* 51 */     return this.supportedEventType.isAssignableFrom(eventType.toClass());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\event\GenericApplicationListenerDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */