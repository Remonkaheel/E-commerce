package org.springframework.context.event;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.aot.hint.annotation.Reflective;
import org.springframework.core.annotation.AliasFor;

@Target({ElementType.METHOD, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Reflective
public @interface EventListener {
  @AliasFor("classes")
  Class<?>[] value() default {};
  
  @AliasFor("value")
  Class<?>[] classes() default {};
  
  String condition() default "";
  
  boolean defaultExecution() default true;
  
  String id() default "";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\event\EventListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */