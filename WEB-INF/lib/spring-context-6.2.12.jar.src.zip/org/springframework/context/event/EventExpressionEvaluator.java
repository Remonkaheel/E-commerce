/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.expression.AnnotatedElementKey;
/*    */ import org.springframework.context.expression.CachedExpressionEvaluator;
/*    */ import org.springframework.context.expression.MethodBasedEvaluationContext;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EventExpressionEvaluator
/*    */   extends CachedExpressionEvaluator
/*    */ {
/* 41 */   private final Map<CachedExpressionEvaluator.ExpressionKey, Expression> conditionCache = new ConcurrentHashMap<>(64);
/*    */   
/*    */   private final StandardEvaluationContext originalEvaluationContext;
/*    */   
/*    */   EventExpressionEvaluator(StandardEvaluationContext originalEvaluationContext) {
/* 46 */     this.originalEvaluationContext = originalEvaluationContext;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean condition(String conditionExpression, ApplicationEvent event, Method targetMethod, AnnotatedElementKey methodKey, Object[] args) {
/* 56 */     EventExpressionRootObject rootObject = new EventExpressionRootObject(event, args);
/* 57 */     EvaluationContext evaluationContext = createEvaluationContext(rootObject, targetMethod, args);
/* 58 */     return Boolean.TRUE.equals(getExpression(this.conditionCache, methodKey, conditionExpression).getValue(evaluationContext, Boolean.class));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private EvaluationContext createEvaluationContext(EventExpressionRootObject rootObject, Method method, Object[] args) {
/* 66 */     MethodBasedEvaluationContext evaluationContext = new MethodBasedEvaluationContext(rootObject, method, args, getParameterNameDiscoverer());
/* 67 */     this.originalEvaluationContext.applyDelegatesTo((StandardEvaluationContext)evaluationContext);
/* 68 */     return (EvaluationContext)evaluationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\event\EventExpressionEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */