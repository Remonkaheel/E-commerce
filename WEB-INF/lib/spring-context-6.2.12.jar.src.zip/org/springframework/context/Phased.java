package org.springframework.context;

public interface Phased {
  int getPhase();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\Phased.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */