/*    */ package org.springframework.context;
/*    */ 
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.ResolvableTypeProvider;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PayloadApplicationEvent<T>
/*    */   extends ApplicationEvent
/*    */   implements ResolvableTypeProvider
/*    */ {
/*    */   private final T payload;
/*    */   private final ResolvableType payloadType;
/*    */   
/*    */   public PayloadApplicationEvent(Object source, T payload) {
/* 51 */     this(source, payload, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PayloadApplicationEvent(Object source, T payload, @Nullable ResolvableType payloadType) {
/* 64 */     super(source);
/* 65 */     Assert.notNull(payload, "Payload must not be null");
/* 66 */     this.payload = payload;
/* 67 */     this.payloadType = (payloadType != null) ? payloadType : ResolvableType.forInstance(payload);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ResolvableType getResolvableType() {
/* 73 */     return ResolvableType.forClassWithGenerics(getClass(), new ResolvableType[] { this.payloadType });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public T getPayload() {
/* 80 */     return this.payload;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\PayloadApplicationEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */