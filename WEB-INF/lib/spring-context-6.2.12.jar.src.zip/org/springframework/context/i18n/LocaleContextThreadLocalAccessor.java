/*    */ package org.springframework.context.i18n;
/*    */ 
/*    */ import io.micrometer.context.ThreadLocalAccessor;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocaleContextThreadLocalAccessor
/*    */   implements ThreadLocalAccessor<LocaleContext>
/*    */ {
/* 37 */   public static final String KEY = LocaleContextThreadLocalAccessor.class.getName() + ".KEY";
/*    */ 
/*    */   
/*    */   public Object key() {
/* 41 */     return KEY;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public LocaleContext getValue() {
/* 47 */     return LocaleContextHolder.getLocaleContext();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(LocaleContext value) {
/* 52 */     LocaleContextHolder.setLocaleContext(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue() {
/* 57 */     LocaleContextHolder.resetLocaleContext();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\i18n\LocaleContextThreadLocalAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */