/*    */ package org.springframework.context.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleLocaleContext
/*    */   implements LocaleContext
/*    */ {
/*    */   @Nullable
/*    */   private final Locale locale;
/*    */   
/*    */   public SimpleLocaleContext(@Nullable Locale locale) {
/* 45 */     this.locale = locale;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Locale getLocale() {
/* 51 */     return this.locale;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 56 */     return (this.locale != null) ? this.locale.toString() : "-";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\i18n\SimpleLocaleContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */