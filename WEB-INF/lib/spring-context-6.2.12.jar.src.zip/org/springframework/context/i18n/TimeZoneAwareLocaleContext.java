package org.springframework.context.i18n;

import java.util.TimeZone;
import org.springframework.lang.Nullable;

public interface TimeZoneAwareLocaleContext extends LocaleContext {
  @Nullable
  TimeZone getTimeZone();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\i18n\TimeZoneAwareLocaleContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */