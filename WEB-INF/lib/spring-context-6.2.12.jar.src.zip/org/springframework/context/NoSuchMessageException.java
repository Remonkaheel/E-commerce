/*    */ package org.springframework.context;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoSuchMessageException
/*    */   extends RuntimeException
/*    */ {
/*    */   public NoSuchMessageException(String code, Locale locale) {
/* 35 */     super("No message found under code '" + code + "' for locale '" + String.valueOf(locale) + "'.");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NoSuchMessageException(String code) {
/* 43 */     super("No message found under code '" + code + "' for locale '" + String.valueOf(Locale.getDefault()) + "'.");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\NoSuchMessageException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */