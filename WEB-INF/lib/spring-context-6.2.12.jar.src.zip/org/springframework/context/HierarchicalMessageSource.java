package org.springframework.context;

import org.springframework.lang.Nullable;

public interface HierarchicalMessageSource extends MessageSource {
  void setParentMessageSource(@Nullable MessageSource paramMessageSource);
  
  @Nullable
  MessageSource getParentMessageSource();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\context\HierarchicalMessageSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */