/*     */ package org.springframework.format.annotation;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Unit
/*     */ {
/* 108 */   NANOS(ChronoUnit.NANOS, "ns", Duration::toNanos),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   MILLIS(ChronoUnit.MILLIS, "ms", Duration::toMillis),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   SECONDS(ChronoUnit.SECONDS, "s", Duration::toSeconds),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   MINUTES(ChronoUnit.MINUTES, "m", Duration::toMinutes),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   HOURS(ChronoUnit.HOURS, "h", Duration::toHours),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   DAYS(ChronoUnit.DAYS, "d", Duration::toDays), MICROS(ChronoUnit.DAYS, "d", Duration::toDays);
/*     */   
/*     */   static {
/*     */     MICROS = new Unit("MICROS", 1, ChronoUnit.MICROS, "us", duration -> Long.valueOf(duration.toNanos() / 1000L));
/*     */   }
/*     */   
/*     */   private final ChronoUnit chronoUnit;
/*     */   
/*     */   Unit(ChronoUnit chronoUnit, String suffix, Function<Duration, Long> toUnit) {
/* 147 */     this.chronoUnit = chronoUnit;
/* 148 */     this.suffix = suffix;
/* 149 */     this.longValue = toUnit;
/*     */   }
/*     */   
/*     */   private final String suffix;
/*     */   private final Function<Duration, Long> longValue;
/*     */   
/*     */   public ChronoUnit asChronoUnit() {
/* 156 */     return this.chronoUnit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asSuffix() {
/* 164 */     return this.suffix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration parse(String value) {
/* 174 */     return Duration.of(Long.parseLong(value), asChronoUnit());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String print(Duration value) {
/* 186 */     return "" + longValue(value) + longValue(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long longValue(Duration value) {
/* 200 */     return ((Long)this.longValue.apply(value)).longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Unit fromChronoUnit(@Nullable ChronoUnit chronoUnit) {
/* 209 */     if (chronoUnit == null) {
/* 210 */       return MILLIS;
/*     */     }
/* 212 */     for (Unit candidate : values()) {
/* 213 */       if (candidate.chronoUnit == chronoUnit) {
/* 214 */         return candidate;
/*     */       }
/*     */     } 
/* 217 */     throw new IllegalArgumentException("No matching Unit for ChronoUnit." + chronoUnit.name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Unit fromSuffix(String suffix) {
/* 225 */     for (Unit candidate : values()) {
/* 226 */       if (candidate.suffix.equalsIgnoreCase(suffix)) {
/* 227 */         return candidate;
/*     */       }
/*     */     } 
/* 230 */     throw new IllegalArgumentException("'" + suffix + "' is not a valid simple duration Unit");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\annotation\DurationFormat$Unit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */