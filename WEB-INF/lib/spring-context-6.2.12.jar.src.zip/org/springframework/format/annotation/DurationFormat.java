/*     */ package org.springframework.format.annotation;
/*     */ 
/*     */ import java.lang.annotation.Documented;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Documented
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE})
/*     */ public @interface DurationFormat
/*     */ {
/*     */   Style style() default Style.ISO8601;
/*     */   
/*     */   Unit defaultUnit() default Unit.MILLIS;
/*     */   
/*     */   public enum Style
/*     */   {
/*  67 */     ISO8601,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     SIMPLE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     COMPOSITE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Unit
/*     */   {
/* 108 */     NANOS((String)ChronoUnit.NANOS, "ns", (ChronoUnit)Duration::toNanos),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     MILLIS((String)ChronoUnit.MILLIS, "ms", (ChronoUnit)Duration::toMillis),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     SECONDS((String)ChronoUnit.SECONDS, "s", (ChronoUnit)Duration::toSeconds),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     MINUTES((String)ChronoUnit.MINUTES, "m", (ChronoUnit)Duration::toMinutes),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     HOURS((String)ChronoUnit.HOURS, "h", (ChronoUnit)Duration::toHours),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     DAYS((String)ChronoUnit.DAYS, "d", (ChronoUnit)Duration::toDays), MICROS((String)ChronoUnit.DAYS, "d", (ChronoUnit)Duration::toDays);
/*     */     
/*     */     static {
/*     */       MICROS = new Unit("MICROS", 1, ChronoUnit.MICROS, "us", duration -> Long.valueOf(duration.toNanos() / 1000L));
/*     */     }
/*     */     
/*     */     private final ChronoUnit chronoUnit;
/*     */     
/*     */     Unit(ChronoUnit chronoUnit, String suffix, Function<Duration, Long> toUnit) {
/* 147 */       this.chronoUnit = chronoUnit;
/* 148 */       this.suffix = suffix;
/* 149 */       this.longValue = toUnit;
/*     */     }
/*     */     
/*     */     private final String suffix;
/*     */     private final Function<Duration, Long> longValue;
/*     */     
/*     */     public ChronoUnit asChronoUnit() {
/* 156 */       return this.chronoUnit;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String asSuffix() {
/* 164 */       return this.suffix;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Duration parse(String value) {
/* 174 */       return Duration.of(Long.parseLong(value), asChronoUnit());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String print(Duration value) {
/* 186 */       return "" + longValue(value) + longValue(value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public long longValue(Duration value) {
/* 200 */       return ((Long)this.longValue.apply(value)).longValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Unit fromChronoUnit(@Nullable ChronoUnit chronoUnit) {
/* 209 */       if (chronoUnit == null) {
/* 210 */         return MILLIS;
/*     */       }
/* 212 */       for (Unit candidate : values()) {
/* 213 */         if (candidate.chronoUnit == chronoUnit) {
/* 214 */           return candidate;
/*     */         }
/*     */       } 
/* 217 */       throw new IllegalArgumentException("No matching Unit for ChronoUnit." + chronoUnit.name());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Unit fromSuffix(String suffix) {
/* 225 */       for (Unit candidate : values()) {
/* 226 */         if (candidate.suffix.equalsIgnoreCase(suffix)) {
/* 227 */           return candidate;
/*     */         }
/*     */       } 
/* 230 */       throw new IllegalArgumentException("'" + suffix + "' is not a valid simple duration Unit");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\annotation\DurationFormat.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */