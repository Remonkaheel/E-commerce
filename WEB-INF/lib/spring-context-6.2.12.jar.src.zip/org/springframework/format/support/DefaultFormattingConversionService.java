/*     */ package org.springframework.format.support;
/*     */ 
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.datetime.DateFormatterRegistrar;
/*     */ import org.springframework.format.datetime.standard.DateTimeFormatterRegistrar;
/*     */ import org.springframework.format.number.NumberFormatAnnotationFormatterFactory;
/*     */ import org.springframework.format.number.money.CurrencyUnitFormatter;
/*     */ import org.springframework.format.number.money.Jsr354NumberFormatAnnotationFormatterFactory;
/*     */ import org.springframework.format.number.money.MonetaryAmountFormatter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFormattingConversionService
/*     */   extends FormattingConversionService
/*     */ {
/*     */   private static final boolean jsr354Present;
/*     */   
/*     */   static {
/*  52 */     ClassLoader classLoader = DefaultFormattingConversionService.class.getClassLoader();
/*  53 */     jsr354Present = ClassUtils.isPresent("javax.money.MonetaryAmount", classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultFormattingConversionService() {
/*  62 */     this(null, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultFormattingConversionService(boolean registerDefaultFormatters) {
/*  73 */     this(null, registerDefaultFormatters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultFormattingConversionService(@Nullable StringValueResolver embeddedValueResolver, boolean registerDefaultFormatters) {
/*  88 */     if (embeddedValueResolver != null) {
/*  89 */       setEmbeddedValueResolver(embeddedValueResolver);
/*     */     }
/*  91 */     DefaultConversionService.addDefaultConverters((ConverterRegistry)this);
/*  92 */     if (registerDefaultFormatters) {
/*  93 */       addDefaultFormatters(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addDefaultFormatters(FormatterRegistry formatterRegistry) {
/* 106 */     formatterRegistry.addFormatterForFieldAnnotation((AnnotationFormatterFactory)new NumberFormatAnnotationFormatterFactory());
/*     */ 
/*     */     
/* 109 */     if (jsr354Present) {
/* 110 */       formatterRegistry.addFormatter((Formatter)new CurrencyUnitFormatter());
/* 111 */       formatterRegistry.addFormatter((Formatter)new MonetaryAmountFormatter());
/* 112 */       formatterRegistry.addFormatterForFieldAnnotation((AnnotationFormatterFactory)new Jsr354NumberFormatAnnotationFormatterFactory());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     (new DateTimeFormatterRegistrar()).registerFormatters(formatterRegistry);
/*     */ 
/*     */     
/* 121 */     (new DateFormatterRegistrar()).registerFormatters(formatterRegistry);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\support\DefaultFormattingConversionService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */