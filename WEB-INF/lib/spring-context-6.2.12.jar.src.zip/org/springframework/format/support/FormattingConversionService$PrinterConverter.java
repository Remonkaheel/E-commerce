/*     */ package org.springframework.format.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PrinterConverter
/*     */   implements GenericConverter
/*     */ {
/*     */   private final Class<?> fieldType;
/*     */   private final TypeDescriptor printerObjectType;
/*     */   private final Printer printer;
/*     */   private final ConversionService conversionService;
/*     */   
/*     */   public PrinterConverter(Class<?> fieldType, Printer<?> printer, ConversionService conversionService) {
/* 154 */     this.fieldType = fieldType;
/* 155 */     this.printerObjectType = TypeDescriptor.valueOf(resolvePrinterObjectType(printer));
/* 156 */     this.printer = printer;
/* 157 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 162 */     return Collections.singleton(new GenericConverter.ConvertiblePair(this.fieldType, String.class));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object convert(@Nullable Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 168 */     if (!sourceType.isAssignableTo(this.printerObjectType)) {
/* 169 */       source = this.conversionService.convert(source, sourceType, this.printerObjectType);
/*     */     }
/* 171 */     if (source == null) {
/* 172 */       return "";
/*     */     }
/* 174 */     return this.printer.print(source, LocaleContextHolder.getLocale());
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Class<?> resolvePrinterObjectType(Printer<?> printer) {
/* 179 */     return GenericTypeResolver.resolveTypeArgument(printer.getClass(), Printer.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 184 */     return this.fieldType.getName() + " -> " + this.fieldType.getName() + " : " + String.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\support\FormattingConversionService$PrinterConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */