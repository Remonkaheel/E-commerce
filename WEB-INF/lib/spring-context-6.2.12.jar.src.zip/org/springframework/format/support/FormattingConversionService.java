/*     */ package org.springframework.format.support;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.core.DecoratingProxy;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.support.GenericConversionService;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormattingConversionService
/*     */   extends GenericConversionService
/*     */   implements FormatterRegistry, EmbeddedValueResolverAware
/*     */ {
/*     */   @Nullable
/*     */   private StringValueResolver embeddedValueResolver;
/*  59 */   private final Map<AnnotationConverterKey, GenericConverter> cachedPrinters = new ConcurrentHashMap<>(64);
/*     */   
/*  61 */   private final Map<AnnotationConverterKey, GenericConverter> cachedParsers = new ConcurrentHashMap<>(64);
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver) {
/*  66 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPrinter(Printer<?> printer) {
/*  72 */     Class<?> fieldType = getFieldType(printer, (Class)Printer.class);
/*  73 */     addConverter(new PrinterConverter(fieldType, printer, (ConversionService)this));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addParser(Parser<?> parser) {
/*  78 */     Class<?> fieldType = getFieldType(parser, (Class)Parser.class);
/*  79 */     addConverter(new ParserConverter(fieldType, parser, (ConversionService)this));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFormatter(Formatter<?> formatter) {
/*  84 */     addFormatterForFieldType(getFieldType(formatter), formatter);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Formatter<?> formatter) {
/*  89 */     addConverter(new PrinterConverter(fieldType, (Printer<?>)formatter, (ConversionService)this));
/*  90 */     addConverter(new ParserConverter(fieldType, (Parser<?>)formatter, (ConversionService)this));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Printer<?> printer, Parser<?> parser) {
/*  95 */     addConverter(new PrinterConverter(fieldType, printer, (ConversionService)this));
/*  96 */     addConverter(new ParserConverter(fieldType, parser, (ConversionService)this));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFormatterForFieldAnnotation(AnnotationFormatterFactory<? extends Annotation> annotationFormatterFactory) {
/* 101 */     Class<? extends Annotation> annotationType = getAnnotationType(annotationFormatterFactory);
/* 102 */     if (this.embeddedValueResolver != null && annotationFormatterFactory instanceof EmbeddedValueResolverAware) {
/* 103 */       EmbeddedValueResolverAware embeddedValueResolverAware = (EmbeddedValueResolverAware)annotationFormatterFactory;
/* 104 */       embeddedValueResolverAware.setEmbeddedValueResolver(this.embeddedValueResolver);
/*     */     } 
/* 106 */     Set<Class<?>> fieldTypes = annotationFormatterFactory.getFieldTypes();
/* 107 */     for (Class<?> fieldType : fieldTypes) {
/* 108 */       addConverter((GenericConverter)new AnnotationPrinterConverter(annotationType, annotationFormatterFactory, fieldType));
/* 109 */       addConverter((GenericConverter)new AnnotationParserConverter(annotationType, annotationFormatterFactory, fieldType));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static Class<?> getFieldType(Formatter<?> formatter) {
/* 115 */     return getFieldType(formatter, (Class)Formatter.class);
/*     */   }
/*     */   
/*     */   private static <T> Class<?> getFieldType(T instance, Class<T> genericInterface) {
/* 119 */     Class<?> fieldType = GenericTypeResolver.resolveTypeArgument(instance.getClass(), genericInterface);
/* 120 */     if (fieldType == null && instance instanceof DecoratingProxy) { DecoratingProxy decoratingProxy = (DecoratingProxy)instance;
/* 121 */       fieldType = GenericTypeResolver.resolveTypeArgument(decoratingProxy.getDecoratedClass(), genericInterface); }
/*     */     
/* 123 */     Assert.notNull(fieldType, () -> "Unable to extract the parameterized field type from " + ClassUtils.getShortName(genericInterface) + " [" + instance.getClass().getName() + "]; does the class parameterize the <T> generic type?");
/*     */ 
/*     */     
/* 126 */     return fieldType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Class<? extends Annotation> getAnnotationType(AnnotationFormatterFactory<? extends Annotation> factory) {
/* 132 */     Class<? extends Annotation> annotationType = GenericTypeResolver.resolveTypeArgument(factory.getClass(), AnnotationFormatterFactory.class);
/* 133 */     if (annotationType == null) {
/* 134 */       throw new IllegalArgumentException("Unable to extract parameterized Annotation type argument from AnnotationFormatterFactory [" + factory
/* 135 */           .getClass().getName() + "]; does the factory parameterize the <A extends Annotation> generic type?");
/*     */     }
/*     */     
/* 138 */     return annotationType;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class PrinterConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private final Class<?> fieldType;
/*     */     
/*     */     private final TypeDescriptor printerObjectType;
/*     */     
/*     */     private final Printer printer;
/*     */     
/*     */     private final ConversionService conversionService;
/*     */     
/*     */     public PrinterConverter(Class<?> fieldType, Printer<?> printer, ConversionService conversionService) {
/* 154 */       this.fieldType = fieldType;
/* 155 */       this.printerObjectType = TypeDescriptor.valueOf(resolvePrinterObjectType(printer));
/* 156 */       this.printer = printer;
/* 157 */       this.conversionService = conversionService;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 162 */       return Collections.singleton(new GenericConverter.ConvertiblePair(this.fieldType, String.class));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object convert(@Nullable Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 168 */       if (!sourceType.isAssignableTo(this.printerObjectType)) {
/* 169 */         source = this.conversionService.convert(source, sourceType, this.printerObjectType);
/*     */       }
/* 171 */       if (source == null) {
/* 172 */         return "";
/*     */       }
/* 174 */       return this.printer.print(source, LocaleContextHolder.getLocale());
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private Class<?> resolvePrinterObjectType(Printer<?> printer) {
/* 179 */       return GenericTypeResolver.resolveTypeArgument(printer.getClass(), Printer.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 184 */       return this.fieldType.getName() + " -> " + this.fieldType.getName() + " : " + String.class.getName();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ParserConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private final Class<?> fieldType;
/*     */     
/*     */     private final Parser<?> parser;
/*     */     private final ConversionService conversionService;
/*     */     
/*     */     public ParserConverter(Class<?> fieldType, Parser<?> parser, ConversionService conversionService) {
/* 198 */       this.fieldType = fieldType;
/* 199 */       this.parser = parser;
/* 200 */       this.conversionService = conversionService;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 205 */       return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, this.fieldType));
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Object convert(@Nullable Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/*     */       Object result;
/* 211 */       String text = (String)source;
/* 212 */       if (!StringUtils.hasText(text)) {
/* 213 */         return null;
/*     */       }
/*     */       
/*     */       try {
/* 217 */         result = this.parser.parse(text, LocaleContextHolder.getLocale());
/*     */       }
/* 219 */       catch (IllegalArgumentException ex) {
/* 220 */         throw ex;
/*     */       }
/* 222 */       catch (Throwable ex) {
/* 223 */         throw new IllegalArgumentException("Parse attempt failed for value [" + text + "]", ex);
/*     */       } 
/* 225 */       TypeDescriptor resultType = TypeDescriptor.valueOf(result.getClass());
/* 226 */       if (!resultType.isAssignableTo(targetType)) {
/* 227 */         result = this.conversionService.convert(result, resultType, targetType);
/*     */       }
/* 229 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 234 */       return String.class.getName() + " -> " + String.class.getName() + ": " + this.fieldType.getName();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class AnnotationPrinterConverter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private final Class<? extends Annotation> annotationType;
/*     */     
/*     */     private final AnnotationFormatterFactory annotationFormatterFactory;
/*     */     
/*     */     private final Class<?> fieldType;
/*     */ 
/*     */     
/*     */     public AnnotationPrinterConverter(Class<? extends Annotation> annotationType, AnnotationFormatterFactory<?> annotationFormatterFactory, Class<?> fieldType) {
/* 251 */       this.annotationType = annotationType;
/* 252 */       this.annotationFormatterFactory = annotationFormatterFactory;
/* 253 */       this.fieldType = fieldType;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 258 */       return Collections.singleton(new GenericConverter.ConvertiblePair(this.fieldType, String.class));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 263 */       return sourceType.hasAnnotation(this.annotationType);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object convert(@Nullable Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 270 */       Annotation ann = sourceType.getAnnotation(this.annotationType);
/* 271 */       if (ann == null) {
/* 272 */         throw new IllegalStateException("Expected [" + this.annotationType
/* 273 */             .getName() + "] to be present on " + String.valueOf(sourceType));
/*     */       }
/* 275 */       FormattingConversionService.AnnotationConverterKey converterKey = new FormattingConversionService.AnnotationConverterKey(ann, sourceType.getObjectType());
/* 276 */       GenericConverter converter = FormattingConversionService.this.cachedPrinters.get(converterKey);
/* 277 */       if (converter == null) {
/* 278 */         Printer<?> printer = this.annotationFormatterFactory.getPrinter(converterKey
/* 279 */             .getAnnotation(), converterKey.getFieldType());
/* 280 */         converter = new FormattingConversionService.PrinterConverter(this.fieldType, printer, (ConversionService)FormattingConversionService.this);
/* 281 */         FormattingConversionService.this.cachedPrinters.put(converterKey, converter);
/*     */       } 
/* 283 */       return converter.convert(source, sourceType, targetType);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 288 */       return "@" + this.annotationType.getName() + " " + this.fieldType.getName() + " -> " + String.class
/* 289 */         .getName() + ": " + String.valueOf(this.annotationFormatterFactory);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class AnnotationParserConverter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private final Class<? extends Annotation> annotationType;
/*     */     
/*     */     private final AnnotationFormatterFactory annotationFormatterFactory;
/*     */     
/*     */     private final Class<?> fieldType;
/*     */ 
/*     */     
/*     */     public AnnotationParserConverter(Class<? extends Annotation> annotationType, AnnotationFormatterFactory<?> annotationFormatterFactory, Class<?> fieldType) {
/* 306 */       this.annotationType = annotationType;
/* 307 */       this.annotationFormatterFactory = annotationFormatterFactory;
/* 308 */       this.fieldType = fieldType;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 313 */       return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, this.fieldType));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 318 */       return targetType.hasAnnotation(this.annotationType);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object convert(@Nullable Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 325 */       Annotation ann = targetType.getAnnotation(this.annotationType);
/* 326 */       if (ann == null) {
/* 327 */         throw new IllegalStateException("Expected [" + this.annotationType
/* 328 */             .getName() + "] to be present on " + String.valueOf(targetType));
/*     */       }
/* 330 */       FormattingConversionService.AnnotationConverterKey converterKey = new FormattingConversionService.AnnotationConverterKey(ann, targetType.getObjectType());
/* 331 */       GenericConverter converter = FormattingConversionService.this.cachedParsers.get(converterKey);
/* 332 */       if (converter == null) {
/* 333 */         Parser<?> parser = this.annotationFormatterFactory.getParser(converterKey
/* 334 */             .getAnnotation(), converterKey.getFieldType());
/* 335 */         converter = new FormattingConversionService.ParserConverter(this.fieldType, parser, (ConversionService)FormattingConversionService.this);
/* 336 */         FormattingConversionService.this.cachedParsers.put(converterKey, converter);
/*     */       } 
/* 338 */       return converter.convert(source, sourceType, targetType);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 343 */       return String.class.getName() + " -> @" + String.class.getName() + " " + this.annotationType.getName() + ": " + this.fieldType
/* 344 */         .getName();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class AnnotationConverterKey
/*     */   {
/*     */     private final Annotation annotation;
/*     */     
/*     */     private final Class<?> fieldType;
/*     */     
/*     */     public AnnotationConverterKey(Annotation annotation, Class<?> fieldType) {
/* 356 */       this.annotation = annotation;
/* 357 */       this.fieldType = fieldType;
/*     */     }
/*     */     
/*     */     public Annotation getAnnotation() {
/* 361 */       return this.annotation;
/*     */     }
/*     */     
/*     */     public Class<?> getFieldType() {
/* 365 */       return this.fieldType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 370 */       if (this != other) { if (other instanceof AnnotationConverterKey) { AnnotationConverterKey that = (AnnotationConverterKey)other; if (this.fieldType == that.fieldType && this.annotation
/* 371 */             .equals(that.annotation)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 376 */       return this.fieldType.hashCode() * 29 + this.annotation.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\support\FormattingConversionService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */