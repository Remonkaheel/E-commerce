/*     */ package org.springframework.format.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ParserConverter
/*     */   implements GenericConverter
/*     */ {
/*     */   private final Class<?> fieldType;
/*     */   private final Parser<?> parser;
/*     */   private final ConversionService conversionService;
/*     */   
/*     */   public ParserConverter(Class<?> fieldType, Parser<?> parser, ConversionService conversionService) {
/* 198 */     this.fieldType = fieldType;
/* 199 */     this.parser = parser;
/* 200 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 205 */     return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, this.fieldType));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Object convert(@Nullable Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/*     */     Object result;
/* 211 */     String text = (String)source;
/* 212 */     if (!StringUtils.hasText(text)) {
/* 213 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 217 */       result = this.parser.parse(text, LocaleContextHolder.getLocale());
/*     */     }
/* 219 */     catch (IllegalArgumentException ex) {
/* 220 */       throw ex;
/*     */     }
/* 222 */     catch (Throwable ex) {
/* 223 */       throw new IllegalArgumentException("Parse attempt failed for value [" + text + "]", ex);
/*     */     } 
/* 225 */     TypeDescriptor resultType = TypeDescriptor.valueOf(result.getClass());
/* 226 */     if (!resultType.isAssignableTo(targetType)) {
/* 227 */       result = this.conversionService.convert(result, resultType, targetType);
/*     */     }
/* 229 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 234 */     return String.class.getName() + " -> " + String.class.getName() + ": " + this.fieldType.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\support\FormattingConversionService$ParserConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */