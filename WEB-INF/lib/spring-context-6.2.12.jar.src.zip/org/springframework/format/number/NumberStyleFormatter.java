/*    */ package org.springframework.format.number;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import java.text.NumberFormat;
/*    */ import java.util.Locale;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NumberStyleFormatter
/*    */   extends AbstractNumberFormatter
/*    */ {
/*    */   @Nullable
/*    */   private String pattern;
/*    */   
/*    */   public NumberStyleFormatter() {}
/*    */   
/*    */   public NumberStyleFormatter(String pattern) {
/* 57 */     this.pattern = pattern;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPattern(String pattern) {
/* 67 */     this.pattern = pattern;
/*    */   }
/*    */ 
/*    */   
/*    */   public NumberFormat getNumberFormat(Locale locale) {
/*    */     DecimalFormat decimalFormat;
/* 73 */     NumberFormat format = NumberFormat.getInstance(locale);
/* 74 */     if (format instanceof DecimalFormat) { decimalFormat = (DecimalFormat)format; }
/* 75 */     else { if (this.pattern != null) {
/* 76 */         throw new IllegalStateException("Cannot support pattern for non-DecimalFormat: " + String.valueOf(format));
/*    */       }
/* 78 */       return format; }
/*    */     
/* 80 */     decimalFormat.setParseBigDecimal(true);
/* 81 */     if (this.pattern != null) {
/* 82 */       decimalFormat.applyPattern(this.pattern);
/*    */     }
/* 84 */     return decimalFormat;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\number\NumberStyleFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */