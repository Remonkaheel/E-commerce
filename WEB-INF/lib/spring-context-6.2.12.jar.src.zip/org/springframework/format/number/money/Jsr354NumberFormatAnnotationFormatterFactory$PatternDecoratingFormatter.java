/*     */ package org.springframework.format.number.money;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.util.Currency;
/*     */ import java.util.Locale;
/*     */ import javax.money.CurrencyUnit;
/*     */ import javax.money.Monetary;
/*     */ import javax.money.MonetaryAmount;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.number.CurrencyStyleFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PatternDecoratingFormatter
/*     */   implements Formatter<MonetaryAmount>
/*     */ {
/*     */   private final String pattern;
/*     */   
/*     */   public PatternDecoratingFormatter(String pattern) {
/* 118 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */   
/*     */   public String print(MonetaryAmount object, Locale locale) {
/* 123 */     CurrencyStyleFormatter formatter = new CurrencyStyleFormatter();
/* 124 */     formatter.setCurrency(Currency.getInstance(object.getCurrency().getCurrencyCode()));
/* 125 */     formatter.setPattern(this.pattern);
/* 126 */     return formatter.print((Number)object.getNumber(), locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public MonetaryAmount parse(String text, Locale locale) throws ParseException {
/* 131 */     CurrencyStyleFormatter formatter = new CurrencyStyleFormatter();
/* 132 */     Currency currency = determineCurrency(text, locale);
/* 133 */     CurrencyUnit currencyUnit = Monetary.getCurrency(currency.getCurrencyCode(), new String[0]);
/* 134 */     formatter.setCurrency(currency);
/* 135 */     formatter.setPattern(this.pattern);
/* 136 */     Number numberValue = formatter.parse(text, locale);
/* 137 */     return Monetary.getDefaultAmountFactory().setNumber(numberValue).setCurrency(currencyUnit).create();
/*     */   }
/*     */   
/*     */   private Currency determineCurrency(String text, Locale locale) {
/*     */     try {
/* 142 */       if (text.length() < 3)
/*     */       {
/*     */         
/* 145 */         return Currency.getInstance(locale);
/*     */       }
/* 147 */       if (this.pattern.startsWith("¤¤")) {
/* 148 */         return Currency.getInstance(text.substring(0, 3));
/*     */       }
/* 150 */       if (this.pattern.endsWith("¤¤")) {
/* 151 */         return Currency.getInstance(text.substring(text.length() - 3));
/*     */       }
/*     */ 
/*     */       
/* 155 */       return Currency.getInstance(locale);
/*     */     
/*     */     }
/* 158 */     catch (IllegalArgumentException ex) {
/* 159 */       throw new IllegalArgumentException("Cannot determine currency for number value [" + text + "]", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\number\money\Jsr354NumberFormatAnnotationFormatterFactory$PatternDecoratingFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */