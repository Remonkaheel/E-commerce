/*     */ package org.springframework.format.number.money;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ import javax.money.CurrencyUnit;
/*     */ import javax.money.Monetary;
/*     */ import javax.money.MonetaryAmount;
/*     */ import org.springframework.format.Formatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NumberDecoratingFormatter
/*     */   implements Formatter<MonetaryAmount>
/*     */ {
/*     */   private final Formatter<Number> numberFormatter;
/*     */   
/*     */   public NumberDecoratingFormatter(Formatter<Number> numberFormatter) {
/*  96 */     this.numberFormatter = numberFormatter;
/*     */   }
/*     */ 
/*     */   
/*     */   public String print(MonetaryAmount object, Locale locale) {
/* 101 */     return this.numberFormatter.print(object.getNumber(), locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public MonetaryAmount parse(String text, Locale locale) throws ParseException {
/* 106 */     CurrencyUnit currencyUnit = Monetary.getCurrency(locale, new String[0]);
/* 107 */     Number numberValue = (Number)this.numberFormatter.parse(text, locale);
/* 108 */     return Monetary.getDefaultAmountFactory().setNumber(numberValue).setCurrency(currencyUnit).create();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\number\money\Jsr354NumberFormatAnnotationFormatterFactory$NumberDecoratingFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */