/*    */ package org.springframework.format.number;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import java.text.NumberFormat;
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PercentStyleFormatter
/*    */   extends AbstractNumberFormatter
/*    */ {
/*    */   protected NumberFormat getNumberFormat(Locale locale) {
/* 39 */     NumberFormat format = NumberFormat.getPercentInstance(locale);
/* 40 */     if (format instanceof DecimalFormat) { DecimalFormat decimalFormat = (DecimalFormat)format;
/* 41 */       decimalFormat.setParseBigDecimal(true); }
/*    */     
/* 43 */     return format;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\number\PercentStyleFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */