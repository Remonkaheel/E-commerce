/*    */ package org.springframework.format.datetime;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.context.support.EmbeddedValueResolutionSupport;
/*    */ import org.springframework.format.AnnotationFormatterFactory;
/*    */ import org.springframework.format.Formatter;
/*    */ import org.springframework.format.Parser;
/*    */ import org.springframework.format.Printer;
/*    */ import org.springframework.format.annotation.DateTimeFormat;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateTimeFormatAnnotationFormatterFactory
/*    */   extends EmbeddedValueResolutionSupport
/*    */   implements AnnotationFormatterFactory<DateTimeFormat>
/*    */ {
/* 43 */   private static final Set<Class<?>> FIELD_TYPES = Set.of(Date.class, Calendar.class, Long.class);
/*    */ 
/*    */   
/*    */   public Set<Class<?>> getFieldTypes() {
/* 47 */     return FIELD_TYPES;
/*    */   }
/*    */ 
/*    */   
/*    */   public Printer<?> getPrinter(DateTimeFormat annotation, Class<?> fieldType) {
/* 52 */     return (Printer<?>)getFormatter(annotation, fieldType);
/*    */   }
/*    */ 
/*    */   
/*    */   public Parser<?> getParser(DateTimeFormat annotation, Class<?> fieldType) {
/* 57 */     return (Parser<?>)getFormatter(annotation, fieldType);
/*    */   }
/*    */   
/*    */   protected Formatter<Date> getFormatter(DateTimeFormat annotation, Class<?> fieldType) {
/* 61 */     DateFormatter formatter = new DateFormatter();
/* 62 */     formatter.setSource(annotation);
/* 63 */     formatter.setIso(annotation.iso());
/*    */     
/* 65 */     String style = resolveEmbeddedValue(annotation.style());
/* 66 */     if (StringUtils.hasLength(style)) {
/* 67 */       formatter.setStylePattern(style);
/*    */     }
/*    */     
/* 70 */     String pattern = resolveEmbeddedValue(annotation.pattern());
/* 71 */     if (StringUtils.hasLength(pattern)) {
/* 72 */       formatter.setPattern(pattern);
/*    */     }
/*    */     
/* 75 */     List<String> resolvedFallbackPatterns = new ArrayList<>();
/* 76 */     for (String fallbackPattern : annotation.fallbackPatterns()) {
/* 77 */       String resolvedFallbackPattern = resolveEmbeddedValue(fallbackPattern);
/* 78 */       if (StringUtils.hasLength(resolvedFallbackPattern)) {
/* 79 */         resolvedFallbackPatterns.add(resolvedFallbackPattern);
/*    */       }
/*    */     } 
/* 82 */     if (!resolvedFallbackPatterns.isEmpty()) {
/* 83 */       formatter.setFallbackPatterns(resolvedFallbackPatterns.<String>toArray(new String[0]));
/*    */     }
/*    */     
/* 86 */     return formatter;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\DateTimeFormatAnnotationFormatterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */