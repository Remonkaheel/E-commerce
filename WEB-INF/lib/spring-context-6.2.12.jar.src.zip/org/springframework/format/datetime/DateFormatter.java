/*     */ package org.springframework.format.datetime;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.EnumMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.annotation.DateTimeFormat;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateFormatter
/*     */   implements Formatter<Date>
/*     */ {
/*  57 */   private static final TimeZone UTC = TimeZone.getTimeZone("UTC"); private static final Map<DateTimeFormat.ISO, String> ISO_PATTERNS; private static final Map<DateTimeFormat.ISO, String> ISO_FALLBACK_PATTERNS; @Nullable
/*     */   private Object source;
/*     */   @Nullable
/*     */   private String pattern;
/*     */   @Nullable
/*     */   private String[] fallbackPatterns;
/*     */   
/*     */   static {
/*  65 */     Map<DateTimeFormat.ISO, String> formats = new EnumMap<>(DateTimeFormat.ISO.class);
/*  66 */     formats.put(DateTimeFormat.ISO.DATE, "yyyy-MM-dd");
/*  67 */     formats.put(DateTimeFormat.ISO.TIME, "HH:mm:ss.SSSXXX");
/*  68 */     formats.put(DateTimeFormat.ISO.DATE_TIME, "yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
/*  69 */     ISO_PATTERNS = Collections.unmodifiableMap(formats);
/*     */ 
/*     */     
/*  72 */     Map<DateTimeFormat.ISO, String> fallbackFormats = new EnumMap<>(DateTimeFormat.ISO.class);
/*  73 */     fallbackFormats.put(DateTimeFormat.ISO.TIME, "HH:mm:ssXXX");
/*  74 */     fallbackFormats.put(DateTimeFormat.ISO.DATE_TIME, "yyyy-MM-dd'T'HH:mm:ssXXX");
/*  75 */     ISO_FALLBACK_PATTERNS = Collections.unmodifiableMap(fallbackFormats);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private int style = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String stylePattern;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private DateTimeFormat.ISO iso;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TimeZone timeZone;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean lenient = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public DateFormatter(String pattern) {
/* 112 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(Object source) {
/* 127 */     this.source = source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPattern(String pattern) {
/* 135 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFallbackPatterns(String... fallbackPatterns) {
/* 147 */     this.fallbackPatterns = fallbackPatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIso(DateTimeFormat.ISO iso) {
/* 156 */     this.iso = iso;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStyle(int style) {
/* 169 */     this.style = style;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStylePattern(String stylePattern) {
/* 188 */     this.stylePattern = stylePattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeZone(TimeZone timeZone) {
/* 195 */     this.timeZone = timeZone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLenient(boolean lenient) {
/* 204 */     this.lenient = lenient;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String print(Date date, Locale locale) {
/* 210 */     return getDateFormat(locale).format(date);
/*     */   }
/*     */ 
/*     */   
/*     */   public Date parse(String text, Locale locale) throws ParseException {
/*     */     try {
/* 216 */       return getDateFormat(locale).parse(text);
/*     */     }
/* 218 */     catch (ParseException ex) {
/* 219 */       Set<String> fallbackPatterns = new LinkedHashSet<>();
/* 220 */       String isoPattern = ISO_FALLBACK_PATTERNS.get(this.iso);
/* 221 */       if (isoPattern != null) {
/* 222 */         fallbackPatterns.add(isoPattern);
/*     */       }
/* 224 */       if (!ObjectUtils.isEmpty((Object[])this.fallbackPatterns)) {
/* 225 */         Collections.addAll(fallbackPatterns, this.fallbackPatterns);
/*     */       }
/* 227 */       if (!fallbackPatterns.isEmpty()) {
/* 228 */         for (String pattern : fallbackPatterns) {
/*     */           try {
/* 230 */             DateFormat dateFormat = configureDateFormat(new SimpleDateFormat(pattern, locale));
/*     */             
/* 232 */             if (this.iso != null && this.iso != DateTimeFormat.ISO.NONE) {
/* 233 */               dateFormat.setTimeZone(UTC);
/*     */             }
/* 235 */             return dateFormat.parse(text);
/*     */           }
/* 237 */           catch (ParseException parseException) {}
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 244 */       if (this.source != null) {
/*     */ 
/*     */         
/* 247 */         ParseException parseException = new ParseException(String.format("Unable to parse date time value \"%s\" using configuration from %s", new Object[] { text, this.source }), ex.getErrorOffset());
/* 248 */         parseException.initCause(ex);
/* 249 */         throw parseException;
/*     */       } 
/*     */       
/* 252 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected DateFormat getDateFormat(Locale locale) {
/* 258 */     return configureDateFormat(createDateFormat(locale));
/*     */   }
/*     */   
/*     */   private DateFormat configureDateFormat(DateFormat dateFormat) {
/* 262 */     if (this.timeZone != null) {
/* 263 */       dateFormat.setTimeZone(this.timeZone);
/*     */     }
/* 265 */     dateFormat.setLenient(this.lenient);
/* 266 */     return dateFormat;
/*     */   }
/*     */   
/*     */   private DateFormat createDateFormat(Locale locale) {
/* 270 */     if (StringUtils.hasLength(this.pattern)) {
/* 271 */       return new SimpleDateFormat(this.pattern, locale);
/*     */     }
/* 273 */     if (this.iso != null && this.iso != DateTimeFormat.ISO.NONE) {
/* 274 */       String pattern = ISO_PATTERNS.get(this.iso);
/* 275 */       if (pattern == null) {
/* 276 */         throw new IllegalStateException("Unsupported ISO format " + String.valueOf(this.iso));
/*     */       }
/* 278 */       SimpleDateFormat format = new SimpleDateFormat(pattern);
/* 279 */       format.setTimeZone(UTC);
/* 280 */       return format;
/*     */     } 
/* 282 */     if (StringUtils.hasLength(this.stylePattern)) {
/* 283 */       int dateStyle = getStylePatternForChar(0);
/* 284 */       int timeStyle = getStylePatternForChar(1);
/* 285 */       if (dateStyle != -1 && timeStyle != -1) {
/* 286 */         return DateFormat.getDateTimeInstance(dateStyle, timeStyle, locale);
/*     */       }
/* 288 */       if (dateStyle != -1) {
/* 289 */         return DateFormat.getDateInstance(dateStyle, locale);
/*     */       }
/* 291 */       if (timeStyle != -1) {
/* 292 */         return DateFormat.getTimeInstance(timeStyle, locale);
/*     */       }
/* 294 */       throw unsupportedStylePatternException();
/*     */     } 
/*     */     
/* 297 */     return DateFormat.getDateInstance(this.style, locale);
/*     */   }
/*     */   
/*     */   private int getStylePatternForChar(int index) {
/* 301 */     if (this.stylePattern != null && this.stylePattern.length() > index) {
/* 302 */       char ch = this.stylePattern.charAt(index);
/* 303 */       switch (ch) { case 'S': 
/*     */         case 'M': 
/*     */         case 'L': 
/*     */         case 'F':
/*     */         
/*     */         case '-':
/* 309 */          }  throw unsupportedStylePatternException();
/*     */     } 
/*     */     
/* 312 */     throw unsupportedStylePatternException();
/*     */   }
/*     */   
/*     */   private IllegalStateException unsupportedStylePatternException() {
/* 316 */     return new IllegalStateException("Unsupported style pattern '" + this.stylePattern + "'");
/*     */   }
/*     */   
/*     */   public DateFormatter() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\DateFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */