/*    */ package org.springframework.format.datetime.standard;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.time.Duration;
/*    */ import java.util.Set;
/*    */ import org.springframework.context.support.EmbeddedValueResolutionSupport;
/*    */ import org.springframework.format.AnnotationFormatterFactory;
/*    */ import org.springframework.format.Parser;
/*    */ import org.springframework.format.Printer;
/*    */ import org.springframework.format.annotation.DurationFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DurationFormatAnnotationFormatterFactory
/*    */   extends EmbeddedValueResolutionSupport
/*    */   implements AnnotationFormatterFactory<DurationFormat>
/*    */ {
/* 41 */   private static final Set<Class<?>> FIELD_TYPES = Set.of(Duration.class);
/*    */ 
/*    */   
/*    */   public final Set<Class<?>> getFieldTypes() {
/* 45 */     return FIELD_TYPES;
/*    */   }
/*    */ 
/*    */   
/*    */   public Printer<?> getPrinter(DurationFormat annotation, Class<?> fieldType) {
/* 50 */     return (Printer<?>)new DurationFormatter(annotation.style(), annotation.defaultUnit());
/*    */   }
/*    */ 
/*    */   
/*    */   public Parser<?> getParser(DurationFormat annotation, Class<?> fieldType) {
/* 55 */     return (Parser<?>)new DurationFormatter(annotation.style(), annotation.defaultUnit());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\standard\DurationFormatAnnotationFormatterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */