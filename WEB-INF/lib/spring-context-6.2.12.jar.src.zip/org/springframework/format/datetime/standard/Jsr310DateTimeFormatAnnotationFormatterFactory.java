/*     */ package org.springframework.format.datetime.standard;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.MonthDay;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.YearMonth;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.support.EmbeddedValueResolutionSupport;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.format.annotation.DateTimeFormat;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jsr310DateTimeFormatAnnotationFormatterFactory
/*     */   extends EmbeddedValueResolutionSupport
/*     */   implements AnnotationFormatterFactory<DateTimeFormat>
/*     */ {
/*  55 */   private static final Set<Class<?>> FIELD_TYPES = Set.of(Instant.class, LocalDate.class, LocalTime.class, LocalDateTime.class, ZonedDateTime.class, OffsetDateTime.class, OffsetTime.class, YearMonth.class, MonthDay.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Set<Class<?>> getFieldTypes() {
/*  68 */     return FIELD_TYPES;
/*     */   }
/*     */ 
/*     */   
/*     */   public Printer<?> getPrinter(DateTimeFormat annotation, Class<?> fieldType) {
/*  73 */     DateTimeFormatter formatter = getFormatter(annotation, fieldType);
/*     */ 
/*     */     
/*  76 */     if (formatter == DateTimeFormatter.ISO_DATE) {
/*  77 */       if (isLocal(fieldType)) {
/*  78 */         formatter = DateTimeFormatter.ISO_LOCAL_DATE;
/*     */       }
/*     */     }
/*  81 */     else if (formatter == DateTimeFormatter.ISO_TIME) {
/*  82 */       if (isLocal(fieldType)) {
/*  83 */         formatter = DateTimeFormatter.ISO_LOCAL_TIME;
/*     */       }
/*     */     }
/*  86 */     else if (formatter == DateTimeFormatter.ISO_DATE_TIME && 
/*  87 */       isLocal(fieldType)) {
/*  88 */       formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
/*     */     } 
/*     */ 
/*     */     
/*  92 */     return new TemporalAccessorPrinter(formatter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Parser<?> getParser(DateTimeFormat annotation, Class<?> fieldType) {
/*  98 */     DateTimeFormatter formatter = getFormatter(annotation, fieldType);
/*     */     
/* 100 */     List<String> resolvedFallbackPatterns = new ArrayList<>();
/* 101 */     for (String fallbackPattern : annotation.fallbackPatterns()) {
/* 102 */       String resolvedFallbackPattern = resolveEmbeddedValue(fallbackPattern);
/* 103 */       if (StringUtils.hasLength(resolvedFallbackPattern)) {
/* 104 */         resolvedFallbackPatterns.add(resolvedFallbackPattern);
/*     */       }
/*     */     } 
/*     */     
/* 108 */     return new TemporalAccessorParser((Class)fieldType, formatter, resolvedFallbackPatterns
/* 109 */         .<String>toArray(new String[0]), annotation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DateTimeFormatter getFormatter(DateTimeFormat annotation, Class<?> fieldType) {
/* 119 */     DateTimeFormatterFactory factory = new DateTimeFormatterFactory();
/* 120 */     String style = resolveEmbeddedValue(annotation.style());
/* 121 */     if (StringUtils.hasLength(style)) {
/* 122 */       factory.setStylePattern(style);
/*     */     }
/* 124 */     factory.setIso(annotation.iso());
/* 125 */     String pattern = resolveEmbeddedValue(annotation.pattern());
/* 126 */     if (StringUtils.hasLength(pattern)) {
/* 127 */       factory.setPattern(pattern);
/*     */     }
/* 129 */     return factory.createDateTimeFormatter();
/*     */   }
/*     */   
/*     */   private boolean isLocal(Class<?> fieldType) {
/* 133 */     return fieldType.getSimpleName().startsWith("Local");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\standard\Jsr310DateTimeFormatAnnotationFormatterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */