/*     */ package org.springframework.format.datetime.standard;


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\standard\DateTimeFormatterRegistrar$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */