/*    */ package org.springframework.format.datetime.standard;
/*    */ 
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateTimeFormatterFactoryBean
/*    */   extends DateTimeFormatterFactory
/*    */   implements FactoryBean<DateTimeFormatter>, InitializingBean
/*    */ {
/*    */   @Nullable
/*    */   private DateTimeFormatter dateTimeFormatter;
/*    */   
/*    */   public void afterPropertiesSet() {
/* 46 */     this.dateTimeFormatter = createDateTimeFormatter();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public DateTimeFormatter getObject() {
/* 52 */     return this.dateTimeFormatter;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getObjectType() {
/* 57 */     return DateTimeFormatter.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSingleton() {
/* 62 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\standard\DateTimeFormatterFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */