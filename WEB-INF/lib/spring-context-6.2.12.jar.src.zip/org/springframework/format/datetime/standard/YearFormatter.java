/*    */ package org.springframework.format.datetime.standard;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.time.Year;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class YearFormatter
/*    */   implements Formatter<Year>
/*    */ {
/*    */   public Year parse(String text, Locale locale) throws ParseException {
/* 37 */     return Year.parse(text);
/*    */   }
/*    */ 
/*    */   
/*    */   public String print(Year object, Locale locale) {
/* 42 */     return object.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\standard\YearFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */