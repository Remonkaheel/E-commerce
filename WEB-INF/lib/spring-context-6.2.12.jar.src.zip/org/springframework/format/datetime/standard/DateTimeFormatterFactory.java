/*     */ package org.springframework.format.datetime.standard;
/*     */ 
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.FormatStyle;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.format.annotation.DateTimeFormat;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateTimeFormatterFactory
/*     */ {
/*     */   @Nullable
/*     */   private String pattern;
/*     */   @Nullable
/*     */   private DateTimeFormat.ISO iso;
/*     */   @Nullable
/*     */   private FormatStyle dateStyle;
/*     */   @Nullable
/*     */   private FormatStyle timeStyle;
/*     */   @Nullable
/*     */   private TimeZone timeZone;
/*     */   
/*     */   public DateTimeFormatterFactory() {}
/*     */   
/*     */   public DateTimeFormatterFactory(String pattern) {
/*  76 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPattern(String pattern) {
/*  85 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIso(DateTimeFormat.ISO iso) {
/*  93 */     this.iso = iso;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDateStyle(FormatStyle dateStyle) {
/* 100 */     this.dateStyle = dateStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeStyle(FormatStyle timeStyle) {
/* 107 */     this.timeStyle = timeStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDateTimeStyle(FormatStyle dateTimeStyle) {
/* 114 */     this.dateStyle = dateTimeStyle;
/* 115 */     this.timeStyle = dateTimeStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStylePattern(String style) {
/* 135 */     Assert.isTrue((style.length() == 2), "Style pattern must consist of two characters");
/* 136 */     this.dateStyle = convertStyleCharacter(style.charAt(0));
/* 137 */     this.timeStyle = convertStyleCharacter(style.charAt(1));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private FormatStyle convertStyleCharacter(char c) {
/* 142 */     switch (c) { case 'S': 
/*     */       case 'M': 
/*     */       case 'L': 
/*     */       case 'F':
/*     */       
/*     */       case '-':
/* 148 */        }  throw new IllegalArgumentException("Invalid style character '" + c + "'");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeZone(TimeZone timeZone) {
/* 157 */     this.timeZone = timeZone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTimeFormatter createDateTimeFormatter() {
/* 169 */     return createDateTimeFormatter(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM));
/*     */   }
/*     */   
/*     */   public DateTimeFormatter createDateTimeFormatter(DateTimeFormatter fallbackFormatter) {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: aload_0
/*     */     //   3: getfield pattern : Ljava/lang/String;
/*     */     //   6: invokestatic hasLength : (Ljava/lang/String;)Z
/*     */     //   9: ifeq -> 23
/*     */     //   12: aload_0
/*     */     //   13: getfield pattern : Ljava/lang/String;
/*     */     //   16: invokestatic createStrictDateTimeFormatter : (Ljava/lang/String;)Ljava/time/format/DateTimeFormatter;
/*     */     //   19: astore_2
/*     */     //   20: goto -> 180
/*     */     //   23: aload_0
/*     */     //   24: getfield iso : Lorg/springframework/format/annotation/DateTimeFormat$ISO;
/*     */     //   27: ifnull -> 118
/*     */     //   30: aload_0
/*     */     //   31: getfield iso : Lorg/springframework/format/annotation/DateTimeFormat$ISO;
/*     */     //   34: getstatic org/springframework/format/annotation/DateTimeFormat$ISO.NONE : Lorg/springframework/format/annotation/DateTimeFormat$ISO;
/*     */     //   37: if_acmpeq -> 118
/*     */     //   40: getstatic org/springframework/format/datetime/standard/DateTimeFormatterFactory$1.$SwitchMap$org$springframework$format$annotation$DateTimeFormat$ISO : [I
/*     */     //   43: aload_0
/*     */     //   44: getfield iso : Lorg/springframework/format/annotation/DateTimeFormat$ISO;
/*     */     //   47: invokevirtual ordinal : ()I
/*     */     //   50: iaload
/*     */     //   51: tableswitch default -> 94, 1 -> 76, 2 -> 82, 3 -> 88
/*     */     //   76: getstatic java/time/format/DateTimeFormatter.ISO_DATE : Ljava/time/format/DateTimeFormatter;
/*     */     //   79: goto -> 114
/*     */     //   82: getstatic java/time/format/DateTimeFormatter.ISO_TIME : Ljava/time/format/DateTimeFormatter;
/*     */     //   85: goto -> 114
/*     */     //   88: getstatic java/time/format/DateTimeFormatter.ISO_DATE_TIME : Ljava/time/format/DateTimeFormatter;
/*     */     //   91: goto -> 114
/*     */     //   94: new java/lang/IllegalStateException
/*     */     //   97: dup
/*     */     //   98: aload_0
/*     */     //   99: getfield iso : Lorg/springframework/format/annotation/DateTimeFormat$ISO;
/*     */     //   102: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   105: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   110: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   113: athrow
/*     */     //   114: astore_2
/*     */     //   115: goto -> 180
/*     */     //   118: aload_0
/*     */     //   119: getfield dateStyle : Ljava/time/format/FormatStyle;
/*     */     //   122: ifnull -> 147
/*     */     //   125: aload_0
/*     */     //   126: getfield timeStyle : Ljava/time/format/FormatStyle;
/*     */     //   129: ifnull -> 147
/*     */     //   132: aload_0
/*     */     //   133: getfield dateStyle : Ljava/time/format/FormatStyle;
/*     */     //   136: aload_0
/*     */     //   137: getfield timeStyle : Ljava/time/format/FormatStyle;
/*     */     //   140: invokestatic ofLocalizedDateTime : (Ljava/time/format/FormatStyle;Ljava/time/format/FormatStyle;)Ljava/time/format/DateTimeFormatter;
/*     */     //   143: astore_2
/*     */     //   144: goto -> 180
/*     */     //   147: aload_0
/*     */     //   148: getfield dateStyle : Ljava/time/format/FormatStyle;
/*     */     //   151: ifnull -> 165
/*     */     //   154: aload_0
/*     */     //   155: getfield dateStyle : Ljava/time/format/FormatStyle;
/*     */     //   158: invokestatic ofLocalizedDate : (Ljava/time/format/FormatStyle;)Ljava/time/format/DateTimeFormatter;
/*     */     //   161: astore_2
/*     */     //   162: goto -> 180
/*     */     //   165: aload_0
/*     */     //   166: getfield timeStyle : Ljava/time/format/FormatStyle;
/*     */     //   169: ifnull -> 180
/*     */     //   172: aload_0
/*     */     //   173: getfield timeStyle : Ljava/time/format/FormatStyle;
/*     */     //   176: invokestatic ofLocalizedTime : (Ljava/time/format/FormatStyle;)Ljava/time/format/DateTimeFormatter;
/*     */     //   179: astore_2
/*     */     //   180: aload_2
/*     */     //   181: ifnull -> 203
/*     */     //   184: aload_0
/*     */     //   185: getfield timeZone : Ljava/util/TimeZone;
/*     */     //   188: ifnull -> 203
/*     */     //   191: aload_2
/*     */     //   192: aload_0
/*     */     //   193: getfield timeZone : Ljava/util/TimeZone;
/*     */     //   196: invokevirtual toZoneId : ()Ljava/time/ZoneId;
/*     */     //   199: invokevirtual withZone : (Ljava/time/ZoneId;)Ljava/time/format/DateTimeFormatter;
/*     */     //   202: astore_2
/*     */     //   203: aload_2
/*     */     //   204: ifnull -> 211
/*     */     //   207: aload_2
/*     */     //   208: goto -> 212
/*     */     //   211: aload_1
/*     */     //   212: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #181	-> 0
/*     */     //   #182	-> 2
/*     */     //   #183	-> 12
/*     */     //   #185	-> 23
/*     */     //   #186	-> 40
/*     */     //   #187	-> 76
/*     */     //   #188	-> 82
/*     */     //   #189	-> 88
/*     */     //   #190	-> 94
/*     */     //   #193	-> 118
/*     */     //   #194	-> 132
/*     */     //   #196	-> 147
/*     */     //   #197	-> 154
/*     */     //   #199	-> 165
/*     */     //   #200	-> 172
/*     */     //   #203	-> 180
/*     */     //   #204	-> 191
/*     */     //   #206	-> 203
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	213	0	this	Lorg/springframework/format/datetime/standard/DateTimeFormatterFactory;
/*     */     //   0	213	1	fallbackFormatter	Ljava/time/format/DateTimeFormatter;
/*     */     //   2	211	2	dateTimeFormatter	Ljava/time/format/DateTimeFormatter;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\standard\DateTimeFormatterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */