/*     */ package org.springframework.format.datetime.standard;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.format.annotation.DurationFormat;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DurationFormatterUtils
/*     */ {
/*  43 */   private static final Pattern ISO_8601_PATTERN = Pattern.compile("^[+-]?[pP].*$");
/*     */   
/*  45 */   private static final Pattern SIMPLE_PATTERN = Pattern.compile("^([+-]?\\d+)([a-zA-Z]{0,2})$");
/*     */   
/*  47 */   private static final Pattern COMPOSITE_PATTERN = Pattern.compile("^([+-]?)\\(?\\s?(\\d+d)?\\s?(\\d+h)?\\s?(\\d+m)?\\s?(\\d+s)?\\s?(\\d+ms)?\\s?(\\d+us)?\\s?(\\d+ns)?\\)?$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String print(Duration value, DurationFormat.Style style) {
/*  58 */     return print(value, style, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String print(Duration value, DurationFormat.Style style, @Nullable DurationFormat.Unit unit) {
/*  70 */     switch (style) { default: throw new IncompatibleClassChangeError();case ISO8601: case SIMPLE: case COMPOSITE: break; }  return 
/*     */ 
/*     */       
/*  73 */       printComposite(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Duration parse(String value, DurationFormat.Style style) {
/*  84 */     return parse(value, style, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Duration parse(String value, DurationFormat.Style style, @Nullable DurationFormat.Unit unit) {
/*  96 */     Assert.hasText(value, () -> "Value must not be empty");
/*  97 */     switch (style) { default: throw new IncompatibleClassChangeError();case ISO8601: case SIMPLE: case COMPOSITE: break; }  return 
/*     */ 
/*     */       
/* 100 */       parseComposite(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DurationFormat.Style detect(String value) {
/* 111 */     Assert.notNull(value, "Value must not be null");
/*     */     
/* 113 */     if (ISO_8601_PATTERN.matcher(value).matches()) {
/* 114 */       return DurationFormat.Style.ISO8601;
/*     */     }
/* 116 */     if (SIMPLE_PATTERN.matcher(value).matches()) {
/* 117 */       return DurationFormat.Style.SIMPLE;
/*     */     }
/* 119 */     if (COMPOSITE_PATTERN.matcher(value).matches()) {
/* 120 */       return DurationFormat.Style.COMPOSITE;
/*     */     }
/* 122 */     throw new IllegalArgumentException("'" + value + "' is not a valid duration, cannot detect any known style");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Duration detectAndParse(String value) {
/* 133 */     return detectAndParse(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Duration detectAndParse(String value, @Nullable DurationFormat.Unit unit) {
/* 146 */     return parse(value, detect(value), unit);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Duration parseIso8601(String value) {
/*     */     try {
/* 152 */       return Duration.parse(value);
/*     */     }
/* 154 */     catch (Exception ex) {
/* 155 */       throw new IllegalArgumentException("'" + value + "' is not a valid ISO-8601 duration", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String printSimple(Duration duration, @Nullable DurationFormat.Unit unit) {
/* 160 */     unit = (unit == null) ? DurationFormat.Unit.MILLIS : unit;
/* 161 */     return unit.print(duration);
/*     */   }
/*     */   
/*     */   private static Duration parseSimple(String text, @Nullable DurationFormat.Unit fallbackUnit) {
/*     */     try {
/* 166 */       Matcher matcher = SIMPLE_PATTERN.matcher(text);
/* 167 */       Assert.state(matcher.matches(), "Does not match simple duration pattern");
/* 168 */       String suffix = matcher.group(2);
/* 169 */       DurationFormat.Unit parsingUnit = (fallbackUnit == null) ? DurationFormat.Unit.MILLIS : fallbackUnit;
/* 170 */       if (StringUtils.hasLength(suffix)) {
/* 171 */         parsingUnit = DurationFormat.Unit.fromSuffix(suffix);
/*     */       }
/* 173 */       return parsingUnit.parse(matcher.group(1));
/*     */     }
/* 175 */     catch (Exception ex) {
/* 176 */       throw new IllegalArgumentException("'" + text + "' is not a valid simple duration", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String printComposite(Duration duration) {
/* 181 */     if (duration.isZero()) {
/* 182 */       return DurationFormat.Unit.SECONDS.print(duration);
/*     */     }
/* 184 */     StringBuilder result = new StringBuilder();
/* 185 */     if (duration.isNegative()) {
/* 186 */       result.append('-');
/* 187 */       duration = duration.negated();
/*     */     } 
/* 189 */     long days = duration.toDaysPart();
/* 190 */     if (days != 0L) {
/* 191 */       result.append(days).append(DurationFormat.Unit.DAYS.asSuffix());
/*     */     }
/* 193 */     int hours = duration.toHoursPart();
/* 194 */     if (hours != 0) {
/* 195 */       result.append(hours).append(DurationFormat.Unit.HOURS.asSuffix());
/*     */     }
/* 197 */     int minutes = duration.toMinutesPart();
/* 198 */     if (minutes != 0) {
/* 199 */       result.append(minutes).append(DurationFormat.Unit.MINUTES.asSuffix());
/*     */     }
/* 201 */     int seconds = duration.toSecondsPart();
/* 202 */     if (seconds != 0) {
/* 203 */       result.append(seconds).append(DurationFormat.Unit.SECONDS.asSuffix());
/*     */     }
/* 205 */     int millis = duration.toMillisPart();
/* 206 */     if (millis != 0) {
/* 207 */       result.append(millis).append(DurationFormat.Unit.MILLIS.asSuffix());
/*     */     }
/*     */     
/* 210 */     long nanos = duration.toNanosPart() - Duration.ofMillis(millis).toNanos();
/* 211 */     if (nanos != 0L) {
/* 212 */       long micros = nanos / 1000L;
/* 213 */       long remainder = nanos - micros * 1000L;
/* 214 */       if (micros > 0L) {
/* 215 */         result.append(micros).append(DurationFormat.Unit.MICROS.asSuffix());
/*     */       }
/* 217 */       if (remainder > 0L) {
/* 218 */         result.append(remainder).append(DurationFormat.Unit.NANOS.asSuffix());
/*     */       }
/*     */     } 
/* 221 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static Duration parseComposite(String text) {
/*     */     try {
/* 226 */       Matcher matcher = COMPOSITE_PATTERN.matcher(text);
/* 227 */       Assert.state((matcher.matches() && matcher.groupCount() > 1), "Does not match composite duration pattern");
/* 228 */       String sign = matcher.group(1);
/* 229 */       boolean negative = (sign != null && sign.equals("-"));
/*     */       
/* 231 */       Duration result = Duration.ZERO;
/* 232 */       DurationFormat.Unit[] units = DurationFormat.Unit.values();
/* 233 */       for (int i = 2; i < matcher.groupCount() + 1; i++) {
/* 234 */         String segment = matcher.group(i);
/* 235 */         if (StringUtils.hasText(segment)) {
/* 236 */           DurationFormat.Unit unit = units[units.length - i + 1];
/* 237 */           result = result.plus(unit.parse(segment.replace(unit.asSuffix(), "")));
/*     */         } 
/*     */       } 
/* 240 */       return negative ? result.negated() : result;
/*     */     }
/* 242 */     catch (Exception ex) {
/* 243 */       throw new IllegalArgumentException("'" + text + "' is not a valid composite duration", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\standard\DurationFormatterUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */