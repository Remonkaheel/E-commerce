/*    */ package org.springframework.format.datetime.standard;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.time.Instant;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InstantFormatter
/*    */   implements Formatter<Instant>
/*    */ {
/*    */   public Instant parse(String text, Locale locale) throws ParseException {
/*    */     try {
/* 45 */       return Instant.ofEpochMilli(Long.parseLong(text));
/*    */     }
/* 47 */     catch (NumberFormatException ex) {
/* 48 */       if (!text.isEmpty() && Character.isAlphabetic(text.charAt(0)))
/*    */       {
/* 50 */         return Instant.from(DateTimeFormatter.RFC_1123_DATE_TIME.parse(text));
/*    */       }
/*    */ 
/*    */       
/* 54 */       return Instant.parse(text);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String print(Instant object, Locale locale) {
/* 61 */     return object.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\standard\InstantFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */