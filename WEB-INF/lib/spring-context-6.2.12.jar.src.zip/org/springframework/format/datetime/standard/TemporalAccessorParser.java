/*     */ package org.springframework.format.datetime.standard;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.MonthDay;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.YearMonth;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeParseException;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Locale;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemporalAccessorParser
/*     */   implements Parser<TemporalAccessor>
/*     */ {
/*     */   private final Class<? extends TemporalAccessor> temporalAccessorType;
/*     */   private final DateTimeFormatter formatter;
/*     */   @Nullable
/*     */   private final String[] fallbackPatterns;
/*     */   @Nullable
/*     */   private final Object source;
/*     */   
/*     */   public TemporalAccessorParser(Class<? extends TemporalAccessor> temporalAccessorType, DateTimeFormatter formatter) {
/*  76 */     this(temporalAccessorType, formatter, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   TemporalAccessorParser(Class<? extends TemporalAccessor> temporalAccessorType, DateTimeFormatter formatter, @Nullable String[] fallbackPatterns, @Nullable Object source) {
/*  82 */     this.temporalAccessorType = temporalAccessorType;
/*  83 */     this.formatter = formatter;
/*  84 */     this.fallbackPatterns = fallbackPatterns;
/*  85 */     this.source = source;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TemporalAccessor parse(String text, Locale locale) throws ParseException {
/*     */     try {
/*  92 */       return doParse(text, locale, this.formatter);
/*     */     }
/*  94 */     catch (DateTimeParseException ex) {
/*  95 */       if (!ObjectUtils.isEmpty((Object[])this.fallbackPatterns)) {
/*  96 */         for (String pattern : this.fallbackPatterns) {
/*     */           try {
/*  98 */             DateTimeFormatter fallbackFormatter = DateTimeFormatterUtils.createStrictDateTimeFormatter(pattern);
/*  99 */             return doParse(text, locale, fallbackFormatter);
/*     */           }
/* 101 */           catch (DateTimeParseException dateTimeParseException) {}
/*     */         } 
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 111 */           return defaultParse(text);
/*     */         }
/* 113 */         catch (DateTimeParseException dateTimeParseException) {}
/*     */       } 
/*     */ 
/*     */       
/* 117 */       if (this.source != null) {
/* 118 */         throw new DateTimeParseException(
/* 119 */             String.format("Unable to parse date time value \"%s\" using configuration from %s", new Object[] { text, this.source }), text, ex
/* 120 */             .getErrorIndex(), ex);
/*     */       }
/*     */       
/* 123 */       throw ex;
/*     */     } 
/*     */   }
/*     */   
/*     */   private TemporalAccessor doParse(String text, Locale locale, DateTimeFormatter formatter) throws DateTimeParseException {
/* 128 */     DateTimeFormatter formatterToUse = DateTimeContextHolder.getFormatter(formatter, locale);
/* 129 */     if (Instant.class == this.temporalAccessorType) {
/* 130 */       return formatterToUse.<TemporalAccessor>parse(text, Instant::from);
/*     */     }
/* 132 */     if (LocalDate.class == this.temporalAccessorType) {
/* 133 */       return LocalDate.parse(text, formatterToUse);
/*     */     }
/* 135 */     if (LocalTime.class == this.temporalAccessorType) {
/* 136 */       return LocalTime.parse(text, formatterToUse);
/*     */     }
/* 138 */     if (LocalDateTime.class == this.temporalAccessorType) {
/* 139 */       return LocalDateTime.parse(text, formatterToUse);
/*     */     }
/* 141 */     if (ZonedDateTime.class == this.temporalAccessorType) {
/* 142 */       return ZonedDateTime.parse(text, formatterToUse);
/*     */     }
/* 144 */     if (OffsetDateTime.class == this.temporalAccessorType) {
/* 145 */       return OffsetDateTime.parse(text, formatterToUse);
/*     */     }
/* 147 */     if (OffsetTime.class == this.temporalAccessorType) {
/* 148 */       return OffsetTime.parse(text, formatterToUse);
/*     */     }
/* 150 */     if (YearMonth.class == this.temporalAccessorType) {
/* 151 */       return YearMonth.parse(text, formatterToUse);
/*     */     }
/* 153 */     if (MonthDay.class == this.temporalAccessorType) {
/* 154 */       return MonthDay.parse(text, formatterToUse);
/*     */     }
/*     */     
/* 157 */     throw new IllegalStateException("Unsupported TemporalAccessor type: " + String.valueOf(this.temporalAccessorType));
/*     */   }
/*     */ 
/*     */   
/*     */   private TemporalAccessor defaultParse(String text) throws DateTimeParseException {
/* 162 */     if (Instant.class == this.temporalAccessorType) {
/* 163 */       return Instant.parse(text);
/*     */     }
/* 165 */     if (LocalDate.class == this.temporalAccessorType) {
/* 166 */       return LocalDate.parse(text);
/*     */     }
/* 168 */     if (LocalTime.class == this.temporalAccessorType) {
/* 169 */       return LocalTime.parse(text);
/*     */     }
/* 171 */     if (LocalDateTime.class == this.temporalAccessorType) {
/* 172 */       return LocalDateTime.parse(text);
/*     */     }
/* 174 */     if (ZonedDateTime.class == this.temporalAccessorType) {
/* 175 */       return ZonedDateTime.parse(text);
/*     */     }
/* 177 */     if (OffsetDateTime.class == this.temporalAccessorType) {
/* 178 */       return OffsetDateTime.parse(text);
/*     */     }
/* 180 */     if (OffsetTime.class == this.temporalAccessorType) {
/* 181 */       return OffsetTime.parse(text);
/*     */     }
/* 183 */     if (YearMonth.class == this.temporalAccessorType) {
/* 184 */       return YearMonth.parse(text);
/*     */     }
/* 186 */     if (MonthDay.class == this.temporalAccessorType) {
/* 187 */       return MonthDay.parse(text);
/*     */     }
/*     */     
/* 190 */     throw new IllegalStateException("Unsupported TemporalAccessor type: " + String.valueOf(this.temporalAccessorType));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\standard\TemporalAccessorParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */