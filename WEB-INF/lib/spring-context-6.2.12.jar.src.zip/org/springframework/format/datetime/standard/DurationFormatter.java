/*    */ package org.springframework.format.datetime.standard;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.time.Duration;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ import org.springframework.format.annotation.DurationFormat;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DurationFormatter
/*    */   implements Formatter<Duration>
/*    */ {
/*    */   private final DurationFormat.Style style;
/*    */   @Nullable
/*    */   private final DurationFormat.Unit defaultUnit;
/*    */   
/*    */   DurationFormatter() {
/* 48 */     this(DurationFormat.Style.ISO8601);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DurationFormatter(DurationFormat.Style style) {
/* 57 */     this(style, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DurationFormatter(DurationFormat.Style style, @Nullable DurationFormat.Unit defaultUnit) {
/* 73 */     this.style = style;
/* 74 */     this.defaultUnit = defaultUnit;
/*    */   }
/*    */ 
/*    */   
/*    */   public Duration parse(String text, Locale locale) throws ParseException {
/* 79 */     if (this.defaultUnit == null)
/*    */     {
/* 81 */       return DurationFormatterUtils.parse(text, this.style);
/*    */     }
/* 83 */     return DurationFormatterUtils.parse(text, this.style, this.defaultUnit);
/*    */   }
/*    */ 
/*    */   
/*    */   public String print(Duration object, Locale locale) {
/* 88 */     if (this.defaultUnit == null)
/*    */     {
/* 90 */       return DurationFormatterUtils.print(object, this.style);
/*    */     }
/* 92 */     return DurationFormatterUtils.print(object, this.style, this.defaultUnit);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-context-6.2.12.jar!\org\springframework\format\datetime\standard\DurationFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */