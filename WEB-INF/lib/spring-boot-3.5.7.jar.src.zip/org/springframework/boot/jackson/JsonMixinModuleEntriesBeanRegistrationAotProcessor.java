/*     */ package org.springframework.boot.jackson;
/*     */ 
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.AccessControl;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.BindingReflectionHintsRegistrar;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragments;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragmentsDecorator;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JsonMixinModuleEntriesBeanRegistrationAotProcessor
/*     */   implements BeanRegistrationAotProcessor
/*     */ {
/*     */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/*  48 */     if (registeredBean.getBeanClass().equals(JsonMixinModuleEntries.class)) {
/*  49 */       return 
/*  50 */         BeanRegistrationAotContribution.withCustomCodeFragments(codeFragments -> new AotContribution(codeFragments, registeredBean));
/*     */     }
/*  52 */     return null;
/*     */   }
/*     */   
/*     */   static class AotContribution
/*     */     extends BeanRegistrationCodeFragmentsDecorator {
/*  57 */     private static final Class<?> BEAN_TYPE = JsonMixinModuleEntries.class;
/*     */     
/*     */     private final RegisteredBean registeredBean;
/*     */     
/*     */     private final ClassLoader classLoader;
/*     */     
/*     */     AotContribution(BeanRegistrationCodeFragments delegate, RegisteredBean registeredBean) {
/*  64 */       super(delegate);
/*  65 */       this.registeredBean = registeredBean;
/*  66 */       this.classLoader = registeredBean.getBeanFactory().getBeanClassLoader();
/*     */     }
/*     */ 
/*     */     
/*     */     public ClassName getTarget(RegisteredBean registeredBean) {
/*  71 */       return ClassName.get(BEAN_TYPE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CodeBlock generateInstanceSupplierCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, boolean allowDirectSupplierShortcut) {
/*  78 */       JsonMixinModuleEntries entries = (JsonMixinModuleEntries)this.registeredBean.getBeanFactory().getBean(this.registeredBean.getBeanName(), JsonMixinModuleEntries.class);
/*  79 */       contributeHints(generationContext.getRuntimeHints(), entries);
/*  80 */       GeneratedMethod generatedMethod = beanRegistrationCode.getMethods().add("getInstance", method -> {
/*     */             method.addJavadoc("Get the bean instance for '$L'.", new Object[] { this.registeredBean.getBeanName() });
/*     */             method.addModifiers(new Modifier[] { Modifier.PRIVATE, Modifier.STATIC });
/*     */             method.returns(BEAN_TYPE);
/*     */             CodeBlock.Builder code = CodeBlock.builder();
/*     */             code.add("return $T.create(", new Object[] { JsonMixinModuleEntries.class }).beginControlFlow("(mixins) ->", new Object[0]);
/*     */             entries.doWithEntry(this.classLoader, ());
/*     */             code.endControlFlow(")", new Object[0]);
/*     */             method.addCode(code.build());
/*     */           });
/*  90 */       return generatedMethod.toMethodReference().toCodeBlock();
/*     */     }
/*     */     
/*     */     private void addEntryCode(CodeBlock.Builder code, Class<?> type, Class<?> mixin) {
/*  94 */       AccessControl accessForTypes = AccessControl.lowest(new AccessControl[] { AccessControl.forClass(type), 
/*  95 */             AccessControl.forClass(mixin) });
/*  96 */       if (accessForTypes.isPublic()) {
/*  97 */         code.addStatement("$L.and($T.class, $T.class)", new Object[] { "mixins", type, mixin });
/*     */       } else {
/*     */         
/* 100 */         code.addStatement("$L.and($S, $S)", new Object[] { "mixins", type.getName(), mixin.getName() });
/*     */       } 
/*     */     }
/*     */     
/*     */     private void contributeHints(RuntimeHints runtimeHints, JsonMixinModuleEntries entries) {
/* 105 */       Set<Class<?>> mixins = new LinkedHashSet<>();
/* 106 */       entries.doWithEntry(this.classLoader, (type, mixin) -> mixins.add(mixin));
/* 107 */       (new BindingReflectionHintsRegistrar()).registerReflectionHints(runtimeHints.reflection(), (Type[])mixins
/* 108 */           .toArray(x$0 -> new Class[x$0]));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jackson\JsonMixinModuleEntriesBeanRegistrationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */