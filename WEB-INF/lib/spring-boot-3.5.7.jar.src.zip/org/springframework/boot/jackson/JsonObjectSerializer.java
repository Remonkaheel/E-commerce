/*    */ package org.springframework.boot.jackson;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JsonObjectSerializer<T>
/*    */   extends JsonSerializer<T>
/*    */ {
/*    */   public final void serialize(T value, JsonGenerator jgen, SerializerProvider provider) throws IOException {
/*    */     try {
/* 39 */       jgen.writeStartObject();
/* 40 */       serializeObject(value, jgen, provider);
/* 41 */       jgen.writeEndObject();
/*    */     }
/* 43 */     catch (Exception ex) {
/* 44 */       if (ex instanceof IOException) { IOException ioException = (IOException)ex;
/* 45 */         throw ioException; }
/*    */       
/* 47 */       throw new JsonMappingException(jgen, "Object serialize error", ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract void serializeObject(T paramT, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider) throws IOException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jackson\JsonObjectSerializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */