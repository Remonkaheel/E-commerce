/*    */ package org.springframework.boot.jackson;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonMixinModule
/*    */   extends SimpleModule
/*    */ {
/*    */   public void registerEntries(JsonMixinModuleEntries entries, ClassLoader classLoader) {
/* 40 */     entries.doWithEntry(classLoader, this::setMixInAnnotation);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jackson\JsonMixinModule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */