/*     */ package org.springframework.boot.jackson;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonObjectDeserializer<T>
/*     */   extends JsonDeserializer<T>
/*     */ {
/*     */   public final T deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
/*     */     try {
/*  49 */       ObjectCodec codec = jp.getCodec();
/*  50 */       JsonNode tree = (JsonNode)codec.readTree(jp);
/*  51 */       return deserializeObject(jp, ctxt, codec, tree);
/*     */     }
/*  53 */     catch (Exception ex) {
/*  54 */       if (ex instanceof IOException) { IOException ioException = (IOException)ex;
/*  55 */         throw ioException; }
/*     */       
/*  57 */       throw new JsonMappingException(jp, "Object deserialize error", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T deserializeObject(JsonParser paramJsonParser, DeserializationContext paramDeserializationContext, ObjectCodec paramObjectCodec, JsonNode paramJsonNode) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final <D, R> R nullSafeValue(JsonNode jsonNode, Class<D> type, Function<D, R> mapper) {
/*  90 */     D value = nullSafeValue(jsonNode, type);
/*  91 */     return (value != null) ? mapper.apply(value) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final <D> D nullSafeValue(JsonNode jsonNode, Class<D> type) {
/* 106 */     Assert.notNull(type, "'type' must not be null");
/* 107 */     if (jsonNode == null) {
/* 108 */       return null;
/*     */     }
/* 110 */     if (type == String.class) {
/* 111 */       return (D)jsonNode.textValue();
/*     */     }
/* 113 */     if (type == Boolean.class) {
/* 114 */       return (D)Boolean.valueOf(jsonNode.booleanValue());
/*     */     }
/* 116 */     if (type == Long.class) {
/* 117 */       return (D)Long.valueOf(jsonNode.longValue());
/*     */     }
/* 119 */     if (type == Integer.class) {
/* 120 */       return (D)Integer.valueOf(jsonNode.intValue());
/*     */     }
/* 122 */     if (type == Short.class) {
/* 123 */       return (D)Short.valueOf(jsonNode.shortValue());
/*     */     }
/* 125 */     if (type == Double.class) {
/* 126 */       return (D)Double.valueOf(jsonNode.doubleValue());
/*     */     }
/* 128 */     if (type == Float.class) {
/* 129 */       return (D)Float.valueOf(jsonNode.floatValue());
/*     */     }
/* 131 */     if (type == BigDecimal.class) {
/* 132 */       return (D)jsonNode.decimalValue();
/*     */     }
/* 134 */     if (type == BigInteger.class) {
/* 135 */       return (D)jsonNode.bigIntegerValue();
/*     */     }
/* 137 */     throw new IllegalArgumentException("Unsupported value type " + type.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonNode getRequiredNode(JsonNode tree, String fieldName) {
/* 147 */     Assert.notNull(tree, "'tree' must not be null");
/* 148 */     JsonNode node = tree.get(fieldName);
/* 149 */     Assert.state((node != null && !(node instanceof com.fasterxml.jackson.databind.node.NullNode)), () -> "Missing JSON field '" + fieldName + "'");
/* 150 */     return node;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jackson\JsonObjectDeserializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */