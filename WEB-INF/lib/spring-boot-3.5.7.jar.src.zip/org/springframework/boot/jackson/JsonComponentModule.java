/*     */ package org.springframework.boot.jackson;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.BiConsumer;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.ReflectionHints;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.HierarchicalBeanFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotProcessor;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonComponentModule
/*     */   extends SimpleModule
/*     */   implements BeanFactoryAware, InitializingBean
/*     */ {
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/*  69 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  74 */     registerJsonComponents();
/*     */   }
/*     */   
/*     */   public void registerJsonComponents() {
/*  78 */     BeanFactory beanFactory = this.beanFactory;
/*  79 */     while (beanFactory != null) {
/*  80 */       if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory listableBeanFactory = (ListableBeanFactory)beanFactory;
/*  81 */         addJsonBeans(listableBeanFactory); }
/*     */       
/*  83 */       HierarchicalBeanFactory hierarchicalBeanFactory = (HierarchicalBeanFactory)beanFactory;
/*  84 */       beanFactory = (beanFactory instanceof HierarchicalBeanFactory) ? hierarchicalBeanFactory.getParentBeanFactory() : null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addJsonBeans(ListableBeanFactory beanFactory) {
/*  89 */     Map<String, Object> beans = beanFactory.getBeansWithAnnotation(JsonComponent.class);
/*  90 */     for (Object bean : beans.values()) {
/*  91 */       addJsonBean(bean);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void addJsonBean(Object bean) {
/*  98 */     MergedAnnotation<JsonComponent> annotation = MergedAnnotations.from(bean.getClass(), MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(JsonComponent.class);
/*  99 */     Class<?>[] types = annotation.getClassArray("type");
/* 100 */     JsonComponent.Scope scope = (JsonComponent.Scope)annotation.getEnum("scope", JsonComponent.Scope.class);
/* 101 */     addJsonBean(bean, types, scope);
/*     */   }
/*     */   
/*     */   private void addJsonBean(Object bean, Class<?>[] types, JsonComponent.Scope scope) {
/* 105 */     if (bean instanceof JsonSerializer) { JsonSerializer<?> jsonSerializer = (JsonSerializer)bean;
/* 106 */       addJsonSerializerBean(jsonSerializer, scope, types); }
/*     */     
/* 108 */     else if (bean instanceof JsonDeserializer) { JsonDeserializer<?> jsonDeserializer = (JsonDeserializer)bean;
/* 109 */       addJsonDeserializerBean(jsonDeserializer, types); }
/*     */     
/* 111 */     else if (bean instanceof KeyDeserializer) { KeyDeserializer keyDeserializer = (KeyDeserializer)bean;
/* 112 */       addKeyDeserializerBean(keyDeserializer, types); }
/*     */     
/* 114 */     for (Class<?> innerClass : bean.getClass().getDeclaredClasses()) {
/* 115 */       if (isSuitableInnerClass(innerClass)) {
/* 116 */         Object innerInstance = BeanUtils.instantiateClass(innerClass);
/* 117 */         addJsonBean(innerInstance, types, scope);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isSuitableInnerClass(Class<?> innerClass) {
/* 123 */     return (!Modifier.isAbstract(innerClass.getModifiers()) && (JsonSerializer.class.isAssignableFrom(innerClass) || JsonDeserializer.class
/* 124 */       .isAssignableFrom(innerClass) || KeyDeserializer.class
/* 125 */       .isAssignableFrom(innerClass)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> void addJsonSerializerBean(JsonSerializer<T> serializer, JsonComponent.Scope scope, Class<?>[] types) {
/* 131 */     Class<T> baseType = ResolvableType.forClass(JsonSerializer.class, serializer.getClass()).resolveGeneric(new int[0]);
/* 132 */     addBeanToModule(serializer, baseType, types, 
/* 133 */         (scope == JsonComponent.Scope.VALUES) ? this::addSerializer : this::addKeySerializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> void addJsonDeserializerBean(JsonDeserializer<T> deserializer, Class<?>[] types) {
/* 140 */     Class<T> baseType = ResolvableType.forClass(JsonDeserializer.class, deserializer.getClass()).resolveGeneric(new int[0]);
/* 141 */     addBeanToModule(deserializer, baseType, types, this::addDeserializer);
/*     */   }
/*     */   
/*     */   private void addKeyDeserializerBean(KeyDeserializer deserializer, Class<?>[] types) {
/* 145 */     Assert.notEmpty((Object[])types, "'types' must not be empty");
/* 146 */     addBeanToModule(deserializer, Object.class, types, this::addKeyDeserializer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <E, T> void addBeanToModule(E element, Class<T> baseType, Class<?>[] types, BiConsumer<Class<T>, E> consumer) {
/* 152 */     if (ObjectUtils.isEmpty((Object[])types)) {
/* 153 */       consumer.accept(baseType, element);
/*     */       return;
/*     */     } 
/* 156 */     for (Class<?> type : types) {
/* 157 */       Assert.isAssignable(baseType, type);
/* 158 */       consumer.accept(type, element);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static class JsonComponentBeanFactoryInitializationAotProcessor
/*     */     implements BeanFactoryInitializationAotProcessor
/*     */   {
/*     */     public BeanFactoryInitializationAotContribution processAheadOfTime(ConfigurableListableBeanFactory beanFactory) {
/* 167 */       String[] jsonComponents = beanFactory.getBeanNamesForAnnotation(JsonComponent.class);
/* 168 */       Map<Class<?>, List<Class<?>>> innerComponents = new HashMap<>();
/* 169 */       for (String jsonComponent : jsonComponents) {
/* 170 */         Class<?> type = beanFactory.getType(jsonComponent, true);
/* 171 */         for (Class<?> declaredClass : type.getDeclaredClasses()) {
/* 172 */           if (JsonComponentModule.isSuitableInnerClass(declaredClass)) {
/* 173 */             ((List<Class<?>>)innerComponents.computeIfAbsent(type, t -> new ArrayList())).add(declaredClass);
/*     */           }
/*     */         } 
/*     */       } 
/* 177 */       return innerComponents.isEmpty() ? null : new JsonComponentModule.JsonComponentAotContribution(innerComponents);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class JsonComponentAotContribution
/*     */     implements BeanFactoryInitializationAotContribution
/*     */   {
/*     */     private final Map<Class<?>, List<Class<?>>> innerComponents;
/*     */     
/*     */     private JsonComponentAotContribution(Map<Class<?>, List<Class<?>>> innerComponents) {
/* 187 */       this.innerComponents = innerComponents;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 193 */       ReflectionHints reflection = generationContext.getRuntimeHints().reflection();
/* 194 */       this.innerComponents.forEach((outer, inners) -> {
/*     */             reflection.registerType(outer, new MemberCategory[] { MemberCategory.DECLARED_CLASSES });
/*     */             inners.forEach(());
/*     */           });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jackson\JsonComponentModule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */