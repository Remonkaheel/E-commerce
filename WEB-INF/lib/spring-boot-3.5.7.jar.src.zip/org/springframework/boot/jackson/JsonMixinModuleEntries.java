/*     */ package org.springframework.boot.jackson;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JsonMixinModuleEntries
/*     */ {
/*     */   private final Map<Object, Object> entries;
/*     */   
/*     */   private JsonMixinModuleEntries(Builder builder) {
/*  48 */     this.entries = new LinkedHashMap<>(builder.entries);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMixinModuleEntries create(Consumer<Builder> mixins) {
/*  57 */     Builder builder = new Builder();
/*  58 */     mixins.accept(builder);
/*  59 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMixinModuleEntries scan(ApplicationContext context, Collection<String> basePackages) {
/*  70 */     return create(builder -> {
/*     */           if (ObjectUtils.isEmpty(basePackages)) {
/*     */             return;
/*     */           }
/*     */           JsonMixinComponentScanner scanner = new JsonMixinComponentScanner();
/*     */           scanner.setEnvironment(context.getEnvironment());
/*     */           scanner.setResourceLoader((ResourceLoader)context);
/*     */           for (String basePackage : basePackages) {
/*     */             if (StringUtils.hasText(basePackage)) {
/*     */               for (BeanDefinition candidate : scanner.findCandidateComponents(basePackage)) {
/*     */                 Class<?> mixinClass = ClassUtils.resolveClassName(candidate.getBeanClassName(), context.getClassLoader());
/*     */                 registerMixinClass(builder, mixinClass);
/*     */               } 
/*     */             }
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registerMixinClass(Builder builder, Class<?> mixinClass) {
/*  92 */     MergedAnnotation<JsonMixin> annotation = MergedAnnotations.from(mixinClass, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(JsonMixin.class);
/*  93 */     Class<?>[] types = annotation.getClassArray("type");
/*  94 */     Assert.state(!ObjectUtils.isEmpty((Object[])types), () -> "@JsonMixin annotation on class '" + mixinClass.getName() + "' does not specify any types");
/*     */     
/*  96 */     for (Class<?> type : types) {
/*  97 */       builder.and(type, mixinClass);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doWithEntry(ClassLoader classLoader, BiConsumer<Class<?>, Class<?>> action) {
/* 108 */     this.entries.forEach((type, mixin) -> action.accept(resolveClassNameIfNecessary(type, classLoader), resolveClassNameIfNecessary(mixin, classLoader)));
/*     */   }
/*     */ 
/*     */   
/*     */   private Class<?> resolveClassNameIfNecessary(Object nameOrType, ClassLoader classLoader) {
/* 113 */     Class<?> type = (Class)nameOrType; return (nameOrType instanceof Class) ? type : 
/* 114 */       ClassUtils.resolveClassName((String)nameOrType, classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/* 125 */     private final Map<Object, Object> entries = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder and(String typeClassName, String mixinClassName) {
/* 135 */       this.entries.put(typeClassName, mixinClassName);
/* 136 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder and(Class<?> type, Class<?> mixinClass) {
/* 146 */       this.entries.put(type, mixinClass);
/* 147 */       return this;
/*     */     }
/*     */     
/*     */     JsonMixinModuleEntries build() {
/* 151 */       return new JsonMixinModuleEntries(this);
/*     */     }
/*     */   }
/*     */   
/*     */   static class JsonMixinComponentScanner
/*     */     extends ClassPathScanningCandidateComponentProvider
/*     */   {
/*     */     JsonMixinComponentScanner() {
/* 159 */       addIncludeFilter((TypeFilter)new AnnotationTypeFilter(JsonMixin.class));
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition) {
/* 164 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jackson\JsonMixinModuleEntries.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */