/*    */ package org.springframework.boot.availability;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum LivenessState
/*    */   implements AvailabilityState
/*    */ {
/* 34 */   CORRECT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   BROKEN;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\availability\LivenessState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */