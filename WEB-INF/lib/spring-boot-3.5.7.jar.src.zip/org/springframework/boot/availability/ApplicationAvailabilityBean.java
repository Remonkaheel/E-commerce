/*     */ package org.springframework.boot.availability;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationAvailabilityBean
/*     */   implements ApplicationAvailability, ApplicationListener<AvailabilityChangeEvent<?>>
/*     */ {
/*  41 */   private final Map<Class<? extends AvailabilityState>, AvailabilityChangeEvent<?>> events = new ConcurrentHashMap<>();
/*     */   
/*     */   private final Log logger;
/*     */   
/*     */   public ApplicationAvailabilityBean() {
/*  46 */     this(LogFactory.getLog(ApplicationAvailabilityBean.class));
/*     */   }
/*     */   
/*     */   ApplicationAvailabilityBean(Log logger) {
/*  50 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   
/*     */   public <S extends AvailabilityState> S getState(Class<S> stateType, S defaultState) {
/*  55 */     Assert.notNull(stateType, "'stateType' must not be null");
/*  56 */     Assert.notNull(defaultState, "'defaultState' must not be null");
/*  57 */     S state = getState(stateType);
/*  58 */     return (state != null) ? state : defaultState;
/*     */   }
/*     */ 
/*     */   
/*     */   public <S extends AvailabilityState> S getState(Class<S> stateType) {
/*  63 */     AvailabilityChangeEvent<S> event = getLastChangeEvent(stateType);
/*  64 */     return (event != null) ? event.getState() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <S extends AvailabilityState> AvailabilityChangeEvent<S> getLastChangeEvent(Class<S> stateType) {
/*  70 */     return (AvailabilityChangeEvent<S>)this.events.get(stateType);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(AvailabilityChangeEvent<?> event) {
/*  75 */     Class<? extends AvailabilityState> type = getStateType((AvailabilityState)event.getState());
/*  76 */     if (this.logger.isDebugEnabled()) {
/*  77 */       this.logger.debug(getLogMessage(type, event));
/*     */     }
/*  79 */     this.events.put(type, event);
/*     */   }
/*     */   
/*     */   private <S extends AvailabilityState> Object getLogMessage(Class<S> type, AvailabilityChangeEvent<?> event) {
/*  83 */     AvailabilityChangeEvent<S> lastChangeEvent = getLastChangeEvent(type);
/*     */     
/*  85 */     StringBuilder message = new StringBuilder("Application availability state " + type.getSimpleName() + " changed");
/*  86 */     message.append((lastChangeEvent != null) ? (" from " + String.valueOf(lastChangeEvent.getState())) : "");
/*  87 */     message.append(" to " + String.valueOf(event.getState()));
/*  88 */     message.append(getSourceDescription(event.getSource()));
/*  89 */     return message;
/*     */   }
/*     */   
/*     */   private String getSourceDescription(Object source) {
/*  93 */     if (source == null || source instanceof org.springframework.context.ApplicationEventPublisher) {
/*  94 */       return "";
/*     */     }
/*  96 */     return ": " + String.valueOf((source instanceof Throwable) ? source : source.getClass().getName());
/*     */   }
/*     */ 
/*     */   
/*     */   private Class<? extends AvailabilityState> getStateType(AvailabilityState state) {
/* 101 */     Enum<?> enumState = (Enum)state; Class<?> type = (state instanceof Enum) ? enumState.getDeclaringClass() : state.getClass();
/* 102 */     return (Class)type;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\availability\ApplicationAvailabilityBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */