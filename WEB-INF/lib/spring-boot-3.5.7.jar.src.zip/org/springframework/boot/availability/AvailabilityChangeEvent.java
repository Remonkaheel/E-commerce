/*    */ package org.springframework.boot.availability;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationEventPublisher;
/*    */ import org.springframework.context.PayloadApplicationEvent;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AvailabilityChangeEvent<S extends AvailabilityState>
/*    */   extends PayloadApplicationEvent<S>
/*    */ {
/*    */   public AvailabilityChangeEvent(Object source, S state) {
/* 45 */     super(source, state);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public S getState() {
/* 53 */     return (S)getPayload();
/*    */   }
/*    */ 
/*    */   
/*    */   public ResolvableType getResolvableType() {
/* 58 */     return ResolvableType.forClassWithGenerics(getClass(), new Class[] { getStateType() });
/*    */   }
/*    */   
/*    */   private Class<?> getStateType() {
/* 62 */     S state = getState();
/* 63 */     if (state instanceof Enum) { Enum<?> enumState = (Enum)state;
/* 64 */       return enumState.getDeclaringClass(); }
/*    */     
/* 66 */     return state.getClass();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <S extends AvailabilityState> void publish(ApplicationContext context, S state) {
/* 77 */     Assert.notNull(context, "'context' must not be null");
/* 78 */     publish((ApplicationEventPublisher)context, context, state);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <S extends AvailabilityState> void publish(ApplicationEventPublisher publisher, Object source, S state) {
/* 91 */     Assert.notNull(publisher, "'publisher' must not be null");
/* 92 */     publisher.publishEvent((ApplicationEvent)new AvailabilityChangeEvent<>(source, state));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\availability\AvailabilityChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */