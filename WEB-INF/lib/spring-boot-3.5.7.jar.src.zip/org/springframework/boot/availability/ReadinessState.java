/*    */ package org.springframework.boot.availability;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ReadinessState
/*    */   implements AvailabilityState
/*    */ {
/* 34 */   ACCEPTING_TRAFFIC,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   REFUSING_TRAFFIC;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\availability\ReadinessState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */