/*    */ package org.springframework.boot.availability;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ApplicationAvailability
/*    */ {
/*    */   default LivenessState getLivenessState() {
/* 40 */     return getState(LivenessState.class, LivenessState.BROKEN);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default ReadinessState getReadinessState() {
/* 48 */     return getState(ReadinessState.class, ReadinessState.REFUSING_TRAFFIC);
/*    */   }
/*    */   
/*    */   <S extends AvailabilityState> S getState(Class<S> paramClass, S paramS);
/*    */   
/*    */   <S extends AvailabilityState> S getState(Class<S> paramClass);
/*    */   
/*    */   <S extends AvailabilityState> AvailabilityChangeEvent<S> getLastChangeEvent(Class<S> paramClass);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\availability\ApplicationAvailability.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */