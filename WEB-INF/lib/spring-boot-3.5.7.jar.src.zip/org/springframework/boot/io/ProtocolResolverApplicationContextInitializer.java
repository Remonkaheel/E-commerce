/*    */ package org.springframework.boot.io;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import org.springframework.context.ApplicationContextInitializer;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.core.io.ProtocolResolver;
/*    */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ProtocolResolverApplicationContextInitializer
/*    */   implements ApplicationContextInitializer<ConfigurableApplicationContext>
/*    */ {
/*    */   public void initialize(ConfigurableApplicationContext applicationContext) {
/* 38 */     SpringFactoriesLoader loader = SpringFactoriesLoader.forDefaultResourceLocation(applicationContext.getClassLoader());
/* 39 */     List<ProtocolResolver> protocolResolvers = loader.load(ProtocolResolver.class);
/* 40 */     Objects.requireNonNull(applicationContext); protocolResolvers.forEach(applicationContext::addProtocolResolver);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\io\ProtocolResolverApplicationContextInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */