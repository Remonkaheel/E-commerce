/*    */ package org.springframework.boot.io;
/*    */ 
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ClassPathResourceFilePathResolver
/*    */   implements ApplicationResourceLoader.FilePathResolver
/*    */ {
/*    */   public String resolveFilePath(String location, Resource resource) {
/* 33 */     return (resource instanceof org.springframework.core.io.ClassPathResource && !isClassPathUrl(location)) ? location : null;
/*    */   }
/*    */   
/*    */   private boolean isClassPathUrl(String location) {
/* 37 */     return location.startsWith("classpath:");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\io\ClassPathResourceFilePathResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */