/*    */ package org.springframework.boot.io;
/*    */ 
/*    */ import java.util.Base64;
/*    */ import org.springframework.core.io.ByteArrayResource;
/*    */ import org.springframework.core.io.ProtocolResolver;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Base64ProtocolResolver
/*    */   implements ProtocolResolver
/*    */ {
/*    */   private static final String BASE64_PREFIX = "base64:";
/*    */   
/*    */   public Resource resolve(String location, ResourceLoader resourceLoader) {
/* 37 */     if (location.startsWith("base64:")) {
/* 38 */       String value = location.substring("base64:".length());
/* 39 */       return (Resource)new ByteArrayResource(decode(value));
/*    */     } 
/* 41 */     return null;
/*    */   }
/*    */   
/*    */   private static byte[] decode(String location) {
/* 45 */     return Base64.getDecoder().decode(location);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\io\Base64ProtocolResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */