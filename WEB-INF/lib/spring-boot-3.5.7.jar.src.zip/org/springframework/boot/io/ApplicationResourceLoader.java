/*     */ package org.springframework.boot.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.core.io.ContextResource;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.FileSystemResource;
/*     */ import org.springframework.core.io.ProtocolResolver;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationResourceLoader
/*     */   extends DefaultResourceLoader
/*     */ {
/*     */   @Deprecated(since = "3.4.0", forRemoval = true)
/*     */   public ApplicationResourceLoader() {
/*  59 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "3.4.0", forRemoval = true)
/*     */   public ApplicationResourceLoader(ClassLoader classLoader) {
/*  71 */     super(classLoader);
/*  72 */     SpringFactoriesLoader loader = SpringFactoriesLoader.forDefaultResourceLocation(classLoader);
/*  73 */     getProtocolResolvers().addAll(loader.load(ProtocolResolver.class));
/*     */   }
/*     */ 
/*     */   
/*     */   protected Resource getResourceByPath(String path) {
/*  78 */     return (Resource)new ApplicationResource(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceLoader get() {
/*  90 */     return get((ClassLoader)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceLoader get(ClassLoader classLoader) {
/* 103 */     return get(classLoader, SpringFactoriesLoader.forDefaultResourceLocation(classLoader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceLoader get(ClassLoader classLoader, SpringFactoriesLoader springFactoriesLoader) {
/* 117 */     return get(classLoader, springFactoriesLoader, (Path)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceLoader get(ClassLoader classLoader, SpringFactoriesLoader springFactoriesLoader, Path workingDirectory) {
/* 133 */     return get(ApplicationFileSystemResourceLoader.get(classLoader, workingDirectory), springFactoriesLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceLoader get(ResourceLoader resourceLoader) {
/* 146 */     return get(resourceLoader, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceLoader get(ResourceLoader resourceLoader, boolean preferFileResolution) {
/* 161 */     Assert.notNull(resourceLoader, "'resourceLoader' must not be null");
/* 162 */     return get(resourceLoader, SpringFactoriesLoader.forDefaultResourceLocation(resourceLoader.getClassLoader()), preferFileResolution);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceLoader get(ResourceLoader resourceLoader, SpringFactoriesLoader springFactoriesLoader) {
/* 177 */     return get(resourceLoader, springFactoriesLoader, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private static ResourceLoader get(ResourceLoader resourceLoader, SpringFactoriesLoader springFactoriesLoader, boolean preferFileResolution) {
/* 182 */     Assert.notNull(resourceLoader, "'resourceLoader' must not be null");
/* 183 */     Assert.notNull(springFactoriesLoader, "'springFactoriesLoader' must not be null");
/* 184 */     List<ProtocolResolver> protocolResolvers = springFactoriesLoader.load(ProtocolResolver.class);
/*     */     
/* 186 */     List<FilePathResolver> filePathResolvers = preferFileResolution ? springFactoriesLoader.load(FilePathResolver.class) : Collections.<FilePathResolver>emptyList();
/* 187 */     return new ProtocolResolvingResourceLoader(resourceLoader, protocolResolvers, filePathResolvers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ApplicationFileSystemResourceLoader
/*     */     extends DefaultResourceLoader
/*     */   {
/* 195 */     private static final ResourceLoader shared = (ResourceLoader)new ApplicationFileSystemResourceLoader(null, null);
/*     */     
/*     */     private final Path workingDirectory;
/*     */     
/*     */     private ApplicationFileSystemResourceLoader(ClassLoader classLoader, Path workingDirectory) {
/* 200 */       super(classLoader);
/* 201 */       this.workingDirectory = workingDirectory;
/*     */     }
/*     */ 
/*     */     
/*     */     public Resource getResource(String location) {
/* 206 */       Resource resource = super.getResource(location);
/* 207 */       if (this.workingDirectory == null) {
/* 208 */         return resource;
/*     */       }
/* 210 */       if (!resource.isFile()) {
/* 211 */         return resource;
/*     */       }
/* 213 */       return resolveFile(resource);
/*     */     }
/*     */     
/*     */     private Resource resolveFile(Resource resource) {
/*     */       try {
/* 218 */         File file = resource.getFile();
/* 219 */         return (Resource)new ApplicationResourceLoader.ApplicationResource(this.workingDirectory.resolve(file.toPath()));
/*     */       }
/* 221 */       catch (FileNotFoundException ex) {
/* 222 */         return resource;
/*     */       }
/* 224 */       catch (IOException ex) {
/* 225 */         throw new UncheckedIOException(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected Resource getResourceByPath(String path) {
/* 231 */       return (Resource)new ApplicationResourceLoader.ApplicationResource(path);
/*     */     }
/*     */     
/*     */     static ResourceLoader get(ClassLoader classLoader, Path workingDirectory) {
/* 235 */       if (classLoader == null && workingDirectory != null) {
/* 236 */         throw new IllegalArgumentException("It's not possible to use null as 'classLoader' but specify a 'workingDirectory'");
/*     */       }
/*     */       
/* 239 */       return (classLoader != null) ? (ResourceLoader)new ApplicationFileSystemResourceLoader(classLoader, workingDirectory) : 
/* 240 */         shared;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ApplicationResource
/*     */     extends FileSystemResource
/*     */     implements ContextResource
/*     */   {
/*     */     ApplicationResource(String path) {
/* 273 */       super(path);
/*     */     }
/*     */     
/*     */     ApplicationResource(Path path) {
/* 277 */       super(path);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPathWithinContext() {
/* 282 */       return getPath();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ProtocolResolvingResourceLoader
/*     */     implements ResourceLoader
/*     */   {
/*     */     private final ResourceLoader resourceLoader;
/*     */ 
/*     */     
/*     */     private final List<ProtocolResolver> protocolResolvers;
/*     */ 
/*     */     
/*     */     private final List<ApplicationResourceLoader.FilePathResolver> filePathResolvers;
/*     */ 
/*     */     
/*     */     ProtocolResolvingResourceLoader(ResourceLoader resourceLoader, List<ProtocolResolver> protocolResolvers, List<ApplicationResourceLoader.FilePathResolver> filePathResolvers) {
/* 301 */       this.resourceLoader = resourceLoader;
/* 302 */       this.protocolResolvers = protocolResolvers;
/* 303 */       this.filePathResolvers = filePathResolvers;
/*     */     }
/*     */ 
/*     */     
/*     */     public ClassLoader getClassLoader() {
/* 308 */       return this.resourceLoader.getClassLoader();
/*     */     }
/*     */ 
/*     */     
/*     */     public Resource getResource(String location) {
/* 313 */       if (StringUtils.hasLength(location)) {
/* 314 */         for (ProtocolResolver protocolResolver : this.protocolResolvers) {
/* 315 */           Resource resource1 = protocolResolver.resolve(location, this);
/* 316 */           if (resource1 != null) {
/* 317 */             return resource1;
/*     */           }
/*     */         } 
/*     */       }
/* 321 */       Resource resource = this.resourceLoader.getResource(location);
/* 322 */       String filePath = getFilePath(location, resource);
/* 323 */       return (filePath != null) ? (Resource)new ApplicationResourceLoader.ApplicationResource(filePath) : resource;
/*     */     }
/*     */     
/*     */     private String getFilePath(String location, Resource resource) {
/* 327 */       for (ApplicationResourceLoader.FilePathResolver filePathResolver : this.filePathResolvers) {
/* 328 */         String filePath = filePathResolver.resolveFilePath(location, resource);
/* 329 */         if (filePath != null) {
/* 330 */           return filePath;
/*     */         }
/*     */       } 
/* 333 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface FilePathResolver {
/*     */     String resolveFilePath(String param1String, Resource param1Resource);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\io\ApplicationResourceLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */