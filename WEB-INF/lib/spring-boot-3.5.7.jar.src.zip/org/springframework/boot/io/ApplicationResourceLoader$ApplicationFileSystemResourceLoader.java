/*     */ package org.springframework.boot.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.nio.file.Path;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ApplicationFileSystemResourceLoader
/*     */   extends DefaultResourceLoader
/*     */ {
/* 195 */   private static final ResourceLoader shared = (ResourceLoader)new ApplicationFileSystemResourceLoader(null, null);
/*     */   
/*     */   private final Path workingDirectory;
/*     */   
/*     */   private ApplicationFileSystemResourceLoader(ClassLoader classLoader, Path workingDirectory) {
/* 200 */     super(classLoader);
/* 201 */     this.workingDirectory = workingDirectory;
/*     */   }
/*     */ 
/*     */   
/*     */   public Resource getResource(String location) {
/* 206 */     Resource resource = super.getResource(location);
/* 207 */     if (this.workingDirectory == null) {
/* 208 */       return resource;
/*     */     }
/* 210 */     if (!resource.isFile()) {
/* 211 */       return resource;
/*     */     }
/* 213 */     return resolveFile(resource);
/*     */   }
/*     */   
/*     */   private Resource resolveFile(Resource resource) {
/*     */     try {
/* 218 */       File file = resource.getFile();
/* 219 */       return (Resource)new ApplicationResourceLoader.ApplicationResource(this.workingDirectory.resolve(file.toPath()));
/*     */     }
/* 221 */     catch (FileNotFoundException ex) {
/* 222 */       return resource;
/*     */     }
/* 224 */     catch (IOException ex) {
/* 225 */       throw new UncheckedIOException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Resource getResourceByPath(String path) {
/* 231 */     return (Resource)new ApplicationResourceLoader.ApplicationResource(path);
/*     */   }
/*     */   
/*     */   static ResourceLoader get(ClassLoader classLoader, Path workingDirectory) {
/* 235 */     if (classLoader == null && workingDirectory != null) {
/* 236 */       throw new IllegalArgumentException("It's not possible to use null as 'classLoader' but specify a 'workingDirectory'");
/*     */     }
/*     */     
/* 239 */     return (classLoader != null) ? (ResourceLoader)new ApplicationFileSystemResourceLoader(classLoader, workingDirectory) : 
/* 240 */       shared;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\io\ApplicationResourceLoader$ApplicationFileSystemResourceLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */