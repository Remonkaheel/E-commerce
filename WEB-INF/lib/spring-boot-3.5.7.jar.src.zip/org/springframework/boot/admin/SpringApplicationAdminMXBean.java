package org.springframework.boot.admin;

public interface SpringApplicationAdminMXBean {
  boolean isReady();
  
  boolean isEmbeddedWebApplication();
  
  String getProperty(String paramString);
  
  void shutdown();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\admin\SpringApplicationAdminMXBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */