/*     */ package org.springframework.boot.admin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SpringApplicationAdmin
/*     */   implements SpringApplicationAdminMXBean
/*     */ {
/*     */   public boolean isReady() {
/* 144 */     return SpringApplicationAdminMXBeanRegistrar.this.ready;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmbeddedWebApplication() {
/* 149 */     return SpringApplicationAdminMXBeanRegistrar.this.embeddedWebApplication;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProperty(String key) {
/* 154 */     return SpringApplicationAdminMXBeanRegistrar.this.environment.getProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 159 */     SpringApplicationAdminMXBeanRegistrar.logger.info("Application shutdown requested.");
/* 160 */     SpringApplicationAdminMXBeanRegistrar.this.applicationContext.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\admin\SpringApplicationAdminMXBeanRegistrar$SpringApplicationAdmin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */