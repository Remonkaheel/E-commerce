package org.springframework.boot.diagnostics;

@FunctionalInterface
public interface FailureAnalysisReporter {
  void report(FailureAnalysis paramFailureAnalysis);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\FailureAnalysisReporter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */