/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Descriptor
/*     */ {
/*     */   private final String propertySource;
/*     */   private final Object value;
/*     */   private final Origin origin;
/*     */   
/*     */   private Descriptor(String propertySource, Object value, Origin origin) {
/* 138 */     this.propertySource = propertySource;
/* 139 */     this.value = value;
/* 140 */     this.origin = origin;
/*     */   }
/*     */   
/*     */   String getPropertySource() {
/* 144 */     return this.propertySource;
/*     */   }
/*     */   
/*     */   Object getValue() {
/* 148 */     return this.value;
/*     */   }
/*     */   
/*     */   void appendOrigin(StringBuilder message) {
/* 152 */     if (this.origin != null) {
/* 153 */       message.append(" (originating from '").append(this.origin).append("')");
/*     */     }
/*     */   }
/*     */   
/*     */   static Descriptor get(PropertySource<?> source, String propertyName) {
/* 158 */     Object value = source.getProperty(propertyName);
/* 159 */     Origin origin = OriginLookup.getOrigin(source, propertyName);
/* 160 */     return new Descriptor(source.getName(), value, origin);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\analyzer\InvalidConfigurationPropertyValueFailureAnalyzer$Descriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */