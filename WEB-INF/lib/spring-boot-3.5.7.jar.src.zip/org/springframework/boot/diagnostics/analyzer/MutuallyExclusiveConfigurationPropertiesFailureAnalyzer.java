/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
/*     */ import org.springframework.boot.context.properties.source.MutuallyExclusiveConfigurationPropertiesException;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MutuallyExclusiveConfigurationPropertiesFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<MutuallyExclusiveConfigurationPropertiesException>
/*     */ {
/*     */   private final ConfigurableEnvironment environment;
/*     */   
/*     */   MutuallyExclusiveConfigurationPropertiesFailureAnalyzer(Environment environment) {
/*  52 */     this.environment = (ConfigurableEnvironment)environment;
/*     */   }
/*     */ 
/*     */   
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, MutuallyExclusiveConfigurationPropertiesException cause) {
/*  57 */     List<Descriptor> descriptors = new ArrayList<>();
/*  58 */     for (String name : cause.getConfiguredNames()) {
/*  59 */       List<Descriptor> descriptorsForName = getDescriptors(name);
/*  60 */       if (descriptorsForName.isEmpty()) {
/*  61 */         return null;
/*     */       }
/*  63 */       descriptors.addAll(descriptorsForName);
/*     */     } 
/*  65 */     StringBuilder description = new StringBuilder();
/*  66 */     appendDetails(description, cause, descriptors);
/*  67 */     return new FailureAnalysis(description.toString(), "Update your configuration so that only one of the mutually exclusive properties is configured.", (Throwable)cause);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Descriptor> getDescriptors(String propertyName) {
/*  73 */     return getPropertySources().filter(source -> source.containsProperty(propertyName))
/*  74 */       .map(source -> Descriptor.get(source, propertyName))
/*  75 */       .toList();
/*     */   }
/*     */   
/*     */   private Stream<PropertySource<?>> getPropertySources() {
/*  79 */     if (this.environment == null) {
/*  80 */       return Stream.empty();
/*     */     }
/*  82 */     return this.environment.getPropertySources()
/*  83 */       .stream()
/*  84 */       .filter(source -> !ConfigurationPropertySources.isAttachedConfigurationPropertySource(source));
/*     */   }
/*     */ 
/*     */   
/*     */   private void appendDetails(StringBuilder message, MutuallyExclusiveConfigurationPropertiesException cause, List<Descriptor> descriptors) {
/*  89 */     descriptors.sort(Comparator.comparing(descriptor -> descriptor.propertyName));
/*  90 */     message.append(String.format("The following configuration properties are mutually exclusive:%n%n", new Object[0]));
/*  91 */     sortedStrings(cause.getMutuallyExclusiveNames())
/*  92 */       .forEach(name -> message.append(String.format("\t%s%n", new Object[] { name })));
/*  93 */     message.append(String.format("%n", new Object[0]));
/*  94 */     message.append(
/*  95 */         String.format("However, more than one of those properties has been configured at the same time:%n%n", new Object[0]));
/*  96 */     Set<String> configuredDescriptions = sortedStrings(descriptors, descriptor -> String.format("\t%s%s%n", new Object[] { descriptor.propertyName, (descriptor.origin != null) ? (" (originating from '" + String.valueOf(descriptor.origin) + "')") : "" }));
/*     */ 
/*     */     
/*  99 */     Objects.requireNonNull(message); configuredDescriptions.forEach(message::append);
/*     */   }
/*     */   
/*     */   private Set<String> sortedStrings(Collection<String> input) {
/* 103 */     return sortedStrings(input, Function.identity());
/*     */   }
/*     */   
/*     */   private <S> Set<String> sortedStrings(Collection<S> input, Function<S, String> converter) {
/* 107 */     TreeSet<String> results = new TreeSet<>();
/* 108 */     for (S item : input) {
/* 109 */       results.add(converter.apply(item));
/*     */     }
/* 111 */     return results;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Descriptor
/*     */   {
/*     */     private final String propertyName;
/*     */     private final Origin origin;
/*     */     
/*     */     private Descriptor(String propertyName, Origin origin) {
/* 121 */       this.propertyName = propertyName;
/* 122 */       this.origin = origin;
/*     */     }
/*     */     
/*     */     static Descriptor get(PropertySource<?> source, String propertyName) {
/* 126 */       Origin origin = OriginLookup.getOrigin(source, propertyName);
/* 127 */       return new Descriptor(propertyName, origin);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\analyzer\MutuallyExclusiveConfigurationPropertiesFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */