/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.InjectionPoint;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BeanInCycle
/*     */ {
/*     */   private final String name;
/*     */   private final String description;
/*     */   
/*     */   private BeanInCycle(BeanCreationException ex) {
/* 144 */     this.name = ex.getBeanName();
/* 145 */     this.description = determineDescription(ex);
/*     */   }
/*     */   
/*     */   private String determineDescription(BeanCreationException ex) {
/* 149 */     if (StringUtils.hasText(ex.getResourceDescription())) {
/* 150 */       return String.format(" defined in %s", new Object[] { ex.getResourceDescription() });
/*     */     }
/* 152 */     InjectionPoint failedInjectionPoint = findFailedInjectionPoint(ex);
/* 153 */     if (failedInjectionPoint != null && failedInjectionPoint.getField() != null) {
/* 154 */       return String.format(" (field %s)", new Object[] { failedInjectionPoint.getField() });
/*     */     }
/* 156 */     return "";
/*     */   }
/*     */   
/*     */   private InjectionPoint findFailedInjectionPoint(BeanCreationException ex) {
/* 160 */     if (ex instanceof UnsatisfiedDependencyException) { UnsatisfiedDependencyException unsatisfiedDependencyException = (UnsatisfiedDependencyException)ex;
/* 161 */       return unsatisfiedDependencyException.getInjectionPoint(); }
/*     */     
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 168 */     if (this == obj) {
/* 169 */       return true;
/*     */     }
/* 171 */     if (obj == null || getClass() != obj.getClass()) {
/* 172 */       return false;
/*     */     }
/* 174 */     return this.name.equals(((BeanInCycle)obj).name);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 179 */     return this.name.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 184 */     return this.name + this.name;
/*     */   }
/*     */   
/*     */   static BeanInCycle get(Throwable ex) {
/* 188 */     if (ex instanceof BeanCreationException) { BeanCreationException beanCreationException = (BeanCreationException)ex;
/* 189 */       return get(beanCreationException); }
/*     */     
/* 191 */     return null;
/*     */   }
/*     */   
/*     */   private static BeanInCycle get(BeanCreationException ex) {
/* 195 */     if (StringUtils.hasText(ex.getBeanName())) {
/* 196 */       return new BeanInCycle(ex);
/*     */     }
/* 198 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\analyzer\BeanCurrentlyInCreationFailureAnalyzer$BeanInCycle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */