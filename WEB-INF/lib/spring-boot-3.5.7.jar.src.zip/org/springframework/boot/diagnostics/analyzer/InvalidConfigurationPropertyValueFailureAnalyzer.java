/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.boot.context.properties.source.InvalidConfigurationPropertyValueException;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.boot.origin.PropertySourceOrigin;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InvalidConfigurationPropertyValueFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<InvalidConfigurationPropertyValueException>
/*     */ {
/*     */   private final ConfigurableEnvironment environment;
/*     */   
/*     */   InvalidConfigurationPropertyValueFailureAnalyzer(Environment environment) {
/*  49 */     this.environment = (ConfigurableEnvironment)environment;
/*     */   }
/*     */ 
/*     */   
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, InvalidConfigurationPropertyValueException cause) {
/*  54 */     List<Descriptor> descriptors = getDescriptors(cause.getName());
/*  55 */     if (descriptors.isEmpty()) {
/*  56 */       descriptors = List.of(new Descriptor(null, cause.getValue(), null));
/*     */     }
/*  58 */     StringBuilder description = new StringBuilder();
/*  59 */     appendDetails(description, cause, descriptors);
/*  60 */     appendReason(description, cause);
/*  61 */     appendAdditionalProperties(description, descriptors);
/*  62 */     return new FailureAnalysis(description.toString(), getAction(cause), (Throwable)cause);
/*     */   }
/*     */   
/*     */   private List<Descriptor> getDescriptors(String propertyName) {
/*  66 */     Set<Origin> seen = new HashSet<>();
/*  67 */     return getPropertySources().filter(source -> source.containsProperty(propertyName))
/*  68 */       .map(source -> Descriptor.get(source, propertyName))
/*  69 */       .filter(descriptor -> seen.add(getOrigin(descriptor)))
/*  70 */       .toList();
/*     */   }
/*     */   
/*     */   private Origin getOrigin(Descriptor descriptor) {
/*  74 */     Origin origin = descriptor.origin;
/*  75 */     if (origin instanceof PropertySourceOrigin) { PropertySourceOrigin propertySourceOrigin = (PropertySourceOrigin)origin;
/*  76 */       origin = propertySourceOrigin.getOrigin(); }
/*     */     
/*  78 */     return origin;
/*     */   }
/*     */   
/*     */   private Stream<PropertySource<?>> getPropertySources() {
/*  82 */     return (this.environment != null) ? this.environment.getPropertySources().stream() : Stream.<PropertySource<?>>empty();
/*     */   }
/*     */ 
/*     */   
/*     */   private void appendDetails(StringBuilder message, InvalidConfigurationPropertyValueException cause, List<Descriptor> descriptors) {
/*  87 */     Descriptor mainDescriptor = descriptors.get(0);
/*  88 */     message.append("Invalid value '").append(mainDescriptor.getValue()).append("' for configuration property '");
/*  89 */     message.append(cause.getName()).append("'");
/*  90 */     mainDescriptor.appendOrigin(message);
/*  91 */     message.append(".");
/*     */   }
/*     */   
/*     */   private void appendReason(StringBuilder message, InvalidConfigurationPropertyValueException cause) {
/*  95 */     if (StringUtils.hasText(cause.getReason())) {
/*  96 */       message.append(String.format(" Validation failed for the following reason:%n%n", new Object[0]));
/*  97 */       message.append(cause.getReason());
/*     */     } else {
/*     */       
/* 100 */       message.append(" No reason was provided.");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void appendAdditionalProperties(StringBuilder message, List<Descriptor> descriptors) {
/* 105 */     List<Descriptor> others = descriptors.subList(1, descriptors.size());
/* 106 */     if (!others.isEmpty()) {
/* 107 */       message
/* 108 */         .append(String.format("%n%nAdditionally, this property is also set in the following property %s:%n%n", new Object[] {
/* 109 */               (others.size() > 1) ? "sources" : "source" }));
/* 110 */       for (Descriptor other : others) {
/* 111 */         message.append("\t- In '").append(other.getPropertySource()).append("'");
/* 112 */         message.append(" with the value '").append(other.getValue()).append("'");
/* 113 */         other.appendOrigin(message);
/* 114 */         message.append(String.format(".%n", new Object[0]));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getAction(InvalidConfigurationPropertyValueException cause) {
/* 120 */     StringBuilder action = new StringBuilder();
/* 121 */     action.append("Review the value of the property");
/* 122 */     if (cause.getReason() != null) {
/* 123 */       action.append(" with the provided reason");
/*     */     }
/* 125 */     action.append(".");
/* 126 */     return action.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Descriptor
/*     */   {
/*     */     private final String propertySource;
/*     */     
/*     */     private final Object value;
/*     */     private final Origin origin;
/*     */     
/*     */     private Descriptor(String propertySource, Object value, Origin origin) {
/* 138 */       this.propertySource = propertySource;
/* 139 */       this.value = value;
/* 140 */       this.origin = origin;
/*     */     }
/*     */     
/*     */     String getPropertySource() {
/* 144 */       return this.propertySource;
/*     */     }
/*     */     
/*     */     Object getValue() {
/* 148 */       return this.value;
/*     */     }
/*     */     
/*     */     void appendOrigin(StringBuilder message) {
/* 152 */       if (this.origin != null) {
/* 153 */         message.append(" (originating from '").append(this.origin).append("')");
/*     */       }
/*     */     }
/*     */     
/*     */     static Descriptor get(PropertySource<?> source, String propertyName) {
/* 158 */       Object value = source.getProperty(propertyName);
/* 159 */       Origin origin = OriginLookup.getOrigin(source, propertyName);
/* 160 */       return new Descriptor(source.getName(), value, origin);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\analyzer\InvalidConfigurationPropertyValueFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */