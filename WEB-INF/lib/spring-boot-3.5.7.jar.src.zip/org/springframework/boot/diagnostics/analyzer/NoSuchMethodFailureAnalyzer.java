/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NoSuchMethodFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<NoSuchMethodError>
/*     */ {
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, NoSuchMethodError cause) {
/*  42 */     NoSuchMethodDescriptor callerDescriptor = getCallerMethodDescriptor(cause);
/*  43 */     if (callerDescriptor == null) {
/*  44 */       return null;
/*     */     }
/*  46 */     NoSuchMethodDescriptor calledDescriptor = getNoSuchMethodDescriptor(cause.getMessage());
/*  47 */     if (calledDescriptor == null) {
/*  48 */       return null;
/*     */     }
/*  50 */     String description = getDescription(callerDescriptor, calledDescriptor);
/*  51 */     String action = getAction(callerDescriptor, calledDescriptor);
/*  52 */     return new FailureAnalysis(description, action, cause);
/*     */   }
/*     */   
/*     */   private NoSuchMethodDescriptor getCallerMethodDescriptor(NoSuchMethodError cause) {
/*  56 */     StackTraceElement firstStackTraceElement = cause.getStackTrace()[0];
/*  57 */     String message = firstStackTraceElement.toString();
/*  58 */     String className = firstStackTraceElement.getClassName();
/*  59 */     return getDescriptorForClass(message, className);
/*     */   }
/*     */   
/*     */   protected NoSuchMethodDescriptor getNoSuchMethodDescriptor(String cause) {
/*  63 */     String message = cleanMessage(cause);
/*  64 */     String className = extractClassName(message);
/*  65 */     return getDescriptorForClass(message, className);
/*     */   }
/*     */   
/*     */   private NoSuchMethodDescriptor getDescriptorForClass(String message, String className) {
/*  69 */     if (className == null) {
/*  70 */       return null;
/*     */     }
/*  72 */     List<URL> candidates = findCandidates(className);
/*  73 */     if (candidates == null) {
/*  74 */       return null;
/*     */     }
/*  76 */     Class<?> type = load(className);
/*  77 */     if (type == null) {
/*  78 */       return null;
/*     */     }
/*  80 */     List<ClassDescriptor> typeHierarchy = getTypeHierarchy(type);
/*  81 */     if (typeHierarchy == null) {
/*  82 */       return null;
/*     */     }
/*  84 */     return new NoSuchMethodDescriptor(message, className, candidates, typeHierarchy);
/*     */   }
/*     */   
/*     */   private String cleanMessage(String message) {
/*  88 */     int loadedFromIndex = message.indexOf(" (loaded from");
/*  89 */     if (loadedFromIndex == -1) {
/*  90 */       return message;
/*     */     }
/*  92 */     return message.substring(0, loadedFromIndex);
/*     */   }
/*     */   
/*     */   private String extractClassName(String message) {
/*  96 */     if (message.startsWith("'") && message.endsWith("'")) {
/*  97 */       int splitIndex = message.indexOf(' ');
/*  98 */       if (splitIndex == -1) {
/*  99 */         return null;
/*     */       }
/* 101 */       message = message.substring(splitIndex + 1);
/*     */     } 
/* 103 */     int descriptorIndex = message.indexOf('(');
/* 104 */     if (descriptorIndex == -1) {
/* 105 */       return null;
/*     */     }
/* 107 */     String classAndMethodName = message.substring(0, descriptorIndex);
/* 108 */     int methodNameIndex = classAndMethodName.lastIndexOf('.');
/* 109 */     if (methodNameIndex == -1) {
/* 110 */       return null;
/*     */     }
/* 112 */     String className = classAndMethodName.substring(0, methodNameIndex);
/* 113 */     return className.replace('/', '.');
/*     */   }
/*     */   
/*     */   private List<URL> findCandidates(String className) {
/*     */     try {
/* 118 */       return Collections.list(NoSuchMethodFailureAnalyzer.class.getClassLoader()
/* 119 */           .getResources(ClassUtils.convertClassNameToResourcePath(className) + ".class"));
/*     */     }
/* 121 */     catch (Throwable ex) {
/* 122 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Class<?> load(String className) {
/*     */     try {
/* 128 */       return Class.forName(className, false, getClass().getClassLoader());
/*     */     }
/* 130 */     catch (Throwable ex) {
/* 131 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<ClassDescriptor> getTypeHierarchy(Class<?> type) {
/*     */     try {
/* 137 */       List<ClassDescriptor> typeHierarchy = new ArrayList<>();
/* 138 */       while (type != null && !type.equals(Object.class)) {
/* 139 */         typeHierarchy.add(new ClassDescriptor(type.getCanonicalName(), type
/* 140 */               .getProtectionDomain().getCodeSource().getLocation()));
/* 141 */         type = type.getSuperclass();
/*     */       } 
/* 143 */       return typeHierarchy;
/*     */     }
/* 145 */     catch (Throwable ex) {
/* 146 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getDescription(NoSuchMethodDescriptor callerDescriptor, NoSuchMethodDescriptor calledDescriptor) {
/* 151 */     StringWriter description = new StringWriter();
/* 152 */     PrintWriter writer = new PrintWriter(description);
/* 153 */     writer.println("An attempt was made to call a method that does not exist. The attempt was made from the following location:");
/*     */     
/* 155 */     writer.println();
/* 156 */     writer.printf("    %s%n", new Object[] { callerDescriptor.getErrorMessage() });
/* 157 */     writer.println();
/* 158 */     writer.println("The following method did not exist:");
/* 159 */     writer.println();
/* 160 */     writer.printf("    %s%n", new Object[] { calledDescriptor.getErrorMessage() });
/* 161 */     writer.println();
/* 162 */     if (callerDescriptor.getCandidateLocations().size() > 1) {
/* 163 */       writer.printf("The calling method's class, %s, is available from the following locations:%n", new Object[] { callerDescriptor
/* 164 */             .getClassName() });
/* 165 */       writer.println();
/* 166 */       for (URL candidate : callerDescriptor.getCandidateLocations()) {
/* 167 */         writer.printf("    %s%n", new Object[] { candidate });
/*     */       } 
/* 169 */       writer.println();
/* 170 */       writer.println("The calling method's class was loaded from the following location:");
/* 171 */       writer.println();
/* 172 */       writer.printf("    %s%n", new Object[] { ((ClassDescriptor)callerDescriptor.getTypeHierarchy().get(0)).getLocation() });
/*     */     } else {
/*     */       
/* 175 */       writer.printf("The calling method's class, %s, was loaded from the following location:%n", new Object[] { callerDescriptor
/* 176 */             .getClassName() });
/* 177 */       writer.println();
/* 178 */       writer.printf("    %s%n", new Object[] { callerDescriptor.getCandidateLocations().get(0) });
/*     */     } 
/* 180 */     writer.println();
/* 181 */     writer.printf("The called method's class, %s, is available from the following locations:%n", new Object[] { calledDescriptor
/* 182 */           .getClassName() });
/* 183 */     writer.println();
/* 184 */     for (URL candidate : calledDescriptor.getCandidateLocations()) {
/* 185 */       writer.printf("    %s%n", new Object[] { candidate });
/*     */     } 
/* 187 */     writer.println();
/* 188 */     writer.println("The called method's class hierarchy was loaded from the following locations:");
/* 189 */     writer.println();
/* 190 */     for (ClassDescriptor type : calledDescriptor.getTypeHierarchy()) {
/* 191 */       writer.printf("    %s: %s%n", new Object[] { type.getName(), type.getLocation() });
/*     */     } 
/*     */     
/* 194 */     return description.toString();
/*     */   }
/*     */   
/*     */   private String getAction(NoSuchMethodDescriptor callerDescriptor, NoSuchMethodDescriptor calledDescriptor) {
/* 198 */     return callerDescriptor.getClassName().equals(calledDescriptor.getClassName()) ? ("Correct the classpath of your application so that it contains a single, compatible version of " + 
/* 199 */       calledDescriptor
/* 200 */       .getClassName()) : ("Correct the classpath of your application so that it contains compatible versions of the classes " + 
/*     */ 
/*     */       
/* 203 */       callerDescriptor
/* 204 */       .getClassName() + " and " + calledDescriptor.getClassName());
/*     */   }
/*     */ 
/*     */   
/*     */   protected static class NoSuchMethodDescriptor
/*     */   {
/*     */     private final String errorMessage;
/*     */     
/*     */     private final String className;
/*     */     
/*     */     private final List<URL> candidateLocations;
/*     */     
/*     */     private final List<NoSuchMethodFailureAnalyzer.ClassDescriptor> typeHierarchy;
/*     */ 
/*     */     
/*     */     public NoSuchMethodDescriptor(String errorMessage, String className, List<URL> candidateLocations, List<NoSuchMethodFailureAnalyzer.ClassDescriptor> typeHierarchy) {
/* 220 */       this.errorMessage = errorMessage;
/* 221 */       this.className = className;
/* 222 */       this.candidateLocations = candidateLocations;
/* 223 */       this.typeHierarchy = typeHierarchy;
/*     */     }
/*     */     
/*     */     public String getErrorMessage() {
/* 227 */       return this.errorMessage;
/*     */     }
/*     */     
/*     */     public String getClassName() {
/* 231 */       return this.className;
/*     */     }
/*     */     
/*     */     public List<URL> getCandidateLocations() {
/* 235 */       return this.candidateLocations;
/*     */     }
/*     */     
/*     */     public List<NoSuchMethodFailureAnalyzer.ClassDescriptor> getTypeHierarchy() {
/* 239 */       return this.typeHierarchy;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected static class ClassDescriptor
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final URL location;
/*     */     
/*     */     public ClassDescriptor(String name, URL location) {
/* 251 */       this.name = name;
/* 252 */       this.location = location;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 256 */       return this.name;
/*     */     }
/*     */     
/*     */     public URL getLocation() {
/* 260 */       return this.location;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\analyzer\NoSuchMethodFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */