/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import org.springframework.boot.AotInitializerNotFoundException;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AotInitializerNotFoundFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<AotInitializerNotFoundException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, AotInitializerNotFoundException cause) {
/* 33 */     return new FailureAnalysis(cause.getMessage(), "Consider the following:\n\tDid you build the application with enabled AOT processing?\n" + "\tIs the main class %s correct?\n"
/*    */         
/* 35 */         .formatted(new Object[] { cause.getMainClass().getName() }, ) + "\tIf you want to run the application in regular mode, remove the system property 'spring.aot.enabled'", (Throwable)cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\analyzer\AotInitializerNotFoundFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */