/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.validation.ObjectError;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExceptionDetails
/*     */ {
/*     */   private final List<ObjectError> errors;
/*     */   private final Object target;
/*     */   private final Throwable cause;
/*     */   
/*     */   ExceptionDetails(List<ObjectError> errors, Object target, Throwable cause) {
/*  97 */     this.errors = errors;
/*  98 */     this.target = target;
/*  99 */     this.cause = cause;
/*     */   }
/*     */   
/*     */   Object getTarget() {
/* 103 */     return this.target;
/*     */   }
/*     */   
/*     */   List<ObjectError> getErrors() {
/* 107 */     return this.errors;
/*     */   }
/*     */   
/*     */   Throwable getCause() {
/* 111 */     return this.cause;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\analyzer\BindValidationFailureAnalyzer$ExceptionDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */