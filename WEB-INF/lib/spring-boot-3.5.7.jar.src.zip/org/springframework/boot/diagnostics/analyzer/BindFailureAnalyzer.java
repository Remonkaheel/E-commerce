/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.boot.context.properties.bind.BindException;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.core.convert.ConversionFailedException;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BindFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<BindException>
/*     */ {
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, BindException cause) {
/*  47 */     Throwable rootCause = cause.getCause();
/*  48 */     if (rootCause instanceof org.springframework.boot.context.properties.bind.validation.BindValidationException || rootCause instanceof org.springframework.boot.context.properties.bind.UnboundConfigurationPropertiesException)
/*     */     {
/*  50 */       return null;
/*     */     }
/*  52 */     return analyzeGenericBindException(rootFailure, cause);
/*     */   }
/*     */ 
/*     */   
/*     */   private FailureAnalysis analyzeGenericBindException(Throwable rootFailure, BindException cause) {
/*  57 */     FailureAnalysis missingParametersAnalysis = MissingParameterNamesFailureAnalyzer.analyzeForMissingParameters(rootFailure);
/*  58 */     StringBuilder description = new StringBuilder(String.format("%s:%n", new Object[] { cause.getMessage() }));
/*  59 */     ConfigurationProperty property = cause.getProperty();
/*  60 */     buildDescription(description, property);
/*  61 */     description.append(String.format("%n    Reason: %s", new Object[] { getMessage(cause) }));
/*  62 */     if (missingParametersAnalysis != null) {
/*  63 */       MissingParameterNamesFailureAnalyzer.appendPossibility(description);
/*     */     }
/*  65 */     return getFailureAnalysis(description.toString(), cause, missingParametersAnalysis);
/*     */   }
/*     */   
/*     */   private void buildDescription(StringBuilder description, ConfigurationProperty property) {
/*  69 */     if (property != null) {
/*  70 */       description.append(String.format("%n    Property: %s", new Object[] { property.getName() }));
/*  71 */       description.append(String.format("%n    Value: \"%s\"", new Object[] { property.getValue() }));
/*  72 */       description.append(String.format("%n    Origin: %s", new Object[] { property.getOrigin() }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getMessage(BindException cause) {
/*  77 */     Throwable rootCause = getRootCause(cause.getCause());
/*  78 */     ConversionFailedException conversionFailure = (ConversionFailedException)findCause((Throwable)cause, ConversionFailedException.class);
/*  79 */     if (conversionFailure != null) {
/*     */       
/*  81 */       String message = "failed to convert " + String.valueOf(conversionFailure.getSourceType()) + " to " + String.valueOf(conversionFailure.getTargetType());
/*  82 */       if (rootCause != null) {
/*  83 */         message = message + " (caused by " + message + ")";
/*     */       }
/*  85 */       return message;
/*     */     } 
/*  87 */     if (rootCause != null && StringUtils.hasText(rootCause.getMessage())) {
/*  88 */       return getExceptionTypeAndMessage(rootCause);
/*     */     }
/*  90 */     return getExceptionTypeAndMessage((Throwable)cause);
/*     */   }
/*     */   
/*     */   private Throwable getRootCause(Throwable cause) {
/*  94 */     Throwable rootCause = cause;
/*  95 */     while (rootCause != null && rootCause.getCause() != null) {
/*  96 */       rootCause = rootCause.getCause();
/*     */     }
/*  98 */     return rootCause;
/*     */   }
/*     */   
/*     */   private String getExceptionTypeAndMessage(Throwable ex) {
/* 102 */     String message = ex.getMessage();
/* 103 */     return ex.getClass().getName() + ex.getClass().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   private FailureAnalysis getFailureAnalysis(String description, BindException cause, FailureAnalysis missingParametersAnalysis) {
/* 108 */     StringBuilder action = new StringBuilder("Update your application's configuration");
/* 109 */     Collection<String> validValues = findValidValues(cause);
/* 110 */     if (!validValues.isEmpty()) {
/* 111 */       action.append(String.format(". The following values are valid:%n", new Object[0]));
/* 112 */       validValues.forEach(value -> action.append(String.format("%n    %s", new Object[] { value })));
/*     */     } 
/* 114 */     if (missingParametersAnalysis != null) {
/* 115 */       action.append(String.format("%n%n%s", new Object[] { missingParametersAnalysis.getAction() }));
/*     */     }
/* 117 */     return new FailureAnalysis(description, action.toString(), (Throwable)cause);
/*     */   }
/*     */   
/*     */   private Collection<String> findValidValues(BindException ex) {
/* 121 */     ConversionFailedException conversionFailure = (ConversionFailedException)findCause((Throwable)ex, ConversionFailedException.class);
/* 122 */     if (conversionFailure != null) {
/* 123 */       Object[] enumConstants = conversionFailure.getTargetType().getType().getEnumConstants();
/* 124 */       if (enumConstants != null) {
/* 125 */         return (Collection<String>)Stream.<Object>of(enumConstants).map(Object::toString).collect(Collectors.toCollection(java.util.TreeSet::new));
/*     */       }
/*     */     } 
/* 128 */     return Collections.emptySet();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\analyzer\BindFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */