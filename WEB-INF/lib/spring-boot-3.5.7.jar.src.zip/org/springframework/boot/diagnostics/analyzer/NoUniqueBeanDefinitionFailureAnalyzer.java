/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NoUniqueBeanDefinitionFailureAnalyzer
/*    */   extends AbstractInjectionFailureAnalyzer<NoUniqueBeanDefinitionException>
/*    */ {
/*    */   private final ConfigurableBeanFactory beanFactory;
/*    */   
/*    */   NoUniqueBeanDefinitionFailureAnalyzer(BeanFactory beanFactory) {
/* 40 */     Assert.isInstanceOf(ConfigurableBeanFactory.class, beanFactory);
/* 41 */     this.beanFactory = (ConfigurableBeanFactory)beanFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, NoUniqueBeanDefinitionException cause, String description) {
/* 47 */     String[] beanNames = extractBeanNames(cause);
/* 48 */     if (beanNames == null) {
/* 49 */       return null;
/*    */     }
/* 51 */     StringBuilder message = new StringBuilder();
/* 52 */     message.append(String.format("%s required a single bean, but %d were found:%n", new Object[] {
/* 53 */             (description != null) ? description : "A component", Integer.valueOf(beanNames.length) }));
/* 54 */     for (String beanName : beanNames) {
/* 55 */       buildMessage(message, beanName);
/*    */     }
/* 57 */     MissingParameterNamesFailureAnalyzer.appendPossibility(message);
/* 58 */     StringBuilder action = new StringBuilder("Consider marking one of the beans as @Primary, updating the consumer to accept multiple beans, or using @Qualifier to identify the bean that should be consumed");
/*    */ 
/*    */     
/* 61 */     action.append("%n%n%s".formatted(new Object[] { "Ensure that your compiler is configured to use the '-parameters' flag.\nYou may need to update both your build tool settings as well as your IDE.\n(See https://github.com/spring-projects/spring-framework/wiki/Spring-Framework-6.1-Release-Notes#parameter-name-retention)\n" }));
/* 62 */     return new FailureAnalysis(message.toString(), action.toString(), (Throwable)cause);
/*    */   }
/*    */   
/*    */   private void buildMessage(StringBuilder message, String beanName) {
/*    */     try {
/* 67 */       BeanDefinition definition = this.beanFactory.getMergedBeanDefinition(beanName);
/* 68 */       message.append(getDefinitionDescription(beanName, definition));
/*    */     }
/* 70 */     catch (NoSuchBeanDefinitionException ex) {
/* 71 */       message.append(String.format("\t- %s: a programmatically registered singleton%n", new Object[] { beanName }));
/*    */     } 
/*    */   }
/*    */   
/*    */   private String getDefinitionDescription(String beanName, BeanDefinition definition) {
/* 76 */     if (StringUtils.hasText(definition.getFactoryMethodName())) {
/* 77 */       return String.format("\t- %s: defined by method '%s' in %s%n", new Object[] { beanName, definition.getFactoryMethodName(), 
/* 78 */             getResourceDescription(definition) });
/*    */     }
/* 80 */     return String.format("\t- %s: defined in %s%n", new Object[] { beanName, getResourceDescription(definition) });
/*    */   }
/*    */   
/*    */   private String getResourceDescription(BeanDefinition definition) {
/* 84 */     String resourceDescription = definition.getResourceDescription();
/* 85 */     return (resourceDescription != null) ? resourceDescription : "unknown location";
/*    */   }
/*    */   
/*    */   private String[] extractBeanNames(NoUniqueBeanDefinitionException cause) {
/* 89 */     if (cause.getMessage().contains("but found")) {
/* 90 */       return StringUtils.commaDelimitedListToStringArray(cause
/* 91 */           .getMessage().substring(cause.getMessage().lastIndexOf(':') + 1).trim());
/*    */     }
/* 93 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\analyzer\NoUniqueBeanDefinitionFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */