/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.boot.diagnostics.FailureAnalyzer;
/*     */ import org.springframework.core.annotation.Order;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(2147483647)
/*     */ class MissingParameterNamesFailureAnalyzer
/*     */   implements FailureAnalyzer
/*     */ {
/*     */   private static final String USE_PARAMETERS_MESSAGE = "Ensure that the compiler uses the '-parameters' flag";
/*     */   static final String POSSIBILITY = "This may be due to missing parameter name information";
/*     */   static final String ACTION = "Ensure that your compiler is configured to use the '-parameters' flag.\nYou may need to update both your build tool settings as well as your IDE.\n(See https://github.com/spring-projects/spring-framework/wiki/Spring-Framework-6.1-Release-Notes#parameter-name-retention)\n";
/*     */   
/*     */   public FailureAnalysis analyze(Throwable failure) {
/*  50 */     return analyzeForMissingParameters(failure);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static FailureAnalysis analyzeForMissingParameters(Throwable failure) {
/*  59 */     return analyzeForMissingParameters(failure, failure, new HashSet<>());
/*     */   }
/*     */ 
/*     */   
/*     */   private static FailureAnalysis analyzeForMissingParameters(Throwable rootFailure, Throwable cause, Set<Throwable> seen) {
/*  64 */     if (cause != null && seen.add(cause)) {
/*  65 */       if (isSpringParametersException(cause)) {
/*  66 */         return getAnalysis(rootFailure, cause);
/*     */       }
/*  68 */       FailureAnalysis analysis = analyzeForMissingParameters(rootFailure, cause.getCause(), seen);
/*  69 */       if (analysis != null) {
/*  70 */         return analysis;
/*     */       }
/*  72 */       for (Throwable suppressed : cause.getSuppressed()) {
/*  73 */         analysis = analyzeForMissingParameters(rootFailure, suppressed, seen);
/*  74 */         if (analysis != null) {
/*  75 */           return analysis;
/*     */         }
/*     */       } 
/*     */     } 
/*  79 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean isSpringParametersException(Throwable failure) {
/*  83 */     String message = failure.getMessage();
/*  84 */     return (message != null && message.contains("Ensure that the compiler uses the '-parameters' flag") && isSpringException(failure));
/*     */   }
/*     */   
/*     */   private static boolean isSpringException(Throwable failure) {
/*  88 */     StackTraceElement[] elements = failure.getStackTrace();
/*  89 */     return (elements.length > 0 && isSpringClass(elements[0].getClassName()));
/*     */   }
/*     */   
/*     */   private static boolean isSpringClass(String className) {
/*  93 */     return (className != null && className.startsWith("org.springframework."));
/*     */   }
/*     */   
/*     */   private static FailureAnalysis getAnalysis(Throwable rootFailure, Throwable cause) {
/*  97 */     StringBuilder description = new StringBuilder(String.format("%s:%n", new Object[] { cause.getMessage() }));
/*  98 */     if (rootFailure != cause) {
/*  99 */       description.append(String.format("%n    Resulting Failure: %s", new Object[] { getExceptionTypeAndMessage(rootFailure) }));
/*     */     }
/* 101 */     return new FailureAnalysis(description.toString(), "Ensure that your compiler is configured to use the '-parameters' flag.\nYou may need to update both your build tool settings as well as your IDE.\n(See https://github.com/spring-projects/spring-framework/wiki/Spring-Framework-6.1-Release-Notes#parameter-name-retention)\n", rootFailure);
/*     */   }
/*     */   
/*     */   private static String getExceptionTypeAndMessage(Throwable ex) {
/* 105 */     String message = ex.getMessage();
/* 106 */     return ex.getClass().getName() + ex.getClass().getName();
/*     */   }
/*     */   
/*     */   static void appendPossibility(StringBuilder description) {
/* 110 */     if (!description.toString().endsWith(System.lineSeparator())) {
/* 111 */       description.append("%n".formatted(new Object[0]));
/*     */     }
/* 113 */     description.append("%n%s".formatted(new Object[] { "This may be due to missing parameter name information" }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\analyzer\MissingParameterNamesFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */