/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.InjectionPoint;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.beans.factory.support.AbstractAutowireCapableBeanFactory;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanCurrentlyInCreationFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<BeanCurrentlyInCreationException>
/*     */ {
/*     */   private final AbstractAutowireCapableBeanFactory beanFactory;
/*     */   
/*     */   BeanCurrentlyInCreationFailureAnalyzer(BeanFactory beanFactory) {
/*  44 */     if (beanFactory instanceof AbstractAutowireCapableBeanFactory) { AbstractAutowireCapableBeanFactory autowireCapableBeanFactory = (AbstractAutowireCapableBeanFactory)beanFactory;
/*  45 */       this.beanFactory = autowireCapableBeanFactory; }
/*     */     else
/*     */     
/*  48 */     { this.beanFactory = null; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, BeanCurrentlyInCreationException cause) {
/*  54 */     DependencyCycle dependencyCycle = findCycle(rootFailure);
/*  55 */     if (dependencyCycle == null) {
/*  56 */       return null;
/*     */     }
/*  58 */     return new FailureAnalysis(buildMessage(dependencyCycle), action(), (Throwable)cause);
/*     */   }
/*     */   
/*     */   private String action() {
/*  62 */     if (this.beanFactory != null && this.beanFactory.isAllowCircularReferences()) {
/*  63 */       return "Despite circular references being allowed, the dependency cycle between beans could not be broken. Update your application to remove the dependency cycle.";
/*     */     }
/*     */     
/*  66 */     return "Relying upon circular references is discouraged and they are prohibited by default. Update your application to remove the dependency cycle between beans. As a last resort, it may be possible to break the cycle automatically by setting spring.main.allow-circular-references to true.";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DependencyCycle findCycle(Throwable rootFailure) {
/*  73 */     List<BeanInCycle> beansInCycle = new ArrayList<>();
/*  74 */     Throwable candidate = rootFailure;
/*  75 */     int cycleStart = -1;
/*  76 */     while (candidate != null) {
/*  77 */       BeanInCycle beanInCycle = BeanInCycle.get(candidate);
/*  78 */       if (beanInCycle != null) {
/*  79 */         int index = beansInCycle.indexOf(beanInCycle);
/*  80 */         if (index == -1) {
/*  81 */           beansInCycle.add(beanInCycle);
/*     */         }
/*  83 */         cycleStart = (cycleStart != -1) ? cycleStart : index;
/*     */       } 
/*  85 */       candidate = candidate.getCause();
/*     */     } 
/*  87 */     if (cycleStart == -1) {
/*  88 */       return null;
/*     */     }
/*  90 */     return new DependencyCycle(beansInCycle, cycleStart);
/*     */   }
/*     */   
/*     */   private String buildMessage(DependencyCycle dependencyCycle) {
/*  94 */     StringBuilder message = new StringBuilder();
/*  95 */     message.append(
/*  96 */         String.format("The dependencies of some of the beans in the application context form a cycle:%n%n", new Object[0]));
/*  97 */     List<BeanInCycle> beansInCycle = dependencyCycle.getBeansInCycle();
/*  98 */     boolean singleBean = (beansInCycle.size() == 1);
/*  99 */     int cycleStart = dependencyCycle.getCycleStart();
/* 100 */     for (int i = 0; i < beansInCycle.size(); i++) {
/* 101 */       BeanInCycle beanInCycle = beansInCycle.get(i);
/* 102 */       if (i == cycleStart) {
/* 103 */         message.append(String.format(singleBean ? "┌──->──┐%n" : "┌─────┐%n", new Object[0]));
/*     */       }
/* 105 */       else if (i > 0) {
/* 106 */         String str = (i < cycleStart) ? " " : "↑";
/* 107 */         message.append(String.format("%s     ↓%n", new Object[] { str }));
/*     */       } 
/* 109 */       String leftSide = (i < cycleStart) ? " " : "|";
/* 110 */       message.append(String.format("%s  %s%n", new Object[] { leftSide, beanInCycle }));
/*     */     } 
/* 112 */     message.append(String.format(singleBean ? "└──<-──┘%n" : "└─────┘%n", new Object[0]));
/* 113 */     return message.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class DependencyCycle
/*     */   {
/*     */     private final List<BeanCurrentlyInCreationFailureAnalyzer.BeanInCycle> beansInCycle;
/*     */     private final int cycleStart;
/*     */     
/*     */     private DependencyCycle(List<BeanCurrentlyInCreationFailureAnalyzer.BeanInCycle> beansInCycle, int cycleStart) {
/* 123 */       this.beansInCycle = beansInCycle;
/* 124 */       this.cycleStart = cycleStart;
/*     */     }
/*     */     
/*     */     List<BeanCurrentlyInCreationFailureAnalyzer.BeanInCycle> getBeansInCycle() {
/* 128 */       return this.beansInCycle;
/*     */     }
/*     */     
/*     */     int getCycleStart() {
/* 132 */       return this.cycleStart;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class BeanInCycle
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final String description;
/*     */     
/*     */     private BeanInCycle(BeanCreationException ex) {
/* 144 */       this.name = ex.getBeanName();
/* 145 */       this.description = determineDescription(ex);
/*     */     }
/*     */     
/*     */     private String determineDescription(BeanCreationException ex) {
/* 149 */       if (StringUtils.hasText(ex.getResourceDescription())) {
/* 150 */         return String.format(" defined in %s", new Object[] { ex.getResourceDescription() });
/*     */       }
/* 152 */       InjectionPoint failedInjectionPoint = findFailedInjectionPoint(ex);
/* 153 */       if (failedInjectionPoint != null && failedInjectionPoint.getField() != null) {
/* 154 */         return String.format(" (field %s)", new Object[] { failedInjectionPoint.getField() });
/*     */       }
/* 156 */       return "";
/*     */     }
/*     */     
/*     */     private InjectionPoint findFailedInjectionPoint(BeanCreationException ex) {
/* 160 */       if (ex instanceof UnsatisfiedDependencyException) { UnsatisfiedDependencyException unsatisfiedDependencyException = (UnsatisfiedDependencyException)ex;
/* 161 */         return unsatisfiedDependencyException.getInjectionPoint(); }
/*     */       
/* 163 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 168 */       if (this == obj) {
/* 169 */         return true;
/*     */       }
/* 171 */       if (obj == null || getClass() != obj.getClass()) {
/* 172 */         return false;
/*     */       }
/* 174 */       return this.name.equals(((BeanInCycle)obj).name);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 179 */       return this.name.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 184 */       return this.name + this.name;
/*     */     }
/*     */     
/*     */     static BeanInCycle get(Throwable ex) {
/* 188 */       if (ex instanceof BeanCreationException) { BeanCreationException beanCreationException = (BeanCreationException)ex;
/* 189 */         return get(beanCreationException); }
/*     */       
/* 191 */       return null;
/*     */     }
/*     */     
/*     */     private static BeanInCycle get(BeanCreationException ex) {
/* 195 */       if (StringUtils.hasText(ex.getBeanName())) {
/* 196 */         return new BeanInCycle(ex);
/*     */       }
/* 198 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\analyzer\BeanCurrentlyInCreationFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */