/*     */ package org.springframework.boot.diagnostics;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.boot.SpringBootExceptionReporter;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FailureAnalyzers
/*     */   implements SpringBootExceptionReporter
/*     */ {
/*  48 */   private static final Log logger = LogFactory.getLog(FailureAnalyzers.class);
/*     */   
/*     */   private final SpringFactoriesLoader springFactoriesLoader;
/*     */   
/*     */   private final List<FailureAnalyzer> analyzers;
/*     */   
/*     */   public FailureAnalyzers(ConfigurableApplicationContext context) {
/*  55 */     this(context, 
/*  56 */         SpringFactoriesLoader.forDefaultResourceLocation((context != null) ? context.getClassLoader() : null));
/*     */   }
/*     */   
/*     */   FailureAnalyzers(ConfigurableApplicationContext context, SpringFactoriesLoader springFactoriesLoader) {
/*  60 */     this.springFactoriesLoader = springFactoriesLoader;
/*  61 */     this.analyzers = loadFailureAnalyzers(context, this.springFactoriesLoader);
/*     */   }
/*     */ 
/*     */   
/*     */   private static List<FailureAnalyzer> loadFailureAnalyzers(ConfigurableApplicationContext context, SpringFactoriesLoader springFactoriesLoader) {
/*  66 */     return springFactoriesLoader.load(FailureAnalyzer.class, getArgumentResolver(context), 
/*  67 */         SpringFactoriesLoader.FailureHandler.logging(logger));
/*     */   }
/*     */   
/*     */   private static SpringFactoriesLoader.ArgumentResolver getArgumentResolver(ConfigurableApplicationContext context) {
/*  71 */     if (context == null) {
/*  72 */       return null;
/*     */     }
/*  74 */     SpringFactoriesLoader.ArgumentResolver argumentResolver = SpringFactoriesLoader.ArgumentResolver.of(BeanFactory.class, context.getBeanFactory());
/*  75 */     argumentResolver = argumentResolver.and(Environment.class, context.getEnvironment());
/*  76 */     return argumentResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean reportException(Throwable failure) {
/*  81 */     FailureAnalysis analysis = analyze(failure, this.analyzers);
/*  82 */     return report(analysis);
/*     */   }
/*     */   
/*     */   private FailureAnalysis analyze(Throwable failure, List<FailureAnalyzer> analyzers) {
/*  86 */     for (FailureAnalyzer analyzer : analyzers) {
/*     */       try {
/*  88 */         FailureAnalysis analysis = analyzer.analyze(failure);
/*  89 */         if (analysis != null) {
/*  90 */           return analysis;
/*     */         }
/*     */       }
/*  93 */       catch (Throwable ex) {
/*  94 */         logger.trace(LogMessage.format("FailureAnalyzer %s failed", analyzer), ex);
/*     */       } 
/*     */     } 
/*  97 */     return null;
/*     */   }
/*     */   
/*     */   private boolean report(FailureAnalysis analysis) {
/* 101 */     List<FailureAnalysisReporter> reporters = this.springFactoriesLoader.load(FailureAnalysisReporter.class);
/* 102 */     if (analysis == null || reporters.isEmpty()) {
/* 103 */       return false;
/*     */     }
/* 105 */     for (FailureAnalysisReporter reporter : reporters) {
/* 106 */       reporter.report(analysis);
/*     */     }
/* 108 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\FailureAnalyzers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */