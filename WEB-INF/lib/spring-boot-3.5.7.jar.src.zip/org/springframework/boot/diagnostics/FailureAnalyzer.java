package org.springframework.boot.diagnostics;

@FunctionalInterface
public interface FailureAnalyzer {
  FailureAnalysis analyze(Throwable paramThrowable);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\FailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */