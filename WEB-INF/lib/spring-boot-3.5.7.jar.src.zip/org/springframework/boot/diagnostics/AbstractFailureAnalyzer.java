/*    */ package org.springframework.boot.diagnostics;
/*    */ 
/*    */ import org.springframework.core.ResolvableType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractFailureAnalyzer<T extends Throwable>
/*    */   implements FailureAnalyzer
/*    */ {
/*    */   public FailureAnalysis analyze(Throwable failure) {
/* 33 */     T cause = findCause(failure, getCauseType());
/* 34 */     return (cause != null) ? analyze(failure, cause) : null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract FailureAnalysis analyze(Throwable paramThrowable, T paramT);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Class<? extends T> getCauseType() {
/* 53 */     return ResolvableType.forClass(AbstractFailureAnalyzer.class, getClass()).resolveGeneric(new int[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   protected final <E extends Throwable> E findCause(Throwable failure, Class<E> type) {
/* 58 */     while (failure != null) {
/* 59 */       if (type.isInstance(failure)) {
/* 60 */         return (E)failure;
/*    */       }
/* 62 */       failure = failure.getCause();
/*    */     } 
/* 64 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\diagnostics\AbstractFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */