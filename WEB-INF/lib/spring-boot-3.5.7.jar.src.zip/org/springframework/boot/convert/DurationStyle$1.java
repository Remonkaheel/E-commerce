/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import java.util.regex.Matcher;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum null
/*    */ {
/*    */   public Duration parse(String value, ChronoUnit unit) {
/*    */     try {
/* 45 */       Matcher matcher = matcher(value);
/* 46 */       Assert.state(matcher.matches(), "Does not match simple duration pattern");
/* 47 */       String suffix = matcher.group(2);
/* 48 */       return (StringUtils.hasLength(suffix) ? DurationStyle.Unit.fromSuffix(suffix) : DurationStyle.Unit.fromChronoUnit(unit))
/* 49 */         .parse(matcher.group(1));
/*    */     }
/* 51 */     catch (Exception ex) {
/* 52 */       throw new IllegalArgumentException("'" + value + "' is not a valid simple duration", ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String print(Duration value, ChronoUnit unit) {
/* 58 */     return DurationStyle.Unit.fromChronoUnit(unit).print(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\DurationStyle$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */