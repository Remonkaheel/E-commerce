/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConverterFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class LenientObjectToEnumConverterFactory<T>
/*     */   implements ConverterFactory<T, Enum<?>>
/*     */ {
/*     */   private static final Map<String, List<String>> ALIASES;
/*     */   
/*     */   static {
/*  44 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/*  45 */     linkedMultiValueMap.add("true", "on");
/*  46 */     linkedMultiValueMap.add("false", "off");
/*  47 */     ALIASES = Collections.unmodifiableMap((Map<? extends String, ? extends List<String>>)linkedMultiValueMap);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends Enum<?>> Converter<T, E> getConverter(Class<E> targetType) {
/*  53 */     Class<?> enumType = targetType;
/*  54 */     while (enumType != null && !enumType.isEnum()) {
/*  55 */       enumType = enumType.getSuperclass();
/*     */     }
/*  57 */     Assert.notNull(enumType, () -> "The target type " + targetType.getName() + " does not refer to an enum");
/*  58 */     return new LenientToEnumConverter(enumType);
/*     */   }
/*     */   
/*     */   private class LenientToEnumConverter<E extends Enum>
/*     */     implements Converter<T, E>
/*     */   {
/*     */     private final Class<E> enumType;
/*     */     
/*     */     LenientToEnumConverter(Class<E> enumType) {
/*  67 */       this.enumType = enumType;
/*     */     }
/*     */ 
/*     */     
/*     */     public E convert(T source) {
/*  72 */       String value = source.toString().trim();
/*  73 */       if (value.isEmpty()) {
/*  74 */         return null;
/*     */       }
/*     */       try {
/*  77 */         return Enum.valueOf(this.enumType, value);
/*     */       }
/*  79 */       catch (Exception ex) {
/*  80 */         return findEnum(value);
/*     */       } 
/*     */     }
/*     */     
/*     */     private E findEnum(String value) {
/*  85 */       String name = getCanonicalName(value);
/*  86 */       List<String> aliases = LenientObjectToEnumConverterFactory.ALIASES.getOrDefault(name, Collections.emptyList());
/*  87 */       for (Enum enum_ : EnumSet.<Enum>allOf(this.enumType)) {
/*  88 */         String candidateName = getCanonicalName(enum_.name());
/*  89 */         if (name.equals(candidateName) || aliases.contains(candidateName)) {
/*  90 */           return (E)enum_;
/*     */         }
/*     */       } 
/*  93 */       throw new IllegalArgumentException("No enum constant " + this.enumType.getCanonicalName() + "." + value);
/*     */     }
/*     */     
/*     */     private String getCanonicalName(String name) {
/*  97 */       StringBuilder canonicalName = new StringBuilder(name.length());
/*  98 */       name.chars()
/*  99 */         .filter(Character::isLetterOrDigit)
/* 100 */         .map(Character::toLowerCase)
/* 101 */         .forEach(c -> canonicalName.append((char)c));
/* 102 */       return canonicalName.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\LenientObjectToEnumConverterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */