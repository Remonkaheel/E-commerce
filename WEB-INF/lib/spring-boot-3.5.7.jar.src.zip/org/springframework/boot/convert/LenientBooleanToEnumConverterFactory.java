package org.springframework.boot.convert;

final class LenientBooleanToEnumConverterFactory extends LenientObjectToEnumConverterFactory<Boolean> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\LenientBooleanToEnumConverterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */