/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum Unit
/*     */ {
/* 182 */   NANOS(ChronoUnit.NANOS, "ns", Duration::toNanos),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   MILLIS(ChronoUnit.MILLIS, "ms", Duration::toMillis),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   SECONDS(ChronoUnit.SECONDS, "s", Duration::getSeconds),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   MINUTES(ChronoUnit.MINUTES, "m", Duration::toMinutes),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   HOURS(ChronoUnit.HOURS, "h", Duration::toHours),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 212 */   DAYS(ChronoUnit.DAYS, "d", Duration::toDays), MICROS(ChronoUnit.DAYS, "d", Duration::toDays);
/*     */   
/*     */   static {
/*     */     MICROS = new Unit("MICROS", 1, ChronoUnit.MICROS, "us", duration -> Long.valueOf(duration.toNanos() / 1000L));
/*     */   }
/*     */   
/*     */   private final ChronoUnit chronoUnit;
/*     */   
/*     */   Unit(ChronoUnit chronoUnit, String suffix, Function<Duration, Long> toUnit) {
/* 221 */     this.chronoUnit = chronoUnit;
/* 222 */     this.suffix = suffix;
/* 223 */     this.longValue = toUnit;
/*     */   }
/*     */   private final String suffix; private final Function<Duration, Long> longValue;
/*     */   public Duration parse(String value) {
/* 227 */     return Duration.of(Long.parseLong(value), this.chronoUnit);
/*     */   }
/*     */   
/*     */   public String print(Duration value) {
/* 231 */     return "" + longValue(value) + longValue(value);
/*     */   }
/*     */   
/*     */   public long longValue(Duration value) {
/* 235 */     return ((Long)this.longValue.apply(value)).longValue();
/*     */   }
/*     */   
/*     */   public static Unit fromChronoUnit(ChronoUnit chronoUnit) {
/* 239 */     if (chronoUnit == null) {
/* 240 */       return MILLIS;
/*     */     }
/* 242 */     for (Unit candidate : values()) {
/* 243 */       if (candidate.chronoUnit == chronoUnit) {
/* 244 */         return candidate;
/*     */       }
/*     */     } 
/* 247 */     throw new IllegalArgumentException("Unknown unit " + String.valueOf(chronoUnit));
/*     */   }
/*     */   
/*     */   public static Unit fromSuffix(String suffix) {
/* 251 */     for (Unit candidate : values()) {
/* 252 */       if (candidate.suffix.equalsIgnoreCase(suffix)) {
/* 253 */         return candidate;
/*     */       }
/*     */     } 
/* 256 */     throw new IllegalArgumentException("Unknown unit '" + suffix + "'");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\DurationStyle$Unit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */