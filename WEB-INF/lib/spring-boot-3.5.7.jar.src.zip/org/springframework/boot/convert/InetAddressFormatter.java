/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import java.net.UnknownHostException;
/*    */ import java.text.ParseException;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class InetAddressFormatter
/*    */   implements Formatter<InetAddress>
/*    */ {
/*    */   public String print(InetAddress object, Locale locale) {
/* 35 */     return object.getHostAddress();
/*    */   }
/*    */ 
/*    */   
/*    */   public InetAddress parse(String text, Locale locale) throws ParseException {
/*    */     try {
/* 41 */       return InetAddress.getByName(text);
/*    */     }
/* 43 */     catch (UnknownHostException ex) {
/* 44 */       throw new IllegalStateException("Unknown host " + text, ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\InetAddressFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */