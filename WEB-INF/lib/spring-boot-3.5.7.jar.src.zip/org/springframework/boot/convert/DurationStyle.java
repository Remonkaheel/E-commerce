/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.function.Function;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum DurationStyle
/*     */ {
/*  40 */   SIMPLE("^([+-]?\\d+)([a-zA-Z]{0,2})$")
/*     */   {
/*     */     public Duration parse(String value, ChronoUnit unit)
/*     */     {
/*     */       try {
/*  45 */         Matcher matcher = matcher(value);
/*  46 */         Assert.state(matcher.matches(), "Does not match simple duration pattern");
/*  47 */         String suffix = matcher.group(2);
/*  48 */         return (StringUtils.hasLength(suffix) ? Unit.fromSuffix(suffix) : Unit.fromChronoUnit(unit))
/*  49 */           .parse(matcher.group(1));
/*     */       }
/*  51 */       catch (Exception ex) {
/*  52 */         throw new IllegalArgumentException("'" + value + "' is not a valid simple duration", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String print(Duration value, ChronoUnit unit) {
/*  58 */       return Unit.fromChronoUnit(unit).print(value);
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   ISO8601("^[+-]?[pP].*$")
/*     */   {
/*     */     public Duration parse(String value, ChronoUnit unit)
/*     */     {
/*     */       try {
/*  71 */         return Duration.parse(value);
/*     */       }
/*  73 */       catch (Exception ex) {
/*  74 */         throw new IllegalArgumentException("'" + value + "' is not a valid ISO-8601 duration", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String print(Duration value, ChronoUnit unit) {
/*  80 */       return value.toString();
/*     */     }
/*     */   };
/*     */ 
/*     */   
/*     */   private final Pattern pattern;
/*     */   
/*     */   DurationStyle(String pattern) {
/*  88 */     this.pattern = Pattern.compile(pattern);
/*     */   }
/*     */   
/*     */   protected final boolean matches(String value) {
/*  92 */     return this.pattern.matcher(value).matches();
/*     */   }
/*     */   
/*     */   protected final Matcher matcher(String value) {
/*  96 */     return this.pattern.matcher(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration parse(String value) {
/* 105 */     return parse(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String print(Duration value) {
/* 123 */     return print(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Duration detectAndParse(String value) {
/* 142 */     return detectAndParse(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Duration detectAndParse(String value, ChronoUnit unit) {
/* 155 */     return detect(value).parse(value, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DurationStyle detect(String value) {
/* 165 */     Assert.notNull(value, "'value' must not be null");
/* 166 */     for (DurationStyle candidate : values()) {
/* 167 */       if (candidate.matches(value)) {
/* 168 */         return candidate;
/*     */       }
/*     */     } 
/* 171 */     throw new IllegalArgumentException("'" + value + "' is not a valid duration");
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract Duration parse(String paramString, ChronoUnit paramChronoUnit);
/*     */ 
/*     */   
/*     */   public abstract String print(Duration paramDuration, ChronoUnit paramChronoUnit);
/*     */   
/*     */   enum Unit
/*     */   {
/* 182 */     NANOS((String)ChronoUnit.NANOS, "ns", (ChronoUnit)Duration::toNanos),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     MILLIS((String)ChronoUnit.MILLIS, "ms", (ChronoUnit)Duration::toMillis),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     SECONDS((String)ChronoUnit.SECONDS, "s", (ChronoUnit)Duration::getSeconds),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 202 */     MINUTES((String)ChronoUnit.MINUTES, "m", (ChronoUnit)Duration::toMinutes),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 207 */     HOURS((String)ChronoUnit.HOURS, "h", (ChronoUnit)Duration::toHours),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     DAYS((String)ChronoUnit.DAYS, "d", (ChronoUnit)Duration::toDays), MICROS((String)ChronoUnit.DAYS, "d", (ChronoUnit)Duration::toDays);
/*     */     
/*     */     static {
/*     */       MICROS = new Unit("MICROS", 1, ChronoUnit.MICROS, "us", duration -> Long.valueOf(duration.toNanos() / 1000L));
/*     */     }
/*     */     
/*     */     private final ChronoUnit chronoUnit;
/*     */     
/*     */     Unit(ChronoUnit chronoUnit, String suffix, Function<Duration, Long> toUnit) {
/* 221 */       this.chronoUnit = chronoUnit;
/* 222 */       this.suffix = suffix;
/* 223 */       this.longValue = toUnit;
/*     */     }
/*     */     private final String suffix; private final Function<Duration, Long> longValue;
/*     */     public Duration parse(String value) {
/* 227 */       return Duration.of(Long.parseLong(value), this.chronoUnit);
/*     */     }
/*     */     
/*     */     public String print(Duration value) {
/* 231 */       return "" + longValue(value) + longValue(value);
/*     */     }
/*     */     
/*     */     public long longValue(Duration value) {
/* 235 */       return ((Long)this.longValue.apply(value)).longValue();
/*     */     }
/*     */     
/*     */     public static Unit fromChronoUnit(ChronoUnit chronoUnit) {
/* 239 */       if (chronoUnit == null) {
/* 240 */         return MILLIS;
/*     */       }
/* 242 */       for (Unit candidate : values()) {
/* 243 */         if (candidate.chronoUnit == chronoUnit) {
/* 244 */           return candidate;
/*     */         }
/*     */       } 
/* 247 */       throw new IllegalArgumentException("Unknown unit " + String.valueOf(chronoUnit));
/*     */     }
/*     */     
/*     */     public static Unit fromSuffix(String suffix) {
/* 251 */       for (Unit candidate : values()) {
/* 252 */         if (candidate.suffix.equalsIgnoreCase(suffix)) {
/* 253 */           return candidate;
/*     */         }
/*     */       } 
/* 256 */       throw new IllegalArgumentException("Unknown unit '" + suffix + "'");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\DurationStyle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */