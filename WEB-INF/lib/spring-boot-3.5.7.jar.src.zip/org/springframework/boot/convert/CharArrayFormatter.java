/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CharArrayFormatter
/*    */   implements Formatter<char[]>
/*    */ {
/*    */   public String print(char[] object, Locale locale) {
/* 33 */     return new String(object);
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] parse(String text, Locale locale) throws ParseException {
/* 38 */     return text.toCharArray();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\CharArrayFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */