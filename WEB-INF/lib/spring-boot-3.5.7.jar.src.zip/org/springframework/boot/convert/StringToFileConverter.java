/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import org.springframework.boot.io.ApplicationResourceLoader;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringToFileConverter
/*    */   implements Converter<String, File>
/*    */ {
/*    */   public File convert(String source) {
/* 37 */     return getFile(ApplicationResourceLoader.get().getResource(source));
/*    */   }
/*    */   
/*    */   private File getFile(Resource resource) {
/*    */     try {
/* 42 */       return resource.getFile();
/*    */     }
/* 44 */     catch (IOException ex) {
/* 45 */       throw new IllegalStateException("Could not retrieve file for " + String.valueOf(resource) + ": " + ex.getMessage());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\StringToFileConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */