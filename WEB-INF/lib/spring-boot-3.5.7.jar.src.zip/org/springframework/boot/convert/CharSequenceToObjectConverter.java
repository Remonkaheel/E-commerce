/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CharSequenceToObjectConverter
/*     */   implements ConditionalGenericConverter
/*     */ {
/*  34 */   private static final TypeDescriptor STRING = TypeDescriptor.valueOf(String.class);
/*     */   
/*  36 */   private static final TypeDescriptor BYTE_ARRAY = TypeDescriptor.valueOf(byte[].class);
/*     */ 
/*     */ 
/*     */   
/*  40 */   private final ThreadLocal<Boolean> disable = new ThreadLocal<>();
/*     */ 
/*     */   
/*  43 */   private static final Set<GenericConverter.ConvertiblePair> TYPES = Collections.singleton(new GenericConverter.ConvertiblePair(CharSequence.class, Object.class));
/*     */   
/*     */   private final ConversionService conversionService;
/*     */ 
/*     */   
/*     */   CharSequenceToObjectConverter(ConversionService conversionService) {
/*  49 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/*  54 */     return TYPES;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/*  59 */     if (sourceType.getType() == String.class || this.disable.get() == Boolean.TRUE) {
/*  60 */       return false;
/*     */     }
/*  62 */     this.disable.set(Boolean.TRUE);
/*     */     try {
/*  64 */       boolean canDirectlyConvertCharSequence = this.conversionService.canConvert(sourceType, targetType);
/*  65 */       if (canDirectlyConvertCharSequence && !isStringConversionBetter(sourceType, targetType)) {
/*  66 */         return false;
/*     */       }
/*  68 */       return this.conversionService.canConvert(STRING, targetType);
/*     */     } finally {
/*     */       
/*  71 */       this.disable.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isStringConversionBetter(TypeDescriptor sourceType, TypeDescriptor targetType) {
/*  83 */     ConversionService conversionService = this.conversionService; if (conversionService instanceof ApplicationConversionService) { ApplicationConversionService applicationConversionService = (ApplicationConversionService)conversionService;
/*  84 */       if (applicationConversionService.isConvertViaObjectSourceType(sourceType, targetType))
/*     */       {
/*     */         
/*  87 */         return true;
/*     */       } }
/*     */     
/*  90 */     if ((targetType.isArray() || targetType.isCollection()) && !targetType.equals(BYTE_ARRAY))
/*     */     {
/*     */       
/*  93 */       return true;
/*     */     }
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 100 */     return this.conversionService.convert(source.toString(), STRING, targetType);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\CharSequenceToObjectConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */