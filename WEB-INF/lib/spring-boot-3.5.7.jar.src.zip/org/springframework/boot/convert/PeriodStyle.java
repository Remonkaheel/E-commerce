/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.time.Period;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.function.Function;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PeriodStyle
/*     */ {
/*  41 */   SIMPLE("^(?:([-+]?[0-9]+)Y)?(?:([-+]?[0-9]+)M)?(?:([-+]?[0-9]+)W)?(?:([-+]?[0-9]+)D)?$", 2)
/*     */   {
/*     */     
/*     */     public Period parse(String value, ChronoUnit unit)
/*     */     {
/*     */       try {
/*  47 */         if (PeriodStyle.NUMERIC.matcher(value).matches()) {
/*  48 */           return Unit.fromChronoUnit(unit).parse(value);
/*     */         }
/*  50 */         Matcher matcher = matcher(value);
/*  51 */         Assert.state(matcher.matches(), "Does not match simple period pattern");
/*  52 */         Assert.isTrue(hasAtLeastOneGroupValue(matcher), () -> "'" + value + "' is not a valid simple period");
/*  53 */         int years = parseInt(matcher, 1);
/*  54 */         int months = parseInt(matcher, 2);
/*  55 */         int weeks = parseInt(matcher, 3);
/*  56 */         int days = parseInt(matcher, 4);
/*  57 */         return Period.of(years, months, Math.addExact(Math.multiplyExact(weeks, 7), days));
/*     */       }
/*  59 */       catch (Exception ex) {
/*  60 */         throw new IllegalArgumentException("'" + value + "' is not a valid simple period", ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean hasAtLeastOneGroupValue(Matcher matcher) {
/*  65 */       for (int i = 0; i < matcher.groupCount(); i++) {
/*  66 */         if (matcher.group(i + 1) != null) {
/*  67 */           return true;
/*     */         }
/*     */       } 
/*  70 */       return false;
/*     */     }
/*     */     
/*     */     private int parseInt(Matcher matcher, int group) {
/*  74 */       String value = matcher.group(group);
/*  75 */       return (value != null) ? Integer.parseInt(value) : 0;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean matches(String value) {
/*  80 */       return (PeriodStyle.NUMERIC.matcher(value).matches() || matcher(value).matches());
/*     */     }
/*     */ 
/*     */     
/*     */     public String print(Period value, ChronoUnit unit) {
/*  85 */       if (value.isZero()) {
/*  86 */         return Unit.fromChronoUnit(unit).print(value);
/*     */       }
/*  88 */       StringBuilder result = new StringBuilder();
/*  89 */       append(result, value, Unit.YEARS);
/*  90 */       append(result, value, Unit.MONTHS);
/*  91 */       append(result, value, Unit.DAYS);
/*  92 */       return result.toString();
/*     */     }
/*     */     
/*     */     private void append(StringBuilder result, Period value, Unit unit) {
/*  96 */       if (!unit.isZero(value)) {
/*  97 */         result.append(unit.print(value));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */     }
/*     */   },
/* 106 */   ISO8601("^[+-]?P.*$", 2)
/*     */   {
/*     */     public Period parse(String value, ChronoUnit unit)
/*     */     {
/*     */       try {
/* 111 */         return Period.parse(value);
/*     */       }
/* 113 */       catch (Exception ex) {
/* 114 */         throw new IllegalArgumentException("'" + value + "' is not a valid ISO-8601 period", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String print(Period value, ChronoUnit unit) {
/* 120 */       return value.toString();
/*     */     } };
/*     */   private static final Pattern NUMERIC;
/*     */   
/*     */   static {
/* 125 */     NUMERIC = Pattern.compile("^[-+]?[0-9]+$");
/*     */   }
/*     */   private final Pattern pattern;
/*     */   
/*     */   PeriodStyle(String pattern, int flags) {
/* 130 */     this.pattern = Pattern.compile(pattern, flags);
/*     */   }
/*     */   
/*     */   protected boolean matches(String value) {
/* 134 */     return this.pattern.matcher(value).matches();
/*     */   }
/*     */   
/*     */   protected final Matcher matcher(String value) {
/* 138 */     return this.pattern.matcher(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Period parse(String value) {
/* 147 */     return parse(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String print(Period value) {
/* 165 */     return print(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Period detectAndParse(String value) {
/* 184 */     return detectAndParse(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Period detectAndParse(String value, ChronoUnit unit) {
/* 197 */     return detect(value).parse(value, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PeriodStyle detect(String value) {
/* 207 */     Assert.notNull(value, "'value' must not be null");
/* 208 */     for (PeriodStyle candidate : values()) {
/* 209 */       if (candidate.matches(value)) {
/* 210 */         return candidate;
/*     */       }
/*     */     } 
/* 213 */     throw new IllegalArgumentException("'" + value + "' is not a valid period");
/*     */   }
/*     */   
/*     */   public abstract Period parse(String paramString, ChronoUnit paramChronoUnit);
/*     */   
/*     */   public abstract String print(Period paramPeriod, ChronoUnit paramChronoUnit);
/*     */   
/*     */   private enum Unit {
/* 221 */     DAYS((String)ChronoUnit.DAYS, "d", (ChronoUnit)Period::getDays, (String)Period::ofDays),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 226 */     WEEKS((String)ChronoUnit.WEEKS, "w", null, (String)Period::ofWeeks),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     MONTHS((String)ChronoUnit.MONTHS, "m", (ChronoUnit)Period::getMonths, (String)Period::ofMonths),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     YEARS((String)ChronoUnit.YEARS, "y", (ChronoUnit)Period::getYears, (String)Period::ofYears);
/*     */     
/*     */     private final ChronoUnit chronoUnit;
/*     */     
/*     */     private final String suffix;
/*     */     
/*     */     private final Function<Period, Integer> intValue;
/*     */     
/*     */     private final Function<Integer, Period> factory;
/*     */ 
/*     */     
/*     */     Unit(ChronoUnit chronoUnit, String suffix, Function<Period, Integer> intValue, Function<Integer, Period> factory) {
/* 248 */       this.chronoUnit = chronoUnit;
/* 249 */       this.suffix = suffix;
/* 250 */       this.intValue = intValue;
/* 251 */       this.factory = factory;
/*     */     }
/*     */     
/*     */     private Period parse(String value) {
/* 255 */       return this.factory.apply(Integer.valueOf(Integer.parseInt(value)));
/*     */     }
/*     */     
/*     */     private String print(Period value) {
/* 259 */       return "" + intValue(value) + intValue(value);
/*     */     }
/*     */     
/*     */     private boolean isZero(Period value) {
/* 263 */       return (intValue(value) == 0);
/*     */     }
/*     */     
/*     */     private int intValue(Period value) {
/* 267 */       Assert.state((this.intValue != null), () -> "intValue cannot be extracted from " + name());
/* 268 */       return ((Integer)this.intValue.apply(value)).intValue();
/*     */     }
/*     */     
/*     */     private static Unit fromChronoUnit(ChronoUnit chronoUnit) {
/* 272 */       if (chronoUnit == null) {
/* 273 */         return DAYS;
/*     */       }
/* 275 */       for (Unit candidate : values()) {
/* 276 */         if (candidate.chronoUnit == chronoUnit) {
/* 277 */           return candidate;
/*     */         }
/*     */       } 
/* 280 */       throw new IllegalArgumentException("Unsupported unit " + String.valueOf(chronoUnit));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\PeriodStyle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */