/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.time.OffsetDateTime;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IsoOffsetFormatter
/*    */   implements Formatter<OffsetDateTime>
/*    */ {
/*    */   public String print(OffsetDateTime object, Locale locale) {
/* 38 */     return DateTimeFormatter.ISO_OFFSET_DATE_TIME.format(object);
/*    */   }
/*    */ 
/*    */   
/*    */   public OffsetDateTime parse(String text, Locale locale) throws ParseException {
/* 43 */     return OffsetDateTime.parse(text, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\IsoOffsetFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */