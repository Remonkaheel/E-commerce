/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.time.Period;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import java.util.regex.Matcher;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum null
/*    */ {
/*    */   public Period parse(String value, ChronoUnit unit) {
/*    */     try {
/* 47 */       if (PeriodStyle.NUMERIC.matcher(value).matches()) {
/* 48 */         return PeriodStyle.Unit.fromChronoUnit(unit).parse(value);
/*    */       }
/* 50 */       Matcher matcher = matcher(value);
/* 51 */       Assert.state(matcher.matches(), "Does not match simple period pattern");
/* 52 */       Assert.isTrue(hasAtLeastOneGroupValue(matcher), () -> "'" + value + "' is not a valid simple period");
/* 53 */       int years = parseInt(matcher, 1);
/* 54 */       int months = parseInt(matcher, 2);
/* 55 */       int weeks = parseInt(matcher, 3);
/* 56 */       int days = parseInt(matcher, 4);
/* 57 */       return Period.of(years, months, Math.addExact(Math.multiplyExact(weeks, 7), days));
/*    */     }
/* 59 */     catch (Exception ex) {
/* 60 */       throw new IllegalArgumentException("'" + value + "' is not a valid simple period", ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   boolean hasAtLeastOneGroupValue(Matcher matcher) {
/* 65 */     for (int i = 0; i < matcher.groupCount(); i++) {
/* 66 */       if (matcher.group(i + 1) != null) {
/* 67 */         return true;
/*    */       }
/*    */     } 
/* 70 */     return false;
/*    */   }
/*    */   
/*    */   private int parseInt(Matcher matcher, int group) {
/* 74 */     String value = matcher.group(group);
/* 75 */     return (value != null) ? Integer.parseInt(value) : 0;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean matches(String value) {
/* 80 */     return (PeriodStyle.NUMERIC.matcher(value).matches() || matcher(value).matches());
/*    */   }
/*    */ 
/*    */   
/*    */   public String print(Period value, ChronoUnit unit) {
/* 85 */     if (value.isZero()) {
/* 86 */       return PeriodStyle.Unit.fromChronoUnit(unit).print(value);
/*    */     }
/* 88 */     StringBuilder result = new StringBuilder();
/* 89 */     append(result, value, PeriodStyle.Unit.YEARS);
/* 90 */     append(result, value, PeriodStyle.Unit.MONTHS);
/* 91 */     append(result, value, PeriodStyle.Unit.DAYS);
/* 92 */     return result.toString();
/*    */   }
/*    */   
/*    */   private void append(StringBuilder result, Period value, PeriodStyle.Unit unit) {
/* 96 */     if (!unit.isZero(value))
/* 97 */       result.append(unit.print(value)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\PeriodStyle$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */