/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.springframework.boot.origin.Origin;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.core.io.InputStreamSource;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.FileCopyUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InputStreamSourceToByteArrayConverter
/*    */   implements Converter<InputStreamSource, byte[]>
/*    */ {
/*    */   public byte[] convert(InputStreamSource source) {
/*    */     try {
/* 37 */       return FileCopyUtils.copyToByteArray(source.getInputStream());
/*    */     }
/* 39 */     catch (IOException ex) {
/* 40 */       throw new IllegalStateException("Unable to read from " + getName(source), ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   private String getName(InputStreamSource source) {
/* 45 */     Origin origin = Origin.from(source);
/* 46 */     if (origin != null) {
/* 47 */       return origin.toString();
/*    */     }
/* 49 */     if (source instanceof Resource) { Resource resource = (Resource)source;
/* 50 */       return resource.getDescription(); }
/*    */     
/* 52 */     return "input stream source";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\InputStreamSourceToByteArrayConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */