/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalConverter;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConverterFactory;
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.format.support.DefaultFormattingConversionService;
/*     */ import org.springframework.format.support.FormattingConversionService;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationConversionService
/*     */   extends FormattingConversionService
/*     */ {
/*  72 */   private static final ResolvableType STRING = ResolvableType.forClass(String.class);
/*     */   
/*     */   private static volatile ApplicationConversionService sharedInstance;
/*     */   
/*     */   private final boolean unmodifiable;
/*     */   
/*     */   public ApplicationConversionService() {
/*  79 */     this((StringValueResolver)null);
/*     */   }
/*     */   
/*     */   public ApplicationConversionService(StringValueResolver embeddedValueResolver) {
/*  83 */     this(embeddedValueResolver, false);
/*     */   }
/*     */   
/*     */   private ApplicationConversionService(StringValueResolver embeddedValueResolver, boolean unmodifiable) {
/*  87 */     if (embeddedValueResolver != null) {
/*  88 */       setEmbeddedValueResolver(embeddedValueResolver);
/*     */     }
/*  90 */     configure((FormatterRegistry)this);
/*  91 */     this.unmodifiable = unmodifiable;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPrinter(Printer<?> printer) {
/*  96 */     assertModifiable();
/*  97 */     super.addPrinter(printer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addParser(Parser<?> parser) {
/* 102 */     assertModifiable();
/* 103 */     super.addParser(parser);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFormatter(Formatter<?> formatter) {
/* 108 */     assertModifiable();
/* 109 */     super.addFormatter(formatter);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Formatter<?> formatter) {
/* 114 */     assertModifiable();
/* 115 */     super.addFormatterForFieldType(fieldType, formatter);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addConverter(Converter<?, ?> converter) {
/* 120 */     assertModifiable();
/* 121 */     super.addConverter(converter);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Printer<?> printer, Parser<?> parser) {
/* 126 */     assertModifiable();
/* 127 */     super.addFormatterForFieldType(fieldType, printer, parser);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFormatterForFieldAnnotation(AnnotationFormatterFactory<? extends Annotation> annotationFormatterFactory) {
/* 133 */     assertModifiable();
/* 134 */     super.addFormatterForFieldAnnotation(annotationFormatterFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <S, T> void addConverter(Class<S> sourceType, Class<T> targetType, Converter<? super S, ? extends T> converter) {
/* 140 */     assertModifiable();
/* 141 */     super.addConverter(sourceType, targetType, converter);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addConverter(GenericConverter converter) {
/* 146 */     assertModifiable();
/* 147 */     super.addConverter(converter);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addConverterFactory(ConverterFactory<?, ?> factory) {
/* 152 */     assertModifiable();
/* 153 */     super.addConverterFactory(factory);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeConvertible(Class<?> sourceType, Class<?> targetType) {
/* 158 */     assertModifiable();
/* 159 */     super.removeConvertible(sourceType, targetType);
/*     */   }
/*     */   
/*     */   private void assertModifiable() {
/* 163 */     if (this.unmodifiable) {
/* 164 */       throw new UnsupportedOperationException("This ApplicationConversionService cannot be modified");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConvertViaObjectSourceType(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 178 */     GenericConverter converter = getConverter(sourceType, targetType);
/* 179 */     Set<GenericConverter.ConvertiblePair> pairs = (converter != null) ? converter.getConvertibleTypes() : null;
/* 180 */     if (pairs != null) {
/* 181 */       for (GenericConverter.ConvertiblePair pair : pairs) {
/* 182 */         if (Object.class.equals(pair.getSourceType())) {
/* 183 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 187 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConversionService getSharedInstance() {
/* 201 */     ApplicationConversionService sharedInstance = ApplicationConversionService.sharedInstance;
/* 202 */     if (sharedInstance == null) {
/* 203 */       synchronized (ApplicationConversionService.class) {
/* 204 */         sharedInstance = ApplicationConversionService.sharedInstance;
/* 205 */         if (sharedInstance == null) {
/* 206 */           sharedInstance = new ApplicationConversionService(null, true);
/* 207 */           ApplicationConversionService.sharedInstance = sharedInstance;
/*     */         } 
/*     */       } 
/*     */     }
/* 211 */     return (ConversionService)sharedInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void configure(FormatterRegistry registry) {
/* 223 */     DefaultConversionService.addDefaultConverters((ConverterRegistry)registry);
/* 224 */     DefaultFormattingConversionService.addDefaultFormatters(registry);
/* 225 */     addApplicationFormatters(registry);
/* 226 */     addApplicationConverters((ConverterRegistry)registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addApplicationConverters(ConverterRegistry registry) {
/* 237 */     addDelimitedStringConverters(registry);
/* 238 */     registry.addConverter(new StringToDurationConverter());
/* 239 */     registry.addConverter(new DurationToStringConverter());
/* 240 */     registry.addConverter(new NumberToDurationConverter());
/* 241 */     registry.addConverter(new DurationToNumberConverter());
/* 242 */     registry.addConverter(new StringToPeriodConverter());
/* 243 */     registry.addConverter(new PeriodToStringConverter());
/* 244 */     registry.addConverter(new NumberToPeriodConverter());
/* 245 */     registry.addConverter(new StringToDataSizeConverter());
/* 246 */     registry.addConverter(new NumberToDataSizeConverter());
/* 247 */     registry.addConverter(new StringToFileConverter());
/* 248 */     registry.addConverter(new InputStreamSourceToByteArrayConverter());
/* 249 */     registry.addConverterFactory(new LenientStringToEnumConverterFactory());
/* 250 */     registry.addConverterFactory(new LenientBooleanToEnumConverterFactory());
/* 251 */     if (registry instanceof ConversionService) { ConversionService conversionService = (ConversionService)registry;
/* 252 */       addApplicationConverters(registry, conversionService); }
/*     */   
/*     */   }
/*     */   
/*     */   private static void addApplicationConverters(ConverterRegistry registry, ConversionService conversionService) {
/* 257 */     registry.addConverter((GenericConverter)new CharSequenceToObjectConverter(conversionService));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addDelimitedStringConverters(ConverterRegistry registry) {
/* 268 */     ConversionService service = (ConversionService)registry;
/* 269 */     registry.addConverter((GenericConverter)new ArrayToDelimitedStringConverter(service));
/* 270 */     registry.addConverter((GenericConverter)new CollectionToDelimitedStringConverter(service));
/* 271 */     registry.addConverter((GenericConverter)new DelimitedStringToArrayConverter(service));
/* 272 */     registry.addConverter((GenericConverter)new DelimitedStringToCollectionConverter(service));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addApplicationFormatters(FormatterRegistry registry) {
/* 280 */     registry.addFormatter(new CharArrayFormatter());
/* 281 */     registry.addFormatter(new InetAddressFormatter());
/* 282 */     registry.addFormatter(new IsoOffsetFormatter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addBeans(FormatterRegistry registry, ListableBeanFactory beanFactory) {
/* 294 */     addBeans(registry, beanFactory, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Object> addBeans(FormatterRegistry registry, ListableBeanFactory beanFactory, String qualifier) {
/* 309 */     ConfigurableListableBeanFactory configurableBeanFactory = getConfigurableListableBeanFactory(beanFactory);
/* 310 */     Map<String, Object> beans = getBeans(beanFactory, qualifier);
/* 311 */     beans.forEach((beanName, bean) -> {
/*     */           BeanDefinition beanDefinition = (configurableBeanFactory != null) ? configurableBeanFactory.getMergedBeanDefinition(beanName) : null;
/*     */           
/*     */           ResolvableType type = (beanDefinition != null) ? beanDefinition.getResolvableType() : null;
/*     */           addBean(registry, bean, type);
/*     */         });
/* 317 */     return beans;
/*     */   }
/*     */   
/*     */   private static ConfigurableListableBeanFactory getConfigurableListableBeanFactory(ListableBeanFactory beanFactory) {
/* 321 */     if (beanFactory instanceof ConfigurableApplicationContext) { ConfigurableApplicationContext applicationContext = (ConfigurableApplicationContext)beanFactory;
/* 322 */       return applicationContext.getBeanFactory(); }
/*     */     
/* 324 */     if (beanFactory instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory configurableListableBeanFactory = (ConfigurableListableBeanFactory)beanFactory;
/* 325 */       return configurableListableBeanFactory; }
/*     */     
/* 327 */     return null;
/*     */   }
/*     */   
/*     */   private static Map<String, Object> getBeans(ListableBeanFactory beanFactory, String qualifier) {
/* 331 */     Map<String, Object> beans = new LinkedHashMap<>();
/* 332 */     beans.putAll(getBeans(beanFactory, Printer.class, qualifier));
/* 333 */     beans.putAll(getBeans(beanFactory, Parser.class, qualifier));
/* 334 */     beans.putAll(getBeans(beanFactory, Formatter.class, qualifier));
/* 335 */     beans.putAll(getBeans(beanFactory, Converter.class, qualifier));
/* 336 */     beans.putAll(getBeans(beanFactory, ConverterFactory.class, qualifier));
/* 337 */     beans.putAll(getBeans(beanFactory, GenericConverter.class, qualifier));
/* 338 */     return beans;
/*     */   }
/*     */   
/*     */   private static <T> Map<String, T> getBeans(ListableBeanFactory beanFactory, Class<T> type, String qualifier) {
/* 342 */     return !StringUtils.hasLength(qualifier) ? beanFactory.getBeansOfType(type) : 
/* 343 */       BeanFactoryAnnotationUtils.qualifiedBeansOfType(beanFactory, type, qualifier);
/*     */   }
/*     */   
/*     */   static void addBean(FormatterRegistry registry, Object bean, ResolvableType beanType) {
/* 347 */     if (bean instanceof GenericConverter) { GenericConverter converterBean = (GenericConverter)bean;
/* 348 */       Objects.requireNonNull(registry); addBean(registry, converterBean, beanType, GenericConverter.class, registry::addConverter, (Runnable)null); }
/*     */     
/* 350 */     else if (bean instanceof Converter) { Converter<?, ?> converterBean = (Converter<?, ?>)bean;
/* 351 */       Objects.requireNonNull(registry); addBean(registry, converterBean, beanType, Converter.class, registry::addConverter, ConverterBeanAdapter::new);
/*     */        }
/*     */     
/* 354 */     else if (bean instanceof ConverterFactory) { ConverterFactory<?, ?> converterBean = (ConverterFactory<?, ?>)bean;
/* 355 */       Objects.requireNonNull(registry); addBean(registry, converterBean, beanType, ConverterFactory.class, registry::addConverterFactory, ConverterFactoryBeanAdapter::new);
/*     */        }
/*     */     
/* 358 */     else if (bean instanceof Formatter) { Formatter<?> formatterBean = (Formatter)bean;
/* 359 */       Objects.requireNonNull(registry); addBean(registry, formatterBean, beanType, Formatter.class, registry::addFormatter, () -> {
/*     */             registry.addConverter((GenericConverter)new PrinterBeanAdapter((Printer<?>)formatterBean, beanType));
/*     */             
/*     */             registry.addConverter((GenericConverter)new ParserBeanAdapter((Parser<?>)formatterBean, beanType));
/*     */           }); }
/* 364 */     else if (bean instanceof Printer) { Printer<?> printerBean = (Printer)bean;
/* 365 */       Objects.requireNonNull(registry); addBean(registry, printerBean, beanType, Printer.class, registry::addPrinter, PrinterBeanAdapter::new); }
/*     */     
/* 367 */     else if (bean instanceof Parser) { Parser<?> parserBean = (Parser)bean;
/* 368 */       Objects.requireNonNull(registry); addBean(registry, parserBean, beanType, Parser.class, registry::addParser, ParserBeanAdapter::new); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private static <B, T> void addBean(FormatterRegistry registry, B bean, ResolvableType beanType, Class<T> type, Consumer<B> standardRegistrar, BiFunction<B, ResolvableType, BeanAdapter<?>> beanAdapterFactory) {
/* 374 */     addBean(registry, bean, beanType, type, standardRegistrar, () -> registry.addConverter(beanAdapterFactory.apply(bean, beanType)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <B, T> void addBean(FormatterRegistry registry, B bean, ResolvableType beanType, Class<T> type, Consumer<B> standardRegistrar, Runnable beanAdapterRegistrar) {
/* 380 */     if (beanType != null && beanAdapterRegistrar != null && 
/* 381 */       ResolvableType.forInstance(bean).as(type).hasUnresolvableGenerics()) {
/* 382 */       beanAdapterRegistrar.run();
/*     */       return;
/*     */     } 
/* 385 */     standardRegistrar.accept(bean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static abstract class BeanAdapter<B>
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private final B bean;
/*     */ 
/*     */     
/*     */     private final ApplicationConversionService.ResolvableTypePair types;
/*     */ 
/*     */     
/*     */     BeanAdapter(B bean, ResolvableType beanType) {
/* 400 */       Assert.isInstanceOf(beanType.toClass(), bean);
/* 401 */       ResolvableType type = ResolvableType.forClass(getClass()).as(BeanAdapter.class).getGeneric(new int[0]);
/* 402 */       ResolvableType[] generics = beanType.as(type.toClass()).getGenerics();
/* 403 */       this.bean = bean;
/* 404 */       this.types = getResolvableTypePair(generics);
/*     */     }
/*     */     
/*     */     protected ApplicationConversionService.ResolvableTypePair getResolvableTypePair(ResolvableType[] generics) {
/* 408 */       return new ApplicationConversionService.ResolvableTypePair(generics[0], generics[1]);
/*     */     }
/*     */     
/*     */     protected B bean() {
/* 412 */       return this.bean;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 417 */       return Set.of(new GenericConverter.ConvertiblePair(this.types.source().toClass(), this.types.target().toClass()));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 422 */       return (this.types.target().toClass() == targetType.getObjectType() && 
/* 423 */         matchesTargetType(targetType.getResolvableType()));
/*     */     }
/*     */     
/*     */     private boolean matchesTargetType(ResolvableType targetType) {
/* 427 */       ResolvableType ours = this.types.target();
/* 428 */       return (targetType.getType() instanceof Class || targetType.isAssignableFrom(ours) || this.types
/* 429 */         .target().hasUnresolvableGenerics());
/*     */     }
/*     */ 
/*     */     
/*     */     protected final boolean conditionalConverterCandidateMatches(Object conditionalConverterCandidate, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 434 */       ConditionalConverter conditionalConverter = (ConditionalConverter)conditionalConverterCandidate; return (conditionalConverterCandidate instanceof ConditionalConverter) ? 
/* 435 */         conditionalConverter.matches(sourceType, targetType) : true;
/*     */     }
/*     */ 
/*     */     
/*     */     protected final Object convert(Object source, TypeDescriptor targetType, Converter<?, ?> converter) {
/* 440 */       return (source != null) ? converter.convert(source) : convertNull(targetType);
/*     */     }
/*     */     
/*     */     private Object convertNull(TypeDescriptor targetType) {
/* 444 */       return (targetType.getObjectType() != Optional.class) ? null : Optional.empty();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 449 */       return String.valueOf(this.types) + " : " + String.valueOf(this.types);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class PrinterBeanAdapter
/*     */     extends BeanAdapter<Printer<?>>
/*     */   {
/*     */     PrinterBeanAdapter(Printer<?> bean, ResolvableType beanType) {
/* 460 */       super(bean, beanType);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ApplicationConversionService.ResolvableTypePair getResolvableTypePair(ResolvableType[] generics) {
/* 465 */       return new ApplicationConversionService.ResolvableTypePair(generics[0], ApplicationConversionService.STRING);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 470 */       return (source != null) ? print(source) : "";
/*     */     }
/*     */ 
/*     */     
/*     */     private String print(Object object) {
/* 475 */       return bean().print(object, LocaleContextHolder.getLocale());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ParserBeanAdapter
/*     */     extends BeanAdapter<Parser<?>>
/*     */   {
/*     */     ParserBeanAdapter(Parser<?> bean, ResolvableType beanType) {
/* 486 */       super(bean, beanType);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ApplicationConversionService.ResolvableTypePair getResolvableTypePair(ResolvableType[] generics) {
/* 491 */       return new ApplicationConversionService.ResolvableTypePair(ApplicationConversionService.STRING, generics[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 496 */       String text = (String)source;
/* 497 */       return !StringUtils.hasText(text) ? null : parse(text);
/*     */     }
/*     */     
/*     */     private Object parse(String text) {
/*     */       try {
/* 502 */         return bean().parse(text, LocaleContextHolder.getLocale());
/*     */       }
/* 504 */       catch (IllegalArgumentException ex) {
/* 505 */         throw ex;
/*     */       }
/* 507 */       catch (Throwable ex) {
/* 508 */         throw new IllegalArgumentException("Parse attempt failed for value [" + text + "]", ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ConverterBeanAdapter
/*     */     extends BeanAdapter<Converter<?, ?>>
/*     */   {
/*     */     ConverterBeanAdapter(Converter<?, ?> bean, ResolvableType beanType) {
/* 520 */       super(bean, beanType);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 525 */       return (super.matches(sourceType, targetType) && 
/* 526 */         conditionalConverterCandidateMatches(bean(), sourceType, targetType));
/*     */     }
/*     */ 
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 531 */       return convert(source, targetType, bean());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ConverterFactoryBeanAdapter
/*     */     extends BeanAdapter<ConverterFactory<?, ?>>
/*     */   {
/*     */     ConverterFactoryBeanAdapter(ConverterFactory<?, ?> bean, ResolvableType beanType) {
/* 542 */       super(bean, beanType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 549 */       Objects.requireNonNull(targetType); return (super.matches(sourceType, targetType) && conditionalConverterCandidateMatches(bean(), sourceType, targetType) && conditionalConverterCandidateMatches(getConverter(targetType::getType), sourceType, targetType));
/*     */     }
/*     */ 
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 554 */       Objects.requireNonNull(targetType); return convert(source, targetType, getConverter(targetType::getObjectType));
/*     */     }
/*     */ 
/*     */     
/*     */     private Converter<Object, ?> getConverter(Supplier<Class<?>> typeSupplier) {
/* 559 */       return bean().getConverter(typeSupplier.get());
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ResolvableTypePair
/*     */     extends Record
/*     */   {
/*     */     private final ResolvableType source;
/*     */     private final ResolvableType target;
/*     */     
/*     */     public ResolvableType source() {
/* 570 */       return this.source; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/convert/ApplicationConversionService$ResolvableTypePair;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #570	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/convert/ApplicationConversionService$ResolvableTypePair; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/convert/ApplicationConversionService$ResolvableTypePair;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #570	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/boot/convert/ApplicationConversionService$ResolvableTypePair;
/* 570 */       //   0	8	1	o	Ljava/lang/Object; } public ResolvableType target() { return this.target; }
/*     */     
/*     */     ResolvableTypePair(ResolvableType source, ResolvableType target) {
/* 573 */       Assert.notNull(source.resolve(), "'source' cannot be resolved");
/* 574 */       Assert.notNull(target.resolve(), "'target' cannot be resolved");
/*     */       this.source = source;
/*     */       this.target = target;
/*     */     }
/*     */     public final String toString() {
/* 579 */       return String.valueOf(source()) + " -> " + String.valueOf(source());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\ApplicationConversionService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */