/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.time.Period;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum Unit
/*     */ {
/* 221 */   DAYS(ChronoUnit.DAYS, "d", Period::getDays, Period::ofDays),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   WEEKS(ChronoUnit.WEEKS, "w", null, Period::ofWeeks),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   MONTHS(ChronoUnit.MONTHS, "m", Period::getMonths, Period::ofMonths),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   YEARS(ChronoUnit.YEARS, "y", Period::getYears, Period::ofYears);
/*     */   
/*     */   private final ChronoUnit chronoUnit;
/*     */   
/*     */   private final String suffix;
/*     */   
/*     */   private final Function<Period, Integer> intValue;
/*     */   
/*     */   private final Function<Integer, Period> factory;
/*     */ 
/*     */   
/*     */   Unit(ChronoUnit chronoUnit, String suffix, Function<Period, Integer> intValue, Function<Integer, Period> factory) {
/* 248 */     this.chronoUnit = chronoUnit;
/* 249 */     this.suffix = suffix;
/* 250 */     this.intValue = intValue;
/* 251 */     this.factory = factory;
/*     */   }
/*     */   
/*     */   private Period parse(String value) {
/* 255 */     return this.factory.apply(Integer.valueOf(Integer.parseInt(value)));
/*     */   }
/*     */   
/*     */   private String print(Period value) {
/* 259 */     return "" + intValue(value) + intValue(value);
/*     */   }
/*     */   
/*     */   private boolean isZero(Period value) {
/* 263 */     return (intValue(value) == 0);
/*     */   }
/*     */   
/*     */   private int intValue(Period value) {
/* 267 */     Assert.state((this.intValue != null), () -> "intValue cannot be extracted from " + name());
/* 268 */     return ((Integer)this.intValue.apply(value)).intValue();
/*     */   }
/*     */   
/*     */   private static Unit fromChronoUnit(ChronoUnit chronoUnit) {
/* 272 */     if (chronoUnit == null) {
/* 273 */       return DAYS;
/*     */     }
/* 275 */     for (Unit candidate : values()) {
/* 276 */       if (candidate.chronoUnit == chronoUnit) {
/* 277 */         return candidate;
/*     */       }
/*     */     } 
/* 280 */     throw new IllegalArgumentException("Unsupported unit " + String.valueOf(chronoUnit));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\PeriodStyle$Unit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */