/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LenientToEnumConverter<E extends Enum>
/*     */   implements Converter<T, E>
/*     */ {
/*     */   private final Class<E> enumType;
/*     */   
/*     */   LenientToEnumConverter(Class<E> enumType) {
/*  67 */     this.enumType = enumType;
/*     */   }
/*     */ 
/*     */   
/*     */   public E convert(T source) {
/*  72 */     String value = source.toString().trim();
/*  73 */     if (value.isEmpty()) {
/*  74 */       return null;
/*     */     }
/*     */     try {
/*  77 */       return Enum.valueOf(this.enumType, value);
/*     */     }
/*  79 */     catch (Exception ex) {
/*  80 */       return findEnum(value);
/*     */     } 
/*     */   }
/*     */   
/*     */   private E findEnum(String value) {
/*  85 */     String name = getCanonicalName(value);
/*  86 */     List<String> aliases = LenientObjectToEnumConverterFactory.ALIASES.getOrDefault(name, Collections.emptyList());
/*  87 */     for (Enum enum_ : EnumSet.<Enum>allOf(this.enumType)) {
/*  88 */       String candidateName = getCanonicalName(enum_.name());
/*  89 */       if (name.equals(candidateName) || aliases.contains(candidateName)) {
/*  90 */         return (E)enum_;
/*     */       }
/*     */     } 
/*  93 */     throw new IllegalArgumentException("No enum constant " + this.enumType.getCanonicalName() + "." + value);
/*     */   }
/*     */   
/*     */   private String getCanonicalName(String name) {
/*  97 */     StringBuilder canonicalName = new StringBuilder(name.length());
/*  98 */     name.chars()
/*  99 */       .filter(Character::isLetterOrDigit)
/* 100 */       .map(Character::toLowerCase)
/* 101 */       .forEach(c -> canonicalName.append((char)c));
/* 102 */     return canonicalName.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\convert\LenientObjectToEnumConverterFactory$LenientToEnumConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */