/*    */ package org.springframework.boot.flyway;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.flywaydb.core.Flyway;
/*    */ import org.springframework.boot.sql.init.dependency.AbstractBeansOfTypeDatabaseInitializerDetector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FlywayDatabaseInitializerDetector
/*    */   extends AbstractBeansOfTypeDatabaseInitializerDetector
/*    */ {
/*    */   protected Set<Class<?>> getDatabaseInitializerBeanTypes() {
/* 36 */     return Collections.singleton(Flyway.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\flyway\FlywayDatabaseInitializerDetector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */