/*     */ package org.springframework.boot.jdbc.init;
/*     */ 
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.boot.jdbc.DatabaseDriver;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlatformPlaceholderDatabaseDriverResolver
/*     */ {
/*     */   private final String placeholder;
/*     */   private final Map<DatabaseDriver, String> driverMappings;
/*     */   
/*     */   public PlatformPlaceholderDatabaseDriverResolver() {
/*  59 */     this("@@platform@@");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlatformPlaceholderDatabaseDriverResolver(String placeholder) {
/*  67 */     this(placeholder, Collections.emptyMap());
/*     */   }
/*     */   
/*     */   private PlatformPlaceholderDatabaseDriverResolver(String placeholder, Map<DatabaseDriver, String> driverMappings) {
/*  71 */     this.placeholder = placeholder;
/*  72 */     this.driverMappings = driverMappings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlatformPlaceholderDatabaseDriverResolver withDriverPlatform(DatabaseDriver driver, String platform) {
/*  83 */     Map<DatabaseDriver, String> driverMappings = new LinkedHashMap<>(this.driverMappings);
/*  84 */     driverMappings.put(driver, platform);
/*  85 */     return new PlatformPlaceholderDatabaseDriverResolver(this.placeholder, driverMappings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> resolveAll(DataSource dataSource, String... values) {
/*  96 */     Assert.notNull(dataSource, "'dataSource' must not be null");
/*  97 */     return resolveAll(() -> determinePlatform(dataSource), values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> resolveAll(String platform, String... values) {
/* 109 */     Assert.notNull(platform, "'platform' must not be null");
/* 110 */     return resolveAll(() -> platform, values);
/*     */   }
/*     */   
/*     */   private List<String> resolveAll(Supplier<String> platformProvider, String... values) {
/* 114 */     if (ObjectUtils.isEmpty((Object[])values)) {
/* 115 */       return Collections.emptyList();
/*     */     }
/* 117 */     List<String> resolved = new ArrayList<>(values.length);
/* 118 */     String platform = null;
/* 119 */     for (String value : values) {
/* 120 */       if (StringUtils.hasLength(value) && 
/* 121 */         value.contains(this.placeholder)) {
/* 122 */         platform = (platform != null) ? platform : platformProvider.get();
/* 123 */         value = value.replace(this.placeholder, platform);
/*     */       } 
/*     */       
/* 126 */       resolved.add(value);
/*     */     } 
/* 128 */     return Collections.unmodifiableList(resolved);
/*     */   }
/*     */   
/*     */   private String determinePlatform(DataSource dataSource) {
/* 132 */     DatabaseDriver databaseDriver = getDatabaseDriver(dataSource);
/* 133 */     Assert.state((databaseDriver != DatabaseDriver.UNKNOWN), "Unable to detect database type");
/* 134 */     return this.driverMappings.getOrDefault(databaseDriver, databaseDriver.getId());
/*     */   }
/*     */   
/*     */   DatabaseDriver getDatabaseDriver(DataSource dataSource) {
/*     */     try {
/* 139 */       String productName = JdbcUtils.commonDatabaseName(
/* 140 */           (String)JdbcUtils.extractDatabaseMetaData(dataSource, DatabaseMetaData::getDatabaseProductName));
/* 141 */       return DatabaseDriver.fromProductName(productName);
/*     */     }
/* 143 */     catch (Exception ex) {
/* 144 */       throw new IllegalStateException("Failed to determine DatabaseDriver", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jdbc\init\PlatformPlaceholderDatabaseDriverResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */