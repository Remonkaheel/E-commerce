/*    */ package org.springframework.boot.jdbc.init;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.boot.sql.init.dependency.AbstractBeansOfTypeDatabaseInitializerDetector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DataSourceScriptDatabaseInitializerDetector
/*    */   extends AbstractBeansOfTypeDatabaseInitializerDetector
/*    */ {
/*    */   static final int PRECEDENCE = 2147483547;
/*    */   
/*    */   protected Set<Class<?>> getDatabaseInitializerBeanTypes() {
/* 37 */     return Collections.singleton(DataSourceScriptDatabaseInitializer.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 42 */     return 2147483547;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jdbc\init\DataSourceScriptDatabaseInitializerDetector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */