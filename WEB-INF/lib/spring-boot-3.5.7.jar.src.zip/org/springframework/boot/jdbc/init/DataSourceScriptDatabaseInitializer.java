/*    */ package org.springframework.boot.jdbc.init;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
/*    */ import org.springframework.boot.sql.init.AbstractScriptDatabaseInitializer;
/*    */ import org.springframework.boot.sql.init.DatabaseInitializationSettings;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*    */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSourceScriptDatabaseInitializer
/*    */   extends AbstractScriptDatabaseInitializer
/*    */ {
/* 41 */   private static final Log logger = LogFactory.getLog(DataSourceScriptDatabaseInitializer.class);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final DataSource dataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataSourceScriptDatabaseInitializer(DataSource dataSource, DatabaseInitializationSettings settings) {
/* 52 */     super(settings);
/* 53 */     this.dataSource = dataSource;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final DataSource getDataSource() {
/* 61 */     return this.dataSource;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isEmbeddedDatabase() {
/*    */     try {
/* 67 */       return EmbeddedDatabaseConnection.isEmbedded(this.dataSource);
/*    */     }
/* 69 */     catch (Exception ex) {
/* 70 */       logger.debug("Could not determine if datasource is embedded", ex);
/* 71 */       return false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void runScripts(AbstractScriptDatabaseInitializer.Scripts scripts) {
/* 77 */     ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
/* 78 */     populator.setContinueOnError(scripts.isContinueOnError());
/* 79 */     populator.setSeparator(scripts.getSeparator());
/* 80 */     if (scripts.getEncoding() != null) {
/* 81 */       populator.setSqlScriptEncoding(scripts.getEncoding().name());
/*    */     }
/* 83 */     for (Resource resource : scripts) {
/* 84 */       populator.addScript(resource);
/*    */     }
/* 86 */     customize(populator);
/* 87 */     DatabasePopulatorUtils.execute((DatabasePopulator)populator, this.dataSource);
/*    */   }
/*    */   
/*    */   protected void customize(ResourceDatabasePopulator populator) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jdbc\init\DataSourceScriptDatabaseInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */