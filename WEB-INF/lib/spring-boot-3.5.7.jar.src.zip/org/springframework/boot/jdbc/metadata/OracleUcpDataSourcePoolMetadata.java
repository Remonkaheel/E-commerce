/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.ucp.jdbc.PoolDataSource;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OracleUcpDataSourcePoolMetadata
/*    */   extends AbstractDataSourcePoolMetadata<PoolDataSource>
/*    */ {
/*    */   public OracleUcpDataSourcePoolMetadata(PoolDataSource dataSource) {
/* 36 */     super(dataSource);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getActive() {
/*    */     try {
/* 42 */       return Integer.valueOf(getDataSource().getBorrowedConnectionsCount());
/*    */     }
/* 44 */     catch (SQLException ex) {
/* 45 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getIdle() {
/*    */     try {
/* 52 */       return Integer.valueOf(getDataSource().getAvailableConnectionsCount());
/*    */     }
/* 54 */     catch (SQLException ex) {
/* 55 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getMax() {
/* 61 */     return Integer.valueOf(getDataSource().getMaxPoolSize());
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getMin() {
/* 66 */     return Integer.valueOf(getDataSource().getMinPoolSize());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValidationQuery() {
/* 71 */     return getDataSource().getSQLForValidateConnection();
/*    */   }
/*    */ 
/*    */   
/*    */   public Boolean getDefaultAutoCommit() {
/* 76 */     String autoCommit = getDataSource().getConnectionProperty("autoCommit");
/* 77 */     return StringUtils.hasText(autoCommit) ? Boolean.valueOf(autoCommit) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jdbc\metadata\OracleUcpDataSourcePoolMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */