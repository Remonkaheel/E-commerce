package org.springframework.boot.jdbc.metadata;

import javax.sql.DataSource;

@FunctionalInterface
public interface DataSourcePoolMetadataProvider {
  DataSourcePoolMetadata getDataSourcePoolMetadata(DataSource paramDataSource);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jdbc\metadata\DataSourcePoolMetadataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */