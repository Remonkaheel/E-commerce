/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeDataSourcePoolMetadataProvider
/*    */   implements DataSourcePoolMetadataProvider
/*    */ {
/*    */   private final List<DataSourcePoolMetadataProvider> providers;
/*    */   
/*    */   public CompositeDataSourcePoolMetadataProvider(Collection<? extends DataSourcePoolMetadataProvider> providers) {
/* 42 */     this.providers = (providers != null) ? List.<DataSourcePoolMetadataProvider>copyOf(providers) : Collections.<DataSourcePoolMetadataProvider>emptyList();
/*    */   }
/*    */ 
/*    */   
/*    */   public DataSourcePoolMetadata getDataSourcePoolMetadata(DataSource dataSource) {
/* 47 */     for (DataSourcePoolMetadataProvider provider : this.providers) {
/* 48 */       DataSourcePoolMetadata metadata = provider.getDataSourcePoolMetadata(dataSource);
/* 49 */       if (metadata != null) {
/* 50 */         return metadata;
/*    */       }
/*    */     } 
/* 53 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jdbc\metadata\CompositeDataSourcePoolMetadataProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */