/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ import org.apache.tomcat.jdbc.pool.ConnectionPool;
/*    */ import org.apache.tomcat.jdbc.pool.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TomcatDataSourcePoolMetadata
/*    */   extends AbstractDataSourcePoolMetadata<DataSource>
/*    */ {
/*    */   public TomcatDataSourcePoolMetadata(DataSource dataSource) {
/* 31 */     super(dataSource);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getActive() {
/* 36 */     ConnectionPool pool = getDataSource().getPool();
/* 37 */     return Integer.valueOf((pool != null) ? pool.getActive() : 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getIdle() {
/* 42 */     return Integer.valueOf(getDataSource().getNumIdle());
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getMax() {
/* 47 */     return Integer.valueOf(getDataSource().getMaxActive());
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getMin() {
/* 52 */     return Integer.valueOf(getDataSource().getMinIdle());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValidationQuery() {
/* 57 */     return getDataSource().getValidationQuery();
/*    */   }
/*    */ 
/*    */   
/*    */   public Boolean getDefaultAutoCommit() {
/* 62 */     return getDataSource().isDefaultAutoCommit();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jdbc\metadata\TomcatDataSourcePoolMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */