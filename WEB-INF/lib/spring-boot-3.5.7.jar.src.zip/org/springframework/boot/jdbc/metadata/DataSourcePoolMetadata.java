/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface DataSourcePoolMetadata
/*    */ {
/*    */   Float getUsage();
/*    */   
/*    */   Integer getActive();
/*    */   
/*    */   default Integer getIdle() {
/* 61 */     return null;
/*    */   }
/*    */   
/*    */   Integer getMax();
/*    */   
/*    */   Integer getMin();
/*    */   
/*    */   String getValidationQuery();
/*    */   
/*    */   Boolean getDefaultAutoCommit();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jdbc\metadata\DataSourcePoolMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */