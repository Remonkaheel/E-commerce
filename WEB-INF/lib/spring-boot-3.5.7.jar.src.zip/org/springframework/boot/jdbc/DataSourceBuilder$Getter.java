package org.springframework.boot.jdbc;

import java.sql.SQLException;

@FunctionalInterface
interface Getter<T, V> {
  V get(T paramT) throws SQLException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jdbc\DataSourceBuilder$Getter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */