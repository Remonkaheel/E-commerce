/*     */ package org.springframework.boot.jdbc;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MappedDataSourceProperties<T extends DataSource>
/*     */   implements DataSourceBuilder.DataSourceProperties<T>
/*     */ {
/* 338 */   private final Map<DataSourceBuilder.DataSourceProperty, DataSourceBuilder.MappedDataSourceProperty<T, ?>> mappedProperties = new HashMap<>();
/*     */   
/*     */   private final Class<T> dataSourceType;
/*     */ 
/*     */   
/*     */   MappedDataSourceProperties() {
/* 344 */     this
/* 345 */       .dataSourceType = ResolvableType.forClass(MappedDataSourceProperties.class, getClass()).resolveGeneric(new int[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<? extends T> getDataSourceInstanceType() {
/* 350 */     return this.dataSourceType;
/*     */   }
/*     */   
/*     */   protected void add(DataSourceBuilder.DataSourceProperty property, DataSourceBuilder.Getter<T, String> getter, DataSourceBuilder.Setter<T, String> setter) {
/* 354 */     add(property, String.class, getter, setter);
/*     */   }
/*     */   
/*     */   protected <V> void add(DataSourceBuilder.DataSourceProperty property, Class<V> type, DataSourceBuilder.Getter<T, V> getter, DataSourceBuilder.Setter<T, V> setter) {
/* 358 */     this.mappedProperties.put(property, new DataSourceBuilder.MappedDataSourceProperty<>(property, type, getter, setter));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canSet(DataSourceBuilder.DataSourceProperty property) {
/* 363 */     return this.mappedProperties.containsKey(property);
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(T dataSource, DataSourceBuilder.DataSourceProperty property, String value) {
/* 368 */     DataSourceBuilder.MappedDataSourceProperty<T, ?> mappedProperty = getMapping(property);
/* 369 */     if (mappedProperty != null) {
/* 370 */       mappedProperty.set(dataSource, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(T dataSource, DataSourceBuilder.DataSourceProperty property) {
/* 376 */     DataSourceBuilder.MappedDataSourceProperty<T, ?> mappedProperty = getMapping(property);
/* 377 */     if (mappedProperty != null) {
/* 378 */       return mappedProperty.get(dataSource);
/*     */     }
/* 380 */     return null;
/*     */   }
/*     */   
/*     */   private DataSourceBuilder.MappedDataSourceProperty<T, ?> getMapping(DataSourceBuilder.DataSourceProperty property) {
/* 384 */     DataSourceBuilder.MappedDataSourceProperty<T, ?> mappedProperty = this.mappedProperties.get(property);
/* 385 */     UnsupportedDataSourcePropertyException.throwIf((!property.isOptional() && mappedProperty == null), () -> "No mapping found for " + String.valueOf(property));
/*     */     
/* 387 */     return mappedProperty;
/*     */   }
/*     */   
/*     */   static <T extends DataSource> MappedDataSourceProperties<T> forType(ClassLoader classLoader, Class<T> type) {
/* 391 */     MappedDataSourceProperties<T> pooled = lookupPooled(classLoader, type);
/* 392 */     if (type == null || pooled != null) {
/* 393 */       return pooled;
/*     */     }
/* 395 */     return lookupBasic(classLoader, type);
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T extends DataSource> MappedDataSourceProperties<T> lookupPooled(ClassLoader classLoader, Class<T> type) {
/* 400 */     MappedDataSourceProperties<T> result = null;
/* 401 */     result = lookup(classLoader, type, result, "com.zaxxer.hikari.HikariDataSource", HikariDataSourceProperties::new, new String[0]);
/*     */     
/* 403 */     result = lookup(classLoader, type, result, "org.apache.tomcat.jdbc.pool.DataSource", TomcatPoolDataSourceProperties::new, new String[0]);
/*     */     
/* 405 */     result = lookup(classLoader, type, result, "org.apache.commons.dbcp2.BasicDataSource", MappedDbcp2DataSource::new, new String[0]);
/*     */     
/* 407 */     result = lookup(classLoader, type, result, "oracle.ucp.jdbc.PoolDataSourceImpl", OraclePoolDataSourceProperties::new, new String[] { "oracle.jdbc.OracleConnection" });
/*     */     
/* 409 */     result = lookup(classLoader, type, result, "com.mchange.v2.c3p0.ComboPooledDataSource", ComboPooledDataSourceProperties::new, new String[0]);
/*     */     
/* 411 */     result = lookup(classLoader, type, result, "org.vibur.dbcp.ViburDBCPDataSource", ViburDataSourceProperties::new, new String[0]);
/*     */     
/* 413 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T extends DataSource> MappedDataSourceProperties<T> lookupBasic(ClassLoader classLoader, Class<T> dataSourceType) {
/* 418 */     MappedDataSourceProperties<T> result = null;
/* 419 */     result = lookup(classLoader, dataSourceType, result, "org.springframework.jdbc.datasource.SimpleDriverDataSource", SimpleDataSourceProperties::new, new String[0]);
/*     */     
/* 421 */     result = lookup(classLoader, dataSourceType, result, "oracle.jdbc.datasource.OracleDataSource", OracleDataSourceProperties::new, new String[0]);
/*     */     
/* 423 */     result = lookup(classLoader, dataSourceType, result, "org.h2.jdbcx.JdbcDataSource", H2DataSourceProperties::new, new String[0]);
/*     */     
/* 425 */     result = lookup(classLoader, dataSourceType, result, "org.postgresql.ds.PGSimpleDataSource", PostgresDataSourceProperties::new, new String[0]);
/*     */     
/* 427 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T extends DataSource> MappedDataSourceProperties<T> lookup(ClassLoader classLoader, Class<T> dataSourceType, MappedDataSourceProperties<T> existing, String dataSourceClassName, Supplier<MappedDataSourceProperties<?>> propertyMappingsSupplier, String... requiredClassNames) {
/* 434 */     if (existing != null || !allPresent(classLoader, dataSourceClassName, requiredClassNames)) {
/* 435 */       return existing;
/*     */     }
/* 437 */     MappedDataSourceProperties<?> propertyMappings = propertyMappingsSupplier.get();
/* 438 */     return (dataSourceType == null || propertyMappings
/* 439 */       .getDataSourceInstanceType().isAssignableFrom(dataSourceType)) ? 
/* 440 */       (MappedDataSourceProperties)propertyMappings : null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean allPresent(ClassLoader classLoader, String dataSourceClassName, String[] requiredClassNames) {
/* 445 */     boolean result = ClassUtils.isPresent(dataSourceClassName, classLoader);
/* 446 */     for (String requiredClassName : requiredClassNames) {
/* 447 */       result = (result && ClassUtils.isPresent(requiredClassName, classLoader));
/*     */     }
/* 449 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\jdbc\DataSourceBuilder$MappedDataSourceProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */