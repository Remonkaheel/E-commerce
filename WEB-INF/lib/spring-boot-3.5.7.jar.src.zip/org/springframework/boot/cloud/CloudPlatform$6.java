/*     */ package org.springframework.boot.cloud;
/*     */ 
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum null
/*     */ {
/*     */   private static final String KUBERNETES_SERVICE_HOST = "KUBERNETES_SERVICE_HOST";
/*     */   private static final String KUBERNETES_SERVICE_PORT = "KUBERNETES_SERVICE_PORT";
/*     */   private static final String SERVICE_HOST_SUFFIX = "_SERVICE_HOST";
/*     */   private static final String SERVICE_PORT_SUFFIX = "_SERVICE_PORT";
/*     */   
/*     */   public boolean isDetected(Environment environment) {
/* 116 */     if (environment instanceof ConfigurableEnvironment) { ConfigurableEnvironment configurableEnvironment = (ConfigurableEnvironment)environment;
/* 117 */       return isAutoDetected(configurableEnvironment); }
/*     */     
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isAutoDetected(ConfigurableEnvironment environment) {
/* 124 */     PropertySource<?> environmentPropertySource = environment.getPropertySources().get("systemEnvironment");
/* 125 */     if (environmentPropertySource != null) {
/* 126 */       if (environmentPropertySource.containsProperty("KUBERNETES_SERVICE_HOST") && environmentPropertySource
/* 127 */         .containsProperty("KUBERNETES_SERVICE_PORT")) {
/* 128 */         return true;
/*     */       }
/* 130 */       if (environmentPropertySource instanceof EnumerablePropertySource) { EnumerablePropertySource<?> enumerablePropertySource = (EnumerablePropertySource)environmentPropertySource;
/* 131 */         return isAutoDetected(enumerablePropertySource); }
/*     */     
/*     */     } 
/* 134 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isAutoDetected(EnumerablePropertySource<?> environmentPropertySource) {
/* 138 */     for (String propertyName : environmentPropertySource.getPropertyNames()) {
/* 139 */       if (propertyName.endsWith("_SERVICE_HOST")) {
/* 140 */         String serviceName = propertyName.substring(0, propertyName
/* 141 */             .length() - "_SERVICE_HOST".length());
/* 142 */         if (environmentPropertySource.getProperty(serviceName + "_SERVICE_PORT") != null) {
/* 143 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 147 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\cloud\CloudPlatform$6.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */