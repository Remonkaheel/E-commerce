/*     */ package org.springframework.boot.cloud;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.env.EnvironmentPostProcessor;
/*     */ import org.springframework.boot.json.JsonParser;
/*     */ import org.springframework.boot.json.JsonParserFactory;
/*     */ import org.springframework.boot.logging.DeferredLogFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertiesPropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CloudFoundryVcapEnvironmentPostProcessor
/*     */   implements EnvironmentPostProcessor, Ordered
/*     */ {
/*     */   private final Log logger;
/*  97 */   private int order = -2147483643;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CloudFoundryVcapEnvironmentPostProcessor(DeferredLogFactory logFactory) {
/* 105 */     this.logger = logFactory.getLog(CloudFoundryVcapEnvironmentPostProcessor.class);
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 109 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 114 */     return this.order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
/* 119 */     if (CloudPlatform.CLOUD_FOUNDRY.isActive((Environment)environment)) {
/* 120 */       Properties properties = new Properties();
/* 121 */       JsonParser jsonParser = JsonParserFactory.getJsonParser();
/* 122 */       addWithPrefix(properties, getPropertiesFromApplication((Environment)environment, jsonParser), "vcap.application.");
/* 123 */       addWithPrefix(properties, getPropertiesFromServices((Environment)environment, jsonParser), "vcap.services.");
/* 124 */       MutablePropertySources propertySources = environment.getPropertySources();
/* 125 */       PropertiesPropertySource vcapSource = new PropertiesPropertySource("vcap", properties);
/* 126 */       if (propertySources.contains("commandLineArgs")) {
/* 127 */         propertySources.addAfter("commandLineArgs", (PropertySource)vcapSource);
/*     */       } else {
/*     */         
/* 130 */         propertySources.addFirst((PropertySource)vcapSource);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addWithPrefix(Properties properties, Properties other, String prefix) {
/* 136 */     for (String key : other.stringPropertyNames()) {
/* 137 */       String prefixed = prefix + prefix;
/* 138 */       properties.setProperty(prefixed, other.getProperty(key));
/*     */     } 
/*     */   }
/*     */   
/*     */   private Properties getPropertiesFromApplication(Environment environment, JsonParser parser) {
/* 143 */     Properties properties = new Properties();
/*     */     try {
/* 145 */       String property = environment.getProperty("VCAP_APPLICATION", "{}");
/* 146 */       Map<String, Object> map = parser.parseMap(property);
/* 147 */       extractPropertiesFromApplication(properties, map);
/*     */     }
/* 149 */     catch (Exception ex) {
/* 150 */       this.logger.error("Could not parse VCAP_APPLICATION", ex);
/*     */     } 
/* 152 */     return properties;
/*     */   }
/*     */   
/*     */   private Properties getPropertiesFromServices(Environment environment, JsonParser parser) {
/* 156 */     Properties properties = new Properties();
/*     */     try {
/* 158 */       String property = environment.getProperty("VCAP_SERVICES", "{}");
/* 159 */       Map<String, Object> map = parser.parseMap(property);
/* 160 */       extractPropertiesFromServices(properties, map);
/*     */     }
/* 162 */     catch (Exception ex) {
/* 163 */       this.logger.error("Could not parse VCAP_SERVICES", ex);
/*     */     } 
/* 165 */     return properties;
/*     */   }
/*     */   
/*     */   private void extractPropertiesFromApplication(Properties properties, Map<String, Object> map) {
/* 169 */     if (map != null) {
/* 170 */       flatten(properties, map, "");
/*     */     }
/*     */   }
/*     */   
/*     */   private void extractPropertiesFromServices(Properties properties, Map<String, Object> map) {
/* 175 */     if (map != null) {
/* 176 */       for (Object services : map.values()) {
/*     */         
/* 178 */         List<Object> list = (List<Object>)services;
/* 179 */         for (Object object : list) {
/*     */           
/* 181 */           Map<String, Object> service = (Map<String, Object>)object;
/* 182 */           String key = (String)service.get("name");
/* 183 */           if (key == null) {
/* 184 */             key = (String)service.get("label");
/*     */           }
/* 186 */           flatten(properties, service, key);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void flatten(Properties properties, Map<String, Object> input, String path) {
/* 194 */     input.forEach((key, value) -> {
/*     */           String name = getPropertyName(path, key);
/*     */           if (value instanceof Map) {
/*     */             flatten(properties, (Map<String, Object>)value, name);
/*     */           } else if (value instanceof Collection) {
/*     */             Collection<?> collection = (Collection)value;
/*     */             properties.put(name, StringUtils.collectionToCommaDelimitedString(collection));
/*     */             int count = 0;
/*     */             for (Object item : collection) {
/*     */               String itemKey = "[" + count++ + "]";
/*     */               flatten(properties, Collections.singletonMap(itemKey, item), name);
/*     */             } 
/*     */           } else if (value instanceof String) {
/*     */             properties.put(name, value);
/*     */           } else if (value instanceof Number || value instanceof Boolean) {
/*     */             properties.put(name, value.toString());
/*     */           } else {
/*     */             properties.put(name, (value != null) ? value : "");
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPropertyName(String path, String key) {
/* 222 */     if (!StringUtils.hasText(path)) {
/* 223 */       return key;
/*     */     }
/* 225 */     if (key.startsWith("[")) {
/* 226 */       return path + path;
/*     */     }
/* 228 */     return path + "." + path;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\cloud\CloudFoundryVcapEnvironmentPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */