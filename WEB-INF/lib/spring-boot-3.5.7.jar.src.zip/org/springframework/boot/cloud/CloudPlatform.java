/*     */ package org.springframework.boot.cloud;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum CloudPlatform
/*     */ {
/*  43 */   NONE
/*     */   {
/*     */     public boolean isDetected(Environment environment)
/*     */     {
/*  47 */       return false;
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   CLOUD_FOUNDRY
/*     */   {
/*     */     public boolean isDetected(Environment environment)
/*     */     {
/*  59 */       return (environment.containsProperty("VCAP_APPLICATION") || environment.containsProperty("VCAP_SERVICES"));
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   HEROKU
/*     */   {
/*     */     public boolean isDetected(Environment environment)
/*     */     {
/*  71 */       return environment.containsProperty("DYNO");
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   SAP
/*     */   {
/*     */     public boolean isDetected(Environment environment)
/*     */     {
/*  83 */       return environment.containsProperty("HC_LANDSCAPE");
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   NOMAD
/*     */   {
/*     */     public boolean isDetected(Environment environment)
/*     */     {
/*  96 */       return environment.containsProperty("NOMAD_ALLOC_ID");
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   KUBERNETES
/*     */   {
/*     */     private static final String KUBERNETES_SERVICE_HOST = "KUBERNETES_SERVICE_HOST";
/*     */     
/*     */     private static final String KUBERNETES_SERVICE_PORT = "KUBERNETES_SERVICE_PORT";
/*     */     
/*     */     private static final String SERVICE_HOST_SUFFIX = "_SERVICE_HOST";
/*     */     
/*     */     private static final String SERVICE_PORT_SUFFIX = "_SERVICE_PORT";
/*     */ 
/*     */     
/*     */     public boolean isDetected(Environment environment) {
/* 116 */       if (environment instanceof ConfigurableEnvironment) { ConfigurableEnvironment configurableEnvironment = (ConfigurableEnvironment)environment;
/* 117 */         return isAutoDetected(configurableEnvironment); }
/*     */       
/* 119 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean isAutoDetected(ConfigurableEnvironment environment) {
/* 124 */       PropertySource<?> environmentPropertySource = environment.getPropertySources().get("systemEnvironment");
/* 125 */       if (environmentPropertySource != null) {
/* 126 */         if (environmentPropertySource.containsProperty("KUBERNETES_SERVICE_HOST") && environmentPropertySource
/* 127 */           .containsProperty("KUBERNETES_SERVICE_PORT")) {
/* 128 */           return true;
/*     */         }
/* 130 */         if (environmentPropertySource instanceof EnumerablePropertySource) { EnumerablePropertySource<?> enumerablePropertySource = (EnumerablePropertySource)environmentPropertySource;
/* 131 */           return isAutoDetected(enumerablePropertySource); }
/*     */       
/*     */       } 
/* 134 */       return false;
/*     */     }
/*     */     
/*     */     private boolean isAutoDetected(EnumerablePropertySource<?> environmentPropertySource) {
/* 138 */       for (String propertyName : environmentPropertySource.getPropertyNames()) {
/* 139 */         if (propertyName.endsWith("_SERVICE_HOST")) {
/* 140 */           String serviceName = propertyName.substring(0, propertyName
/* 141 */               .length() - "_SERVICE_HOST".length());
/* 142 */           if (environmentPropertySource.getProperty(serviceName + "_SERVICE_PORT") != null) {
/* 143 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/* 147 */       return false;
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   AZURE_APP_SERVICE
/*     */   {
/* 157 */     private final List<String> azureEnvVariables = Arrays.asList(new String[] { "WEBSITE_SITE_NAME", "WEBSITE_INSTANCE_ID", "WEBSITE_RESOURCE_GROUP", "WEBSITE_SKU" });
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDetected(Environment environment) {
/* 162 */       Objects.requireNonNull(environment); return this.azureEnvVariables.stream().allMatch(environment::containsProperty);
/*     */     }
/*     */   };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PROPERTY_NAME = "spring.main.cloud-platform";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive(Environment environment) {
/* 175 */     String platformProperty = environment.getProperty("spring.main.cloud-platform");
/* 176 */     return (isEnforced(platformProperty) || (platformProperty == null && isDetected(environment)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnforced(Environment environment) {
/* 187 */     return isEnforced(environment.getProperty("spring.main.cloud-platform"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnforced(Binder binder) {
/* 198 */     return isEnforced((String)binder.bind("spring.main.cloud-platform", String.class).orElse(null));
/*     */   }
/*     */   
/*     */   private boolean isEnforced(String platform) {
/* 202 */     return name().equalsIgnoreCase(platform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUsingForwardHeaders() {
/* 220 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CloudPlatform getActive(Environment environment) {
/* 229 */     if (environment != null) {
/* 230 */       for (CloudPlatform cloudPlatform : values()) {
/* 231 */         if (cloudPlatform.isActive(environment)) {
/* 232 */           return cloudPlatform;
/*     */         }
/*     */       } 
/*     */     }
/* 236 */     return null;
/*     */   }
/*     */   
/*     */   public abstract boolean isDetected(Environment paramEnvironment);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\cloud\CloudPlatform.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */