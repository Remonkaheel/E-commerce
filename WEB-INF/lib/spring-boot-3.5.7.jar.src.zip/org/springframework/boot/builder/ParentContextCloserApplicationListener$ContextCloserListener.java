/*     */ package org.springframework.boot.builder;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.event.ContextClosedEvent;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextCloserListener
/*     */   implements ApplicationListener<ContextClosedEvent>
/*     */ {
/*     */   private final WeakReference<ConfigurableApplicationContext> childContext;
/*     */   
/*     */   public ContextCloserListener(ConfigurableApplicationContext childContext) {
/*  86 */     this.childContext = new WeakReference<>(childContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ContextClosedEvent event) {
/*  91 */     ConfigurableApplicationContext context = this.childContext.get();
/*  92 */     if (context != null && event.getApplicationContext() == context.getParent() && context.isActive()) {
/*  93 */       context.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  99 */     if (this == obj) {
/* 100 */       return true;
/*     */     }
/* 102 */     if (obj == null) {
/* 103 */       return false;
/*     */     }
/* 105 */     if (obj instanceof ContextCloserListener) { ContextCloserListener other = (ContextCloserListener)obj;
/* 106 */       return ObjectUtils.nullSafeEquals(this.childContext.get(), other.childContext.get()); }
/*     */     
/* 108 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 113 */     return ObjectUtils.nullSafeHashCode(this.childContext.get());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\builder\ParentContextCloserApplicationListener$ContextCloserListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */