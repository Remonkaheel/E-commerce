/*    */ package org.springframework.boot.builder;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.context.event.ContextRefreshedEvent;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class EventPublisher
/*    */   implements ApplicationListener<ContextRefreshedEvent>, Ordered
/*    */ {
/* 65 */   private static final EventPublisher INSTANCE = new EventPublisher();
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 69 */     return Integer.MIN_VALUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(ContextRefreshedEvent event) {
/* 74 */     ApplicationContext context = event.getApplicationContext();
/* 75 */     if (context instanceof ConfigurableApplicationContext) { ConfigurableApplicationContext configurableApplicationContext = (ConfigurableApplicationContext)context; if (context == event
/* 76 */         .getSource())
/* 77 */         context.publishEvent(new ParentContextApplicationContextInitializer.ParentContextAvailableEvent(configurableApplicationContext));  }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\builder\ParentContextApplicationContextInitializer$EventPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */