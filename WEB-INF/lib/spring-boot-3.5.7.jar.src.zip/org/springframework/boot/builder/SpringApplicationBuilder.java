/*     */ package org.springframework.boot.builder;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.boot.ApplicationContextFactory;
/*     */ import org.springframework.boot.Banner;
/*     */ import org.springframework.boot.BootstrapRegistryInitializer;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.WebApplicationType;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.metrics.ApplicationStartup;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringApplicationBuilder
/*     */ {
/*     */   private final SpringApplication application;
/*     */   private volatile ConfigurableApplicationContext context;
/*     */   private SpringApplicationBuilder parent;
/*  83 */   private final AtomicBoolean running = new AtomicBoolean();
/*     */   
/*  85 */   private final Set<Class<?>> sources = new LinkedHashSet<>();
/*     */   
/*  87 */   private final Map<String, Object> defaultProperties = new LinkedHashMap<>();
/*     */   
/*     */   private ConfigurableEnvironment environment;
/*     */   
/*  91 */   private Set<String> additionalProfiles = new LinkedHashSet<>();
/*     */   
/*     */   private boolean registerShutdownHookApplied;
/*     */   
/*     */   private boolean configuredAsChild;
/*     */   
/*     */   public SpringApplicationBuilder(Class<?>... sources) {
/*  98 */     this(null, sources);
/*     */   }
/*     */   
/*     */   public SpringApplicationBuilder(ResourceLoader resourceLoader, Class<?>... sources) {
/* 102 */     this.application = createSpringApplication(resourceLoader, sources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpringApplication createSpringApplication(ResourceLoader resourceLoader, Class<?>... sources) {
/* 115 */     return new SpringApplication(resourceLoader, sources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurableApplicationContext context() {
/* 123 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplication application() {
/* 131 */     return this.application;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurableApplicationContext run(String... args) {
/* 142 */     if (this.running.get())
/*     */     {
/* 144 */       return this.context;
/*     */     }
/* 146 */     configureAsChildIfNecessary(args);
/* 147 */     if (this.running.compareAndSet(false, true))
/*     */     {
/* 149 */       this.context = build().run(args);
/*     */     }
/* 151 */     return this.context;
/*     */   }
/*     */   
/*     */   private void configureAsChildIfNecessary(String... args) {
/* 155 */     if (this.parent != null && !this.configuredAsChild) {
/* 156 */       this.configuredAsChild = true;
/* 157 */       if (!this.registerShutdownHookApplied) {
/* 158 */         this.application.setRegisterShutdownHook(false);
/*     */       }
/* 160 */       initializers((ApplicationContextInitializer<?>[])new ApplicationContextInitializer[] { new ParentContextApplicationContextInitializer((ApplicationContext)this.parent.run(args)) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplication build() {
/* 169 */     return build(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplication build(String... args) {
/* 179 */     configureAsChildIfNecessary(args);
/* 180 */     this.application.addPrimarySources(this.sources);
/* 181 */     return this.application;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder child(Class<?>... sources) {
/* 191 */     SpringApplicationBuilder child = new SpringApplicationBuilder(new Class[0]);
/* 192 */     child.sources(sources);
/*     */ 
/*     */     
/* 195 */     child.properties(this.defaultProperties)
/* 196 */       .environment(this.environment)
/* 197 */       .additionalProfiles(this.additionalProfiles);
/* 198 */     child.parent = this;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     web(WebApplicationType.NONE);
/*     */ 
/*     */     
/* 206 */     bannerMode(Banner.Mode.OFF);
/*     */ 
/*     */     
/* 209 */     this.application.addPrimarySources(this.sources);
/*     */     
/* 211 */     return child;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder parent(Class<?>... sources) {
/* 221 */     if (this.parent == null) {
/* 222 */       this
/*     */         
/* 224 */         .parent = (new SpringApplicationBuilder(sources)).web(WebApplicationType.NONE).properties(this.defaultProperties).environment(this.environment);
/*     */     } else {
/*     */       
/* 227 */       this.parent.sources(sources);
/*     */     } 
/* 229 */     return this.parent;
/*     */   }
/*     */   
/*     */   private SpringApplicationBuilder runAndExtractParent(String... args) {
/* 233 */     if (this.context == null) {
/* 234 */       run(args);
/*     */     }
/* 236 */     if (this.parent != null) {
/* 237 */       return this.parent;
/*     */     }
/* 239 */     throw new IllegalStateException("No parent defined yet (please use the other overloaded parent methods to set one)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder parent(ConfigurableApplicationContext parent) {
/* 249 */     this.parent = new SpringApplicationBuilder(new Class[0]);
/* 250 */     this.parent.context = parent;
/* 251 */     this.parent.running.set(true);
/* 252 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder sibling(Class<?>... sources) {
/* 265 */     return runAndExtractParent(new String[0]).child(sources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder sibling(Class<?>[] sources, String... args) {
/* 278 */     return runAndExtractParent(args).child(sources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder contextFactory(ApplicationContextFactory factory) {
/* 288 */     this.application.setApplicationContextFactory(factory);
/* 289 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder sources(Class<?>... sources) {
/* 298 */     this.sources.addAll(new LinkedHashSet<>(Arrays.asList(sources)));
/* 299 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder web(WebApplicationType webApplicationType) {
/* 310 */     this.application.setWebApplicationType(webApplicationType);
/* 311 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder logStartupInfo(boolean logStartupInfo) {
/* 320 */     this.application.setLogStartupInfo(logStartupInfo);
/* 321 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder banner(Banner banner) {
/* 331 */     this.application.setBanner(banner);
/* 332 */     return this;
/*     */   }
/*     */   
/*     */   public SpringApplicationBuilder bannerMode(Banner.Mode bannerMode) {
/* 336 */     this.application.setBannerMode(bannerMode);
/* 337 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder headless(boolean headless) {
/* 347 */     this.application.setHeadless(headless);
/* 348 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder registerShutdownHook(boolean registerShutdownHook) {
/* 358 */     this.registerShutdownHookApplied = true;
/* 359 */     this.application.setRegisterShutdownHook(registerShutdownHook);
/* 360 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder main(Class<?> mainApplicationClass) {
/* 369 */     this.application.setMainApplicationClass(mainApplicationClass);
/* 370 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder addCommandLineProperties(boolean addCommandLineProperties) {
/* 379 */     this.application.setAddCommandLineProperties(addCommandLineProperties);
/* 380 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder setAddConversionService(boolean addConversionService) {
/* 391 */     this.application.setAddConversionService(addConversionService);
/* 392 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder addBootstrapRegistryInitializer(BootstrapRegistryInitializer bootstrapRegistryInitializer) {
/* 404 */     this.application.addBootstrapRegistryInitializer(bootstrapRegistryInitializer);
/* 405 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder lazyInitialization(boolean lazyInitialization) {
/* 415 */     this.application.setLazyInitialization(lazyInitialization);
/* 416 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder properties(String... defaultProperties) {
/* 429 */     return properties(getMapFromKeyValuePairs(defaultProperties));
/*     */   }
/*     */   
/*     */   private Map<String, Object> getMapFromKeyValuePairs(String[] properties) {
/* 433 */     Map<String, Object> map = new HashMap<>();
/* 434 */     for (String property : properties) {
/* 435 */       int index = lowestIndexOf(property, new String[] { ":", "=" });
/* 436 */       String key = (index > 0) ? property.substring(0, index) : property;
/* 437 */       String value = (index > 0) ? property.substring(index + 1) : "";
/* 438 */       map.put(key, value);
/*     */     } 
/* 440 */     return map;
/*     */   }
/*     */   
/*     */   private int lowestIndexOf(String property, String... candidates) {
/* 444 */     int index = -1;
/* 445 */     for (String candidate : candidates) {
/* 446 */       int candidateIndex = property.indexOf(candidate);
/* 447 */       if (candidateIndex > 0) {
/* 448 */         index = (index != -1) ? Math.min(index, candidateIndex) : candidateIndex;
/*     */       }
/*     */     } 
/* 451 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder properties(Properties defaultProperties) {
/* 463 */     return properties(getMapFromProperties(defaultProperties));
/*     */   }
/*     */   
/*     */   private Map<String, Object> getMapFromProperties(Properties properties) {
/* 467 */     Map<String, Object> map = new HashMap<>();
/* 468 */     for (Object key : Collections.list(properties.propertyNames())) {
/* 469 */       map.put((String)key, properties.get(key));
/*     */     }
/* 471 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder properties(Map<String, Object> defaults) {
/* 483 */     this.defaultProperties.putAll(defaults);
/* 484 */     this.application.setDefaultProperties(this.defaultProperties);
/* 485 */     if (this.parent != null) {
/* 486 */       this.parent.properties(this.defaultProperties);
/* 487 */       this.parent.environment(this.environment);
/*     */     } 
/* 489 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder profiles(String... profiles) {
/* 498 */     this.additionalProfiles.addAll(Arrays.asList(profiles));
/* 499 */     this.application.setAdditionalProfiles(StringUtils.toStringArray(this.additionalProfiles));
/* 500 */     return this;
/*     */   }
/*     */   
/*     */   private SpringApplicationBuilder additionalProfiles(Collection<String> additionalProfiles) {
/* 504 */     this.additionalProfiles = new LinkedHashSet<>(additionalProfiles);
/* 505 */     this.application.setAdditionalProfiles(StringUtils.toStringArray(this.additionalProfiles));
/* 506 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder beanNameGenerator(BeanNameGenerator beanNameGenerator) {
/* 516 */     this.application.setBeanNameGenerator(beanNameGenerator);
/* 517 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder environment(ConfigurableEnvironment environment) {
/* 526 */     this.application.setEnvironment(environment);
/* 527 */     this.environment = environment;
/* 528 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder environmentPrefix(String environmentPrefix) {
/* 539 */     this.application.setEnvironmentPrefix(environmentPrefix);
/* 540 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder resourceLoader(ResourceLoader resourceLoader) {
/* 550 */     this.application.setResourceLoader(resourceLoader);
/* 551 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder initializers(ApplicationContextInitializer<?>... initializers) {
/* 561 */     this.application.addInitializers((ApplicationContextInitializer[])initializers);
/* 562 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder listeners(ApplicationListener<?>... listeners) {
/* 574 */     this.application.addListeners((ApplicationListener[])listeners);
/* 575 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder applicationStartup(ApplicationStartup applicationStartup) {
/* 586 */     this.application.setApplicationStartup(applicationStartup);
/* 587 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringApplicationBuilder allowCircularReferences(boolean allowCircularReferences) {
/* 599 */     this.application.setAllowCircularReferences(allowCircularReferences);
/* 600 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\builder\SpringApplicationBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */