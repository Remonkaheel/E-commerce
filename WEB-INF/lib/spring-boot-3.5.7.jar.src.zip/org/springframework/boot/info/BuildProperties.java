/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.time.DateTimeException;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Properties;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.context.annotation.ImportRuntimeHints;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ImportRuntimeHints({BuildProperties.BuildPropertiesRuntimeHints.class})
/*     */ public class BuildProperties
/*     */   extends InfoProperties
/*     */ {
/*     */   public BuildProperties(Properties entries) {
/*  43 */     super(processEntries(entries));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getGroup() {
/*  51 */     return get("group");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getArtifact() {
/*  59 */     return get("artifact");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  67 */     return get("name");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVersion() {
/*  75 */     return get("version");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getTime() {
/*  87 */     return getInstant("time");
/*     */   }
/*     */   
/*     */   private static Properties processEntries(Properties properties) {
/*  91 */     coerceDate(properties, "time");
/*  92 */     return properties;
/*     */   }
/*     */   
/*     */   private static void coerceDate(Properties properties, String key) {
/*  96 */     String value = properties.getProperty(key);
/*  97 */     if (value != null) {
/*     */       
/*     */       try {
/* 100 */         String updatedValue = String.valueOf(((Instant)DateTimeFormatter.ISO_INSTANT.<Instant>parse(value, Instant::from)).toEpochMilli());
/* 101 */         properties.setProperty(key, updatedValue);
/*     */       }
/* 103 */       catch (DateTimeException dateTimeException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class BuildPropertiesRuntimeHints
/*     */     implements RuntimeHintsRegistrar
/*     */   {
/*     */     public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 113 */       hints.resources().registerPattern("META-INF/build-info.properties");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\BuildProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */