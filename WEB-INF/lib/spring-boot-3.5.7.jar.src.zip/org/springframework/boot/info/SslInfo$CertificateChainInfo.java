/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CertificateChainInfo
/*     */ {
/*     */   private final String alias;
/*     */   private final List<SslInfo.CertificateInfo> certificates;
/*     */   
/*     */   CertificateChainInfo(KeyStore keyStore, String alias) {
/* 151 */     this.alias = alias;
/* 152 */     this.certificates = extractCertificates(keyStore, alias);
/*     */   }
/*     */   
/*     */   private List<SslInfo.CertificateInfo> extractCertificates(KeyStore keyStore, String alias) {
/*     */     try {
/* 157 */       Certificate[] certificates = keyStore.getCertificateChain(alias);
/* 158 */       return !ObjectUtils.isEmpty((Object[])certificates) ? 
/* 159 */         Arrays.<Certificate>stream(certificates).map(x$0 -> new SslInfo.CertificateInfo(SslInfo.this, x$0)).toList() : Collections.<SslInfo.CertificateInfo>emptyList();
/*     */     }
/* 161 */     catch (KeyStoreException ex) {
/* 162 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getAlias() {
/* 167 */     return this.alias;
/*     */   }
/*     */   
/*     */   public List<SslInfo.CertificateInfo> getCertificates() {
/* 171 */     return this.certificates;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\SslInfo$CertificateChainInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */