/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeParseException;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.context.annotation.ImportRuntimeHints;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ImportRuntimeHints({GitProperties.GitPropertiesRuntimeHints.class})
/*     */ public class GitProperties
/*     */   extends InfoProperties
/*     */ {
/*  42 */   static final Set<Coercer> coercers = Set.of(Coercer.milliseconds(), 
/*  43 */       Coercer.dateTimePattern("yyyy-MM-dd'T'HH:mm:ssXXX"), Coercer.dateTimePattern("yyyy-MM-dd'T'HH:mm:ssZ"));
/*     */   
/*     */   public GitProperties(Properties entries) {
/*  46 */     super(processEntries(entries));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBranch() {
/*  54 */     return get("branch");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCommitId() {
/*  62 */     return get("commit.id");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getShortCommitId() {
/*  70 */     String shortId = get("commit.id.abbrev");
/*  71 */     if (shortId != null) {
/*  72 */       return shortId;
/*     */     }
/*  74 */     String id = getCommitId();
/*  75 */     if (id == null) {
/*  76 */       return null;
/*     */     }
/*  78 */     return (id.length() > 7) ? id.substring(0, 7) : id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getCommitTime() {
/*  90 */     return getInstant("commit.time");
/*     */   }
/*     */   
/*     */   private static Properties processEntries(Properties properties) {
/*  94 */     coercePropertyToEpoch(properties, "commit.time");
/*  95 */     coercePropertyToEpoch(properties, "build.time");
/*  96 */     Object commitId = properties.get("commit.id");
/*  97 */     if (commitId != null)
/*     */     {
/*  99 */       properties.put("commit.id.full", commitId);
/*     */     }
/* 101 */     return properties;
/*     */   }
/*     */   
/*     */   private static void coercePropertyToEpoch(Properties properties, String key) {
/* 105 */     String value = properties.getProperty(key);
/* 106 */     if (value != null) {
/* 107 */       properties.setProperty(key, coercers
/* 108 */           .stream()
/* 109 */           .map(coercer -> coercer.apply(value))
/* 110 */           .filter(Objects::nonNull)
/* 111 */           .findFirst()
/* 112 */           .orElse(value));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class GitPropertiesRuntimeHints
/*     */     implements RuntimeHintsRegistrar
/*     */   {
/*     */     public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 123 */       hints.resources().registerPattern("git.properties");
/*     */     }
/*     */   } private static final class Coercer extends Record { private final Function<String, Long> action; private final Predicate<RuntimeException> ignoredExceptions; public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/info/GitProperties$Coercer;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #131	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/info/GitProperties$Coercer;
/*     */     }
/*     */     public final int hashCode() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/info/GitProperties$Coercer;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #131	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/info/GitProperties$Coercer;
/*     */     }
/* 131 */     private Coercer(Function<String, Long> action, Predicate<RuntimeException> ignoredExceptions) { this.action = action; this.ignoredExceptions = ignoredExceptions; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/info/GitProperties$Coercer;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #131	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/boot/info/GitProperties$Coercer;
/* 131 */       //   0	8	1	o	Ljava/lang/Object; } public Function<String, Long> action() { return this.action; } public Predicate<RuntimeException> ignoredExceptions() { return this.ignoredExceptions; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String apply(String value) {
/*     */       try {
/* 140 */         Long result = this.action.apply(value);
/* 141 */         return (result != null) ? String.valueOf(result) : null;
/*     */       }
/* 143 */       catch (RuntimeException ex) {
/* 144 */         if (this.ignoredExceptions.test(ex)) {
/* 145 */           return null;
/*     */         }
/* 147 */         throw ex;
/*     */       } 
/*     */     }
/*     */     
/*     */     static Coercer milliseconds() {
/* 152 */       Objects.requireNonNull(NumberFormatException.class); return new Coercer(value -> Long.valueOf(Long.parseLong(value) * 1000L), NumberFormatException.class::isInstance);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     static Coercer dateTimePattern(String pattern) {
/* 158 */       Objects.requireNonNull(DateTimeParseException.class); return new Coercer(value -> Long.valueOf(((Instant)DateTimeFormatter.ofPattern(pattern).<Instant>parse(value, Instant::from)).toEpochMilli()), DateTimeParseException.class::isInstance);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\GitProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */