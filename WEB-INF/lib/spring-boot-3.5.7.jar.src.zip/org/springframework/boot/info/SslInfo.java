/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.time.Clock;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslBundles;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SslInfo
/*     */ {
/*     */   private final SslBundles sslBundles;
/*     */   private final Duration certificateValidityWarningThreshold;
/*     */   private final Clock clock;
/*     */   
/*     */   public SslInfo(SslBundles sslBundles, Duration certificateValidityWarningThreshold) {
/*  62 */     this(sslBundles, certificateValidityWarningThreshold, Clock.systemDefaultZone());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslInfo(SslBundles sslBundles, Duration certificateValidityWarningThreshold, Clock clock) {
/*  74 */     this.sslBundles = sslBundles;
/*  75 */     this.certificateValidityWarningThreshold = certificateValidityWarningThreshold;
/*  76 */     this.clock = clock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<BundleInfo> getBundles() {
/*  84 */     return this.sslBundles.getBundleNames()
/*  85 */       .stream()
/*  86 */       .map(name -> new BundleInfo(name, this.sslBundles.getBundle(name)))
/*  87 */       .toList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleInfo getBundle(String name) {
/*  98 */     SslBundle bundle = this.sslBundles.getBundle(name);
/*  99 */     return new BundleInfo(name, bundle);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final class BundleInfo
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final List<SslInfo.CertificateChainInfo> certificateChains;
/*     */ 
/*     */     
/*     */     private BundleInfo(String name, SslBundle sslBundle) {
/* 112 */       this.name = name;
/* 113 */       this.certificateChains = extractCertificateChains(sslBundle.getStores().getKeyStore());
/*     */     }
/*     */     
/*     */     private List<SslInfo.CertificateChainInfo> extractCertificateChains(KeyStore keyStore) {
/* 117 */       if (keyStore == null) {
/* 118 */         return Collections.emptyList();
/*     */       }
/*     */       try {
/* 121 */         return Collections.<String>list(keyStore.aliases())
/* 122 */           .stream()
/* 123 */           .map(alias -> new SslInfo.CertificateChainInfo(keyStore, alias))
/* 124 */           .toList();
/*     */       }
/* 126 */       catch (KeyStoreException ex) {
/* 127 */         return Collections.emptyList();
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getName() {
/* 132 */       return this.name;
/*     */     }
/*     */     
/*     */     public List<SslInfo.CertificateChainInfo> getCertificateChains() {
/* 136 */       return this.certificateChains;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final class CertificateChainInfo
/*     */   {
/*     */     private final String alias;
/*     */ 
/*     */     
/*     */     private final List<SslInfo.CertificateInfo> certificates;
/*     */ 
/*     */     
/*     */     CertificateChainInfo(KeyStore keyStore, String alias) {
/* 151 */       this.alias = alias;
/* 152 */       this.certificates = extractCertificates(keyStore, alias);
/*     */     }
/*     */     
/*     */     private List<SslInfo.CertificateInfo> extractCertificates(KeyStore keyStore, String alias) {
/*     */       try {
/* 157 */         Certificate[] certificates = keyStore.getCertificateChain(alias);
/* 158 */         return !ObjectUtils.isEmpty((Object[])certificates) ? 
/* 159 */           Arrays.<Certificate>stream(certificates).map(x$0 -> new SslInfo.CertificateInfo(x$0)).toList() : Collections.<SslInfo.CertificateInfo>emptyList();
/*     */       }
/* 161 */       catch (KeyStoreException ex) {
/* 162 */         return Collections.emptyList();
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getAlias() {
/* 167 */       return this.alias;
/*     */     }
/*     */     
/*     */     public List<SslInfo.CertificateInfo> getCertificates() {
/* 171 */       return this.certificates;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final class CertificateInfo
/*     */   {
/*     */     private final X509Certificate certificate;
/*     */ 
/*     */ 
/*     */     
/*     */     private CertificateInfo(Certificate certificate) {
/* 184 */       X509Certificate x509Certificate = (X509Certificate)certificate; this.certificate = (certificate instanceof X509Certificate) ? x509Certificate : null;
/*     */     }
/*     */     
/*     */     public String getSubject() {
/* 188 */       return extract(X509Certificate::getSubjectX500Principal, X500Principal::getName);
/*     */     }
/*     */     
/*     */     public String getIssuer() {
/* 192 */       return extract(X509Certificate::getIssuerX500Principal, X500Principal::getName);
/*     */     }
/*     */     
/*     */     public String getSerialNumber() {
/* 196 */       return extract(X509Certificate::getSerialNumber, serial -> serial.toString(16));
/*     */     }
/*     */     
/*     */     public String getVersion() {
/* 200 */       return extract(certificate -> "V" + certificate.getVersion());
/*     */     }
/*     */     
/*     */     public String getSignatureAlgorithmName() {
/* 204 */       return extract(X509Certificate::getSigAlgName);
/*     */     }
/*     */     
/*     */     public Instant getValidityStarts() {
/* 208 */       return extract(X509Certificate::getNotBefore, Date::toInstant);
/*     */     }
/*     */     
/*     */     public Instant getValidityEnds() {
/* 212 */       return extract(X509Certificate::getNotAfter, Date::toInstant);
/*     */     }
/*     */     
/*     */     public SslInfo.CertificateValidityInfo getValidity() {
/* 216 */       return extract(certificate -> {
/*     */             Instant starts = getValidityStarts(); Instant ends = getValidityEnds();
/*     */             Duration threshold = SslInfo.this.certificateValidityWarningThreshold;
/*     */             SslInfo.CertificateValidityInfo.Status validity = checkValidity(starts, ends, threshold);
/*     */             switch (validity) {
/*     */               default:
/*     */                 throw new IncompatibleClassChangeError();
/*     */               case VALID:
/*     */               
/*     */               case EXPIRED:
/*     */               
/*     */               case NOT_YET_VALID:
/*     */               
/*     */               case WILL_EXPIRE_SOON:
/*     */                 break;
/*     */             } 
/*     */             return new SslInfo.CertificateValidityInfo(SslInfo.CertificateValidityInfo.Status.WILL_EXPIRE_SOON, "Certificate will expire within threshold (%s) at %s", new Object[] { threshold, ends });
/* 233 */           }); } private SslInfo.CertificateValidityInfo.Status checkValidity(Instant starts, Instant ends, Duration threshold) { Instant now = SslInfo.this.clock.instant();
/* 234 */       if (now.isBefore(starts)) {
/* 235 */         return SslInfo.CertificateValidityInfo.Status.NOT_YET_VALID;
/*     */       }
/* 237 */       if (now.isAfter(ends)) {
/* 238 */         return SslInfo.CertificateValidityInfo.Status.EXPIRED;
/*     */       }
/* 240 */       Instant shouldBeValidAt = now.plus(threshold);
/* 241 */       if (shouldBeValidAt.isAfter(ends)) {
/* 242 */         return SslInfo.CertificateValidityInfo.Status.WILL_EXPIRE_SOON;
/*     */       }
/* 244 */       return SslInfo.CertificateValidityInfo.Status.VALID; }
/*     */ 
/*     */     
/*     */     private <V, R> R extract(Function<X509Certificate, V> valueExtractor, Function<V, R> resultExtractor) {
/* 248 */       return extract(valueExtractor.andThen(resultExtractor));
/*     */     }
/*     */     
/*     */     private <R> R extract(Function<X509Certificate, R> extractor) {
/* 252 */       return (this.certificate != null) ? extractor.apply(this.certificate) : null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CertificateValidityInfo
/*     */   {
/* 262 */     static final CertificateValidityInfo VALID = new CertificateValidityInfo(Status.VALID, null, new Object[0]);
/*     */     
/*     */     private final Status status;
/*     */     
/*     */     private final String message;
/*     */     
/*     */     CertificateValidityInfo(Status status, String message, Object... messageArgs) {
/* 269 */       this.status = status;
/* 270 */       this.message = (message != null) ? message.formatted(messageArgs) : null;
/*     */     }
/*     */     
/*     */     public Status getStatus() {
/* 274 */       return this.status;
/*     */     }
/*     */     
/*     */     public String getMessage() {
/* 278 */       return this.message;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public enum Status
/*     */     {
/* 289 */       VALID(true),
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 294 */       NOT_YET_VALID(false),
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 299 */       EXPIRED(false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 305 */       WILL_EXPIRE_SOON(true);
/*     */       
/*     */       private final boolean valid;
/*     */       
/*     */       Status(boolean valid) {
/* 310 */         this.valid = valid;
/*     */       }
/*     */       
/*     */       public boolean isValid() {
/* 314 */         return this.valid; } } } public enum Status { public boolean isValid() { return this.valid; }
/*     */ 
/*     */     
/*     */     VALID(true),
/*     */     NOT_YET_VALID(false),
/*     */     EXPIRED(false),
/*     */     WILL_EXPIRE_SOON(true);
/*     */     private final boolean valid;
/*     */     
/*     */     Status(boolean valid) {
/*     */       this.valid = valid;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\SslInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */