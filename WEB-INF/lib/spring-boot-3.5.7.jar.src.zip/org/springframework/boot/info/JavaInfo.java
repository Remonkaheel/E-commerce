/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaInfo
/*     */ {
/*  37 */   private final String version = System.getProperty("java.version");
/*  38 */   private final JavaVendorInfo vendor = new JavaVendorInfo();
/*  39 */   private final JavaRuntimeEnvironmentInfo runtime = new JavaRuntimeEnvironmentInfo();
/*  40 */   private final JavaVirtualMachineInfo jvm = new JavaVirtualMachineInfo();
/*     */ 
/*     */   
/*     */   public String getVersion() {
/*  44 */     return this.version;
/*     */   }
/*     */   
/*     */   public JavaVendorInfo getVendor() {
/*  48 */     return this.vendor;
/*     */   }
/*     */   
/*     */   public JavaRuntimeEnvironmentInfo getRuntime() {
/*  52 */     return this.runtime;
/*     */   }
/*     */   
/*     */   public JavaVirtualMachineInfo getJvm() {
/*  56 */     return this.jvm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class JavaVendorInfo
/*     */   {
/*  72 */     private final String name = System.getProperty("java.vendor");
/*  73 */     private final String version = System.getProperty("java.vendor.version");
/*     */ 
/*     */     
/*     */     public String getName() {
/*  77 */       return this.name;
/*     */     }
/*     */     
/*     */     public String getVersion() {
/*  81 */       return this.version;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class JavaRuntimeEnvironmentInfo
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     private final String version;
/*     */ 
/*     */     
/*     */     public JavaRuntimeEnvironmentInfo() {
/*  96 */       this.name = System.getProperty("java.runtime.name");
/*  97 */       this.version = System.getProperty("java.runtime.version");
/*     */     }
/*     */     
/*     */     public String getName() {
/* 101 */       return this.name;
/*     */     }
/*     */     
/*     */     public String getVersion() {
/* 105 */       return this.version;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class JavaVirtualMachineInfo
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     private final String vendor;
/*     */     
/*     */     private final String version;
/*     */ 
/*     */     
/*     */     public JavaVirtualMachineInfo() {
/* 122 */       this.name = System.getProperty("java.vm.name");
/* 123 */       this.vendor = System.getProperty("java.vm.vendor");
/* 124 */       this.version = System.getProperty("java.vm.version");
/*     */     }
/*     */     
/*     */     public String getName() {
/* 128 */       return this.name;
/*     */     }
/*     */     
/*     */     public String getVendor() {
/* 132 */       return this.vendor;
/*     */     }
/*     */     
/*     */     public String getVersion() {
/* 136 */       return this.version;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\JavaInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */