/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PropertiesIterator
/*     */   implements Iterator<InfoProperties.Entry>
/*     */ {
/*     */   private final Iterator<Map.Entry<Object, Object>> iterator;
/*     */   
/*     */   private PropertiesIterator(Properties properties) {
/* 100 */     this.iterator = properties.entrySet().iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 105 */     return this.iterator.hasNext();
/*     */   }
/*     */ 
/*     */   
/*     */   public InfoProperties.Entry next() {
/* 110 */     Map.Entry<Object, Object> entry = this.iterator.next();
/* 111 */     return new InfoProperties.Entry((String)entry.getKey(), (String)entry.getValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove() {
/* 116 */     throw new UnsupportedOperationException("InfoProperties are immutable.");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\InfoProperties$PropertiesIterator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */