/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BundleInfo
/*     */ {
/*     */   private final String name;
/*     */   private final List<SslInfo.CertificateChainInfo> certificateChains;
/*     */   
/*     */   private BundleInfo(String name, SslBundle sslBundle) {
/* 112 */     this.name = name;
/* 113 */     this.certificateChains = extractCertificateChains(sslBundle.getStores().getKeyStore());
/*     */   }
/*     */   
/*     */   private List<SslInfo.CertificateChainInfo> extractCertificateChains(KeyStore keyStore) {
/* 117 */     if (keyStore == null) {
/* 118 */       return Collections.emptyList();
/*     */     }
/*     */     try {
/* 121 */       return Collections.<String>list(keyStore.aliases())
/* 122 */         .stream()
/* 123 */         .map(alias -> new SslInfo.CertificateChainInfo(SslInfo.this, keyStore, alias))
/* 124 */         .toList();
/*     */     }
/* 126 */     catch (KeyStoreException ex) {
/* 127 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getName() {
/* 132 */     return this.name;
/*     */   }
/*     */   
/*     */   public List<SslInfo.CertificateChainInfo> getCertificateChains() {
/* 136 */     return this.certificateChains;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\SslInfo$BundleInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */