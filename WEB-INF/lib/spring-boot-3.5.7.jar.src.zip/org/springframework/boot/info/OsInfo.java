/*    */ package org.springframework.boot.info;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OsInfo
/*    */ {
/* 34 */   private final String name = System.getProperty("os.name");
/* 35 */   private final String version = System.getProperty("os.version");
/* 36 */   private final String arch = System.getProperty("os.arch");
/*    */ 
/*    */   
/*    */   public String getName() {
/* 40 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getVersion() {
/* 44 */     return this.version;
/*    */   }
/*    */   
/*    */   public String getArch() {
/* 48 */     return this.arch;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\OsInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */