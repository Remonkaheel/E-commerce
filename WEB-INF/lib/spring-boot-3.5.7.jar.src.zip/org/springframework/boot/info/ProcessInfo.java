/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.lang.management.GarbageCollectorMXBean;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.MemoryMXBean;
/*     */ import java.lang.management.MemoryUsage;
/*     */ import java.lang.management.PlatformManagedObject;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProcessInfo
/*     */ {
/*     */   private static final String VIRTUAL_THREAD_SCHEDULER_CLASS = "jdk.management.VirtualThreadSchedulerMXBean";
/*  41 */   private static final boolean VIRTUAL_THREAD_SCHEDULER_CLASS_PRESENT = ClassUtils.isPresent("jdk.management.VirtualThreadSchedulerMXBean", null);
/*     */   
/*  43 */   private static final Runtime runtime = Runtime.getRuntime();
/*     */   
/*     */   private final long pid;
/*     */   
/*     */   private final long parentPid;
/*     */   
/*     */   private final String owner;
/*     */   
/*     */   public ProcessInfo() {
/*  52 */     ProcessHandle process = ProcessHandle.current();
/*  53 */     this.pid = process.pid();
/*  54 */     this.parentPid = ((Long)process.parent().<Long>map(ProcessHandle::pid).orElse(Long.valueOf(-1L))).longValue();
/*  55 */     this.owner = process.info().user().orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCpus() {
/*  66 */     return runtime.availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MemoryInfo getMemory() {
/*  84 */     return new MemoryInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VirtualThreadsInfo getVirtualThreads() {
/*  98 */     if (!VIRTUAL_THREAD_SCHEDULER_CLASS_PRESENT) {
/*  99 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 103 */       Class<PlatformManagedObject> mxbeanClass = ClassUtils.forName("jdk.management.VirtualThreadSchedulerMXBean", null);
/* 104 */       PlatformManagedObject mxbean = ManagementFactory.getPlatformMXBean(mxbeanClass);
/* 105 */       int mountedVirtualThreadCount = ((Integer)invokeMethod(mxbeanClass, mxbean, "getMountedVirtualThreadCount")).intValue();
/* 106 */       long queuedVirtualThreadCount = ((Long)invokeMethod(mxbeanClass, mxbean, "getQueuedVirtualThreadCount")).longValue();
/* 107 */       int parallelism = ((Integer)invokeMethod(mxbeanClass, mxbean, "getParallelism")).intValue();
/* 108 */       int poolSize = ((Integer)invokeMethod(mxbeanClass, mxbean, "getPoolSize")).intValue();
/* 109 */       return new VirtualThreadsInfo(mountedVirtualThreadCount, queuedVirtualThreadCount, parallelism, poolSize);
/*     */     }
/* 111 */     catch (ReflectiveOperationException ex) {
/* 112 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T invokeMethod(Class<?> mxbeanClass, Object mxbean, String name) throws ReflectiveOperationException {
/* 118 */     Method method = mxbeanClass.getMethod(name, new Class[0]);
/* 119 */     return (T)method.invoke(mxbean, new Object[0]);
/*     */   }
/*     */   
/*     */   public long getPid() {
/* 123 */     return this.pid;
/*     */   }
/*     */   
/*     */   public long getParentPid() {
/* 127 */     return this.parentPid;
/*     */   }
/*     */   
/*     */   public String getOwner() {
/* 131 */     return this.owner;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class VirtualThreadsInfo
/*     */   {
/*     */     private final int mounted;
/*     */ 
/*     */     
/*     */     private final long queued;
/*     */ 
/*     */     
/*     */     private final int parallelism;
/*     */     
/*     */     private final int poolSize;
/*     */ 
/*     */     
/*     */     VirtualThreadsInfo(int mounted, long queued, int parallelism, int poolSize) {
/* 150 */       this.mounted = mounted;
/* 151 */       this.queued = queued;
/* 152 */       this.parallelism = parallelism;
/* 153 */       this.poolSize = poolSize;
/*     */     }
/*     */     
/*     */     public int getMounted() {
/* 157 */       return this.mounted;
/*     */     }
/*     */     
/*     */     public long getQueued() {
/* 161 */       return this.queued;
/*     */     }
/*     */     
/*     */     public int getParallelism() {
/* 165 */       return this.parallelism;
/*     */     }
/*     */     
/*     */     public int getPoolSize() {
/* 169 */       return this.poolSize;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MemoryInfo
/*     */   {
/* 181 */     private static final MemoryMXBean memoryMXBean = ManagementFactory.getMemoryMXBean();
/*     */ 
/*     */     
/* 184 */     private static final List<GarbageCollectorMXBean> garbageCollectorMXBeans = ManagementFactory.getGarbageCollectorMXBeans();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     private final MemoryUsageInfo heap = new MemoryUsageInfo(memoryMXBean.getHeapMemoryUsage());
/* 194 */     private final MemoryUsageInfo nonHeap = new MemoryUsageInfo(memoryMXBean.getNonHeapMemoryUsage());
/* 195 */     private final List<GarbageCollectorInfo> garbageCollectors = garbageCollectorMXBeans.stream().map(GarbageCollectorInfo::new).toList();
/*     */ 
/*     */     
/*     */     public MemoryUsageInfo getHeap() {
/* 199 */       return this.heap;
/*     */     }
/*     */     
/*     */     public MemoryUsageInfo getNonHeap() {
/* 203 */       return this.nonHeap;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<GarbageCollectorInfo> getGarbageCollectors() {
/* 217 */       return this.garbageCollectors;
/*     */     }
/*     */     
/*     */     public static class MemoryUsageInfo
/*     */     {
/*     */       private final MemoryUsage memoryUsage;
/*     */       
/*     */       MemoryUsageInfo(MemoryUsage memoryUsage) {
/* 225 */         this.memoryUsage = memoryUsage;
/*     */       }
/*     */       
/*     */       public long getInit() {
/* 229 */         return this.memoryUsage.getInit();
/*     */       }
/*     */       
/*     */       public long getUsed() {
/* 233 */         return this.memoryUsage.getUsed();
/*     */       }
/*     */       
/*     */       public long getCommitted() {
/* 237 */         return this.memoryUsage.getCommitted();
/*     */       }
/*     */       
/*     */       public long getMax() {
/* 241 */         return this.memoryUsage.getMax();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class GarbageCollectorInfo
/*     */     {
/*     */       private final String name;
/*     */ 
/*     */       
/*     */       private final long collectionCount;
/*     */ 
/*     */ 
/*     */       
/*     */       GarbageCollectorInfo(GarbageCollectorMXBean garbageCollectorMXBean) {
/* 258 */         this.name = garbageCollectorMXBean.getName();
/* 259 */         this.collectionCount = garbageCollectorMXBean.getCollectionCount();
/*     */       }
/*     */       
/*     */       public String getName() {
/* 263 */         return this.name;
/*     */       }
/*     */       
/*     */       public long getCollectionCount() {
/* 267 */         return this.collectionCount; } } } public static class MemoryUsageInfo { private final MemoryUsage memoryUsage; MemoryUsageInfo(MemoryUsage memoryUsage) { this.memoryUsage = memoryUsage; } public long getInit() { return this.memoryUsage.getInit(); } public long getUsed() { return this.memoryUsage.getUsed(); } public long getCommitted() { return this.memoryUsage.getCommitted(); } public long getMax() { return this.memoryUsage.getMax(); } } public static class GarbageCollectorInfo { public long getCollectionCount() { return this.collectionCount; }
/*     */ 
/*     */     
/*     */     private final String name;
/*     */     private final long collectionCount;
/*     */     
/*     */     GarbageCollectorInfo(GarbageCollectorMXBean garbageCollectorMXBean) {
/*     */       this.name = garbageCollectorMXBean.getName();
/*     */       this.collectionCount = garbageCollectorMXBean.getCollectionCount();
/*     */     }
/*     */     
/*     */     public String getName() {
/*     */       return this.name;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\ProcessInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */