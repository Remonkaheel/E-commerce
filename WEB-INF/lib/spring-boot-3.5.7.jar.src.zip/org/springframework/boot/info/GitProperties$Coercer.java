/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeParseException;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Coercer
/*     */   extends Record
/*     */ {
/*     */   private final Function<String, Long> action;
/*     */   private final Predicate<RuntimeException> ignoredExceptions;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lorg/springframework/boot/info/GitProperties$Coercer;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #131	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/boot/info/GitProperties$Coercer;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/info/GitProperties$Coercer;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #131	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/boot/info/GitProperties$Coercer;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lorg/springframework/boot/info/GitProperties$Coercer;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #131	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lorg/springframework/boot/info/GitProperties$Coercer;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   private Coercer(Function<String, Long> action, Predicate<RuntimeException> ignoredExceptions) {
/* 131 */     this.action = action; this.ignoredExceptions = ignoredExceptions; } public Function<String, Long> action() { return this.action; } public Predicate<RuntimeException> ignoredExceptions() { return this.ignoredExceptions; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String apply(String value) {
/*     */     try {
/* 140 */       Long result = this.action.apply(value);
/* 141 */       return (result != null) ? String.valueOf(result) : null;
/*     */     }
/* 143 */     catch (RuntimeException ex) {
/* 144 */       if (this.ignoredExceptions.test(ex)) {
/* 145 */         return null;
/*     */       }
/* 147 */       throw ex;
/*     */     } 
/*     */   }
/*     */   
/*     */   static Coercer milliseconds() {
/* 152 */     Objects.requireNonNull(NumberFormatException.class); return new Coercer(value -> Long.valueOf(Long.parseLong(value) * 1000L), NumberFormatException.class::isInstance);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Coercer dateTimePattern(String pattern) {
/* 158 */     Objects.requireNonNull(DateTimeParseException.class); return new Coercer(value -> Long.valueOf(((Instant)DateTimeFormatter.ofPattern(pattern).<Instant>parse(value, Instant::from)).toEpochMilli()), DateTimeParseException.class::isInstance);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\GitProperties$Coercer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */