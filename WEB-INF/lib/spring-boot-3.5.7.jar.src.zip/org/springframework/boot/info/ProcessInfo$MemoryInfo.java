/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.lang.management.GarbageCollectorMXBean;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.MemoryMXBean;
/*     */ import java.lang.management.MemoryUsage;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryInfo
/*     */ {
/* 181 */   private static final MemoryMXBean memoryMXBean = ManagementFactory.getMemoryMXBean();
/*     */ 
/*     */   
/* 184 */   private static final List<GarbageCollectorMXBean> garbageCollectorMXBeans = ManagementFactory.getGarbageCollectorMXBeans();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   private final MemoryUsageInfo heap = new MemoryUsageInfo(memoryMXBean.getHeapMemoryUsage());
/* 194 */   private final MemoryUsageInfo nonHeap = new MemoryUsageInfo(memoryMXBean.getNonHeapMemoryUsage());
/* 195 */   private final List<GarbageCollectorInfo> garbageCollectors = garbageCollectorMXBeans.stream().map(GarbageCollectorInfo::new).toList();
/*     */ 
/*     */   
/*     */   public MemoryUsageInfo getHeap() {
/* 199 */     return this.heap;
/*     */   }
/*     */   
/*     */   public MemoryUsageInfo getNonHeap() {
/* 203 */     return this.nonHeap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GarbageCollectorInfo> getGarbageCollectors() {
/* 217 */     return this.garbageCollectors;
/*     */   }
/*     */   
/*     */   public static class MemoryUsageInfo
/*     */   {
/*     */     private final MemoryUsage memoryUsage;
/*     */     
/*     */     MemoryUsageInfo(MemoryUsage memoryUsage) {
/* 225 */       this.memoryUsage = memoryUsage;
/*     */     }
/*     */     
/*     */     public long getInit() {
/* 229 */       return this.memoryUsage.getInit();
/*     */     }
/*     */     
/*     */     public long getUsed() {
/* 233 */       return this.memoryUsage.getUsed();
/*     */     }
/*     */     
/*     */     public long getCommitted() {
/* 237 */       return this.memoryUsage.getCommitted();
/*     */     }
/*     */     
/*     */     public long getMax() {
/* 241 */       return this.memoryUsage.getMax();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class GarbageCollectorInfo
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     private final long collectionCount;
/*     */ 
/*     */ 
/*     */     
/*     */     GarbageCollectorInfo(GarbageCollectorMXBean garbageCollectorMXBean) {
/* 258 */       this.name = garbageCollectorMXBean.getName();
/* 259 */       this.collectionCount = garbageCollectorMXBean.getCollectionCount();
/*     */     }
/*     */     
/*     */     public String getName() {
/* 263 */       return this.name;
/*     */     }
/*     */     
/*     */     public long getCollectionCount() {
/* 267 */       return this.collectionCount;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\ProcessInfo$MemoryInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */