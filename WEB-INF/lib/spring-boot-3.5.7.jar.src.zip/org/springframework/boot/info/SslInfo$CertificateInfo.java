/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.Date;
/*     */ import java.util.function.Function;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CertificateInfo
/*     */ {
/*     */   private final X509Certificate certificate;
/*     */   
/*     */   private CertificateInfo(Certificate certificate) {
/* 184 */     X509Certificate x509Certificate = (X509Certificate)certificate; this.certificate = (certificate instanceof X509Certificate) ? x509Certificate : null;
/*     */   }
/*     */   
/*     */   public String getSubject() {
/* 188 */     return extract(X509Certificate::getSubjectX500Principal, X500Principal::getName);
/*     */   }
/*     */   
/*     */   public String getIssuer() {
/* 192 */     return extract(X509Certificate::getIssuerX500Principal, X500Principal::getName);
/*     */   }
/*     */   
/*     */   public String getSerialNumber() {
/* 196 */     return extract(X509Certificate::getSerialNumber, serial -> serial.toString(16));
/*     */   }
/*     */   
/*     */   public String getVersion() {
/* 200 */     return extract(certificate -> "V" + certificate.getVersion());
/*     */   }
/*     */   
/*     */   public String getSignatureAlgorithmName() {
/* 204 */     return extract(X509Certificate::getSigAlgName);
/*     */   }
/*     */   
/*     */   public Instant getValidityStarts() {
/* 208 */     return extract(X509Certificate::getNotBefore, Date::toInstant);
/*     */   }
/*     */   
/*     */   public Instant getValidityEnds() {
/* 212 */     return extract(X509Certificate::getNotAfter, Date::toInstant);
/*     */   }
/*     */   
/*     */   public SslInfo.CertificateValidityInfo getValidity() {
/* 216 */     return extract(certificate -> {
/*     */           Instant starts = getValidityStarts(); Instant ends = getValidityEnds();
/*     */           Duration threshold = SslInfo.this.certificateValidityWarningThreshold;
/*     */           SslInfo.CertificateValidityInfo.Status validity = checkValidity(starts, ends, threshold);
/*     */           switch (SslInfo.null.$SwitchMap$org$springframework$boot$info$SslInfo$CertificateValidityInfo$Status[validity.ordinal()]) {
/*     */             default:
/*     */               throw new IncompatibleClassChangeError();
/*     */             case 1:
/*     */             
/*     */             case 2:
/*     */             
/*     */             case 3:
/*     */             
/*     */             case 4:
/*     */               break;
/*     */           } 
/*     */           return new SslInfo.CertificateValidityInfo(SslInfo.CertificateValidityInfo.Status.WILL_EXPIRE_SOON, "Certificate will expire within threshold (%s) at %s", new Object[] { threshold, ends });
/* 233 */         }); } private SslInfo.CertificateValidityInfo.Status checkValidity(Instant starts, Instant ends, Duration threshold) { Instant now = SslInfo.this.clock.instant();
/* 234 */     if (now.isBefore(starts)) {
/* 235 */       return SslInfo.CertificateValidityInfo.Status.NOT_YET_VALID;
/*     */     }
/* 237 */     if (now.isAfter(ends)) {
/* 238 */       return SslInfo.CertificateValidityInfo.Status.EXPIRED;
/*     */     }
/* 240 */     Instant shouldBeValidAt = now.plus(threshold);
/* 241 */     if (shouldBeValidAt.isAfter(ends)) {
/* 242 */       return SslInfo.CertificateValidityInfo.Status.WILL_EXPIRE_SOON;
/*     */     }
/* 244 */     return SslInfo.CertificateValidityInfo.Status.VALID; }
/*     */ 
/*     */   
/*     */   private <V, R> R extract(Function<X509Certificate, V> valueExtractor, Function<V, R> resultExtractor) {
/* 248 */     return extract(valueExtractor.andThen(resultExtractor));
/*     */   }
/*     */   
/*     */   private <R> R extract(Function<X509Certificate, R> extractor) {
/* 252 */     return (this.certificate != null) ? extractor.apply(this.certificate) : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\info\SslInfo$CertificateInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */