/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.GeneratedClass;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EnvironmentAotContribution
/*     */   implements BeanFactoryInitializationAotContribution
/*     */ {
/*     */   private static final String ENVIRONMENT_VARIABLE = "environment";
/*     */   private final String[] activeProfiles;
/*     */   
/*     */   private EnvironmentAotContribution(String[] activeProfiles) {
/* 218 */     this.activeProfiles = activeProfiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 225 */     GeneratedClass generatedClass = generationContext.getGeneratedClasses().addForFeature("EnvironmentPostProcessor", type -> {
/*     */           type.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */           type.addJavadoc("Configure the environment with AOT optimizations.", new Object[0]);
/*     */           type.addSuperinterface(EnvironmentPostProcessor.class);
/*     */         });
/* 230 */     generatedClass.getMethods().add("postProcessEnvironment", method -> {
/*     */           method.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */           method.addAnnotation(Override.class);
/*     */           method.addParameter(ConfigurableEnvironment.class, "environment", new Modifier[0]);
/*     */           method.addParameter(SpringApplication.class, "application", new Modifier[0]);
/*     */           method.addCode(generateActiveProfilesInitializeCode());
/*     */         });
/*     */   }
/*     */   
/*     */   private CodeBlock generateActiveProfilesInitializeCode() {
/* 240 */     CodeBlock.Builder code = CodeBlock.builder();
/* 241 */     for (String activeProfile : this.activeProfiles) {
/* 242 */       code.addStatement("$L.addActiveProfile($S)", new Object[] { "environment", activeProfile });
/*     */     } 
/* 244 */     return code.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\EnvironmentPostProcessorApplicationListener$EnvironmentAotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */