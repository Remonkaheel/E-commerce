/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginTrackedValue;
/*     */ import org.springframework.boot.origin.TextResourceOrigin;
/*     */ import org.yaml.snakeyaml.LoaderOptions;
/*     */ import org.yaml.snakeyaml.constructor.SafeConstructor;
/*     */ import org.yaml.snakeyaml.error.Mark;
/*     */ import org.yaml.snakeyaml.nodes.MappingNode;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.NodeTuple;
/*     */ import org.yaml.snakeyaml.nodes.SequenceNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OriginTrackingConstructor
/*     */   extends SafeConstructor
/*     */ {
/*     */   OriginTrackingConstructor(LoaderOptions loadingConfig) {
/*  94 */     super(loadingConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getData() throws NoSuchElementException {
/*  99 */     Object data = super.getData();
/* 100 */     if (data instanceof CharSequence) { CharSequence charSequence = (CharSequence)data; if (charSequence.isEmpty())
/* 101 */         return null;  }
/*     */     
/* 103 */     return data;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object constructObject(Node node) {
/* 108 */     if (node instanceof SequenceNode) { SequenceNode sequenceNode = (SequenceNode)node; if (sequenceNode.getValue().isEmpty())
/* 109 */         return constructTrackedObject(node, "");  }
/*     */     
/* 111 */     if (node instanceof org.yaml.snakeyaml.nodes.ScalarNode && 
/* 112 */       !(node instanceof OriginTrackedYamlLoader.KeyScalarNode)) {
/* 113 */       return constructTrackedObject(node, super.constructObject(node));
/*     */     }
/*     */     
/* 116 */     if (node instanceof MappingNode) { MappingNode mappingNode = (MappingNode)node;
/* 117 */       replaceMappingNodeKeys(mappingNode); }
/*     */     
/* 119 */     return super.constructObject(node);
/*     */   }
/*     */   
/*     */   private void replaceMappingNodeKeys(MappingNode node) {
/* 123 */     List<NodeTuple> value = node.getValue();
/* 124 */     List<NodeTuple> newValue = new ArrayList<>(value.size());
/* 125 */     for (NodeTuple tuple : value) {
/* 126 */       newValue.add(OriginTrackedYamlLoader.KeyScalarNode.get(tuple));
/*     */     }
/* 128 */     node.setValue(newValue);
/*     */   }
/*     */   
/*     */   private Object constructTrackedObject(Node node, Object value) {
/* 132 */     Origin origin = getOrigin(node);
/* 133 */     return OriginTrackedValue.of(getValue(value), origin);
/*     */   }
/*     */   
/*     */   private Object getValue(Object value) {
/* 137 */     return (value != null) ? value : "";
/*     */   }
/*     */   
/*     */   private Origin getOrigin(Node node) {
/* 141 */     Mark mark = node.getStartMark();
/* 142 */     TextResourceOrigin.Location location = new TextResourceOrigin.Location(mark.getLine(), mark.getColumn());
/* 143 */     return (Origin)new TextResourceOrigin(OriginTrackedYamlLoader.this.resource, location);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\OriginTrackedYamlLoader$OriginTrackingConstructor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */