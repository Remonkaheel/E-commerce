/*    */ package org.springframework.boot.env;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.boot.logging.DeferredLogFactory;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RandomValuePropertySourceEnvironmentPostProcessor
/*    */   implements EnvironmentPostProcessor, Ordered
/*    */ {
/*    */   public static final int ORDER = -2147483647;
/*    */   private final Log logger;
/*    */   
/*    */   public RandomValuePropertySourceEnvironmentPostProcessor(DeferredLogFactory logFactory) {
/* 47 */     this.logger = logFactory.getLog(RandomValuePropertySourceEnvironmentPostProcessor.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 52 */     return -2147483647;
/*    */   }
/*    */ 
/*    */   
/*    */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
/* 57 */     RandomValuePropertySource.addToEnvironment(environment, this.logger);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\RandomValuePropertySourceEnvironmentPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */