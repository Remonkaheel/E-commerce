/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.beans.factory.config.YamlProcessor;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginTrackedValue;
/*     */ import org.springframework.boot.origin.TextResourceOrigin;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.yaml.snakeyaml.DumperOptions;
/*     */ import org.yaml.snakeyaml.LoaderOptions;
/*     */ import org.yaml.snakeyaml.Yaml;
/*     */ import org.yaml.snakeyaml.constructor.BaseConstructor;
/*     */ import org.yaml.snakeyaml.constructor.SafeConstructor;
/*     */ import org.yaml.snakeyaml.error.Mark;
/*     */ import org.yaml.snakeyaml.nodes.MappingNode;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.NodeTuple;
/*     */ import org.yaml.snakeyaml.nodes.ScalarNode;
/*     */ import org.yaml.snakeyaml.nodes.SequenceNode;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ import org.yaml.snakeyaml.representer.Representer;
/*     */ import org.yaml.snakeyaml.resolver.Resolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OriginTrackedYamlLoader
/*     */   extends YamlProcessor
/*     */ {
/*     */   private final Resource resource;
/*     */   
/*     */   OriginTrackedYamlLoader(Resource resource) {
/*  60 */     this.resource = resource;
/*  61 */     setResources(new Resource[] { resource });
/*     */   }
/*     */ 
/*     */   
/*     */   protected Yaml createYaml() {
/*  66 */     LoaderOptions loaderOptions = new LoaderOptions();
/*  67 */     loaderOptions.setAllowDuplicateKeys(false);
/*  68 */     loaderOptions.setMaxAliasesForCollections(2147483647);
/*  69 */     loaderOptions.setAllowRecursiveKeys(true);
/*  70 */     loaderOptions.setCodePointLimit(2147483647);
/*  71 */     return createYaml(loaderOptions);
/*     */   }
/*     */   
/*     */   private Yaml createYaml(LoaderOptions loaderOptions) {
/*  75 */     OriginTrackingConstructor originTrackingConstructor = new OriginTrackingConstructor(loaderOptions);
/*  76 */     DumperOptions dumperOptions = new DumperOptions();
/*  77 */     Representer representer = new Representer(dumperOptions);
/*  78 */     NoTimestampResolver resolver = new NoTimestampResolver();
/*  79 */     return new Yaml((BaseConstructor)originTrackingConstructor, representer, dumperOptions, loaderOptions, resolver);
/*     */   }
/*     */   
/*     */   List<Map<String, Object>> load() {
/*  83 */     List<Map<String, Object>> result = new ArrayList<>();
/*  84 */     process((properties, map) -> result.add(getFlattenedMap(map)));
/*  85 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class OriginTrackingConstructor
/*     */     extends SafeConstructor
/*     */   {
/*     */     OriginTrackingConstructor(LoaderOptions loadingConfig) {
/*  94 */       super(loadingConfig);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getData() throws NoSuchElementException {
/*  99 */       Object data = super.getData();
/* 100 */       if (data instanceof CharSequence) { CharSequence charSequence = (CharSequence)data; if (charSequence.isEmpty())
/* 101 */           return null;  }
/*     */       
/* 103 */       return data;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object constructObject(Node node) {
/* 108 */       if (node instanceof SequenceNode) { SequenceNode sequenceNode = (SequenceNode)node; if (sequenceNode.getValue().isEmpty())
/* 109 */           return constructTrackedObject(node, "");  }
/*     */       
/* 111 */       if (node instanceof ScalarNode && 
/* 112 */         !(node instanceof OriginTrackedYamlLoader.KeyScalarNode)) {
/* 113 */         return constructTrackedObject(node, super.constructObject(node));
/*     */       }
/*     */       
/* 116 */       if (node instanceof MappingNode) { MappingNode mappingNode = (MappingNode)node;
/* 117 */         replaceMappingNodeKeys(mappingNode); }
/*     */       
/* 119 */       return super.constructObject(node);
/*     */     }
/*     */     
/*     */     private void replaceMappingNodeKeys(MappingNode node) {
/* 123 */       List<NodeTuple> value = node.getValue();
/* 124 */       List<NodeTuple> newValue = new ArrayList<>(value.size());
/* 125 */       for (NodeTuple tuple : value) {
/* 126 */         newValue.add(OriginTrackedYamlLoader.KeyScalarNode.get(tuple));
/*     */       }
/* 128 */       node.setValue(newValue);
/*     */     }
/*     */     
/*     */     private Object constructTrackedObject(Node node, Object value) {
/* 132 */       Origin origin = getOrigin(node);
/* 133 */       return OriginTrackedValue.of(getValue(value), origin);
/*     */     }
/*     */     
/*     */     private Object getValue(Object value) {
/* 137 */       return (value != null) ? value : "";
/*     */     }
/*     */     
/*     */     private Origin getOrigin(Node node) {
/* 141 */       Mark mark = node.getStartMark();
/* 142 */       TextResourceOrigin.Location location = new TextResourceOrigin.Location(mark.getLine(), mark.getColumn());
/* 143 */       return (Origin)new TextResourceOrigin(OriginTrackedYamlLoader.this.resource, location);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KeyScalarNode
/*     */     extends ScalarNode
/*     */   {
/*     */     KeyScalarNode(ScalarNode node) {
/* 154 */       super(node.getTag(), node.getValue(), node.getStartMark(), node.getEndMark(), node.getScalarStyle());
/*     */     }
/*     */     
/*     */     static NodeTuple get(NodeTuple nodeTuple) {
/* 158 */       Node keyNode = nodeTuple.getKeyNode();
/* 159 */       Node valueNode = nodeTuple.getValueNode();
/* 160 */       return new NodeTuple(get(keyNode), valueNode);
/*     */     }
/*     */     
/*     */     private static Node get(Node node) {
/* 164 */       if (node instanceof ScalarNode) { ScalarNode scalarNode = (ScalarNode)node;
/* 165 */         return (Node)new KeyScalarNode(scalarNode); }
/*     */       
/* 167 */       return node;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class NoTimestampResolver
/*     */     extends Resolver
/*     */   {
/*     */     public void addImplicitResolver(Tag tag, Pattern regexp, String first, int limit) {
/* 179 */       if (tag == Tag.TIMESTAMP) {
/*     */         return;
/*     */       }
/* 182 */       super.addImplicitResolver(tag, regexp, first, limit);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\OriginTrackedYamlLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */