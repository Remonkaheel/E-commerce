/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginProvider;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PropertyFileContent
/*     */   implements ConfigTreePropertySource.Value, OriginProvider
/*     */ {
/*     */   private final Path path;
/* 266 */   private final Lock resourceLock = new ReentrantLock();
/*     */   
/*     */   private final Resource resource;
/*     */   
/*     */   private final Origin origin;
/*     */   
/*     */   private final boolean cacheContent;
/*     */   
/*     */   private final boolean autoTrimTrailingNewLine;
/*     */   
/*     */   private volatile byte[] content;
/*     */ 
/*     */   
/*     */   private PropertyFileContent(Path path, Resource resource, Origin origin, boolean cacheContent, boolean autoTrimTrailingNewLine) {
/* 280 */     this.path = path;
/* 281 */     this.resource = resource;
/* 282 */     this.origin = origin;
/* 283 */     this.cacheContent = cacheContent;
/* 284 */     this.autoTrimTrailingNewLine = autoTrimTrailingNewLine;
/*     */   }
/*     */ 
/*     */   
/*     */   public Origin getOrigin() {
/* 289 */     return this.origin;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/* 294 */     return toString().length();
/*     */   }
/*     */ 
/*     */   
/*     */   public char charAt(int index) {
/* 299 */     return toString().charAt(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence subSequence(int start, int end) {
/* 304 */     return toString().subSequence(start, end);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 309 */     String string = new String(getBytes());
/* 310 */     if (this.autoTrimTrailingNewLine) {
/* 311 */       string = autoTrimTrailingNewLine(string);
/*     */     }
/* 313 */     return string;
/*     */   }
/*     */   
/*     */   private String autoTrimTrailingNewLine(String string) {
/* 317 */     if (!string.endsWith("\n")) {
/* 318 */       return string;
/*     */     }
/* 320 */     int numberOfLines = 0;
/* 321 */     for (int i = 0; i < string.length(); i++) {
/* 322 */       char ch = string.charAt(i);
/* 323 */       if (ch == '\n') {
/* 324 */         numberOfLines++;
/*     */       }
/*     */     } 
/* 327 */     if (numberOfLines > 1) {
/* 328 */       return string;
/*     */     }
/* 330 */     return string.endsWith("\r\n") ? string.substring(0, string.length() - 2) : 
/* 331 */       string.substring(0, string.length() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 336 */     if (!this.cacheContent) {
/* 337 */       assertStillExists();
/* 338 */       return this.resource.getInputStream();
/*     */     } 
/* 340 */     return new ByteArrayInputStream(getBytes());
/*     */   }
/*     */   
/*     */   private byte[] getBytes() {
/*     */     try {
/* 345 */       if (!this.cacheContent) {
/* 346 */         assertStillExists();
/* 347 */         return FileCopyUtils.copyToByteArray(this.resource.getInputStream());
/*     */       } 
/* 349 */       if (this.content == null) {
/* 350 */         assertStillExists();
/* 351 */         this.resourceLock.lock();
/*     */         try {
/* 353 */           if (this.content == null) {
/* 354 */             this.content = FileCopyUtils.copyToByteArray(this.resource.getInputStream());
/*     */           }
/*     */         } finally {
/*     */           
/* 358 */           this.resourceLock.unlock();
/*     */         } 
/*     */       } 
/* 361 */       return this.content;
/*     */     }
/* 363 */     catch (IOException ex) {
/* 364 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void assertStillExists() {
/* 369 */     Assert.state(Files.exists(this.path, new java.nio.file.LinkOption[0]), () -> "The property file '" + String.valueOf(this.path) + "' no longer exists");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\ConfigTreePropertySource$PropertyFileContent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */