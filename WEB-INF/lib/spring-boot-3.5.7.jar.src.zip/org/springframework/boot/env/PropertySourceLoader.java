package org.springframework.boot.env;

import java.io.IOException;
import java.util.List;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;

public interface PropertySourceLoader {
  String[] getFileExtensions();
  
  List<PropertySource<?>> load(String paramString, Resource paramResource) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\PropertySourceLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */