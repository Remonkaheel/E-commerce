/*    */ package org.springframework.boot.env;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.boot.BootstrapContext;
/*    */ import org.springframework.boot.BootstrapRegistry;
/*    */ import org.springframework.boot.ConfigurableBootstrapContext;
/*    */ import org.springframework.boot.logging.DeferredLogFactory;
/*    */ import org.springframework.boot.util.Instantiator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReflectionEnvironmentPostProcessorsFactory
/*    */   implements EnvironmentPostProcessorsFactory
/*    */ {
/*    */   private final List<Class<?>> classes;
/*    */   private ClassLoader classLoader;
/*    */   private final List<String> classNames;
/*    */   
/*    */   ReflectionEnvironmentPostProcessorsFactory(Class<?>... classes) {
/* 46 */     this.classes = new ArrayList<>(Arrays.asList(classes));
/* 47 */     this.classNames = null;
/*    */   }
/*    */   
/*    */   ReflectionEnvironmentPostProcessorsFactory(ClassLoader classLoader, String... classNames) {
/* 51 */     this(classLoader, Arrays.asList(classNames));
/*    */   }
/*    */   
/*    */   ReflectionEnvironmentPostProcessorsFactory(ClassLoader classLoader, List<String> classNames) {
/* 55 */     this.classes = null;
/* 56 */     this.classLoader = classLoader;
/* 57 */     this.classNames = classNames;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<EnvironmentPostProcessor> getEnvironmentPostProcessors(DeferredLogFactory logFactory, ConfigurableBootstrapContext bootstrapContext) {
/* 63 */     Instantiator<EnvironmentPostProcessor> instantiator = new Instantiator(EnvironmentPostProcessor.class, parameters -> {
/*    */           parameters.add(DeferredLogFactory.class, logFactory);
/*    */           Objects.requireNonNull(logFactory);
/*    */           parameters.add(Log.class, logFactory::getLog);
/*    */           parameters.add(ConfigurableBootstrapContext.class, bootstrapContext);
/*    */           parameters.add(BootstrapContext.class, bootstrapContext);
/*    */           parameters.add(BootstrapRegistry.class, bootstrapContext);
/*    */         });
/* 71 */     return (this.classes != null) ? instantiator.instantiateTypes(this.classes) : 
/* 72 */       instantiator.instantiate(this.classLoader, this.classNames);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\ReflectionEnvironmentPostProcessorsFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */