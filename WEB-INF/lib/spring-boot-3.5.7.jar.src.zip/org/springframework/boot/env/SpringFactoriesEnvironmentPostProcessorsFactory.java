/*    */ package org.springframework.boot.env;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.boot.BootstrapContext;
/*    */ import org.springframework.boot.BootstrapRegistry;
/*    */ import org.springframework.boot.ConfigurableBootstrapContext;
/*    */ import org.springframework.boot.logging.DeferredLogFactory;
/*    */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpringFactoriesEnvironmentPostProcessorsFactory
/*    */   implements EnvironmentPostProcessorsFactory
/*    */ {
/*    */   private final SpringFactoriesLoader loader;
/*    */   
/*    */   SpringFactoriesEnvironmentPostProcessorsFactory(SpringFactoriesLoader loader) {
/* 38 */     this.loader = loader;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<EnvironmentPostProcessor> getEnvironmentPostProcessors(DeferredLogFactory logFactory, ConfigurableBootstrapContext bootstrapContext) {
/* 44 */     SpringFactoriesLoader.ArgumentResolver argumentResolver = SpringFactoriesLoader.ArgumentResolver.of(DeferredLogFactory.class, logFactory);
/* 45 */     argumentResolver = argumentResolver.and(ConfigurableBootstrapContext.class, bootstrapContext);
/* 46 */     argumentResolver = argumentResolver.and(BootstrapContext.class, bootstrapContext);
/* 47 */     argumentResolver = argumentResolver.and(BootstrapRegistry.class, bootstrapContext);
/* 48 */     return this.loader.load(EnvironmentPostProcessor.class, argumentResolver);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\SpringFactoriesEnvironmentPostProcessorsFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */