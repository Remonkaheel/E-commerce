/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.LineNumberReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.springframework.boot.origin.TextResourceOrigin;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CharacterReader
/*     */   implements Closeable
/*     */ {
/* 191 */   private static final String[] ESCAPES = new String[] { "trnf", "\t\r\n\f" };
/*     */   
/*     */   private final LineNumberReader reader;
/*     */   
/* 195 */   private int columnNumber = -1;
/*     */   
/*     */   private boolean escaped;
/*     */   
/*     */   private int character;
/*     */   
/*     */   private int lastLineCommentPrefixCharacter;
/*     */   
/*     */   CharacterReader(Resource resource) throws IOException {
/* 204 */     this
/* 205 */       .reader = new LineNumberReader(new InputStreamReader(resource.getInputStream(), StandardCharsets.ISO_8859_1));
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 210 */     this.reader.close();
/*     */   }
/*     */   
/*     */   boolean read() throws IOException {
/* 214 */     this.escaped = false;
/* 215 */     this.character = this.reader.read();
/* 216 */     this.columnNumber++;
/* 217 */     if (this.columnNumber == 0) {
/* 218 */       skipWhitespace();
/*     */     }
/* 220 */     if (this.character == 92) {
/* 221 */       this.escaped = true;
/* 222 */       readEscaped();
/*     */     }
/* 224 */     else if (this.character == 10) {
/* 225 */       this.columnNumber = -1;
/*     */     } 
/* 227 */     return !isEndOfFile();
/*     */   }
/*     */   
/*     */   private void skipWhitespace() throws IOException {
/* 231 */     while (isWhiteSpace()) {
/* 232 */       this.character = this.reader.read();
/* 233 */       this.columnNumber++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setLastLineCommentPrefixCharacter(int lastLineCommentPrefixCharacter) {
/* 238 */     this.lastLineCommentPrefixCharacter = lastLineCommentPrefixCharacter;
/*     */   }
/*     */   
/*     */   private void skipComment() throws IOException {
/* 242 */     while (this.character != 10 && this.character != -1) {
/* 243 */       this.character = this.reader.read();
/*     */     }
/* 245 */     this.columnNumber = -1;
/*     */   }
/*     */   
/*     */   private void readEscaped() throws IOException {
/* 249 */     this.character = this.reader.read();
/* 250 */     int escapeIndex = ESCAPES[0].indexOf(this.character);
/* 251 */     if (escapeIndex != -1) {
/* 252 */       this.character = ESCAPES[1].charAt(escapeIndex);
/*     */     }
/* 254 */     else if (this.character == 10) {
/* 255 */       this.columnNumber = -1;
/* 256 */       read();
/*     */     }
/* 258 */     else if (this.character == 117) {
/* 259 */       readUnicode();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readUnicode() throws IOException {
/* 264 */     this.character = 0;
/* 265 */     for (int i = 0; i < 4; i++) {
/* 266 */       int digit = this.reader.read();
/* 267 */       if (digit >= 48 && digit <= 57) {
/* 268 */         this.character = (this.character << 4) + digit - 48;
/*     */       }
/* 270 */       else if (digit >= 97 && digit <= 102) {
/* 271 */         this.character = (this.character << 4) + digit - 97 + 10;
/*     */       }
/* 273 */       else if (digit >= 65 && digit <= 70) {
/* 274 */         this.character = (this.character << 4) + digit - 65 + 10;
/*     */       } else {
/*     */         
/* 277 */         throw new IllegalStateException("Malformed \\uxxxx encoding.");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isWhiteSpace() {
/* 283 */     return (!this.escaped && (this.character == 32 || this.character == 9 || this.character == 12));
/*     */   }
/*     */   
/*     */   boolean isEndOfFile() {
/* 287 */     return (this.character == -1);
/*     */   }
/*     */   
/*     */   boolean isEndOfLine() {
/* 291 */     return (this.character == -1 || (!this.escaped && this.character == 10));
/*     */   }
/*     */   
/*     */   boolean isListDelimiter() {
/* 295 */     return (!this.escaped && this.character == 44);
/*     */   }
/*     */   
/*     */   boolean isPropertyDelimiter() {
/* 299 */     return (!this.escaped && (this.character == 61 || this.character == 58));
/*     */   }
/*     */   
/*     */   char getCharacter() {
/* 303 */     return (char)this.character;
/*     */   }
/*     */   
/*     */   TextResourceOrigin.Location getLocation() {
/* 307 */     return new TextResourceOrigin.Location(this.reader.getLineNumber(), this.columnNumber);
/*     */   }
/*     */   
/*     */   boolean isSameLastLineCommentPrefix() {
/* 311 */     return (this.lastLineCommentPrefixCharacter == this.character);
/*     */   }
/*     */   
/*     */   boolean isCommentPrefixCharacter() {
/* 315 */     return (this.character == 35 || this.character == 33);
/*     */   }
/*     */   
/*     */   boolean isHyphenCharacter() {
/* 319 */     return (this.character == 45);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\OriginTrackedPropertiesLoader$CharacterReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */