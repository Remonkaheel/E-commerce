/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.util.function.Function;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Range<T extends Number>
/*     */ {
/*     */   private final String value;
/*     */   private final T min;
/*     */   private final T max;
/*     */   
/*     */   private Range(String value, T min, T max) {
/* 175 */     this.value = value;
/* 176 */     this.min = min;
/* 177 */     this.max = max;
/*     */   }
/*     */   
/*     */   T getMin() {
/* 181 */     return this.min;
/*     */   }
/*     */   
/*     */   T getMax() {
/* 185 */     return this.max;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 190 */     return this.value;
/*     */   }
/*     */   
/*     */   static <T extends Number & Comparable<T>> Range<T> of(String value, Function<String, T> parse) {
/* 194 */     Number number1 = (Number)parse.apply("0");
/* 195 */     String[] tokens = StringUtils.commaDelimitedListToStringArray(value);
/* 196 */     Number number2 = (Number)parse.apply(tokens[0]);
/* 197 */     if (tokens.length == 1) {
/* 198 */       Assert.state((((Comparable<Number>)number2).compareTo(number1) > 0), "Bound must be positive.");
/* 199 */       return (Range)new Range<>(value, number1, number2);
/*     */     } 
/* 201 */     Number number3 = (Number)parse.apply(tokens[1]);
/* 202 */     Assert.state((((Comparable<Number>)number2).compareTo(number3) < 0), "Lower bound must be less than upper bound.");
/* 203 */     return (Range)new Range<>(value, number2, number3);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\RandomValuePropertySource$Range.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */