/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.AotDetector;
/*     */ import org.springframework.aot.generate.GeneratedClass;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotProcessor;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.ConfigurableBootstrapContext;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationFailedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationPreparedEvent;
/*     */ import org.springframework.boot.logging.DeferredLogFactory;
/*     */ import org.springframework.boot.logging.DeferredLogs;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.event.SmartApplicationListener;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnvironmentPostProcessorApplicationListener
/*     */   implements SmartApplicationListener, Ordered
/*     */ {
/*     */   private static final String AOT_FEATURE_NAME = "EnvironmentPostProcessor";
/*     */   public static final int DEFAULT_ORDER = -2147483638;
/*     */   private final DeferredLogs deferredLogs;
/*  71 */   private int order = -2147483638;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Function<ClassLoader, EnvironmentPostProcessorsFactory> postProcessorsFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   public EnvironmentPostProcessorApplicationListener() {
/*  80 */     this(EnvironmentPostProcessorsFactory::fromSpringFactories);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EnvironmentPostProcessorApplicationListener(Function<ClassLoader, EnvironmentPostProcessorsFactory> postProcessorsFactory) {
/*  90 */     this.postProcessorsFactory = postProcessorsFactory;
/*  91 */     this.deferredLogs = new DeferredLogs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnvironmentPostProcessorApplicationListener with(EnvironmentPostProcessorsFactory postProcessorsFactory) {
/* 102 */     return new EnvironmentPostProcessorApplicationListener(classloader -> postProcessorsFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsEventType(Class<? extends ApplicationEvent> eventType) {
/* 107 */     return (ApplicationEnvironmentPreparedEvent.class.isAssignableFrom(eventType) || ApplicationPreparedEvent.class
/* 108 */       .isAssignableFrom(eventType) || ApplicationFailedEvent.class
/* 109 */       .isAssignableFrom(eventType));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event) {
/* 114 */     if (event instanceof ApplicationEnvironmentPreparedEvent) { ApplicationEnvironmentPreparedEvent environmentPreparedEvent = (ApplicationEnvironmentPreparedEvent)event;
/* 115 */       onApplicationEnvironmentPreparedEvent(environmentPreparedEvent); }
/*     */     
/* 117 */     if (event instanceof ApplicationPreparedEvent) {
/* 118 */       onApplicationPreparedEvent();
/*     */     }
/* 120 */     if (event instanceof ApplicationFailedEvent) {
/* 121 */       onApplicationFailedEvent();
/*     */     }
/*     */   }
/*     */   
/*     */   private void onApplicationEnvironmentPreparedEvent(ApplicationEnvironmentPreparedEvent event) {
/* 126 */     ConfigurableEnvironment environment = event.getEnvironment();
/* 127 */     SpringApplication application = event.getSpringApplication();
/* 128 */     List<EnvironmentPostProcessor> postProcessors = getEnvironmentPostProcessors(application.getResourceLoader(), event
/* 129 */         .getBootstrapContext());
/* 130 */     addAotGeneratedEnvironmentPostProcessorIfNecessary(postProcessors, application);
/* 131 */     for (EnvironmentPostProcessor postProcessor : postProcessors) {
/* 132 */       postProcessor.postProcessEnvironment(environment, application);
/*     */     }
/*     */   }
/*     */   
/*     */   private void onApplicationPreparedEvent() {
/* 137 */     finish();
/*     */   }
/*     */   
/*     */   private void onApplicationFailedEvent() {
/* 141 */     finish();
/*     */   }
/*     */   
/*     */   private void finish() {
/* 145 */     this.deferredLogs.switchOverAll();
/*     */   }
/*     */ 
/*     */   
/*     */   List<EnvironmentPostProcessor> getEnvironmentPostProcessors(ResourceLoader resourceLoader, ConfigurableBootstrapContext bootstrapContext) {
/* 150 */     ClassLoader classLoader = (resourceLoader != null) ? resourceLoader.getClassLoader() : null;
/* 151 */     EnvironmentPostProcessorsFactory postProcessorsFactory = this.postProcessorsFactory.apply(classLoader);
/* 152 */     return postProcessorsFactory.getEnvironmentPostProcessors((DeferredLogFactory)this.deferredLogs, bootstrapContext);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addAotGeneratedEnvironmentPostProcessorIfNecessary(List<EnvironmentPostProcessor> postProcessors, SpringApplication springApplication) {
/* 157 */     if (AotDetector.useGeneratedArtifacts()) {
/*     */       
/* 159 */       ClassLoader classLoader = (springApplication.getResourceLoader() != null) ? springApplication.getResourceLoader().getClassLoader() : null;
/* 160 */       String postProcessorClassName = springApplication.getMainApplicationClass().getName() + "__EnvironmentPostProcessor";
/*     */       
/* 162 */       if (ClassUtils.isPresent(postProcessorClassName, classLoader)) {
/* 163 */         postProcessors.add(0, instantiateEnvironmentPostProcessor(postProcessorClassName, classLoader));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private EnvironmentPostProcessor instantiateEnvironmentPostProcessor(String postProcessorClassName, ClassLoader classLoader) {
/*     */     try {
/* 171 */       Class<?> initializerClass = ClassUtils.resolveClassName(postProcessorClassName, classLoader);
/* 172 */       Assert.isAssignable(EnvironmentPostProcessor.class, initializerClass);
/* 173 */       return (EnvironmentPostProcessor)BeanUtils.instantiateClass(initializerClass);
/*     */     }
/* 175 */     catch (BeanInstantiationException ex) {
/* 176 */       throw new IllegalArgumentException("Failed to instantiate EnvironmentPostProcessor: " + postProcessorClassName, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 183 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 187 */     this.order = order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class EnvironmentBeanFactoryInitializationAotProcessor
/*     */     implements BeanFactoryInitializationAotProcessor
/*     */   {
/*     */     public BeanFactoryInitializationAotContribution processAheadOfTime(ConfigurableListableBeanFactory beanFactory) {
/* 199 */       Environment environment = (Environment)beanFactory.getBean("environment", Environment.class);
/*     */       
/* 201 */       String[] activeProfiles = environment.getActiveProfiles();
/* 202 */       String[] defaultProfiles = environment.getDefaultProfiles();
/* 203 */       if (!ObjectUtils.isEmpty((Object[])activeProfiles) && !Arrays.equals((Object[])activeProfiles, (Object[])defaultProfiles)) {
/* 204 */         return new EnvironmentPostProcessorApplicationListener.EnvironmentAotContribution(activeProfiles);
/*     */       }
/* 206 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class EnvironmentAotContribution
/*     */     implements BeanFactoryInitializationAotContribution
/*     */   {
/*     */     private static final String ENVIRONMENT_VARIABLE = "environment";
/*     */     private final String[] activeProfiles;
/*     */     
/*     */     private EnvironmentAotContribution(String[] activeProfiles) {
/* 218 */       this.activeProfiles = activeProfiles;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 225 */       GeneratedClass generatedClass = generationContext.getGeneratedClasses().addForFeature("EnvironmentPostProcessor", type -> {
/*     */             type.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */             type.addJavadoc("Configure the environment with AOT optimizations.", new Object[0]);
/*     */             type.addSuperinterface(EnvironmentPostProcessor.class);
/*     */           });
/* 230 */       generatedClass.getMethods().add("postProcessEnvironment", method -> {
/*     */             method.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */             method.addAnnotation(Override.class);
/*     */             method.addParameter(ConfigurableEnvironment.class, "environment", new Modifier[0]);
/*     */             method.addParameter(SpringApplication.class, "application", new Modifier[0]);
/*     */             method.addCode(generateActiveProfilesInitializeCode());
/*     */           });
/*     */     }
/*     */     
/*     */     private CodeBlock generateActiveProfilesInitializeCode() {
/* 240 */       CodeBlock.Builder code = CodeBlock.builder();
/* 241 */       for (String activeProfile : this.activeProfiles) {
/* 242 */         code.addStatement("$L.addActiveProfile($S)", new Object[] { "environment", activeProfile });
/*     */       } 
/* 244 */       return code.build();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\EnvironmentPostProcessorApplicationListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */