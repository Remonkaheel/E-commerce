/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.file.FileVisitOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.boot.origin.OriginProvider;
/*     */ import org.springframework.boot.origin.TextResourceOrigin;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.io.FileSystemResource;
/*     */ import org.springframework.core.io.InputStreamSource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigTreePropertySource
/*     */   extends EnumerablePropertySource<Path>
/*     */   implements OriginLookup<String>
/*     */ {
/*     */   private static final int MAX_DEPTH = 100;
/*     */   private final Map<String, PropertyFile> propertyFiles;
/*     */   private final String[] names;
/*     */   private final Set<Option> options;
/*     */   
/*     */   public ConfigTreePropertySource(String name, Path sourceDirectory) {
/*  93 */     this(name, sourceDirectory, EnumSet.noneOf(Option.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigTreePropertySource(String name, Path sourceDirectory, Option... options) {
/* 103 */     this(name, sourceDirectory, EnumSet.copyOf(Arrays.asList(options)));
/*     */   }
/*     */   
/*     */   private ConfigTreePropertySource(String name, Path sourceDirectory, Set<Option> options) {
/* 107 */     super(name, sourceDirectory);
/* 108 */     Assert.isTrue(Files.exists(sourceDirectory, new java.nio.file.LinkOption[0]), () -> "'sourceDirectory' [%s] must exist".formatted(new Object[] { sourceDirectory }));
/*     */     
/* 110 */     Assert.isTrue(Files.isDirectory(sourceDirectory, new java.nio.file.LinkOption[0]), () -> "'sourceDirectory' [%s] must be a directory".formatted(new Object[] { sourceDirectory }));
/*     */     
/* 112 */     this.propertyFiles = PropertyFile.findAll(sourceDirectory, options);
/* 113 */     this.options = options;
/* 114 */     this.names = StringUtils.toStringArray(this.propertyFiles.keySet());
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getPropertyNames() {
/* 119 */     return (String[])this.names.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public Value getProperty(String name) {
/* 124 */     PropertyFile propertyFile = this.propertyFiles.get(name);
/* 125 */     return (propertyFile != null) ? propertyFile.getContent() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Origin getOrigin(String name) {
/* 130 */     PropertyFile propertyFile = this.propertyFiles.get(name);
/* 131 */     return (propertyFile != null) ? propertyFile.getOrigin() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isImmutable() {
/* 136 */     return !this.options.contains(Option.ALWAYS_READ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Option
/*     */   {
/* 149 */     ALWAYS_READ,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     USE_LOWERCASE_NAMES,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     AUTO_TRIM_TRAILING_NEW_LINE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class PropertyFile
/*     */   {
/* 177 */     private static final TextResourceOrigin.Location START_OF_FILE = new TextResourceOrigin.Location(0, 0);
/*     */     
/*     */     private final Path path;
/*     */     
/*     */     private final FileSystemResource resource;
/*     */     
/*     */     private final Origin origin;
/*     */     
/*     */     private final ConfigTreePropertySource.PropertyFileContent cachedContent;
/*     */     
/*     */     private final boolean autoTrimTrailingNewLine;
/*     */     
/*     */     private PropertyFile(Path path, Set<ConfigTreePropertySource.Option> options) {
/* 190 */       this.path = path;
/* 191 */       this.resource = new FileSystemResource(path);
/* 192 */       this.origin = (Origin)new TextResourceOrigin((Resource)this.resource, START_OF_FILE);
/* 193 */       this.autoTrimTrailingNewLine = options.contains(ConfigTreePropertySource.Option.AUTO_TRIM_TRAILING_NEW_LINE);
/* 194 */       this
/* 195 */         .cachedContent = options.contains(ConfigTreePropertySource.Option.ALWAYS_READ) ? null : new ConfigTreePropertySource.PropertyFileContent(path, (Resource)this.resource, this.origin, true, this.autoTrimTrailingNewLine);
/*     */     }
/*     */     
/*     */     ConfigTreePropertySource.PropertyFileContent getContent() {
/* 199 */       if (this.cachedContent != null) {
/* 200 */         return this.cachedContent;
/*     */       }
/* 202 */       return new ConfigTreePropertySource.PropertyFileContent(this.path, (Resource)this.resource, this.origin, false, this.autoTrimTrailingNewLine);
/*     */     }
/*     */     
/*     */     Origin getOrigin() {
/* 206 */       return this.origin;
/*     */     }
/*     */     
/*     */     static Map<String, PropertyFile> findAll(Path sourceDirectory, Set<ConfigTreePropertySource.Option> options) {
/*     */       try {
/* 211 */         Map<String, PropertyFile> propertyFiles = new TreeMap<>();
/* 212 */         Stream<Path> pathStream = Files.find(sourceDirectory, 100, PropertyFile::isPropertyFile, new FileVisitOption[] { FileVisitOption.FOLLOW_LINKS });
/*     */         
/* 214 */         try { pathStream.forEach(path -> {
/*     */                 String name = getName(sourceDirectory.relativize(path));
/*     */                 if (StringUtils.hasText(name)) {
/*     */                   if (options.contains(ConfigTreePropertySource.Option.USE_LOWERCASE_NAMES)) {
/*     */                     name = name.toLowerCase(Locale.getDefault());
/*     */                   }
/*     */                   propertyFiles.put(name, new PropertyFile(path, options));
/*     */                 } 
/*     */               });
/* 223 */           if (pathStream != null) pathStream.close();  } catch (Throwable throwable) { if (pathStream != null)
/* 224 */             try { pathStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return Collections.unmodifiableMap(propertyFiles);
/*     */       }
/* 226 */       catch (IOException ex) {
/* 227 */         throw new IllegalStateException("Unable to find files in '" + String.valueOf(sourceDirectory) + "'", ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     private static boolean isPropertyFile(Path path, BasicFileAttributes attributes) {
/* 232 */       return (!hasHiddenPathElement(path) && (attributes.isRegularFile() || attributes.isSymbolicLink()));
/*     */     }
/*     */     
/*     */     private static boolean hasHiddenPathElement(Path path) {
/* 236 */       for (Path element : path) {
/* 237 */         if (element.toString().startsWith("..")) {
/* 238 */           return true;
/*     */         }
/*     */       } 
/* 241 */       return false;
/*     */     }
/*     */     
/*     */     private static String getName(Path relativePath) {
/* 245 */       int nameCount = relativePath.getNameCount();
/* 246 */       if (nameCount == 1) {
/* 247 */         return relativePath.toString();
/*     */       }
/* 249 */       StringBuilder name = new StringBuilder();
/* 250 */       for (int i = 0; i < nameCount; i++) {
/* 251 */         name.append((i != 0) ? "." : "");
/* 252 */         name.append(relativePath.getName(i));
/*     */       } 
/* 254 */       return name.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class PropertyFileContent
/*     */     implements Value, OriginProvider
/*     */   {
/*     */     private final Path path;
/*     */ 
/*     */     
/* 266 */     private final Lock resourceLock = new ReentrantLock();
/*     */     
/*     */     private final Resource resource;
/*     */     
/*     */     private final Origin origin;
/*     */     
/*     */     private final boolean cacheContent;
/*     */     
/*     */     private final boolean autoTrimTrailingNewLine;
/*     */     
/*     */     private volatile byte[] content;
/*     */ 
/*     */     
/*     */     private PropertyFileContent(Path path, Resource resource, Origin origin, boolean cacheContent, boolean autoTrimTrailingNewLine) {
/* 280 */       this.path = path;
/* 281 */       this.resource = resource;
/* 282 */       this.origin = origin;
/* 283 */       this.cacheContent = cacheContent;
/* 284 */       this.autoTrimTrailingNewLine = autoTrimTrailingNewLine;
/*     */     }
/*     */ 
/*     */     
/*     */     public Origin getOrigin() {
/* 289 */       return this.origin;
/*     */     }
/*     */ 
/*     */     
/*     */     public int length() {
/* 294 */       return toString().length();
/*     */     }
/*     */ 
/*     */     
/*     */     public char charAt(int index) {
/* 299 */       return toString().charAt(index);
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence subSequence(int start, int end) {
/* 304 */       return toString().subSequence(start, end);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 309 */       String string = new String(getBytes());
/* 310 */       if (this.autoTrimTrailingNewLine) {
/* 311 */         string = autoTrimTrailingNewLine(string);
/*     */       }
/* 313 */       return string;
/*     */     }
/*     */     
/*     */     private String autoTrimTrailingNewLine(String string) {
/* 317 */       if (!string.endsWith("\n")) {
/* 318 */         return string;
/*     */       }
/* 320 */       int numberOfLines = 0;
/* 321 */       for (int i = 0; i < string.length(); i++) {
/* 322 */         char ch = string.charAt(i);
/* 323 */         if (ch == '\n') {
/* 324 */           numberOfLines++;
/*     */         }
/*     */       } 
/* 327 */       if (numberOfLines > 1) {
/* 328 */         return string;
/*     */       }
/* 330 */       return string.endsWith("\r\n") ? string.substring(0, string.length() - 2) : 
/* 331 */         string.substring(0, string.length() - 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public InputStream getInputStream() throws IOException {
/* 336 */       if (!this.cacheContent) {
/* 337 */         assertStillExists();
/* 338 */         return this.resource.getInputStream();
/*     */       } 
/* 340 */       return new ByteArrayInputStream(getBytes());
/*     */     }
/*     */     
/*     */     private byte[] getBytes() {
/*     */       try {
/* 345 */         if (!this.cacheContent) {
/* 346 */           assertStillExists();
/* 347 */           return FileCopyUtils.copyToByteArray(this.resource.getInputStream());
/*     */         } 
/* 349 */         if (this.content == null) {
/* 350 */           assertStillExists();
/* 351 */           this.resourceLock.lock();
/*     */           try {
/* 353 */             if (this.content == null) {
/* 354 */               this.content = FileCopyUtils.copyToByteArray(this.resource.getInputStream());
/*     */             }
/*     */           } finally {
/*     */             
/* 358 */             this.resourceLock.unlock();
/*     */           } 
/*     */         } 
/* 361 */         return this.content;
/*     */       }
/* 363 */       catch (IOException ex) {
/* 364 */         throw new IllegalStateException(ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void assertStillExists() {
/* 369 */       Assert.state(Files.exists(this.path, new java.nio.file.LinkOption[0]), () -> "The property file '" + String.valueOf(this.path) + "' no longer exists");
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Value extends CharSequence, InputStreamSource {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\ConfigTreePropertySource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */