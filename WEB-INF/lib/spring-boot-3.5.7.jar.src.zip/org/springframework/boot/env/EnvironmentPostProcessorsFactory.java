/*    */ package org.springframework.boot.env;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.boot.ConfigurableBootstrapContext;
/*    */ import org.springframework.boot.logging.DeferredLogFactory;
/*    */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface EnvironmentPostProcessorsFactory
/*    */ {
/*    */   List<EnvironmentPostProcessor> getEnvironmentPostProcessors(DeferredLogFactory paramDeferredLogFactory, ConfigurableBootstrapContext paramConfigurableBootstrapContext);
/*    */   
/*    */   static EnvironmentPostProcessorsFactory fromSpringFactories(ClassLoader classLoader) {
/* 51 */     return new SpringFactoriesEnvironmentPostProcessorsFactory(
/* 52 */         SpringFactoriesLoader.forDefaultResourceLocation(classLoader));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static EnvironmentPostProcessorsFactory of(Class<?>... classes) {
/* 62 */     return new ReflectionEnvironmentPostProcessorsFactory(classes);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static EnvironmentPostProcessorsFactory of(String... classNames) {
/* 72 */     return of(null, classNames);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static EnvironmentPostProcessorsFactory of(ClassLoader classLoader, String... classNames) {
/* 84 */     return new ReflectionEnvironmentPostProcessorsFactory(classLoader, classNames);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\EnvironmentPostProcessorsFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */