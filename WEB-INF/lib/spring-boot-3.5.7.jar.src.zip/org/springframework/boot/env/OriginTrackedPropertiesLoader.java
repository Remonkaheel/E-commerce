/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.LineNumberReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginTrackedValue;
/*     */ import org.springframework.boot.origin.TextResourceOrigin;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OriginTrackedPropertiesLoader
/*     */ {
/*     */   private final Resource resource;
/*     */   
/*     */   OriginTrackedPropertiesLoader(Resource resource) {
/*  56 */     Assert.notNull(resource, "'resource' must not be null");
/*  57 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<Document> load() throws IOException {
/*  66 */     return load(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<Document> load(boolean expandLists) throws IOException {
/*  77 */     List<Document> documents = new ArrayList<>();
/*  78 */     Document document = new Document();
/*  79 */     StringBuilder buffer = new StringBuilder();
/*  80 */     CharacterReader reader = new CharacterReader(this.resource); 
/*  81 */     try { while (reader.read()) {
/*  82 */         if (reader.isCommentPrefixCharacter()) {
/*  83 */           char commentPrefixCharacter = reader.getCharacter();
/*  84 */           if (isNewDocument(reader)) {
/*  85 */             if (!document.isEmpty()) {
/*  86 */               documents.add(document);
/*     */             }
/*  88 */             document = new Document();
/*     */             continue;
/*     */           } 
/*  91 */           if (document.isEmpty() && !documents.isEmpty()) {
/*  92 */             document = documents.remove(documents.size() - 1);
/*     */           }
/*  94 */           reader.setLastLineCommentPrefixCharacter(commentPrefixCharacter);
/*  95 */           reader.skipComment();
/*     */           
/*     */           continue;
/*     */         } 
/*  99 */         reader.setLastLineCommentPrefixCharacter(-1);
/* 100 */         loadKeyAndValue(expandLists, document, reader, buffer);
/*     */       } 
/*     */ 
/*     */       
/* 104 */       reader.close(); } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 105 */      if (!document.isEmpty() && !documents.contains(document)) {
/* 106 */       documents.add(document);
/*     */     }
/* 108 */     return documents;
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadKeyAndValue(boolean expandLists, Document document, CharacterReader reader, StringBuilder buffer) throws IOException {
/* 113 */     String key = loadKey(buffer, reader).trim();
/* 114 */     if (expandLists && key.endsWith("[]")) {
/* 115 */       key = key.substring(0, key.length() - 2);
/* 116 */       int index = 0;
/*     */       do {
/* 118 */         OriginTrackedValue value = loadValue(buffer, reader, true);
/* 119 */         document.put(key + "[" + key + "]", value);
/* 120 */         if (reader.isEndOfLine())
/* 121 */           continue;  reader.read();
/*     */       
/*     */       }
/* 124 */       while (!reader.isEndOfLine());
/*     */     } else {
/*     */       
/* 127 */       OriginTrackedValue value = loadValue(buffer, reader, false);
/* 128 */       document.put(key, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String loadKey(StringBuilder buffer, CharacterReader reader) throws IOException {
/* 133 */     buffer.setLength(0);
/* 134 */     boolean previousWhitespace = false;
/* 135 */     while (!reader.isEndOfLine()) {
/* 136 */       if (reader.isPropertyDelimiter()) {
/* 137 */         reader.read();
/* 138 */         return buffer.toString();
/*     */       } 
/* 140 */       if (!reader.isWhiteSpace() && previousWhitespace) {
/* 141 */         return buffer.toString();
/*     */       }
/* 143 */       previousWhitespace = reader.isWhiteSpace();
/* 144 */       buffer.append(reader.getCharacter());
/* 145 */       reader.read();
/*     */     } 
/* 147 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private OriginTrackedValue loadValue(StringBuilder buffer, CharacterReader reader, boolean splitLists) throws IOException {
/* 152 */     buffer.setLength(0);
/* 153 */     while (reader.isWhiteSpace() && !reader.isEndOfLine()) {
/* 154 */       reader.read();
/*     */     }
/* 156 */     TextResourceOrigin.Location location = reader.getLocation();
/* 157 */     while (!reader.isEndOfLine() && (!splitLists || !reader.isListDelimiter())) {
/* 158 */       buffer.append(reader.getCharacter());
/* 159 */       reader.read();
/*     */     } 
/* 161 */     TextResourceOrigin textResourceOrigin = new TextResourceOrigin(this.resource, location);
/* 162 */     return OriginTrackedValue.of(buffer.toString(), (Origin)textResourceOrigin);
/*     */   }
/*     */   
/*     */   private boolean isNewDocument(CharacterReader reader) throws IOException {
/* 166 */     if (reader.isSameLastLineCommentPrefix()) {
/* 167 */       return false;
/*     */     }
/* 169 */     boolean result = (reader.getLocation().getColumn() == 0);
/* 170 */     Objects.requireNonNull(reader); result = (result && readAndExpect(reader, reader::isHyphenCharacter));
/* 171 */     Objects.requireNonNull(reader); result = (result && readAndExpect(reader, reader::isHyphenCharacter));
/* 172 */     Objects.requireNonNull(reader); result = (result && readAndExpect(reader, reader::isHyphenCharacter));
/* 173 */     if (!reader.isEndOfLine()) {
/* 174 */       reader.read();
/* 175 */       reader.skipWhitespace();
/*     */     } 
/* 177 */     return (result && reader.isEndOfLine());
/*     */   }
/*     */   
/*     */   private boolean readAndExpect(CharacterReader reader, BooleanSupplier check) throws IOException {
/* 181 */     reader.read();
/* 182 */     return check.getAsBoolean();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CharacterReader
/*     */     implements Closeable
/*     */   {
/* 191 */     private static final String[] ESCAPES = new String[] { "trnf", "\t\r\n\f" };
/*     */     
/*     */     private final LineNumberReader reader;
/*     */     
/* 195 */     private int columnNumber = -1;
/*     */     
/*     */     private boolean escaped;
/*     */     
/*     */     private int character;
/*     */     
/*     */     private int lastLineCommentPrefixCharacter;
/*     */     
/*     */     CharacterReader(Resource resource) throws IOException {
/* 204 */       this
/* 205 */         .reader = new LineNumberReader(new InputStreamReader(resource.getInputStream(), StandardCharsets.ISO_8859_1));
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 210 */       this.reader.close();
/*     */     }
/*     */     
/*     */     boolean read() throws IOException {
/* 214 */       this.escaped = false;
/* 215 */       this.character = this.reader.read();
/* 216 */       this.columnNumber++;
/* 217 */       if (this.columnNumber == 0) {
/* 218 */         skipWhitespace();
/*     */       }
/* 220 */       if (this.character == 92) {
/* 221 */         this.escaped = true;
/* 222 */         readEscaped();
/*     */       }
/* 224 */       else if (this.character == 10) {
/* 225 */         this.columnNumber = -1;
/*     */       } 
/* 227 */       return !isEndOfFile();
/*     */     }
/*     */     
/*     */     private void skipWhitespace() throws IOException {
/* 231 */       while (isWhiteSpace()) {
/* 232 */         this.character = this.reader.read();
/* 233 */         this.columnNumber++;
/*     */       } 
/*     */     }
/*     */     
/*     */     private void setLastLineCommentPrefixCharacter(int lastLineCommentPrefixCharacter) {
/* 238 */       this.lastLineCommentPrefixCharacter = lastLineCommentPrefixCharacter;
/*     */     }
/*     */     
/*     */     private void skipComment() throws IOException {
/* 242 */       while (this.character != 10 && this.character != -1) {
/* 243 */         this.character = this.reader.read();
/*     */       }
/* 245 */       this.columnNumber = -1;
/*     */     }
/*     */     
/*     */     private void readEscaped() throws IOException {
/* 249 */       this.character = this.reader.read();
/* 250 */       int escapeIndex = ESCAPES[0].indexOf(this.character);
/* 251 */       if (escapeIndex != -1) {
/* 252 */         this.character = ESCAPES[1].charAt(escapeIndex);
/*     */       }
/* 254 */       else if (this.character == 10) {
/* 255 */         this.columnNumber = -1;
/* 256 */         read();
/*     */       }
/* 258 */       else if (this.character == 117) {
/* 259 */         readUnicode();
/*     */       } 
/*     */     }
/*     */     
/*     */     private void readUnicode() throws IOException {
/* 264 */       this.character = 0;
/* 265 */       for (int i = 0; i < 4; i++) {
/* 266 */         int digit = this.reader.read();
/* 267 */         if (digit >= 48 && digit <= 57) {
/* 268 */           this.character = (this.character << 4) + digit - 48;
/*     */         }
/* 270 */         else if (digit >= 97 && digit <= 102) {
/* 271 */           this.character = (this.character << 4) + digit - 97 + 10;
/*     */         }
/* 273 */         else if (digit >= 65 && digit <= 70) {
/* 274 */           this.character = (this.character << 4) + digit - 65 + 10;
/*     */         } else {
/*     */           
/* 277 */           throw new IllegalStateException("Malformed \\uxxxx encoding.");
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean isWhiteSpace() {
/* 283 */       return (!this.escaped && (this.character == 32 || this.character == 9 || this.character == 12));
/*     */     }
/*     */     
/*     */     boolean isEndOfFile() {
/* 287 */       return (this.character == -1);
/*     */     }
/*     */     
/*     */     boolean isEndOfLine() {
/* 291 */       return (this.character == -1 || (!this.escaped && this.character == 10));
/*     */     }
/*     */     
/*     */     boolean isListDelimiter() {
/* 295 */       return (!this.escaped && this.character == 44);
/*     */     }
/*     */     
/*     */     boolean isPropertyDelimiter() {
/* 299 */       return (!this.escaped && (this.character == 61 || this.character == 58));
/*     */     }
/*     */     
/*     */     char getCharacter() {
/* 303 */       return (char)this.character;
/*     */     }
/*     */     
/*     */     TextResourceOrigin.Location getLocation() {
/* 307 */       return new TextResourceOrigin.Location(this.reader.getLineNumber(), this.columnNumber);
/*     */     }
/*     */     
/*     */     boolean isSameLastLineCommentPrefix() {
/* 311 */       return (this.lastLineCommentPrefixCharacter == this.character);
/*     */     }
/*     */     
/*     */     boolean isCommentPrefixCharacter() {
/* 315 */       return (this.character == 35 || this.character == 33);
/*     */     }
/*     */     
/*     */     boolean isHyphenCharacter() {
/* 319 */       return (this.character == 45);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Document
/*     */   {
/* 329 */     private final Map<String, OriginTrackedValue> values = new LinkedHashMap<>();
/*     */     
/*     */     void put(String key, OriginTrackedValue value) {
/* 332 */       if (!key.isEmpty()) {
/* 333 */         this.values.put(key, value);
/*     */       }
/*     */     }
/*     */     
/*     */     boolean isEmpty() {
/* 338 */       return this.values.isEmpty();
/*     */     }
/*     */     
/*     */     Map<String, OriginTrackedValue> asMap() {
/* 342 */       return this.values;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\OriginTrackedPropertiesLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */