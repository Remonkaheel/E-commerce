/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.PropertySourceOrigin;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JsonPropertyValue
/*     */ {
/* 194 */   private static final String[] CANDIDATES = new String[] { "spring.application.json", "SPRING_APPLICATION_JSON" };
/*     */   
/*     */   private final PropertySource<?> propertySource;
/*     */   
/*     */   private final String propertyName;
/*     */   
/*     */   private final String json;
/*     */ 
/*     */   
/*     */   JsonPropertyValue(PropertySource<?> propertySource, String propertyName, String json) {
/* 204 */     this.propertySource = propertySource;
/* 205 */     this.propertyName = propertyName;
/* 206 */     this.json = json;
/*     */   }
/*     */   
/*     */   String getJson() {
/* 210 */     return this.json;
/*     */   }
/*     */   
/*     */   Origin getOrigin() {
/* 214 */     return PropertySourceOrigin.get(this.propertySource, this.propertyName);
/*     */   }
/*     */   
/*     */   static JsonPropertyValue get(PropertySource<?> propertySource) {
/* 218 */     for (String candidate : CANDIDATES) {
/* 219 */       Object value = propertySource.getProperty(candidate);
/* 220 */       if (value instanceof String) { String string = (String)value; if (StringUtils.hasLength(string))
/* 221 */           return new JsonPropertyValue(propertySource, candidate, string);  }
/*     */     
/*     */     } 
/* 224 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\SpringApplicationJsonEnvironmentPostProcessor$JsonPropertyValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */