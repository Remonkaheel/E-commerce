/*    */ package org.springframework.boot.env;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class YamlPropertySourceLoader
/*    */   implements PropertySourceLoader
/*    */ {
/*    */   public String[] getFileExtensions() {
/* 41 */     return new String[] { "yml", "yaml" };
/*    */   }
/*    */ 
/*    */   
/*    */   public List<PropertySource<?>> load(String name, Resource resource) throws IOException {
/* 46 */     if (!ClassUtils.isPresent("org.yaml.snakeyaml.Yaml", getClass().getClassLoader())) {
/* 47 */       throw new IllegalStateException("Attempted to load " + name + " but snakeyaml was not found on the classpath");
/*    */     }
/*    */     
/* 50 */     List<Map<String, Object>> loaded = (new OriginTrackedYamlLoader(resource)).load();
/* 51 */     if (loaded.isEmpty()) {
/* 52 */       return Collections.emptyList();
/*    */     }
/* 54 */     List<PropertySource<?>> propertySources = new ArrayList<>(loaded.size());
/* 55 */     for (int i = 0; i < loaded.size(); i++) {
/* 56 */       String documentNumber = (loaded.size() != 1) ? (" (document #" + i + ")") : "";
/* 57 */       propertySources.add(new OriginTrackedMapPropertySource(name + name, 
/* 58 */             Collections.unmodifiableMap(loaded.get(i)), true));
/*    */     } 
/* 60 */     return propertySources;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\YamlPropertySourceLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */