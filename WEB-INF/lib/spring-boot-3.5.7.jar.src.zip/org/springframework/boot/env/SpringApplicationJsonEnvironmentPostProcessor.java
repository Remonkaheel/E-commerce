/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.json.JsonParser;
/*     */ import org.springframework.boot.json.JsonParserFactory;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.boot.origin.PropertySourceOrigin;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.MapPropertySource;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringApplicationJsonEnvironmentPostProcessor
/*     */   implements EnvironmentPostProcessor, Ordered
/*     */ {
/*     */   public static final String SPRING_APPLICATION_JSON_PROPERTY = "spring.application.json";
/*     */   public static final String SPRING_APPLICATION_JSON_ENVIRONMENT_VARIABLE = "SPRING_APPLICATION_JSON";
/*     */   private static final String SERVLET_ENVIRONMENT_CLASS = "org.springframework.web.context.support.StandardServletEnvironment";
/*  72 */   private static final Set<String> SERVLET_ENVIRONMENT_PROPERTY_SOURCES = new LinkedHashSet<>(
/*  73 */       Arrays.asList(new String[] { "jndiProperties", "servletContextInitParams", "servletConfigInitParams" }));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_ORDER = -2147483643;
/*     */ 
/*     */ 
/*     */   
/*  82 */   private int order = -2147483643;
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  86 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/*  90 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
/*  95 */     MutablePropertySources propertySources = environment.getPropertySources();
/*  96 */     propertySources.stream()
/*  97 */       .map(JsonPropertyValue::get)
/*  98 */       .filter(Objects::nonNull)
/*  99 */       .findFirst()
/* 100 */       .ifPresent(v -> processJson(environment, v));
/*     */   }
/*     */   
/*     */   private void processJson(ConfigurableEnvironment environment, JsonPropertyValue propertyValue) {
/* 104 */     JsonParser parser = JsonParserFactory.getJsonParser();
/* 105 */     Map<String, Object> map = parser.parseMap(propertyValue.getJson());
/* 106 */     if (!map.isEmpty()) {
/* 107 */       addJsonPropertySource(environment, (PropertySource<?>)new JsonPropertySource(propertyValue, flatten(map)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> flatten(Map<String, Object> map) {
/* 117 */     Map<String, Object> result = new LinkedHashMap<>();
/* 118 */     flatten(null, result, map);
/* 119 */     return result;
/*     */   }
/*     */   
/*     */   private void flatten(String prefix, Map<String, Object> result, Map<String, Object> map) {
/* 123 */     String namePrefix = (prefix != null) ? (prefix + ".") : "";
/* 124 */     map.forEach((key, value) -> extract(namePrefix + namePrefix, result, value));
/*     */   }
/*     */ 
/*     */   
/*     */   private void extract(String name, Map<String, Object> result, Object value) {
/* 129 */     if (value instanceof Map) { Map<?, ?> map = (Map<?, ?>)value;
/* 130 */       if (CollectionUtils.isEmpty(map)) {
/* 131 */         result.put(name, value);
/*     */         return;
/*     */       } 
/* 134 */       flatten(name, result, (Map<String, Object>)value); }
/*     */     
/* 136 */     else if (value instanceof Collection) { Collection<?> collection = (Collection)value;
/* 137 */       if (CollectionUtils.isEmpty(collection)) {
/* 138 */         result.put(name, value);
/*     */         return;
/*     */       } 
/* 141 */       int index = 0;
/* 142 */       for (Object object : collection) {
/* 143 */         extract(name + "[" + name + "]", result, object);
/* 144 */         index++;
/*     */       }  }
/*     */     else
/*     */     
/* 148 */     { result.put(name, value); }
/*     */   
/*     */   }
/*     */   
/*     */   private void addJsonPropertySource(ConfigurableEnvironment environment, PropertySource<?> source) {
/* 153 */     MutablePropertySources sources = environment.getPropertySources();
/* 154 */     String name = findPropertySource(sources);
/* 155 */     if (sources.contains(name)) {
/* 156 */       sources.addBefore(name, source);
/*     */     } else {
/*     */       
/* 159 */       sources.addFirst(source);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String findPropertySource(MutablePropertySources sources) {
/* 164 */     if (ClassUtils.isPresent("org.springframework.web.context.support.StandardServletEnvironment", null)) {
/*     */ 
/*     */ 
/*     */       
/* 168 */       PropertySource<?> servletPropertySource = sources.stream().filter(source -> SERVLET_ENVIRONMENT_PROPERTY_SOURCES.contains(source.getName())).findFirst().orElse(null);
/* 169 */       if (servletPropertySource != null) {
/* 170 */         return servletPropertySource.getName();
/*     */       }
/*     */     } 
/* 173 */     return "systemProperties";
/*     */   }
/*     */   
/*     */   private static class JsonPropertySource
/*     */     extends MapPropertySource implements OriginLookup<String> {
/*     */     private final SpringApplicationJsonEnvironmentPostProcessor.JsonPropertyValue propertyValue;
/*     */     
/*     */     JsonPropertySource(SpringApplicationJsonEnvironmentPostProcessor.JsonPropertyValue propertyValue, Map<String, Object> source) {
/* 181 */       super("spring.application.json", source);
/* 182 */       this.propertyValue = propertyValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public Origin getOrigin(String key) {
/* 187 */       return this.propertyValue.getOrigin();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class JsonPropertyValue
/*     */   {
/* 194 */     private static final String[] CANDIDATES = new String[] { "spring.application.json", "SPRING_APPLICATION_JSON" };
/*     */     
/*     */     private final PropertySource<?> propertySource;
/*     */     
/*     */     private final String propertyName;
/*     */     
/*     */     private final String json;
/*     */ 
/*     */     
/*     */     JsonPropertyValue(PropertySource<?> propertySource, String propertyName, String json) {
/* 204 */       this.propertySource = propertySource;
/* 205 */       this.propertyName = propertyName;
/* 206 */       this.json = json;
/*     */     }
/*     */     
/*     */     String getJson() {
/* 210 */       return this.json;
/*     */     }
/*     */     
/*     */     Origin getOrigin() {
/* 214 */       return PropertySourceOrigin.get(this.propertySource, this.propertyName);
/*     */     }
/*     */     
/*     */     static JsonPropertyValue get(PropertySource<?> propertySource) {
/* 218 */       for (String candidate : CANDIDATES) {
/* 219 */         Object value = propertySource.getProperty(candidate);
/* 220 */         if (value instanceof String) { String string = (String)value; if (StringUtils.hasLength(string))
/* 221 */             return new JsonPropertyValue(propertySource, candidate, string);  }
/*     */       
/*     */       } 
/* 224 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\SpringApplicationJsonEnvironmentPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */