package org.springframework.boot.env;

import org.springframework.core.io.InputStreamSource;

public interface Value extends CharSequence, InputStreamSource {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\ConfigTreePropertySource$Value.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */