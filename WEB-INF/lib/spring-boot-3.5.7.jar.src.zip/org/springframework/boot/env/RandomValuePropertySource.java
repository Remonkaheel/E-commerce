/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.util.HexFormat;
/*     */ import java.util.OptionalInt;
/*     */ import java.util.OptionalLong;
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RandomValuePropertySource
/*     */   extends PropertySource<Random>
/*     */ {
/*     */   public static final String RANDOM_PROPERTY_SOURCE_NAME = "random";
/*     */   private static final String PREFIX = "random.";
/*  73 */   private static final Log logger = LogFactory.getLog(RandomValuePropertySource.class);
/*     */   
/*     */   public RandomValuePropertySource() {
/*  76 */     this("random");
/*     */   }
/*     */   
/*     */   public RandomValuePropertySource(String name) {
/*  80 */     super(name, new Random());
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) {
/*  85 */     if (!name.startsWith("random.")) {
/*  86 */       return null;
/*     */     }
/*  88 */     logger.trace(LogMessage.format("Generating random property for '%s'", name));
/*  89 */     return getRandomValue(name.substring("random.".length()));
/*     */   }
/*     */   
/*     */   private Object getRandomValue(String type) {
/*  93 */     if (type.equals("int")) {
/*  94 */       return Integer.valueOf(((Random)getSource()).nextInt());
/*     */     }
/*  96 */     if (type.equals("long")) {
/*  97 */       return Long.valueOf(((Random)getSource()).nextLong());
/*     */     }
/*  99 */     String range = getRange(type, "int");
/* 100 */     if (range != null) {
/* 101 */       return Integer.valueOf(getNextIntInRange(Range.of(range, Integer::parseInt)));
/*     */     }
/* 103 */     range = getRange(type, "long");
/* 104 */     if (range != null) {
/* 105 */       return Long.valueOf(getNextLongInRange(Range.of(range, Long::parseLong)));
/*     */     }
/* 107 */     if (type.equals("uuid")) {
/* 108 */       return UUID.randomUUID().toString();
/*     */     }
/* 110 */     return getRandomBytes();
/*     */   }
/*     */   
/*     */   private String getRange(String type, String prefix) {
/* 114 */     if (type.startsWith(prefix)) {
/* 115 */       int startIndex = prefix.length() + 1;
/* 116 */       if (type.length() > startIndex) {
/* 117 */         return type.substring(startIndex, type.length() - 1);
/*     */       }
/*     */     } 
/* 120 */     return null;
/*     */   }
/*     */   
/*     */   private int getNextIntInRange(Range<Integer> range) {
/* 124 */     OptionalInt first = ((Random)getSource()).ints(1L, ((Integer)range.getMin()).intValue(), ((Integer)range.getMax()).intValue()).findFirst();
/* 125 */     assertPresent(first.isPresent(), range);
/* 126 */     return first.getAsInt();
/*     */   }
/*     */   
/*     */   private long getNextLongInRange(Range<Long> range) {
/* 130 */     OptionalLong first = ((Random)getSource()).longs(1L, ((Long)range.getMin()).longValue(), ((Long)range.getMax()).longValue()).findFirst();
/* 131 */     assertPresent(first.isPresent(), range);
/* 132 */     return first.getAsLong();
/*     */   }
/*     */   
/*     */   private void assertPresent(boolean present, Range<?> range) {
/* 136 */     Assert.state(present, () -> "Could not get random number for range '" + String.valueOf(range) + "'");
/*     */   }
/*     */   
/*     */   private Object getRandomBytes() {
/* 140 */     byte[] bytes = new byte[16];
/* 141 */     ((Random)getSource()).nextBytes(bytes);
/* 142 */     return HexFormat.of().withLowerCase().formatHex(bytes);
/*     */   }
/*     */   
/*     */   public static void addToEnvironment(ConfigurableEnvironment environment) {
/* 146 */     addToEnvironment(environment, logger);
/*     */   }
/*     */   
/*     */   static void addToEnvironment(ConfigurableEnvironment environment, Log logger) {
/* 150 */     MutablePropertySources sources = environment.getPropertySources();
/* 151 */     PropertySource<?> existing = sources.get("random");
/* 152 */     if (existing != null) {
/* 153 */       logger.trace("RandomValuePropertySource already present");
/*     */       return;
/*     */     } 
/* 156 */     RandomValuePropertySource randomSource = new RandomValuePropertySource("random");
/* 157 */     if (sources.get("systemEnvironment") != null) {
/* 158 */       sources.addAfter("systemEnvironment", randomSource);
/*     */     } else {
/*     */       
/* 161 */       sources.addLast(randomSource);
/*     */     } 
/* 163 */     logger.trace("RandomValuePropertySource add to Environment");
/*     */   }
/*     */ 
/*     */   
/*     */   static final class Range<T extends Number>
/*     */   {
/*     */     private final String value;
/*     */     
/*     */     private final T min;
/*     */     private final T max;
/*     */     
/*     */     private Range(String value, T min, T max) {
/* 175 */       this.value = value;
/* 176 */       this.min = min;
/* 177 */       this.max = max;
/*     */     }
/*     */     
/*     */     T getMin() {
/* 181 */       return this.min;
/*     */     }
/*     */     
/*     */     T getMax() {
/* 185 */       return this.max;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 190 */       return this.value;
/*     */     }
/*     */     
/*     */     static <T extends Number & Comparable<T>> Range<T> of(String value, Function<String, T> parse) {
/* 194 */       Number number1 = (Number)parse.apply("0");
/* 195 */       String[] tokens = StringUtils.commaDelimitedListToStringArray(value);
/* 196 */       Number number2 = (Number)parse.apply(tokens[0]);
/* 197 */       if (tokens.length == 1) {
/* 198 */         Assert.state((((Comparable<Number>)number2).compareTo(number1) > 0), "Bound must be positive.");
/* 199 */         return (Range)new Range<>(value, number1, number2);
/*     */       } 
/* 201 */       Number number3 = (Number)parse.apply(tokens[1]);
/* 202 */       Assert.state((((Comparable<Number>)number2).compareTo(number3) < 0), "Lower bound must be less than upper bound.");
/* 203 */       return (Range)new Range<>(value, number2, number3);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\RandomValuePropertySource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */