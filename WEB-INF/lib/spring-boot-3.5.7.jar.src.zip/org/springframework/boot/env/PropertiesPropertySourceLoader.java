/*    */ package org.springframework.boot.env;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.origin.OriginTrackedValue;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertiesPropertySourceLoader
/*    */   implements PropertySourceLoader
/*    */ {
/*    */   private static final String XML_FILE_EXTENSION = ".xml";
/*    */   
/*    */   public String[] getFileExtensions() {
/* 44 */     return new String[] { "properties", "xml" };
/*    */   }
/*    */ 
/*    */   
/*    */   public List<PropertySource<?>> load(String name, Resource resource) throws IOException {
/* 49 */     List<Map<String, ?>> properties = loadProperties(resource);
/* 50 */     if (properties.isEmpty()) {
/* 51 */       return Collections.emptyList();
/*    */     }
/* 53 */     List<PropertySource<?>> propertySources = new ArrayList<>(properties.size());
/* 54 */     for (int i = 0; i < properties.size(); i++) {
/* 55 */       String documentNumber = (properties.size() != 1) ? (" (document #" + i + ")") : "";
/* 56 */       propertySources.add(new OriginTrackedMapPropertySource(name + name, 
/* 57 */             Collections.unmodifiableMap(properties.get(i)), true));
/*    */     } 
/* 59 */     return propertySources;
/*    */   }
/*    */ 
/*    */   
/*    */   private List<Map<String, ?>> loadProperties(Resource resource) throws IOException {
/* 64 */     String filename = resource.getFilename();
/* 65 */     List<Map<String, ?>> result = new ArrayList<>();
/* 66 */     if (filename != null && filename.endsWith(".xml")) {
/* 67 */       result.add(PropertiesLoaderUtils.loadProperties(resource));
/*    */     } else {
/*    */       
/* 70 */       List<OriginTrackedPropertiesLoader.Document> documents = (new OriginTrackedPropertiesLoader(resource)).load();
/* 71 */       documents.forEach(document -> result.add(document.asMap()));
/*    */     } 
/* 73 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\PropertiesPropertySourceLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */