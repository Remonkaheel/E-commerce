/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.file.FileVisitOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.util.Collections;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.TextResourceOrigin;
/*     */ import org.springframework.core.io.FileSystemResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PropertyFile
/*     */ {
/* 177 */   private static final TextResourceOrigin.Location START_OF_FILE = new TextResourceOrigin.Location(0, 0);
/*     */   
/*     */   private final Path path;
/*     */   
/*     */   private final FileSystemResource resource;
/*     */   
/*     */   private final Origin origin;
/*     */   
/*     */   private final ConfigTreePropertySource.PropertyFileContent cachedContent;
/*     */   
/*     */   private final boolean autoTrimTrailingNewLine;
/*     */   
/*     */   private PropertyFile(Path path, Set<ConfigTreePropertySource.Option> options) {
/* 190 */     this.path = path;
/* 191 */     this.resource = new FileSystemResource(path);
/* 192 */     this.origin = (Origin)new TextResourceOrigin((Resource)this.resource, START_OF_FILE);
/* 193 */     this.autoTrimTrailingNewLine = options.contains(ConfigTreePropertySource.Option.AUTO_TRIM_TRAILING_NEW_LINE);
/* 194 */     this
/* 195 */       .cachedContent = options.contains(ConfigTreePropertySource.Option.ALWAYS_READ) ? null : new ConfigTreePropertySource.PropertyFileContent(path, (Resource)this.resource, this.origin, true, this.autoTrimTrailingNewLine);
/*     */   }
/*     */   
/*     */   ConfigTreePropertySource.PropertyFileContent getContent() {
/* 199 */     if (this.cachedContent != null) {
/* 200 */       return this.cachedContent;
/*     */     }
/* 202 */     return new ConfigTreePropertySource.PropertyFileContent(this.path, (Resource)this.resource, this.origin, false, this.autoTrimTrailingNewLine);
/*     */   }
/*     */   
/*     */   Origin getOrigin() {
/* 206 */     return this.origin;
/*     */   }
/*     */   
/*     */   static Map<String, PropertyFile> findAll(Path sourceDirectory, Set<ConfigTreePropertySource.Option> options) {
/*     */     try {
/* 211 */       Map<String, PropertyFile> propertyFiles = new TreeMap<>();
/* 212 */       Stream<Path> pathStream = Files.find(sourceDirectory, 100, PropertyFile::isPropertyFile, new FileVisitOption[] { FileVisitOption.FOLLOW_LINKS });
/*     */       
/* 214 */       try { pathStream.forEach(path -> {
/*     */               String name = getName(sourceDirectory.relativize(path));
/*     */               if (StringUtils.hasText(name)) {
/*     */                 if (options.contains(ConfigTreePropertySource.Option.USE_LOWERCASE_NAMES)) {
/*     */                   name = name.toLowerCase(Locale.getDefault());
/*     */                 }
/*     */                 propertyFiles.put(name, new PropertyFile(path, options));
/*     */               } 
/*     */             });
/* 223 */         if (pathStream != null) pathStream.close();  } catch (Throwable throwable) { if (pathStream != null)
/* 224 */           try { pathStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return Collections.unmodifiableMap(propertyFiles);
/*     */     }
/* 226 */     catch (IOException ex) {
/* 227 */       throw new IllegalStateException("Unable to find files in '" + String.valueOf(sourceDirectory) + "'", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isPropertyFile(Path path, BasicFileAttributes attributes) {
/* 232 */     return (!hasHiddenPathElement(path) && (attributes.isRegularFile() || attributes.isSymbolicLink()));
/*     */   }
/*     */   
/*     */   private static boolean hasHiddenPathElement(Path path) {
/* 236 */     for (Path element : path) {
/* 237 */       if (element.toString().startsWith("..")) {
/* 238 */         return true;
/*     */       }
/*     */     } 
/* 241 */     return false;
/*     */   }
/*     */   
/*     */   private static String getName(Path relativePath) {
/* 245 */     int nameCount = relativePath.getNameCount();
/* 246 */     if (nameCount == 1) {
/* 247 */       return relativePath.toString();
/*     */     }
/* 249 */     StringBuilder name = new StringBuilder();
/* 250 */     for (int i = 0; i < nameCount; i++) {
/* 251 */       name.append((i != 0) ? "." : "");
/* 252 */       name.append(relativePath.getName(i));
/*     */     } 
/* 254 */     return name.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\ConfigTreePropertySource$PropertyFile.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */