/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.boot.origin.SystemEnvironmentOrigin;
/*     */ import org.springframework.core.env.SystemEnvironmentPropertySource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OriginAwareSystemEnvironmentPropertySource
/*     */   extends SystemEnvironmentPropertySource
/*     */   implements OriginLookup<String>
/*     */ {
/*     */   private final String prefix;
/*     */   
/*     */   OriginAwareSystemEnvironmentPropertySource(String name, Map<String, Object> source, String environmentPrefix) {
/*  86 */     super(name, source);
/*  87 */     this.prefix = determinePrefix(environmentPrefix);
/*     */   }
/*     */   
/*     */   private String determinePrefix(String environmentPrefix) {
/*  91 */     if (!StringUtils.hasText(environmentPrefix)) {
/*  92 */       return null;
/*     */     }
/*  94 */     if (environmentPrefix.endsWith(".") || environmentPrefix.endsWith("_") || environmentPrefix.endsWith("-")) {
/*  95 */       return environmentPrefix.substring(0, environmentPrefix.length() - 1);
/*     */     }
/*  97 */     return environmentPrefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsProperty(String name) {
/* 102 */     return super.containsProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) {
/* 107 */     return super.getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Origin getOrigin(String key) {
/* 112 */     String property = resolvePropertyName(key);
/* 113 */     if (super.containsProperty(property)) {
/* 114 */       return (Origin)new SystemEnvironmentOrigin(property);
/*     */     }
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/* 121 */     return this.prefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isImmutable() {
/* 126 */     return (getSource() == System.getenv());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\env\SystemEnvironmentPropertySourceEnvironmentPostProcessor$OriginAwareSystemEnvironmentPropertySource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */