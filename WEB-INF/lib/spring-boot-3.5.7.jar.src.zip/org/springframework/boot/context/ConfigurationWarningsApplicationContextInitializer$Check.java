package org.springframework.boot.context;

import org.springframework.beans.factory.support.BeanDefinitionRegistry;

@FunctionalInterface
public interface Check {
  String getWarning(BeanDefinitionRegistry paramBeanDefinitionRegistry);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\ConfigurationWarningsApplicationContextInitializer$Check.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */