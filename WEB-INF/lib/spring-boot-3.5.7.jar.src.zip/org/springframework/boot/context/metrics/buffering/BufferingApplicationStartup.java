/*     */ package org.springframework.boot.context.metrics.buffering;
/*     */ 
/*     */ import java.time.Clock;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.core.metrics.ApplicationStartup;
/*     */ import org.springframework.core.metrics.StartupStep;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferingApplicationStartup
/*     */   implements ApplicationStartup
/*     */ {
/*     */   private final int capacity;
/*     */   private final Clock clock;
/*     */   private Instant startTime;
/*  61 */   private final AtomicInteger idSeq = new AtomicInteger();
/*     */   
/*     */   private Predicate<StartupStep> filter = step -> true;
/*     */   
/*  65 */   private final AtomicReference<BufferedStartupStep> current = new AtomicReference<>();
/*     */   
/*  67 */   private final AtomicInteger estimatedSize = new AtomicInteger();
/*     */   
/*  69 */   private final ConcurrentLinkedQueue<StartupTimeline.TimelineEvent> events = new ConcurrentLinkedQueue<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferingApplicationStartup(int capacity) {
/*  77 */     this(capacity, Clock.systemDefaultZone());
/*     */   }
/*     */   
/*     */   BufferingApplicationStartup(int capacity, Clock clock) {
/*  81 */     this.capacity = capacity;
/*  82 */     this.clock = clock;
/*  83 */     this.startTime = clock.instant();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startRecording() {
/*  94 */     Assert.state(this.events.isEmpty(), "Cannot restart recording once steps have been buffered");
/*  95 */     this.startTime = this.clock.instant();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFilter(Predicate<StartupStep> filter) {
/* 105 */     this.filter = this.filter.and(filter);
/*     */   }
/*     */ 
/*     */   
/*     */   public StartupStep start(String name) {
/* 110 */     int id = this.idSeq.getAndIncrement();
/* 111 */     Instant start = this.clock.instant();
/*     */     while (true) {
/* 113 */       BufferedStartupStep current = this.current.get();
/* 114 */       BufferedStartupStep parent = getLatestActive(current);
/* 115 */       BufferedStartupStep next = new BufferedStartupStep(parent, name, id, start, this::record);
/* 116 */       if (this.current.compareAndSet(current, next))
/* 117 */         return next; 
/*     */     } 
/*     */   }
/*     */   private void record(BufferedStartupStep step) {
/*     */     BufferedStartupStep current;
/*     */     BufferedStartupStep next;
/* 123 */     if (this.filter.test(step) && this.estimatedSize.get() < this.capacity) {
/* 124 */       this.estimatedSize.incrementAndGet();
/* 125 */       this.events.add(new StartupTimeline.TimelineEvent(step, this.clock.instant()));
/*     */     } 
/*     */     do {
/* 128 */       current = this.current.get();
/* 129 */       next = getLatestActive(current);
/* 130 */     } while (!this.current.compareAndSet(current, next));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BufferedStartupStep getLatestActive(BufferedStartupStep step) {
/* 137 */     while (step != null && step.isEnded()) {
/* 138 */       step = step.getParent();
/*     */     }
/* 140 */     return step;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StartupTimeline getBufferedTimeline() {
/* 152 */     return new StartupTimeline(this.startTime, new ArrayList<>(this.events));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StartupTimeline drainBufferedTimeline() {
/* 163 */     List<StartupTimeline.TimelineEvent> events = new ArrayList<>();
/* 164 */     Iterator<StartupTimeline.TimelineEvent> iterator = this.events.iterator();
/* 165 */     while (iterator.hasNext()) {
/* 166 */       events.add(iterator.next());
/* 167 */       iterator.remove();
/*     */     } 
/* 169 */     this.estimatedSize.set(0);
/* 170 */     return new StartupTimeline(this.startTime, events);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\metrics\buffering\BufferingApplicationStartup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */