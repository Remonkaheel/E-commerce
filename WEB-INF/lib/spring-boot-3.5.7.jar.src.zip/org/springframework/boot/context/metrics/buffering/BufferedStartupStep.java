/*     */ package org.springframework.boot.context.metrics.buffering;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.core.metrics.StartupStep;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BufferedStartupStep
/*     */   implements StartupStep
/*     */ {
/*     */   private final String name;
/*     */   private final long id;
/*     */   private final BufferedStartupStep parent;
/*  46 */   private final List<StartupStep.Tag> tags = new ArrayList<>();
/*     */   
/*     */   private final Consumer<BufferedStartupStep> recorder;
/*     */   
/*     */   private final Instant startTime;
/*     */   
/*  52 */   private final AtomicBoolean ended = new AtomicBoolean();
/*     */ 
/*     */   
/*     */   BufferedStartupStep(BufferedStartupStep parent, String name, long id, Instant startTime, Consumer<BufferedStartupStep> recorder) {
/*  56 */     this.parent = parent;
/*  57 */     this.name = name;
/*  58 */     this.id = id;
/*  59 */     this.startTime = startTime;
/*  60 */     this.recorder = recorder;
/*     */   }
/*     */   
/*     */   BufferedStartupStep getParent() {
/*  64 */     return this.parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  69 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getId() {
/*  74 */     return this.id;
/*     */   }
/*     */   
/*     */   Instant getStartTime() {
/*  78 */     return this.startTime;
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getParentId() {
/*  83 */     return (this.parent != null) ? Long.valueOf(this.parent.getId()) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public StartupStep.Tags getTags() {
/*  88 */     Objects.requireNonNull(Collections.unmodifiableList(this.tags)); return Collections.unmodifiableList(this.tags)::iterator;
/*     */   }
/*     */ 
/*     */   
/*     */   public StartupStep tag(String key, Supplier<String> value) {
/*  93 */     return tag(key, value.get());
/*     */   }
/*     */ 
/*     */   
/*     */   public StartupStep tag(String key, String value) {
/*  98 */     Assert.state(!this.ended.get(), "StartupStep has already ended.");
/*  99 */     this.tags.add(new DefaultTag(key, value));
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void end() {
/* 105 */     this.ended.set(true);
/* 106 */     this.recorder.accept(this);
/*     */   }
/*     */   
/*     */   boolean isEnded() {
/* 110 */     return this.ended.get();
/*     */   }
/*     */   
/*     */   static class DefaultTag
/*     */     implements StartupStep.Tag
/*     */   {
/*     */     private final String key;
/*     */     private final String value;
/*     */     
/*     */     DefaultTag(String key, String value) {
/* 120 */       this.key = key;
/* 121 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 126 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 131 */       return this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\metrics\buffering\BufferedStartupStep.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */