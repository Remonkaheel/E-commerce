/*     */ package org.springframework.boot.context;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.annotation.ComponentScan;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentScanPackageCheck
/*     */   implements ConfigurationWarningsApplicationContextInitializer.Check
/*     */ {
/*     */   private static final Set<String> PROBLEM_PACKAGES;
/*     */   
/*     */   static {
/* 133 */     Set<String> packages = new HashSet<>();
/* 134 */     packages.add("org.springframework");
/* 135 */     packages.add("org");
/* 136 */     PROBLEM_PACKAGES = Collections.unmodifiableSet(packages);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getWarning(BeanDefinitionRegistry registry) {
/* 141 */     Set<String> scannedPackages = getComponentScanningPackages(registry);
/* 142 */     List<String> problematicPackages = getProblematicPackages(scannedPackages);
/* 143 */     if (problematicPackages.isEmpty()) {
/* 144 */       return null;
/*     */     }
/*     */     
/* 147 */     return "Your ApplicationContext is unlikely to start due to a @ComponentScan of " + StringUtils.collectionToDelimitedString(problematicPackages, ", ") + ".";
/*     */   }
/*     */   
/*     */   protected Set<String> getComponentScanningPackages(BeanDefinitionRegistry registry) {
/* 151 */     Set<String> packages = new LinkedHashSet<>();
/* 152 */     String[] names = registry.getBeanDefinitionNames();
/* 153 */     for (String name : names) {
/* 154 */       BeanDefinition definition = registry.getBeanDefinition(name);
/* 155 */       if (definition instanceof AnnotatedBeanDefinition) { AnnotatedBeanDefinition annotatedDefinition = (AnnotatedBeanDefinition)definition;
/* 156 */         addComponentScanningPackages(packages, annotatedDefinition.getMetadata()); }
/*     */     
/*     */     } 
/* 159 */     return packages;
/*     */   }
/*     */ 
/*     */   
/*     */   private void addComponentScanningPackages(Set<String> packages, AnnotationMetadata metadata) {
/* 164 */     AnnotationAttributes attributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(ComponentScan.class.getName(), true));
/* 165 */     if (attributes != null) {
/* 166 */       addPackages(packages, attributes.getStringArray("value"));
/* 167 */       addPackages(packages, attributes.getStringArray("basePackages"));
/* 168 */       addClasses(packages, attributes.getStringArray("basePackageClasses"));
/* 169 */       if (packages.isEmpty()) {
/* 170 */         packages.add(ClassUtils.getPackageName(metadata.getClassName()));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addPackages(Set<String> packages, String[] values) {
/* 176 */     if (values != null) {
/* 177 */       Collections.addAll(packages, values);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addClasses(Set<String> packages, String[] values) {
/* 182 */     if (values != null) {
/* 183 */       for (String value : values) {
/* 184 */         packages.add(ClassUtils.getPackageName(value));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private List<String> getProblematicPackages(Set<String> scannedPackages) {
/* 190 */     List<String> problematicPackages = new ArrayList<>();
/* 191 */     for (String scannedPackage : scannedPackages) {
/* 192 */       if (isProblematicPackage(scannedPackage)) {
/* 193 */         problematicPackages.add(getDisplayName(scannedPackage));
/*     */       }
/*     */     } 
/* 196 */     return problematicPackages;
/*     */   }
/*     */   
/*     */   private boolean isProblematicPackage(String scannedPackage) {
/* 200 */     if (scannedPackage == null || scannedPackage.isEmpty()) {
/* 201 */       return true;
/*     */     }
/* 203 */     return PROBLEM_PACKAGES.contains(scannedPackage);
/*     */   }
/*     */   
/*     */   private String getDisplayName(String scannedPackage) {
/* 207 */     if (scannedPackage == null || scannedPackage.isEmpty()) {
/* 208 */       return "the default package";
/*     */     }
/* 210 */     return "'" + scannedPackage + "'";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\ConfigurationWarningsApplicationContextInitializer$ComponentScanPackageCheck.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */