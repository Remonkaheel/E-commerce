/*     */ package org.springframework.boot.context.logging;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.function.BiConsumer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationFailedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationPreparedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationStartingEvent;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ import org.springframework.boot.logging.LogLevel;
/*     */ import org.springframework.boot.logging.LoggerGroup;
/*     */ import org.springframework.boot.logging.LoggerGroups;
/*     */ import org.springframework.boot.logging.LoggingInitializationContext;
/*     */ import org.springframework.boot.logging.LoggingSystem;
/*     */ import org.springframework.boot.logging.LoggingSystemProperties;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.SmartLifecycle;
/*     */ import org.springframework.context.event.ContextClosedEvent;
/*     */ import org.springframework.context.event.GenericApplicationListener;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggingApplicationListener
/*     */   implements GenericApplicationListener
/*     */ {
/*  96 */   private static final ConfigurationPropertyName LOGGING_LEVEL = ConfigurationPropertyName.of("logging.level");
/*     */   
/*  98 */   private static final ConfigurationPropertyName LOGGING_GROUP = ConfigurationPropertyName.of("logging.group");
/*     */   
/* 100 */   private static final Bindable<Map<String, LogLevel>> STRING_LOGLEVEL_MAP = Bindable.mapOf(String.class, LogLevel.class);
/*     */ 
/*     */ 
/*     */   
/* 104 */   private static final Bindable<Map<String, List<String>>> STRING_STRINGS_MAP = Bindable.of(ResolvableType.forClassWithGenerics(MultiValueMap.class, new Class[] { String.class, String.class }).asMap());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_ORDER = -2147483628;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String CONFIG_PROPERTY = "logging.config";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String REGISTER_SHUTDOWN_HOOK_PROPERTY = "logging.register-shutdown-hook";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LOGGING_SYSTEM_BEAN_NAME = "springBootLoggingSystem";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LOG_FILE_BEAN_NAME = "springBootLogFile";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LOGGER_GROUPS_BEAN_NAME = "springBootLoggerGroups";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String LOGGING_LIFECYCLE_BEAN_NAME = "springBootLoggingLifecycle";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Map<String, List<String>> DEFAULT_GROUP_LOGGERS;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Map<LogLevel, List<String>> SPRING_BOOT_LOGGING_LOGGERS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 148 */     LinkedMultiValueMap linkedMultiValueMap2 = new LinkedMultiValueMap();
/* 149 */     linkedMultiValueMap2.add("web", "org.springframework.core.codec");
/* 150 */     linkedMultiValueMap2.add("web", "org.springframework.http");
/* 151 */     linkedMultiValueMap2.add("web", "org.springframework.web");
/* 152 */     linkedMultiValueMap2.add("web", "org.springframework.boot.actuate.endpoint.web");
/* 153 */     linkedMultiValueMap2.add("web", "org.springframework.boot.web.servlet.ServletContextInitializerBeans");
/* 154 */     linkedMultiValueMap2.add("sql", "org.springframework.jdbc.core");
/* 155 */     linkedMultiValueMap2.add("sql", "org.hibernate.SQL");
/* 156 */     linkedMultiValueMap2.add("sql", "org.jooq.tools.LoggerListener");
/* 157 */     DEFAULT_GROUP_LOGGERS = Collections.unmodifiableMap((Map<? extends String, ? extends List<String>>)linkedMultiValueMap2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     LinkedMultiValueMap linkedMultiValueMap1 = new LinkedMultiValueMap();
/* 163 */     linkedMultiValueMap1.add(LogLevel.DEBUG, "sql");
/* 164 */     linkedMultiValueMap1.add(LogLevel.DEBUG, "web");
/* 165 */     linkedMultiValueMap1.add(LogLevel.DEBUG, "org.springframework.boot");
/* 166 */     linkedMultiValueMap1.add(LogLevel.TRACE, "org.springframework");
/* 167 */     linkedMultiValueMap1.add(LogLevel.TRACE, "org.apache.tomcat");
/* 168 */     linkedMultiValueMap1.add(LogLevel.TRACE, "org.apache.catalina");
/* 169 */     linkedMultiValueMap1.add(LogLevel.TRACE, "org.eclipse.jetty");
/* 170 */     linkedMultiValueMap1.add(LogLevel.TRACE, "org.hibernate.tool.hbm2ddl");
/* 171 */     SPRING_BOOT_LOGGING_LOGGERS = Collections.unmodifiableMap((Map<? extends LogLevel, ? extends List<String>>)linkedMultiValueMap1);
/*     */   }
/*     */   
/* 174 */   private static final Class<?>[] EVENT_TYPES = new Class[] { ApplicationStartingEvent.class, ApplicationEnvironmentPreparedEvent.class, ApplicationPreparedEvent.class, ContextClosedEvent.class, ApplicationFailedEvent.class };
/*     */ 
/*     */ 
/*     */   
/* 178 */   private static final Class<?>[] SOURCE_TYPES = new Class[] { SpringApplication.class, ApplicationContext.class };
/*     */   
/* 180 */   private static final AtomicBoolean shutdownHookRegistered = new AtomicBoolean();
/*     */   
/* 182 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private LoggingSystem loggingSystem;
/*     */   
/*     */   private LogFile logFile;
/*     */   
/*     */   private LoggerGroups loggerGroups;
/*     */   
/* 190 */   private int order = -2147483628;
/*     */   
/*     */   private boolean parseArgs = true;
/*     */   
/* 194 */   private LogLevel springBootLogging = null;
/*     */ 
/*     */   
/*     */   public boolean supportsEventType(ResolvableType resolvableType) {
/* 198 */     return isAssignableFrom(resolvableType.getRawClass(), EVENT_TYPES);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsSourceType(Class<?> sourceType) {
/* 203 */     return isAssignableFrom(sourceType, SOURCE_TYPES);
/*     */   }
/*     */   
/*     */   private boolean isAssignableFrom(Class<?> type, Class<?>... supportedTypes) {
/* 207 */     if (type != null) {
/* 208 */       for (Class<?> supportedType : supportedTypes) {
/* 209 */         if (supportedType.isAssignableFrom(type)) {
/* 210 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 214 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event) {
/* 219 */     if (event instanceof ApplicationStartingEvent) { ApplicationStartingEvent startingEvent = (ApplicationStartingEvent)event;
/* 220 */       onApplicationStartingEvent(startingEvent); }
/*     */     
/* 222 */     else if (event instanceof ApplicationEnvironmentPreparedEvent) { ApplicationEnvironmentPreparedEvent environmentPreparedEvent = (ApplicationEnvironmentPreparedEvent)event;
/* 223 */       onApplicationEnvironmentPreparedEvent(environmentPreparedEvent); }
/*     */     
/* 225 */     else if (event instanceof ApplicationPreparedEvent) { ApplicationPreparedEvent preparedEvent = (ApplicationPreparedEvent)event;
/* 226 */       onApplicationPreparedEvent(preparedEvent); }
/*     */     
/* 228 */     else if (event instanceof ContextClosedEvent) { ContextClosedEvent contextClosedEvent = (ContextClosedEvent)event;
/* 229 */       onContextClosedEvent(contextClosedEvent); }
/*     */     
/* 231 */     else if (event instanceof ApplicationFailedEvent)
/* 232 */     { onApplicationFailedEvent(); }
/*     */   
/*     */   }
/*     */   
/*     */   private void onApplicationStartingEvent(ApplicationStartingEvent event) {
/* 237 */     this.loggingSystem = LoggingSystem.get(event.getSpringApplication().getClassLoader());
/* 238 */     this.loggingSystem.beforeInitialize();
/*     */   }
/*     */   
/*     */   private void onApplicationEnvironmentPreparedEvent(ApplicationEnvironmentPreparedEvent event) {
/* 242 */     SpringApplication springApplication = event.getSpringApplication();
/* 243 */     if (this.loggingSystem == null) {
/* 244 */       this.loggingSystem = LoggingSystem.get(springApplication.getClassLoader());
/*     */     }
/* 246 */     initialize(event.getEnvironment(), springApplication.getClassLoader());
/*     */   }
/*     */   
/*     */   private void onApplicationPreparedEvent(ApplicationPreparedEvent event) {
/* 250 */     ConfigurableApplicationContext applicationContext = event.getApplicationContext();
/* 251 */     ConfigurableListableBeanFactory beanFactory = applicationContext.getBeanFactory();
/* 252 */     if (!beanFactory.containsBean("springBootLoggingSystem")) {
/* 253 */       beanFactory.registerSingleton("springBootLoggingSystem", this.loggingSystem);
/*     */     }
/* 255 */     if (this.logFile != null && !beanFactory.containsBean("springBootLogFile")) {
/* 256 */       beanFactory.registerSingleton("springBootLogFile", this.logFile);
/*     */     }
/* 258 */     if (this.loggerGroups != null && !beanFactory.containsBean("springBootLoggerGroups")) {
/* 259 */       beanFactory.registerSingleton("springBootLoggerGroups", this.loggerGroups);
/*     */     }
/* 261 */     if (!beanFactory.containsBean("springBootLoggingLifecycle") && applicationContext.getParent() == null) {
/* 262 */       beanFactory.registerSingleton("springBootLoggingLifecycle", new Lifecycle());
/*     */     }
/*     */   }
/*     */   
/*     */   private void onContextClosedEvent(ContextClosedEvent event) {
/* 267 */     ApplicationContext applicationContext = event.getApplicationContext();
/* 268 */     if (applicationContext.getParent() != null || applicationContext.containsBean("springBootLoggingLifecycle")) {
/*     */       return;
/*     */     }
/* 271 */     cleanupLoggingSystem();
/*     */   }
/*     */   
/*     */   void cleanupLoggingSystem() {
/* 275 */     if (this.loggingSystem != null) {
/* 276 */       this.loggingSystem.cleanUp();
/*     */     }
/*     */   }
/*     */   
/*     */   private void onApplicationFailedEvent() {
/* 281 */     cleanupLoggingSystem();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize(ConfigurableEnvironment environment, ClassLoader classLoader) {
/* 291 */     getLoggingSystemProperties(environment).apply();
/* 292 */     this.logFile = LogFile.get((PropertyResolver)environment);
/* 293 */     if (this.logFile != null) {
/* 294 */       this.logFile.applyToSystemProperties();
/*     */     }
/* 296 */     this.loggerGroups = new LoggerGroups(DEFAULT_GROUP_LOGGERS);
/* 297 */     initializeEarlyLoggingLevel(environment);
/* 298 */     initializeSystem(environment, this.loggingSystem, this.logFile);
/* 299 */     initializeFinalLoggingLevels(environment, this.loggingSystem);
/* 300 */     registerShutdownHookIfNecessary((Environment)environment, this.loggingSystem);
/*     */   }
/*     */   
/*     */   private LoggingSystemProperties getLoggingSystemProperties(ConfigurableEnvironment environment) {
/* 304 */     return (this.loggingSystem != null) ? this.loggingSystem.getSystemProperties(environment) : 
/* 305 */       new LoggingSystemProperties((Environment)environment);
/*     */   }
/*     */   
/*     */   private void initializeEarlyLoggingLevel(ConfigurableEnvironment environment) {
/* 309 */     if (this.parseArgs && this.springBootLogging == null) {
/* 310 */       if (isSet(environment, "debug")) {
/* 311 */         this.springBootLogging = LogLevel.DEBUG;
/*     */       }
/* 313 */       if (isSet(environment, "trace")) {
/* 314 */         this.springBootLogging = LogLevel.TRACE;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isSet(ConfigurableEnvironment environment, String property) {
/* 320 */     String value = environment.getProperty(property);
/* 321 */     return (value != null && !value.equals("false"));
/*     */   }
/*     */   
/*     */   private void initializeSystem(ConfigurableEnvironment environment, LoggingSystem system, LogFile logFile) {
/* 325 */     String logConfig = environment.getProperty("logging.config");
/* 326 */     if (StringUtils.hasLength(logConfig)) {
/* 327 */       logConfig = logConfig.strip();
/*     */     }
/*     */     try {
/* 330 */       LoggingInitializationContext initializationContext = new LoggingInitializationContext(environment);
/* 331 */       if (ignoreLogConfig(logConfig)) {
/* 332 */         system.initialize(initializationContext, null, logFile);
/*     */       } else {
/*     */         
/* 335 */         system.initialize(initializationContext, logConfig, logFile);
/*     */       }
/*     */     
/* 338 */     } catch (Throwable ex) {
/* 339 */       Throwable exceptionToReport = ex;
/* 340 */       while (exceptionToReport != null && !(exceptionToReport instanceof java.io.FileNotFoundException)) {
/* 341 */         exceptionToReport = exceptionToReport.getCause();
/*     */       }
/* 343 */       exceptionToReport = (exceptionToReport != null) ? exceptionToReport : ex;
/*     */       
/* 345 */       System.err.println("Logging system failed to initialize using configuration from '" + logConfig + "'");
/* 346 */       exceptionToReport.printStackTrace(System.err);
/* 347 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean ignoreLogConfig(String logConfig) {
/* 352 */     return (!StringUtils.hasLength(logConfig) || logConfig.startsWith("-D"));
/*     */   }
/*     */   
/*     */   private void initializeFinalLoggingLevels(ConfigurableEnvironment environment, LoggingSystem system) {
/* 356 */     bindLoggerGroups(environment);
/* 357 */     if (this.springBootLogging != null) {
/* 358 */       initializeSpringBootLogging(system, this.springBootLogging);
/*     */     }
/* 360 */     setLogLevels(system, environment);
/*     */   }
/*     */   
/*     */   private void bindLoggerGroups(ConfigurableEnvironment environment) {
/* 364 */     if (this.loggerGroups != null) {
/* 365 */       Binder binder = Binder.get((Environment)environment);
/* 366 */       Objects.requireNonNull(this.loggerGroups); binder.bind(LOGGING_GROUP, STRING_STRINGS_MAP).ifBound(this.loggerGroups::putAll);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initializeSpringBootLogging(LoggingSystem system, LogLevel springBootLogging) {
/* 379 */     BiConsumer<String, LogLevel> configurer = getLogLevelConfigurer(system);
/* 380 */     ((List)SPRING_BOOT_LOGGING_LOGGERS.getOrDefault(springBootLogging, Collections.emptyList()))
/* 381 */       .forEach(name -> configureLogLevel(name, springBootLogging, configurer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLogLevels(LoggingSystem system, ConfigurableEnvironment environment) {
/* 391 */     BiConsumer<String, LogLevel> customizer = getLogLevelConfigurer(system);
/* 392 */     Binder binder = Binder.get((Environment)environment);
/* 393 */     Map<String, LogLevel> levels = (Map<String, LogLevel>)binder.bind(LOGGING_LEVEL, STRING_LOGLEVEL_MAP).orElseGet(Collections::emptyMap);
/* 394 */     levels.forEach((name, level) -> configureLogLevel(name, level, customizer));
/*     */   }
/*     */   
/*     */   private void configureLogLevel(String name, LogLevel level, BiConsumer<String, LogLevel> configurer) {
/* 398 */     if (this.loggerGroups != null) {
/* 399 */       LoggerGroup group = this.loggerGroups.get(name);
/* 400 */       if (group != null && group.hasMembers()) {
/* 401 */         group.configureLogLevel(level, configurer);
/*     */         return;
/*     */       } 
/*     */     } 
/* 405 */     configurer.accept(name, level);
/*     */   }
/*     */   
/*     */   private BiConsumer<String, LogLevel> getLogLevelConfigurer(LoggingSystem system) {
/* 409 */     return (name, level) -> {
/*     */         try {
/*     */           name = name.equalsIgnoreCase("ROOT") ? null : name;
/*     */           
/*     */           system.setLogLevel(name, level);
/* 414 */         } catch (RuntimeException ex) {
/*     */           this.logger.error(LogMessage.format("Cannot set level '%s' for '%s'", level, name));
/*     */         } 
/*     */       };
/*     */   }
/*     */   
/*     */   private void registerShutdownHookIfNecessary(Environment environment, LoggingSystem loggingSystem) {
/* 421 */     if (((Boolean)environment.getProperty("logging.register-shutdown-hook", Boolean.class, Boolean.valueOf(true))).booleanValue()) {
/* 422 */       Runnable shutdownHandler = loggingSystem.getShutdownHandler();
/* 423 */       if (shutdownHandler != null && shutdownHookRegistered.compareAndSet(false, true)) {
/* 424 */         registerShutdownHook(shutdownHandler);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   void registerShutdownHook(Runnable shutdownHandler) {
/* 430 */     SpringApplication.getShutdownHandlers().add(shutdownHandler);
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 434 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 439 */     return this.order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSpringBootLogging(LogLevel springBootLogging) {
/* 447 */     this.springBootLogging = springBootLogging;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParseArgs(boolean parseArgs) {
/* 457 */     this.parseArgs = parseArgs;
/*     */   }
/*     */   
/*     */   private final class Lifecycle
/*     */     implements SmartLifecycle
/*     */   {
/*     */     private volatile boolean running;
/*     */     
/*     */     public void start() {
/* 466 */       this.running = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void stop() {
/* 471 */       this.running = false;
/* 472 */       LoggingApplicationListener.this.cleanupLoggingSystem();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRunning() {
/* 477 */       return this.running;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getPhase() {
/* 483 */       return -2147483647;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\logging\LoggingApplicationListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */