/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ConfigurationPropertyState
/*    */ {
/* 35 */   PRESENT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   ABSENT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   UNKNOWN;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> ConfigurationPropertyState search(Iterable<T> source, Predicate<T> predicate) {
/* 59 */     Assert.notNull(source, "'source' must not be null");
/* 60 */     Assert.notNull(predicate, "'predicate' must not be null");
/* 61 */     for (T item : source) {
/* 62 */       if (predicate.test(item)) {
/* 63 */         return PRESENT;
/*    */       }
/*    */     } 
/* 66 */     return ABSENT;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> ConfigurationPropertyState search(T[] source, int startInclusive, int endExclusive, Predicate<T> predicate) {
/* 82 */     Assert.notNull(source, "'source' must not be null");
/* 83 */     Assert.notNull(predicate, "'predicate' must not be null");
/* 84 */     for (int i = startInclusive; i < endExclusive; i++) {
/* 85 */       if (predicate.test(source[i])) {
/* 86 */         return PRESENT;
/*    */       }
/*    */     } 
/* 89 */     return ABSENT;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */