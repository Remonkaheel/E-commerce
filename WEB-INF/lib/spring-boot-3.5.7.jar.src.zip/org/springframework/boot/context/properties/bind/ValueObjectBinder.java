/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Parameter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Consumer;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.convert.ConversionException;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ValueObjectBinder
/*     */   implements DataObjectBinder
/*     */ {
/*  66 */   private static final Log logger = LogFactory.getLog(ValueObjectBinder.class);
/*     */   
/*     */   private final BindConstructorProvider constructorProvider;
/*     */   
/*     */   ValueObjectBinder(BindConstructorProvider constructorProvider) {
/*  71 */     this.constructorProvider = constructorProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bind(ConfigurationPropertyName name, Bindable<T> target, Binder.Context context, DataObjectPropertyBinder propertyBinder) {
/*  77 */     ValueObject<T> valueObject = ValueObject.get(target, context, this.constructorProvider, Discoverer.LENIENT);
/*  78 */     if (valueObject == null) {
/*  79 */       return null;
/*     */     }
/*  81 */     context.pushConstructorBoundTypes(target.getType().resolve());
/*  82 */     List<ConstructorParameter> parameters = valueObject.getConstructorParameters();
/*  83 */     List<Object> args = new ArrayList(parameters.size());
/*  84 */     boolean bound = false;
/*  85 */     for (ConstructorParameter parameter : parameters) {
/*  86 */       Object arg = parameter.bind(propertyBinder);
/*  87 */       bound = (bound || arg != null);
/*  88 */       arg = (arg != null) ? arg : getDefaultValue(context, parameter);
/*  89 */       args.add(arg);
/*     */     } 
/*  91 */     context.clearConfigurationProperty();
/*  92 */     context.popConstructorBoundTypes();
/*  93 */     return bound ? valueObject.instantiate(args) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T create(Bindable<T> target, Binder.Context context) {
/*  98 */     ValueObject<T> valueObject = ValueObject.get(target, context, this.constructorProvider, Discoverer.LENIENT);
/*  99 */     if (valueObject == null) {
/* 100 */       return null;
/*     */     }
/* 102 */     List<ConstructorParameter> parameters = valueObject.getConstructorParameters();
/* 103 */     List<Object> args = new ArrayList(parameters.size());
/* 104 */     for (ConstructorParameter parameter : parameters) {
/* 105 */       args.add(getDefaultValue(context, parameter));
/*     */     }
/* 107 */     return valueObject.instantiate(args);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> void onUnableToCreateInstance(Bindable<T> target, Binder.Context context, RuntimeException exception) {
/*     */     try {
/* 113 */       ValueObject.get(target, context, this.constructorProvider, Discoverer.STRICT);
/*     */     }
/* 115 */     catch (Exception ex) {
/* 116 */       exception.addSuppressed(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private <T> T getDefaultValue(Binder.Context context, ConstructorParameter parameter) {
/* 121 */     ResolvableType type = parameter.getType();
/* 122 */     Annotation[] annotations = parameter.getAnnotations();
/* 123 */     for (Annotation annotation : annotations) {
/* 124 */       if (annotation instanceof DefaultValue) { DefaultValue defaultValueAnnotation = (DefaultValue)annotation;
/* 125 */         String[] defaultValue = defaultValueAnnotation.value();
/* 126 */         if (defaultValue.length == 0) {
/* 127 */           return getNewDefaultValueInstanceIfPossible(context, type);
/*     */         }
/* 129 */         return convertDefaultValue(context.getConverter(), defaultValue, type, annotations); }
/*     */     
/*     */     } 
/* 132 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T convertDefaultValue(BindConverter converter, String[] defaultValue, ResolvableType type, Annotation[] annotations) {
/*     */     try {
/* 138 */       return converter.convert(defaultValue, type, annotations);
/*     */     }
/* 140 */     catch (ConversionException ex) {
/*     */       
/* 142 */       if (defaultValue.length == 1) {
/* 143 */         return converter.convert(defaultValue[0], type, annotations);
/*     */       }
/* 145 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T getNewDefaultValueInstanceIfPossible(Binder.Context context, ResolvableType type) {
/* 151 */     Class<T> resolved = type.resolve();
/* 152 */     Assert.state((resolved == null || isEmptyDefaultValueAllowed(resolved)), () -> "Parameter of type " + String.valueOf(type) + " must have a non-empty default value.");
/*     */     
/* 154 */     if (resolved != null) {
/* 155 */       if (Optional.class == resolved) {
/* 156 */         return (T)Optional.empty();
/*     */       }
/* 158 */       if (Collection.class.isAssignableFrom(resolved)) {
/* 159 */         return (T)CollectionFactory.createCollection(resolved, 0);
/*     */       }
/* 161 */       if (EnumMap.class.isAssignableFrom(resolved)) {
/* 162 */         Class<?> keyType = type.asMap().resolveGeneric(new int[] { 0 });
/* 163 */         return (T)CollectionFactory.createMap(resolved, keyType, 0);
/*     */       } 
/* 165 */       if (Map.class.isAssignableFrom(resolved)) {
/* 166 */         return (T)CollectionFactory.createMap(resolved, 0);
/*     */       }
/* 168 */       if (resolved.isArray()) {
/* 169 */         return (T)Array.newInstance(resolved.getComponentType(), 0);
/*     */       }
/*     */     } 
/* 172 */     T instance = create(Bindable.of(type), context);
/* 173 */     if (instance != null) {
/* 174 */       return instance;
/*     */     }
/* 176 */     return (resolved != null) ? (T)BeanUtils.instantiateClass(resolved) : null;
/*     */   }
/*     */   
/*     */   private boolean isEmptyDefaultValueAllowed(Class<?> type) {
/* 180 */     return (Optional.class == type || isAggregate(type) || (
/* 181 */       !type.isPrimitive() && !type.isEnum() && !type.getName().startsWith("java.lang")));
/*     */   }
/*     */   
/*     */   private boolean isAggregate(Class<?> type) {
/* 185 */     return (type.isArray() || Map.class.isAssignableFrom(type) || Collection.class.isAssignableFrom(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static abstract class ValueObject<T>
/*     */   {
/* 195 */     private static final Object NONE = new Object();
/*     */     
/*     */     private final Constructor<T> constructor;
/*     */     
/*     */     protected ValueObject(Constructor<T> constructor) {
/* 200 */       this.constructor = constructor;
/*     */     }
/*     */     
/*     */     T instantiate(List<Object> args) {
/* 204 */       return (T)BeanUtils.instantiateClass(this.constructor, args.toArray());
/*     */     }
/*     */ 
/*     */     
/*     */     abstract List<ValueObjectBinder.ConstructorParameter> getConstructorParameters();
/*     */ 
/*     */     
/*     */     static <T> ValueObject<T> get(Bindable<T> bindable, Binder.Context context, BindConstructorProvider constructorProvider, ParameterNameDiscoverer parameterNameDiscoverer) {
/* 212 */       Class<T> resolvedType = bindable.getType().resolve();
/* 213 */       if (resolvedType == null || resolvedType.isEnum() || Modifier.isAbstract(resolvedType.getModifiers())) {
/* 214 */         return null;
/*     */       }
/* 216 */       Map<CacheKey, Object> cache = getCache(context);
/* 217 */       CacheKey cacheKey = new CacheKey(bindable, constructorProvider, parameterNameDiscoverer);
/* 218 */       Object<T> valueObject = (Object<T>)cache.get(cacheKey);
/* 219 */       if (valueObject == null) {
/* 220 */         valueObject = get(bindable, context, constructorProvider, parameterNameDiscoverer, resolvedType);
/* 221 */         cache.put(cacheKey, (valueObject != null) ? valueObject : NONE);
/*     */       } 
/* 223 */       return (valueObject != NONE) ? (ValueObject<T>)valueObject : null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static <T> ValueObject<T> get(Bindable<T> bindable, Binder.Context context, BindConstructorProvider constructorProvider, ParameterNameDiscoverer parameterNameDiscoverer, Class<T> resolvedType) {
/* 230 */       Constructor<?> bindConstructor = constructorProvider.getBindConstructor(bindable, context
/* 231 */           .isNestedConstructorBinding());
/* 232 */       if (bindConstructor == null) {
/* 233 */         return null;
/*     */       }
/* 235 */       if (KotlinDetector.isKotlinType(resolvedType)) {
/* 236 */         return ValueObjectBinder.KotlinValueObject.get((Constructor)bindConstructor, bindable.getType(), parameterNameDiscoverer);
/*     */       }
/*     */       
/* 239 */       return ValueObjectBinder.DefaultValueObject.get(bindConstructor, bindable.getType(), parameterNameDiscoverer);
/*     */     }
/*     */ 
/*     */     
/*     */     private static Map<CacheKey, Object> getCache(Binder.Context context) {
/* 244 */       Map<CacheKey, Object> cache = (Map<CacheKey, Object>)context.getCache().get(ValueObject.class);
/* 245 */       if (cache == null) {
/* 246 */         cache = new ConcurrentHashMap<>();
/* 247 */         context.getCache().put(ValueObject.class, cache);
/*     */       } 
/* 249 */       return cache;
/*     */     }
/*     */     private static final class CacheKey extends Record { private final Bindable<?> bindable; private final BindConstructorProvider constructorProvider; private final ParameterNameDiscoverer parameterNameDiscoverer;
/* 252 */       private CacheKey(Bindable<?> bindable, BindConstructorProvider constructorProvider, ParameterNameDiscoverer parameterNameDiscoverer) { this.bindable = bindable; this.constructorProvider = constructorProvider; this.parameterNameDiscoverer = parameterNameDiscoverer; } public final String toString() { // Byte code:
/*     */         //   0: aload_0
/*     */         //   1: <illegal opcode> toString : (Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;)Ljava/lang/String;
/*     */         //   6: areturn
/*     */         // Line number table:
/*     */         //   Java source line number -> byte code offset
/*     */         //   #252	-> 0
/*     */         // Local variable table:
/*     */         //   start	length	slot	name	descriptor
/* 252 */         //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey; } public Bindable<?> bindable() { return this.bindable; } public final int hashCode() { // Byte code:
/*     */         //   0: aload_0
/*     */         //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;)I
/*     */         //   6: ireturn
/*     */         // Line number table:
/*     */         //   Java source line number -> byte code offset
/*     */         //   #252	-> 0
/*     */         // Local variable table:
/*     */         //   start	length	slot	name	descriptor
/*     */         //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey; } public final boolean equals(Object o) { // Byte code:
/*     */         //   0: aload_0
/*     */         //   1: aload_1
/*     */         //   2: <illegal opcode> equals : (Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;Ljava/lang/Object;)Z
/*     */         //   7: ireturn
/*     */         // Line number table:
/*     */         //   Java source line number -> byte code offset
/*     */         //   #252	-> 0
/*     */         // Local variable table:
/*     */         //   start	length	slot	name	descriptor
/*     */         //   0	8	0	this	Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;
/* 252 */         //   0	8	1	o	Ljava/lang/Object; } public BindConstructorProvider constructorProvider() { return this.constructorProvider; } public ParameterNameDiscoverer parameterNameDiscoverer() { return this.parameterNameDiscoverer; } } } private static final class CacheKey extends Record { private final Bindable<?> bindable; private final BindConstructorProvider constructorProvider; private final ParameterNameDiscoverer parameterNameDiscoverer; private CacheKey(Bindable<?> bindable, BindConstructorProvider constructorProvider, ParameterNameDiscoverer parameterNameDiscoverer) { this.bindable = bindable; this.constructorProvider = constructorProvider; this.parameterNameDiscoverer = parameterNameDiscoverer; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #252	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 252 */       //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey; } public Bindable<?> bindable() { return this.bindable; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #252	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #252	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;
/* 252 */       //   0	8	1	o	Ljava/lang/Object; } public BindConstructorProvider constructorProvider() { return this.constructorProvider; } public ParameterNameDiscoverer parameterNameDiscoverer() { return this.parameterNameDiscoverer; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class KotlinValueObject<T>
/*     */     extends ValueObject<T>
/*     */   {
/* 264 */     private static final Annotation[] ANNOTATION_ARRAY = new Annotation[0];
/*     */     
/*     */     private final List<ValueObjectBinder.ConstructorParameter> constructorParameters;
/*     */ 
/*     */     
/*     */     private KotlinValueObject(Constructor<T> primaryConstructor, KFunction<T> kotlinConstructor, ResolvableType type) {
/* 270 */       super(primaryConstructor);
/* 271 */       this.constructorParameters = parseConstructorParameters(kotlinConstructor, type);
/*     */     }
/*     */ 
/*     */     
/*     */     private List<ValueObjectBinder.ConstructorParameter> parseConstructorParameters(KFunction<T> kotlinConstructor, ResolvableType type) {
/* 276 */       List<KParameter> parameters = kotlinConstructor.getParameters();
/* 277 */       List<ValueObjectBinder.ConstructorParameter> result = new ArrayList<>(parameters.size());
/* 278 */       for (KParameter parameter : parameters) {
/* 279 */         String name = getParameterName(parameter);
/*     */         
/* 281 */         ResolvableType parameterType = ResolvableType.forType(ReflectJvmMapping.getJavaType(parameter.getType()), type);
/* 282 */         Annotation[] annotations = (Annotation[])parameter.getAnnotations().toArray((Object[])ANNOTATION_ARRAY);
/* 283 */         result.add(new ValueObjectBinder.ConstructorParameter(name, parameterType, annotations));
/*     */       } 
/* 285 */       return Collections.unmodifiableList(result);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String getParameterName(KParameter parameter) {
/* 292 */       Objects.requireNonNull(parameter); return MergedAnnotations.from(parameter, (Annotation[])parameter.getAnnotations().toArray((Object[])ANNOTATION_ARRAY)).get(Name.class).getValue("value", String.class).orElseGet(parameter::getName);
/*     */     }
/*     */ 
/*     */     
/*     */     List<ValueObjectBinder.ConstructorParameter> getConstructorParameters() {
/* 297 */       return this.constructorParameters;
/*     */     }
/*     */ 
/*     */     
/*     */     static <T> ValueObjectBinder.ValueObject<T> get(Constructor<T> bindConstructor, ResolvableType type, ParameterNameDiscoverer parameterNameDiscoverer) {
/* 302 */       KFunction<T> kotlinConstructor = ReflectJvmMapping.getKotlinFunction(bindConstructor);
/* 303 */       if (kotlinConstructor != null) {
/* 304 */         return new KotlinValueObject<>(bindConstructor, kotlinConstructor, type);
/*     */       }
/* 306 */       return ValueObjectBinder.DefaultValueObject.get(bindConstructor, type, parameterNameDiscoverer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DefaultValueObject<T>
/*     */     extends ValueObject<T>
/*     */   {
/*     */     private final List<ValueObjectBinder.ConstructorParameter> constructorParameters;
/*     */ 
/*     */ 
/*     */     
/*     */     private DefaultValueObject(Constructor<T> constructor, List<ValueObjectBinder.ConstructorParameter> constructorParameters) {
/* 320 */       super(constructor);
/* 321 */       this.constructorParameters = constructorParameters;
/*     */     }
/*     */ 
/*     */     
/*     */     List<ValueObjectBinder.ConstructorParameter> getConstructorParameters() {
/* 326 */       return this.constructorParameters;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     static <T> ValueObjectBinder.ValueObject<T> get(Constructor<?> bindConstructor, ResolvableType type, ParameterNameDiscoverer parameterNameDiscoverer) {
/* 332 */       String[] names = parameterNameDiscoverer.getParameterNames(bindConstructor);
/* 333 */       if (names == null) {
/* 334 */         return null;
/*     */       }
/* 336 */       List<ValueObjectBinder.ConstructorParameter> constructorParameters = parseConstructorParameters(bindConstructor, type, names);
/* 337 */       return new DefaultValueObject<>((Constructor)bindConstructor, constructorParameters);
/*     */     }
/*     */ 
/*     */     
/*     */     private static List<ValueObjectBinder.ConstructorParameter> parseConstructorParameters(Constructor<?> constructor, ResolvableType type, String[] names) {
/* 342 */       Parameter[] parameters = constructor.getParameters();
/* 343 */       List<ValueObjectBinder.ConstructorParameter> result = new ArrayList<>(parameters.length);
/* 344 */       for (int i = 0; i < parameters.length; i++) {
/*     */ 
/*     */ 
/*     */         
/* 348 */         String name = MergedAnnotations.from(parameters[i]).get(Name.class).getValue("value", String.class).orElse(names[i]);
/* 349 */         ResolvableType parameterType = ResolvableType.forMethodParameter(new MethodParameter(constructor, i), type);
/*     */         
/* 351 */         Annotation[] annotations = parameters[i].getDeclaredAnnotations();
/* 352 */         result.add(new ValueObjectBinder.ConstructorParameter(name, parameterType, annotations));
/*     */       } 
/* 354 */       return Collections.unmodifiableList(result);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConstructorParameter
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     private final ResolvableType type;
/*     */     
/*     */     private final Annotation[] annotations;
/*     */ 
/*     */     
/*     */     ConstructorParameter(String name, ResolvableType type, Annotation[] annotations) {
/* 371 */       this.name = DataObjectPropertyName.toDashedForm(name);
/* 372 */       this.type = type;
/* 373 */       this.annotations = annotations;
/*     */     }
/*     */     
/*     */     Object bind(DataObjectPropertyBinder propertyBinder) {
/* 377 */       return propertyBinder.bindProperty(this.name, Bindable.of(this.type).withAnnotations(this.annotations));
/*     */     }
/*     */     
/*     */     Annotation[] getAnnotations() {
/* 381 */       return this.annotations;
/*     */     }
/*     */     
/*     */     ResolvableType getType() {
/* 385 */       return this.type;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Discoverer
/*     */     implements ParameterNameDiscoverer
/*     */   {
/* 395 */     private static final ParameterNameDiscoverer DEFAULT_DELEGATE = (ParameterNameDiscoverer)new DefaultParameterNameDiscoverer();
/*     */     
/* 397 */     private static final ParameterNameDiscoverer LENIENT = new Discoverer(DEFAULT_DELEGATE, message -> {
/*     */         
/*     */         }); private static final ParameterNameDiscoverer STRICT; private final ParameterNameDiscoverer delegate; private final Consumer<LogMessage> noParameterNamesHandler; static {
/* 400 */       STRICT = new Discoverer(DEFAULT_DELEGATE, message -> {
/*     */             throw new IllegalStateException(message.toString());
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Discoverer(ParameterNameDiscoverer delegate, Consumer<LogMessage> noParameterNamesHandler) {
/* 409 */       this.delegate = delegate;
/* 410 */       this.noParameterNamesHandler = noParameterNamesHandler;
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getParameterNames(Method method) {
/* 415 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getParameterNames(Constructor<?> constructor) {
/* 420 */       String[] names = this.delegate.getParameterNames(constructor);
/* 421 */       if (names != null) {
/* 422 */         return names;
/*     */       }
/* 424 */       LogMessage message = LogMessage.format("Unable to use value object binding with constructor [%s] as parameter names cannot be discovered. Ensure that the compiler uses the '-parameters' flag", constructor);
/*     */ 
/*     */ 
/*     */       
/* 428 */       this.noParameterNamesHandler.accept(message);
/* 429 */       ValueObjectBinder.logger.debug(message);
/* 430 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\ValueObjectBinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */