/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.env.MutablePropertySources;
/*    */ import org.springframework.core.env.PropertySources;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PropertySourcesDeducer
/*    */ {
/* 39 */   private static final Log logger = LogFactory.getLog(PropertySourcesDeducer.class);
/*    */   
/*    */   private final ApplicationContext applicationContext;
/*    */   
/*    */   PropertySourcesDeducer(ApplicationContext applicationContext) {
/* 44 */     this.applicationContext = applicationContext;
/*    */   }
/*    */   
/*    */   PropertySources getPropertySources() {
/* 48 */     PropertySourcesPlaceholderConfigurer configurer = getSinglePropertySourcesPlaceholderConfigurer();
/* 49 */     if (configurer != null) {
/* 50 */       return configurer.getAppliedPropertySources();
/*    */     }
/* 52 */     MutablePropertySources sources = extractEnvironmentPropertySources();
/* 53 */     Assert.state((sources != null), "Unable to obtain PropertySources from PropertySourcesPlaceholderConfigurer or Environment");
/*    */     
/* 55 */     return (PropertySources)sources;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private PropertySourcesPlaceholderConfigurer getSinglePropertySourcesPlaceholderConfigurer() {
/* 61 */     Map<String, PropertySourcesPlaceholderConfigurer> beans = this.applicationContext.getBeansOfType(PropertySourcesPlaceholderConfigurer.class, false, false);
/* 62 */     if (beans.size() == 1) {
/* 63 */       return beans.values().iterator().next();
/*    */     }
/* 65 */     if (beans.size() > 1 && logger.isWarnEnabled()) {
/* 66 */       logger.warn("Multiple PropertySourcesPlaceholderConfigurer beans registered " + String.valueOf(beans.keySet()) + ", falling back to Environment");
/*    */     }
/*    */     
/* 69 */     return null;
/*    */   }
/*    */   
/*    */   private MutablePropertySources extractEnvironmentPropertySources() {
/* 73 */     Environment environment = this.applicationContext.getEnvironment();
/* 74 */     if (environment instanceof ConfigurableEnvironment) { ConfigurableEnvironment configurableEnvironment = (ConfigurableEnvironment)environment;
/* 75 */       return configurableEnvironment.getPropertySources(); }
/*    */     
/* 77 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\PropertySourcesDeducer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */