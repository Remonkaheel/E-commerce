/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.ResolvableType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanProperties
/*     */ {
/* 152 */   private final Map<String, JavaBeanBinder.BeanProperty> properties = new LinkedHashMap<>();
/*     */   
/*     */   private final ResolvableType type;
/*     */   
/*     */   private final Class<?> resolvedType;
/*     */   
/*     */   BeanProperties(ResolvableType type, Class<?> resolvedType) {
/* 159 */     this.type = type;
/* 160 */     this.resolvedType = resolvedType;
/* 161 */     addProperties(resolvedType);
/*     */   }
/*     */   
/*     */   private void addProperties(Class<?> type) {
/* 165 */     while (type != null && !Object.class.equals(type)) {
/* 166 */       Method[] declaredMethods = getSorted(type, this::getDeclaredMethods, Method::getName);
/* 167 */       Field[] declaredFields = getSorted(type, Class::getDeclaredFields, Field::getName);
/* 168 */       addProperties(declaredMethods, declaredFields);
/* 169 */       type = type.getSuperclass();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Method[] getDeclaredMethods(Class<?> type) {
/* 174 */     Method[] methods = type.getDeclaredMethods();
/* 175 */     Set<Method> result = new LinkedHashSet<>(methods.length);
/* 176 */     for (Method method : methods) {
/* 177 */       result.add(BridgeMethodResolver.findBridgedMethod(method));
/*     */     }
/* 179 */     return result.<Method>toArray(new Method[0]);
/*     */   }
/*     */   
/*     */   private <S, E> E[] getSorted(S source, Function<S, E[]> elements, Function<E, String> name) {
/* 183 */     E[] result = elements.apply(source);
/* 184 */     Arrays.sort(result, Comparator.comparing(name));
/* 185 */     return result;
/*     */   }
/*     */   
/*     */   protected void addProperties(Method[] declaredMethods, Field[] declaredFields) {
/* 189 */     for (int i = 0; i < declaredMethods.length; i++) {
/* 190 */       if (!isCandidate(declaredMethods[i])) {
/* 191 */         declaredMethods[i] = null;
/*     */       }
/*     */     } 
/* 194 */     for (Method method : declaredMethods) {
/* 195 */       addMethodIfPossible(method, "is", 0, JavaBeanBinder.BeanProperty::addGetter);
/*     */     }
/* 197 */     for (Method method : declaredMethods) {
/* 198 */       addMethodIfPossible(method, "get", 0, JavaBeanBinder.BeanProperty::addGetter);
/*     */     }
/* 200 */     for (Method method : declaredMethods) {
/* 201 */       addMethodIfPossible(method, "set", 1, JavaBeanBinder.BeanProperty::addSetter);
/*     */     }
/* 203 */     for (Field field : declaredFields) {
/* 204 */       addField(field);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isCandidate(Method method) {
/* 209 */     int modifiers = method.getModifiers();
/* 210 */     return (!Modifier.isPrivate(modifiers) && !Modifier.isProtected(modifiers) && !Modifier.isAbstract(modifiers) && 
/* 211 */       !Modifier.isStatic(modifiers) && !method.isBridge() && 
/* 212 */       !Object.class.equals(method.getDeclaringClass()) && 
/* 213 */       !Class.class.equals(method.getDeclaringClass()) && method.getName().indexOf('$') == -1);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addMethodIfPossible(Method method, String prefix, int parameterCount, BiConsumer<JavaBeanBinder.BeanProperty, Method> consumer) {
/* 218 */     if (method != null && method.getParameterCount() == parameterCount && method.getName().startsWith(prefix) && method
/* 219 */       .getName().length() > prefix.length()) {
/* 220 */       String propertyName = Introspector.decapitalize(method.getName().substring(prefix.length()));
/* 221 */       consumer.accept(this.properties.computeIfAbsent(propertyName, this::getBeanProperty), method);
/*     */     } 
/*     */   }
/*     */   
/*     */   private JavaBeanBinder.BeanProperty getBeanProperty(String name) {
/* 226 */     return new JavaBeanBinder.BeanProperty(name, this.type);
/*     */   }
/*     */   
/*     */   private void addField(Field field) {
/* 230 */     JavaBeanBinder.BeanProperty property = this.properties.get(field.getName());
/* 231 */     if (property != null) {
/* 232 */       property.addField(field);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final ResolvableType getType() {
/* 237 */     return this.type;
/*     */   }
/*     */   
/*     */   protected final Class<?> getResolvedType() {
/* 241 */     return this.resolvedType;
/*     */   }
/*     */   
/*     */   final Map<String, JavaBeanBinder.BeanProperty> getProperties() {
/* 245 */     return this.properties;
/*     */   }
/*     */   
/*     */   static BeanProperties of(Bindable<?> bindable) {
/* 249 */     ResolvableType type = bindable.getType();
/* 250 */     Class<?> resolvedType = type.resolve(Object.class);
/* 251 */     return new BeanProperties(type, resolvedType);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\JavaBeanBinder$BeanProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */