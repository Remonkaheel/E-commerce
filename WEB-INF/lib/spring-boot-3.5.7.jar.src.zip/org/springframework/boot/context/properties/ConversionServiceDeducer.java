/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.boot.convert.ApplicationConversionService;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.converter.ConverterRegistry;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.core.convert.support.DefaultConversionService;
/*    */ import org.springframework.format.FormatterRegistry;
/*    */ import org.springframework.format.support.FormattingConversionService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConversionServiceDeducer
/*    */ {
/*    */   private final ApplicationContext applicationContext;
/*    */   
/*    */   ConversionServiceDeducer(ApplicationContext applicationContext) {
/* 42 */     this.applicationContext = applicationContext;
/*    */   }
/*    */   
/*    */   List<ConversionService> getConversionServices() {
/* 46 */     if (hasUserDefinedConfigurationServiceBean()) {
/* 47 */       return Collections.singletonList((ConversionService)this.applicationContext
/* 48 */           .getBean("conversionService", ConversionService.class));
/*    */     }
/* 50 */     ApplicationContext applicationContext = this.applicationContext; if (applicationContext instanceof ConfigurableApplicationContext) { ConfigurableApplicationContext configurableContext = (ConfigurableApplicationContext)applicationContext;
/* 51 */       return getConversionServices(configurableContext); }
/*    */     
/* 53 */     return null;
/*    */   }
/*    */   
/*    */   private List<ConversionService> getConversionServices(ConfigurableApplicationContext applicationContext) {
/* 57 */     List<ConversionService> conversionServices = new ArrayList<>();
/* 58 */     FormattingConversionService beansConverterService = new FormattingConversionService();
/* 59 */     Map<String, Object> converterBeans = addBeans(applicationContext, beansConverterService);
/* 60 */     if (!converterBeans.isEmpty()) {
/* 61 */       conversionServices.add(beansConverterService);
/*    */     }
/* 63 */     if (applicationContext.getBeanFactory().getConversionService() != null) {
/* 64 */       conversionServices.add(applicationContext.getBeanFactory().getConversionService());
/*    */     }
/* 66 */     if (!converterBeans.isEmpty())
/*    */     {
/*    */ 
/*    */ 
/*    */       
/* 71 */       conversionServices.add(ApplicationConversionService.getSharedInstance());
/*    */     }
/* 73 */     return conversionServices;
/*    */   }
/*    */ 
/*    */   
/*    */   private Map<String, Object> addBeans(ConfigurableApplicationContext applicationContext, FormattingConversionService converterService) {
/* 78 */     DefaultConversionService.addCollectionConverters((ConverterRegistry)converterService);
/* 79 */     converterService.addConverter((GenericConverter)new ConfigurationPropertiesCharSequenceToObjectConverter((ConversionService)converterService));
/* 80 */     return ApplicationConversionService.addBeans((FormatterRegistry)converterService, (ListableBeanFactory)applicationContext.getBeanFactory(), "org.springframework.boot.context.properties.ConfigurationPropertiesBinding");
/*    */   }
/*    */ 
/*    */   
/*    */   private boolean hasUserDefinedConfigurationServiceBean() {
/* 85 */     String beanName = "conversionService";
/* 86 */     return (this.applicationContext.containsBean(beanName) && this.applicationContext.getAutowireCapableBeanFactory()
/* 87 */       .isTypeMatch(beanName, ConversionService.class));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConversionServiceDeducer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */