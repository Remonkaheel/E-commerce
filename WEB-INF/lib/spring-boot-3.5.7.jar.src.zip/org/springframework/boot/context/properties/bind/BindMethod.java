/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum BindMethod
/*    */ {
/* 30 */   JAVA_BEAN,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   VALUE_OBJECT;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\BindMethod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */