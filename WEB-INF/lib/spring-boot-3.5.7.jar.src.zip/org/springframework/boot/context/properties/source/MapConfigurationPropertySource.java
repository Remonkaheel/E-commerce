/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.MapPropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapConfigurationPropertySource
/*     */   implements IterableConfigurationPropertySource
/*     */ {
/*  38 */   private static final PropertyMapper[] DEFAULT_MAPPERS = new PropertyMapper[] { DefaultPropertyMapper.INSTANCE };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapConfigurationPropertySource() {
/*  48 */     this(Collections.emptyMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   private final Map<String, Object> source = new LinkedHashMap<>(); public MapConfigurationPropertySource(Map<?, ?> map) {
/*  58 */     MapPropertySource mapPropertySource = new MapPropertySource("source", this.source);
/*  59 */     this.delegate = new SpringIterableConfigurationPropertySource((EnumerablePropertySource<?>)mapPropertySource, false, DEFAULT_MAPPERS);
/*  60 */     putAll(map);
/*     */   }
/*     */ 
/*     */   
/*     */   private final IterableConfigurationPropertySource delegate;
/*     */ 
/*     */   
/*     */   public void putAll(Map<?, ?> map) {
/*  68 */     Assert.notNull(map, "'map' must not be null");
/*  69 */     assertNotReadOnlySystemAttributesMap(map);
/*  70 */     map.forEach(this::put);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Object name, Object value) {
/*  79 */     this.source.put((name != null) ? name.toString() : null, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getUnderlyingSource() {
/*  84 */     return this.source;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName name) {
/*  89 */     return this.delegate.getConfigurationProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<ConfigurationPropertyName> iterator() {
/*  94 */     return this.delegate.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<ConfigurationPropertyName> stream() {
/*  99 */     return this.delegate.stream();
/*     */   }
/*     */   
/*     */   private void assertNotReadOnlySystemAttributesMap(Map<?, ?> map) {
/*     */     try {
/* 104 */       map.size();
/*     */     }
/* 106 */     catch (UnsupportedOperationException ex) {
/* 107 */       throw new IllegalArgumentException("Security restricted maps are not supported", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\MapConfigurationPropertySource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */