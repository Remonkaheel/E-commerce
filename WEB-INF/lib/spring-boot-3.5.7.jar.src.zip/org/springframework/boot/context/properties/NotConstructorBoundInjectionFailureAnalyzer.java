/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.springframework.beans.factory.InjectionPoint;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*    */ import org.springframework.boot.context.properties.bind.BindMethod;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.boot.diagnostics.analyzer.AbstractInjectionFailureAnalyzer;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.annotation.MergedAnnotations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NotConstructorBoundInjectionFailureAnalyzer
/*    */   extends AbstractInjectionFailureAnalyzer<NoSuchBeanDefinitionException>
/*    */   implements Ordered
/*    */ {
/*    */   public int getOrder() {
/* 44 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, NoSuchBeanDefinitionException cause, String description) {
/* 49 */     InjectionPoint injectionPoint = findInjectionPoint(rootFailure);
/* 50 */     if (isConstructorBindingConfigurationProperties(injectionPoint)) {
/* 51 */       String simpleName = injectionPoint.getMember().getDeclaringClass().getSimpleName();
/*    */ 
/*    */       
/* 54 */       String action = "Update your configuration so that " + simpleName + " is defined via @" + ConfigurationPropertiesScan.class.getSimpleName() + " or @" + EnableConfigurationProperties.class.getSimpleName() + ".";
/* 55 */       return new FailureAnalysis(simpleName + " is annotated with @" + simpleName + " but it is defined as a regular bean which caused dependency injection to fail.", 
/* 56 */           action, (Throwable)cause);
/*    */     } 
/*    */ 
/*    */     
/* 60 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   private boolean isConstructorBindingConfigurationProperties(InjectionPoint injectionPoint) {
/*    */     // Byte code:
/*    */     //   0: aload_1
/*    */     //   1: ifnull -> 33
/*    */     //   4: aload_1
/*    */     //   5: invokevirtual getMember : ()Ljava/lang/reflect/Member;
/*    */     //   8: astore_3
/*    */     //   9: aload_3
/*    */     //   10: instanceof java/lang/reflect/Constructor
/*    */     //   13: ifeq -> 33
/*    */     //   16: aload_3
/*    */     //   17: checkcast java/lang/reflect/Constructor
/*    */     //   20: astore_2
/*    */     //   21: aload_0
/*    */     //   22: aload_2
/*    */     //   23: invokevirtual isConstructorBindingConfigurationProperties : (Ljava/lang/reflect/Constructor;)Z
/*    */     //   26: ifeq -> 33
/*    */     //   29: iconst_1
/*    */     //   30: goto -> 34
/*    */     //   33: iconst_0
/*    */     //   34: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #65	-> 0
/*    */     //   #64	-> 4
/*    */     //   #65	-> 23
/*    */     //   #64	-> 34
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   21	12	2	constructor	Ljava/lang/reflect/Constructor;
/*    */     //   0	35	0	this	Lorg/springframework/boot/context/properties/NotConstructorBoundInjectionFailureAnalyzer;
/*    */     //   0	35	1	injectionPoint	Lorg/springframework/beans/factory/InjectionPoint;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   21	12	2	constructor	Ljava/lang/reflect/Constructor<*>;
/*    */   }
/*    */   
/*    */   private boolean isConstructorBindingConfigurationProperties(Constructor<?> constructor) {
/* 69 */     Class<?> declaringClass = constructor.getDeclaringClass();
/* 70 */     BindMethod bindMethod = ConfigurationPropertiesBean.deduceBindMethod(declaringClass);
/* 71 */     return (MergedAnnotations.from(declaringClass, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY)
/* 72 */       .isPresent(ConfigurationProperties.class) && bindMethod == BindMethod.VALUE_OBJECT);
/*    */   }
/*    */   
/*    */   private InjectionPoint findInjectionPoint(Throwable failure) {
/* 76 */     UnsatisfiedDependencyException unsatisfiedDependencyException = (UnsatisfiedDependencyException)findCause(failure, UnsatisfiedDependencyException.class);
/*    */     
/* 78 */     if (unsatisfiedDependencyException == null) {
/* 79 */       return null;
/*    */     }
/* 81 */     return unsatisfiedDependencyException.getInjectionPoint();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\NotConstructorBoundInjectionFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */