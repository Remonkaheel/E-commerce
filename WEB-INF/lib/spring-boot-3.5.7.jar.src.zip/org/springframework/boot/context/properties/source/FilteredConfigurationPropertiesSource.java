/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FilteredConfigurationPropertiesSource
/*    */   implements ConfigurationPropertySource
/*    */ {
/*    */   private final ConfigurationPropertySource source;
/*    */   private final Predicate<ConfigurationPropertyName> filter;
/*    */   
/*    */   FilteredConfigurationPropertiesSource(ConfigurationPropertySource source, Predicate<ConfigurationPropertyName> filter) {
/* 37 */     Assert.notNull(source, "'source' must not be null");
/* 38 */     Assert.notNull(filter, "'filter' must not be null");
/* 39 */     this.source = source;
/* 40 */     this.filter = filter;
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName name) {
/* 45 */     boolean filtered = getFilter().test(name);
/* 46 */     return filtered ? getSource().getConfigurationProperty(name) : null;
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/* 51 */     ConfigurationPropertyState result = this.source.containsDescendantOf(name);
/* 52 */     if (result == ConfigurationPropertyState.PRESENT)
/*    */     {
/* 54 */       return ConfigurationPropertyState.UNKNOWN;
/*    */     }
/* 56 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getUnderlyingSource() {
/* 61 */     return this.source.getUnderlyingSource();
/*    */   }
/*    */   
/*    */   protected ConfigurationPropertySource getSource() {
/* 65 */     return this.source;
/*    */   }
/*    */   
/*    */   protected Predicate<ConfigurationPropertyName> getFilter() {
/* 69 */     return this.filter;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     return this.source.toString() + " (filtered)";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\FilteredConfigurationPropertiesSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */