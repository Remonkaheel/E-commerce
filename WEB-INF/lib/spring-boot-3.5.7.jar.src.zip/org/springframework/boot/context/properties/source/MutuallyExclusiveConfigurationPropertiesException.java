/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MutuallyExclusiveConfigurationPropertiesException
/*     */   extends RuntimeException
/*     */ {
/*     */   private final Set<String> configuredNames;
/*     */   private final Set<String> mutuallyExclusiveNames;
/*     */   
/*     */   public MutuallyExclusiveConfigurationPropertiesException(Collection<String> configuredNames, Collection<String> mutuallyExclusiveNames) {
/*  55 */     this(asSet(configuredNames), asSet(mutuallyExclusiveNames));
/*     */   }
/*     */ 
/*     */   
/*     */   private MutuallyExclusiveConfigurationPropertiesException(Set<String> configuredNames, Set<String> mutuallyExclusiveNames) {
/*  60 */     super(buildMessage(mutuallyExclusiveNames, configuredNames));
/*  61 */     this.configuredNames = configuredNames;
/*  62 */     this.mutuallyExclusiveNames = mutuallyExclusiveNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getConfiguredNames() {
/*  70 */     return this.configuredNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getMutuallyExclusiveNames() {
/*  78 */     return this.mutuallyExclusiveNames;
/*     */   }
/*     */   
/*     */   private static Set<String> asSet(Collection<String> collection) {
/*  82 */     return (collection != null) ? new LinkedHashSet<>(collection) : null;
/*     */   }
/*     */   
/*     */   private static String buildMessage(Set<String> mutuallyExclusiveNames, Set<String> configuredNames) {
/*  86 */     Assert.isTrue((configuredNames != null && configuredNames.size() > 1), "'configuredNames' must contain 2 or more names");
/*     */     
/*  88 */     Assert.isTrue((mutuallyExclusiveNames != null && mutuallyExclusiveNames.size() > 1), "'mutuallyExclusiveNames' must contain 2 or more names");
/*     */     
/*  90 */     return "The configuration properties '" + String.join(", ", (Iterable)mutuallyExclusiveNames) + "' are mutually exclusive and '" + 
/*  91 */       String.join(", ", (Iterable)configuredNames) + "' have been configured together";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void throwIfMultipleNonNullValuesIn(Consumer<Map<String, Object>> entries) {
/* 101 */     throwIfMultipleMatchingValuesIn(entries, Objects::nonNull);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <V> void throwIfMultipleMatchingValuesIn(Consumer<Map<String, V>> entries, Predicate<V> predicate) {
/* 113 */     Map<String, V> map = new LinkedHashMap<>();
/* 114 */     entries.accept(map);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     Set<String> configuredNames = (Set<String>)map.entrySet().stream().filter(entry -> predicate.test(entry.getValue())).map(Map.Entry::getKey).collect(Collectors.toCollection(LinkedHashSet::new));
/* 120 */     if (configuredNames.size() > 1)
/* 121 */       throw new MutuallyExclusiveConfigurationPropertiesException(configuredNames, map.keySet()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\MutuallyExclusiveConfigurationPropertiesException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */