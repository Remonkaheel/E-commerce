/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidConfigurationPropertyNameException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final CharSequence name;
/*    */   private final List<Character> invalidCharacters;
/*    */   
/*    */   public InvalidConfigurationPropertyNameException(CharSequence name, List<Character> invalidCharacters) {
/* 34 */     super("Configuration property name '" + String.valueOf(name) + "' is not valid");
/* 35 */     this.name = name;
/* 36 */     this.invalidCharacters = invalidCharacters;
/*    */   }
/*    */   
/*    */   public List<Character> getInvalidCharacters() {
/* 40 */     return this.invalidCharacters;
/*    */   }
/*    */   
/*    */   public CharSequence getName() {
/* 44 */     return this.name;
/*    */   }
/*    */   
/*    */   public static void throwIfHasInvalidChars(CharSequence name, List<Character> invalidCharacters) {
/* 48 */     if (!invalidCharacters.isEmpty())
/* 49 */       throw new InvalidConfigurationPropertyNameException(name, invalidCharacters); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\InvalidConfigurationPropertyNameException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */