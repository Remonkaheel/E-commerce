/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface CachingConfigurationPropertySource
/*    */ {
/*    */   ConfigurationPropertyCaching getCaching();
/*    */   
/*    */   static ConfigurationPropertyCaching find(ConfigurationPropertySource source) {
/* 40 */     if (source instanceof CachingConfigurationPropertySource) { CachingConfigurationPropertySource cachingSource = (CachingConfigurationPropertySource)source;
/* 41 */       return cachingSource.getCaching(); }
/*    */     
/* 43 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\CachingConfigurationPropertySource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */