/*      */ package org.springframework.boot.context.properties.source;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.IntFunction;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ConfigurationPropertyName
/*      */   implements Comparable<ConfigurationPropertyName>
/*      */ {
/*      */   private static final String EMPTY_STRING = "";
/*   62 */   public static final ConfigurationPropertyName EMPTY = new ConfigurationPropertyName(Elements.EMPTY);
/*      */   
/*      */   private final Elements elements;
/*      */   
/*      */   private final CharSequence[] uniformElements;
/*      */   
/*      */   private int hashCode;
/*      */   
/*   70 */   private String[] string = new String[(ToStringFormat.values()).length];
/*      */   
/*      */   private Boolean hasDashedElement;
/*      */   
/*      */   private ConfigurationPropertyName systemEnvironmentLegacyName;
/*      */   
/*      */   private ConfigurationPropertyName(Elements elements) {
/*   77 */     this.elements = elements;
/*   78 */     this.uniformElements = new CharSequence[elements.getSize()];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*   86 */     return (this.elements.getSize() == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLastElementIndexed() {
/*   94 */     int size = getNumberOfElements();
/*   95 */     return (size > 0 && isIndexed(size - 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasIndexedElement() {
/*  104 */     for (int i = 0; i < getNumberOfElements(); i++) {
/*  105 */       if (isIndexed(i)) {
/*  106 */         return true;
/*      */       }
/*      */     } 
/*  109 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isIndexed(int elementIndex) {
/*  118 */     return this.elements.getType(elementIndex).isIndexed();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNumericIndex(int elementIndex) {
/*  127 */     return (this.elements.getType(elementIndex) == ElementType.NUMERICALLY_INDEXED);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLastElement(Form form) {
/*  136 */     int size = getNumberOfElements();
/*  137 */     return (size != 0) ? getElement(size - 1, form) : "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getElement(int elementIndex, Form form) {
/*  147 */     CharSequence element = this.elements.get(elementIndex);
/*  148 */     ElementType type = this.elements.getType(elementIndex);
/*  149 */     if (type.isIndexed()) {
/*  150 */       return element.toString();
/*      */     }
/*  152 */     if (form == Form.ORIGINAL) {
/*  153 */       if (type != ElementType.NON_UNIFORM) {
/*  154 */         return element.toString();
/*      */       }
/*  156 */       return convertToOriginalForm(element).toString();
/*      */     } 
/*  158 */     if (form == Form.DASHED) {
/*  159 */       if (type == ElementType.UNIFORM || type == ElementType.DASHED) {
/*  160 */         return element.toString();
/*      */       }
/*  162 */       return convertToDashedElement(element).toString();
/*      */     } 
/*  164 */     CharSequence uniformElement = this.uniformElements[elementIndex];
/*  165 */     if (uniformElement == null) {
/*  166 */       uniformElement = (type != ElementType.UNIFORM) ? convertToUniformElement(element) : element;
/*  167 */       this.uniformElements[elementIndex] = uniformElement.toString();
/*      */     } 
/*  169 */     return uniformElement.toString();
/*      */   }
/*      */   
/*      */   private CharSequence convertToOriginalForm(CharSequence element) {
/*  173 */     return convertElement(element, false, (ch, i) -> 
/*  174 */         (ch == '_' || ElementsParser.isValidChar(Character.toLowerCase(ch), i)));
/*      */   }
/*      */   
/*      */   private CharSequence convertToDashedElement(CharSequence element) {
/*  178 */     return convertElement(element, true, ElementsParser::isValidChar);
/*      */   }
/*      */   
/*      */   private CharSequence convertToUniformElement(CharSequence element) {
/*  182 */     return convertElement(element, true, (ch, i) -> ElementsParser.isAlphaNumeric(ch));
/*      */   }
/*      */   
/*      */   private CharSequence convertElement(CharSequence element, boolean lowercase, ElementCharPredicate filter) {
/*  186 */     StringBuilder result = new StringBuilder(element.length());
/*  187 */     for (int i = 0; i < element.length(); i++) {
/*  188 */       char ch = lowercase ? Character.toLowerCase(element.charAt(i)) : element.charAt(i);
/*  189 */       if (filter.test(ch, i)) {
/*  190 */         result.append(ch);
/*      */       }
/*      */     } 
/*  193 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfElements() {
/*  201 */     return this.elements.getSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConfigurationPropertyName append(String suffix) {
/*  211 */     if (!StringUtils.hasLength(suffix)) {
/*  212 */       return this;
/*      */     }
/*  214 */     Elements additionalElements = probablySingleElementOf(suffix);
/*  215 */     return new ConfigurationPropertyName(this.elements.append(additionalElements));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConfigurationPropertyName append(ConfigurationPropertyName suffix) {
/*  225 */     if (suffix == null) {
/*  226 */       return this;
/*      */     }
/*  228 */     return new ConfigurationPropertyName(this.elements.append(suffix.elements));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConfigurationPropertyName getParent() {
/*  237 */     int numberOfElements = getNumberOfElements();
/*  238 */     return (numberOfElements <= 1) ? EMPTY : chop(numberOfElements - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConfigurationPropertyName chop(int size) {
/*  249 */     if (size >= getNumberOfElements()) {
/*  250 */       return this;
/*      */     }
/*  252 */     return new ConfigurationPropertyName(this.elements.chop(size));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConfigurationPropertyName subName(int offset) {
/*  264 */     if (offset == 0) {
/*  265 */       return this;
/*      */     }
/*  267 */     if (offset == getNumberOfElements()) {
/*  268 */       return EMPTY;
/*      */     }
/*  270 */     if (offset < 0 || offset > getNumberOfElements()) {
/*  271 */       throw new IndexOutOfBoundsException("Offset: " + offset + ", NumberOfElements: " + getNumberOfElements());
/*      */     }
/*  273 */     return new ConfigurationPropertyName(this.elements.subElements(offset));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isParentOf(ConfigurationPropertyName name) {
/*  282 */     Assert.notNull(name, "'name' must not be null");
/*  283 */     if (getNumberOfElements() != name.getNumberOfElements() - 1) {
/*  284 */       return false;
/*      */     }
/*  286 */     return isAncestorOf(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAncestorOf(ConfigurationPropertyName name) {
/*  296 */     Assert.notNull(name, "'name' must not be null");
/*  297 */     if (getNumberOfElements() >= name.getNumberOfElements()) {
/*  298 */       return false;
/*      */     }
/*  300 */     return endsWithElementsEqualTo(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public int compareTo(ConfigurationPropertyName other) {
/*  305 */     return compare(this, other);
/*      */   }
/*      */   
/*      */   private int compare(ConfigurationPropertyName n1, ConfigurationPropertyName n2) {
/*  309 */     int l1 = n1.getNumberOfElements();
/*  310 */     int l2 = n2.getNumberOfElements();
/*  311 */     int i1 = 0;
/*  312 */     int i2 = 0;
/*  313 */     while (i1 < l1 || i2 < l2) {
/*      */       try {
/*  315 */         ElementType type1 = (i1 < l1) ? n1.elements.getType(i1) : null;
/*  316 */         ElementType type2 = (i2 < l2) ? n2.elements.getType(i2) : null;
/*  317 */         String e1 = (i1 < l1) ? n1.getElement(i1++, Form.UNIFORM) : null;
/*  318 */         String e2 = (i2 < l2) ? n2.getElement(i2++, Form.UNIFORM) : null;
/*  319 */         int result = compare(e1, type1, e2, type2);
/*  320 */         if (result != 0) {
/*  321 */           return result;
/*      */         }
/*      */       }
/*  324 */       catch (ArrayIndexOutOfBoundsException ex) {
/*  325 */         throw new RuntimeException(ex);
/*      */       } 
/*      */     } 
/*  328 */     return 0;
/*      */   }
/*      */   
/*      */   private int compare(String e1, ElementType type1, String e2, ElementType type2) {
/*  332 */     if (e1 == null) {
/*  333 */       return -1;
/*      */     }
/*  335 */     if (e2 == null) {
/*  336 */       return 1;
/*      */     }
/*  338 */     int result = Boolean.compare(type2.isIndexed(), type1.isIndexed());
/*  339 */     if (result != 0) {
/*  340 */       return result;
/*      */     }
/*  342 */     if (type1 == ElementType.NUMERICALLY_INDEXED && type2 == ElementType.NUMERICALLY_INDEXED) {
/*  343 */       long v1 = Long.parseLong(e1);
/*  344 */       long v2 = Long.parseLong(e2);
/*  345 */       return Long.compare(v1, v2);
/*      */     } 
/*  347 */     return e1.compareTo(e2);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/*  352 */     if (obj == this) {
/*  353 */       return true;
/*      */     }
/*  355 */     if (obj == null || obj.getClass() != getClass()) {
/*  356 */       return false;
/*      */     }
/*  358 */     ConfigurationPropertyName other = (ConfigurationPropertyName)obj;
/*  359 */     if (getNumberOfElements() != other.getNumberOfElements()) {
/*  360 */       return false;
/*      */     }
/*  362 */     if (this.elements.canShortcutWithSource(ElementType.UNIFORM) && other.elements
/*  363 */       .canShortcutWithSource(ElementType.UNIFORM)) {
/*  364 */       return toString().equals(other.toString());
/*      */     }
/*  366 */     if (hashCode() != other.hashCode()) {
/*  367 */       return false;
/*      */     }
/*  369 */     if (toStringMatches(toString(), other.toString())) {
/*  370 */       return true;
/*      */     }
/*  372 */     return endsWithElementsEqualTo(other);
/*      */   }
/*      */   
/*      */   private boolean toStringMatches(String s1, String s2) {
/*  376 */     return (s1.hashCode() == s2.hashCode() && s1.equals(s2));
/*      */   }
/*      */   
/*      */   private boolean endsWithElementsEqualTo(ConfigurationPropertyName name) {
/*  380 */     for (int i = this.elements.getSize() - 1; i >= 0; i--) {
/*  381 */       if (elementDiffers(this.elements, name.elements, i)) {
/*  382 */         return false;
/*      */       }
/*      */     } 
/*  385 */     return true;
/*      */   }
/*      */   
/*      */   private boolean elementDiffers(Elements e1, Elements e2, int i) {
/*  389 */     ElementType type1 = e1.getType(i);
/*  390 */     ElementType type2 = e2.getType(i);
/*  391 */     if (type1.allowsFastEqualityCheck() && type2.allowsFastEqualityCheck()) {
/*  392 */       return !fastElementEquals(e1, e2, i);
/*      */     }
/*  394 */     if (type1.allowsDashIgnoringEqualityCheck() && type2.allowsDashIgnoringEqualityCheck()) {
/*  395 */       return !dashIgnoringElementEquals(e1, e2, i);
/*      */     }
/*  397 */     return !defaultElementEquals(e1, e2, i);
/*      */   }
/*      */   
/*      */   private boolean fastElementEquals(Elements e1, Elements e2, int i) {
/*  401 */     int length1 = e1.getLength(i);
/*  402 */     int length2 = e2.getLength(i);
/*  403 */     if (length1 == length2) {
/*  404 */       int i1 = 0;
/*  405 */       while (length1-- != 0) {
/*  406 */         char ch1 = e1.charAt(i, i1);
/*  407 */         char ch2 = e2.charAt(i, i1);
/*  408 */         if (ch1 != ch2) {
/*  409 */           return false;
/*      */         }
/*  411 */         i1++;
/*      */       } 
/*  413 */       return true;
/*      */     } 
/*  415 */     return false;
/*      */   }
/*      */   
/*      */   private boolean dashIgnoringElementEquals(Elements e1, Elements e2, int i) {
/*  419 */     int l1 = e1.getLength(i);
/*  420 */     int l2 = e2.getLength(i);
/*  421 */     int i1 = 0;
/*  422 */     int i2 = 0;
/*  423 */     while (i1 < l1) {
/*  424 */       if (i2 >= l2) {
/*  425 */         return remainderIsDashes(e1, i, i1);
/*      */       }
/*  427 */       char ch1 = e1.charAt(i, i1);
/*  428 */       char ch2 = e2.charAt(i, i2);
/*  429 */       if (ch1 == '-') {
/*  430 */         i1++; continue;
/*      */       } 
/*  432 */       if (ch2 == '-') {
/*  433 */         i2++; continue;
/*      */       } 
/*  435 */       if (ch1 != ch2) {
/*  436 */         return false;
/*      */       }
/*      */       
/*  439 */       i1++;
/*  440 */       i2++;
/*      */     } 
/*      */     
/*  443 */     if (i2 < l2) {
/*  444 */       if (e2.getType(i).isIndexed()) {
/*  445 */         return false;
/*      */       }
/*      */       do {
/*  448 */         char ch2 = e2.charAt(i, i2++);
/*  449 */         if (ch2 != '-') {
/*  450 */           return false;
/*      */         }
/*      */       }
/*  453 */       while (i2 < l2);
/*      */     } 
/*  455 */     return true;
/*      */   }
/*      */   
/*      */   private boolean defaultElementEquals(Elements e1, Elements e2, int i) {
/*  459 */     int l1 = e1.getLength(i);
/*  460 */     int l2 = e2.getLength(i);
/*  461 */     boolean indexed1 = e1.getType(i).isIndexed();
/*  462 */     boolean indexed2 = e2.getType(i).isIndexed();
/*  463 */     int i1 = 0;
/*  464 */     int i2 = 0;
/*  465 */     while (i1 < l1) {
/*  466 */       if (i2 >= l2) {
/*  467 */         return remainderIsNotAlphanumeric(e1, i, i1);
/*      */       }
/*  469 */       char ch1 = indexed1 ? e1.charAt(i, i1) : Character.toLowerCase(e1.charAt(i, i1));
/*  470 */       char ch2 = indexed2 ? e2.charAt(i, i2) : Character.toLowerCase(e2.charAt(i, i2));
/*  471 */       if (!indexed1 && !ElementsParser.isAlphaNumeric(ch1)) {
/*  472 */         i1++; continue;
/*      */       } 
/*  474 */       if (!indexed2 && !ElementsParser.isAlphaNumeric(ch2)) {
/*  475 */         i2++; continue;
/*      */       } 
/*  477 */       if (ch1 != ch2) {
/*  478 */         return false;
/*      */       }
/*      */       
/*  481 */       i1++;
/*  482 */       i2++;
/*      */     } 
/*      */     
/*  485 */     if (i2 < l2) {
/*  486 */       return remainderIsNotAlphanumeric(e2, i, i2);
/*      */     }
/*  488 */     return true;
/*      */   }
/*      */   
/*      */   private boolean remainderIsNotAlphanumeric(Elements elements, int element, int index) {
/*  492 */     if (elements.getType(element).isIndexed()) {
/*  493 */       return false;
/*      */     }
/*  495 */     int length = elements.getLength(element);
/*      */     while (true) {
/*  497 */       char c = Character.toLowerCase(elements.charAt(element, index++));
/*  498 */       if (ElementsParser.isAlphaNumeric(c)) {
/*  499 */         return false;
/*      */       }
/*      */       
/*  502 */       if (index >= length)
/*  503 */         return true; 
/*      */     } 
/*      */   }
/*      */   private boolean remainderIsDashes(Elements elements, int element, int index) {
/*  507 */     if (elements.getType(element).isIndexed()) {
/*  508 */       return false;
/*      */     }
/*  510 */     int length = elements.getLength(element);
/*      */     while (true) {
/*  512 */       char c = elements.charAt(element, index++);
/*  513 */       if (c != '-') {
/*  514 */         return false;
/*      */       }
/*      */       
/*  517 */       if (index >= length)
/*  518 */         return true; 
/*      */     } 
/*      */   }
/*      */   
/*      */   public int hashCode() {
/*  523 */     int hashCode = this.hashCode;
/*  524 */     Elements elements = this.elements;
/*  525 */     if (hashCode == 0 && elements.getSize() != 0) {
/*  526 */       for (int elementIndex = 0; elementIndex < elements.getSize(); elementIndex++) {
/*  527 */         hashCode = 31 * hashCode + elements.hashCode(elementIndex);
/*      */       }
/*  529 */       this.hashCode = hashCode;
/*      */     } 
/*  531 */     return hashCode;
/*      */   }
/*      */   
/*      */   ConfigurationPropertyName asSystemEnvironmentLegacyName() {
/*  535 */     ConfigurationPropertyName name = this.systemEnvironmentLegacyName;
/*  536 */     if (name == null) {
/*      */       
/*  538 */       name = ofIfValid(buildSimpleToString('.', i -> getElement(i, Form.DASHED).replace('-', '.')));
/*  539 */       this.systemEnvironmentLegacyName = (name != null) ? name : EMPTY;
/*      */     } 
/*  541 */     return (name != EMPTY) ? name : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  546 */     return toString(ToStringFormat.DEFAULT, false);
/*      */   }
/*      */   
/*      */   String toString(ToStringFormat format, boolean upperCase) {
/*  550 */     String string = this.string[format.ordinal()];
/*  551 */     if (string == null) {
/*  552 */       string = buildToString(format);
/*  553 */       this.string[format.ordinal()] = string;
/*      */     } 
/*  555 */     return !upperCase ? string : string.toUpperCase(Locale.ENGLISH);
/*      */   }
/*      */   
/*      */   private String buildToString(ToStringFormat format) {
/*  559 */     switch (format) { default: throw new IncompatibleClassChangeError();case DEFAULT: case SYSTEM_ENVIRONMENT: case LEGACY_SYSTEM_ENVIRONMENT: break; }  return 
/*      */ 
/*      */ 
/*      */       
/*  563 */       buildSimpleToString('_', i -> getElement(i, Form.ORIGINAL).replace('-', '_'));
/*      */   }
/*      */ 
/*      */   
/*      */   private String buildDefaultToString() {
/*  568 */     if (this.elements.canShortcutWithSource(ElementType.UNIFORM, ElementType.DASHED)) {
/*  569 */       return this.elements.getSource().toString();
/*      */     }
/*  571 */     int elements = getNumberOfElements();
/*  572 */     StringBuilder result = new StringBuilder(elements * 8);
/*  573 */     for (int i = 0; i < elements; i++) {
/*  574 */       boolean indexed = isIndexed(i);
/*  575 */       if (!result.isEmpty() && !indexed) {
/*  576 */         result.append('.');
/*      */       }
/*  578 */       if (indexed) {
/*  579 */         result.append('[');
/*  580 */         result.append(getElement(i, Form.ORIGINAL));
/*  581 */         result.append(']');
/*      */       } else {
/*      */         
/*  584 */         result.append(getElement(i, Form.DASHED));
/*      */       } 
/*      */     } 
/*  587 */     return result.toString();
/*      */   }
/*      */   
/*      */   private String buildSimpleToString(char joinChar, IntFunction<String> elementConverter) {
/*  591 */     StringBuilder result = new StringBuilder();
/*  592 */     for (int i = 0; i < getNumberOfElements(); i++) {
/*  593 */       if (!result.isEmpty()) {
/*  594 */         result.append(joinChar);
/*      */       }
/*  596 */       result.append(elementConverter.apply(i));
/*      */     } 
/*  598 */     return result.toString();
/*      */   }
/*      */   
/*      */   boolean hasDashedElement() {
/*  602 */     Boolean hasDashedElement = this.hasDashedElement;
/*  603 */     if (hasDashedElement != null) {
/*  604 */       return hasDashedElement.booleanValue();
/*      */     }
/*  606 */     for (int i = 0; i < getNumberOfElements(); i++) {
/*  607 */       if (getElement(i, Form.DASHED).indexOf('-') != -1) {
/*  608 */         this.hasDashedElement = Boolean.valueOf(true);
/*  609 */         return true;
/*      */       } 
/*      */     } 
/*  612 */     this.hasDashedElement = Boolean.valueOf(false);
/*  613 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValid(CharSequence name) {
/*  623 */     return (of(name, true) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ConfigurationPropertyName of(CharSequence name) {
/*  633 */     return of(name, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ConfigurationPropertyName ofIfValid(CharSequence name) {
/*  644 */     return of(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static ConfigurationPropertyName of(CharSequence name, boolean returnNullIfInvalid) {
/*  656 */     Elements elements = elementsOf(name, returnNullIfInvalid);
/*  657 */     return (elements != null) ? new ConfigurationPropertyName(elements) : null;
/*      */   }
/*      */   
/*      */   private static Elements probablySingleElementOf(CharSequence name) {
/*  661 */     return elementsOf(name, false, 1);
/*      */   }
/*      */   
/*      */   private static Elements elementsOf(CharSequence name, boolean returnNullIfInvalid) {
/*  665 */     return elementsOf(name, returnNullIfInvalid, 6);
/*      */   }
/*      */   
/*      */   private static Elements elementsOf(CharSequence name, boolean returnNullIfInvalid, int parserCapacity) {
/*  669 */     if (name == null) {
/*  670 */       Assert.isTrue(returnNullIfInvalid, "'name' must not be null");
/*  671 */       return null;
/*      */     } 
/*  673 */     if (name.isEmpty()) {
/*  674 */       return Elements.EMPTY;
/*      */     }
/*  676 */     if (name.charAt(0) == '.' || name.charAt(name.length() - 1) == '.') {
/*  677 */       if (returnNullIfInvalid) {
/*  678 */         return null;
/*      */       }
/*  680 */       throw new InvalidConfigurationPropertyNameException(name, Collections.singletonList(Character.valueOf('.')));
/*      */     } 
/*  682 */     Elements elements = (new ElementsParser(name, '.', parserCapacity)).parse();
/*  683 */     for (int i = 0; i < elements.getSize(); i++) {
/*  684 */       if (elements.getType(i) == ElementType.NON_UNIFORM) {
/*  685 */         if (returnNullIfInvalid) {
/*  686 */           return null;
/*      */         }
/*  688 */         throw new InvalidConfigurationPropertyNameException(name, getInvalidChars(elements, i));
/*      */       } 
/*      */     } 
/*  691 */     return elements;
/*      */   }
/*      */   
/*      */   private static List<Character> getInvalidChars(Elements elements, int index) {
/*  695 */     List<Character> invalidChars = new ArrayList<>();
/*  696 */     for (int charIndex = 0; charIndex < elements.getLength(index); charIndex++) {
/*  697 */       char ch = elements.charAt(index, charIndex);
/*  698 */       if (!ElementsParser.isValidChar(ch, charIndex)) {
/*  699 */         invalidChars.add(Character.valueOf(ch));
/*      */       }
/*      */     } 
/*  702 */     return invalidChars;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ConfigurationPropertyName adapt(CharSequence name, char separator) {
/*  713 */     return adapt(name, separator, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static ConfigurationPropertyName adapt(CharSequence name, char separator, Function<CharSequence, CharSequence> elementValueProcessor) {
/*  731 */     Assert.notNull(name, "Name must not be null");
/*  732 */     if (name.isEmpty()) {
/*  733 */       return EMPTY;
/*      */     }
/*  735 */     Elements elements = (new ElementsParser(name, separator)).parse(elementValueProcessor);
/*  736 */     if (elements.getSize() == 0) {
/*  737 */       return EMPTY;
/*      */     }
/*  739 */     return new ConfigurationPropertyName(elements);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Form
/*      */   {
/*  757 */     ORIGINAL,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  769 */     DASHED,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  781 */     UNIFORM;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class Elements
/*      */   {
/*  791 */     private static final int[] NO_POSITION = new int[0];
/*      */     
/*  793 */     private static final ConfigurationPropertyName.ElementType[] NO_TYPE = new ConfigurationPropertyName.ElementType[0];
/*      */     
/*  795 */     public static final Elements EMPTY = new Elements("", 0, NO_POSITION, NO_POSITION, NO_TYPE, null, null);
/*      */ 
/*      */     
/*      */     private final CharSequence source;
/*      */ 
/*      */     
/*      */     private final int size;
/*      */ 
/*      */     
/*      */     private final int[] start;
/*      */ 
/*      */     
/*      */     private final int[] end;
/*      */ 
/*      */     
/*      */     private final ConfigurationPropertyName.ElementType[] type;
/*      */ 
/*      */     
/*      */     private final int[] hashCode;
/*      */ 
/*      */     
/*      */     private final CharSequence[] resolved;
/*      */ 
/*      */ 
/*      */     
/*      */     Elements(CharSequence source, int size, int[] start, int[] end, ConfigurationPropertyName.ElementType[] type, int[] hashCode, CharSequence[] resolved) {
/*  821 */       this.source = source;
/*  822 */       this.size = size;
/*  823 */       this.start = start;
/*  824 */       this.end = end;
/*  825 */       this.type = type;
/*  826 */       this.hashCode = (hashCode != null) ? hashCode : new int[size];
/*  827 */       this.resolved = resolved;
/*      */     }
/*      */     
/*      */     Elements append(Elements additional) {
/*  831 */       int size = this.size + additional.size;
/*  832 */       ConfigurationPropertyName.ElementType[] type = new ConfigurationPropertyName.ElementType[size];
/*  833 */       int[] hashCode = new int[size];
/*  834 */       System.arraycopy(this.type, 0, type, 0, this.size);
/*  835 */       System.arraycopy(additional.type, 0, type, this.size, additional.size);
/*  836 */       System.arraycopy(this.hashCode, 0, hashCode, 0, this.size);
/*  837 */       System.arraycopy(additional.hashCode, 0, hashCode, this.size, additional.size);
/*  838 */       CharSequence[] resolved = newResolved(0, size);
/*  839 */       for (int i = 0; i < additional.size; i++) {
/*  840 */         resolved[this.size + i] = additional.get(i);
/*      */       }
/*  842 */       return new Elements(this.source, size, this.start, this.end, type, hashCode, resolved);
/*      */     }
/*      */     
/*      */     Elements chop(int size) {
/*  846 */       CharSequence[] resolved = newResolved(0, size);
/*  847 */       return new Elements(this.source, size, this.start, this.end, this.type, this.hashCode, resolved);
/*      */     }
/*      */     
/*      */     Elements subElements(int offset) {
/*  851 */       int size = this.size - offset;
/*  852 */       CharSequence[] resolved = newResolved(offset, size);
/*  853 */       int[] start = new int[size];
/*  854 */       System.arraycopy(this.start, offset, start, 0, size);
/*  855 */       int[] end = new int[size];
/*  856 */       System.arraycopy(this.end, offset, end, 0, size);
/*  857 */       ConfigurationPropertyName.ElementType[] type = new ConfigurationPropertyName.ElementType[size];
/*  858 */       System.arraycopy(this.type, offset, type, 0, size);
/*  859 */       int[] hashCode = new int[size];
/*  860 */       System.arraycopy(this.hashCode, offset, hashCode, 0, size);
/*  861 */       return new Elements(this.source, size, start, end, type, hashCode, resolved);
/*      */     }
/*      */     
/*      */     private CharSequence[] newResolved(int offset, int size) {
/*  865 */       CharSequence[] resolved = new CharSequence[size];
/*  866 */       if (this.resolved != null) {
/*  867 */         System.arraycopy(this.resolved, offset, resolved, 0, Math.min(size, this.size));
/*      */       }
/*  869 */       return resolved;
/*      */     }
/*      */     
/*      */     int getSize() {
/*  873 */       return this.size;
/*      */     }
/*      */     
/*      */     CharSequence get(int index) {
/*  877 */       if (this.resolved != null && this.resolved[index] != null) {
/*  878 */         return this.resolved[index];
/*      */       }
/*  880 */       int start = this.start[index];
/*  881 */       int end = this.end[index];
/*  882 */       return this.source.subSequence(start, end);
/*      */     }
/*      */     
/*      */     int getLength(int index) {
/*  886 */       if (this.resolved != null && this.resolved[index] != null) {
/*  887 */         return this.resolved[index].length();
/*      */       }
/*  889 */       int start = this.start[index];
/*  890 */       int end = this.end[index];
/*  891 */       return end - start;
/*      */     }
/*      */     
/*      */     char charAt(int index, int charIndex) {
/*  895 */       if (this.resolved != null && this.resolved[index] != null) {
/*  896 */         return this.resolved[index].charAt(charIndex);
/*      */       }
/*  898 */       int start = this.start[index];
/*  899 */       return this.source.charAt(start + charIndex);
/*      */     }
/*      */     
/*      */     ConfigurationPropertyName.ElementType getType(int index) {
/*  903 */       return this.type[index];
/*      */     }
/*      */     
/*      */     int hashCode(int index) {
/*  907 */       int hashCode = this.hashCode[index];
/*  908 */       if (hashCode == 0) {
/*  909 */         boolean indexed = getType(index).isIndexed();
/*  910 */         int length = getLength(index);
/*  911 */         for (int i = 0; i < length; i++) {
/*  912 */           char ch = charAt(index, i);
/*  913 */           if (!indexed) {
/*  914 */             ch = Character.toLowerCase(ch);
/*      */           }
/*  916 */           if (ConfigurationPropertyName.ElementsParser.isAlphaNumeric(ch)) {
/*  917 */             hashCode = 31 * hashCode + ch;
/*      */           }
/*      */         } 
/*  920 */         this.hashCode[index] = hashCode;
/*      */       } 
/*  922 */       return hashCode;
/*      */     }
/*      */     
/*      */     CharSequence getSource() {
/*  926 */       return this.source;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean canShortcutWithSource(ConfigurationPropertyName.ElementType requiredType) {
/*  936 */       return canShortcutWithSource(requiredType, requiredType);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean canShortcutWithSource(ConfigurationPropertyName.ElementType requiredType, ConfigurationPropertyName.ElementType alternativeType) {
/*  947 */       if (this.resolved != null) {
/*  948 */         return false;
/*      */       }
/*  950 */       for (int i = 0; i < this.size; i++) {
/*  951 */         ConfigurationPropertyName.ElementType type = this.type[i];
/*  952 */         if (type != requiredType && type != alternativeType) {
/*  953 */           return false;
/*      */         }
/*  955 */         if (i > 0 && this.end[i - 1] + 1 != this.start[i]) {
/*  956 */           return false;
/*      */         }
/*      */       } 
/*  959 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ElementsParser
/*      */   {
/*      */     private static final int DEFAULT_CAPACITY = 6;
/*      */ 
/*      */     
/*      */     private final CharSequence source;
/*      */     
/*      */     private final char separator;
/*      */     
/*      */     private int size;
/*      */     
/*      */     private int[] start;
/*      */     
/*      */     private int[] end;
/*      */     
/*      */     private ConfigurationPropertyName.ElementType[] type;
/*      */     
/*      */     private CharSequence[] resolved;
/*      */ 
/*      */     
/*      */     ElementsParser(CharSequence source, char separator) {
/*  986 */       this(source, separator, 6);
/*      */     }
/*      */     
/*      */     ElementsParser(CharSequence source, char separator, int capacity) {
/*  990 */       this.source = source;
/*  991 */       this.separator = separator;
/*  992 */       this.start = new int[capacity];
/*  993 */       this.end = new int[capacity];
/*  994 */       this.type = new ConfigurationPropertyName.ElementType[capacity];
/*      */     }
/*      */     
/*      */     ConfigurationPropertyName.Elements parse() {
/*  998 */       return parse(null);
/*      */     }
/*      */     
/*      */     ConfigurationPropertyName.Elements parse(Function<CharSequence, CharSequence> valueProcessor) {
/* 1002 */       int length = this.source.length();
/* 1003 */       int openBracketCount = 0;
/* 1004 */       int start = 0;
/* 1005 */       ConfigurationPropertyName.ElementType type = ConfigurationPropertyName.ElementType.EMPTY;
/* 1006 */       for (int i = 0; i < length; i++) {
/* 1007 */         char ch = this.source.charAt(i);
/* 1008 */         if (ch == '[') {
/* 1009 */           if (openBracketCount == 0) {
/* 1010 */             add(start, i, type, valueProcessor);
/* 1011 */             start = i + 1;
/* 1012 */             type = ConfigurationPropertyName.ElementType.NUMERICALLY_INDEXED;
/*      */           } 
/* 1014 */           openBracketCount++;
/*      */         }
/* 1016 */         else if (ch == ']') {
/* 1017 */           openBracketCount--;
/* 1018 */           if (openBracketCount == 0) {
/* 1019 */             add(start, i, type, valueProcessor);
/* 1020 */             start = i + 1;
/* 1021 */             type = ConfigurationPropertyName.ElementType.EMPTY;
/*      */           }
/*      */         
/* 1024 */         } else if (!type.isIndexed() && ch == this.separator) {
/* 1025 */           add(start, i, type, valueProcessor);
/* 1026 */           start = i + 1;
/* 1027 */           type = ConfigurationPropertyName.ElementType.EMPTY;
/*      */         } else {
/*      */           
/* 1030 */           type = updateType(type, ch, i - start);
/*      */         } 
/*      */       } 
/* 1033 */       if (openBracketCount != 0) {
/* 1034 */         type = ConfigurationPropertyName.ElementType.NON_UNIFORM;
/*      */       }
/* 1036 */       add(start, length, type, valueProcessor);
/* 1037 */       return new ConfigurationPropertyName.Elements(this.source, this.size, this.start, this.end, this.type, null, this.resolved);
/*      */     }
/*      */     
/*      */     private ConfigurationPropertyName.ElementType updateType(ConfigurationPropertyName.ElementType existingType, char ch, int index) {
/* 1041 */       if (existingType.isIndexed()) {
/* 1042 */         if (existingType == ConfigurationPropertyName.ElementType.NUMERICALLY_INDEXED && !isNumeric(ch)) {
/* 1043 */           return ConfigurationPropertyName.ElementType.INDEXED;
/*      */         }
/* 1045 */         return existingType;
/*      */       } 
/* 1047 */       if (existingType == ConfigurationPropertyName.ElementType.EMPTY && isValidChar(ch, index)) {
/* 1048 */         return (index == 0) ? ConfigurationPropertyName.ElementType.UNIFORM : ConfigurationPropertyName.ElementType.NON_UNIFORM;
/*      */       }
/* 1050 */       if (existingType == ConfigurationPropertyName.ElementType.UNIFORM && ch == '-') {
/* 1051 */         return ConfigurationPropertyName.ElementType.DASHED;
/*      */       }
/* 1053 */       if (!isValidChar(ch, index)) {
/* 1054 */         if (existingType == ConfigurationPropertyName.ElementType.EMPTY && !isValidChar(Character.toLowerCase(ch), index)) {
/* 1055 */           return ConfigurationPropertyName.ElementType.EMPTY;
/*      */         }
/* 1057 */         return ConfigurationPropertyName.ElementType.NON_UNIFORM;
/*      */       } 
/* 1059 */       return existingType;
/*      */     }
/*      */     
/*      */     private void add(int start, int end, ConfigurationPropertyName.ElementType type, Function<CharSequence, CharSequence> valueProcessor) {
/* 1063 */       if (end - start < 1 || type == ConfigurationPropertyName.ElementType.EMPTY) {
/*      */         return;
/*      */       }
/* 1066 */       if (this.start.length == this.size) {
/* 1067 */         this.start = expand(this.start);
/* 1068 */         this.end = expand(this.end);
/* 1069 */         this.type = expand(this.type);
/* 1070 */         this.resolved = expand(this.resolved);
/*      */       } 
/* 1072 */       if (valueProcessor != null) {
/* 1073 */         if (this.resolved == null) {
/* 1074 */           this.resolved = new CharSequence[this.start.length];
/*      */         }
/* 1076 */         CharSequence resolved = valueProcessor.apply(this.source.subSequence(start, end));
/* 1077 */         ConfigurationPropertyName.Elements resolvedElements = (new ElementsParser(resolved, '.')).parse();
/* 1078 */         Assert.state((resolvedElements.getSize() == 1), "Resolved element must not contain multiple elements");
/* 1079 */         this.resolved[this.size] = resolvedElements.get(0);
/* 1080 */         type = resolvedElements.getType(0);
/*      */       } 
/* 1082 */       this.start[this.size] = start;
/* 1083 */       this.end[this.size] = end;
/* 1084 */       this.type[this.size] = type;
/* 1085 */       this.size++;
/*      */     }
/*      */     
/*      */     private int[] expand(int[] src) {
/* 1089 */       int[] dest = new int[src.length + 6];
/* 1090 */       System.arraycopy(src, 0, dest, 0, src.length);
/* 1091 */       return dest;
/*      */     }
/*      */     
/*      */     private ConfigurationPropertyName.ElementType[] expand(ConfigurationPropertyName.ElementType[] src) {
/* 1095 */       ConfigurationPropertyName.ElementType[] dest = new ConfigurationPropertyName.ElementType[src.length + 6];
/* 1096 */       System.arraycopy(src, 0, dest, 0, src.length);
/* 1097 */       return dest;
/*      */     }
/*      */     
/*      */     private CharSequence[] expand(CharSequence[] src) {
/* 1101 */       if (src == null) {
/* 1102 */         return null;
/*      */       }
/* 1104 */       CharSequence[] dest = new CharSequence[src.length + 6];
/* 1105 */       System.arraycopy(src, 0, dest, 0, src.length);
/* 1106 */       return dest;
/*      */     }
/*      */     
/*      */     static boolean isValidChar(char ch, int index) {
/* 1110 */       return (isAlpha(ch) || isNumeric(ch) || (index != 0 && ch == '-'));
/*      */     }
/*      */     
/*      */     static boolean isAlphaNumeric(char ch) {
/* 1114 */       return (isAlpha(ch) || isNumeric(ch));
/*      */     }
/*      */     
/*      */     private static boolean isAlpha(char ch) {
/* 1118 */       return (ch >= 'a' && ch <= 'z');
/*      */     }
/*      */     
/*      */     private static boolean isNumeric(char ch) {
/* 1122 */       return (ch >= '0' && ch <= '9');
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private enum ElementType
/*      */   {
/* 1135 */     EMPTY(false),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1140 */     UNIFORM(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1146 */     DASHED(false),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1151 */     NON_UNIFORM(false),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1156 */     INDEXED(true),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1161 */     NUMERICALLY_INDEXED(true);
/*      */     
/*      */     private final boolean indexed;
/*      */     
/*      */     ElementType(boolean indexed) {
/* 1166 */       this.indexed = indexed;
/*      */     }
/*      */     
/*      */     public boolean isIndexed() {
/* 1170 */       return this.indexed;
/*      */     }
/*      */     
/*      */     public boolean allowsFastEqualityCheck() {
/* 1174 */       return (this == UNIFORM || this == NUMERICALLY_INDEXED);
/*      */     }
/*      */     
/*      */     public boolean allowsDashIgnoringEqualityCheck() {
/* 1178 */       return (allowsFastEqualityCheck() || this == DASHED);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   enum ToStringFormat
/*      */   {
/* 1197 */     DEFAULT, SYSTEM_ENVIRONMENT, LEGACY_SYSTEM_ENVIRONMENT;
/*      */   }
/*      */   
/*      */   private static interface ElementCharPredicate {
/*      */     boolean test(char param1Char, int param1Int);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */