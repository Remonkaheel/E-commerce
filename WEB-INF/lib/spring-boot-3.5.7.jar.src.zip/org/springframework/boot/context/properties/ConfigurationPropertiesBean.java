/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.boot.context.properties.bind.BindConstructorProvider;
/*     */ import org.springframework.boot.context.properties.bind.BindMethod;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.annotation.Validated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConfigurationPropertiesBean
/*     */ {
/*  61 */   private static final BindMethod JAVA_BEAN_BIND_METHOD = BindMethod.JAVA_BEAN;
/*     */ 
/*     */   
/*  64 */   private static final BindMethod VALUE_OBJECT_BIND_METHOD = BindMethod.VALUE_OBJECT;
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final Object instance;
/*     */   
/*     */   private final Bindable<?> bindTarget;
/*     */ 
/*     */   
/*     */   private ConfigurationPropertiesBean(String name, Object instance, Bindable<?> bindTarget) {
/*  74 */     this.name = name;
/*  75 */     this.instance = instance;
/*  76 */     this.bindTarget = bindTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  84 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getInstance() {
/*  92 */     return this.instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class<?> getType() {
/* 100 */     return this.bindTarget.getType().resolve();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationProperties getAnnotation() {
/* 110 */     return (ConfigurationProperties)this.bindTarget.getAnnotation(ConfigurationProperties.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bindable<?> asBindTarget() {
/* 119 */     return this.bindTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, ConfigurationPropertiesBean> getAll(ApplicationContext applicationContext) {
/* 131 */     Assert.notNull(applicationContext, "'applicationContext' must not be null");
/* 132 */     if (applicationContext instanceof ConfigurableApplicationContext) { ConfigurableApplicationContext configurableContext = (ConfigurableApplicationContext)applicationContext;
/* 133 */       return getAll(configurableContext); }
/*     */     
/* 135 */     Map<String, ConfigurationPropertiesBean> propertiesBeans = new LinkedHashMap<>();
/* 136 */     applicationContext.getBeansWithAnnotation(ConfigurationProperties.class).forEach((name, instance) -> {
/*     */           ConfigurationPropertiesBean propertiesBean = get(applicationContext, instance, name);
/*     */           if (propertiesBean != null) {
/*     */             propertiesBeans.put(name, propertiesBean);
/*     */           }
/*     */         });
/* 142 */     return propertiesBeans;
/*     */   }
/*     */   
/*     */   private static Map<String, ConfigurationPropertiesBean> getAll(ConfigurableApplicationContext applicationContext) {
/* 146 */     Map<String, ConfigurationPropertiesBean> propertiesBeans = new LinkedHashMap<>();
/* 147 */     ConfigurableListableBeanFactory beanFactory = applicationContext.getBeanFactory();
/* 148 */     Iterator<String> beanNames = beanFactory.getBeanNamesIterator();
/* 149 */     while (beanNames.hasNext()) {
/* 150 */       String beanName = beanNames.next();
/* 151 */       if (isConfigurationPropertiesBean(beanFactory, beanName)) {
/*     */         try {
/* 153 */           Object bean = beanFactory.getBean(beanName);
/* 154 */           ConfigurationPropertiesBean propertiesBean = get((ApplicationContext)applicationContext, bean, beanName);
/* 155 */           if (propertiesBean != null) {
/* 156 */             propertiesBeans.put(beanName, propertiesBean);
/*     */           }
/*     */         }
/* 159 */         catch (Exception exception) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 164 */     return propertiesBeans;
/*     */   }
/*     */   
/*     */   private static boolean isConfigurationPropertiesBean(ConfigurableListableBeanFactory beanFactory, String beanName) {
/*     */     try {
/* 169 */       if (beanFactory.getBeanDefinition(beanName).isAbstract()) {
/* 170 */         return false;
/*     */       }
/* 172 */       if (beanFactory.findAnnotationOnBean(beanName, ConfigurationProperties.class) != null) {
/* 173 */         return true;
/*     */       }
/* 175 */       Method factoryMethod = findFactoryMethod(beanFactory, beanName);
/* 176 */       return findMergedAnnotation(factoryMethod, ConfigurationProperties.class).isPresent();
/*     */     }
/* 178 */     catch (NoSuchBeanDefinitionException ex) {
/* 179 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConfigurationPropertiesBean get(ApplicationContext applicationContext, Object bean, String beanName) {
/* 197 */     Method factoryMethod = findFactoryMethod(applicationContext, beanName);
/* 198 */     Bindable<Object> bindTarget = createBindTarget(bean, bean.getClass(), factoryMethod);
/* 199 */     if (bindTarget == null) {
/* 200 */       return null;
/*     */     }
/* 202 */     bindTarget = bindTarget.withBindMethod(BindMethodAttribute.get(applicationContext, beanName));
/* 203 */     if (bindTarget.getBindMethod() == null && factoryMethod != null) {
/* 204 */       bindTarget = bindTarget.withBindMethod(JAVA_BEAN_BIND_METHOD);
/*     */     }
/* 206 */     if (bindTarget.getBindMethod() != VALUE_OBJECT_BIND_METHOD) {
/* 207 */       bindTarget = bindTarget.withExistingValue(bean);
/*     */     }
/* 209 */     return create(beanName, bean, bindTarget);
/*     */   }
/*     */   
/*     */   private static Method findFactoryMethod(ApplicationContext applicationContext, String beanName) {
/* 213 */     if (applicationContext instanceof ConfigurableApplicationContext) { ConfigurableApplicationContext configurableContext = (ConfigurableApplicationContext)applicationContext;
/* 214 */       return findFactoryMethod(configurableContext, beanName); }
/*     */     
/* 216 */     return null;
/*     */   }
/*     */   
/*     */   private static Method findFactoryMethod(ConfigurableApplicationContext applicationContext, String beanName) {
/* 220 */     return findFactoryMethod(applicationContext.getBeanFactory(), beanName);
/*     */   }
/*     */   
/*     */   private static Method findFactoryMethod(ConfigurableListableBeanFactory beanFactory, String beanName) {
/* 224 */     if (beanFactory.containsBeanDefinition(beanName)) {
/* 225 */       BeanDefinition beanDefinition = beanFactory.getMergedBeanDefinition(beanName);
/* 226 */       if (beanDefinition instanceof RootBeanDefinition) { RootBeanDefinition rootBeanDefinition = (RootBeanDefinition)beanDefinition;
/* 227 */         return rootBeanDefinition.getResolvedFactoryMethod(); }
/*     */     
/*     */     } 
/* 230 */     return null;
/*     */   }
/*     */   
/*     */   static ConfigurationPropertiesBean forValueObject(Class<?> beanType, String beanName) {
/* 234 */     Bindable<Object> bindTarget = createBindTarget(null, beanType, null);
/* 235 */     Assert.state((bindTarget != null && deduceBindMethod(bindTarget) == VALUE_OBJECT_BIND_METHOD), () -> "Bean '" + beanName + "' is not a @ConfigurationProperties value object");
/*     */     
/* 237 */     return create(beanName, null, bindTarget.withBindMethod(VALUE_OBJECT_BIND_METHOD));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Bindable<Object> createBindTarget(Object bean, Class<?> beanType, Method factoryMethod) {
/* 242 */     ResolvableType type = (factoryMethod != null) ? ResolvableType.forMethodReturnType(factoryMethod) : ResolvableType.forClass(beanType);
/* 243 */     Annotation[] annotations = findAnnotations(bean, beanType, factoryMethod);
/* 244 */     return (annotations != null) ? Bindable.of(type).withAnnotations(annotations) : null;
/*     */   }
/*     */   
/*     */   private static Annotation[] findAnnotations(Object instance, Class<?> type, Method factory) {
/* 248 */     ConfigurationProperties annotation = findAnnotation(instance, type, factory, ConfigurationProperties.class);
/* 249 */     if (annotation == null) {
/* 250 */       return null;
/*     */     }
/* 252 */     Validated validated = findAnnotation(instance, type, factory, Validated.class);
/* 253 */     (new Annotation[2])[0] = annotation; (new Annotation[2])[1] = (Annotation)validated; (new Annotation[1])[0] = annotation; return (validated != null) ? new Annotation[2] : new Annotation[1];
/*     */   }
/*     */ 
/*     */   
/*     */   private static <A extends Annotation> A findAnnotation(Object instance, Class<?> type, Method factory, Class<A> annotationType) {
/* 258 */     MergedAnnotation<A> annotation = MergedAnnotation.missing();
/* 259 */     if (factory != null) {
/* 260 */       annotation = findMergedAnnotation(factory, annotationType);
/*     */     }
/* 262 */     if (!annotation.isPresent()) {
/* 263 */       annotation = findMergedAnnotation(type, annotationType);
/*     */     }
/* 265 */     if (!annotation.isPresent() && AopUtils.isAopProxy(instance))
/*     */     {
/* 267 */       annotation = MergedAnnotations.from(AopUtils.getTargetClass(instance), MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(annotationType);
/*     */     }
/* 269 */     return annotation.isPresent() ? (A)annotation.synthesize() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <A extends Annotation> MergedAnnotation<A> findMergedAnnotation(AnnotatedElement element, Class<A> annotationType) {
/* 274 */     return (element != null) ? MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(annotationType) : 
/* 275 */       MergedAnnotation.missing();
/*     */   }
/*     */   
/*     */   private static ConfigurationPropertiesBean create(String name, Object instance, Bindable<Object> bindTarget) {
/* 279 */     return (bindTarget != null) ? new ConfigurationPropertiesBean(name, instance, bindTarget) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BindMethod deduceBindMethod(Class<?> type) {
/* 288 */     return deduceBindMethod(BindConstructorProvider.DEFAULT.getBindConstructor(type, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BindMethod deduceBindMethod(Bindable<Object> bindable) {
/* 297 */     return deduceBindMethod(BindConstructorProvider.DEFAULT.getBindConstructor(bindable, false));
/*     */   }
/*     */ 
/*     */   
/*     */   private static BindMethod deduceBindMethod(Constructor<?> bindConstructor) {
/* 302 */     return (bindConstructor != null) ? VALUE_OBJECT_BIND_METHOD : JAVA_BEAN_BIND_METHOD;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */