/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AggregateSupplier<T>
/*     */ {
/*     */   private final Supplier<T> supplier;
/*     */   private T supplied;
/*     */   
/*     */   public AggregateSupplier(Supplier<T> supplier) {
/* 102 */     this.supplier = supplier;
/*     */   }
/*     */   
/*     */   public T get() {
/* 106 */     if (this.supplied == null) {
/* 107 */       this.supplied = this.supplier.get();
/*     */     }
/* 109 */     return this.supplied;
/*     */   }
/*     */   
/*     */   public boolean wasSupplied() {
/* 113 */     return (this.supplied != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\AggregateBinder$AggregateSupplier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */