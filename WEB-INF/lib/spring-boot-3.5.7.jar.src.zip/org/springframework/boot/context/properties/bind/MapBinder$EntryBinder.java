/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.IterableConfigurationPropertySource;
/*     */ import org.springframework.core.ResolvableType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EntryBinder
/*     */ {
/*     */   private final ConfigurationPropertyName root;
/*     */   private final AggregateElementBinder elementBinder;
/*     */   private final ResolvableType mapType;
/*     */   private final ResolvableType keyType;
/*     */   private final ResolvableType valueType;
/*     */   private final Class<?> resolvedValueType;
/*     */   private final boolean valueTreatedAsNestedMap;
/*     */   private final Bindable<Object> bindableMapType;
/*     */   private final Bindable<Object> bindableValueType;
/*     */   
/*     */   EntryBinder(ConfigurationPropertyName root, Bindable<?> target, AggregateElementBinder elementBinder) {
/* 167 */     this.root = root;
/* 168 */     this.elementBinder = elementBinder;
/* 169 */     this.mapType = target.getType().asMap();
/* 170 */     this.keyType = this.mapType.getGeneric(new int[] { 0 });
/* 171 */     this.valueType = this.mapType.getGeneric(new int[] { 1 });
/* 172 */     this.resolvedValueType = this.valueType.resolve(Object.class);
/* 173 */     this.valueTreatedAsNestedMap = Object.class.equals(this.resolvedValueType);
/* 174 */     this.bindableMapType = Bindable.of(this.mapType);
/* 175 */     this.bindableValueType = Bindable.of(this.valueType);
/*     */   }
/*     */   
/*     */   void bindEntries(ConfigurationPropertySource source, Map<Object, Object> map) {
/* 179 */     if (source instanceof IterableConfigurationPropertySource) { IterableConfigurationPropertySource iterableSource = (IterableConfigurationPropertySource)source;
/* 180 */       for (ConfigurationPropertyName name : iterableSource) {
/* 181 */         ConfigurationPropertyName entryName = getEntryName(source, name);
/* 182 */         Object key = MapBinder.this.getContext().getConverter().convert(getKeyName(entryName), this.keyType, new java.lang.annotation.Annotation[0]);
/* 183 */         Bindable<?> valueBindable = getValueBindable(name);
/* 184 */         map.computeIfAbsent(key, k -> this.elementBinder.bind(entryName, valueBindable));
/*     */       }  }
/*     */   
/*     */   }
/*     */   
/*     */   private Bindable<?> getValueBindable(ConfigurationPropertyName name) {
/* 190 */     return (!isParentOf(name) && this.valueTreatedAsNestedMap) ? this.bindableMapType : this.bindableValueType;
/*     */   }
/*     */ 
/*     */   
/*     */   private ConfigurationPropertyName getEntryName(ConfigurationPropertySource source, ConfigurationPropertyName name) {
/* 195 */     if (Collection.class.isAssignableFrom(this.resolvedValueType) || this.valueType.isArray()) {
/* 196 */       return chopNameAtNumericIndex(name);
/*     */     }
/* 198 */     if (!isParentOf(name) && (this.valueTreatedAsNestedMap || !isScalarValue(source, name))) {
/* 199 */       return name.chop(this.root.getNumberOfElements() + 1);
/*     */     }
/* 201 */     return name;
/*     */   }
/*     */   
/*     */   private boolean isParentOf(ConfigurationPropertyName name) {
/* 205 */     return this.root.isParentOf(name);
/*     */   }
/*     */   
/*     */   private ConfigurationPropertyName chopNameAtNumericIndex(ConfigurationPropertyName name) {
/* 209 */     int start = this.root.getNumberOfElements() + 1;
/* 210 */     int size = name.getNumberOfElements();
/* 211 */     for (int i = start; i < size; i++) {
/* 212 */       if (name.isNumericIndex(i)) {
/* 213 */         return name.chop(i);
/*     */       }
/*     */     } 
/* 216 */     return name;
/*     */   }
/*     */   
/*     */   private boolean isScalarValue(ConfigurationPropertySource source, ConfigurationPropertyName name) {
/* 220 */     Class<?> resolved = this.valueType.resolve(Object.class);
/* 221 */     if (!resolved.getName().startsWith("java.lang") && !resolved.isEnum()) {
/* 222 */       return false;
/*     */     }
/* 224 */     ConfigurationProperty property = source.getConfigurationProperty(name);
/* 225 */     if (property == null) {
/* 226 */       return false;
/*     */     }
/* 228 */     Object value = property.getValue();
/* 229 */     value = MapBinder.this.getContext().getPlaceholdersResolver().resolvePlaceholders(value);
/* 230 */     return MapBinder.this.getContext().getConverter().canConvert(value, this.valueType, new java.lang.annotation.Annotation[0]);
/*     */   }
/*     */   
/*     */   private String getKeyName(ConfigurationPropertyName name) {
/* 234 */     StringBuilder result = new StringBuilder();
/* 235 */     for (int i = this.root.getNumberOfElements(); i < name.getNumberOfElements(); i++) {
/* 236 */       if (!result.isEmpty()) {
/* 237 */         result.append('.');
/*     */       }
/* 239 */       result.append(name.getElement(i, ConfigurationPropertyName.Form.ORIGINAL));
/*     */     } 
/* 241 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\MapBinder$EntryBinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */