/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface PlaceholdersResolver
/*    */ {
/*    */   public static final PlaceholdersResolver NONE;
/*    */   
/*    */   Object resolvePlaceholders(Object paramObject);
/*    */   
/*    */   static {
/* 35 */     NONE = (value -> value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\PlaceholdersResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */