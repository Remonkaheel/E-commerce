/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ConfigurationPropertyCaching
/*     */ {
/*     */   void enable();
/*     */   
/*     */   void disable();
/*     */   
/*     */   void setTimeToLive(Duration paramDuration);
/*     */   
/*     */   void clear();
/*     */   
/*     */   CacheOverride override();
/*     */   
/*     */   static ConfigurationPropertyCaching get(Environment environment) {
/*  68 */     return get(environment, (Object)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigurationPropertyCaching get(Environment environment, Object underlyingSource) {
/*  80 */     Iterable<ConfigurationPropertySource> sources = ConfigurationPropertySources.get(environment);
/*  81 */     return get(sources, underlyingSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigurationPropertyCaching get(Iterable<ConfigurationPropertySource> sources) {
/*  90 */     return get(sources, (Object)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigurationPropertyCaching get(Iterable<ConfigurationPropertySource> sources, Object underlyingSource) {
/* 103 */     Assert.notNull(sources, "'sources' must not be null");
/* 104 */     if (underlyingSource == null) {
/* 105 */       return new ConfigurationPropertySourcesCaching(sources);
/*     */     }
/* 107 */     for (ConfigurationPropertySource source : sources) {
/* 108 */       if (source.getUnderlyingSource() == underlyingSource) {
/* 109 */         ConfigurationPropertyCaching caching = CachingConfigurationPropertySource.find(source);
/* 110 */         if (caching != null) {
/* 111 */           return caching;
/*     */         }
/*     */       } 
/*     */     } 
/* 115 */     throw new IllegalStateException("Unable to find cache from configuration property sources");
/*     */   }
/*     */   
/*     */   public static interface CacheOverride extends AutoCloseable {
/*     */     void close();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyCaching.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */