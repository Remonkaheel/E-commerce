/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ActiveCacheOverride
/*     */   extends Record
/*     */   implements ConfigurationPropertyCaching.CacheOverride
/*     */ {
/*     */   private final SoftReferenceConfigurationPropertyCache<?> cache;
/*     */   private final Duration timeToLive;
/*     */   private final Instant lastAccessed;
/*     */   private final AtomicBoolean active;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #140	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #140	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #140	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   private ActiveCacheOverride(SoftReferenceConfigurationPropertyCache<?> cache, Duration timeToLive, Instant lastAccessed, AtomicBoolean active) {
/* 140 */     this.cache = cache; this.timeToLive = timeToLive; this.lastAccessed = lastAccessed; this.active = active; } public SoftReferenceConfigurationPropertyCache<?> cache() { return this.cache; } public Duration timeToLive() { return this.timeToLive; } public Instant lastAccessed() { return this.lastAccessed; } public AtomicBoolean active() { return this.active; }
/*     */ 
/*     */   
/*     */   ActiveCacheOverride(SoftReferenceConfigurationPropertyCache<?> cache) {
/* 144 */     this(cache, cache.timeToLive, cache.lastAccessed, new AtomicBoolean());
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 149 */     if (active().compareAndSet(false, true))
/* 150 */       this.cache.restore(this); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\SoftReferenceConfigurationPropertyCache$ActiveCacheOverride.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */