/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginProvider;
/*     */ import org.springframework.boot.origin.OriginTrackedValue;
/*     */ import org.springframework.core.style.ToStringCreator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConfigurationProperty
/*     */   implements OriginProvider, Comparable<ConfigurationProperty>
/*     */ {
/*     */   private final ConfigurationPropertyName name;
/*     */   private final Object value;
/*     */   private final ConfigurationPropertySource source;
/*     */   private final Origin origin;
/*     */   
/*     */   public ConfigurationProperty(ConfigurationPropertyName name, Object value, Origin origin) {
/*  46 */     this(null, name, value, origin);
/*     */   }
/*     */ 
/*     */   
/*     */   private ConfigurationProperty(ConfigurationPropertySource source, ConfigurationPropertyName name, Object value, Origin origin) {
/*  51 */     Assert.notNull(name, "'name' must not be null");
/*  52 */     Assert.notNull(value, "'value' must not be null");
/*  53 */     this.source = source;
/*  54 */     this.name = name;
/*  55 */     this.value = value;
/*  56 */     this.origin = origin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPropertySource getSource() {
/*  66 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPropertyName getName() {
/*  74 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue() {
/*  82 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Origin getOrigin() {
/*  87 */     return this.origin;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  92 */     if (this == obj) {
/*  93 */       return true;
/*     */     }
/*  95 */     if (obj == null || getClass() != obj.getClass()) {
/*  96 */       return false;
/*     */     }
/*  98 */     ConfigurationProperty other = (ConfigurationProperty)obj;
/*  99 */     boolean result = true;
/* 100 */     result = (result && ObjectUtils.nullSafeEquals(this.name, other.name));
/* 101 */     result = (result && ObjectUtils.nullSafeEquals(this.value, other.value));
/* 102 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 107 */     int result = ObjectUtils.nullSafeHashCode(this.name);
/* 108 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.value);
/* 109 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return (new ToStringCreator(this)).append("name", this.name)
/* 115 */       .append("value", this.value)
/* 116 */       .append("origin", this.origin)
/* 117 */       .toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(ConfigurationProperty other) {
/* 122 */     return this.name.compareTo(other.name);
/*     */   }
/*     */   
/*     */   static ConfigurationProperty of(ConfigurationPropertyName name, OriginTrackedValue value) {
/* 126 */     if (value == null) {
/* 127 */       return null;
/*     */     }
/* 129 */     return new ConfigurationProperty(name, value.getValue(), value.getOrigin());
/*     */   }
/*     */ 
/*     */   
/*     */   static ConfigurationProperty of(ConfigurationPropertySource source, ConfigurationPropertyName name, Object value, Origin origin) {
/* 134 */     if (value == null) {
/* 135 */       return null;
/*     */     }
/* 137 */     return new ConfigurationProperty(source, name, value, origin);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationProperty.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */