/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoundPropertiesTrackingBindHandler
/*    */   extends AbstractBindHandler
/*    */ {
/*    */   private final Consumer<ConfigurationProperty> consumer;
/*    */   
/*    */   public BoundPropertiesTrackingBindHandler(Consumer<ConfigurationProperty> consumer) {
/* 36 */     Assert.notNull(consumer, "'consumer' must not be null");
/* 37 */     this.consumer = consumer;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object onSuccess(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) {
/* 42 */     if (context.getConfigurationProperty() != null && name.equals(context.getConfigurationProperty().getName())) {
/* 43 */       this.consumer.accept(context.getConfigurationProperty());
/*    */     }
/* 45 */     return super.onSuccess(name, target, context, result);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\BoundPropertiesTrackingBindHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */