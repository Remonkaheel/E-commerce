/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.convert.ApplicationConversionService;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ConfigurationPropertiesCharSequenceToObjectConverter
/*     */   implements ConditionalGenericConverter
/*     */ {
/*  37 */   private static final TypeDescriptor STRING = TypeDescriptor.valueOf(String.class);
/*     */   
/*  39 */   private static final TypeDescriptor BYTE_ARRAY = TypeDescriptor.valueOf(byte[].class);
/*     */ 
/*     */ 
/*     */   
/*  43 */   private final ThreadLocal<Boolean> disable = new ThreadLocal<>();
/*     */ 
/*     */   
/*  46 */   private static final Set<GenericConverter.ConvertiblePair> TYPES = Collections.singleton(new GenericConverter.ConvertiblePair(CharSequence.class, Object.class));
/*     */   
/*     */   private final ConversionService conversionService;
/*     */ 
/*     */   
/*     */   ConfigurationPropertiesCharSequenceToObjectConverter(ConversionService conversionService) {
/*  52 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/*  57 */     return TYPES;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/*  62 */     if (sourceType.getType() == String.class || this.disable.get() == Boolean.TRUE) {
/*  63 */       return false;
/*     */     }
/*  65 */     this.disable.set(Boolean.TRUE);
/*     */     try {
/*  67 */       boolean canDirectlyConvertCharSequence = this.conversionService.canConvert(sourceType, targetType);
/*  68 */       if (canDirectlyConvertCharSequence && !isStringConversionBetter(sourceType, targetType)) {
/*  69 */         return false;
/*     */       }
/*  71 */       return this.conversionService.canConvert(STRING, targetType);
/*     */     } finally {
/*     */       
/*  74 */       this.disable.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isStringConversionBetter(TypeDescriptor sourceType, TypeDescriptor targetType) {
/*  86 */     ConversionService conversionService = this.conversionService; if (conversionService instanceof ApplicationConversionService) { ApplicationConversionService applicationConversionService = (ApplicationConversionService)conversionService;
/*  87 */       if (applicationConversionService.isConvertViaObjectSourceType(sourceType, targetType))
/*     */       {
/*     */         
/*  90 */         return true;
/*     */       } }
/*     */ 
/*     */ 
/*     */     
/*  95 */     return ((targetType.isArray() || targetType.isCollection()) && !targetType.equals(BYTE_ARRAY));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 100 */     return this.conversionService.convert(source.toString(), STRING, targetType);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesCharSequenceToObjectConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */