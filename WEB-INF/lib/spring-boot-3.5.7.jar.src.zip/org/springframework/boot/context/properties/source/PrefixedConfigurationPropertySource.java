/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PrefixedConfigurationPropertySource
/*    */   implements ConfigurationPropertySource
/*    */ {
/*    */   private final ConfigurationPropertySource source;
/*    */   private final ConfigurationPropertyName prefix;
/*    */   
/*    */   PrefixedConfigurationPropertySource(ConfigurationPropertySource source, String prefix) {
/* 33 */     Assert.notNull(source, "'source' must not be null");
/* 34 */     Assert.hasText(prefix, "'prefix' must not be empty");
/* 35 */     this.source = source;
/* 36 */     this.prefix = ConfigurationPropertyName.of(prefix);
/*    */   }
/*    */   
/*    */   protected final ConfigurationPropertyName getPrefix() {
/* 40 */     return this.prefix;
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName name) {
/* 45 */     ConfigurationProperty configurationProperty = this.source.getConfigurationProperty(getPrefixedName(name));
/* 46 */     if (configurationProperty == null) {
/* 47 */       return null;
/*    */     }
/* 49 */     return ConfigurationProperty.of(configurationProperty.getSource(), name, configurationProperty.getValue(), configurationProperty
/* 50 */         .getOrigin());
/*    */   }
/*    */   
/*    */   private ConfigurationPropertyName getPrefixedName(ConfigurationPropertyName name) {
/* 54 */     return this.prefix.append(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/* 59 */     return this.source.containsDescendantOf(getPrefixedName(name));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getUnderlyingSource() {
/* 64 */     return this.source.getUnderlyingSource();
/*    */   }
/*    */   
/*    */   protected ConfigurationPropertySource getSource() {
/* 68 */     return this.source;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\PrefixedConfigurationPropertySource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */