package org.springframework.boot.context.properties.bind;

import org.springframework.boot.context.properties.source.ConfigurationProperty;
import org.springframework.boot.context.properties.source.ConfigurationPropertySource;

public interface BindContext {
  Binder getBinder();
  
  int getDepth();
  
  Iterable<ConfigurationPropertySource> getSources();
  
  ConfigurationProperty getConfigurationProperty();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\BindContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */