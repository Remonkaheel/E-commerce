/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Objects;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.boot.validation.beanvalidation.MethodValidationExcludeFilter;
/*    */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*    */ import org.springframework.core.Conventions;
/*    */ import org.springframework.core.annotation.MergedAnnotation;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EnableConfigurationPropertiesRegistrar
/*    */   implements ImportBeanDefinitionRegistrar
/*    */ {
/* 42 */   private static final String METHOD_VALIDATION_EXCLUDE_FILTER_BEAN_NAME = Conventions.getQualifiedAttributeName(EnableConfigurationPropertiesRegistrar.class, "methodValidationExcludeFilter");
/*    */ 
/*    */   
/*    */   public void registerBeanDefinitions(AnnotationMetadata metadata, BeanDefinitionRegistry registry) {
/* 46 */     registerInfrastructureBeans(registry);
/* 47 */     registerMethodValidationExcludeFilter(registry);
/* 48 */     ConfigurationPropertiesBeanRegistrar beanRegistrar = new ConfigurationPropertiesBeanRegistrar(registry);
/* 49 */     Objects.requireNonNull(beanRegistrar); getTypes(metadata).forEach(beanRegistrar::register);
/*    */   }
/*    */   
/*    */   private Set<Class<?>> getTypes(AnnotationMetadata metadata) {
/* 53 */     return (Set<Class<?>>)metadata.getAnnotations()
/* 54 */       .stream(EnableConfigurationProperties.class)
/* 55 */       .flatMap(annotation -> Arrays.stream((Class<?>[][])annotation.getClassArray("value")))
/* 56 */       .filter(type -> (void.class != type))
/* 57 */       .collect(Collectors.toSet());
/*    */   }
/*    */   
/*    */   static void registerInfrastructureBeans(BeanDefinitionRegistry registry) {
/* 61 */     ConfigurationPropertiesBindingPostProcessor.register(registry);
/* 62 */     BoundConfigurationProperties.register(registry);
/*    */   }
/*    */   
/*    */   static void registerMethodValidationExcludeFilter(BeanDefinitionRegistry registry) {
/* 66 */     if (!registry.containsBeanDefinition(METHOD_VALIDATION_EXCLUDE_FILTER_BEAN_NAME)) {
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 71 */       AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(MethodValidationExcludeFilter.class, "byAnnotation").addConstructorArgValue(ConfigurationProperties.class).setRole(2).getBeanDefinition();
/* 72 */       registry.registerBeanDefinition(METHOD_VALIDATION_EXCLUDE_FILTER_BEAN_NAME, (BeanDefinition)abstractBeanDefinition);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\EnableConfigurationPropertiesRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */