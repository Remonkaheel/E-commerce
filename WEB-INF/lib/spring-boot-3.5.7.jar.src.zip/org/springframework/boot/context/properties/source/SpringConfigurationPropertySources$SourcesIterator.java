/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SourcesIterator
/*     */   implements Iterator<ConfigurationPropertySource>
/*     */ {
/*     */   private final Deque<Iterator<PropertySource<?>>> iterators;
/*     */   private ConfigurationPropertySource next;
/*     */   private final Function<PropertySource<?>, ConfigurationPropertySource> adapter;
/*     */   
/*     */   SourcesIterator(Iterator<PropertySource<?>> iterator, Function<PropertySource<?>, ConfigurationPropertySource> adapter) {
/*  87 */     this.iterators = new ArrayDeque<>(4);
/*  88 */     this.iterators.push(iterator);
/*  89 */     this.adapter = adapter;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  94 */     return (fetchNext() != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationPropertySource next() {
/*  99 */     ConfigurationPropertySource next = fetchNext();
/* 100 */     if (next == null) {
/* 101 */       throw new NoSuchElementException();
/*     */     }
/* 103 */     this.next = null;
/* 104 */     return next;
/*     */   }
/*     */   
/*     */   private ConfigurationPropertySource fetchNext() {
/* 108 */     if (this.next == null) {
/* 109 */       if (this.iterators.isEmpty()) {
/* 110 */         return null;
/*     */       }
/* 112 */       if (!((Iterator)this.iterators.peek()).hasNext()) {
/* 113 */         this.iterators.pop();
/* 114 */         return fetchNext();
/*     */       } 
/* 116 */       PropertySource<?> candidate = ((Iterator<PropertySource>)this.iterators.peek()).next();
/* 117 */       Object object = candidate.getSource(); if (object instanceof ConfigurableEnvironment) { ConfigurableEnvironment configurableEnvironment = (ConfigurableEnvironment)object;
/* 118 */         push(configurableEnvironment);
/* 119 */         return fetchNext(); }
/*     */       
/* 121 */       if (isIgnored(candidate)) {
/* 122 */         return fetchNext();
/*     */       }
/* 124 */       this.next = this.adapter.apply(candidate);
/*     */     } 
/* 126 */     return this.next;
/*     */   }
/*     */   
/*     */   private void push(ConfigurableEnvironment environment) {
/* 130 */     this.iterators.push(environment.getPropertySources().iterator());
/*     */   }
/*     */   
/*     */   private boolean isIgnored(PropertySource<?> candidate) {
/* 134 */     return (candidate instanceof PropertySource.StubPropertySource || candidate instanceof ConfigurationPropertySourcesPropertySource);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\SpringConfigurationPropertySources$SourcesIterator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */