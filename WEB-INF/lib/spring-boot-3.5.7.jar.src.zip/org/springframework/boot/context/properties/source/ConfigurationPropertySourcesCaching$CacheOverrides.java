/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CacheOverrides
/*    */   implements ConfigurationPropertyCaching.CacheOverride
/*    */ {
/* 81 */   private List<ConfigurationPropertyCaching.CacheOverride> overrides = new ArrayList<>();
/*    */   
/*    */   void add(ConfigurationPropertyCaching caching) {
/* 84 */     this.overrides.add(caching.override());
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 89 */     this.overrides.forEach(ConfigurationPropertyCaching.CacheOverride::close);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertySourcesCaching$CacheOverrides.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */