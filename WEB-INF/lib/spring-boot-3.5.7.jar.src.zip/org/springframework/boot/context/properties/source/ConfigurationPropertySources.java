/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.ConfigurablePropertyResolver;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConfigurationPropertySources
/*     */ {
/*     */   private static final String ATTACHED_PROPERTY_SOURCE_NAME = "configurationProperties";
/*     */   
/*     */   public static ConfigurablePropertyResolver createPropertyResolver(MutablePropertySources propertySources) {
/*  59 */     return (ConfigurablePropertyResolver)new ConfigurationPropertySourcesPropertyResolver(propertySources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAttachedConfigurationPropertySource(PropertySource<?> propertySource) {
/*  70 */     return "configurationProperties".equals(propertySource.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void attach(Environment environment) {
/*  87 */     Assert.isInstanceOf(ConfigurableEnvironment.class, environment);
/*  88 */     MutablePropertySources sources = ((ConfigurableEnvironment)environment).getPropertySources();
/*  89 */     PropertySource<?> attached = getAttached(sources);
/*  90 */     if (!isUsingSources(attached, sources)) {
/*  91 */       attached = new ConfigurationPropertySourcesPropertySource("configurationProperties", new SpringConfigurationPropertySources((Iterable<PropertySource<?>>)sources));
/*     */     }
/*     */     
/*  94 */     sources.remove("configurationProperties");
/*  95 */     sources.addFirst(attached);
/*     */   }
/*     */   
/*     */   private static boolean isUsingSources(PropertySource<?> attached, MutablePropertySources sources) {
/*  99 */     return (attached instanceof ConfigurationPropertySourcesPropertySource && ((SpringConfigurationPropertySources)attached
/* 100 */       .getSource()).isUsingSources((Iterable<PropertySource<?>>)sources));
/*     */   }
/*     */   
/*     */   static PropertySource<?> getAttached(MutablePropertySources sources) {
/* 104 */     return (sources != null) ? sources.get("configurationProperties") : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Iterable<ConfigurationPropertySource> get(Environment environment) {
/* 117 */     Assert.isInstanceOf(ConfigurableEnvironment.class, environment);
/* 118 */     MutablePropertySources sources = ((ConfigurableEnvironment)environment).getPropertySources();
/*     */     
/* 120 */     ConfigurationPropertySourcesPropertySource attached = (ConfigurationPropertySourcesPropertySource)sources.get("configurationProperties");
/* 121 */     if (attached == null) {
/* 122 */       return from((Iterable<PropertySource<?>>)sources);
/*     */     }
/* 124 */     return (Iterable<ConfigurationPropertySource>)attached.getSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Iterable<ConfigurationPropertySource> from(PropertySource<?> source) {
/* 135 */     return Collections.singleton(ConfigurationPropertySource.from(source));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Iterable<ConfigurationPropertySource> from(Iterable<PropertySource<?>> sources) {
/* 152 */     return new SpringConfigurationPropertySources(sources);
/*     */   }
/*     */   
/*     */   private static Stream<PropertySource<?>> streamPropertySources(PropertySources sources) {
/* 156 */     return sources.stream()
/* 157 */       .flatMap(ConfigurationPropertySources::flatten)
/* 158 */       .filter(ConfigurationPropertySources::isIncluded);
/*     */   }
/*     */   
/*     */   private static Stream<PropertySource<?>> flatten(PropertySource<?> source) {
/* 162 */     Object object = source.getSource(); if (object instanceof ConfigurableEnvironment) { ConfigurableEnvironment configurableEnvironment = (ConfigurableEnvironment)object;
/* 163 */       return streamPropertySources((PropertySources)configurableEnvironment.getPropertySources()); }
/*     */     
/* 165 */     return Stream.of(source);
/*     */   }
/*     */   
/*     */   private static boolean isIncluded(PropertySource<?> source) {
/* 169 */     return (!(source instanceof PropertySource.StubPropertySource) && !(source instanceof ConfigurationPropertySourcesPropertySource));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertySources.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */