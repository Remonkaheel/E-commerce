/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.core.CollectionFactory;
/*    */ import org.springframework.core.ResolvableType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CollectionBinder
/*    */   extends IndexedElementsBinder<Collection<Object>>
/*    */ {
/*    */   CollectionBinder(Binder.Context context) {
/* 37 */     super(context);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object bindAggregate(ConfigurationPropertyName name, Bindable<?> target, AggregateElementBinder elementBinder) {
/* 43 */     ResolvableType aggregateType = ResolvableType.forClassWithGenerics(List.class, target
/* 44 */         .getType().asCollection().getGenerics());
/* 45 */     ResolvableType elementType = target.getType().asCollection().getGeneric(new int[0]);
/* 46 */     IndexedElementsBinder.IndexedCollectionSupplier result = new IndexedElementsBinder.IndexedCollectionSupplier(() -> CollectionFactory.createCollection(List.class, elementType.resolve(), 0));
/*    */     
/* 48 */     bindIndexed(name, target, elementBinder, aggregateType, elementType, result);
/* 49 */     if (result.wasSupplied()) {
/* 50 */       return result.get();
/*    */     }
/* 52 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Collection<Object> merge(Supplier<Collection<Object>> existing, Collection<Object> additional) {
/* 57 */     Collection<Object> existingCollection = getExistingIfPossible(existing);
/* 58 */     if (existingCollection == null) {
/* 59 */       return additional;
/*    */     }
/*    */     try {
/* 62 */       existingCollection.clear();
/* 63 */       existingCollection.addAll(additional);
/* 64 */       return copyIfPossible(existingCollection);
/*    */     }
/* 66 */     catch (UnsupportedOperationException ex) {
/* 67 */       return createNewCollection(additional);
/*    */     } 
/*    */   }
/*    */   
/*    */   private Collection<Object> getExistingIfPossible(Supplier<Collection<Object>> existing) {
/*    */     try {
/* 73 */       return existing.get();
/*    */     }
/* 75 */     catch (Exception ex) {
/* 76 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   private Collection<Object> copyIfPossible(Collection<Object> collection) {
/*    */     try {
/* 82 */       return createNewCollection(collection);
/*    */     }
/* 84 */     catch (Exception ex) {
/* 85 */       return collection;
/*    */     } 
/*    */   }
/*    */   
/*    */   private Collection<Object> createNewCollection(Collection<Object> collection) {
/* 90 */     Collection<Object> result = CollectionFactory.createCollection(collection.getClass(), collection.size());
/* 91 */     result.addAll(collection);
/* 92 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\CollectionBinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */