/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.IterableConfigurationPropertySource;
/*     */ import org.springframework.core.ResolvableType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class IndexedElementsBinder<T>
/*     */   extends AggregateBinder<T>
/*     */ {
/*  47 */   private static final String[] INDEXES = new String[10]; static {
/*  48 */     for (int i = 0; i < INDEXES.length; i++) {
/*  49 */       INDEXES[i] = "[" + i + "]";
/*     */     }
/*     */   }
/*     */   
/*     */   IndexedElementsBinder(Binder.Context context) {
/*  54 */     super(context);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isAllowRecursiveBinding(ConfigurationPropertySource source) {
/*  59 */     return (source == null || source instanceof IterableConfigurationPropertySource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void bindIndexed(ConfigurationPropertyName name, Bindable<?> target, AggregateElementBinder elementBinder, ResolvableType aggregateType, ResolvableType elementType, IndexedCollectionSupplier result) {
/*  74 */     for (ConfigurationPropertySource source : getContext().getSources()) {
/*  75 */       bindIndexed(source, name, target, elementBinder, result, aggregateType, elementType);
/*  76 */       if (result.wasSupplied() && result.get() != null) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void bindIndexed(ConfigurationPropertySource source, ConfigurationPropertyName root, Bindable<?> target, AggregateElementBinder elementBinder, IndexedCollectionSupplier collection, ResolvableType aggregateType, ResolvableType elementType) {
/*  85 */     ConfigurationProperty property = source.getConfigurationProperty(root);
/*  86 */     if (property != null) {
/*  87 */       getContext().setConfigurationProperty(property);
/*  88 */       bindValue(target, collection.get(), aggregateType, elementType, property.getValue());
/*     */     } else {
/*     */       
/*  91 */       bindIndexed(source, root, elementBinder, collection, elementType);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void bindValue(Bindable<?> target, Collection<Object> collection, ResolvableType aggregateType, ResolvableType elementType, Object value) {
/*  97 */     if (value != null) { if (value instanceof CharSequence) { CharSequence charSequence = (CharSequence)value; if (charSequence.isEmpty())
/*     */           return;  }  }
/*     */     else { return; }
/* 100 */      Object aggregate = convert(value, aggregateType, target.getAnnotations());
/* 101 */     ResolvableType collectionType = ResolvableType.forClassWithGenerics(collection.getClass(), new ResolvableType[] { elementType });
/* 102 */     Collection<Object> elements = convert(aggregate, collectionType, new Annotation[0]);
/* 103 */     collection.addAll(elements);
/*     */   }
/*     */ 
/*     */   
/*     */   private void bindIndexed(ConfigurationPropertySource source, ConfigurationPropertyName root, AggregateElementBinder elementBinder, IndexedCollectionSupplier collection, ResolvableType elementType) {
/* 108 */     Set<String> knownIndexedChildren = Collections.emptySet();
/* 109 */     if (source instanceof IterableConfigurationPropertySource) { IterableConfigurationPropertySource iterableSource = (IterableConfigurationPropertySource)source;
/* 110 */       knownIndexedChildren = getKnownIndexedChildren(iterableSource, root); }
/*     */     
/* 112 */     for (int i = 0; i < Integer.MAX_VALUE; i++) {
/* 113 */       ConfigurationPropertyName name = appendIndex(root, i);
/* 114 */       Object value = elementBinder.bind(name, Bindable.of(elementType), source);
/* 115 */       if (value == null) {
/*     */         break;
/*     */       }
/* 118 */       knownIndexedChildren.remove(name.getLastElement(ConfigurationPropertyName.Form.UNIFORM));
/* 119 */       collection.get().add(value);
/*     */     } 
/* 121 */     if (source instanceof IterableConfigurationPropertySource) { IterableConfigurationPropertySource iterableSource = (IterableConfigurationPropertySource)source;
/* 122 */       assertNoUnboundChildren(knownIndexedChildren, iterableSource, root); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> getKnownIndexedChildren(IterableConfigurationPropertySource source, ConfigurationPropertyName root) {
/* 128 */     Set<String> knownIndexedChildren = new HashSet<>();
/* 129 */     Objects.requireNonNull(root); for (ConfigurationPropertyName name : source.filter(root::isAncestorOf)) {
/* 130 */       ConfigurationPropertyName choppedName = name.chop(root.getNumberOfElements() + 1);
/* 131 */       if (choppedName.isLastElementIndexed()) {
/* 132 */         knownIndexedChildren.add(choppedName.getLastElement(ConfigurationPropertyName.Form.UNIFORM));
/*     */       }
/*     */     } 
/* 135 */     return knownIndexedChildren;
/*     */   }
/*     */ 
/*     */   
/*     */   private void assertNoUnboundChildren(Set<String> unboundIndexedChildren, IterableConfigurationPropertySource source, ConfigurationPropertyName root) {
/* 140 */     if (unboundIndexedChildren.isEmpty()) {
/*     */       return;
/*     */     }
/* 143 */     Set<ConfigurationProperty> unboundProperties = new TreeSet<>();
/* 144 */     Objects.requireNonNull(root); for (ConfigurationPropertyName name : source.filter(root::isAncestorOf)) {
/* 145 */       ConfigurationPropertyName choppedName = name.chop(root.getNumberOfElements() + 1);
/* 146 */       if (choppedName.isLastElementIndexed() && unboundIndexedChildren
/* 147 */         .contains(choppedName.getLastElement(ConfigurationPropertyName.Form.UNIFORM))) {
/* 148 */         unboundProperties.add(source.getConfigurationProperty(name));
/*     */       }
/*     */     } 
/* 151 */     if (!unboundProperties.isEmpty()) {
/* 152 */       throw new UnboundConfigurationPropertiesException(unboundProperties);
/*     */     }
/*     */   }
/*     */   
/*     */   private ConfigurationPropertyName appendIndex(ConfigurationPropertyName root, int i) {
/* 157 */     return root.append((i < INDEXES.length) ? INDEXES[i] : ("[" + i + "]"));
/*     */   }
/*     */   
/*     */   private <C> C convert(Object value, ResolvableType type, Annotation... annotations) {
/* 161 */     value = getContext().getPlaceholdersResolver().resolvePlaceholders(value);
/* 162 */     return getContext().getConverter().convert(value, type, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class IndexedCollectionSupplier
/*     */     extends AggregateBinder.AggregateSupplier<Collection<Object>>
/*     */   {
/*     */     public IndexedCollectionSupplier(Supplier<Collection<Object>> supplier) {
/* 172 */       super(supplier);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\IndexedElementsBinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */