/*      */ package org.springframework.boot.context.properties.source;
/*      */ 
/*      */ import java.util.function.Function;
/*      */ import org.springframework.util.Assert;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class ElementsParser
/*      */ {
/*      */   private static final int DEFAULT_CAPACITY = 6;
/*      */   private final CharSequence source;
/*      */   private final char separator;
/*      */   private int size;
/*      */   private int[] start;
/*      */   private int[] end;
/*      */   private ConfigurationPropertyName.ElementType[] type;
/*      */   private CharSequence[] resolved;
/*      */   
/*      */   ElementsParser(CharSequence source, char separator) {
/*  986 */     this(source, separator, 6);
/*      */   }
/*      */   
/*      */   ElementsParser(CharSequence source, char separator, int capacity) {
/*  990 */     this.source = source;
/*  991 */     this.separator = separator;
/*  992 */     this.start = new int[capacity];
/*  993 */     this.end = new int[capacity];
/*  994 */     this.type = new ConfigurationPropertyName.ElementType[capacity];
/*      */   }
/*      */   
/*      */   ConfigurationPropertyName.Elements parse() {
/*  998 */     return parse(null);
/*      */   }
/*      */   
/*      */   ConfigurationPropertyName.Elements parse(Function<CharSequence, CharSequence> valueProcessor) {
/* 1002 */     int length = this.source.length();
/* 1003 */     int openBracketCount = 0;
/* 1004 */     int start = 0;
/* 1005 */     ConfigurationPropertyName.ElementType type = ConfigurationPropertyName.ElementType.EMPTY;
/* 1006 */     for (int i = 0; i < length; i++) {
/* 1007 */       char ch = this.source.charAt(i);
/* 1008 */       if (ch == '[') {
/* 1009 */         if (openBracketCount == 0) {
/* 1010 */           add(start, i, type, valueProcessor);
/* 1011 */           start = i + 1;
/* 1012 */           type = ConfigurationPropertyName.ElementType.NUMERICALLY_INDEXED;
/*      */         } 
/* 1014 */         openBracketCount++;
/*      */       }
/* 1016 */       else if (ch == ']') {
/* 1017 */         openBracketCount--;
/* 1018 */         if (openBracketCount == 0) {
/* 1019 */           add(start, i, type, valueProcessor);
/* 1020 */           start = i + 1;
/* 1021 */           type = ConfigurationPropertyName.ElementType.EMPTY;
/*      */         }
/*      */       
/* 1024 */       } else if (!type.isIndexed() && ch == this.separator) {
/* 1025 */         add(start, i, type, valueProcessor);
/* 1026 */         start = i + 1;
/* 1027 */         type = ConfigurationPropertyName.ElementType.EMPTY;
/*      */       } else {
/*      */         
/* 1030 */         type = updateType(type, ch, i - start);
/*      */       } 
/*      */     } 
/* 1033 */     if (openBracketCount != 0) {
/* 1034 */       type = ConfigurationPropertyName.ElementType.NON_UNIFORM;
/*      */     }
/* 1036 */     add(start, length, type, valueProcessor);
/* 1037 */     return new ConfigurationPropertyName.Elements(this.source, this.size, this.start, this.end, this.type, null, this.resolved);
/*      */   }
/*      */   
/*      */   private ConfigurationPropertyName.ElementType updateType(ConfigurationPropertyName.ElementType existingType, char ch, int index) {
/* 1041 */     if (existingType.isIndexed()) {
/* 1042 */       if (existingType == ConfigurationPropertyName.ElementType.NUMERICALLY_INDEXED && !isNumeric(ch)) {
/* 1043 */         return ConfigurationPropertyName.ElementType.INDEXED;
/*      */       }
/* 1045 */       return existingType;
/*      */     } 
/* 1047 */     if (existingType == ConfigurationPropertyName.ElementType.EMPTY && isValidChar(ch, index)) {
/* 1048 */       return (index == 0) ? ConfigurationPropertyName.ElementType.UNIFORM : ConfigurationPropertyName.ElementType.NON_UNIFORM;
/*      */     }
/* 1050 */     if (existingType == ConfigurationPropertyName.ElementType.UNIFORM && ch == '-') {
/* 1051 */       return ConfigurationPropertyName.ElementType.DASHED;
/*      */     }
/* 1053 */     if (!isValidChar(ch, index)) {
/* 1054 */       if (existingType == ConfigurationPropertyName.ElementType.EMPTY && !isValidChar(Character.toLowerCase(ch), index)) {
/* 1055 */         return ConfigurationPropertyName.ElementType.EMPTY;
/*      */       }
/* 1057 */       return ConfigurationPropertyName.ElementType.NON_UNIFORM;
/*      */     } 
/* 1059 */     return existingType;
/*      */   }
/*      */   
/*      */   private void add(int start, int end, ConfigurationPropertyName.ElementType type, Function<CharSequence, CharSequence> valueProcessor) {
/* 1063 */     if (end - start < 1 || type == ConfigurationPropertyName.ElementType.EMPTY) {
/*      */       return;
/*      */     }
/* 1066 */     if (this.start.length == this.size) {
/* 1067 */       this.start = expand(this.start);
/* 1068 */       this.end = expand(this.end);
/* 1069 */       this.type = expand(this.type);
/* 1070 */       this.resolved = expand(this.resolved);
/*      */     } 
/* 1072 */     if (valueProcessor != null) {
/* 1073 */       if (this.resolved == null) {
/* 1074 */         this.resolved = new CharSequence[this.start.length];
/*      */       }
/* 1076 */       CharSequence resolved = valueProcessor.apply(this.source.subSequence(start, end));
/* 1077 */       ConfigurationPropertyName.Elements resolvedElements = (new ElementsParser(resolved, '.')).parse();
/* 1078 */       Assert.state((resolvedElements.getSize() == 1), "Resolved element must not contain multiple elements");
/* 1079 */       this.resolved[this.size] = resolvedElements.get(0);
/* 1080 */       type = resolvedElements.getType(0);
/*      */     } 
/* 1082 */     this.start[this.size] = start;
/* 1083 */     this.end[this.size] = end;
/* 1084 */     this.type[this.size] = type;
/* 1085 */     this.size++;
/*      */   }
/*      */   
/*      */   private int[] expand(int[] src) {
/* 1089 */     int[] dest = new int[src.length + 6];
/* 1090 */     System.arraycopy(src, 0, dest, 0, src.length);
/* 1091 */     return dest;
/*      */   }
/*      */   
/*      */   private ConfigurationPropertyName.ElementType[] expand(ConfigurationPropertyName.ElementType[] src) {
/* 1095 */     ConfigurationPropertyName.ElementType[] dest = new ConfigurationPropertyName.ElementType[src.length + 6];
/* 1096 */     System.arraycopy(src, 0, dest, 0, src.length);
/* 1097 */     return dest;
/*      */   }
/*      */   
/*      */   private CharSequence[] expand(CharSequence[] src) {
/* 1101 */     if (src == null) {
/* 1102 */       return null;
/*      */     }
/* 1104 */     CharSequence[] dest = new CharSequence[src.length + 6];
/* 1105 */     System.arraycopy(src, 0, dest, 0, src.length);
/* 1106 */     return dest;
/*      */   }
/*      */   
/*      */   static boolean isValidChar(char ch, int index) {
/* 1110 */     return (isAlpha(ch) || isNumeric(ch) || (index != 0 && ch == '-'));
/*      */   }
/*      */   
/*      */   static boolean isAlphaNumeric(char ch) {
/* 1114 */     return (isAlpha(ch) || isNumeric(ch));
/*      */   }
/*      */   
/*      */   private static boolean isAlpha(char ch) {
/* 1118 */     return (ch >= 'a' && ch <= 'z');
/*      */   }
/*      */   
/*      */   private static boolean isNumeric(char ch) {
/* 1122 */     return (ch >= '0' && ch <= '9');
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyName$ElementsParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */