package org.springframework.boot.context.properties.bind;

import org.springframework.boot.context.properties.source.ConfigurationPropertyName;

interface DataObjectBinder {
  <T> T bind(ConfigurationPropertyName paramConfigurationPropertyName, Bindable<T> paramBindable, Binder.Context paramContext, DataObjectPropertyBinder paramDataObjectPropertyBinder);
  
  <T> T create(Bindable<T> paramBindable, Binder.Context paramContext);
  
  default <T> void onUnableToCreateInstance(Bindable<T> target, Binder.Context context, RuntimeException exception) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\DataObjectBinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */