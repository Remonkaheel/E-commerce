/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import org.springframework.aop.scope.ScopedProxyUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.boot.context.properties.bind.BindMethod;
/*     */ import org.springframework.context.annotation.AnnotationConfigUtils;
/*     */ import org.springframework.context.annotation.AnnotationScopeMetadataResolver;
/*     */ import org.springframework.context.annotation.ScopeMetadata;
/*     */ import org.springframework.context.annotation.ScopeMetadataResolver;
/*     */ import org.springframework.context.annotation.ScopedProxyMode;
/*     */ import org.springframework.core.AttributeAccessor;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ConfigurationPropertiesBeanRegistrar
/*     */ {
/*  49 */   private static final ScopeMetadataResolver scopeMetadataResolver = (ScopeMetadataResolver)new AnnotationScopeMetadataResolver();
/*     */   
/*     */   private final BeanDefinitionRegistry registry;
/*     */   
/*     */   private final BeanFactory beanFactory;
/*     */   
/*     */   ConfigurationPropertiesBeanRegistrar(BeanDefinitionRegistry registry) {
/*  56 */     this.registry = registry;
/*  57 */     this.beanFactory = (BeanFactory)this.registry;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void register(Class<?> type) {
/*  63 */     MergedAnnotation<ConfigurationProperties> annotation = MergedAnnotations.from(type, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(ConfigurationProperties.class);
/*  64 */     register(type, annotation);
/*     */   }
/*     */   
/*     */   void register(Class<?> type, MergedAnnotation<ConfigurationProperties> annotation) {
/*  68 */     String name = getName(type, annotation);
/*  69 */     if (!containsBeanDefinition(name)) {
/*  70 */       registerBeanDefinition(name, type, annotation);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getName(Class<?> type, MergedAnnotation<ConfigurationProperties> annotation) {
/*  75 */     String prefix = annotation.isPresent() ? annotation.getString("prefix") : "";
/*  76 */     return StringUtils.hasText(prefix) ? (prefix + "-" + prefix) : type.getName();
/*     */   }
/*     */   
/*     */   private boolean containsBeanDefinition(String name) {
/*  80 */     BeanFactory beanFactory = this.beanFactory; if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory listableBeanFactory = (ListableBeanFactory)beanFactory; if (listableBeanFactory
/*  81 */         .containsBeanDefinition(name)); }
/*     */     
/*     */     return false;
/*     */   }
/*     */   private void registerBeanDefinition(String beanName, Class<?> type, MergedAnnotation<ConfigurationProperties> annotation) {
/*  86 */     Assert.state(annotation.isPresent(), () -> "No " + ConfigurationProperties.class.getSimpleName() + " annotation found on  '" + type.getName() + "'.");
/*     */     
/*  88 */     BeanDefinitionReaderUtils.registerBeanDefinition(createBeanDefinition(beanName, type), this.registry);
/*     */   }
/*     */   
/*     */   private BeanDefinitionHolder createBeanDefinition(String beanName, Class<?> type) {
/*  92 */     AnnotatedGenericBeanDefinition definition = new AnnotatedGenericBeanDefinition(type);
/*  93 */     AnnotationConfigUtils.processCommonDefinitionAnnotations((AnnotatedBeanDefinition)definition);
/*  94 */     BindMethod bindMethod = ConfigurationPropertiesBean.deduceBindMethod(type);
/*  95 */     BindMethodAttribute.set((AttributeAccessor)definition, bindMethod);
/*  96 */     if (bindMethod == BindMethod.VALUE_OBJECT) {
/*  97 */       definition.setInstanceSupplier(() -> ConstructorBound.from(this.beanFactory, beanName, type));
/*     */     }
/*  99 */     ScopeMetadata metadata = scopeMetadataResolver.resolveScopeMetadata((BeanDefinition)definition);
/* 100 */     definition.setScope(metadata.getScopeName());
/* 101 */     BeanDefinitionHolder definitionHolder = new BeanDefinitionHolder((BeanDefinition)definition, beanName);
/* 102 */     return applyScopedProxyMode(metadata, definitionHolder, this.registry);
/*     */   }
/*     */ 
/*     */   
/*     */   static BeanDefinitionHolder applyScopedProxyMode(ScopeMetadata metadata, BeanDefinitionHolder definition, BeanDefinitionRegistry registry) {
/* 107 */     ScopedProxyMode mode = metadata.getScopedProxyMode();
/* 108 */     if (mode != ScopedProxyMode.NO) {
/* 109 */       return ScopedProxyUtils.createScopedProxy(definition, registry, (mode == ScopedProxyMode.TARGET_CLASS));
/*     */     }
/* 111 */     return definition;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBeanRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */