/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.LinkedMultiValueMap;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConfigurationPropertyNameAliases
/*    */   implements Iterable<ConfigurationPropertyName>
/*    */ {
/* 39 */   private final MultiValueMap<ConfigurationPropertyName, ConfigurationPropertyName> aliases = (MultiValueMap<ConfigurationPropertyName, ConfigurationPropertyName>)new LinkedMultiValueMap();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurationPropertyNameAliases(String name, String... aliases) {
/* 45 */     addAliases(name, aliases);
/*    */   }
/*    */   
/*    */   public ConfigurationPropertyNameAliases(ConfigurationPropertyName name, ConfigurationPropertyName... aliases) {
/* 49 */     addAliases(name, aliases);
/*    */   }
/*    */   
/*    */   public void addAliases(String name, String... aliases) {
/* 53 */     Assert.notNull(name, "'name' must not be null");
/* 54 */     Assert.notNull(aliases, "'aliases' must not be null");
/* 55 */     addAliases(ConfigurationPropertyName.of(name), 
/* 56 */         (ConfigurationPropertyName[])Arrays.<String>stream(aliases).map(ConfigurationPropertyName::of).toArray(x$0 -> new ConfigurationPropertyName[x$0]));
/*    */   }
/*    */   
/*    */   public void addAliases(ConfigurationPropertyName name, ConfigurationPropertyName... aliases) {
/* 60 */     Assert.notNull(name, "'name' must not be null");
/* 61 */     Assert.notNull(aliases, "'aliases' must not be null");
/* 62 */     this.aliases.addAll(name, Arrays.asList(aliases));
/*    */   }
/*    */   
/*    */   public List<ConfigurationPropertyName> getAliases(ConfigurationPropertyName name) {
/* 66 */     return (List<ConfigurationPropertyName>)this.aliases.getOrDefault(name, Collections.emptyList());
/*    */   }
/*    */   
/*    */   public ConfigurationPropertyName getNameForAlias(ConfigurationPropertyName alias) {
/* 70 */     return this.aliases.entrySet()
/* 71 */       .stream()
/* 72 */       .filter(e -> ((List)e.getValue()).contains(alias))
/* 73 */       .map(Map.Entry::getKey)
/* 74 */       .findFirst()
/* 75 */       .orElse(null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator<ConfigurationPropertyName> iterator() {
/* 80 */     return this.aliases.keySet().iterator();
/*    */   }
/*    */   
/*    */   public ConfigurationPropertyNameAliases() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyNameAliases.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */