/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyCaching;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyState;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.ConverterNotFoundException;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Binder
/*     */ {
/*  61 */   private static final Set<Class<?>> NON_BEAN_CLASSES = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(new Class[] { Object.class, Class.class })));
/*     */   
/*     */   private final Iterable<ConfigurationPropertySource> sources;
/*     */   
/*     */   private final PlaceholdersResolver placeholdersResolver;
/*     */   
/*     */   private final BindConverter bindConverter;
/*     */   
/*     */   private final BindHandler defaultBindHandler;
/*     */   
/*     */   private final Map<BindMethod, List<DataObjectBinder>> dataObjectBinders;
/*     */   
/*  73 */   private final Map<Object, Object> cache = (Map<Object, Object>)new ConcurrentReferenceHashMap();
/*     */ 
/*     */ 
/*     */   
/*     */   private ConfigurationPropertyCaching configurationPropertyCaching;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(ConfigurationPropertySource... sources) {
/*  83 */     this((sources != null) ? Arrays.<ConfigurationPropertySource>asList(sources) : null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources) {
/*  92 */     this(sources, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources, PlaceholdersResolver placeholdersResolver) {
/* 101 */     this(sources, placeholdersResolver, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources, PlaceholdersResolver placeholdersResolver, ConversionService conversionService) {
/* 113 */     this(sources, placeholdersResolver, conversionService, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources, PlaceholdersResolver placeholdersResolver, ConversionService conversionService, Consumer<PropertyEditorRegistry> propertyEditorInitializer) {
/* 128 */     this(sources, placeholdersResolver, conversionService, propertyEditorInitializer, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources, PlaceholdersResolver placeholdersResolver, ConversionService conversionService, Consumer<PropertyEditorRegistry> propertyEditorInitializer, BindHandler defaultBindHandler) {
/* 147 */     this(sources, placeholdersResolver, conversionService, propertyEditorInitializer, defaultBindHandler, (BindConstructorProvider)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources, PlaceholdersResolver placeholdersResolver, ConversionService conversionService, Consumer<PropertyEditorRegistry> propertyEditorInitializer, BindHandler defaultBindHandler, BindConstructorProvider constructorProvider) {
/* 168 */     this(sources, placeholdersResolver, 
/* 169 */         (conversionService != null) ? Collections.<ConversionService>singletonList(conversionService) : 
/* 170 */         (List<ConversionService>)null, propertyEditorInitializer, defaultBindHandler, constructorProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Binder(Iterable<ConfigurationPropertySource> sources, PlaceholdersResolver placeholdersResolver, List<ConversionService> conversionServices, Consumer<PropertyEditorRegistry> propertyEditorInitializer, BindHandler defaultBindHandler, BindConstructorProvider constructorProvider) {
/* 192 */     Assert.notNull(sources, "'sources' must not be null");
/* 193 */     for (ConfigurationPropertySource source : sources) {
/* 194 */       Assert.notNull(source, "'sources' must not contain null elements");
/*     */     }
/* 196 */     this.sources = sources;
/* 197 */     this.configurationPropertyCaching = ConfigurationPropertyCaching.get(sources);
/* 198 */     this.placeholdersResolver = (placeholdersResolver != null) ? placeholdersResolver : PlaceholdersResolver.NONE;
/* 199 */     this.bindConverter = BindConverter.get(conversionServices, propertyEditorInitializer);
/* 200 */     this.defaultBindHandler = (defaultBindHandler != null) ? defaultBindHandler : BindHandler.DEFAULT;
/* 201 */     if (constructorProvider == null) {
/* 202 */       constructorProvider = BindConstructorProvider.DEFAULT;
/*     */     }
/* 204 */     ValueObjectBinder valueObjectBinder = new ValueObjectBinder(constructorProvider);
/* 205 */     JavaBeanBinder javaBeanBinder = JavaBeanBinder.INSTANCE;
/* 206 */     Map<BindMethod, List<DataObjectBinder>> dataObjectBinders = new HashMap<>();
/* 207 */     dataObjectBinders.put(BindMethod.VALUE_OBJECT, List.of(valueObjectBinder));
/* 208 */     dataObjectBinders.put(BindMethod.JAVA_BEAN, List.of(javaBeanBinder));
/* 209 */     dataObjectBinders.put(null, List.of(valueObjectBinder, javaBeanBinder));
/* 210 */     this.dataObjectBinders = Collections.unmodifiableMap(dataObjectBinders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> BindResult<T> bind(String name, Class<T> target) {
/* 223 */     return bind(name, Bindable.of(target));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> BindResult<T> bind(String name, Bindable<T> target) {
/* 236 */     return bind(ConfigurationPropertyName.of(name), target, (BindHandler)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> BindResult<T> bind(ConfigurationPropertyName name, Bindable<T> target) {
/* 249 */     return bind(name, target, (BindHandler)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> BindResult<T> bind(String name, Bindable<T> target, BindHandler handler) {
/* 262 */     return bind(ConfigurationPropertyName.of(name), target, handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> BindResult<T> bind(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler) {
/* 275 */     T bound = bind(name, target, handler, false);
/* 276 */     return BindResult.of(bound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bindOrCreate(String name, Class<T> target) {
/* 291 */     return bindOrCreate(name, Bindable.of(target));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bindOrCreate(String name, Bindable<T> target) {
/* 306 */     return bindOrCreate(ConfigurationPropertyName.of(name), target, (BindHandler)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bindOrCreate(String name, Bindable<T> target, BindHandler handler) {
/* 322 */     return bindOrCreate(ConfigurationPropertyName.of(name), target, handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bindOrCreate(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler) {
/* 337 */     return bind(name, target, handler, true);
/*     */   }
/*     */   
/*     */   private <T> T bind(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, boolean create) {
/* 341 */     Assert.notNull(name, "'name' must not be null");
/* 342 */     Assert.notNull(target, "'target' must not be null");
/* 343 */     handler = (handler != null) ? handler : this.defaultBindHandler;
/* 344 */     Context context = new Context();
/* 345 */     return bind(name, target, handler, context, false, create);
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T bind(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, Context context, boolean allowRecursiveBinding, boolean create) {
/* 350 */     ConfigurationPropertyCaching.CacheOverride cacheOverride = this.configurationPropertyCaching.override();
/*     */     
/* 352 */     try { Bindable<T> replacementTarget = handler.onStart(name, target, context);
/* 353 */       if (replacementTarget == null)
/* 354 */       { T t1 = (T)handleBindResult(name, (Bindable)target, handler, context, null, create);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 363 */         if (cacheOverride != null) cacheOverride.close();  return t1; }  target = replacementTarget; Object bound = bindObject(name, target, handler, context, allowRecursiveBinding); T t = (T)handleBindResult(name, (Bindable)target, handler, context, bound, create); if (cacheOverride != null) cacheOverride.close();  return t; } catch (Exception ex) { T t = (T)handleBindError(name, (Bindable)target, handler, context, ex); if (cacheOverride != null) cacheOverride.close();  return t; }
/*     */     catch (Throwable throwable) { if (cacheOverride != null)
/*     */         try { cacheOverride.close(); }
/*     */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */           throw throwable; }
/* 368 */      } private <T> T handleBindResult(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, Context context, Object result, boolean create) throws Exception { if (result != null) {
/* 369 */       result = handler.onSuccess(name, target, context, result);
/* 370 */       result = context.getConverter().convert(result, target);
/*     */     } 
/* 372 */     if (result == null && create) {
/* 373 */       result = fromDataObjectBinders(target.getBindMethod(), dataObjectBinder -> dataObjectBinder.create(target, context));
/*     */       
/* 375 */       result = handler.onCreate(name, target, context, result);
/* 376 */       result = context.getConverter().convert(result, target);
/* 377 */       if (result == null) {
/*     */         
/* 379 */         IllegalStateException ex = new IllegalStateException("Unable to create instance for " + String.valueOf(target.getType()));
/* 380 */         ((List)this.dataObjectBinders.get(target.getBindMethod()))
/* 381 */           .forEach(dataObjectBinder -> dataObjectBinder.onUnableToCreateInstance(target, context, ex));
/* 382 */         throw ex;
/*     */       } 
/*     */     } 
/* 385 */     handler.onFinish(name, target, context, result);
/* 386 */     return context.getConverter().convert(result, target); }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> T handleBindError(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, Context context, Exception error) {
/*     */     try {
/* 392 */       Object result = handler.onFailure(name, target, context, error);
/* 393 */       return context.getConverter().convert(result, target);
/*     */     }
/* 395 */     catch (Exception ex) {
/* 396 */       if (ex instanceof BindException) { BindException bindException = (BindException)ex;
/* 397 */         throw bindException; }
/*     */       
/* 399 */       throw new BindException(name, target, context.getConfigurationProperty(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> Object bindObject(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, Context context, boolean allowRecursiveBinding) {
/* 405 */     ConfigurationProperty property = findProperty(name, target, context);
/* 406 */     if (property == null && context.depth != 0 && containsNoDescendantOf(context.getSources(), name)) {
/* 407 */       return null;
/*     */     }
/* 409 */     AggregateBinder<?> aggregateBinder = getAggregateBinder(target, context);
/* 410 */     if (aggregateBinder != null) {
/* 411 */       return bindAggregate(name, target, handler, context, aggregateBinder);
/*     */     }
/* 413 */     if (property != null) {
/*     */       try {
/* 415 */         return bindProperty(target, context, property);
/*     */       }
/* 417 */       catch (ConverterNotFoundException ex) {
/*     */         
/* 419 */         Object instance = bindDataObject(name, target, handler, context, allowRecursiveBinding);
/* 420 */         if (instance != null) {
/* 421 */           return instance;
/*     */         }
/* 423 */         throw ex;
/*     */       } 
/*     */     }
/* 426 */     return bindDataObject(name, target, handler, context, allowRecursiveBinding);
/*     */   }
/*     */   
/*     */   private AggregateBinder<?> getAggregateBinder(Bindable<?> target, Context context) {
/* 430 */     Class<?> resolvedType = target.getType().resolve(Object.class);
/* 431 */     if (Map.class.isAssignableFrom(resolvedType)) {
/* 432 */       return new MapBinder(context);
/*     */     }
/* 434 */     if (Collection.class.isAssignableFrom(resolvedType)) {
/* 435 */       return new CollectionBinder(context);
/*     */     }
/* 437 */     if (target.getType().isArray()) {
/* 438 */       return new ArrayBinder(context);
/*     */     }
/* 440 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> Object bindAggregate(ConfigurationPropertyName name, Bindable<T> target, BindHandler handler, Context context, AggregateBinder<?> aggregateBinder) {
/* 445 */     AggregateElementBinder elementBinder = (itemName, itemTarget, source) -> {
/*     */         boolean allowRecursiveBinding = aggregateBinder.isAllowRecursiveBinding(source);
/*     */         Supplier<?> supplier = ();
/*     */         return context.withSource(source, supplier);
/*     */       };
/* 450 */     return context.withIncreasedDepth(() -> aggregateBinder.bind(name, target, elementBinder));
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> ConfigurationProperty findProperty(ConfigurationPropertyName name, Bindable<T> target, Context context) {
/* 455 */     if (name.isEmpty() || target.hasBindRestriction(Bindable.BindRestriction.NO_DIRECT_PROPERTY)) {
/* 456 */       return null;
/*     */     }
/* 458 */     for (ConfigurationPropertySource source : context.getSources()) {
/* 459 */       ConfigurationProperty property = source.getConfigurationProperty(name);
/* 460 */       if (property != null) {
/* 461 */         return property;
/*     */       }
/*     */     } 
/* 464 */     return null;
/*     */   }
/*     */   
/*     */   private <T> Object bindProperty(Bindable<T> target, Context context, ConfigurationProperty property) {
/* 468 */     context.setConfigurationProperty(property);
/* 469 */     Object result = property.getValue();
/* 470 */     result = this.placeholdersResolver.resolvePlaceholders(result);
/* 471 */     result = context.getConverter().convert(result, target);
/* 472 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object bindDataObject(ConfigurationPropertyName name, Bindable<?> target, BindHandler handler, Context context, boolean allowRecursiveBinding) {
/* 477 */     if (isUnbindableBean(name, target, context)) {
/* 478 */       return null;
/*     */     }
/* 480 */     Class<?> type = target.getType().resolve(Object.class);
/* 481 */     BindMethod bindMethod = target.getBindMethod();
/* 482 */     if (!allowRecursiveBinding && context.isBindingDataObject(type)) {
/* 483 */       return null;
/*     */     }
/* 485 */     DataObjectPropertyBinder propertyBinder = (propertyName, propertyTarget) -> bind(name.append(propertyName), propertyTarget, handler, context, false, false);
/*     */     
/* 487 */     return context.withDataObject(type, () -> fromDataObjectBinders(bindMethod, ()));
/*     */   }
/*     */ 
/*     */   
/*     */   private Object fromDataObjectBinders(BindMethod bindMethod, Function<DataObjectBinder, Object> operation) {
/* 492 */     for (DataObjectBinder dataObjectBinder : this.dataObjectBinders.get(bindMethod)) {
/* 493 */       Object bound = operation.apply(dataObjectBinder);
/* 494 */       if (bound != null) {
/* 495 */         return bound;
/*     */       }
/*     */     } 
/* 498 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isUnbindableBean(ConfigurationPropertyName name, Bindable<?> target, Context context) {
/* 502 */     for (ConfigurationPropertySource source : context.getSources()) {
/* 503 */       if (source.containsDescendantOf(name) == ConfigurationPropertyState.PRESENT)
/*     */       {
/* 505 */         return false;
/*     */       }
/*     */     } 
/* 508 */     Class<?> resolved = target.getType().resolve(Object.class);
/* 509 */     if (resolved.isPrimitive() || NON_BEAN_CLASSES.contains(resolved)) {
/* 510 */       return true;
/*     */     }
/* 512 */     return resolved.getName().startsWith("java.");
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean containsNoDescendantOf(Iterable<ConfigurationPropertySource> sources, ConfigurationPropertyName name) {
/* 517 */     for (ConfigurationPropertySource source : sources) {
/* 518 */       if (source.containsDescendantOf(name) != ConfigurationPropertyState.ABSENT) {
/* 519 */         return false;
/*     */       }
/*     */     } 
/* 522 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Binder get(Environment environment) {
/* 532 */     return get(environment, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Binder get(Environment environment, BindHandler defaultBindHandler) {
/* 545 */     Iterable<ConfigurationPropertySource> sources = ConfigurationPropertySources.get(environment);
/* 546 */     PropertySourcesPlaceholdersResolver placeholdersResolver = new PropertySourcesPlaceholdersResolver(environment);
/* 547 */     return new Binder(sources, placeholdersResolver, null, null, defaultBindHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final class Context
/*     */     implements BindContext
/*     */   {
/*     */     private int depth;
/*     */     
/* 557 */     private final List<ConfigurationPropertySource> source = Arrays.asList(new ConfigurationPropertySource[] { (ConfigurationPropertySource)null });
/*     */     
/*     */     private int sourcePushCount;
/*     */     
/* 561 */     private final Deque<Class<?>> dataObjectBindings = new ArrayDeque<>();
/*     */     
/* 563 */     private final Deque<Class<?>> constructorBindings = new ArrayDeque<>();
/*     */     
/*     */     private ConfigurationProperty configurationProperty;
/*     */     
/*     */     private void increaseDepth() {
/* 568 */       this.depth++;
/*     */     }
/*     */     
/*     */     private void decreaseDepth() {
/* 572 */       this.depth--;
/*     */     }
/*     */     
/*     */     private <T> T withSource(ConfigurationPropertySource source, Supplier<T> supplier) {
/* 576 */       if (source == null) {
/* 577 */         return supplier.get();
/*     */       }
/* 579 */       ConfigurationPropertySource previous = this.source.get(0);
/* 580 */       this.source.set(0, source);
/* 581 */       this.sourcePushCount++;
/*     */       try {
/* 583 */         return supplier.get();
/*     */       } finally {
/*     */         
/* 586 */         this.sourcePushCount--;
/* 587 */         this.source.set(0, previous);
/*     */       } 
/*     */     }
/*     */     
/*     */     private <T> T withDataObject(Class<?> type, Supplier<T> supplier) {
/* 592 */       this.dataObjectBindings.push(type);
/*     */       try {
/* 594 */         return (T)withIncreasedDepth((Supplier)supplier);
/*     */       } finally {
/*     */         
/* 597 */         this.dataObjectBindings.pop();
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean isBindingDataObject(Class<?> type) {
/* 602 */       return this.dataObjectBindings.contains(type);
/*     */     }
/*     */     
/*     */     private <T> T withIncreasedDepth(Supplier<T> supplier) {
/* 606 */       increaseDepth();
/*     */       try {
/* 608 */         return supplier.get();
/*     */       } finally {
/*     */         
/* 611 */         decreaseDepth();
/*     */       } 
/*     */     }
/*     */     
/*     */     void setConfigurationProperty(ConfigurationProperty configurationProperty) {
/* 616 */       this.configurationProperty = configurationProperty;
/*     */     }
/*     */     
/*     */     void clearConfigurationProperty() {
/* 620 */       this.configurationProperty = null;
/*     */     }
/*     */     
/*     */     void pushConstructorBoundTypes(Class<?> value) {
/* 624 */       this.constructorBindings.push(value);
/*     */     }
/*     */     
/*     */     boolean isNestedConstructorBinding() {
/* 628 */       return !this.constructorBindings.isEmpty();
/*     */     }
/*     */     
/*     */     void popConstructorBoundTypes() {
/* 632 */       this.constructorBindings.pop();
/*     */     }
/*     */     
/*     */     PlaceholdersResolver getPlaceholdersResolver() {
/* 636 */       return Binder.this.placeholdersResolver;
/*     */     }
/*     */     
/*     */     BindConverter getConverter() {
/* 640 */       return Binder.this.bindConverter;
/*     */     }
/*     */     
/*     */     Map<Object, Object> getCache() {
/* 644 */       return Binder.this.cache;
/*     */     }
/*     */ 
/*     */     
/*     */     public Binder getBinder() {
/* 649 */       return Binder.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getDepth() {
/* 654 */       return this.depth;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterable<ConfigurationPropertySource> getSources() {
/* 659 */       if (this.sourcePushCount > 0) {
/* 660 */         return this.source;
/*     */       }
/* 662 */       return Binder.this.sources;
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigurationProperty getConfigurationProperty() {
/* 667 */       return this.configurationProperty;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\Binder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */