/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.function.UnaryOperator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SoftReferenceConfigurationPropertyCache<T>
/*     */   implements ConfigurationPropertyCaching
/*     */ {
/*  35 */   private static final Duration UNLIMITED = Duration.ZERO;
/*     */   
/*     */   static final ConfigurationPropertyCaching.CacheOverride NO_OP_OVERRIDE = () -> {
/*     */     
/*     */     };
/*     */   
/*     */   private final boolean neverExpire;
/*     */   
/*     */   private volatile Duration timeToLive;
/*  44 */   private volatile SoftReference<T> value = new SoftReference<>(null);
/*     */   
/*  46 */   private volatile Instant lastAccessed = now();
/*     */   
/*     */   SoftReferenceConfigurationPropertyCache(boolean neverExpire) {
/*  49 */     this.neverExpire = neverExpire;
/*     */   }
/*     */ 
/*     */   
/*     */   public void enable() {
/*  54 */     this.timeToLive = UNLIMITED;
/*     */   }
/*     */ 
/*     */   
/*     */   public void disable() {
/*  59 */     this.timeToLive = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeToLive(Duration timeToLive) {
/*  64 */     this.timeToLive = (timeToLive == null || timeToLive.isZero()) ? null : timeToLive;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  69 */     this.lastAccessed = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationPropertyCaching.CacheOverride override() {
/*  74 */     if (this.neverExpire) {
/*  75 */       return NO_OP_OVERRIDE;
/*     */     }
/*  77 */     ActiveCacheOverride override = new ActiveCacheOverride(this);
/*  78 */     if (override.timeToLive() == null)
/*     */     {
/*  80 */       clear();
/*     */     }
/*  82 */     this.timeToLive = UNLIMITED;
/*  83 */     return override;
/*     */   }
/*     */   
/*     */   void restore(ActiveCacheOverride override) {
/*  87 */     this.timeToLive = override.timeToLive();
/*  88 */     this.lastAccessed = override.lastAccessed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T get(Supplier<T> factory, UnaryOperator<T> refreshAction) {
/*  98 */     T value = getValue();
/*  99 */     if (value == null) {
/* 100 */       value = refreshAction.apply(factory.get());
/* 101 */       setValue(value);
/*     */     }
/* 103 */     else if (hasExpired()) {
/* 104 */       value = refreshAction.apply(value);
/* 105 */       setValue(value);
/*     */     } 
/* 107 */     if (!this.neverExpire) {
/* 108 */       this.lastAccessed = now();
/*     */     }
/* 110 */     return value;
/*     */   }
/*     */   
/*     */   private boolean hasExpired() {
/* 114 */     if (this.neverExpire) {
/* 115 */       return false;
/*     */     }
/* 117 */     Duration timeToLive = this.timeToLive;
/* 118 */     Instant lastAccessed = this.lastAccessed;
/* 119 */     if (timeToLive == null || lastAccessed == null) {
/* 120 */       return true;
/*     */     }
/* 122 */     return (!UNLIMITED.equals(timeToLive) && now().isAfter(lastAccessed.plus(timeToLive)));
/*     */   }
/*     */   
/*     */   protected Instant now() {
/* 126 */     return Instant.now();
/*     */   }
/*     */   
/*     */   protected T getValue() {
/* 130 */     return this.value.get();
/*     */   }
/*     */   
/*     */   protected void setValue(T value) {
/* 134 */     this.value = new SoftReference<>(value);
/*     */   }
/*     */   private static final class ActiveCacheOverride extends Record implements ConfigurationPropertyCaching.CacheOverride { private final SoftReferenceConfigurationPropertyCache<?> cache; private final Duration timeToLive;
/*     */     private final Instant lastAccessed;
/*     */     private final AtomicBoolean active;
/*     */     
/* 140 */     private ActiveCacheOverride(SoftReferenceConfigurationPropertyCache<?> cache, Duration timeToLive, Instant lastAccessed, AtomicBoolean active) { this.cache = cache; this.timeToLive = timeToLive; this.lastAccessed = lastAccessed; this.active = active; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #140	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 140 */       //   0	7	0	this	Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride; } public SoftReferenceConfigurationPropertyCache<?> cache() { return this.cache; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #140	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #140	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/boot/context/properties/source/SoftReferenceConfigurationPropertyCache$ActiveCacheOverride;
/* 140 */       //   0	8	1	o	Ljava/lang/Object; } public Duration timeToLive() { return this.timeToLive; } public Instant lastAccessed() { return this.lastAccessed; } public AtomicBoolean active() { return this.active; }
/*     */ 
/*     */     
/*     */     ActiveCacheOverride(SoftReferenceConfigurationPropertyCache<?> cache) {
/* 144 */       this(cache, cache.timeToLive, cache.lastAccessed, new AtomicBoolean());
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() {
/* 149 */       if (active().compareAndSet(false, true))
/* 150 */         this.cache.restore(this); 
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\SoftReferenceConfigurationPropertyCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */