/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class KotlinValueObject<T>
/*     */   extends ValueObjectBinder.ValueObject<T>
/*     */ {
/* 264 */   private static final Annotation[] ANNOTATION_ARRAY = new Annotation[0];
/*     */   
/*     */   private final List<ValueObjectBinder.ConstructorParameter> constructorParameters;
/*     */ 
/*     */   
/*     */   private KotlinValueObject(Constructor<T> primaryConstructor, KFunction<T> kotlinConstructor, ResolvableType type) {
/* 270 */     super(primaryConstructor);
/* 271 */     this.constructorParameters = parseConstructorParameters(kotlinConstructor, type);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ValueObjectBinder.ConstructorParameter> parseConstructorParameters(KFunction<T> kotlinConstructor, ResolvableType type) {
/* 276 */     List<KParameter> parameters = kotlinConstructor.getParameters();
/* 277 */     List<ValueObjectBinder.ConstructorParameter> result = new ArrayList<>(parameters.size());
/* 278 */     for (KParameter parameter : parameters) {
/* 279 */       String name = getParameterName(parameter);
/*     */       
/* 281 */       ResolvableType parameterType = ResolvableType.forType(ReflectJvmMapping.getJavaType(parameter.getType()), type);
/* 282 */       Annotation[] annotations = (Annotation[])parameter.getAnnotations().toArray((Object[])ANNOTATION_ARRAY);
/* 283 */       result.add(new ValueObjectBinder.ConstructorParameter(name, parameterType, annotations));
/*     */     } 
/* 285 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getParameterName(KParameter parameter) {
/* 292 */     Objects.requireNonNull(parameter); return MergedAnnotations.from(parameter, (Annotation[])parameter.getAnnotations().toArray((Object[])ANNOTATION_ARRAY)).get(Name.class).getValue("value", String.class).orElseGet(parameter::getName);
/*     */   }
/*     */ 
/*     */   
/*     */   List<ValueObjectBinder.ConstructorParameter> getConstructorParameters() {
/* 297 */     return this.constructorParameters;
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> ValueObjectBinder.ValueObject<T> get(Constructor<T> bindConstructor, ResolvableType type, ParameterNameDiscoverer parameterNameDiscoverer) {
/* 302 */     KFunction<T> kotlinConstructor = ReflectJvmMapping.getKotlinFunction(bindConstructor);
/* 303 */     if (kotlinConstructor != null) {
/* 304 */       return new KotlinValueObject<>(bindConstructor, kotlinConstructor, type);
/*     */     }
/* 306 */     return ValueObjectBinder.DefaultValueObject.get(bindConstructor, type, parameterNameDiscoverer);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\ValueObjectBinder$KotlinValueObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */