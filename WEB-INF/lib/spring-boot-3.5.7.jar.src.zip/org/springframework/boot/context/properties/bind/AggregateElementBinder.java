/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ interface AggregateElementBinder
/*    */ {
/*    */   default Object bind(ConfigurationPropertyName name, Bindable<?> target) {
/* 39 */     return bind(name, target, null);
/*    */   }
/*    */   
/*    */   Object bind(ConfigurationPropertyName paramConfigurationPropertyName, Bindable<?> paramBindable, ConfigurationPropertySource paramConfigurationPropertySource);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\AggregateElementBinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */