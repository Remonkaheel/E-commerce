/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragments;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragmentsDecorator;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.InstanceSupplier;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.boot.context.properties.bind.BindMethod;
/*     */ import org.springframework.core.AttributeAccessor;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationPropertiesBeanRegistrationAotProcessor
/*     */   implements BeanRegistrationAotProcessor
/*     */ {
/*     */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/*  49 */     if (!isImmutableConfigurationPropertiesBeanDefinition((BeanDefinition)registeredBean.getMergedBeanDefinition())) {
/*  50 */       return null;
/*     */     }
/*  52 */     return BeanRegistrationAotContribution.withCustomCodeFragments(codeFragments -> new ConfigurationPropertiesBeanRegistrationCodeFragments(codeFragments, registeredBean));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isImmutableConfigurationPropertiesBeanDefinition(BeanDefinition beanDefinition) {
/*  59 */     return BindMethod.VALUE_OBJECT.equals(BindMethodAttribute.get((AttributeAccessor)beanDefinition));
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ConfigurationPropertiesBeanRegistrationCodeFragments
/*     */     extends BeanRegistrationCodeFragmentsDecorator
/*     */   {
/*     */     private static final String REGISTERED_BEAN_PARAMETER_NAME = "registeredBean";
/*     */     
/*     */     private final RegisteredBean registeredBean;
/*     */     
/*     */     ConfigurationPropertiesBeanRegistrationCodeFragments(BeanRegistrationCodeFragments codeFragments, RegisteredBean registeredBean) {
/*  71 */       super(codeFragments);
/*  72 */       this.registeredBean = registeredBean;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CodeBlock generateSetBeanDefinitionPropertiesCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, RootBeanDefinition beanDefinition, Predicate<String> attributeFilter) {
/*  80 */       Objects.requireNonNull(BindMethodAttribute.NAME); return super.generateSetBeanDefinitionPropertiesCode(generationContext, beanRegistrationCode, beanDefinition, attributeFilter.or(BindMethodAttribute.NAME::equals));
/*     */     }
/*     */ 
/*     */     
/*     */     public ClassName getTarget(RegisteredBean registeredBean) {
/*  85 */       return ClassName.get(this.registeredBean.getBeanClass());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public CodeBlock generateInstanceSupplierCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, boolean allowDirectSupplierShortcut) {
/*  91 */       GeneratedMethod generatedMethod = beanRegistrationCode.getMethods().add("getInstance", method -> {
/*     */             Class<?> beanClass = this.registeredBean.getBeanClass();
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             method.addJavadoc("Get the bean instance for '$L'.", new Object[] { this.registeredBean.getBeanName() }).addModifiers(new Modifier[] { Modifier.PRIVATE, Modifier.STATIC }).returns(beanClass).addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]).addStatement("$T beanFactory = registeredBean.getBeanFactory()", new Object[] { BeanFactory.class }).addStatement("$T beanName = registeredBean.getBeanName()", new Object[] { String.class }).addStatement("$T<?> beanClass = registeredBean.getBeanClass()", new Object[] { Class.class }).addStatement("return ($T) $T.from(beanFactory, beanName, beanClass)", new Object[] { beanClass, ConstructorBound.class });
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 103 */       return CodeBlock.of("$T.of($T::$L)", new Object[] { InstanceSupplier.class, beanRegistrationCode.getClassName(), generatedMethod
/* 104 */             .getName() });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBeanRegistrationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */