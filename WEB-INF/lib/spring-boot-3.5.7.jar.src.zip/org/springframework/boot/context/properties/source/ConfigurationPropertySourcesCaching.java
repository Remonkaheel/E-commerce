/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConfigurationPropertySourcesCaching
/*    */   implements ConfigurationPropertyCaching
/*    */ {
/*    */   private final Iterable<ConfigurationPropertySource> sources;
/*    */   
/*    */   ConfigurationPropertySourcesCaching(Iterable<ConfigurationPropertySource> sources) {
/* 35 */     this.sources = sources;
/*    */   }
/*    */ 
/*    */   
/*    */   public void enable() {
/* 40 */     forEach(ConfigurationPropertyCaching::enable);
/*    */   }
/*    */ 
/*    */   
/*    */   public void disable() {
/* 45 */     forEach(ConfigurationPropertyCaching::disable);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTimeToLive(Duration timeToLive) {
/* 50 */     forEach(caching -> caching.setTimeToLive(timeToLive));
/*    */   }
/*    */ 
/*    */   
/*    */   public void clear() {
/* 55 */     forEach(ConfigurationPropertyCaching::clear);
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationPropertyCaching.CacheOverride override() {
/* 60 */     CacheOverrides override = new CacheOverrides();
/* 61 */     Objects.requireNonNull(override); forEach(override::add);
/* 62 */     return override;
/*    */   }
/*    */   
/*    */   private void forEach(Consumer<ConfigurationPropertyCaching> action) {
/* 66 */     if (this.sources != null) {
/* 67 */       for (ConfigurationPropertySource source : this.sources) {
/* 68 */         ConfigurationPropertyCaching caching = CachingConfigurationPropertySource.find(source);
/* 69 */         if (caching != null) {
/* 70 */           action.accept(caching);
/*    */         }
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private final class CacheOverrides
/*    */     implements ConfigurationPropertyCaching.CacheOverride
/*    */   {
/* 81 */     private List<ConfigurationPropertyCaching.CacheOverride> overrides = new ArrayList<>();
/*    */     
/*    */     void add(ConfigurationPropertyCaching caching) {
/* 84 */       this.overrides.add(caching.override());
/*    */     }
/*    */ 
/*    */     
/*    */     public void close() {
/* 89 */       this.overrides.forEach(ConfigurationPropertyCaching.CacheOverride::close);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertySourcesCaching.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */