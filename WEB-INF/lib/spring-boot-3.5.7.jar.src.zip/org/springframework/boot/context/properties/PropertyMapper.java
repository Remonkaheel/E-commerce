/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PropertyMapper
/*     */ {
/*     */   private static final Predicate<?> ALWAYS = t -> true;
/*  63 */   private static final PropertyMapper INSTANCE = new PropertyMapper(null, null);
/*     */   
/*     */   private final PropertyMapper parent;
/*     */   
/*     */   private final SourceOperator sourceOperator;
/*     */   
/*     */   private PropertyMapper(PropertyMapper parent, SourceOperator sourceOperator) {
/*  70 */     this.parent = parent;
/*  71 */     this.sourceOperator = sourceOperator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyMapper alwaysApplyingWhenNonNull() {
/*  80 */     return alwaysApplying(this::whenNonNull);
/*     */   }
/*     */   
/*     */   private <T> Source<T> whenNonNull(Source<T> source) {
/*  84 */     return source.whenNonNull();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyMapper alwaysApplying(SourceOperator operator) {
/*  94 */     Assert.notNull(operator, "'operator' must not be null");
/*  95 */     return new PropertyMapper(this, operator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Source<T> from(Supplier<T> supplier) {
/* 107 */     Assert.notNull(supplier, "'supplier' must not be null");
/* 108 */     Source<T> source = getSource(supplier);
/* 109 */     if (this.sourceOperator != null) {
/* 110 */       source = this.sourceOperator.apply(source);
/*     */     }
/* 112 */     return source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Source<T> from(T value) {
/* 123 */     return from(() -> value);
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> Source<T> getSource(Supplier<T> supplier) {
/* 128 */     if (this.parent != null) {
/* 129 */       return this.parent.from(supplier);
/*     */     }
/* 131 */     return new Source<>((Supplier<T>)SingletonSupplier.of(supplier), (Predicate)ALWAYS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyMapper get() {
/* 139 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface SourceOperator
/*     */   {
/*     */     <T> PropertyMapper.Source<T> apply(PropertyMapper.Source<T> param1Source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Source<T>
/*     */   {
/*     */     private final Supplier<T> supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Predicate<T> predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Source(Supplier<T> supplier, Predicate<T> predicate) {
/* 170 */       Assert.notNull(predicate, "'predicate' must not be null");
/* 171 */       this.supplier = supplier;
/* 172 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R extends Number> Source<Integer> asInt(Function<T, R> adapter) {
/* 182 */       return as(adapter).as(Number::intValue);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R> Source<R> as(Function<T, R> adapter) {
/* 193 */       Assert.notNull(adapter, "'adapter' must not be null");
/* 194 */       Supplier<Boolean> test = () -> Boolean.valueOf(this.predicate.test(this.supplier.get()));
/* 195 */       Predicate<R> predicate = t -> ((Boolean)test.get()).booleanValue();
/* 196 */       Supplier<R> supplier = () -> ((Boolean)test.get()).booleanValue() ? adapter.apply(this.supplier.get()) : null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 202 */       return new Source(supplier, predicate);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenNonNull() {
/* 211 */       return new Source(new PropertyMapper.NullPointerExceptionSafeSupplier<>(this.supplier), Objects::nonNull);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenTrue() {
/* 220 */       Objects.requireNonNull(Boolean.TRUE); return when(Boolean.TRUE::equals);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenFalse() {
/* 229 */       Objects.requireNonNull(Boolean.FALSE); return when(Boolean.FALSE::equals);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenHasText() {
/* 238 */       return when(value -> StringUtils.hasText(Objects.toString(value, null)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenEqualTo(Object object) {
/* 248 */       Objects.requireNonNull(object); return when(object::equals);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R extends T> Source<R> whenInstanceOf(Class<R> target) {
/* 259 */       Objects.requireNonNull(target); Objects.requireNonNull(target); return when(target::isInstance).as(target::cast);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> whenNot(Predicate<T> predicate) {
/* 269 */       Assert.notNull(predicate, "'predicate' must not be null");
/* 270 */       return when(predicate.negate());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Source<T> when(Predicate<T> predicate) {
/* 280 */       Assert.notNull(predicate, "'predicate' must not be null");
/* 281 */       return new Source(this.supplier, (this.predicate != null) ? this.predicate.and(predicate) : predicate);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void to(Consumer<T> consumer) {
/* 291 */       Assert.notNull(consumer, "'consumer' must not be null");
/* 292 */       T value = this.supplier.get();
/* 293 */       if (this.predicate.test(value)) {
/* 294 */         consumer.accept(value);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R> R to(R instance, BiFunction<R, T, R> mapper) {
/* 310 */       Assert.notNull(instance, "'instance' must not be null");
/* 311 */       Assert.notNull(mapper, "'mapper' must not be null");
/* 312 */       T value = this.supplier.get();
/* 313 */       return !this.predicate.test(value) ? instance : mapper.apply(instance, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R> R toInstance(Function<T, R> factory) {
/* 324 */       Assert.notNull(factory, "'factory' must not be null");
/* 325 */       T value = this.supplier.get();
/* 326 */       if (!this.predicate.test(value)) {
/* 327 */         throw new NoSuchElementException("No value present");
/*     */       }
/* 329 */       return factory.apply(value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void toCall(Runnable runnable) {
/* 338 */       Assert.notNull(runnable, "'runnable' must not be null");
/* 339 */       T value = this.supplier.get();
/* 340 */       if (this.predicate.test(value)) {
/* 341 */         runnable.run();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NullPointerExceptionSafeSupplier<T>
/*     */     implements Supplier<T>
/*     */   {
/*     */     private final Supplier<T> supplier;
/*     */ 
/*     */     
/*     */     NullPointerExceptionSafeSupplier(Supplier<T> supplier) {
/* 355 */       this.supplier = supplier;
/*     */     }
/*     */ 
/*     */     
/*     */     public T get() {
/*     */       try {
/* 361 */         return this.supplier.get();
/*     */       }
/* 363 */       catch (NullPointerException ex) {
/* 364 */         return null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\PropertyMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */