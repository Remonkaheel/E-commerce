/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.SimpleTypeConverter;
/*     */ import org.springframework.beans.propertyeditors.CustomBooleanEditor;
/*     */ import org.springframework.beans.propertyeditors.CustomNumberEditor;
/*     */ import org.springframework.beans.propertyeditors.FileEditor;
/*     */ import org.springframework.boot.convert.ApplicationConversionService;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.ConversionException;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.ConverterNotFoundException;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.support.GenericConversionService;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BindConverter
/*     */ {
/*     */   private static BindConverter sharedInstance;
/*     */   private final List<ConversionService> delegates;
/*     */   
/*     */   private BindConverter(List<ConversionService> conversionServices, Consumer<PropertyEditorRegistry> propertyEditorInitializer) {
/*  63 */     List<ConversionService> delegates = new ArrayList<>();
/*  64 */     delegates.add(new TypeConverterConversionService(propertyEditorInitializer));
/*  65 */     boolean hasApplication = false;
/*  66 */     if (!CollectionUtils.isEmpty(conversionServices)) {
/*  67 */       for (ConversionService conversionService : conversionServices) {
/*  68 */         delegates.add(conversionService);
/*  69 */         hasApplication = (hasApplication || conversionService instanceof ApplicationConversionService);
/*     */       } 
/*     */     }
/*  72 */     if (!hasApplication) {
/*  73 */       delegates.add(ApplicationConversionService.getSharedInstance());
/*     */     }
/*  75 */     this.delegates = Collections.unmodifiableList(delegates);
/*     */   }
/*     */   
/*     */   boolean canConvert(Object source, ResolvableType targetType, Annotation... targetAnnotations) {
/*  79 */     return canConvert(TypeDescriptor.forObject(source), new ResolvableTypeDescriptor(targetType, targetAnnotations));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean canConvert(TypeDescriptor sourceType, TypeDescriptor targetType) {
/*  84 */     for (ConversionService service : this.delegates) {
/*  85 */       if (service.canConvert(sourceType, targetType)) {
/*  86 */         return true;
/*     */       }
/*     */     } 
/*  89 */     return false;
/*     */   }
/*     */   
/*     */   <T> T convert(Object source, Bindable<T> target) {
/*  93 */     return convert(source, target.getType(), target.getAnnotations());
/*     */   }
/*     */ 
/*     */   
/*     */   <T> T convert(Object source, ResolvableType targetType, Annotation... targetAnnotations) {
/*  98 */     if (source == null) {
/*  99 */       return null;
/*     */     }
/* 101 */     return (T)convert(source, TypeDescriptor.forObject(source), new ResolvableTypeDescriptor(targetType, targetAnnotations));
/*     */   }
/*     */ 
/*     */   
/*     */   private Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 106 */     ConversionException failure = null;
/* 107 */     for (ConversionService delegate : this.delegates) {
/*     */       try {
/* 109 */         if (delegate.canConvert(sourceType, targetType)) {
/* 110 */           return delegate.convert(source, sourceType, targetType);
/*     */         }
/*     */       }
/* 113 */       catch (ConversionException ex) {
/* 114 */         if (failure == null && ex instanceof org.springframework.core.convert.ConversionFailedException) {
/* 115 */           failure = ex;
/*     */         }
/*     */       } 
/*     */     } 
/* 119 */     throw (failure != null) ? failure : new ConverterNotFoundException(sourceType, targetType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static BindConverter get(List<ConversionService> conversionServices, Consumer<PropertyEditorRegistry> propertyEditorInitializer) {
/* 125 */     boolean sharedApplicationConversionService = (conversionServices == null || (conversionServices.size() == 1 && conversionServices.get(0) == ApplicationConversionService.getSharedInstance()));
/* 126 */     if (propertyEditorInitializer == null && sharedApplicationConversionService) {
/* 127 */       return getSharedInstance();
/*     */     }
/* 129 */     return new BindConverter(conversionServices, propertyEditorInitializer);
/*     */   }
/*     */   
/*     */   private static BindConverter getSharedInstance() {
/* 133 */     if (sharedInstance == null) {
/* 134 */       sharedInstance = new BindConverter(null, null);
/*     */     }
/* 136 */     return sharedInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ResolvableTypeDescriptor
/*     */     extends TypeDescriptor
/*     */   {
/*     */     ResolvableTypeDescriptor(ResolvableType resolvableType, Annotation[] annotations) {
/* 145 */       super(resolvableType, null, annotations);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class TypeConverterConversionService
/*     */     extends GenericConversionService
/*     */   {
/*     */     TypeConverterConversionService(Consumer<PropertyEditorRegistry> initializer) {
/* 158 */       ApplicationConversionService.addDelimitedStringConverters((ConverterRegistry)this);
/* 159 */       addConverter((GenericConverter)new BindConverter.TypeConverterConverter(initializer));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean canConvert(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 165 */       if (targetType.isArray() && targetType.getElementTypeDescriptor().isPrimitive()) {
/* 166 */         return false;
/*     */       }
/* 168 */       return super.canConvert(sourceType, targetType);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TypeConverterConverter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private static final Set<Class<?>> EXCLUDED_EDITORS;
/*     */     private final Consumer<PropertyEditorRegistry> initializer;
/*     */     private final SimpleTypeConverter matchesOnlyTypeConverter;
/*     */     
/*     */     static {
/* 180 */       Set<Class<?>> excluded = new HashSet<>();
/* 181 */       excluded.add(CustomNumberEditor.class);
/* 182 */       excluded.add(CustomBooleanEditor.class);
/* 183 */       excluded.add(FileEditor.class);
/* 184 */       EXCLUDED_EDITORS = Collections.unmodifiableSet(excluded);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TypeConverterConverter(Consumer<PropertyEditorRegistry> initializer) {
/* 194 */       this.initializer = initializer;
/* 195 */       this.matchesOnlyTypeConverter = createTypeConverter();
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 200 */       return Set.of(new GenericConverter.ConvertiblePair(String.class, Object.class), new GenericConverter.ConvertiblePair(String.class, Resource[].class), new GenericConverter.ConvertiblePair(String.class, Collection.class));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 207 */       Class<?> type = targetType.getType();
/* 208 */       if (type == null || type == Object.class || Map.class.isAssignableFrom(type)) {
/* 209 */         return false;
/*     */       }
/* 211 */       if (Collection.class.isAssignableFrom(type)) {
/* 212 */         TypeDescriptor elementType = targetType.getElementTypeDescriptor();
/* 213 */         if (elementType == null || !Resource.class.isAssignableFrom(elementType.getType())) {
/* 214 */           return false;
/*     */         }
/*     */       } 
/* 217 */       PropertyEditor editor = this.matchesOnlyTypeConverter.getDefaultEditor(type);
/* 218 */       if (editor == null) {
/* 219 */         editor = this.matchesOnlyTypeConverter.findCustomEditor(type, null);
/*     */       }
/* 221 */       if (editor == null && String.class != type) {
/* 222 */         editor = BeanUtils.findEditorByConvention(type);
/*     */       }
/* 224 */       return (editor != null && !EXCLUDED_EDITORS.contains(editor.getClass()));
/*     */     }
/*     */ 
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 229 */       return createTypeConverter().convertIfNecessary(source, targetType.getType(), targetType);
/*     */     }
/*     */     
/*     */     private SimpleTypeConverter createTypeConverter() {
/* 233 */       SimpleTypeConverter typeConverter = new SimpleTypeConverter();
/* 234 */       if (this.initializer != null) {
/* 235 */         this.initializer.accept(typeConverter);
/*     */       }
/* 237 */       return typeConverter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\BindConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */