/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DataObjectPropertyName
/*    */ {
/*    */   public static String toDashedForm(String name) {
/* 38 */     StringBuilder result = new StringBuilder(name.length());
/* 39 */     boolean inIndex = false;
/* 40 */     for (int i = 0; i < name.length(); i++) {
/* 41 */       char ch = name.charAt(i);
/* 42 */       if (inIndex) {
/* 43 */         result.append(ch);
/* 44 */         if (ch == ']') {
/* 45 */           inIndex = false;
/*    */         
/*    */         }
/*    */       }
/* 49 */       else if (ch == '[') {
/* 50 */         inIndex = true;
/* 51 */         result.append(ch);
/*    */       } else {
/*    */         
/* 54 */         ch = (ch != '_') ? ch : '-';
/* 55 */         if (Character.isUpperCase(ch) && !result.isEmpty() && result.charAt(result.length() - 1) != '-') {
/* 56 */           result.append('-');
/*    */         }
/* 58 */         result.append(Character.toLowerCase(ch));
/*    */       } 
/*    */     } 
/*    */     
/* 62 */     return result.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\DataObjectPropertyName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */