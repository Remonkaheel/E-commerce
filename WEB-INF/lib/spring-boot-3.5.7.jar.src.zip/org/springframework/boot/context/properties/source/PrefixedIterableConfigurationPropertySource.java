/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PrefixedIterableConfigurationPropertySource
/*    */   extends PrefixedConfigurationPropertySource
/*    */   implements IterableConfigurationPropertySource
/*    */ {
/*    */   PrefixedIterableConfigurationPropertySource(IterableConfigurationPropertySource source, String prefix) {
/* 30 */     super(source, prefix);
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<ConfigurationPropertyName> stream() {
/* 35 */     return getSource().stream().map(this::stripPrefix);
/*    */   }
/*    */   
/*    */   private ConfigurationPropertyName stripPrefix(ConfigurationPropertyName name) {
/* 39 */     return getPrefix().isAncestorOf(name) ? name.subName(getPrefix().getNumberOfElements()) : name;
/*    */   }
/*    */ 
/*    */   
/*    */   protected IterableConfigurationPropertySource getSource() {
/* 44 */     return (IterableConfigurationPropertySource)super.getSource();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\PrefixedIterableConfigurationPropertySource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */