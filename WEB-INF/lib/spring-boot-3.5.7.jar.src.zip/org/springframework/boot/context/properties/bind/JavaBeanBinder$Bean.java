/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.ResolvableType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Bean<T>
/*     */   extends JavaBeanBinder.BeanProperties
/*     */ {
/*     */   Bean(ResolvableType type, Class<?> resolvedType) {
/* 264 */     super(type, resolvedType);
/*     */   }
/*     */ 
/*     */   
/*     */   JavaBeanBinder.BeanSupplier<T> getSupplier(Bindable<T> target) {
/* 269 */     return new JavaBeanBinder.BeanSupplier<>(() -> {
/*     */           T instance = null;
/*     */           if (target.getValue() != null) {
/*     */             instance = target.getValue().get();
/*     */           }
/*     */           if (instance == null) {
/*     */             instance = (T)BeanUtils.instantiateClass(getResolvedType());
/*     */           }
/*     */           return (Supplier)instance;
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> Bean<T> get(Bindable<T> bindable, Binder.Context context, boolean canCallGetValue) {
/* 283 */     ResolvableType type = bindable.getType();
/* 284 */     Class<?> resolvedType = type.resolve(Object.class);
/* 285 */     Supplier<T> value = bindable.getValue();
/* 286 */     T instance = null;
/* 287 */     if (canCallGetValue && value != null) {
/* 288 */       instance = value.get();
/* 289 */       resolvedType = (instance != null) ? instance.getClass() : resolvedType;
/*     */     } 
/* 291 */     if (instance == null && !isInstantiable(resolvedType)) {
/* 292 */       return null;
/*     */     }
/* 294 */     Map<CacheKey, Bean<?>> cache = getCache(context);
/* 295 */     CacheKey cacheKey = new CacheKey(type, resolvedType);
/* 296 */     Bean<?> bean = cache.get(cacheKey);
/* 297 */     if (bean == null) {
/* 298 */       bean = new Bean(type, resolvedType);
/* 299 */       cache.put(cacheKey, bean);
/*     */     } 
/* 301 */     return (Bean)bean;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Map<CacheKey, Bean<?>> getCache(Binder.Context context) {
/* 306 */     Map<CacheKey, Bean<?>> cache = (Map<CacheKey, Bean<?>>)context.getCache().get(Bean.class);
/* 307 */     if (cache == null) {
/* 308 */       cache = new ConcurrentHashMap<>();
/* 309 */       context.getCache().put(Bean.class, cache);
/*     */     } 
/* 311 */     return cache;
/*     */   }
/*     */   
/*     */   private static boolean isInstantiable(Class<?> type) {
/* 315 */     if (type.isInterface()) {
/* 316 */       return false;
/*     */     }
/*     */     try {
/* 319 */       type.getDeclaredConstructor(new Class[0]);
/* 320 */       return true;
/*     */     }
/* 322 */     catch (Exception ex) {
/* 323 */       return false;
/*     */     } 
/*     */   }
/*     */   private static final class CacheKey extends Record { private final ResolvableType type; private final Class<?> resolvedType;
/* 327 */     private CacheKey(ResolvableType type, Class<?> resolvedType) { this.type = type; this.resolvedType = resolvedType; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #327	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 327 */       //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey; } public ResolvableType type() { return this.type; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #327	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #327	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;
/* 327 */       //   0	8	1	o	Ljava/lang/Object; } public Class<?> resolvedType() { return this.resolvedType; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\JavaBeanBinder$Bean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */