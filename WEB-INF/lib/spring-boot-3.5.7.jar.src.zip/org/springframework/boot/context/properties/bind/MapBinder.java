/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyState;
/*     */ import org.springframework.boot.context.properties.source.IterableConfigurationPropertySource;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.ResolvableType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MapBinder
/*     */   extends AggregateBinder<Map<Object, Object>>
/*     */ {
/*  43 */   private static final Bindable<Map<String, String>> STRING_STRING_MAP = Bindable.mapOf(String.class, String.class);
/*     */   
/*     */   MapBinder(Binder.Context context) {
/*  46 */     super(context);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isAllowRecursiveBinding(ConfigurationPropertySource source) {
/*  51 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object bindAggregate(ConfigurationPropertyName name, Bindable<?> target, AggregateElementBinder elementBinder) {
/*  57 */     Bindable<?> resolvedTarget = resolveTarget(target);
/*  58 */     boolean hasDescendants = hasDescendants(name);
/*  59 */     if (!hasDescendants && !ConfigurationPropertyName.EMPTY.equals(name)) {
/*  60 */       for (ConfigurationPropertySource source : getContext().getSources()) {
/*  61 */         ConfigurationProperty property = source.getConfigurationProperty(name);
/*  62 */         if (property != null) {
/*  63 */           getContext().setConfigurationProperty(property);
/*  64 */           Object result = getContext().getPlaceholdersResolver().resolvePlaceholders(property.getValue());
/*  65 */           return getContext().getConverter().convert(result, target);
/*     */         } 
/*     */       } 
/*     */     }
/*  69 */     Map<Object, Object> map = createMap(target);
/*  70 */     for (ConfigurationPropertySource source : getContext().getSources()) {
/*  71 */       if (!ConfigurationPropertyName.EMPTY.equals(name)) {
/*  72 */         Objects.requireNonNull(name); source = source.filter(name::isAncestorOf);
/*     */       } 
/*  74 */       (new EntryBinder(name, resolvedTarget, elementBinder)).bindEntries(source, map);
/*     */     } 
/*  76 */     return map.isEmpty() ? null : map;
/*     */   }
/*     */   
/*     */   private Map<Object, Object> createMap(Bindable<?> target) {
/*  80 */     Class<?> mapType = (target.getValue() != null) ? Map.class : target.getType().resolve(Object.class);
/*  81 */     if (EnumMap.class.isAssignableFrom(mapType)) {
/*  82 */       Class<?> keyType = target.getType().asMap().resolveGeneric(new int[] { 0 });
/*  83 */       return CollectionFactory.createMap(mapType, keyType, 0);
/*     */     } 
/*  85 */     return CollectionFactory.createMap(mapType, 0);
/*     */   }
/*     */   
/*     */   private boolean hasDescendants(ConfigurationPropertyName name) {
/*  89 */     for (ConfigurationPropertySource source : getContext().getSources()) {
/*  90 */       if (source.containsDescendantOf(name) == ConfigurationPropertyState.PRESENT) {
/*  91 */         return true;
/*     */       }
/*     */     } 
/*  94 */     return false;
/*     */   }
/*     */   
/*     */   private Bindable<?> resolveTarget(Bindable<?> target) {
/*  98 */     Class<?> type = target.getType().resolve(Object.class);
/*  99 */     if (Properties.class.isAssignableFrom(type)) {
/* 100 */       return STRING_STRING_MAP;
/*     */     }
/* 102 */     return target;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<Object, Object> merge(Supplier<Map<Object, Object>> existing, Map<Object, Object> additional) {
/* 107 */     Map<Object, Object> existingMap = getExistingIfPossible(existing);
/* 108 */     if (existingMap == null) {
/* 109 */       return additional;
/*     */     }
/*     */     try {
/* 112 */       existingMap.putAll(additional);
/* 113 */       return copyIfPossible(existingMap);
/*     */     }
/* 115 */     catch (UnsupportedOperationException ex) {
/* 116 */       Map<Object, Object> result = createNewMap(additional.getClass(), existingMap);
/* 117 */       result.putAll(additional);
/* 118 */       return result;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<Object, Object> getExistingIfPossible(Supplier<Map<Object, Object>> existing) {
/*     */     try {
/* 124 */       return existing.get();
/*     */     }
/* 126 */     catch (Exception ex) {
/* 127 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<Object, Object> copyIfPossible(Map<Object, Object> map) {
/*     */     try {
/* 133 */       return createNewMap(map.getClass(), map);
/*     */     }
/* 135 */     catch (Exception ex) {
/* 136 */       return map;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<Object, Object> createNewMap(Class<?> mapClass, Map<Object, Object> map) {
/* 141 */     Map<Object, Object> result = CollectionFactory.createMap(mapClass, map.size());
/* 142 */     result.putAll(map);
/* 143 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private class EntryBinder
/*     */   {
/*     */     private final ConfigurationPropertyName root;
/*     */     
/*     */     private final AggregateElementBinder elementBinder;
/*     */     
/*     */     private final ResolvableType mapType;
/*     */     
/*     */     private final ResolvableType keyType;
/*     */     
/*     */     private final ResolvableType valueType;
/*     */     
/*     */     private final Class<?> resolvedValueType;
/*     */     
/*     */     private final boolean valueTreatedAsNestedMap;
/*     */     
/*     */     private final Bindable<Object> bindableMapType;
/*     */     private final Bindable<Object> bindableValueType;
/*     */     
/*     */     EntryBinder(ConfigurationPropertyName root, Bindable<?> target, AggregateElementBinder elementBinder) {
/* 167 */       this.root = root;
/* 168 */       this.elementBinder = elementBinder;
/* 169 */       this.mapType = target.getType().asMap();
/* 170 */       this.keyType = this.mapType.getGeneric(new int[] { 0 });
/* 171 */       this.valueType = this.mapType.getGeneric(new int[] { 1 });
/* 172 */       this.resolvedValueType = this.valueType.resolve(Object.class);
/* 173 */       this.valueTreatedAsNestedMap = Object.class.equals(this.resolvedValueType);
/* 174 */       this.bindableMapType = Bindable.of(this.mapType);
/* 175 */       this.bindableValueType = Bindable.of(this.valueType);
/*     */     }
/*     */     
/*     */     void bindEntries(ConfigurationPropertySource source, Map<Object, Object> map) {
/* 179 */       if (source instanceof IterableConfigurationPropertySource) { IterableConfigurationPropertySource iterableSource = (IterableConfigurationPropertySource)source;
/* 180 */         for (ConfigurationPropertyName name : iterableSource) {
/* 181 */           ConfigurationPropertyName entryName = getEntryName(source, name);
/* 182 */           Object key = MapBinder.this.getContext().getConverter().convert(getKeyName(entryName), this.keyType, new java.lang.annotation.Annotation[0]);
/* 183 */           Bindable<?> valueBindable = getValueBindable(name);
/* 184 */           map.computeIfAbsent(key, k -> this.elementBinder.bind(entryName, valueBindable));
/*     */         }  }
/*     */     
/*     */     }
/*     */     
/*     */     private Bindable<?> getValueBindable(ConfigurationPropertyName name) {
/* 190 */       return (!isParentOf(name) && this.valueTreatedAsNestedMap) ? this.bindableMapType : this.bindableValueType;
/*     */     }
/*     */ 
/*     */     
/*     */     private ConfigurationPropertyName getEntryName(ConfigurationPropertySource source, ConfigurationPropertyName name) {
/* 195 */       if (Collection.class.isAssignableFrom(this.resolvedValueType) || this.valueType.isArray()) {
/* 196 */         return chopNameAtNumericIndex(name);
/*     */       }
/* 198 */       if (!isParentOf(name) && (this.valueTreatedAsNestedMap || !isScalarValue(source, name))) {
/* 199 */         return name.chop(this.root.getNumberOfElements() + 1);
/*     */       }
/* 201 */       return name;
/*     */     }
/*     */     
/*     */     private boolean isParentOf(ConfigurationPropertyName name) {
/* 205 */       return this.root.isParentOf(name);
/*     */     }
/*     */     
/*     */     private ConfigurationPropertyName chopNameAtNumericIndex(ConfigurationPropertyName name) {
/* 209 */       int start = this.root.getNumberOfElements() + 1;
/* 210 */       int size = name.getNumberOfElements();
/* 211 */       for (int i = start; i < size; i++) {
/* 212 */         if (name.isNumericIndex(i)) {
/* 213 */           return name.chop(i);
/*     */         }
/*     */       } 
/* 216 */       return name;
/*     */     }
/*     */     
/*     */     private boolean isScalarValue(ConfigurationPropertySource source, ConfigurationPropertyName name) {
/* 220 */       Class<?> resolved = this.valueType.resolve(Object.class);
/* 221 */       if (!resolved.getName().startsWith("java.lang") && !resolved.isEnum()) {
/* 222 */         return false;
/*     */       }
/* 224 */       ConfigurationProperty property = source.getConfigurationProperty(name);
/* 225 */       if (property == null) {
/* 226 */         return false;
/*     */       }
/* 228 */       Object value = property.getValue();
/* 229 */       value = MapBinder.this.getContext().getPlaceholdersResolver().resolvePlaceholders(value);
/* 230 */       return MapBinder.this.getContext().getConverter().canConvert(value, this.valueType, new java.lang.annotation.Annotation[0]);
/*     */     }
/*     */     
/*     */     private String getKeyName(ConfigurationPropertyName name) {
/* 234 */       StringBuilder result = new StringBuilder();
/* 235 */       for (int i = this.root.getNumberOfElements(); i < name.getNumberOfElements(); i++) {
/* 236 */         if (!result.isEmpty()) {
/* 237 */           result.append('.');
/*     */         }
/* 239 */         result.append(name.getElement(i, ConfigurationPropertyName.Form.ORIGINAL));
/*     */       } 
/* 241 */       return result.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\MapBinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */