/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.boot.context.TypeExcludeFilter;
/*     */ import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationPropertiesScanRegistrar
/*     */   implements ImportBeanDefinitionRegistrar
/*     */ {
/*     */   private final Environment environment;
/*     */   private final ResourceLoader resourceLoader;
/*     */   
/*     */   ConfigurationPropertiesScanRegistrar(Environment environment, ResourceLoader resourceLoader) {
/*  55 */     this.environment = environment;
/*  56 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/*  61 */     Set<String> packagesToScan = getPackagesToScan(importingClassMetadata);
/*  62 */     scan(registry, packagesToScan);
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> getPackagesToScan(AnnotationMetadata metadata) {
/*  67 */     AnnotationAttributes attributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(ConfigurationPropertiesScan.class.getName()));
/*  68 */     String[] basePackages = attributes.getStringArray("basePackages");
/*  69 */     Class<?>[] basePackageClasses = attributes.getClassArray("basePackageClasses");
/*  70 */     Set<String> packagesToScan = new LinkedHashSet<>(Arrays.asList(basePackages));
/*  71 */     for (Class<?> basePackageClass : basePackageClasses) {
/*  72 */       packagesToScan.add(ClassUtils.getPackageName(basePackageClass));
/*     */     }
/*  74 */     if (packagesToScan.isEmpty()) {
/*  75 */       packagesToScan.add(ClassUtils.getPackageName(metadata.getClassName()));
/*     */     }
/*  77 */     packagesToScan.removeIf(candidate -> !StringUtils.hasText(candidate));
/*  78 */     return packagesToScan;
/*     */   }
/*     */   
/*     */   private void scan(BeanDefinitionRegistry registry, Set<String> packages) {
/*  82 */     ConfigurationPropertiesBeanRegistrar registrar = new ConfigurationPropertiesBeanRegistrar(registry);
/*  83 */     ClassPathScanningCandidateComponentProvider scanner = getScanner(registry);
/*  84 */     for (String basePackage : packages) {
/*  85 */       for (BeanDefinition candidate : scanner.findCandidateComponents(basePackage)) {
/*  86 */         register(registrar, candidate.getBeanClassName());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private ClassPathScanningCandidateComponentProvider getScanner(BeanDefinitionRegistry registry) {
/*  92 */     ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(false);
/*  93 */     scanner.setEnvironment(this.environment);
/*  94 */     scanner.setResourceLoader(this.resourceLoader);
/*  95 */     scanner.addIncludeFilter((TypeFilter)new AnnotationTypeFilter(ConfigurationProperties.class));
/*  96 */     TypeExcludeFilter typeExcludeFilter = new TypeExcludeFilter();
/*  97 */     typeExcludeFilter.setBeanFactory((BeanFactory)registry);
/*  98 */     scanner.addExcludeFilter((TypeFilter)typeExcludeFilter);
/*  99 */     return scanner;
/*     */   }
/*     */   
/*     */   private void register(ConfigurationPropertiesBeanRegistrar registrar, String className) throws LinkageError {
/*     */     try {
/* 104 */       register(registrar, ClassUtils.forName(className, null));
/*     */     }
/* 106 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void register(ConfigurationPropertiesBeanRegistrar registrar, Class<?> type) {
/* 112 */     if (!isComponent(type)) {
/* 113 */       registrar.register(type);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isComponent(Class<?> type) {
/* 118 */     return MergedAnnotations.from(type, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).isPresent(Component.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesScanRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */