/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.boot.context.properties.bind.BindMethod;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationPropertiesBindingPostProcessor
/*     */   implements BeanPostProcessor, PriorityOrdered, ApplicationContextAware, InitializingBean
/*     */ {
/*  50 */   public static final String BEAN_NAME = ConfigurationPropertiesBindingPostProcessor.class.getName();
/*     */   
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */   private BeanDefinitionRegistry registry;
/*     */   
/*     */   private ConfigurationPropertiesBinder binder;
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/*  60 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  67 */     this.registry = (BeanDefinitionRegistry)this.applicationContext.getAutowireCapableBeanFactory();
/*  68 */     this.binder = ConfigurationPropertiesBinder.get((BeanFactory)this.applicationContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  73 */     return -2147483647;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
/*  78 */     if (!hasBoundValueObject(beanName)) {
/*  79 */       bind(ConfigurationPropertiesBean.get(this.applicationContext, bean, beanName));
/*     */     }
/*  81 */     return bean;
/*     */   }
/*     */   
/*     */   private boolean hasBoundValueObject(String beanName) {
/*  85 */     return BindMethod.VALUE_OBJECT.equals(BindMethodAttribute.get(this.registry, beanName));
/*     */   }
/*     */   
/*     */   private void bind(ConfigurationPropertiesBean bean) {
/*  89 */     if (bean == null) {
/*     */       return;
/*     */     }
/*  92 */     Assert.state((bean.asBindTarget().getBindMethod() != BindMethod.VALUE_OBJECT), "Cannot bind @ConfigurationProperties for bean '" + bean
/*  93 */         .getName() + "'. Ensure that @ConstructorBinding has not been applied to regular bean");
/*     */     
/*     */     try {
/*  96 */       this.binder.bind(bean);
/*     */     }
/*  98 */     catch (Exception ex) {
/*  99 */       throw new ConfigurationPropertiesBindException(bean, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register(BeanDefinitionRegistry registry) {
/* 110 */     Assert.notNull(registry, "'registry' must not be null");
/* 111 */     if (!registry.containsBeanDefinition(BEAN_NAME)) {
/*     */ 
/*     */       
/* 114 */       AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(ConfigurationPropertiesBindingPostProcessor.class).getBeanDefinition();
/* 115 */       abstractBeanDefinition.setRole(2);
/* 116 */       registry.registerBeanDefinition(BEAN_NAME, (BeanDefinition)abstractBeanDefinition);
/*     */     } 
/* 118 */     ConfigurationPropertiesBinder.register(registry);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBindingPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */