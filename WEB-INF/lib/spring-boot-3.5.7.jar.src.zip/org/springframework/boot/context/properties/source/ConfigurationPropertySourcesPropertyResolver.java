/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import org.springframework.core.convert.ConversionFailedException;
/*     */ import org.springframework.core.env.AbstractPropertyResolver;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.core.env.PropertySourcesPropertyResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationPropertySourcesPropertyResolver
/*     */   extends AbstractPropertyResolver
/*     */ {
/*     */   private final MutablePropertySources propertySources;
/*     */   private final DefaultResolver defaultResolver;
/*     */   
/*     */   ConfigurationPropertySourcesPropertyResolver(MutablePropertySources propertySources) {
/*  39 */     this.propertySources = propertySources;
/*  40 */     this.defaultResolver = new DefaultResolver((PropertySources)propertySources);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsProperty(String key) {
/*  45 */     ConfigurationPropertySourcesPropertySource attached = getAttached();
/*  46 */     if (attached != null) {
/*  47 */       ConfigurationPropertyName name = ConfigurationPropertyName.of(key, true);
/*  48 */       if (name != null) {
/*     */         try {
/*  50 */           return (attached.findConfigurationProperty(name) != null);
/*     */         }
/*  52 */         catch (Exception exception) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  57 */     return this.defaultResolver.containsProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProperty(String key) {
/*  62 */     return getProperty(key, String.class, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getProperty(String key, Class<T> targetValueType) {
/*  67 */     return getProperty(key, targetValueType, true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getPropertyAsRawString(String key) {
/*  72 */     return getProperty(key, String.class, false);
/*     */   }
/*     */   
/*     */   private <T> T getProperty(String key, Class<T> targetValueType, boolean resolveNestedPlaceholders) {
/*  76 */     Object value = findPropertyValue(key);
/*  77 */     if (value == null) {
/*  78 */       return null;
/*     */     }
/*  80 */     if (resolveNestedPlaceholders && value instanceof String) { String string = (String)value;
/*  81 */       value = resolveNestedPlaceholders(string); }
/*     */     
/*     */     try {
/*  84 */       return (T)convertValueIfNecessary(value, targetValueType);
/*     */     }
/*  86 */     catch (ConversionFailedException ex) {
/*     */       
/*  88 */       Exception wrappedCause = new InvalidConfigurationPropertyValueException(key, value, "Failed to convert to type " + String.valueOf(ex.getTargetType()), ex.getCause());
/*  89 */       throw new ConversionFailedException(ex.getSourceType(), ex.getTargetType(), ex.getValue(), wrappedCause);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object findPropertyValue(String key) {
/*  94 */     ConfigurationPropertySourcesPropertySource attached = getAttached();
/*  95 */     if (attached != null) {
/*  96 */       ConfigurationPropertyName name = ConfigurationPropertyName.of(key, true);
/*  97 */       if (name != null) {
/*     */         try {
/*  99 */           ConfigurationProperty configurationProperty = attached.findConfigurationProperty(name);
/* 100 */           return (configurationProperty != null) ? configurationProperty.getValue() : null;
/*     */         }
/* 102 */         catch (Exception exception) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 107 */     return this.defaultResolver.getProperty(key, Object.class, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private ConfigurationPropertySourcesPropertySource getAttached() {
/* 112 */     ConfigurationPropertySourcesPropertySource attached = (ConfigurationPropertySourcesPropertySource)ConfigurationPropertySources.getAttached(this.propertySources);
/* 113 */     Iterable<ConfigurationPropertySource> attachedSource = (attached != null) ? (Iterable<ConfigurationPropertySource>)attached.getSource() : null;
/* 114 */     if (attachedSource instanceof SpringConfigurationPropertySources) { SpringConfigurationPropertySources springSource = (SpringConfigurationPropertySources)attachedSource; if (springSource
/* 115 */         .isUsingSources((Iterable<PropertySource<?>>)this.propertySources))
/* 116 */         return attached;  }
/*     */     
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DefaultResolver
/*     */     extends PropertySourcesPropertyResolver
/*     */   {
/*     */     DefaultResolver(PropertySources propertySources) {
/* 128 */       super(propertySources);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T getProperty(String key, Class<T> targetValueType, boolean resolveNestedPlaceholders) {
/* 133 */       return (T)super.getProperty(key, targetValueType, resolveNestedPlaceholders);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertySourcesPropertyResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */