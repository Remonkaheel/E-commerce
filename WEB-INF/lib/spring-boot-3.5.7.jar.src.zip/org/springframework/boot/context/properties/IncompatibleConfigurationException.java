/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IncompatibleConfigurationException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final List<String> incompatibleKeys;
/*    */   
/*    */   public IncompatibleConfigurationException(String... incompatibleKeys) {
/* 35 */     super("The following configuration properties have incompatible values: " + Arrays.toString((Object[])incompatibleKeys));
/* 36 */     this.incompatibleKeys = Arrays.asList(incompatibleKeys);
/*    */   }
/*    */   
/*    */   public Collection<String> getIncompatibleKeys() {
/* 40 */     return this.incompatibleKeys;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\IncompatibleConfigurationException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */