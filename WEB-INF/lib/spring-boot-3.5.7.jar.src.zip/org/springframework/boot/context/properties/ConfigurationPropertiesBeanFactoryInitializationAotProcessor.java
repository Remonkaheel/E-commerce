/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotProcessor;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.boot.context.properties.bind.BindMethod;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.bind.BindableRuntimeHintsRegistrar;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConfigurationPropertiesBeanFactoryInitializationAotProcessor
/*    */   implements BeanFactoryInitializationAotProcessor
/*    */ {
/*    */   public ConfigurationPropertiesReflectionHintsContribution processAheadOfTime(ConfigurableListableBeanFactory beanFactory) {
/* 46 */     String[] beanNames = beanFactory.getBeanNamesForAnnotation(ConfigurationProperties.class);
/* 47 */     List<Bindable<?>> bindables = new ArrayList<>();
/* 48 */     for (String beanName : beanNames) {
/* 49 */       Class<?> beanType = beanFactory.getType(beanName, false);
/* 50 */       if (beanType != null) {
/*    */ 
/*    */         
/* 53 */         BindMethod bindMethod = beanFactory.containsBeanDefinition(beanName) ? (BindMethod)beanFactory.getBeanDefinition(beanName).getAttribute(BindMethod.class.getName()) : null;
/* 54 */         bindables.add(Bindable.of(ClassUtils.getUserClass(beanType))
/* 55 */             .withBindMethod((bindMethod != null) ? bindMethod : BindMethod.JAVA_BEAN));
/*    */       } 
/*    */     } 
/* 58 */     return !bindables.isEmpty() ? new ConfigurationPropertiesReflectionHintsContribution(bindables) : null;
/*    */   }
/*    */   
/*    */   static final class ConfigurationPropertiesReflectionHintsContribution
/*    */     implements BeanFactoryInitializationAotContribution
/*    */   {
/*    */     private final List<Bindable<?>> bindables;
/*    */     
/*    */     private ConfigurationPropertiesReflectionHintsContribution(List<Bindable<?>> bindables) {
/* 67 */       this.bindables = bindables;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 73 */       BindableRuntimeHintsRegistrar.forBindables(this.bindables)
/* 74 */         .registerHints(generationContext.getRuntimeHints());
/*    */     }
/*    */     
/*    */     Iterable<Bindable<?>> getBindables() {
/* 78 */       return this.bindables;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBeanFactoryInitializationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */