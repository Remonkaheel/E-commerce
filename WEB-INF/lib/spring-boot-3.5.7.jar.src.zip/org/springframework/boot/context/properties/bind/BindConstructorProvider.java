/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface BindConstructorProvider
/*    */ {
/* 34 */   public static final BindConstructorProvider DEFAULT = new DefaultBindConstructorProvider();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Constructor<?> getBindConstructor(Class<?> type, boolean isNestedConstructorBinding) {
/* 46 */     return getBindConstructor(Bindable.of(type), isNestedConstructorBinding);
/*    */   }
/*    */   
/*    */   Constructor<?> getBindConstructor(Bindable<?> paramBindable, boolean paramBoolean);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\BindConstructorProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */