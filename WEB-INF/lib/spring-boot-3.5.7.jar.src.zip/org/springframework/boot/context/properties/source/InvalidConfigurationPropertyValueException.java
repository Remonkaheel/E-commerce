/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidConfigurationPropertyValueException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final String name;
/*    */   private final Object value;
/*    */   private final String reason;
/*    */   
/*    */   public InvalidConfigurationPropertyValueException(String name, Object value, String reason) {
/* 46 */     this(name, value, reason, null);
/*    */   }
/*    */   
/*    */   InvalidConfigurationPropertyValueException(String name, Object value, String reason, Throwable cause) {
/* 50 */     super("Property " + name + " with value '" + String.valueOf(value) + "' is invalid: " + reason, cause);
/* 51 */     Assert.notNull(name, "'name' must not be null");
/* 52 */     this.name = name;
/* 53 */     this.value = value;
/* 54 */     this.reason = reason;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 62 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 70 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getReason() {
/* 78 */     return this.reason;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\InvalidConfigurationPropertyValueException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */