/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.PropertySourceOrigin;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.SystemEnvironmentPropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringConfigurationPropertySource
/*     */   implements ConfigurationPropertySource
/*     */ {
/*  56 */   private static final PropertyMapper[] DEFAULT_MAPPERS = new PropertyMapper[] { DefaultPropertyMapper.INSTANCE };
/*     */   
/*  58 */   private static final PropertyMapper[] SYSTEM_ENVIRONMENT_MAPPERS = new PropertyMapper[] { SystemEnvironmentPropertyMapper.INSTANCE, DefaultPropertyMapper.INSTANCE };
/*     */ 
/*     */ 
/*     */   
/*     */   private final PropertySource<?> propertySource;
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean systemEnvironmentSource;
/*     */ 
/*     */ 
/*     */   
/*     */   private final PropertyMapper[] mappers;
/*     */ 
/*     */ 
/*     */   
/*     */   SpringConfigurationPropertySource(PropertySource<?> propertySource, boolean systemEnvironmentSource, PropertyMapper... mappers) {
/*  75 */     Assert.notNull(propertySource, "'propertySource' must not be null");
/*  76 */     Assert.isTrue((mappers.length > 0), "'mappers' must contain at least one item");
/*  77 */     this.propertySource = propertySource;
/*  78 */     this.systemEnvironmentSource = systemEnvironmentSource;
/*  79 */     this.mappers = mappers;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName name) {
/*  84 */     if (name == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     for (PropertyMapper mapper : this.mappers) {
/*     */       try {
/*  89 */         for (String candidate : mapper.map(name)) {
/*  90 */           Object value = getPropertySourceProperty(candidate);
/*  91 */           if (value != null) {
/*  92 */             Origin origin = PropertySourceOrigin.get(this.propertySource, candidate);
/*  93 */             return ConfigurationProperty.of(this, name, value, origin);
/*     */           }
/*     */         
/*     */         } 
/*  97 */       } catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object getPropertySourceProperty(String name) {
/* 107 */     PropertySource<?> propertySource = getPropertySource();
/* 108 */     return !this.systemEnvironmentSource ? propertySource.getProperty(name) : 
/* 109 */       getSystemEnvironmentProperty((Map<String, Object>)((SystemEnvironmentPropertySource)propertySource).getSource(), name);
/*     */   }
/*     */   
/*     */   Object getSystemEnvironmentProperty(Map<String, Object> systemEnvironment, String name) {
/* 113 */     Object value = systemEnvironment.get(name);
/* 114 */     return (value != null) ? value : systemEnvironment.get(name.toLowerCase(Locale.ROOT));
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/* 119 */     PropertySource<?> source = getPropertySource();
/* 120 */     Object underlyingSource = source.getSource();
/* 121 */     if (underlyingSource instanceof java.util.Random) {
/* 122 */       return containsDescendantOfForRandom("random", name);
/*     */     }
/* 124 */     if (underlyingSource instanceof PropertySource) { PropertySource<?> underlyingPropertySource = (PropertySource)underlyingSource; if (underlyingPropertySource
/* 125 */         .getSource() instanceof java.util.Random)
/*     */       {
/* 127 */         return containsDescendantOfForRandom(source.getName(), name); }  }
/*     */     
/* 129 */     return ConfigurationPropertyState.UNKNOWN;
/*     */   }
/*     */ 
/*     */   
/*     */   private static ConfigurationPropertyState containsDescendantOfForRandom(String prefix, ConfigurationPropertyName name) {
/* 134 */     if (name.getNumberOfElements() > 1 && name.getElement(0, ConfigurationPropertyName.Form.DASHED).equals(prefix)) {
/* 135 */       return ConfigurationPropertyState.PRESENT;
/*     */     }
/* 137 */     return ConfigurationPropertyState.ABSENT;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getUnderlyingSource() {
/* 142 */     return this.propertySource;
/*     */   }
/*     */   
/*     */   protected PropertySource<?> getPropertySource() {
/* 146 */     return this.propertySource;
/*     */   }
/*     */   
/*     */   protected final boolean isSystemEnvironmentSource() {
/* 150 */     return this.systemEnvironmentSource;
/*     */   }
/*     */   
/*     */   protected final PropertyMapper[] getMappers() {
/* 154 */     return this.mappers;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 159 */     return this.propertySource.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SpringConfigurationPropertySource from(PropertySource<?> source) {
/* 170 */     Assert.notNull(source, "'source' must not be null");
/* 171 */     boolean systemEnvironmentSource = isSystemEnvironmentPropertySource(source);
/* 172 */     PropertyMapper[] mappers = !systemEnvironmentSource ? DEFAULT_MAPPERS : SYSTEM_ENVIRONMENT_MAPPERS;
/* 173 */     return !isFullEnumerable(source) ? 
/* 174 */       new SpringConfigurationPropertySource(source, systemEnvironmentSource, mappers) : 
/* 175 */       new SpringIterableConfigurationPropertySource((EnumerablePropertySource)source, systemEnvironmentSource, mappers);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isSystemEnvironmentPropertySource(PropertySource<?> source) {
/* 180 */     String name = source.getName();
/* 181 */     return (source instanceof SystemEnvironmentPropertySource && ("systemEnvironment"
/* 182 */       .equals(name) || name
/* 183 */       .endsWith("-systemEnvironment")));
/*     */   }
/*     */   
/*     */   private static boolean isFullEnumerable(PropertySource<?> source) {
/* 187 */     PropertySource<?> rootSource = getRootSource(source);
/* 188 */     Object object = rootSource.getSource(); if (object instanceof Map) { Map<?, ?> map = (Map<?, ?>)object;
/*     */       
/*     */       try {
/* 191 */         map.size();
/*     */       }
/* 193 */       catch (UnsupportedOperationException ex) {
/* 194 */         return false;
/*     */       }  }
/*     */     
/* 197 */     return source instanceof EnumerablePropertySource;
/*     */   }
/*     */   private static PropertySource<?> getRootSource(PropertySource<?> source) {
/*     */     while (true) {
/* 201 */       Object object = source.getSource(); if (object instanceof PropertySource) { PropertySource<?> propertySource = (PropertySource)object;
/* 202 */         source = propertySource; continue; }
/*     */        break;
/* 204 */     }  return source;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\SpringConfigurationPropertySource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */