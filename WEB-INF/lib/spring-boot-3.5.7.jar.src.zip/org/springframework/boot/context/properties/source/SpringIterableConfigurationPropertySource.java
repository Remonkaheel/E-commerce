/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.boot.origin.PropertySourceOrigin;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.MapPropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringIterableConfigurationPropertySource
/*     */   extends SpringConfigurationPropertySource
/*     */   implements IterableConfigurationPropertySource, CachingConfigurationPropertySource
/*     */ {
/*     */   private final BiPredicate<ConfigurationPropertyName, ConfigurationPropertyName> ancestorOfCheck;
/*     */   private final SoftReferenceConfigurationPropertyCache<Cache> cache;
/*     */   private volatile ConfigurationPropertyName[] configurationPropertyNames;
/*     */   private final Map<ConfigurationPropertyName, ConfigurationPropertyState> containsDescendantOfCache;
/*     */   
/*     */   SpringIterableConfigurationPropertySource(EnumerablePropertySource<?> propertySource, boolean systemEnvironmentSource, PropertyMapper... mappers) {
/*  67 */     super((PropertySource<?>)propertySource, systemEnvironmentSource, mappers);
/*  68 */     assertEnumerablePropertySource();
/*  69 */     boolean immutable = isImmutablePropertySource();
/*  70 */     this.ancestorOfCheck = getAncestorOfCheck(mappers);
/*  71 */     this.cache = new SoftReferenceConfigurationPropertyCache<>(immutable);
/*  72 */     this.containsDescendantOfCache = !systemEnvironmentSource ? null : (Map<ConfigurationPropertyName, ConfigurationPropertyState>)new ConcurrentReferenceHashMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private BiPredicate<ConfigurationPropertyName, ConfigurationPropertyName> getAncestorOfCheck(PropertyMapper[] mappers) {
/*  78 */     BiPredicate<ConfigurationPropertyName, ConfigurationPropertyName> ancestorOfCheck = mappers[0].getAncestorOfCheck();
/*  79 */     for (int i = 1; i < mappers.length; i++) {
/*  80 */       ancestorOfCheck = ancestorOfCheck.or(mappers[i].getAncestorOfCheck());
/*     */     }
/*  82 */     return ancestorOfCheck;
/*     */   }
/*     */   
/*     */   private void assertEnumerablePropertySource() {
/*  86 */     EnumerablePropertySource<?> enumerablePropertySource = getPropertySource(); if (enumerablePropertySource instanceof MapPropertySource) { MapPropertySource mapSource = (MapPropertySource)enumerablePropertySource;
/*     */       try {
/*  88 */         ((Map)mapSource.getSource()).size();
/*     */       }
/*  90 */       catch (UnsupportedOperationException ex) {
/*  91 */         throw new IllegalArgumentException("PropertySource must be fully enumerable");
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationPropertyCaching getCaching() {
/*  98 */     return this.cache;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName name) {
/* 103 */     if (name == null) {
/* 104 */       return null;
/*     */     }
/* 106 */     ConfigurationProperty configurationProperty = super.getConfigurationProperty(name);
/* 107 */     if (configurationProperty != null) {
/* 108 */       return configurationProperty;
/*     */     }
/* 110 */     for (String candidate : getCache().getMapped(name)) {
/* 111 */       Object value = getPropertySourceProperty(candidate);
/* 112 */       if (value != null) {
/* 113 */         Origin origin = PropertySourceOrigin.get((PropertySource)getPropertySource(), candidate);
/* 114 */         return ConfigurationProperty.of(this, name, value, origin);
/*     */       } 
/*     */     } 
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getSystemEnvironmentProperty(Map<String, Object> systemEnvironment, String name) {
/* 122 */     return getCache().getSystemEnvironmentProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<ConfigurationPropertyName> stream() {
/* 127 */     ConfigurationPropertyName[] names = getConfigurationPropertyNames();
/* 128 */     return Arrays.<ConfigurationPropertyName>stream(names).filter(Objects::nonNull);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<ConfigurationPropertyName> iterator() {
/* 133 */     return new ConfigurationPropertyNamesIterator(getConfigurationPropertyNames());
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/* 138 */     ConfigurationPropertyState result = super.containsDescendantOf(name);
/* 139 */     if (result != ConfigurationPropertyState.UNKNOWN) {
/* 140 */       return result;
/*     */     }
/* 142 */     if (this.ancestorOfCheck == PropertyMapper.DEFAULT_ANCESTOR_OF_CHECK) {
/* 143 */       Set<ConfigurationPropertyName> descendants = getCache().getDescendants();
/* 144 */       if (descendants != null) {
/* 145 */         if (name.isEmpty() && !descendants.isEmpty()) {
/* 146 */           return ConfigurationPropertyState.PRESENT;
/*     */         }
/* 148 */         return !descendants.contains(name) ? ConfigurationPropertyState.ABSENT : 
/* 149 */           ConfigurationPropertyState.PRESENT;
/*     */       } 
/*     */     } 
/* 152 */     result = (this.containsDescendantOfCache != null) ? this.containsDescendantOfCache.get(name) : null;
/* 153 */     if (result == null) {
/* 154 */       result = !ancestorOfCheck(name) ? ConfigurationPropertyState.ABSENT : ConfigurationPropertyState.PRESENT;
/* 155 */       if (this.containsDescendantOfCache != null) {
/* 156 */         this.containsDescendantOfCache.put(name, result);
/*     */       }
/*     */     } 
/* 159 */     return result;
/*     */   }
/*     */   
/*     */   private boolean ancestorOfCheck(ConfigurationPropertyName name) {
/* 163 */     ConfigurationPropertyName[] candidates = getConfigurationPropertyNames();
/* 164 */     for (ConfigurationPropertyName candidate : candidates) {
/* 165 */       if (candidate != null && this.ancestorOfCheck.test(name, candidate)) {
/* 166 */         return true;
/*     */       }
/*     */     } 
/* 169 */     return false;
/*     */   }
/*     */   
/*     */   ConfigurationPropertyName[] getConfigurationPropertyNames() {
/* 173 */     if (!isImmutablePropertySource()) {
/* 174 */       return getCache().getConfigurationPropertyNames(getPropertySource().getPropertyNames());
/*     */     }
/* 176 */     ConfigurationPropertyName[] configurationPropertyNames = this.configurationPropertyNames;
/* 177 */     if (configurationPropertyNames == null) {
/*     */       
/* 179 */       configurationPropertyNames = getCache().getConfigurationPropertyNames(getPropertySource().getPropertyNames());
/* 180 */       this.configurationPropertyNames = configurationPropertyNames;
/*     */     } 
/* 182 */     return configurationPropertyNames;
/*     */   }
/*     */   
/*     */   private Cache getCache() {
/* 186 */     return this.cache.get(this::createCache, this::updateCache);
/*     */   }
/*     */   
/*     */   private Cache createCache() {
/* 190 */     boolean immutable = isImmutablePropertySource();
/* 191 */     boolean captureDescendants = (this.ancestorOfCheck == PropertyMapper.DEFAULT_ANCESTOR_OF_CHECK);
/* 192 */     return new Cache(getMappers(), immutable, captureDescendants, isSystemEnvironmentSource());
/*     */   }
/*     */   
/*     */   private Cache updateCache(Cache cache) {
/* 196 */     cache.update(getPropertySource());
/* 197 */     return cache;
/*     */   }
/*     */   
/*     */   boolean isImmutablePropertySource() {
/* 201 */     EnumerablePropertySource<?> source = getPropertySource();
/* 202 */     if (source instanceof OriginLookup) { OriginLookup<?> originLookup = (OriginLookup)source;
/* 203 */       return originLookup.isImmutable(); }
/*     */     
/* 205 */     if ("systemEnvironment".equals(source.getName())) {
/* 206 */       return (source.getSource() == System.getenv());
/*     */     }
/* 208 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected EnumerablePropertySource<?> getPropertySource() {
/* 213 */     return (EnumerablePropertySource)super.getPropertySource();
/*     */   }
/*     */   
/*     */   private static class Cache
/*     */   {
/* 218 */     private static final ConfigurationPropertyName[] EMPTY_NAMES_ARRAY = new ConfigurationPropertyName[0];
/*     */     
/*     */     private final PropertyMapper[] mappers;
/*     */     
/*     */     private final boolean immutable;
/*     */     
/*     */     private final boolean captureDescendants;
/*     */     
/*     */     private final boolean systemEnvironmentSource;
/*     */     
/*     */     private volatile Data data;
/*     */ 
/*     */     
/*     */     Cache(PropertyMapper[] mappers, boolean immutable, boolean captureDescendants, boolean systemEnvironmentSource) {
/* 232 */       this.mappers = mappers;
/* 233 */       this.immutable = immutable;
/* 234 */       this.captureDescendants = captureDescendants;
/* 235 */       this.systemEnvironmentSource = systemEnvironmentSource;
/*     */     }
/*     */     
/*     */     void update(EnumerablePropertySource<?> propertySource) {
/* 239 */       if (this.data == null || !this.immutable) {
/* 240 */         int count = 0;
/*     */         while (true) {
/*     */           try {
/* 243 */             tryUpdate(propertySource);
/*     */             
/*     */             return;
/* 246 */           } catch (ConcurrentModificationException ex) {
/* 247 */             if (count++ > 10) {
/* 248 */               throw ex;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void tryUpdate(EnumerablePropertySource<?> propertySource) {
/* 256 */       Data data = this.data;
/* 257 */       String[] lastUpdated = (data != null) ? data.lastUpdated() : null;
/* 258 */       String[] propertyNames = propertySource.getPropertyNames();
/* 259 */       if (lastUpdated != null && Arrays.equals((Object[])lastUpdated, (Object[])propertyNames)) {
/*     */         return;
/*     */       }
/* 262 */       int size = propertyNames.length;
/* 263 */       Map<ConfigurationPropertyName, Set<String>> mappings = cloneOrCreate(
/* 264 */           (data != null) ? data.mappings() : null, size);
/* 265 */       Map<String, ConfigurationPropertyName> reverseMappings = cloneOrCreate(
/* 266 */           (data != null) ? data.reverseMappings() : null, size);
/* 267 */       Set<ConfigurationPropertyName> descendants = !this.captureDescendants ? null : new HashSet<>();
/*     */       
/* 269 */       Map<String, Object> systemEnvironmentCopy = !this.systemEnvironmentSource ? null : copySource(propertySource);
/* 270 */       for (PropertyMapper propertyMapper : this.mappers) {
/* 271 */         for (String propertyName : propertyNames) {
/* 272 */           if (!reverseMappings.containsKey(propertyName)) {
/* 273 */             ConfigurationPropertyName configurationPropertyName = propertyMapper.map(propertyName);
/* 274 */             if (configurationPropertyName != null && !configurationPropertyName.isEmpty()) {
/* 275 */               add(mappings, configurationPropertyName, propertyName);
/* 276 */               reverseMappings.put(propertyName, configurationPropertyName);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 281 */       for (String propertyName : propertyNames) {
/* 282 */         addParents(descendants, reverseMappings.get(propertyName));
/*     */       }
/*     */       
/* 285 */       ConfigurationPropertyName[] configurationPropertyNames = this.immutable ? (ConfigurationPropertyName[])reverseMappings.values().toArray((Object[])new ConfigurationPropertyName[0]) : null;
/* 286 */       lastUpdated = this.immutable ? null : propertyNames;
/* 287 */       this.data = new Data(mappings, reverseMappings, descendants, configurationPropertyNames, systemEnvironmentCopy, lastUpdated);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private HashMap<String, Object> copySource(EnumerablePropertySource<?> propertySource) {
/* 293 */       return new HashMap<>((Map<? extends String, ?>)propertySource.getSource());
/*     */     }
/*     */     
/*     */     private <K, V> Map<K, V> cloneOrCreate(Map<K, V> source, int size) {
/* 297 */       return (source != null) ? new LinkedHashMap<>(source) : new LinkedHashMap<>(size);
/*     */     }
/*     */     
/*     */     private void addParents(Set<ConfigurationPropertyName> descendants, ConfigurationPropertyName name) {
/* 301 */       if (descendants == null || name == null || name.isEmpty()) {
/*     */         return;
/*     */       }
/* 304 */       ConfigurationPropertyName parent = name.getParent();
/* 305 */       while (!parent.isEmpty()) {
/* 306 */         if (!descendants.add(parent)) {
/*     */           return;
/*     */         }
/* 309 */         parent = parent.getParent();
/*     */       } 
/*     */     }
/*     */     
/*     */     private <K, T> void add(Map<K, Set<T>> map, K key, T value) {
/* 314 */       ((Set<T>)map.computeIfAbsent(key, k -> new HashSet())).add(value);
/*     */     }
/*     */     
/*     */     Set<String> getMapped(ConfigurationPropertyName configurationPropertyName) {
/* 318 */       return this.data.mappings().getOrDefault(configurationPropertyName, Collections.emptySet());
/*     */     }
/*     */     
/*     */     ConfigurationPropertyName[] getConfigurationPropertyNames(String[] propertyNames) {
/* 322 */       Data data = this.data;
/* 323 */       ConfigurationPropertyName[] names = data.configurationPropertyNames();
/* 324 */       if (names != null) {
/* 325 */         return names;
/*     */       }
/* 327 */       Map<String, ConfigurationPropertyName> reverseMappings = data.reverseMappings();
/* 328 */       if (reverseMappings == null || reverseMappings.isEmpty()) {
/* 329 */         return EMPTY_NAMES_ARRAY;
/*     */       }
/* 331 */       names = new ConfigurationPropertyName[propertyNames.length];
/* 332 */       for (int i = 0; i < propertyNames.length; i++) {
/* 333 */         names[i] = reverseMappings.get(propertyNames[i]);
/*     */       }
/* 335 */       return names;
/*     */     }
/*     */     
/*     */     Set<ConfigurationPropertyName> getDescendants() {
/* 339 */       return this.data.descendants();
/*     */     }
/*     */     
/*     */     Object getSystemEnvironmentProperty(String name) {
/* 343 */       return this.data.systemEnvironmentCopy().get(name);
/*     */     }
/*     */     private static final class Data extends Record { private final Map<ConfigurationPropertyName, Set<String>> mappings; private final Map<String, ConfigurationPropertyName> reverseMappings; private final Set<ConfigurationPropertyName> descendants; private final ConfigurationPropertyName[] configurationPropertyNames; private final Map<String, Object> systemEnvironmentCopy; private final String[] lastUpdated;
/* 346 */       private Data(Map<ConfigurationPropertyName, Set<String>> mappings, Map<String, ConfigurationPropertyName> reverseMappings, Set<ConfigurationPropertyName> descendants, ConfigurationPropertyName[] configurationPropertyNames, Map<String, Object> systemEnvironmentCopy, String[] lastUpdated) { this.mappings = mappings; this.reverseMappings = reverseMappings; this.descendants = descendants; this.configurationPropertyNames = configurationPropertyNames; this.systemEnvironmentCopy = systemEnvironmentCopy; this.lastUpdated = lastUpdated; } public final String toString() { // Byte code:
/*     */         //   0: aload_0
/*     */         //   1: <illegal opcode> toString : (Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;)Ljava/lang/String;
/*     */         //   6: areturn
/*     */         // Line number table:
/*     */         //   Java source line number -> byte code offset
/*     */         //   #346	-> 0
/*     */         // Local variable table:
/*     */         //   start	length	slot	name	descriptor
/* 346 */         //   0	7	0	this	Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data; } public Map<ConfigurationPropertyName, Set<String>> mappings() { return this.mappings; } public final int hashCode() { // Byte code:
/*     */         //   0: aload_0
/*     */         //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;)I
/*     */         //   6: ireturn
/*     */         // Line number table:
/*     */         //   Java source line number -> byte code offset
/*     */         //   #346	-> 0
/*     */         // Local variable table:
/*     */         //   start	length	slot	name	descriptor
/*     */         //   0	7	0	this	Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data; } public final boolean equals(Object o) { // Byte code:
/*     */         //   0: aload_0
/*     */         //   1: aload_1
/*     */         //   2: <illegal opcode> equals : (Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;Ljava/lang/Object;)Z
/*     */         //   7: ireturn
/*     */         // Line number table:
/*     */         //   Java source line number -> byte code offset
/*     */         //   #346	-> 0
/*     */         // Local variable table:
/*     */         //   start	length	slot	name	descriptor
/*     */         //   0	8	0	this	Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;
/* 346 */         //   0	8	1	o	Ljava/lang/Object; } public Map<String, ConfigurationPropertyName> reverseMappings() { return this.reverseMappings; } public Set<ConfigurationPropertyName> descendants() { return this.descendants; } public ConfigurationPropertyName[] configurationPropertyNames() { return this.configurationPropertyNames; } public Map<String, Object> systemEnvironmentCopy() { return this.systemEnvironmentCopy; } public String[] lastUpdated() { return this.lastUpdated; } } } private static final class Data extends Record { private final Map<ConfigurationPropertyName, Set<String>> mappings; private final Map<String, ConfigurationPropertyName> reverseMappings; private final Set<ConfigurationPropertyName> descendants; private final ConfigurationPropertyName[] configurationPropertyNames; private final Map<String, Object> systemEnvironmentCopy; private final String[] lastUpdated; private Data(Map<ConfigurationPropertyName, Set<String>> mappings, Map<String, ConfigurationPropertyName> reverseMappings, Set<ConfigurationPropertyName> descendants, ConfigurationPropertyName[] configurationPropertyNames, Map<String, Object> systemEnvironmentCopy, String[] lastUpdated) { this.mappings = mappings; this.reverseMappings = reverseMappings; this.descendants = descendants; this.configurationPropertyNames = configurationPropertyNames; this.systemEnvironmentCopy = systemEnvironmentCopy; this.lastUpdated = lastUpdated; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #346	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 346 */       //   0	7	0	this	Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data; } public Map<ConfigurationPropertyName, Set<String>> mappings() { return this.mappings; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #346	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #346	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;
/* 346 */       //   0	8	1	o	Ljava/lang/Object; } public Map<String, ConfigurationPropertyName> reverseMappings() { return this.reverseMappings; } public Set<ConfigurationPropertyName> descendants() { return this.descendants; } public ConfigurationPropertyName[] configurationPropertyNames() { return this.configurationPropertyNames; } public Map<String, Object> systemEnvironmentCopy() { return this.systemEnvironmentCopy; } public String[] lastUpdated() { return this.lastUpdated; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConfigurationPropertyNamesIterator
/*     */     implements Iterator<ConfigurationPropertyName>
/*     */   {
/*     */     private final ConfigurationPropertyName[] names;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     private int index = 0;
/*     */     
/*     */     ConfigurationPropertyNamesIterator(ConfigurationPropertyName[] names) {
/* 365 */       this.names = names;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 370 */       skipNulls();
/* 371 */       return (this.index < this.names.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigurationPropertyName next() {
/* 376 */       skipNulls();
/* 377 */       if (this.index >= this.names.length) {
/* 378 */         throw new NoSuchElementException();
/*     */       }
/* 380 */       return this.names[this.index++];
/*     */     }
/*     */     
/*     */     private void skipNulls() {
/* 384 */       while (this.index < this.names.length) {
/* 385 */         if (this.names[this.index] != null) {
/*     */           return;
/*     */         }
/* 388 */         this.index++;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\SpringIterableConfigurationPropertySource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */