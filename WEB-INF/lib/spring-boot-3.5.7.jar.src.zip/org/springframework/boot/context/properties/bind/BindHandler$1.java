package org.springframework.boot.context.properties.bind;

class null implements BindHandler {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\BindHandler$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */