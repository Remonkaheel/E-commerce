/*     */ package org.springframework.boot.context.properties.bind.validation;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.boot.context.properties.bind.AbstractBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.BindContext;
/*     */ import org.springframework.boot.context.properties.bind.BindHandler;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.DataObjectPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.validation.BeanPropertyBindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.Validator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidationBindHandler
/*     */   extends AbstractBindHandler
/*     */ {
/*     */   private final Validator[] validators;
/*  51 */   private final Map<ConfigurationPropertyName, ResolvableType> boundTypes = new LinkedHashMap<>();
/*     */   
/*  53 */   private final Map<ConfigurationPropertyName, Object> boundResults = new LinkedHashMap<>();
/*     */   
/*  55 */   private final Set<ConfigurationProperty> boundProperties = new LinkedHashSet<>();
/*     */   
/*     */   private BindValidationException exception;
/*     */   
/*     */   public ValidationBindHandler(Validator... validators) {
/*  60 */     this.validators = validators;
/*     */   }
/*     */   
/*     */   public ValidationBindHandler(BindHandler parent, Validator... validators) {
/*  64 */     super(parent);
/*  65 */     this.validators = validators;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Bindable<T> onStart(ConfigurationPropertyName name, Bindable<T> target, BindContext context) {
/*  70 */     this.boundTypes.put(name, target.getType());
/*  71 */     return super.onStart(name, target, context);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object onSuccess(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) {
/*  76 */     this.boundResults.put(name, result);
/*  77 */     if (context.getConfigurationProperty() != null) {
/*  78 */       this.boundProperties.add(context.getConfigurationProperty());
/*     */     }
/*  80 */     return super.onSuccess(name, target, context, result);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object onFailure(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Exception error) throws Exception {
/*  86 */     Object result = super.onFailure(name, target, context, error);
/*  87 */     if (result != null) {
/*  88 */       clear();
/*  89 */       this.boundResults.put(name, result);
/*     */     } 
/*  91 */     validate(name, target, context, result);
/*  92 */     return result;
/*     */   }
/*     */   
/*     */   private void clear() {
/*  96 */     this.boundTypes.clear();
/*  97 */     this.boundResults.clear();
/*  98 */     this.boundProperties.clear();
/*  99 */     this.exception = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onFinish(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) throws Exception {
/* 105 */     validate(name, target, context, result);
/* 106 */     super.onFinish(name, target, context, result);
/*     */   }
/*     */   
/*     */   private void validate(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) {
/* 110 */     if (this.exception == null) {
/* 111 */       Object validationTarget = getValidationTarget(target, context, result);
/* 112 */       Class<?> validationType = target.getBoxedType().resolve();
/* 113 */       if (validationTarget != null) {
/* 114 */         validateAndPush(name, validationTarget, validationType);
/*     */       }
/*     */     } 
/* 117 */     if (context.getDepth() == 0 && this.exception != null) {
/* 118 */       throw this.exception;
/*     */     }
/*     */   }
/*     */   
/*     */   private Object getValidationTarget(Bindable<?> target, BindContext context, Object result) {
/* 123 */     if (result != null) {
/* 124 */       return result;
/*     */     }
/* 126 */     if (context.getDepth() == 0 && target.getValue() != null) {
/* 127 */       return target.getValue().get();
/*     */     }
/* 129 */     return null;
/*     */   }
/*     */   
/*     */   private void validateAndPush(ConfigurationPropertyName name, Object target, Class<?> type) {
/* 133 */     ValidationResult result = null;
/* 134 */     for (Validator validator : this.validators) {
/* 135 */       if (validator.supports(type)) {
/* 136 */         result = (result != null) ? result : new ValidationResult(name, target);
/* 137 */         validator.validate(target, (Errors)result);
/*     */       } 
/*     */     } 
/* 140 */     if (result != null && result.hasErrors()) {
/* 141 */       this.exception = new BindValidationException(result.getValidationErrors());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class ValidationResult
/*     */     extends BeanPropertyBindingResult
/*     */   {
/*     */     private final ConfigurationPropertyName name;
/*     */ 
/*     */     
/*     */     protected ValidationResult(ConfigurationPropertyName name, Object target) {
/* 153 */       super(target, null);
/* 154 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getObjectName() {
/* 159 */       return this.name.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getFieldType(String field) {
/* 164 */       ResolvableType type = getBoundField(ValidationBindHandler.this.boundTypes, field);
/* 165 */       Class<?> resolved = (type != null) ? type.resolve() : null;
/* 166 */       if (resolved != null) {
/* 167 */         return resolved;
/*     */       }
/* 169 */       return super.getFieldType(field);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object getActualFieldValue(String field) {
/* 174 */       Object boundField = getBoundField(ValidationBindHandler.this.boundResults, field);
/* 175 */       if (boundField != null) {
/* 176 */         return boundField;
/*     */       }
/*     */       try {
/* 179 */         return super.getActualFieldValue(field);
/*     */       }
/* 181 */       catch (Exception ex) {
/* 182 */         if (isPropertyNotReadable(ex)) {
/* 183 */           return null;
/*     */         }
/* 185 */         throw ex;
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean isPropertyNotReadable(Throwable ex) {
/* 190 */       while (ex != null) {
/* 191 */         if (ex instanceof org.springframework.beans.NotReadablePropertyException) {
/* 192 */           return true;
/*     */         }
/* 194 */         ex = ex.getCause();
/*     */       } 
/* 196 */       return false;
/*     */     }
/*     */     
/*     */     private <T> T getBoundField(Map<ConfigurationPropertyName, T> boundFields, String field) {
/*     */       try {
/* 201 */         ConfigurationPropertyName name = getName(field);
/* 202 */         T bound = boundFields.get(name);
/* 203 */         if (bound != null) {
/* 204 */           return bound;
/*     */         }
/* 206 */         if (name.hasIndexedElement()) {
/* 207 */           for (Map.Entry<ConfigurationPropertyName, T> entry : boundFields.entrySet()) {
/* 208 */             if (isFieldNameMatch(entry.getKey(), name)) {
/* 209 */               return entry.getValue();
/*     */             }
/*     */           }
/*     */         
/*     */         }
/* 214 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 217 */       return null;
/*     */     }
/*     */     
/*     */     private boolean isFieldNameMatch(ConfigurationPropertyName name, ConfigurationPropertyName fieldName) {
/* 221 */       if (name.getNumberOfElements() != fieldName.getNumberOfElements()) {
/* 222 */         return false;
/*     */       }
/* 224 */       for (int i = 0; i < name.getNumberOfElements(); i++) {
/* 225 */         String element = name.getElement(i, ConfigurationPropertyName.Form.ORIGINAL);
/* 226 */         String fieldElement = fieldName.getElement(i, ConfigurationPropertyName.Form.ORIGINAL);
/* 227 */         if (!ObjectUtils.nullSafeEquals(element, fieldElement)) {
/* 228 */           return false;
/*     */         }
/*     */       } 
/* 231 */       return true;
/*     */     }
/*     */     
/*     */     private ConfigurationPropertyName getName(String field) {
/* 235 */       return this.name.append(DataObjectPropertyName.toDashedForm(field));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     ValidationErrors getValidationErrors() {
/* 241 */       Set<ConfigurationProperty> boundProperties = (Set<ConfigurationProperty>)ValidationBindHandler.this.boundProperties.stream().filter(property -> this.name.isAncestorOf(property.getName())).collect(Collectors.toCollection(LinkedHashSet::new));
/* 242 */       return new ValidationErrors(this.name, boundProperties, getAllErrors());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\validation\ValidationBindHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */