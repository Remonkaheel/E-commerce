package org.springframework.boot.context.properties.bind;

interface DataObjectPropertyBinder {
  Object bindProperty(String paramString, Bindable<?> paramBindable);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\DataObjectPropertyBinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */