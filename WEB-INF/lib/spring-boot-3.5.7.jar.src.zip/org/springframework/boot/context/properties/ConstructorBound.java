/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ConstructorBound
/*    */ {
/*    */   public static Object from(BeanFactory beanFactory, String beanName, Class<?> beanType) {
/* 41 */     ConfigurationPropertiesBean bean = ConfigurationPropertiesBean.forValueObject(beanType, beanName);
/* 42 */     ConfigurationPropertiesBinder binder = ConfigurationPropertiesBinder.get(beanFactory);
/*    */     try {
/* 44 */       return binder.bindOrCreate(bean);
/*    */     }
/* 46 */     catch (Exception ex) {
/* 47 */       throw new ConfigurationPropertiesBindException(bean, ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConstructorBound.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */