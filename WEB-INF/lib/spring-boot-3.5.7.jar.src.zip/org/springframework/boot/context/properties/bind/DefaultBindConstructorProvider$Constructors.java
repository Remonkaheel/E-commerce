/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Constructors
/*     */ {
/*  64 */   private static final Constructors NONE = new Constructors(false, null, false, false);
/*     */   
/*     */   private final boolean hasAutowired;
/*     */   
/*     */   private final Constructor<?> bind;
/*     */   
/*     */   private final boolean deducedBindConstructor;
/*     */   
/*     */   private final boolean immutableType;
/*     */ 
/*     */   
/*     */   private Constructors(boolean hasAutowired, Constructor<?> bind, boolean deducedBindConstructor, boolean immutableType) {
/*  76 */     this.hasAutowired = hasAutowired;
/*  77 */     this.bind = bind;
/*  78 */     this.deducedBindConstructor = deducedBindConstructor;
/*  79 */     this.immutableType = immutableType;
/*     */   }
/*     */   
/*     */   boolean hasAutowired() {
/*  83 */     return this.hasAutowired;
/*     */   }
/*     */   
/*     */   Constructor<?> getBind() {
/*  87 */     return this.bind;
/*     */   }
/*     */   
/*     */   boolean isDeducedBindConstructor() {
/*  91 */     return this.deducedBindConstructor;
/*     */   }
/*     */   
/*     */   boolean isImmutableType() {
/*  95 */     return this.immutableType;
/*     */   }
/*     */   
/*     */   static Constructors getConstructors(Class<?> type, boolean isNestedConstructorBinding) {
/*  99 */     if (type == null) {
/* 100 */       return NONE;
/*     */     }
/* 102 */     boolean hasAutowiredConstructor = isAutowiredPresent(type);
/* 103 */     Constructor[] arrayOfConstructor = (Constructor[])getCandidateConstructors(type);
/* 104 */     MergedAnnotations[] candidateAnnotations = getAnnotations((Constructor<?>[])arrayOfConstructor);
/* 105 */     boolean deducedBindConstructor = false;
/* 106 */     boolean immutableType = type.isRecord();
/* 107 */     Constructor<?> bind = getConstructorBindingAnnotated(type, (Constructor<?>[])arrayOfConstructor, candidateAnnotations);
/* 108 */     if (bind == null && !hasAutowiredConstructor) {
/* 109 */       bind = deduceBindConstructor(type, (Constructor<?>[])arrayOfConstructor);
/* 110 */       deducedBindConstructor = (bind != null);
/*     */     } 
/* 112 */     if (bind == null && !hasAutowiredConstructor && isKotlinType(type)) {
/* 113 */       bind = deduceKotlinBindConstructor(type);
/* 114 */       deducedBindConstructor = (bind != null);
/*     */     } 
/* 116 */     if (bind != null || isNestedConstructorBinding) {
/* 117 */       Assert.state(!hasAutowiredConstructor, () -> type.getName() + " declares @ConstructorBinding and @Autowired constructor");
/*     */     }
/*     */     
/* 120 */     return new Constructors(hasAutowiredConstructor, bind, deducedBindConstructor, immutableType);
/*     */   }
/*     */   
/*     */   private static boolean isAutowiredPresent(Class<?> type) {
/* 124 */     if (Stream.<Constructor<?>>of(type.getDeclaredConstructors())
/* 125 */       .map(MergedAnnotations::from)
/* 126 */       .anyMatch(annotations -> annotations.isPresent(Autowired.class))) {
/* 127 */       return true;
/*     */     }
/* 129 */     Class<?> userClass = ClassUtils.getUserClass(type);
/* 130 */     return (userClass != type && isAutowiredPresent(userClass));
/*     */   }
/*     */   
/*     */   private static Constructor<?>[] getCandidateConstructors(Class<?> type) {
/* 134 */     if (isInnerClass(type)) {
/* 135 */       return (Constructor<?>[])new Constructor[0];
/*     */     }
/* 137 */     return (Constructor<?>[])Arrays.<Constructor<?>>stream(type.getDeclaredConstructors())
/* 138 */       .filter(Constructors::isNonSynthetic)
/* 139 */       .toArray(x$0 -> new Constructor[x$0]);
/*     */   }
/*     */   
/*     */   private static boolean isInnerClass(Class<?> type) {
/*     */     try {
/* 144 */       return type.getDeclaredField("this$0").isSynthetic();
/*     */     }
/* 146 */     catch (NoSuchFieldException ex) {
/* 147 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isNonSynthetic(Constructor<?> constructor) {
/* 152 */     return !constructor.isSynthetic();
/*     */   }
/*     */   
/*     */   private static MergedAnnotations[] getAnnotations(Constructor<?>[] candidates) {
/* 156 */     MergedAnnotations[] candidateAnnotations = new MergedAnnotations[candidates.length];
/* 157 */     for (int i = 0; i < candidates.length; i++) {
/* 158 */       candidateAnnotations[i] = MergedAnnotations.from(candidates[i], MergedAnnotations.SearchStrategy.SUPERCLASS);
/*     */     }
/* 160 */     return candidateAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Constructor<?> getConstructorBindingAnnotated(Class<?> type, Constructor<?>[] candidates, MergedAnnotations[] mergedAnnotations) {
/* 165 */     Constructor<?> result = null;
/* 166 */     for (int i = 0; i < candidates.length; i++) {
/* 167 */       if (mergedAnnotations[i].isPresent(ConstructorBinding.class)) {
/* 168 */         Assert.state((candidates[i].getParameterCount() > 0), () -> type.getName() + " declares @ConstructorBinding on a no-args constructor");
/*     */         
/* 170 */         Assert.state((result == null), () -> type.getName() + " has more than one @ConstructorBinding constructor");
/*     */         
/* 172 */         result = candidates[i];
/*     */       } 
/*     */     } 
/* 175 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Constructor<?> deduceBindConstructor(Class<?> type, Constructor<?>[] candidates) {
/* 180 */     if (candidates.length == 1 && candidates[0].getParameterCount() > 0) {
/* 181 */       if (type.isMemberClass() && Modifier.isPrivate(candidates[0].getModifiers())) {
/* 182 */         return null;
/*     */       }
/* 184 */       return candidates[0];
/*     */     } 
/* 186 */     Constructor<?> result = null;
/* 187 */     for (Constructor<?> candidate : candidates) {
/* 188 */       if (!Modifier.isPrivate(candidate.getModifiers())) {
/* 189 */         if (result != null) {
/* 190 */           return null;
/*     */         }
/* 192 */         result = candidate;
/*     */       } 
/*     */     } 
/* 195 */     return (result != null && result.getParameterCount() > 0) ? result : null;
/*     */   }
/*     */   
/*     */   private static boolean isKotlinType(Class<?> type) {
/* 199 */     return (KotlinDetector.isKotlinPresent() && KotlinDetector.isKotlinType(type));
/*     */   }
/*     */   
/*     */   private static Constructor<?> deduceKotlinBindConstructor(Class<?> type) {
/* 203 */     Constructor<?> primaryConstructor = BeanUtils.findPrimaryConstructor(type);
/* 204 */     if (primaryConstructor != null && primaryConstructor.getParameterCount() > 0) {
/* 205 */       return primaryConstructor;
/*     */     }
/* 207 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\DefaultBindConstructorProvider$Constructors.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */