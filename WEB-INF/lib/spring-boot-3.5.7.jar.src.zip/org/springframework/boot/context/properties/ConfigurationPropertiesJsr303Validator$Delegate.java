/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import org.springframework.boot.validation.MessageInterpolatorFactory;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Delegate
/*    */   extends LocalValidatorFactoryBean
/*    */ {
/*    */   Delegate(ApplicationContext applicationContext) {
/* 70 */     setApplicationContext(applicationContext);
/* 71 */     setMessageInterpolator((new MessageInterpolatorFactory((MessageSource)applicationContext)).getObject());
/* 72 */     afterPropertiesSet();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesJsr303Validator$Delegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */