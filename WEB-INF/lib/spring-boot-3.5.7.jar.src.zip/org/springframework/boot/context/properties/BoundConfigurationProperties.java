/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoundConfigurationProperties
/*    */ {
/* 40 */   private final Map<ConfigurationPropertyName, ConfigurationProperty> properties = new LinkedHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   private static final String BEAN_NAME = BoundConfigurationProperties.class.getName();
/*    */   
/*    */   void add(ConfigurationProperty configurationProperty) {
/* 48 */     this.properties.put(configurationProperty.getName(), configurationProperty);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurationProperty get(ConfigurationPropertyName name) {
/* 57 */     return this.properties.get(name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<ConfigurationPropertyName, ConfigurationProperty> getAll() {
/* 65 */     return Collections.unmodifiableMap(this.properties);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static BoundConfigurationProperties get(ApplicationContext context) {
/* 75 */     return !context.containsBeanDefinition(BEAN_NAME) ? null : 
/* 76 */       (BoundConfigurationProperties)context.getBean(BEAN_NAME, BoundConfigurationProperties.class);
/*    */   }
/*    */   
/*    */   static void register(BeanDefinitionRegistry registry) {
/* 80 */     Assert.notNull(registry, "'registry' must not be null");
/* 81 */     if (!registry.containsBeanDefinition(BEAN_NAME)) {
/*    */ 
/*    */       
/* 84 */       AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(BoundConfigurationProperties.class).setRole(2).getBeanDefinition();
/* 85 */       registry.registerBeanDefinition(BEAN_NAME, (BeanDefinition)abstractBeanDefinition);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\BoundConfigurationProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */