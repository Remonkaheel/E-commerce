/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import org.springframework.boot.validation.MessageInterpolatorFactory;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.validation.Errors;
/*    */ import org.springframework.validation.Validator;
/*    */ import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ConfigurationPropertiesJsr303Validator
/*    */   implements Validator
/*    */ {
/* 35 */   private static final String[] VALIDATOR_CLASSES = new String[] { "jakarta.validation.Validator", "jakarta.validation.ValidatorFactory", "jakarta.validation.bootstrap.GenericBootstrap" };
/*    */   
/*    */   private final Delegate delegate;
/*    */   
/*    */   private final Class<?> validatedType;
/*    */ 
/*    */   
/*    */   ConfigurationPropertiesJsr303Validator(ApplicationContext applicationContext, Class<?> validatedType) {
/* 43 */     this.delegate = new Delegate(applicationContext);
/* 44 */     this.validatedType = validatedType;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> type) {
/* 49 */     return (this.validatedType.equals(type) && this.delegate.supports(type));
/*    */   }
/*    */ 
/*    */   
/*    */   public void validate(Object target, Errors errors) {
/* 54 */     this.delegate.validate(target, errors);
/*    */   }
/*    */   
/*    */   static boolean isJsr303Present(ApplicationContext applicationContext) {
/* 58 */     ClassLoader classLoader = applicationContext.getClassLoader();
/* 59 */     for (String validatorClass : VALIDATOR_CLASSES) {
/* 60 */       if (!ClassUtils.isPresent(validatorClass, classLoader)) {
/* 61 */         return false;
/*    */       }
/*    */     } 
/* 64 */     return true;
/*    */   }
/*    */   
/*    */   private static class Delegate
/*    */     extends LocalValidatorFactoryBean {
/*    */     Delegate(ApplicationContext applicationContext) {
/* 70 */       setApplicationContext(applicationContext);
/* 71 */       setMessageInterpolator((new MessageInterpolatorFactory((MessageSource)applicationContext)).getObject());
/* 72 */       afterPropertiesSet();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesJsr303Validator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */