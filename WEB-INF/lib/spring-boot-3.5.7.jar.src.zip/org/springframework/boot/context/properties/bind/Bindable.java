/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.style.ToStringCreator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Bindable<T>
/*     */ {
/*  46 */   private static final Annotation[] NO_ANNOTATIONS = new Annotation[0];
/*     */   
/*  48 */   private static final EnumSet<BindRestriction> NO_BIND_RESTRICTIONS = EnumSet.noneOf(BindRestriction.class);
/*     */   
/*     */   private final ResolvableType type;
/*     */   
/*     */   private final ResolvableType boxedType;
/*     */   
/*     */   private final Supplier<T> value;
/*     */   
/*     */   private final Annotation[] annotations;
/*     */   
/*     */   private final EnumSet<BindRestriction> bindRestrictions;
/*     */   
/*     */   private final BindMethod bindMethod;
/*     */ 
/*     */   
/*     */   private Bindable(ResolvableType type, ResolvableType boxedType, Supplier<T> value, Annotation[] annotations, EnumSet<BindRestriction> bindRestrictions, BindMethod bindMethod) {
/*  64 */     this.type = type;
/*  65 */     this.boxedType = boxedType;
/*  66 */     this.value = value;
/*  67 */     this.annotations = annotations;
/*  68 */     this.bindRestrictions = bindRestrictions;
/*  69 */     this.bindMethod = bindMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvableType getType() {
/*  77 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvableType getBoxedType() {
/*  85 */     return this.boxedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Supplier<T> getValue() {
/*  93 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[] getAnnotations() {
/* 101 */     return this.annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A getAnnotation(Class<A> type) {
/* 112 */     for (Annotation annotation : this.annotations) {
/* 113 */       if (type.isInstance(annotation)) {
/* 114 */         return (A)annotation;
/*     */       }
/*     */     } 
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasBindRestriction(BindRestriction bindRestriction) {
/* 127 */     return this.bindRestrictions.contains(bindRestriction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BindMethod getBindMethod() {
/* 137 */     return this.bindMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 142 */     if (this == obj) {
/* 143 */       return true;
/*     */     }
/* 145 */     if (obj == null || getClass() != obj.getClass()) {
/* 146 */       return false;
/*     */     }
/* 148 */     Bindable<?> other = (Bindable)obj;
/* 149 */     boolean result = true;
/* 150 */     result = (result && nullSafeEquals(this.type.resolve(), other.type.resolve()));
/* 151 */     result = (result && nullSafeEquals(this.annotations, other.annotations));
/* 152 */     result = (result && nullSafeEquals(this.bindRestrictions, other.bindRestrictions));
/* 153 */     result = (result && nullSafeEquals(this.bindMethod, other.bindMethod));
/* 154 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 159 */     return ObjectUtils.nullSafeHash(new Object[] { this.type, this.annotations, this.bindRestrictions, this.bindMethod });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 164 */     ToStringCreator creator = new ToStringCreator(this);
/* 165 */     creator.append("type", this.type);
/* 166 */     creator.append("value", (this.value != null) ? "provided" : "none");
/* 167 */     creator.append("annotations", this.annotations);
/* 168 */     creator.append("bindMethod", this.bindMethod);
/* 169 */     return creator.toString();
/*     */   }
/*     */   
/*     */   private boolean nullSafeEquals(Object o1, Object o2) {
/* 173 */     return ObjectUtils.nullSafeEquals(o1, o2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bindable<T> withAnnotations(Annotation... annotations) {
/* 182 */     return new Bindable(this.type, this.boxedType, this.value, 
/* 183 */         (annotations != null) ? annotations : NO_ANNOTATIONS, NO_BIND_RESTRICTIONS, this.bindMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bindable<T> withExistingValue(T existingValue) {
/* 193 */     Assert.isTrue((existingValue == null || this.type
/* 194 */         .isArray() || this.boxedType.resolve().isInstance(existingValue)), () -> "'existingValue' must be an instance of " + String.valueOf(this.type));
/*     */     
/* 196 */     Assert.state((this.bindMethod != BindMethod.VALUE_OBJECT), () -> "An existing value cannot be provided when binding as a value object");
/*     */     
/* 198 */     Supplier<T> value = (existingValue != null) ? (() -> existingValue) : null;
/* 199 */     return new Bindable(this.type, this.boxedType, value, this.annotations, this.bindRestrictions, BindMethod.JAVA_BEAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bindable<T> withSuppliedValue(Supplier<T> suppliedValue) {
/* 209 */     return new Bindable(this.type, this.boxedType, suppliedValue, this.annotations, this.bindRestrictions, this.bindMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bindable<T> withBindRestrictions(BindRestriction... additionalRestrictions) {
/* 220 */     EnumSet<BindRestriction> bindRestrictions = EnumSet.copyOf(this.bindRestrictions);
/* 221 */     bindRestrictions.addAll(Arrays.asList(additionalRestrictions));
/* 222 */     return new Bindable(this.type, this.boxedType, this.value, this.annotations, bindRestrictions, this.bindMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bindable<T> withBindMethod(BindMethod bindMethod) {
/* 235 */     Assert.state((bindMethod != BindMethod.VALUE_OBJECT || this.value == null), () -> "Value object binding cannot be used with an existing or supplied value");
/*     */     
/* 237 */     return new Bindable(this.type, this.boxedType, this.value, this.annotations, this.bindRestrictions, bindMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Bindable<T> ofInstance(T instance) {
/* 252 */     Assert.notNull(instance, "'instance' must not be null");
/* 253 */     Class<T> type = (Class)instance.getClass();
/* 254 */     return of(type).withExistingValue(instance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Bindable<T> of(Class<T> type) {
/* 265 */     Assert.notNull(type, "'type' must not be null");
/* 266 */     return of(ResolvableType.forClass(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> Bindable<List<E>> listOf(Class<E> elementType) {
/* 276 */     return of(ResolvableType.forClassWithGenerics(List.class, new Class[] { elementType }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> Bindable<Set<E>> setOf(Class<E> elementType) {
/* 286 */     return of(ResolvableType.forClassWithGenerics(Set.class, new Class[] { elementType }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> Bindable<Map<K, V>> mapOf(Class<K> keyType, Class<V> valueType) {
/* 298 */     return of(ResolvableType.forClassWithGenerics(Map.class, new Class[] { keyType, valueType }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Bindable<T> of(ResolvableType type) {
/* 309 */     Assert.notNull(type, "'type' must not be null");
/* 310 */     ResolvableType boxedType = box(type);
/* 311 */     return new Bindable<>(type, boxedType, null, NO_ANNOTATIONS, NO_BIND_RESTRICTIONS, null);
/*     */   }
/*     */   
/*     */   private static ResolvableType box(ResolvableType type) {
/* 315 */     Class<?> resolved = type.resolve();
/* 316 */     if (resolved != null && resolved.isPrimitive()) {
/* 317 */       Object array = Array.newInstance(resolved, 1);
/* 318 */       Class<?> wrapperType = Array.get(array, 0).getClass();
/* 319 */       return ResolvableType.forClass(wrapperType);
/*     */     } 
/* 321 */     if (resolved != null && resolved.isArray()) {
/* 322 */       return ResolvableType.forArrayComponent(box(type.getComponentType()));
/*     */     }
/* 324 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum BindRestriction
/*     */   {
/* 337 */     NO_DIRECT_PROPERTY;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\Bindable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */