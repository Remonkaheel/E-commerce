/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.boot.context.properties.bind.AbstractBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.BindContext;
/*     */ import org.springframework.boot.context.properties.bind.BindHandler;
/*     */ import org.springframework.boot.context.properties.bind.BindResult;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.bind.BoundPropertiesTrackingBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.PlaceholdersResolver;
/*     */ import org.springframework.boot.context.properties.bind.PropertySourcesPlaceholdersResolver;
/*     */ import org.springframework.boot.context.properties.bind.handler.IgnoreErrorsBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.handler.IgnoreTopLevelConverterNotFoundBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.handler.NoUnboundElementsBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.validation.ValidationBindHandler;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
/*     */ import org.springframework.boot.context.properties.source.UnboundElementsSourceFilter;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.validation.annotation.Validated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationPropertiesBinder
/*     */ {
/*     */   private static final String BEAN_NAME = "org.springframework.boot.context.internalConfigurationPropertiesBinder";
/*     */   private static final String VALIDATOR_BEAN_NAME = "configurationPropertiesValidator";
/*     */   private final ApplicationContext applicationContext;
/*     */   private final PropertySources propertySources;
/*     */   private final Validator configurationPropertiesValidator;
/*     */   private final boolean jsr303Present;
/*     */   private volatile List<ConfigurationPropertiesBindHandlerAdvisor> bindHandlerAdvisors;
/*     */   private volatile Binder binder;
/*     */   
/*     */   ConfigurationPropertiesBinder(ApplicationContext applicationContext) {
/*  84 */     this.applicationContext = applicationContext;
/*  85 */     this.propertySources = (new PropertySourcesDeducer(applicationContext)).getPropertySources();
/*  86 */     this.configurationPropertiesValidator = getConfigurationPropertiesValidator(applicationContext);
/*  87 */     this.jsr303Present = ConfigurationPropertiesJsr303Validator.isJsr303Present(applicationContext);
/*     */   }
/*     */   
/*     */   BindResult<?> bind(ConfigurationPropertiesBean propertiesBean) {
/*  91 */     Bindable<?> target = propertiesBean.asBindTarget();
/*  92 */     ConfigurationProperties annotation = propertiesBean.getAnnotation();
/*  93 */     BindHandler bindHandler = getBindHandler(target, annotation);
/*  94 */     return getBinder().bind(annotation.prefix(), target, bindHandler);
/*     */   }
/*     */   
/*     */   Object bindOrCreate(ConfigurationPropertiesBean propertiesBean) {
/*  98 */     Bindable<?> target = propertiesBean.asBindTarget();
/*  99 */     ConfigurationProperties annotation = propertiesBean.getAnnotation();
/* 100 */     BindHandler bindHandler = getBindHandler(target, annotation);
/* 101 */     return getBinder().bindOrCreate(annotation.prefix(), target, bindHandler);
/*     */   }
/*     */   
/*     */   private Validator getConfigurationPropertiesValidator(ApplicationContext applicationContext) {
/* 105 */     if (applicationContext.containsBean("configurationPropertiesValidator")) {
/* 106 */       return (Validator)applicationContext.getBean("configurationPropertiesValidator", Validator.class);
/*     */     }
/* 108 */     return null; } private <T> BindHandler getBindHandler(Bindable<T> target, ConfigurationProperties annotation) { IgnoreErrorsBindHandler ignoreErrorsBindHandler;
/*     */     NoUnboundElementsBindHandler noUnboundElementsBindHandler;
/*     */     ValidationBindHandler validationBindHandler;
/*     */     BindHandler bindHandler;
/* 112 */     List<Validator> validators = getValidators(target);
/* 113 */     IgnoreTopLevelConverterNotFoundBindHandler ignoreTopLevelConverterNotFoundBindHandler = getHandler();
/* 114 */     ConfigurationPropertiesBindHandler configurationPropertiesBindHandler = new ConfigurationPropertiesBindHandler((BindHandler)ignoreTopLevelConverterNotFoundBindHandler);
/* 115 */     if (annotation.ignoreInvalidFields()) {
/* 116 */       ignoreErrorsBindHandler = new IgnoreErrorsBindHandler((BindHandler)configurationPropertiesBindHandler);
/*     */     }
/* 118 */     if (!annotation.ignoreUnknownFields()) {
/* 119 */       UnboundElementsSourceFilter filter = new UnboundElementsSourceFilter();
/* 120 */       noUnboundElementsBindHandler = new NoUnboundElementsBindHandler((BindHandler)ignoreErrorsBindHandler, (Function)filter);
/*     */     } 
/* 122 */     if (!validators.isEmpty()) {
/* 123 */       validationBindHandler = new ValidationBindHandler((BindHandler)noUnboundElementsBindHandler, validators.<Validator>toArray(new Validator[0]));
/*     */     }
/* 125 */     for (ConfigurationPropertiesBindHandlerAdvisor advisor : getBindHandlerAdvisors()) {
/* 126 */       bindHandler = advisor.apply((BindHandler)validationBindHandler);
/*     */     }
/* 128 */     return bindHandler; }
/*     */ 
/*     */   
/*     */   private List<ConfigurationPropertiesBindHandlerAdvisor> getBindHandlerAdvisors() {
/* 132 */     List<ConfigurationPropertiesBindHandlerAdvisor> bindHandlerAdvisors = this.bindHandlerAdvisors;
/* 133 */     if (bindHandlerAdvisors == null) {
/*     */ 
/*     */ 
/*     */       
/* 137 */       bindHandlerAdvisors = this.applicationContext.getBeanProvider(ConfigurationPropertiesBindHandlerAdvisor.class).orderedStream().toList();
/* 138 */       this.bindHandlerAdvisors = bindHandlerAdvisors;
/*     */     } 
/* 140 */     return bindHandlerAdvisors;
/*     */   }
/*     */   
/*     */   private IgnoreTopLevelConverterNotFoundBindHandler getHandler() {
/* 144 */     BoundConfigurationProperties bound = BoundConfigurationProperties.get(this.applicationContext);
/*     */     
/* 146 */     Objects.requireNonNull(bound); return (bound != null) ? new IgnoreTopLevelConverterNotFoundBindHandler((BindHandler)new BoundPropertiesTrackingBindHandler(bound::add)) : 
/* 147 */       new IgnoreTopLevelConverterNotFoundBindHandler();
/*     */   }
/*     */   
/*     */   private List<Validator> getValidators(Bindable<?> target) {
/* 151 */     List<Validator> validators = new ArrayList<>(3);
/* 152 */     if (this.configurationPropertiesValidator != null) {
/* 153 */       validators.add(this.configurationPropertiesValidator);
/*     */     }
/* 155 */     if (this.jsr303Present && target.getAnnotation(Validated.class) != null) {
/* 156 */       validators.add(getJsr303Validator(target.getType().resolve()));
/*     */     }
/* 158 */     Validator selfValidator = getSelfValidator(target);
/* 159 */     if (selfValidator != null) {
/* 160 */       validators.add(selfValidator);
/*     */     }
/* 162 */     return validators;
/*     */   }
/*     */   
/*     */   private Validator getSelfValidator(Bindable<?> target) {
/* 166 */     if (target.getValue() != null) {
/* 167 */       Object value = target.getValue().get();
/* 168 */       Validator validator = (Validator)value; return (value instanceof Validator) ? validator : null;
/*     */     } 
/* 170 */     Class<?> type = target.getType().resolve();
/* 171 */     if (type != null && Validator.class.isAssignableFrom(type)) {
/* 172 */       return new SelfValidatingConstructorBoundBindableValidator(type);
/*     */     }
/* 174 */     return null;
/*     */   }
/*     */   
/*     */   private Validator getJsr303Validator(Class<?> type) {
/* 178 */     return new ConfigurationPropertiesJsr303Validator(this.applicationContext, type);
/*     */   }
/*     */   
/*     */   private Binder getBinder() {
/* 182 */     if (this.binder == null) {
/* 183 */       this
/* 184 */         .binder = new Binder(getConfigurationPropertySources(), (PlaceholdersResolver)getPropertySourcesPlaceholdersResolver(), getConversionServices(), getPropertyEditorInitializer(), null, null);
/*     */     }
/* 186 */     return this.binder;
/*     */   }
/*     */   
/*     */   private Iterable<ConfigurationPropertySource> getConfigurationPropertySources() {
/* 190 */     return ConfigurationPropertySources.from((Iterable)this.propertySources);
/*     */   }
/*     */   
/*     */   private PropertySourcesPlaceholdersResolver getPropertySourcesPlaceholdersResolver() {
/* 194 */     return new PropertySourcesPlaceholdersResolver((Iterable)this.propertySources);
/*     */   }
/*     */   
/*     */   private List<ConversionService> getConversionServices() {
/* 198 */     return (new ConversionServiceDeducer(this.applicationContext)).getConversionServices();
/*     */   }
/*     */   
/*     */   private Consumer<PropertyEditorRegistry> getPropertyEditorInitializer() {
/* 202 */     ApplicationContext applicationContext = this.applicationContext; if (applicationContext instanceof ConfigurableApplicationContext) { ConfigurableApplicationContext configurableContext = (ConfigurableApplicationContext)applicationContext;
/* 203 */       Objects.requireNonNull(configurableContext.getBeanFactory()); return configurableContext.getBeanFactory()::copyRegisteredEditorsTo; }
/*     */     
/* 205 */     return null;
/*     */   }
/*     */   
/*     */   static void register(BeanDefinitionRegistry registry) {
/* 209 */     if (!registry.containsBeanDefinition("org.springframework.boot.context.internalConfigurationPropertiesBinder")) {
/*     */ 
/*     */       
/* 212 */       AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(ConfigurationPropertiesBinderFactory.class).getBeanDefinition();
/* 213 */       abstractBeanDefinition.setRole(2);
/* 214 */       registry.registerBeanDefinition("org.springframework.boot.context.internalConfigurationPropertiesBinder", (BeanDefinition)abstractBeanDefinition);
/*     */     } 
/*     */   }
/*     */   
/*     */   static ConfigurationPropertiesBinder get(BeanFactory beanFactory) {
/* 219 */     return (ConfigurationPropertiesBinder)beanFactory.getBean("org.springframework.boot.context.internalConfigurationPropertiesBinder", ConfigurationPropertiesBinder.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConfigurationPropertiesBindHandler
/*     */     extends AbstractBindHandler
/*     */   {
/*     */     ConfigurationPropertiesBindHandler(BindHandler handler) {
/* 229 */       super(handler);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Bindable<T> onStart(ConfigurationPropertyName name, Bindable<T> target, BindContext context) {
/* 234 */       return isConfigurationProperties(target.getType().resolve()) ? 
/* 235 */         target.withBindRestrictions(new Bindable.BindRestriction[] { Bindable.BindRestriction.NO_DIRECT_PROPERTY }) : target;
/*     */     }
/*     */     
/*     */     private boolean isConfigurationProperties(Class<?> target) {
/* 239 */       return (target != null && MergedAnnotations.from(target).isPresent(ConfigurationProperties.class));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ConfigurationPropertiesBinderFactory
/*     */     implements FactoryBean<ConfigurationPropertiesBinder>, ApplicationContextAware
/*     */   {
/*     */     private ConfigurationPropertiesBinder binder;
/*     */ 
/*     */ 
/*     */     
/*     */     public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 254 */       this.binder = (this.binder != null) ? this.binder : new ConfigurationPropertiesBinder(applicationContext);
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getObjectType() {
/* 259 */       return ConfigurationPropertiesBinder.class;
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigurationPropertiesBinder getObject() throws Exception {
/* 264 */       Assert.state((this.binder != null), "Binder was not created due to missing setApplicationContext call");
/* 265 */       return this.binder;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class SelfValidatingConstructorBoundBindableValidator
/*     */     implements Validator
/*     */   {
/*     */     private final Class<?> type;
/*     */ 
/*     */ 
/*     */     
/*     */     SelfValidatingConstructorBoundBindableValidator(Class<?> type) {
/* 279 */       this.type = type;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean supports(Class<?> candidate) {
/* 284 */       return candidate.isAssignableFrom(this.type);
/*     */     }
/*     */ 
/*     */     
/*     */     public void validate(Object target, Errors errors) {
/* 289 */       ((Validator)target).validate(target, errors);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */