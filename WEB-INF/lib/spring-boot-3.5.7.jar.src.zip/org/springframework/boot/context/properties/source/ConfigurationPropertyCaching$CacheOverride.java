package org.springframework.boot.context.properties.source;

public interface CacheOverride extends AutoCloseable {
  void close();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyCaching$CacheOverride.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */