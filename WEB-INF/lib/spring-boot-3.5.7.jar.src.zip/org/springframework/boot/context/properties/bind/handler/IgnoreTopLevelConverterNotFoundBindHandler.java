/*    */ package org.springframework.boot.context.properties.bind.handler;
/*    */ 
/*    */ import org.springframework.boot.context.properties.bind.AbstractBindHandler;
/*    */ import org.springframework.boot.context.properties.bind.BindContext;
/*    */ import org.springframework.boot.context.properties.bind.BindHandler;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IgnoreTopLevelConverterNotFoundBindHandler
/*    */   extends AbstractBindHandler
/*    */ {
/*    */   public IgnoreTopLevelConverterNotFoundBindHandler() {}
/*    */   
/*    */   public IgnoreTopLevelConverterNotFoundBindHandler(BindHandler parent) {
/* 47 */     super(parent);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object onFailure(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Exception error) throws Exception {
/* 53 */     if (context.getDepth() == 0 && error instanceof org.springframework.core.convert.ConverterNotFoundException) {
/* 54 */       return null;
/*    */     }
/* 56 */     throw error;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\handler\IgnoreTopLevelConverterNotFoundBindHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */