package org.springframework.boot.context.properties;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.core.annotation.AliasFor;
import org.springframework.stereotype.Indexed;

@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Indexed
public @interface ConfigurationProperties {
  @AliasFor("prefix")
  String value() default "";
  
  @AliasFor("value")
  String prefix() default "";
  
  boolean ignoreInvalidFields() default false;
  
  boolean ignoreUnknownFields() default true;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */