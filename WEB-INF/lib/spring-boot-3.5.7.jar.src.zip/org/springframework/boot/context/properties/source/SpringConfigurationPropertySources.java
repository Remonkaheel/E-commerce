/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringConfigurationPropertySources
/*     */   implements Iterable<ConfigurationPropertySource>
/*     */ {
/*     */   private final Iterable<PropertySource<?>> sources;
/*  45 */   private final Map<PropertySource<?>, ConfigurationPropertySource> cache = (Map<PropertySource<?>, ConfigurationPropertySource>)new ConcurrentReferenceHashMap(16, ConcurrentReferenceHashMap.ReferenceType.SOFT);
/*     */ 
/*     */   
/*     */   SpringConfigurationPropertySources(Iterable<PropertySource<?>> sources) {
/*  49 */     Assert.notNull(sources, "'sources' must not be null");
/*  50 */     this.sources = sources;
/*     */   }
/*     */   
/*     */   boolean isUsingSources(Iterable<PropertySource<?>> sources) {
/*  54 */     return (this.sources == sources);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<ConfigurationPropertySource> iterator() {
/*  59 */     return new SourcesIterator(this.sources.iterator(), this::adapt);
/*     */   }
/*     */   
/*     */   private ConfigurationPropertySource adapt(PropertySource<?> source) {
/*  63 */     ConfigurationPropertySource result = this.cache.get(source);
/*     */ 
/*     */     
/*  66 */     if (result != null && result.getUnderlyingSource() == source) {
/*  67 */       return result;
/*     */     }
/*  69 */     result = SpringConfigurationPropertySource.from(source);
/*  70 */     if (source instanceof OriginLookup) { OriginLookup<?> originLookup = (OriginLookup)source;
/*  71 */       result = result.withPrefix(originLookup.getPrefix()); }
/*     */     
/*  73 */     this.cache.put(source, result);
/*  74 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class SourcesIterator
/*     */     implements Iterator<ConfigurationPropertySource>
/*     */   {
/*     */     private final Deque<Iterator<PropertySource<?>>> iterators;
/*     */     
/*     */     private ConfigurationPropertySource next;
/*     */     private final Function<PropertySource<?>, ConfigurationPropertySource> adapter;
/*     */     
/*     */     SourcesIterator(Iterator<PropertySource<?>> iterator, Function<PropertySource<?>, ConfigurationPropertySource> adapter) {
/*  87 */       this.iterators = new ArrayDeque<>(4);
/*  88 */       this.iterators.push(iterator);
/*  89 */       this.adapter = adapter;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/*  94 */       return (fetchNext() != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigurationPropertySource next() {
/*  99 */       ConfigurationPropertySource next = fetchNext();
/* 100 */       if (next == null) {
/* 101 */         throw new NoSuchElementException();
/*     */       }
/* 103 */       this.next = null;
/* 104 */       return next;
/*     */     }
/*     */     
/*     */     private ConfigurationPropertySource fetchNext() {
/* 108 */       if (this.next == null) {
/* 109 */         if (this.iterators.isEmpty()) {
/* 110 */           return null;
/*     */         }
/* 112 */         if (!((Iterator)this.iterators.peek()).hasNext()) {
/* 113 */           this.iterators.pop();
/* 114 */           return fetchNext();
/*     */         } 
/* 116 */         PropertySource<?> candidate = ((Iterator<PropertySource>)this.iterators.peek()).next();
/* 117 */         Object object = candidate.getSource(); if (object instanceof ConfigurableEnvironment) { ConfigurableEnvironment configurableEnvironment = (ConfigurableEnvironment)object;
/* 118 */           push(configurableEnvironment);
/* 119 */           return fetchNext(); }
/*     */         
/* 121 */         if (isIgnored(candidate)) {
/* 122 */           return fetchNext();
/*     */         }
/* 124 */         this.next = this.adapter.apply(candidate);
/*     */       } 
/* 126 */       return this.next;
/*     */     }
/*     */     
/*     */     private void push(ConfigurableEnvironment environment) {
/* 130 */       this.iterators.push(environment.getPropertySources().iterator());
/*     */     }
/*     */     
/*     */     private boolean isIgnored(PropertySource<?> candidate) {
/* 134 */       return (candidate instanceof PropertySource.StubPropertySource || candidate instanceof ConfigurationPropertySourcesPropertySource);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\SpringConfigurationPropertySources.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */