/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.boot.context.properties.bind.BindMethod;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.core.AttributeAccessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BindMethodAttribute
/*    */ {
/* 34 */   static final String NAME = BindMethod.class.getName();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static BindMethod get(ApplicationContext applicationContext, String beanName) {
/* 40 */     ConfigurableApplicationContext configurableApplicationContext = (ConfigurableApplicationContext)applicationContext; return (applicationContext instanceof ConfigurableApplicationContext) ? 
/* 41 */       get(configurableApplicationContext.getBeanFactory(), beanName) : null;
/*    */   }
/*    */   
/*    */   static BindMethod get(ConfigurableListableBeanFactory beanFactory, String beanName) {
/* 45 */     return !beanFactory.containsBeanDefinition(beanName) ? null : get((AttributeAccessor)beanFactory.getBeanDefinition(beanName));
/*    */   }
/*    */   
/*    */   static BindMethod get(BeanDefinitionRegistry beanDefinitionRegistry, String beanName) {
/* 49 */     return !beanDefinitionRegistry.containsBeanDefinition(beanName) ? null : 
/* 50 */       get((AttributeAccessor)beanDefinitionRegistry.getBeanDefinition(beanName));
/*    */   }
/*    */   
/*    */   static BindMethod get(AttributeAccessor attributes) {
/* 54 */     return (BindMethod)attributes.getAttribute(NAME);
/*    */   }
/*    */   
/*    */   static void set(AttributeAccessor attributes, BindMethod bindMethod) {
/* 58 */     attributes.setAttribute(NAME, bindMethod);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\BindMethodAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */