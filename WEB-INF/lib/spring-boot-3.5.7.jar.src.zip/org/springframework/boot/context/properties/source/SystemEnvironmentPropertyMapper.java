/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import java.util.function.BiPredicate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SystemEnvironmentPropertyMapper
/*    */   implements PropertyMapper
/*    */ {
/* 40 */   public static final PropertyMapper INSTANCE = new SystemEnvironmentPropertyMapper();
/*    */ 
/*    */   
/*    */   public List<String> map(ConfigurationPropertyName configurationPropertyName) {
/* 44 */     List<String> mapped = new ArrayList<>(4);
/* 45 */     addIfMissing(mapped, configurationPropertyName.toString(ConfigurationPropertyName.ToStringFormat.SYSTEM_ENVIRONMENT, true));
/* 46 */     addIfMissing(mapped, configurationPropertyName.toString(ConfigurationPropertyName.ToStringFormat.LEGACY_SYSTEM_ENVIRONMENT, true));
/* 47 */     addIfMissing(mapped, configurationPropertyName.toString(ConfigurationPropertyName.ToStringFormat.SYSTEM_ENVIRONMENT, false));
/* 48 */     addIfMissing(mapped, configurationPropertyName.toString(ConfigurationPropertyName.ToStringFormat.LEGACY_SYSTEM_ENVIRONMENT, false));
/* 49 */     return mapped;
/*    */   }
/*    */   
/*    */   private void addIfMissing(List<String> list, String value) {
/* 53 */     if (!list.contains(value)) {
/* 54 */       list.add(value);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationPropertyName map(String propertySourceName) {
/* 60 */     return convertName(propertySourceName);
/*    */   }
/*    */   
/*    */   private ConfigurationPropertyName convertName(String propertySourceName) {
/*    */     try {
/* 65 */       return ConfigurationPropertyName.adapt(propertySourceName, '_', this::processElementValue);
/*    */     }
/* 67 */     catch (Exception ex) {
/* 68 */       return ConfigurationPropertyName.EMPTY;
/*    */     } 
/*    */   }
/*    */   
/*    */   private CharSequence processElementValue(CharSequence value) {
/* 73 */     String result = value.toString().toLowerCase(Locale.ENGLISH);
/* 74 */     return isNumber(result) ? ("[" + result + "]") : result;
/*    */   }
/*    */   
/*    */   private static boolean isNumber(String string) {
/* 78 */     return string.chars().allMatch(Character::isDigit);
/*    */   }
/*    */ 
/*    */   
/*    */   public BiPredicate<ConfigurationPropertyName, ConfigurationPropertyName> getAncestorOfCheck() {
/* 83 */     return this::isAncestorOf;
/*    */   }
/*    */   
/*    */   private boolean isAncestorOf(ConfigurationPropertyName name, ConfigurationPropertyName candidate) {
/* 87 */     return (name.isAncestorOf(candidate) || isLegacyAncestorOf(name, candidate));
/*    */   }
/*    */   
/*    */   private boolean isLegacyAncestorOf(ConfigurationPropertyName name, ConfigurationPropertyName candidate) {
/* 91 */     if (!name.hasDashedElement()) {
/* 92 */       return false;
/*    */     }
/* 94 */     ConfigurationPropertyName legacyCompatibleName = name.asSystemEnvironmentLegacyName();
/* 95 */     return (legacyCompatibleName != null && legacyCompatibleName.isAncestorOf(candidate));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\SystemEnvironmentPropertyMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */