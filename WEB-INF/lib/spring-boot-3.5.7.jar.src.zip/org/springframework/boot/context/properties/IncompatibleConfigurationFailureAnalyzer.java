/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IncompatibleConfigurationFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<IncompatibleConfigurationException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, IncompatibleConfigurationException cause) {
/* 32 */     String action = String.format("Review the docs for %s and change the configured values.", new Object[] {
/* 33 */           String.join(", ", (Iterable)cause.getIncompatibleKeys()) });
/* 34 */     return new FailureAnalysis(cause.getMessage(), action, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\IncompatibleConfigurationFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */