/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Predicate;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IterableConfigurationPropertySource
/*    */   extends ConfigurationPropertySource, Iterable<ConfigurationPropertyName>
/*    */ {
/*    */   default Iterator<ConfigurationPropertyName> iterator() {
/* 52 */     return stream().iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/* 64 */     Objects.requireNonNull(name); return ConfigurationPropertyState.search(this, name::isAncestorOf);
/*    */   }
/*    */ 
/*    */   
/*    */   default IterableConfigurationPropertySource filter(Predicate<ConfigurationPropertyName> filter) {
/* 69 */     return new FilteredIterableConfigurationPropertiesSource(this, filter);
/*    */   }
/*    */ 
/*    */   
/*    */   default IterableConfigurationPropertySource withAliases(ConfigurationPropertyNameAliases aliases) {
/* 74 */     return new AliasedIterableConfigurationPropertySource(this, aliases);
/*    */   }
/*    */ 
/*    */   
/*    */   default IterableConfigurationPropertySource withPrefix(String prefix) {
/* 79 */     return StringUtils.hasText(prefix) ? new PrefixedIterableConfigurationPropertySource(this, prefix) : this;
/*    */   }
/*    */   
/*    */   Stream<ConfigurationPropertyName> stream();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\IterableConfigurationPropertySource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */