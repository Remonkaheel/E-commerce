/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Stream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.reflect.KClass;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.ReflectionHints;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindableRuntimeHintsRegistrar
/*     */   implements RuntimeHintsRegistrar
/*     */ {
/*  64 */   private static final Log logger = LogFactory.getLog(BindableRuntimeHintsRegistrar.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final Bindable<?>[] bindables;
/*     */ 
/*     */ 
/*     */   
/*     */   protected BindableRuntimeHintsRegistrar(Class<?>... types) {
/*  73 */     this((Bindable<?>[])Stream.<Class<?>>of(types).map(Bindable::of).toArray(x$0 -> new Bindable[x$0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BindableRuntimeHintsRegistrar(Bindable<?>... bindables) {
/*  82 */     this.bindables = bindables;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/*  87 */     registerHints(hints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerHints(RuntimeHints hints) {
/*  95 */     for (Bindable<?> bindable : this.bindables) {
/*     */       try {
/*  97 */         (new Processor(bindable)).process(hints.reflection());
/*     */       }
/*  99 */       catch (Exception ex) {
/* 100 */         logger.debug("Skipping hints for " + String.valueOf(bindable), ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BindableRuntimeHintsRegistrar forTypes(Iterable<Class<?>> types) {
/* 111 */     Assert.notNull(types, "'types' must not be null");
/* 112 */     return forTypes((Class[])StreamSupport.stream(types.spliterator(), false).toArray(x$0 -> new Class[x$0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BindableRuntimeHintsRegistrar forTypes(Class<?>... types) {
/* 121 */     return new BindableRuntimeHintsRegistrar(types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BindableRuntimeHintsRegistrar forBindables(Iterable<Bindable<?>> bindables) {
/* 131 */     Assert.notNull(bindables, "'bindables' must not be null");
/* 132 */     return forBindables((Bindable<?>[])StreamSupport.stream(bindables.spliterator(), false).toArray(x$0 -> new Bindable[x$0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BindableRuntimeHintsRegistrar forBindables(Bindable<?>... bindables) {
/* 142 */     return new BindableRuntimeHintsRegistrar(bindables);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Processor
/*     */   {
/*     */     private final Class<?> type;
/*     */     
/*     */     private final Constructor<?> bindConstructor;
/*     */     
/*     */     private final JavaBeanBinder.BeanProperties bean;
/*     */     
/*     */     private final Set<Class<?>> seen;
/*     */ 
/*     */     
/*     */     Processor(Bindable<?> bindable) {
/* 159 */       this(bindable, false, new HashSet<>());
/*     */     }
/*     */     
/*     */     private Processor(Bindable<?> bindable, boolean nestedType, Set<Class<?>> seen) {
/* 163 */       this.type = bindable.getType().getRawClass();
/* 164 */       this
/*     */         
/* 166 */         .bindConstructor = (bindable.getBindMethod() != BindMethod.JAVA_BEAN) ? BindConstructorProvider.DEFAULT.getBindConstructor(bindable.getType().resolve(), nestedType) : null;
/* 167 */       this.bean = JavaBeanBinder.BeanProperties.of(bindable);
/* 168 */       this.seen = seen;
/*     */     }
/*     */     
/*     */     void process(ReflectionHints hints) {
/* 172 */       if (this.seen.contains(this.type)) {
/*     */         return;
/*     */       }
/* 175 */       this.seen.add(this.type);
/* 176 */       handleConstructor(hints);
/* 177 */       if (this.bindConstructor != null) {
/* 178 */         handleValueObjectProperties(hints);
/*     */       }
/* 180 */       else if (this.bean != null && !this.bean.getProperties().isEmpty()) {
/* 181 */         handleJavaBeanProperties(hints);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void handleConstructor(ReflectionHints hints) {
/* 186 */       if (this.bindConstructor != null) {
/* 187 */         if (KotlinDetector.isKotlinType(this.bindConstructor.getDeclaringClass())) {
/* 188 */           BindableRuntimeHintsRegistrar.KotlinDelegate.handleConstructor(hints, this.bindConstructor);
/*     */         } else {
/*     */           
/* 191 */           hints.registerConstructor(this.bindConstructor, ExecutableMode.INVOKE);
/*     */         } 
/*     */         return;
/*     */       } 
/* 195 */       Arrays.<Constructor<?>>stream(this.type.getDeclaredConstructors())
/* 196 */         .filter(this::hasNoParameters)
/* 197 */         .findFirst()
/* 198 */         .ifPresent(constructor -> hints.registerConstructor(constructor, ExecutableMode.INVOKE));
/*     */     }
/*     */     
/*     */     private boolean hasNoParameters(Constructor<?> candidate) {
/* 202 */       return (candidate.getParameterCount() == 0);
/*     */     }
/*     */     
/*     */     private void handleValueObjectProperties(ReflectionHints hints) {
/* 206 */       for (int i = 0; i < this.bindConstructor.getParameterCount(); i++) {
/* 207 */         String propertyName = this.bindConstructor.getParameters()[i].getName();
/* 208 */         ResolvableType propertyType = ResolvableType.forConstructorParameter(this.bindConstructor, i);
/* 209 */         handleProperty(hints, propertyName, propertyType);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void handleJavaBeanProperties(ReflectionHints hints) {
/* 214 */       Map<String, JavaBeanBinder.BeanProperty> properties = this.bean.getProperties();
/* 215 */       properties.forEach((name, property) -> {
/*     */             Method getter = property.getGetter();
/*     */             if (getter != null) {
/*     */               hints.registerMethod(getter, ExecutableMode.INVOKE);
/*     */             }
/*     */             Method setter = property.getSetter();
/*     */             if (setter != null) {
/*     */               hints.registerMethod(setter, ExecutableMode.INVOKE);
/*     */             }
/*     */             Field field = property.getField();
/*     */             if (field != null) {
/*     */               hints.registerField(field);
/*     */             }
/*     */             handleProperty(hints, name, property.getType());
/*     */           });
/*     */     }
/*     */     
/*     */     private void handleProperty(ReflectionHints hints, String propertyName, ResolvableType propertyType) {
/* 233 */       Class<?> propertyClass = propertyType.resolve();
/* 234 */       if (propertyClass == null) {
/*     */         return;
/*     */       }
/* 237 */       if (propertyClass.equals(this.type)) {
/*     */         return;
/*     */       }
/* 240 */       Class<?> componentType = getComponentClass(propertyType);
/* 241 */       if (componentType != null) {
/*     */         
/* 243 */         if (!isJavaType(componentType)) {
/* 244 */           processNested(componentType, hints);
/*     */         }
/*     */       }
/* 247 */       else if (isNestedType(propertyName, propertyClass)) {
/* 248 */         processNested(propertyClass, hints);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void processNested(Class<?> type, ReflectionHints hints) {
/* 253 */       (new Processor(Bindable.of(type), true, this.seen)).process(hints);
/*     */     }
/*     */     
/*     */     private Class<?> getComponentClass(ResolvableType type) {
/* 257 */       ResolvableType componentType = getComponentType(type);
/* 258 */       if (componentType == null) {
/* 259 */         return null;
/*     */       }
/* 261 */       if (isContainer(componentType))
/*     */       {
/* 263 */         return getComponentClass(componentType);
/*     */       }
/* 265 */       return componentType.toClass();
/*     */     }
/*     */     
/*     */     private ResolvableType getComponentType(ResolvableType type) {
/* 269 */       if (type.isArray()) {
/* 270 */         return type.getComponentType();
/*     */       }
/* 272 */       if (isCollection(type)) {
/* 273 */         return type.asCollection().getGeneric(new int[0]);
/*     */       }
/* 275 */       if (isMap(type)) {
/* 276 */         return type.asMap().getGeneric(new int[] { 1 });
/*     */       }
/* 278 */       return null;
/*     */     }
/*     */     
/*     */     private boolean isContainer(ResolvableType type) {
/* 282 */       return (type.isArray() || isCollection(type) || isMap(type));
/*     */     }
/*     */     
/*     */     private boolean isCollection(ResolvableType type) {
/* 286 */       return Collection.class.isAssignableFrom(type.toClass());
/*     */     }
/*     */     
/*     */     private boolean isMap(ResolvableType type) {
/* 290 */       return Map.class.isAssignableFrom(type.toClass());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isNestedType(String propertyName, Class<?> propertyType) {
/* 302 */       Class<?> declaringClass = propertyType.getDeclaringClass();
/* 303 */       if (declaringClass != null && isNested(declaringClass, this.type)) {
/* 304 */         return true;
/*     */       }
/* 306 */       Field field = ReflectionUtils.findField(this.type, propertyName);
/* 307 */       return (field != null && MergedAnnotations.from(field).isPresent(Nested.class));
/*     */     }
/*     */     
/*     */     private static boolean isNested(Class<?> type, Class<?> candidate) {
/* 311 */       if (type.isAssignableFrom(candidate)) {
/* 312 */         return true;
/*     */       }
/* 314 */       return (candidate.getDeclaringClass() != null && isNested(type, candidate.getDeclaringClass()));
/*     */     }
/*     */     
/*     */     private boolean isJavaType(Class<?> candidate) {
/* 318 */       return candidate.getPackageName().startsWith("java.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class KotlinDelegate
/*     */   {
/*     */     static void handleConstructor(ReflectionHints hints, Constructor<?> constructor) {
/* 329 */       KClass<?> kClass = JvmClassMappingKt.getKotlinClass(constructor.getDeclaringClass());
/* 330 */       if (kClass.isData()) {
/* 331 */         hints.registerType(constructor.getDeclaringClass(), new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*     */       } else {
/*     */         
/* 334 */         hints.registerConstructor(constructor, ExecutableMode.INVOKE);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\BindableRuntimeHintsRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */