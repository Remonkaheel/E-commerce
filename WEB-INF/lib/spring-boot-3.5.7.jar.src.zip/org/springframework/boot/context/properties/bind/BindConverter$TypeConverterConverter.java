/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.SimpleTypeConverter;
/*     */ import org.springframework.beans.propertyeditors.CustomBooleanEditor;
/*     */ import org.springframework.beans.propertyeditors.CustomNumberEditor;
/*     */ import org.springframework.beans.propertyeditors.FileEditor;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TypeConverterConverter
/*     */   implements ConditionalGenericConverter
/*     */ {
/*     */   private static final Set<Class<?>> EXCLUDED_EDITORS;
/*     */   private final Consumer<PropertyEditorRegistry> initializer;
/*     */   private final SimpleTypeConverter matchesOnlyTypeConverter;
/*     */   
/*     */   static {
/* 180 */     Set<Class<?>> excluded = new HashSet<>();
/* 181 */     excluded.add(CustomNumberEditor.class);
/* 182 */     excluded.add(CustomBooleanEditor.class);
/* 183 */     excluded.add(FileEditor.class);
/* 184 */     EXCLUDED_EDITORS = Collections.unmodifiableSet(excluded);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeConverterConverter(Consumer<PropertyEditorRegistry> initializer) {
/* 194 */     this.initializer = initializer;
/* 195 */     this.matchesOnlyTypeConverter = createTypeConverter();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 200 */     return Set.of(new GenericConverter.ConvertiblePair(String.class, Object.class), new GenericConverter.ConvertiblePair(String.class, Resource[].class), new GenericConverter.ConvertiblePair(String.class, Collection.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 207 */     Class<?> type = targetType.getType();
/* 208 */     if (type == null || type == Object.class || Map.class.isAssignableFrom(type)) {
/* 209 */       return false;
/*     */     }
/* 211 */     if (Collection.class.isAssignableFrom(type)) {
/* 212 */       TypeDescriptor elementType = targetType.getElementTypeDescriptor();
/* 213 */       if (elementType == null || !Resource.class.isAssignableFrom(elementType.getType())) {
/* 214 */         return false;
/*     */       }
/*     */     } 
/* 217 */     PropertyEditor editor = this.matchesOnlyTypeConverter.getDefaultEditor(type);
/* 218 */     if (editor == null) {
/* 219 */       editor = this.matchesOnlyTypeConverter.findCustomEditor(type, null);
/*     */     }
/* 221 */     if (editor == null && String.class != type) {
/* 222 */       editor = BeanUtils.findEditorByConvention(type);
/*     */     }
/* 224 */     return (editor != null && !EXCLUDED_EDITORS.contains(editor.getClass()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 229 */     return createTypeConverter().convertIfNecessary(source, targetType.getType(), targetType);
/*     */   }
/*     */   
/*     */   private SimpleTypeConverter createTypeConverter() {
/* 233 */     SimpleTypeConverter typeConverter = new SimpleTypeConverter();
/* 234 */     if (this.initializer != null) {
/* 235 */       this.initializer.accept(typeConverter);
/*     */     }
/* 237 */     return typeConverter;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\BindConverter$TypeConverterConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */