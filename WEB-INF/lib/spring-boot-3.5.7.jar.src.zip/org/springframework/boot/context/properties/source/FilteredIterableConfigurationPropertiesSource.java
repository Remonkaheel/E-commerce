/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Predicate;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FilteredIterableConfigurationPropertiesSource
/*    */   extends FilteredConfigurationPropertiesSource
/*    */   implements IterableConfigurationPropertySource
/*    */ {
/*    */   private ConfigurationPropertyName[] filteredNames;
/*    */   private int numerOfFilteredNames;
/*    */   
/*    */   FilteredIterableConfigurationPropertiesSource(IterableConfigurationPropertySource source, Predicate<ConfigurationPropertyName> filter) {
/* 38 */     super(source, filter);
/* 39 */     ConfigurationPropertyName[] filterableNames = getFilterableNames(source);
/* 40 */     if (filterableNames != null) {
/* 41 */       this.filteredNames = new ConfigurationPropertyName[filterableNames.length];
/* 42 */       this.numerOfFilteredNames = 0;
/* 43 */       for (ConfigurationPropertyName name : filterableNames) {
/* 44 */         if (name == null) {
/*    */           break;
/*    */         }
/* 47 */         if (filter.test(name)) {
/* 48 */           this.filteredNames[this.numerOfFilteredNames++] = name;
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private ConfigurationPropertyName[] getFilterableNames(IterableConfigurationPropertySource source) {
/* 55 */     if (source instanceof SpringIterableConfigurationPropertySource) { SpringIterableConfigurationPropertySource springPropertySource = (SpringIterableConfigurationPropertySource)source; if (springPropertySource
/* 56 */         .isImmutablePropertySource())
/* 57 */         return springPropertySource.getConfigurationPropertyNames();  }
/*    */     
/* 59 */     if (source instanceof FilteredIterableConfigurationPropertiesSource) { FilteredIterableConfigurationPropertiesSource filteredSource = (FilteredIterableConfigurationPropertiesSource)source;
/* 60 */       return filteredSource.filteredNames; }
/*    */     
/* 62 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<ConfigurationPropertyName> stream() {
/* 67 */     if (this.filteredNames != null) {
/* 68 */       return Arrays.stream(this.filteredNames, 0, this.numerOfFilteredNames);
/*    */     }
/* 70 */     return getSource().stream().filter(getFilter());
/*    */   }
/*    */ 
/*    */   
/*    */   protected IterableConfigurationPropertySource getSource() {
/* 75 */     return (IterableConfigurationPropertySource)super.getSource();
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/* 80 */     if (this.filteredNames != null) {
/*    */       
/* 82 */       Objects.requireNonNull(name); return ConfigurationPropertyState.search(this.filteredNames, 0, this.numerOfFilteredNames, name::isAncestorOf);
/*    */     } 
/* 84 */     Objects.requireNonNull(name); return ConfigurationPropertyState.search(this, name::isAncestorOf);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\FilteredIterableConfigurationPropertiesSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */