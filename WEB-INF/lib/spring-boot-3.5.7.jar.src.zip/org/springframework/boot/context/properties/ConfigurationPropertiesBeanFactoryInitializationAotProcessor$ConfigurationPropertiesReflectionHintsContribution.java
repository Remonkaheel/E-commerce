/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.bind.BindableRuntimeHintsRegistrar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ConfigurationPropertiesReflectionHintsContribution
/*    */   implements BeanFactoryInitializationAotContribution
/*    */ {
/*    */   private final List<Bindable<?>> bindables;
/*    */   
/*    */   private ConfigurationPropertiesReflectionHintsContribution(List<Bindable<?>> bindables) {
/* 67 */     this.bindables = bindables;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 73 */     BindableRuntimeHintsRegistrar.forBindables(this.bindables)
/* 74 */       .registerHints(generationContext.getRuntimeHints());
/*    */   }
/*    */   
/*    */   Iterable<Bindable<?>> getBindables() {
/* 78 */     return this.bindables;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBeanFactoryInitializationAotProcessor$ConfigurationPropertiesReflectionHintsContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */