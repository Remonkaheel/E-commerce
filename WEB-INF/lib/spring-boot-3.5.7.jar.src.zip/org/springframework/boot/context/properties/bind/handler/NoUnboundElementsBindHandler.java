/*     */ package org.springframework.boot.context.properties.bind.handler;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.boot.context.properties.bind.AbstractBindHandler;
/*     */ import org.springframework.boot.context.properties.bind.BindContext;
/*     */ import org.springframework.boot.context.properties.bind.BindHandler;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.UnboundConfigurationPropertiesException;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.IterableConfigurationPropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoUnboundElementsBindHandler
/*     */   extends AbstractBindHandler
/*     */ {
/*  44 */   private final Set<ConfigurationPropertyName> boundNames = new HashSet<>();
/*     */   
/*  46 */   private final Set<ConfigurationPropertyName> attemptedNames = new HashSet<>();
/*     */   
/*     */   private final Function<ConfigurationPropertySource, Boolean> filter;
/*     */   
/*     */   NoUnboundElementsBindHandler() {
/*  51 */     this(BindHandler.DEFAULT, configurationPropertySource -> Boolean.valueOf(true));
/*     */   }
/*     */   
/*     */   public NoUnboundElementsBindHandler(BindHandler parent) {
/*  55 */     this(parent, configurationPropertySource -> Boolean.valueOf(true));
/*     */   }
/*     */   
/*     */   public NoUnboundElementsBindHandler(BindHandler parent, Function<ConfigurationPropertySource, Boolean> filter) {
/*  59 */     super(parent);
/*  60 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Bindable<T> onStart(ConfigurationPropertyName name, Bindable<T> target, BindContext context) {
/*  65 */     this.attemptedNames.add(name);
/*  66 */     return super.onStart(name, target, context);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object onSuccess(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) {
/*  71 */     this.boundNames.add(name);
/*  72 */     return super.onSuccess(name, target, context, result);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object onFailure(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Exception error) throws Exception {
/*  78 */     if (error instanceof UnboundConfigurationPropertiesException) {
/*  79 */       throw error;
/*     */     }
/*  81 */     return super.onFailure(name, target, context, error);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onFinish(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) throws Exception {
/*  87 */     if (context.getDepth() == 0) {
/*  88 */       checkNoUnboundElements(name, context);
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkNoUnboundElements(ConfigurationPropertyName name, BindContext context) {
/*  93 */     Set<ConfigurationProperty> unbound = new TreeSet<>();
/*  94 */     for (ConfigurationPropertySource source : context.getSources()) {
/*  95 */       if (source instanceof IterableConfigurationPropertySource && ((Boolean)this.filter.apply(source)).booleanValue()) {
/*  96 */         collectUnbound(name, unbound, (IterableConfigurationPropertySource)source);
/*     */       }
/*     */     } 
/*  99 */     if (!unbound.isEmpty()) {
/* 100 */       throw new UnboundConfigurationPropertiesException(unbound);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void collectUnbound(ConfigurationPropertyName name, Set<ConfigurationProperty> unbound, IterableConfigurationPropertySource source) {
/* 106 */     IterableConfigurationPropertySource filtered = source.filter(candidate -> isUnbound(name, candidate));
/* 107 */     for (ConfigurationPropertyName unboundName : filtered) {
/*     */       try {
/* 109 */         unbound.add(source
/* 110 */             .filter(candidate -> isUnbound(name, candidate)).getConfigurationProperty(unboundName));
/*     */       }
/* 112 */       catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isUnbound(ConfigurationPropertyName name, ConfigurationPropertyName candidate) {
/* 119 */     if (name.isAncestorOf(candidate)) {
/* 120 */       return (!this.boundNames.contains(candidate) && !isOverriddenCollectionElement(candidate));
/*     */     }
/* 122 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isOverriddenCollectionElement(ConfigurationPropertyName candidate) {
/* 126 */     int lastIndex = candidate.getNumberOfElements() - 1;
/* 127 */     if (candidate.isLastElementIndexed()) {
/* 128 */       ConfigurationPropertyName propertyName = candidate.chop(lastIndex);
/* 129 */       return this.boundNames.contains(propertyName);
/*     */     } 
/* 131 */     Indexed indexed = getIndexed(candidate);
/* 132 */     if (indexed != null) {
/* 133 */       String zeroethProperty = indexed.getName() + "[0]";
/* 134 */       if (this.boundNames.contains(ConfigurationPropertyName.of(zeroethProperty))) {
/* 135 */         String nestedZeroethProperty = zeroethProperty + "." + zeroethProperty;
/* 136 */         return isCandidateValidPropertyName(nestedZeroethProperty);
/*     */       } 
/*     */     } 
/* 139 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isCandidateValidPropertyName(String nestedZeroethProperty) {
/* 143 */     return this.attemptedNames.contains(ConfigurationPropertyName.of(nestedZeroethProperty));
/*     */   }
/*     */   
/*     */   private Indexed getIndexed(ConfigurationPropertyName candidate) {
/* 147 */     for (int i = 0; i < candidate.getNumberOfElements(); i++) {
/* 148 */       if (candidate.isNumericIndex(i)) {
/* 149 */         return new Indexed(candidate.chop(i).toString(), candidate
/* 150 */             .getElement(i + 1, ConfigurationPropertyName.Form.UNIFORM));
/*     */       }
/*     */     } 
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Indexed
/*     */   {
/*     */     private final String name;
/*     */     private final String nestedPropertyName;
/*     */     
/*     */     private Indexed(String name, String nestedPropertyName) {
/* 163 */       this.name = name;
/* 164 */       this.nestedPropertyName = nestedPropertyName;
/*     */     }
/*     */     
/*     */     String getName() {
/* 168 */       return this.name;
/*     */     }
/*     */     
/*     */     String getNestedPropertyName() {
/* 172 */       return this.nestedPropertyName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\handler\NoUnboundElementsBindHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */