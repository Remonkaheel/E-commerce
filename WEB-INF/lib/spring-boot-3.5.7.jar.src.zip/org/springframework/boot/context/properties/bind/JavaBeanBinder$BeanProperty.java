/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanProperty
/*     */ {
/*     */   private final String name;
/*     */   private final ResolvableType declaringClassType;
/*     */   private Method getter;
/*     */   private Method setter;
/*     */   private Field field;
/*     */   
/*     */   BeanProperty(String name, ResolvableType declaringClassType) {
/* 369 */     this.name = DataObjectPropertyName.toDashedForm(name);
/* 370 */     this.declaringClassType = declaringClassType;
/*     */   }
/*     */   
/*     */   void addGetter(Method getter) {
/* 374 */     if (this.getter == null || this.getter.getName().startsWith("is")) {
/* 375 */       this.getter = getter;
/*     */     }
/*     */   }
/*     */   
/*     */   void addSetter(Method setter) {
/* 380 */     if (this.setter == null || isBetterSetter(setter)) {
/* 381 */       this.setter = setter;
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isBetterSetter(Method setter) {
/* 386 */     return (this.getter != null && this.getter.getReturnType().equals(setter.getParameterTypes()[0]));
/*     */   }
/*     */   
/*     */   void addField(Field field) {
/* 390 */     if (this.field == null) {
/* 391 */       this.field = field;
/*     */     }
/*     */   }
/*     */   
/*     */   String getName() {
/* 396 */     return this.name;
/*     */   }
/*     */   
/*     */   ResolvableType getType() {
/* 400 */     if (this.setter != null) {
/* 401 */       MethodParameter methodParameter1 = new MethodParameter(this.setter, 0);
/* 402 */       return ResolvableType.forMethodParameter(methodParameter1, this.declaringClassType);
/*     */     } 
/* 404 */     MethodParameter methodParameter = new MethodParameter(this.getter, -1);
/* 405 */     return ResolvableType.forMethodParameter(methodParameter, this.declaringClassType);
/*     */   }
/*     */   
/*     */   Annotation[] getAnnotations() {
/*     */     try {
/* 410 */       return (this.field != null) ? this.field.getDeclaredAnnotations() : null;
/*     */     }
/* 412 */     catch (Exception ex) {
/* 413 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   Supplier<Object> getValue(Supplier<?> instance) {
/* 418 */     if (this.getter == null) {
/* 419 */       return null;
/*     */     }
/* 421 */     return () -> {
/*     */         try {
/*     */           this.getter.setAccessible(true);
/*     */           
/*     */           return this.getter.invoke(instance.get(), new Object[0]);
/* 426 */         } catch (Exception ex) {
/*     */           if (isUninitializedKotlinProperty(ex)) {
/*     */             return null;
/*     */           }
/*     */           throw new IllegalStateException("Unable to get value for property " + this.name, ex);
/*     */         } 
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isUninitializedKotlinProperty(Exception ex) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: instanceof java/lang/reflect/InvocationTargetException
/*     */     //   4: ifeq -> 34
/*     */     //   7: aload_1
/*     */     //   8: checkcast java/lang/reflect/InvocationTargetException
/*     */     //   11: astore_2
/*     */     //   12: ldc 'kotlin.UninitializedPropertyAccessException'
/*     */     //   14: aload_2
/*     */     //   15: invokevirtual getTargetException : ()Ljava/lang/Throwable;
/*     */     //   18: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   21: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   24: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   27: ifeq -> 34
/*     */     //   30: iconst_1
/*     */     //   31: goto -> 35
/*     */     //   34: iconst_0
/*     */     //   35: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #437	-> 0
/*     */     //   #436	-> 7
/*     */     //   #438	-> 15
/*     */     //   #436	-> 35
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   12	22	2	invocationTargetException	Ljava/lang/reflect/InvocationTargetException;
/*     */     //   0	36	0	this	Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$BeanProperty;
/*     */     //   0	36	1	ex	Ljava/lang/Exception;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isSettable() {
/* 442 */     return (this.setter != null);
/*     */   }
/*     */   
/*     */   void setValue(Supplier<?> instance, Object value) {
/*     */     try {
/* 447 */       this.setter.setAccessible(true);
/* 448 */       this.setter.invoke(instance.get(), new Object[] { value });
/*     */     }
/* 450 */     catch (Exception ex) {
/* 451 */       throw new IllegalStateException("Unable to set value for property " + this.name, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   Method getGetter() {
/* 456 */     return this.getter;
/*     */   }
/*     */   
/*     */   Method getSetter() {
/* 460 */     return this.setter;
/*     */   }
/*     */   
/*     */   Field getField() {
/* 464 */     return this.field;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\JavaBeanBinder$BeanProperty.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */