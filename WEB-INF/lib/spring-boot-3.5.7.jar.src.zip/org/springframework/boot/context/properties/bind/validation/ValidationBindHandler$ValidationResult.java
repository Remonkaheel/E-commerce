/*     */ package org.springframework.boot.context.properties.bind.validation;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.boot.context.properties.bind.DataObjectPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.validation.BeanPropertyBindingResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ValidationResult
/*     */   extends BeanPropertyBindingResult
/*     */ {
/*     */   private final ConfigurationPropertyName name;
/*     */   
/*     */   protected ValidationResult(ConfigurationPropertyName name, Object target) {
/* 153 */     super(target, null);
/* 154 */     this.name = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getObjectName() {
/* 159 */     return this.name.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getFieldType(String field) {
/* 164 */     ResolvableType type = getBoundField(ValidationBindHandler.this.boundTypes, field);
/* 165 */     Class<?> resolved = (type != null) ? type.resolve() : null;
/* 166 */     if (resolved != null) {
/* 167 */       return resolved;
/*     */     }
/* 169 */     return super.getFieldType(field);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getActualFieldValue(String field) {
/* 174 */     Object boundField = getBoundField(ValidationBindHandler.this.boundResults, field);
/* 175 */     if (boundField != null) {
/* 176 */       return boundField;
/*     */     }
/*     */     try {
/* 179 */       return super.getActualFieldValue(field);
/*     */     }
/* 181 */     catch (Exception ex) {
/* 182 */       if (isPropertyNotReadable(ex)) {
/* 183 */         return null;
/*     */       }
/* 185 */       throw ex;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPropertyNotReadable(Throwable ex) {
/* 190 */     while (ex != null) {
/* 191 */       if (ex instanceof org.springframework.beans.NotReadablePropertyException) {
/* 192 */         return true;
/*     */       }
/* 194 */       ex = ex.getCause();
/*     */     } 
/* 196 */     return false;
/*     */   }
/*     */   
/*     */   private <T> T getBoundField(Map<ConfigurationPropertyName, T> boundFields, String field) {
/*     */     try {
/* 201 */       ConfigurationPropertyName name = getName(field);
/* 202 */       T bound = boundFields.get(name);
/* 203 */       if (bound != null) {
/* 204 */         return bound;
/*     */       }
/* 206 */       if (name.hasIndexedElement()) {
/* 207 */         for (Map.Entry<ConfigurationPropertyName, T> entry : boundFields.entrySet()) {
/* 208 */           if (isFieldNameMatch(entry.getKey(), name)) {
/* 209 */             return entry.getValue();
/*     */           }
/*     */         }
/*     */       
/*     */       }
/* 214 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 217 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isFieldNameMatch(ConfigurationPropertyName name, ConfigurationPropertyName fieldName) {
/* 221 */     if (name.getNumberOfElements() != fieldName.getNumberOfElements()) {
/* 222 */       return false;
/*     */     }
/* 224 */     for (int i = 0; i < name.getNumberOfElements(); i++) {
/* 225 */       String element = name.getElement(i, ConfigurationPropertyName.Form.ORIGINAL);
/* 226 */       String fieldElement = fieldName.getElement(i, ConfigurationPropertyName.Form.ORIGINAL);
/* 227 */       if (!ObjectUtils.nullSafeEquals(element, fieldElement)) {
/* 228 */         return false;
/*     */       }
/*     */     } 
/* 231 */     return true;
/*     */   }
/*     */   
/*     */   private ConfigurationPropertyName getName(String field) {
/* 235 */     return this.name.append(DataObjectPropertyName.toDashedForm(field));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ValidationErrors getValidationErrors() {
/* 241 */     Set<ConfigurationProperty> boundProperties = (Set<ConfigurationProperty>)ValidationBindHandler.this.boundProperties.stream().filter(property -> this.name.isAncestorOf(property.getName())).collect(Collectors.toCollection(java.util.LinkedHashSet::new));
/* 242 */     return new ValidationErrors(this.name, boundProperties, getAllErrors());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\validation\ValidationBindHandler$ValidationResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */