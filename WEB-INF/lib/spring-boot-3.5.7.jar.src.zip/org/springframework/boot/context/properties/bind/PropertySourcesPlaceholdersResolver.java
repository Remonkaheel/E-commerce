/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ import org.springframework.core.env.PropertySources;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.PropertyPlaceholderHelper;
/*    */ import org.springframework.util.SystemPropertyUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertySourcesPlaceholdersResolver
/*    */   implements PlaceholdersResolver
/*    */ {
/*    */   private final Iterable<PropertySource<?>> sources;
/*    */   private final PropertyPlaceholderHelper helper;
/*    */   
/*    */   public PropertySourcesPlaceholdersResolver(Environment environment) {
/* 41 */     this((Iterable<PropertySource<?>>)getSources(environment), null);
/*    */   }
/*    */   
/*    */   public PropertySourcesPlaceholdersResolver(Iterable<PropertySource<?>> sources) {
/* 45 */     this(sources, null);
/*    */   }
/*    */   
/*    */   public PropertySourcesPlaceholdersResolver(Iterable<PropertySource<?>> sources, PropertyPlaceholderHelper helper) {
/* 49 */     this.sources = sources;
/* 50 */     this
/* 51 */       .helper = (helper != null) ? helper : new PropertyPlaceholderHelper("${", "}", ":", SystemPropertyUtils.ESCAPE_CHARACTER, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object resolvePlaceholders(Object value) {
/* 58 */     if (value instanceof String) { String string = (String)value;
/* 59 */       return this.helper.replacePlaceholders(string, this::resolvePlaceholder); }
/*    */     
/* 61 */     return value;
/*    */   }
/*    */   
/*    */   protected String resolvePlaceholder(String placeholder) {
/* 65 */     if (this.sources != null) {
/* 66 */       for (PropertySource<?> source : this.sources) {
/* 67 */         Object value = source.getProperty(placeholder);
/* 68 */         if (value != null) {
/* 69 */           return String.valueOf(value);
/*    */         }
/*    */       } 
/*    */     }
/* 73 */     return null;
/*    */   }
/*    */   
/*    */   private static PropertySources getSources(Environment environment) {
/* 77 */     Assert.notNull(environment, "'environment' must not be null");
/* 78 */     Assert.isInstanceOf(ConfigurableEnvironment.class, environment, "'environment' must be a ConfigurableEnvironment");
/*    */     
/* 80 */     return (PropertySources)((ConfigurableEnvironment)environment).getPropertySources();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\PropertySourcesPlaceholdersResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */