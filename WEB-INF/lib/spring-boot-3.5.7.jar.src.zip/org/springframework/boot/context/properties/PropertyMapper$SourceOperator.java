package org.springframework.boot.context.properties;

@FunctionalInterface
public interface SourceOperator {
  <T> PropertyMapper.Source<T> apply(PropertyMapper.Source<T> paramSource);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\PropertyMapper$SourceOperator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */