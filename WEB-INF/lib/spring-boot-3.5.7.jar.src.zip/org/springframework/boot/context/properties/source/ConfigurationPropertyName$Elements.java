/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Elements
/*     */ {
/* 791 */   private static final int[] NO_POSITION = new int[0];
/*     */   
/* 793 */   private static final ConfigurationPropertyName.ElementType[] NO_TYPE = new ConfigurationPropertyName.ElementType[0];
/*     */   
/* 795 */   public static final Elements EMPTY = new Elements("", 0, NO_POSITION, NO_POSITION, NO_TYPE, null, null);
/*     */ 
/*     */   
/*     */   private final CharSequence source;
/*     */ 
/*     */   
/*     */   private final int size;
/*     */ 
/*     */   
/*     */   private final int[] start;
/*     */ 
/*     */   
/*     */   private final int[] end;
/*     */ 
/*     */   
/*     */   private final ConfigurationPropertyName.ElementType[] type;
/*     */ 
/*     */   
/*     */   private final int[] hashCode;
/*     */ 
/*     */   
/*     */   private final CharSequence[] resolved;
/*     */ 
/*     */ 
/*     */   
/*     */   Elements(CharSequence source, int size, int[] start, int[] end, ConfigurationPropertyName.ElementType[] type, int[] hashCode, CharSequence[] resolved) {
/* 821 */     this.source = source;
/* 822 */     this.size = size;
/* 823 */     this.start = start;
/* 824 */     this.end = end;
/* 825 */     this.type = type;
/* 826 */     this.hashCode = (hashCode != null) ? hashCode : new int[size];
/* 827 */     this.resolved = resolved;
/*     */   }
/*     */   
/*     */   Elements append(Elements additional) {
/* 831 */     int size = this.size + additional.size;
/* 832 */     ConfigurationPropertyName.ElementType[] type = new ConfigurationPropertyName.ElementType[size];
/* 833 */     int[] hashCode = new int[size];
/* 834 */     System.arraycopy(this.type, 0, type, 0, this.size);
/* 835 */     System.arraycopy(additional.type, 0, type, this.size, additional.size);
/* 836 */     System.arraycopy(this.hashCode, 0, hashCode, 0, this.size);
/* 837 */     System.arraycopy(additional.hashCode, 0, hashCode, this.size, additional.size);
/* 838 */     CharSequence[] resolved = newResolved(0, size);
/* 839 */     for (int i = 0; i < additional.size; i++) {
/* 840 */       resolved[this.size + i] = additional.get(i);
/*     */     }
/* 842 */     return new Elements(this.source, size, this.start, this.end, type, hashCode, resolved);
/*     */   }
/*     */   
/*     */   Elements chop(int size) {
/* 846 */     CharSequence[] resolved = newResolved(0, size);
/* 847 */     return new Elements(this.source, size, this.start, this.end, this.type, this.hashCode, resolved);
/*     */   }
/*     */   
/*     */   Elements subElements(int offset) {
/* 851 */     int size = this.size - offset;
/* 852 */     CharSequence[] resolved = newResolved(offset, size);
/* 853 */     int[] start = new int[size];
/* 854 */     System.arraycopy(this.start, offset, start, 0, size);
/* 855 */     int[] end = new int[size];
/* 856 */     System.arraycopy(this.end, offset, end, 0, size);
/* 857 */     ConfigurationPropertyName.ElementType[] type = new ConfigurationPropertyName.ElementType[size];
/* 858 */     System.arraycopy(this.type, offset, type, 0, size);
/* 859 */     int[] hashCode = new int[size];
/* 860 */     System.arraycopy(this.hashCode, offset, hashCode, 0, size);
/* 861 */     return new Elements(this.source, size, start, end, type, hashCode, resolved);
/*     */   }
/*     */   
/*     */   private CharSequence[] newResolved(int offset, int size) {
/* 865 */     CharSequence[] resolved = new CharSequence[size];
/* 866 */     if (this.resolved != null) {
/* 867 */       System.arraycopy(this.resolved, offset, resolved, 0, Math.min(size, this.size));
/*     */     }
/* 869 */     return resolved;
/*     */   }
/*     */   
/*     */   int getSize() {
/* 873 */     return this.size;
/*     */   }
/*     */   
/*     */   CharSequence get(int index) {
/* 877 */     if (this.resolved != null && this.resolved[index] != null) {
/* 878 */       return this.resolved[index];
/*     */     }
/* 880 */     int start = this.start[index];
/* 881 */     int end = this.end[index];
/* 882 */     return this.source.subSequence(start, end);
/*     */   }
/*     */   
/*     */   int getLength(int index) {
/* 886 */     if (this.resolved != null && this.resolved[index] != null) {
/* 887 */       return this.resolved[index].length();
/*     */     }
/* 889 */     int start = this.start[index];
/* 890 */     int end = this.end[index];
/* 891 */     return end - start;
/*     */   }
/*     */   
/*     */   char charAt(int index, int charIndex) {
/* 895 */     if (this.resolved != null && this.resolved[index] != null) {
/* 896 */       return this.resolved[index].charAt(charIndex);
/*     */     }
/* 898 */     int start = this.start[index];
/* 899 */     return this.source.charAt(start + charIndex);
/*     */   }
/*     */   
/*     */   ConfigurationPropertyName.ElementType getType(int index) {
/* 903 */     return this.type[index];
/*     */   }
/*     */   
/*     */   int hashCode(int index) {
/* 907 */     int hashCode = this.hashCode[index];
/* 908 */     if (hashCode == 0) {
/* 909 */       boolean indexed = getType(index).isIndexed();
/* 910 */       int length = getLength(index);
/* 911 */       for (int i = 0; i < length; i++) {
/* 912 */         char ch = charAt(index, i);
/* 913 */         if (!indexed) {
/* 914 */           ch = Character.toLowerCase(ch);
/*     */         }
/* 916 */         if (ConfigurationPropertyName.ElementsParser.isAlphaNumeric(ch)) {
/* 917 */           hashCode = 31 * hashCode + ch;
/*     */         }
/*     */       } 
/* 920 */       this.hashCode[index] = hashCode;
/*     */     } 
/* 922 */     return hashCode;
/*     */   }
/*     */   
/*     */   CharSequence getSource() {
/* 926 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean canShortcutWithSource(ConfigurationPropertyName.ElementType requiredType) {
/* 936 */     return canShortcutWithSource(requiredType, requiredType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean canShortcutWithSource(ConfigurationPropertyName.ElementType requiredType, ConfigurationPropertyName.ElementType alternativeType) {
/* 947 */     if (this.resolved != null) {
/* 948 */       return false;
/*     */     }
/* 950 */     for (int i = 0; i < this.size; i++) {
/* 951 */       ConfigurationPropertyName.ElementType type = this.type[i];
/* 952 */       if (type != requiredType && type != alternativeType) {
/* 953 */         return false;
/*     */       }
/* 955 */       if (i > 0 && this.end[i - 1] + 1 != this.start[i]) {
/* 956 */         return false;
/*     */       }
/*     */     } 
/* 959 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyName$Elements.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */