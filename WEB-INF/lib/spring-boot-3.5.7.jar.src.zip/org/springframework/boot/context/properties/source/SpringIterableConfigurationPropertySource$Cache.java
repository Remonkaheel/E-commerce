/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Cache
/*     */ {
/* 218 */   private static final ConfigurationPropertyName[] EMPTY_NAMES_ARRAY = new ConfigurationPropertyName[0];
/*     */   
/*     */   private final PropertyMapper[] mappers;
/*     */   
/*     */   private final boolean immutable;
/*     */   
/*     */   private final boolean captureDescendants;
/*     */   
/*     */   private final boolean systemEnvironmentSource;
/*     */   
/*     */   private volatile Data data;
/*     */ 
/*     */   
/*     */   Cache(PropertyMapper[] mappers, boolean immutable, boolean captureDescendants, boolean systemEnvironmentSource) {
/* 232 */     this.mappers = mappers;
/* 233 */     this.immutable = immutable;
/* 234 */     this.captureDescendants = captureDescendants;
/* 235 */     this.systemEnvironmentSource = systemEnvironmentSource;
/*     */   }
/*     */   
/*     */   void update(EnumerablePropertySource<?> propertySource) {
/* 239 */     if (this.data == null || !this.immutable) {
/* 240 */       int count = 0;
/*     */       while (true) {
/*     */         try {
/* 243 */           tryUpdate(propertySource);
/*     */           
/*     */           return;
/* 246 */         } catch (ConcurrentModificationException ex) {
/* 247 */           if (count++ > 10) {
/* 248 */             throw ex;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tryUpdate(EnumerablePropertySource<?> propertySource) {
/* 256 */     Data data = this.data;
/* 257 */     String[] lastUpdated = (data != null) ? data.lastUpdated() : null;
/* 258 */     String[] propertyNames = propertySource.getPropertyNames();
/* 259 */     if (lastUpdated != null && Arrays.equals((Object[])lastUpdated, (Object[])propertyNames)) {
/*     */       return;
/*     */     }
/* 262 */     int size = propertyNames.length;
/* 263 */     Map<ConfigurationPropertyName, Set<String>> mappings = cloneOrCreate(
/* 264 */         (data != null) ? data.mappings() : null, size);
/* 265 */     Map<String, ConfigurationPropertyName> reverseMappings = cloneOrCreate(
/* 266 */         (data != null) ? data.reverseMappings() : null, size);
/* 267 */     Set<ConfigurationPropertyName> descendants = !this.captureDescendants ? null : new HashSet<>();
/*     */     
/* 269 */     Map<String, Object> systemEnvironmentCopy = !this.systemEnvironmentSource ? null : copySource(propertySource);
/* 270 */     for (PropertyMapper propertyMapper : this.mappers) {
/* 271 */       for (String propertyName : propertyNames) {
/* 272 */         if (!reverseMappings.containsKey(propertyName)) {
/* 273 */           ConfigurationPropertyName configurationPropertyName = propertyMapper.map(propertyName);
/* 274 */           if (configurationPropertyName != null && !configurationPropertyName.isEmpty()) {
/* 275 */             add(mappings, configurationPropertyName, propertyName);
/* 276 */             reverseMappings.put(propertyName, configurationPropertyName);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 281 */     for (String propertyName : propertyNames) {
/* 282 */       addParents(descendants, reverseMappings.get(propertyName));
/*     */     }
/*     */     
/* 285 */     ConfigurationPropertyName[] configurationPropertyNames = this.immutable ? (ConfigurationPropertyName[])reverseMappings.values().toArray((Object[])new ConfigurationPropertyName[0]) : null;
/* 286 */     lastUpdated = this.immutable ? null : propertyNames;
/* 287 */     this.data = new Data(mappings, reverseMappings, descendants, configurationPropertyNames, systemEnvironmentCopy, lastUpdated);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<String, Object> copySource(EnumerablePropertySource<?> propertySource) {
/* 293 */     return new HashMap<>((Map<? extends String, ?>)propertySource.getSource());
/*     */   }
/*     */   
/*     */   private <K, V> Map<K, V> cloneOrCreate(Map<K, V> source, int size) {
/* 297 */     return (source != null) ? new LinkedHashMap<>(source) : new LinkedHashMap<>(size);
/*     */   }
/*     */   
/*     */   private void addParents(Set<ConfigurationPropertyName> descendants, ConfigurationPropertyName name) {
/* 301 */     if (descendants == null || name == null || name.isEmpty()) {
/*     */       return;
/*     */     }
/* 304 */     ConfigurationPropertyName parent = name.getParent();
/* 305 */     while (!parent.isEmpty()) {
/* 306 */       if (!descendants.add(parent)) {
/*     */         return;
/*     */       }
/* 309 */       parent = parent.getParent();
/*     */     } 
/*     */   }
/*     */   
/*     */   private <K, T> void add(Map<K, Set<T>> map, K key, T value) {
/* 314 */     ((Set<T>)map.computeIfAbsent(key, k -> new HashSet())).add(value);
/*     */   }
/*     */   
/*     */   Set<String> getMapped(ConfigurationPropertyName configurationPropertyName) {
/* 318 */     return this.data.mappings().getOrDefault(configurationPropertyName, Collections.emptySet());
/*     */   }
/*     */   
/*     */   ConfigurationPropertyName[] getConfigurationPropertyNames(String[] propertyNames) {
/* 322 */     Data data = this.data;
/* 323 */     ConfigurationPropertyName[] names = data.configurationPropertyNames();
/* 324 */     if (names != null) {
/* 325 */       return names;
/*     */     }
/* 327 */     Map<String, ConfigurationPropertyName> reverseMappings = data.reverseMappings();
/* 328 */     if (reverseMappings == null || reverseMappings.isEmpty()) {
/* 329 */       return EMPTY_NAMES_ARRAY;
/*     */     }
/* 331 */     names = new ConfigurationPropertyName[propertyNames.length];
/* 332 */     for (int i = 0; i < propertyNames.length; i++) {
/* 333 */       names[i] = reverseMappings.get(propertyNames[i]);
/*     */     }
/* 335 */     return names;
/*     */   }
/*     */   
/*     */   Set<ConfigurationPropertyName> getDescendants() {
/* 339 */     return this.data.descendants();
/*     */   }
/*     */   
/*     */   Object getSystemEnvironmentProperty(String name) {
/* 343 */     return this.data.systemEnvironmentCopy().get(name);
/*     */   }
/*     */   private static final class Data extends Record { private final Map<ConfigurationPropertyName, Set<String>> mappings; private final Map<String, ConfigurationPropertyName> reverseMappings; private final Set<ConfigurationPropertyName> descendants; private final ConfigurationPropertyName[] configurationPropertyNames; private final Map<String, Object> systemEnvironmentCopy; private final String[] lastUpdated;
/* 346 */     private Data(Map<ConfigurationPropertyName, Set<String>> mappings, Map<String, ConfigurationPropertyName> reverseMappings, Set<ConfigurationPropertyName> descendants, ConfigurationPropertyName[] configurationPropertyNames, Map<String, Object> systemEnvironmentCopy, String[] lastUpdated) { this.mappings = mappings; this.reverseMappings = reverseMappings; this.descendants = descendants; this.configurationPropertyNames = configurationPropertyNames; this.systemEnvironmentCopy = systemEnvironmentCopy; this.lastUpdated = lastUpdated; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #346	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 346 */       //   0	7	0	this	Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data; } public Map<ConfigurationPropertyName, Set<String>> mappings() { return this.mappings; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #346	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #346	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/boot/context/properties/source/SpringIterableConfigurationPropertySource$Cache$Data;
/* 346 */       //   0	8	1	o	Ljava/lang/Object; } public Map<String, ConfigurationPropertyName> reverseMappings() { return this.reverseMappings; } public Set<ConfigurationPropertyName> descendants() { return this.descendants; } public ConfigurationPropertyName[] configurationPropertyNames() { return this.configurationPropertyNames; } public Map<String, Object> systemEnvironmentCopy() { return this.systemEnvironmentCopy; } public String[] lastUpdated() { return this.lastUpdated; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\SpringIterableConfigurationPropertySource$Cache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */