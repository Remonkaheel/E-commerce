/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface ConfigurationPropertySource
/*     */ {
/*     */   ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName paramConfigurationPropertyName);
/*     */   
/*     */   default ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name) {
/*  56 */     return ConfigurationPropertyState.UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ConfigurationPropertySource filter(Predicate<ConfigurationPropertyName> filter) {
/*  66 */     return new FilteredConfigurationPropertiesSource(this, filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ConfigurationPropertySource withAliases(ConfigurationPropertyNameAliases aliases) {
/*  75 */     return new AliasedConfigurationPropertySource(this, aliases);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ConfigurationPropertySource withPrefix(String prefix) {
/*  85 */     return StringUtils.hasText(prefix) ? new PrefixedConfigurationPropertySource(this, prefix) : this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Object getUnderlyingSource() {
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigurationPropertySource from(PropertySource<?> source) {
/* 104 */     if (source instanceof ConfigurationPropertySourcesPropertySource) {
/* 105 */       return null;
/*     */     }
/* 107 */     return SpringConfigurationPropertySource.from(source);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertySource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */