/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyState;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JavaBeanBinder
/*     */   implements DataObjectBinder
/*     */ {
/*  54 */   private static final String HAS_KNOWN_BINDABLE_PROPERTIES_CACHE = JavaBeanBinder.class.getName() + ".HAS_KNOWN_BINDABLE_PROPERTIES_CACHE";
/*     */ 
/*     */   
/*  57 */   static final JavaBeanBinder INSTANCE = new JavaBeanBinder();
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bind(ConfigurationPropertyName name, Bindable<T> target, Binder.Context context, DataObjectPropertyBinder propertyBinder) {
/*  62 */     boolean hasKnownBindableProperties = (target.getValue() != null && hasKnownBindableProperties(name, context));
/*  63 */     Bean<T> bean = Bean.get(target, context, hasKnownBindableProperties);
/*  64 */     if (bean == null) {
/*  65 */       return null;
/*     */     }
/*  67 */     BeanSupplier<T> beanSupplier = bean.getSupplier(target);
/*  68 */     boolean bound = bind(propertyBinder, bean, beanSupplier, context);
/*  69 */     return bound ? beanSupplier.get() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T create(Bindable<T> target, Binder.Context context) {
/*  75 */     Class<T> type = target.getType().resolve();
/*  76 */     return (type != null) ? (T)BeanUtils.instantiateClass(type) : null;
/*     */   }
/*     */   
/*     */   private boolean hasKnownBindableProperties(ConfigurationPropertyName name, Binder.Context context) {
/*  80 */     Map<ConfigurationPropertyName, Boolean> cache = getHasKnownBindablePropertiesCache(context);
/*  81 */     Boolean hasKnownBindableProperties = cache.get(name);
/*  82 */     if (hasKnownBindableProperties == null) {
/*  83 */       hasKnownBindableProperties = Boolean.valueOf(computeHasKnownBindableProperties(name, context));
/*  84 */       cache.put(name, hasKnownBindableProperties);
/*     */     } 
/*  86 */     return hasKnownBindableProperties.booleanValue();
/*     */   }
/*     */   
/*     */   private boolean computeHasKnownBindableProperties(ConfigurationPropertyName name, Binder.Context context) {
/*  90 */     for (ConfigurationPropertySource source : context.getSources()) {
/*  91 */       if (source.containsDescendantOf(name) == ConfigurationPropertyState.PRESENT) {
/*  92 */         return true;
/*     */       }
/*     */     } 
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<ConfigurationPropertyName, Boolean> getHasKnownBindablePropertiesCache(Binder.Context context) {
/* 100 */     Object<Object, Object> cache = (Object<Object, Object>)context.getCache().get(HAS_KNOWN_BINDABLE_PROPERTIES_CACHE);
/* 101 */     if (cache == null) {
/* 102 */       cache = (Object<Object, Object>)new ConcurrentHashMap<>();
/* 103 */       context.getCache().put(HAS_KNOWN_BINDABLE_PROPERTIES_CACHE, cache);
/*     */     } 
/* 105 */     return (Map)cache;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> boolean bind(DataObjectPropertyBinder propertyBinder, Bean<T> bean, BeanSupplier<T> beanSupplier, Binder.Context context) {
/* 110 */     boolean bound = false;
/* 111 */     for (BeanProperty beanProperty : bean.getProperties().values()) {
/* 112 */       bound |= bind(beanSupplier, propertyBinder, beanProperty);
/* 113 */       context.clearConfigurationProperty();
/*     */     } 
/* 115 */     return bound;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> boolean bind(BeanSupplier<T> beanSupplier, DataObjectPropertyBinder propertyBinder, BeanProperty property) {
/* 120 */     String propertyName = determinePropertyName(property);
/* 121 */     ResolvableType type = property.getType();
/* 122 */     Supplier<Object> value = property.getValue(beanSupplier);
/* 123 */     Annotation[] annotations = property.getAnnotations();
/* 124 */     Object bound = propertyBinder.bindProperty(propertyName, 
/* 125 */         Bindable.of(type).withSuppliedValue(value).withAnnotations(annotations));
/* 126 */     if (bound == null) {
/* 127 */       return false;
/*     */     }
/* 129 */     if (property.isSettable()) {
/* 130 */       property.setValue(beanSupplier, bound);
/*     */     }
/* 132 */     else if (value == null || !bound.equals(value.get())) {
/* 133 */       throw new IllegalStateException("No setter found for property: " + property.getName());
/*     */     } 
/* 135 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String determinePropertyName(BeanProperty property) {
/* 142 */     Objects.requireNonNull(Name.class); return Arrays.<Annotation>stream((property.getAnnotations() != null) ? property.getAnnotations() : new Annotation[0]).filter(annotation -> (annotation.annotationType() == Name.class)).findFirst().map(Name.class::cast)
/* 143 */       .map(Name::value)
/* 144 */       .orElse(property.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class BeanProperties
/*     */   {
/* 152 */     private final Map<String, JavaBeanBinder.BeanProperty> properties = new LinkedHashMap<>();
/*     */     
/*     */     private final ResolvableType type;
/*     */     
/*     */     private final Class<?> resolvedType;
/*     */     
/*     */     BeanProperties(ResolvableType type, Class<?> resolvedType) {
/* 159 */       this.type = type;
/* 160 */       this.resolvedType = resolvedType;
/* 161 */       addProperties(resolvedType);
/*     */     }
/*     */     
/*     */     private void addProperties(Class<?> type) {
/* 165 */       while (type != null && !Object.class.equals(type)) {
/* 166 */         Method[] declaredMethods = getSorted(type, this::getDeclaredMethods, Method::getName);
/* 167 */         Field[] declaredFields = getSorted(type, Class::getDeclaredFields, Field::getName);
/* 168 */         addProperties(declaredMethods, declaredFields);
/* 169 */         type = type.getSuperclass();
/*     */       } 
/*     */     }
/*     */     
/*     */     private Method[] getDeclaredMethods(Class<?> type) {
/* 174 */       Method[] methods = type.getDeclaredMethods();
/* 175 */       Set<Method> result = new LinkedHashSet<>(methods.length);
/* 176 */       for (Method method : methods) {
/* 177 */         result.add(BridgeMethodResolver.findBridgedMethod(method));
/*     */       }
/* 179 */       return result.<Method>toArray(new Method[0]);
/*     */     }
/*     */     
/*     */     private <S, E> E[] getSorted(S source, Function<S, E[]> elements, Function<E, String> name) {
/* 183 */       E[] result = elements.apply(source);
/* 184 */       Arrays.sort(result, Comparator.comparing(name));
/* 185 */       return result;
/*     */     }
/*     */     
/*     */     protected void addProperties(Method[] declaredMethods, Field[] declaredFields) {
/* 189 */       for (int i = 0; i < declaredMethods.length; i++) {
/* 190 */         if (!isCandidate(declaredMethods[i])) {
/* 191 */           declaredMethods[i] = null;
/*     */         }
/*     */       } 
/* 194 */       for (Method method : declaredMethods) {
/* 195 */         addMethodIfPossible(method, "is", 0, JavaBeanBinder.BeanProperty::addGetter);
/*     */       }
/* 197 */       for (Method method : declaredMethods) {
/* 198 */         addMethodIfPossible(method, "get", 0, JavaBeanBinder.BeanProperty::addGetter);
/*     */       }
/* 200 */       for (Method method : declaredMethods) {
/* 201 */         addMethodIfPossible(method, "set", 1, JavaBeanBinder.BeanProperty::addSetter);
/*     */       }
/* 203 */       for (Field field : declaredFields) {
/* 204 */         addField(field);
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean isCandidate(Method method) {
/* 209 */       int modifiers = method.getModifiers();
/* 210 */       return (!Modifier.isPrivate(modifiers) && !Modifier.isProtected(modifiers) && !Modifier.isAbstract(modifiers) && 
/* 211 */         !Modifier.isStatic(modifiers) && !method.isBridge() && 
/* 212 */         !Object.class.equals(method.getDeclaringClass()) && 
/* 213 */         !Class.class.equals(method.getDeclaringClass()) && method.getName().indexOf('$') == -1);
/*     */     }
/*     */ 
/*     */     
/*     */     private void addMethodIfPossible(Method method, String prefix, int parameterCount, BiConsumer<JavaBeanBinder.BeanProperty, Method> consumer) {
/* 218 */       if (method != null && method.getParameterCount() == parameterCount && method.getName().startsWith(prefix) && method
/* 219 */         .getName().length() > prefix.length()) {
/* 220 */         String propertyName = Introspector.decapitalize(method.getName().substring(prefix.length()));
/* 221 */         consumer.accept(this.properties.computeIfAbsent(propertyName, this::getBeanProperty), method);
/*     */       } 
/*     */     }
/*     */     
/*     */     private JavaBeanBinder.BeanProperty getBeanProperty(String name) {
/* 226 */       return new JavaBeanBinder.BeanProperty(name, this.type);
/*     */     }
/*     */     
/*     */     private void addField(Field field) {
/* 230 */       JavaBeanBinder.BeanProperty property = this.properties.get(field.getName());
/* 231 */       if (property != null) {
/* 232 */         property.addField(field);
/*     */       }
/*     */     }
/*     */     
/*     */     protected final ResolvableType getType() {
/* 237 */       return this.type;
/*     */     }
/*     */     
/*     */     protected final Class<?> getResolvedType() {
/* 241 */       return this.resolvedType;
/*     */     }
/*     */     
/*     */     final Map<String, JavaBeanBinder.BeanProperty> getProperties() {
/* 245 */       return this.properties;
/*     */     }
/*     */     
/*     */     static BeanProperties of(Bindable<?> bindable) {
/* 249 */       ResolvableType type = bindable.getType();
/* 250 */       Class<?> resolvedType = type.resolve(Object.class);
/* 251 */       return new BeanProperties(type, resolvedType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Bean<T>
/*     */     extends BeanProperties
/*     */   {
/*     */     Bean(ResolvableType type, Class<?> resolvedType) {
/* 264 */       super(type, resolvedType);
/*     */     }
/*     */ 
/*     */     
/*     */     JavaBeanBinder.BeanSupplier<T> getSupplier(Bindable<T> target) {
/* 269 */       return new JavaBeanBinder.BeanSupplier<>(() -> {
/*     */             T instance = null;
/*     */             if (target.getValue() != null) {
/*     */               instance = target.getValue().get();
/*     */             }
/*     */             if (instance == null) {
/*     */               instance = (T)BeanUtils.instantiateClass(getResolvedType());
/*     */             }
/*     */             return (Supplier)instance;
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     static <T> Bean<T> get(Bindable<T> bindable, Binder.Context context, boolean canCallGetValue) {
/* 283 */       ResolvableType type = bindable.getType();
/* 284 */       Class<?> resolvedType = type.resolve(Object.class);
/* 285 */       Supplier<T> value = bindable.getValue();
/* 286 */       T instance = null;
/* 287 */       if (canCallGetValue && value != null) {
/* 288 */         instance = value.get();
/* 289 */         resolvedType = (instance != null) ? instance.getClass() : resolvedType;
/*     */       } 
/* 291 */       if (instance == null && !isInstantiable(resolvedType)) {
/* 292 */         return null;
/*     */       }
/* 294 */       Map<CacheKey, Bean<?>> cache = getCache(context);
/* 295 */       CacheKey cacheKey = new CacheKey(type, resolvedType);
/* 296 */       Bean<?> bean = cache.get(cacheKey);
/* 297 */       if (bean == null) {
/* 298 */         bean = new Bean(type, resolvedType);
/* 299 */         cache.put(cacheKey, bean);
/*     */       } 
/* 301 */       return (Bean)bean;
/*     */     }
/*     */ 
/*     */     
/*     */     private static Map<CacheKey, Bean<?>> getCache(Binder.Context context) {
/* 306 */       Map<CacheKey, Bean<?>> cache = (Map<CacheKey, Bean<?>>)context.getCache().get(Bean.class);
/* 307 */       if (cache == null) {
/* 308 */         cache = new ConcurrentHashMap<>();
/* 309 */         context.getCache().put(Bean.class, cache);
/*     */       } 
/* 311 */       return cache;
/*     */     }
/*     */     
/*     */     private static boolean isInstantiable(Class<?> type) {
/* 315 */       if (type.isInterface()) {
/* 316 */         return false;
/*     */       }
/*     */       try {
/* 319 */         type.getDeclaredConstructor(new Class[0]);
/* 320 */         return true;
/*     */       }
/* 322 */       catch (Exception ex) {
/* 323 */         return false;
/*     */       } 
/*     */     }
/*     */     private static final class CacheKey extends Record { private final ResolvableType type; private final Class<?> resolvedType;
/* 327 */       private CacheKey(ResolvableType type, Class<?> resolvedType) { this.type = type; this.resolvedType = resolvedType; } public final String toString() { // Byte code:
/*     */         //   0: aload_0
/*     */         //   1: <illegal opcode> toString : (Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;)Ljava/lang/String;
/*     */         //   6: areturn
/*     */         // Line number table:
/*     */         //   Java source line number -> byte code offset
/*     */         //   #327	-> 0
/*     */         // Local variable table:
/*     */         //   start	length	slot	name	descriptor
/* 327 */         //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey; } public ResolvableType type() { return this.type; } public final int hashCode() { // Byte code:
/*     */         //   0: aload_0
/*     */         //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;)I
/*     */         //   6: ireturn
/*     */         // Line number table:
/*     */         //   Java source line number -> byte code offset
/*     */         //   #327	-> 0
/*     */         // Local variable table:
/*     */         //   start	length	slot	name	descriptor
/*     */         //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey; } public final boolean equals(Object o) { // Byte code:
/*     */         //   0: aload_0
/*     */         //   1: aload_1
/*     */         //   2: <illegal opcode> equals : (Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;Ljava/lang/Object;)Z
/*     */         //   7: ireturn
/*     */         // Line number table:
/*     */         //   Java source line number -> byte code offset
/*     */         //   #327	-> 0
/*     */         // Local variable table:
/*     */         //   start	length	slot	name	descriptor
/*     */         //   0	8	0	this	Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;
/* 327 */         //   0	8	1	o	Ljava/lang/Object; } public Class<?> resolvedType() { return this.resolvedType; } } } private static final class CacheKey extends Record { private final ResolvableType type; private final Class<?> resolvedType; private CacheKey(ResolvableType type, Class<?> resolvedType) { this.type = type; this.resolvedType = resolvedType; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #327	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 327 */       //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey; } public ResolvableType type() { return this.type; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #327	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #327	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$Bean$CacheKey;
/* 327 */       //   0	8	1	o	Ljava/lang/Object; } public Class<?> resolvedType() { return this.resolvedType; }
/*     */      }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BeanSupplier<T>
/*     */     implements Supplier<T>
/*     */   {
/*     */     private final Supplier<T> factory;
/*     */     
/*     */     private T instance;
/*     */     
/*     */     BeanSupplier(Supplier<T> factory) {
/* 340 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */     
/*     */     public T get() {
/* 345 */       if (this.instance == null) {
/* 346 */         this.instance = this.factory.get();
/*     */       }
/* 348 */       return this.instance;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class BeanProperty
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     private final ResolvableType declaringClassType;
/*     */     
/*     */     private Method getter;
/*     */     
/*     */     private Method setter;
/*     */     
/*     */     private Field field;
/*     */ 
/*     */     
/*     */     BeanProperty(String name, ResolvableType declaringClassType) {
/* 369 */       this.name = DataObjectPropertyName.toDashedForm(name);
/* 370 */       this.declaringClassType = declaringClassType;
/*     */     }
/*     */     
/*     */     void addGetter(Method getter) {
/* 374 */       if (this.getter == null || this.getter.getName().startsWith("is")) {
/* 375 */         this.getter = getter;
/*     */       }
/*     */     }
/*     */     
/*     */     void addSetter(Method setter) {
/* 380 */       if (this.setter == null || isBetterSetter(setter)) {
/* 381 */         this.setter = setter;
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean isBetterSetter(Method setter) {
/* 386 */       return (this.getter != null && this.getter.getReturnType().equals(setter.getParameterTypes()[0]));
/*     */     }
/*     */     
/*     */     void addField(Field field) {
/* 390 */       if (this.field == null) {
/* 391 */         this.field = field;
/*     */       }
/*     */     }
/*     */     
/*     */     String getName() {
/* 396 */       return this.name;
/*     */     }
/*     */     
/*     */     ResolvableType getType() {
/* 400 */       if (this.setter != null) {
/* 401 */         MethodParameter methodParameter1 = new MethodParameter(this.setter, 0);
/* 402 */         return ResolvableType.forMethodParameter(methodParameter1, this.declaringClassType);
/*     */       } 
/* 404 */       MethodParameter methodParameter = new MethodParameter(this.getter, -1);
/* 405 */       return ResolvableType.forMethodParameter(methodParameter, this.declaringClassType);
/*     */     }
/*     */     
/*     */     Annotation[] getAnnotations() {
/*     */       try {
/* 410 */         return (this.field != null) ? this.field.getDeclaredAnnotations() : null;
/*     */       }
/* 412 */       catch (Exception ex) {
/* 413 */         return null;
/*     */       } 
/*     */     }
/*     */     
/*     */     Supplier<Object> getValue(Supplier<?> instance) {
/* 418 */       if (this.getter == null) {
/* 419 */         return null;
/*     */       }
/* 421 */       return () -> {
/*     */           try {
/*     */             this.getter.setAccessible(true);
/*     */             
/*     */             return this.getter.invoke(instance.get(), new Object[0]);
/* 426 */           } catch (Exception ex) {
/*     */             if (isUninitializedKotlinProperty(ex)) {
/*     */               return null;
/*     */             }
/*     */             throw new IllegalStateException("Unable to get value for property " + this.name, ex);
/*     */           } 
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean isUninitializedKotlinProperty(Exception ex) {
/*     */       // Byte code:
/*     */       //   0: aload_1
/*     */       //   1: instanceof java/lang/reflect/InvocationTargetException
/*     */       //   4: ifeq -> 34
/*     */       //   7: aload_1
/*     */       //   8: checkcast java/lang/reflect/InvocationTargetException
/*     */       //   11: astore_2
/*     */       //   12: ldc 'kotlin.UninitializedPropertyAccessException'
/*     */       //   14: aload_2
/*     */       //   15: invokevirtual getTargetException : ()Ljava/lang/Throwable;
/*     */       //   18: invokevirtual getClass : ()Ljava/lang/Class;
/*     */       //   21: invokevirtual getName : ()Ljava/lang/String;
/*     */       //   24: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */       //   27: ifeq -> 34
/*     */       //   30: iconst_1
/*     */       //   31: goto -> 35
/*     */       //   34: iconst_0
/*     */       //   35: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #437	-> 0
/*     */       //   #436	-> 7
/*     */       //   #438	-> 15
/*     */       //   #436	-> 35
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   12	22	2	invocationTargetException	Ljava/lang/reflect/InvocationTargetException;
/*     */       //   0	36	0	this	Lorg/springframework/boot/context/properties/bind/JavaBeanBinder$BeanProperty;
/*     */       //   0	36	1	ex	Ljava/lang/Exception;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isSettable() {
/* 442 */       return (this.setter != null);
/*     */     }
/*     */     
/*     */     void setValue(Supplier<?> instance, Object value) {
/*     */       try {
/* 447 */         this.setter.setAccessible(true);
/* 448 */         this.setter.invoke(instance.get(), new Object[] { value });
/*     */       }
/* 450 */       catch (Exception ex) {
/* 451 */         throw new IllegalStateException("Unable to set value for property " + this.name, ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     Method getGetter() {
/* 456 */       return this.getter;
/*     */     }
/*     */     
/*     */     Method getSetter() {
/* 460 */       return this.setter;
/*     */     }
/*     */     
/*     */     Field getField() {
/* 464 */       return this.field;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\JavaBeanBinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */