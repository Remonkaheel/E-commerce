/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ValueObject<T>
/*     */ {
/* 195 */   private static final Object NONE = new Object();
/*     */   
/*     */   private final Constructor<T> constructor;
/*     */   
/*     */   protected ValueObject(Constructor<T> constructor) {
/* 200 */     this.constructor = constructor;
/*     */   }
/*     */   
/*     */   T instantiate(List<Object> args) {
/* 204 */     return (T)BeanUtils.instantiateClass(this.constructor, args.toArray());
/*     */   }
/*     */ 
/*     */   
/*     */   abstract List<ValueObjectBinder.ConstructorParameter> getConstructorParameters();
/*     */ 
/*     */   
/*     */   static <T> ValueObject<T> get(Bindable<T> bindable, Binder.Context context, BindConstructorProvider constructorProvider, ParameterNameDiscoverer parameterNameDiscoverer) {
/* 212 */     Class<T> resolvedType = bindable.getType().resolve();
/* 213 */     if (resolvedType == null || resolvedType.isEnum() || Modifier.isAbstract(resolvedType.getModifiers())) {
/* 214 */       return null;
/*     */     }
/* 216 */     Map<CacheKey, Object> cache = getCache(context);
/* 217 */     CacheKey cacheKey = new CacheKey(bindable, constructorProvider, parameterNameDiscoverer);
/* 218 */     Object<T> valueObject = (Object<T>)cache.get(cacheKey);
/* 219 */     if (valueObject == null) {
/* 220 */       valueObject = get(bindable, context, constructorProvider, parameterNameDiscoverer, resolvedType);
/* 221 */       cache.put(cacheKey, (valueObject != null) ? valueObject : NONE);
/*     */     } 
/* 223 */     return (valueObject != NONE) ? (ValueObject<T>)valueObject : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> ValueObject<T> get(Bindable<T> bindable, Binder.Context context, BindConstructorProvider constructorProvider, ParameterNameDiscoverer parameterNameDiscoverer, Class<T> resolvedType) {
/* 230 */     Constructor<?> bindConstructor = constructorProvider.getBindConstructor(bindable, context
/* 231 */         .isNestedConstructorBinding());
/* 232 */     if (bindConstructor == null) {
/* 233 */       return null;
/*     */     }
/* 235 */     if (KotlinDetector.isKotlinType(resolvedType)) {
/* 236 */       return ValueObjectBinder.KotlinValueObject.get((Constructor)bindConstructor, bindable.getType(), parameterNameDiscoverer);
/*     */     }
/*     */     
/* 239 */     return ValueObjectBinder.DefaultValueObject.get(bindConstructor, bindable.getType(), parameterNameDiscoverer);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Map<CacheKey, Object> getCache(Binder.Context context) {
/* 244 */     Map<CacheKey, Object> cache = (Map<CacheKey, Object>)context.getCache().get(ValueObject.class);
/* 245 */     if (cache == null) {
/* 246 */       cache = new ConcurrentHashMap<>();
/* 247 */       context.getCache().put(ValueObject.class, cache);
/*     */     } 
/* 249 */     return cache;
/*     */   }
/*     */   private static final class CacheKey extends Record { private final Bindable<?> bindable; private final BindConstructorProvider constructorProvider; private final ParameterNameDiscoverer parameterNameDiscoverer;
/* 252 */     private CacheKey(Bindable<?> bindable, BindConstructorProvider constructorProvider, ParameterNameDiscoverer parameterNameDiscoverer) { this.bindable = bindable; this.constructorProvider = constructorProvider; this.parameterNameDiscoverer = parameterNameDiscoverer; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #252	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 252 */       //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey; } public Bindable<?> bindable() { return this.bindable; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #252	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #252	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/boot/context/properties/bind/ValueObjectBinder$ValueObject$CacheKey;
/* 252 */       //   0	8	1	o	Ljava/lang/Object; } public BindConstructorProvider constructorProvider() { return this.constructorProvider; } public ParameterNameDiscoverer parameterNameDiscoverer() { return this.parameterNameDiscoverer; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\properties\bind\ValueObjectBinder$ValueObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */