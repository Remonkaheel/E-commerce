/*    */ package org.springframework.boot.context.event;
/*    */ 
/*    */ import org.springframework.boot.ConfigurableBootstrapContext;
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationEnvironmentPreparedEvent
/*    */   extends SpringApplicationEvent
/*    */ {
/*    */   private final ConfigurableBootstrapContext bootstrapContext;
/*    */   private final ConfigurableEnvironment environment;
/*    */   
/*    */   public ApplicationEnvironmentPreparedEvent(ConfigurableBootstrapContext bootstrapContext, SpringApplication application, String[] args, ConfigurableEnvironment environment) {
/* 47 */     super(application, args);
/* 48 */     this.bootstrapContext = bootstrapContext;
/* 49 */     this.environment = environment;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurableBootstrapContext getBootstrapContext() {
/* 58 */     return this.bootstrapContext;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurableEnvironment getEnvironment() {
/* 66 */     return this.environment;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\event\ApplicationEnvironmentPreparedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */