/*     */ package org.springframework.boot.context.event;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.ConfigurableBootstrapContext;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.SpringApplicationRunListener;
/*     */ import org.springframework.boot.availability.AvailabilityChangeEvent;
/*     */ import org.springframework.boot.availability.AvailabilityState;
/*     */ import org.springframework.boot.availability.LivenessState;
/*     */ import org.springframework.boot.availability.ReadinessState;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.event.SimpleApplicationEventMulticaster;
/*     */ import org.springframework.context.support.AbstractApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.ErrorHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EventPublishingRunListener
/*     */   implements SpringApplicationRunListener, Ordered
/*     */ {
/*     */   private final SpringApplication application;
/*     */   private final String[] args;
/*     */   private final SimpleApplicationEventMulticaster initialMulticaster;
/*     */   
/*     */   EventPublishingRunListener(SpringApplication application, String[] args) {
/*  63 */     this.application = application;
/*  64 */     this.args = args;
/*  65 */     this.initialMulticaster = new SimpleApplicationEventMulticaster();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  70 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void starting(ConfigurableBootstrapContext bootstrapContext) {
/*  75 */     multicastInitialEvent(new ApplicationStartingEvent(bootstrapContext, this.application, this.args));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void environmentPrepared(ConfigurableBootstrapContext bootstrapContext, ConfigurableEnvironment environment) {
/*  81 */     multicastInitialEvent(new ApplicationEnvironmentPreparedEvent(bootstrapContext, this.application, this.args, environment));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void contextPrepared(ConfigurableApplicationContext context) {
/*  87 */     multicastInitialEvent(new ApplicationContextInitializedEvent(this.application, this.args, context));
/*     */   }
/*     */ 
/*     */   
/*     */   public void contextLoaded(ConfigurableApplicationContext context) {
/*  92 */     for (ApplicationListener<?> listener : (Iterable<ApplicationListener<?>>)this.application.getListeners()) {
/*  93 */       if (listener instanceof ApplicationContextAware) { ApplicationContextAware contextAware = (ApplicationContextAware)listener;
/*  94 */         contextAware.setApplicationContext((ApplicationContext)context); }
/*     */       
/*  96 */       context.addApplicationListener(listener);
/*     */     } 
/*  98 */     multicastInitialEvent(new ApplicationPreparedEvent(this.application, this.args, context));
/*     */   }
/*     */ 
/*     */   
/*     */   public void started(ConfigurableApplicationContext context, Duration timeTaken) {
/* 103 */     context.publishEvent(new ApplicationStartedEvent(this.application, this.args, context, timeTaken));
/* 104 */     AvailabilityChangeEvent.publish((ApplicationContext)context, (AvailabilityState)LivenessState.CORRECT);
/*     */   }
/*     */ 
/*     */   
/*     */   public void ready(ConfigurableApplicationContext context, Duration timeTaken) {
/* 109 */     context.publishEvent(new ApplicationReadyEvent(this.application, this.args, context, timeTaken));
/* 110 */     AvailabilityChangeEvent.publish((ApplicationContext)context, (AvailabilityState)ReadinessState.ACCEPTING_TRAFFIC);
/*     */   }
/*     */ 
/*     */   
/*     */   public void failed(ConfigurableApplicationContext context, Throwable exception) {
/* 115 */     ApplicationFailedEvent event = new ApplicationFailedEvent(this.application, this.args, context, exception);
/* 116 */     if (context != null && context.isActive()) {
/*     */ 
/*     */       
/* 119 */       context.publishEvent(event);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 124 */       if (context instanceof AbstractApplicationContext) { AbstractApplicationContext abstractApplicationContext = (AbstractApplicationContext)context;
/* 125 */         for (ApplicationListener<?> listener : (Iterable<ApplicationListener<?>>)abstractApplicationContext.getApplicationListeners()) {
/* 126 */           this.initialMulticaster.addApplicationListener(listener);
/*     */         } }
/*     */       
/* 129 */       this.initialMulticaster.setErrorHandler(new LoggingErrorHandler());
/* 130 */       this.initialMulticaster.multicastEvent(event);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void multicastInitialEvent(ApplicationEvent event) {
/* 135 */     refreshApplicationListeners();
/* 136 */     this.initialMulticaster.multicastEvent(event);
/*     */   }
/*     */   
/*     */   private void refreshApplicationListeners() {
/* 140 */     Objects.requireNonNull(this.initialMulticaster); this.application.getListeners().forEach(this.initialMulticaster::addApplicationListener);
/*     */   }
/*     */   
/*     */   private static final class LoggingErrorHandler
/*     */     implements ErrorHandler {
/* 145 */     private static final Log logger = LogFactory.getLog(EventPublishingRunListener.class);
/*     */ 
/*     */     
/*     */     public void handleError(Throwable throwable) {
/* 149 */       logger.warn("Error calling ApplicationEventListener", throwable);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\event\EventPublishingRunListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */