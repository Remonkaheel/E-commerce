/*    */ package org.springframework.boot.context.event;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationReadyEvent
/*    */   extends SpringApplicationEvent
/*    */ {
/*    */   private final ConfigurableApplicationContext context;
/*    */   private final Duration timeTaken;
/*    */   
/*    */   public ApplicationReadyEvent(SpringApplication application, String[] args, ConfigurableApplicationContext context, Duration timeTaken) {
/* 52 */     super(application, args);
/* 53 */     this.context = context;
/* 54 */     this.timeTaken = timeTaken;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurableApplicationContext getApplicationContext() {
/* 62 */     return this.context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Duration getTimeTaken() {
/* 72 */     return this.timeTaken;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\event\ApplicationReadyEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */