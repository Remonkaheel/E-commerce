/*    */ package org.springframework.boot.context.event;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationStartedEvent
/*    */   extends SpringApplicationEvent
/*    */ {
/*    */   private final ConfigurableApplicationContext context;
/*    */   private final Duration timeTaken;
/*    */   
/*    */   public ApplicationStartedEvent(SpringApplication application, String[] args, ConfigurableApplicationContext context, Duration timeTaken) {
/* 51 */     super(application, args);
/* 52 */     this.context = context;
/* 53 */     this.timeTaken = timeTaken;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurableApplicationContext getApplicationContext() {
/* 61 */     return this.context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Duration getTimeTaken() {
/* 70 */     return this.timeTaken;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\event\ApplicationStartedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */