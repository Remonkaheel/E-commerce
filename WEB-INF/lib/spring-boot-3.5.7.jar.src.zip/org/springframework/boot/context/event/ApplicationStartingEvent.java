/*    */ package org.springframework.boot.context.event;
/*    */ 
/*    */ import org.springframework.boot.ConfigurableBootstrapContext;
/*    */ import org.springframework.boot.SpringApplication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationStartingEvent
/*    */   extends SpringApplicationEvent
/*    */ {
/*    */   private final ConfigurableBootstrapContext bootstrapContext;
/*    */   
/*    */   public ApplicationStartingEvent(ConfigurableBootstrapContext bootstrapContext, SpringApplication application, String[] args) {
/* 49 */     super(application, args);
/* 50 */     this.bootstrapContext = bootstrapContext;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurableBootstrapContext getBootstrapContext() {
/* 59 */     return this.bootstrapContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\event\ApplicationStartingEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */