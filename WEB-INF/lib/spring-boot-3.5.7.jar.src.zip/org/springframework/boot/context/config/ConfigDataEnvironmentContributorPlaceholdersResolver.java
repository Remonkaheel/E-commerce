/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import org.springframework.boot.context.properties.bind.PlaceholdersResolver;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.PropertyPlaceholderHelper;
/*     */ import org.springframework.util.SystemPropertyUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigDataEnvironmentContributorPlaceholdersResolver
/*     */   implements PlaceholdersResolver
/*     */ {
/*     */   private final Iterable<ConfigDataEnvironmentContributor> contributors;
/*     */   private final ConfigDataActivationContext activationContext;
/*     */   private final boolean failOnResolveFromInactiveContributor;
/*     */   private final PropertyPlaceholderHelper helper;
/*     */   private final ConfigDataEnvironmentContributor activeContributor;
/*     */   private final ConversionService conversionService;
/*     */   
/*     */   ConfigDataEnvironmentContributorPlaceholdersResolver(Iterable<ConfigDataEnvironmentContributor> contributors, ConfigDataActivationContext activationContext, ConfigDataEnvironmentContributor activeContributor, boolean failOnResolveFromInactiveContributor, ConversionService conversionService) {
/*  53 */     this.contributors = contributors;
/*  54 */     this.activationContext = activationContext;
/*  55 */     this.activeContributor = activeContributor;
/*  56 */     this.failOnResolveFromInactiveContributor = failOnResolveFromInactiveContributor;
/*  57 */     this.conversionService = conversionService;
/*  58 */     this.helper = new PropertyPlaceholderHelper("${", "}", ":", SystemPropertyUtils.ESCAPE_CHARACTER, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object resolvePlaceholders(Object value) {
/*  65 */     if (value instanceof String) { String string = (String)value;
/*  66 */       return this.helper.replacePlaceholders(string, this::resolvePlaceholder); }
/*     */     
/*  68 */     return value;
/*     */   }
/*     */   
/*     */   private String resolvePlaceholder(String placeholder) {
/*  72 */     Object result = null;
/*  73 */     for (ConfigDataEnvironmentContributor contributor : this.contributors) {
/*  74 */       PropertySource<?> propertySource = contributor.getPropertySource();
/*  75 */       Object value = (propertySource != null) ? propertySource.getProperty(placeholder) : null;
/*  76 */       if (value != null && !isActive(contributor)) {
/*  77 */         if (this.failOnResolveFromInactiveContributor) {
/*  78 */           ConfigDataResource resource = contributor.getResource();
/*  79 */           Origin origin = OriginLookup.getOrigin(propertySource, placeholder);
/*  80 */           throw new InactiveConfigDataAccessException(propertySource, resource, placeholder, origin);
/*     */         } 
/*  82 */         value = null;
/*     */       } 
/*  84 */       result = (result != null) ? result : value;
/*     */     } 
/*  86 */     return (result != null) ? convertValueIfNecessary(result) : null;
/*     */   }
/*     */   
/*     */   private boolean isActive(ConfigDataEnvironmentContributor contributor) {
/*  90 */     if (contributor == this.activeContributor) {
/*  91 */       return true;
/*     */     }
/*  93 */     if (contributor.getKind() != ConfigDataEnvironmentContributor.Kind.UNBOUND_IMPORT) {
/*  94 */       return contributor.isActive(this.activationContext);
/*     */     }
/*  96 */     return contributor.withBoundProperties(this.contributors, this.activationContext)
/*  97 */       .isActive(this.activationContext);
/*     */   }
/*     */   
/*     */   private String convertValueIfNecessary(Object value) {
/* 101 */     String string = (String)value; return (value instanceof String) ? string : (String)this.conversionService.convert(value, String.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataEnvironmentContributorPlaceholdersResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */