/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Supplier;
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.boot.context.properties.bind.AbstractBindHandler;
/*    */ import org.springframework.boot.context.properties.bind.BindContext;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.boot.origin.Origin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConfigDataLocationBindHandler
/*    */   extends AbstractBindHandler
/*    */ {
/*    */   public Object onSuccess(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) {
/* 43 */     if (result instanceof ConfigDataLocation) { ConfigDataLocation location = (ConfigDataLocation)result;
/* 44 */       return withOrigin(context, location); }
/*    */     
/* 46 */     if (result instanceof List) { List<?> list = (List)result;
/* 47 */       return list.stream()
/* 48 */         .filter(Objects::nonNull)
/* 49 */         .map(element -> {
/*    */             ConfigDataLocation location = (ConfigDataLocation)element; return (element instanceof ConfigDataLocation) ? withOrigin(context, location) : element;
/* 51 */           }).collect(Collectors.toCollection(java.util.ArrayList::new)); }
/*    */     
/* 53 */     if (result instanceof ConfigDataLocation[]) { ConfigDataLocation[] unfilteredLocations = (ConfigDataLocation[])result;
/* 54 */       return Arrays.<ConfigDataLocation>stream(unfilteredLocations)
/* 55 */         .filter(Objects::nonNull)
/* 56 */         .map(element -> withOrigin(context, element))
/* 57 */         .toArray(x$0 -> new ConfigDataLocation[x$0]); }
/*    */     
/* 59 */     return result;
/*    */   }
/*    */   
/*    */   private ConfigDataLocation withOrigin(BindContext context, ConfigDataLocation result) {
/* 63 */     if (result.getOrigin() != null) {
/* 64 */       return result;
/*    */     }
/* 66 */     Origin origin = Origin.from(context.getConfigurationProperty());
/* 67 */     return result.withOrigin(origin);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataLocationBindHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */