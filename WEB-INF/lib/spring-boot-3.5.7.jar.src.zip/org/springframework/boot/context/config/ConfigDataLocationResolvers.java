/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.boot.BootstrapContext;
/*     */ import org.springframework.boot.BootstrapRegistry;
/*     */ import org.springframework.boot.ConfigurableBootstrapContext;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.logging.DeferredLogFactory;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigDataLocationResolvers
/*     */ {
/*     */   private final List<ConfigDataLocationResolver<?>> resolvers;
/*     */   
/*     */   ConfigDataLocationResolvers(DeferredLogFactory logFactory, ConfigurableBootstrapContext bootstrapContext, Binder binder, ResourceLoader resourceLoader, SpringFactoriesLoader springFactoriesLoader) {
/*  57 */     SpringFactoriesLoader.ArgumentResolver argumentResolver = SpringFactoriesLoader.ArgumentResolver.of(DeferredLogFactory.class, logFactory);
/*  58 */     argumentResolver = argumentResolver.and(Binder.class, binder);
/*  59 */     argumentResolver = argumentResolver.and(ResourceLoader.class, resourceLoader);
/*  60 */     argumentResolver = argumentResolver.and(ConfigurableBootstrapContext.class, bootstrapContext);
/*  61 */     argumentResolver = argumentResolver.and(BootstrapContext.class, bootstrapContext);
/*  62 */     argumentResolver = argumentResolver.and(BootstrapRegistry.class, bootstrapContext);
/*  63 */     argumentResolver = argumentResolver.andSupplied(Log.class, () -> {
/*     */           throw new IllegalArgumentException("Log types cannot be injected, please use DeferredLogFactory");
/*     */         });
/*  66 */     this.resolvers = reorder(springFactoriesLoader.load(ConfigDataLocationResolver.class, argumentResolver));
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ConfigDataLocationResolver<?>> reorder(List<ConfigDataLocationResolver> resolvers) {
/*  71 */     List<ConfigDataLocationResolver<?>> reordered = new ArrayList<>(resolvers.size());
/*  72 */     ConfigDataLocationResolver<?> standardConfigDataLocationResolver = null;
/*  73 */     for (ConfigDataLocationResolver<?> resolver : resolvers) {
/*  74 */       if (resolver instanceof StandardConfigDataLocationResolver) {
/*  75 */         standardConfigDataLocationResolver = resolver;
/*     */         continue;
/*     */       } 
/*  78 */       reordered.add(resolver);
/*     */     } 
/*     */     
/*  81 */     if (standardConfigDataLocationResolver != null) {
/*  82 */       reordered.add(standardConfigDataLocationResolver);
/*     */     }
/*  84 */     return Collections.unmodifiableList(reordered);
/*     */   }
/*     */ 
/*     */   
/*     */   List<ConfigDataResolutionResult> resolve(ConfigDataLocationResolverContext context, ConfigDataLocation location, Profiles profiles) {
/*  89 */     if (location == null) {
/*  90 */       return Collections.emptyList();
/*     */     }
/*  92 */     for (ConfigDataLocationResolver<?> resolver : getResolvers()) {
/*  93 */       if (resolver.isResolvable(context, location)) {
/*  94 */         return resolve(resolver, context, location, profiles);
/*     */       }
/*     */     } 
/*  97 */     throw new UnsupportedConfigDataLocationException(location);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ConfigDataResolutionResult> resolve(ConfigDataLocationResolver<?> resolver, ConfigDataLocationResolverContext context, ConfigDataLocation location, Profiles profiles) {
/* 102 */     List<ConfigDataResolutionResult> resolved = resolve(location, false, () -> resolver.resolve(context, location));
/* 103 */     if (profiles == null) {
/* 104 */       return resolved;
/*     */     }
/* 106 */     List<ConfigDataResolutionResult> profileSpecific = resolve(location, true, () -> resolver.resolveProfileSpecific(context, location, profiles));
/*     */     
/* 108 */     return merge(resolved, profileSpecific);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ConfigDataResolutionResult> resolve(ConfigDataLocation location, boolean profileSpecific, Supplier<List<? extends ConfigDataResource>> resolveAction) {
/* 113 */     List<ConfigDataResource> resources = nonNullList(resolveAction.get());
/* 114 */     List<ConfigDataResolutionResult> resolved = new ArrayList<>(resources.size());
/* 115 */     for (ConfigDataResource resource : resources) {
/* 116 */       resolved.add(new ConfigDataResolutionResult(location, resource, profileSpecific));
/*     */     }
/* 118 */     return resolved;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> List<T> nonNullList(List<? extends T> list) {
/* 123 */     return (list != null) ? (List)list : Collections.<T>emptyList();
/*     */   }
/*     */   
/*     */   private <T> List<T> merge(List<T> list1, List<T> list2) {
/* 127 */     List<T> merged = new ArrayList<>(list1.size() + list2.size());
/* 128 */     merged.addAll(list1);
/* 129 */     merged.addAll(list2);
/* 130 */     return merged;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<ConfigDataLocationResolver<?>> getResolvers() {
/* 138 */     return this.resolvers;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataLocationResolvers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */