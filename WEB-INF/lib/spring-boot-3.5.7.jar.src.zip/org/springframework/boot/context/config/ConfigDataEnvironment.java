/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.boot.BootstrapRegistry;
/*     */ import org.springframework.boot.ConfigurableBootstrapContext;
/*     */ import org.springframework.boot.DefaultPropertiesPropertySource;
/*     */ import org.springframework.boot.context.properties.bind.BindException;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.bind.PlaceholdersResolver;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.logging.DeferredLogFactory;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigDataEnvironment
/*     */ {
/*     */   static final String LOCATION_PROPERTY = "spring.config.location";
/*     */   static final String ADDITIONAL_LOCATION_PROPERTY = "spring.config.additional-location";
/*     */   static final String IMPORT_PROPERTY = "spring.config.import";
/*     */   static final String ON_NOT_FOUND_PROPERTY = "spring.config.on-not-found";
/*     */   static final ConfigDataLocation[] DEFAULT_SEARCH_LOCATIONS;
/*     */   
/*     */   static {
/*  90 */     List<ConfigDataLocation> locations = new ArrayList<>();
/*  91 */     locations.add(ConfigDataLocation.of("optional:classpath:/;optional:classpath:/config/"));
/*  92 */     locations.add(ConfigDataLocation.of("optional:file:./;optional:file:./config/;optional:file:./config/*/"));
/*  93 */     DEFAULT_SEARCH_LOCATIONS = locations.<ConfigDataLocation>toArray(new ConfigDataLocation[0]);
/*     */   }
/*     */   
/*  96 */   private static final ConfigDataLocation[] EMPTY_LOCATIONS = new ConfigDataLocation[0];
/*     */ 
/*     */   
/*  99 */   private static final Bindable<ConfigDataLocation[]> CONFIG_DATA_LOCATION_ARRAY = Bindable.of(ConfigDataLocation[].class);
/*     */   
/* 101 */   private static final Bindable<List<String>> STRING_LIST = Bindable.listOf(String.class);
/*     */   
/* 103 */   private static final ConfigDataEnvironmentContributors.BinderOption[] ALLOW_INACTIVE_BINDING = new ConfigDataEnvironmentContributors.BinderOption[0];
/*     */   
/* 105 */   private static final ConfigDataEnvironmentContributors.BinderOption[] DENY_INACTIVE_BINDING = new ConfigDataEnvironmentContributors.BinderOption[] { ConfigDataEnvironmentContributors.BinderOption.FAIL_ON_BIND_TO_INACTIVE_SOURCE };
/*     */ 
/*     */ 
/*     */   
/*     */   private final DeferredLogFactory logFactory;
/*     */ 
/*     */   
/*     */   private final Log logger;
/*     */ 
/*     */   
/*     */   private final ConfigDataNotFoundAction notFoundAction;
/*     */ 
/*     */   
/*     */   private final ConfigurableBootstrapContext bootstrapContext;
/*     */ 
/*     */   
/*     */   private final ConfigurableEnvironment environment;
/*     */ 
/*     */   
/*     */   private final ConfigDataLocationResolvers resolvers;
/*     */ 
/*     */   
/*     */   private final Collection<String> additionalProfiles;
/*     */ 
/*     */   
/*     */   private final ConfigDataEnvironmentUpdateListener environmentUpdateListener;
/*     */ 
/*     */   
/*     */   private final ConfigDataLoaders loaders;
/*     */ 
/*     */   
/*     */   private final ConfigDataEnvironmentContributors contributors;
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataEnvironment(DeferredLogFactory logFactory, ConfigurableBootstrapContext bootstrapContext, ConfigurableEnvironment environment, ResourceLoader resourceLoader, Collection<String> additionalProfiles, ConfigDataEnvironmentUpdateListener environmentUpdateListener) {
/* 141 */     Binder binder = Binder.get((Environment)environment);
/* 142 */     this.logFactory = logFactory;
/* 143 */     this.logger = logFactory.getLog(getClass());
/* 144 */     this
/* 145 */       .notFoundAction = (ConfigDataNotFoundAction)binder.bind("spring.config.on-not-found", ConfigDataNotFoundAction.class).orElse(ConfigDataNotFoundAction.FAIL);
/* 146 */     this.bootstrapContext = bootstrapContext;
/* 147 */     this.environment = environment;
/* 148 */     this.resolvers = createConfigDataLocationResolvers(logFactory, bootstrapContext, binder, resourceLoader);
/* 149 */     this.additionalProfiles = additionalProfiles;
/* 150 */     this
/* 151 */       .environmentUpdateListener = (environmentUpdateListener != null) ? environmentUpdateListener : ConfigDataEnvironmentUpdateListener.NONE;
/* 152 */     this
/* 153 */       .loaders = new ConfigDataLoaders(logFactory, bootstrapContext, SpringFactoriesLoader.forDefaultResourceLocation(resourceLoader.getClassLoader()));
/* 154 */     this.contributors = createContributors(binder);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ConfigDataLocationResolvers createConfigDataLocationResolvers(DeferredLogFactory logFactory, ConfigurableBootstrapContext bootstrapContext, Binder binder, ResourceLoader resourceLoader) {
/* 159 */     return new ConfigDataLocationResolvers(logFactory, bootstrapContext, binder, resourceLoader, 
/* 160 */         SpringFactoriesLoader.forDefaultResourceLocation(resourceLoader.getClassLoader()));
/*     */   }
/*     */   
/*     */   private ConfigDataEnvironmentContributors createContributors(Binder binder) {
/* 164 */     this.logger.trace("Building config data environment contributors");
/* 165 */     MutablePropertySources propertySources = this.environment.getPropertySources();
/* 166 */     List<ConfigDataEnvironmentContributor> contributors = new ArrayList<>(propertySources.size() + 10);
/* 167 */     PropertySource<?> defaultPropertySource = null;
/* 168 */     for (PropertySource<?> propertySource : (Iterable<PropertySource<?>>)propertySources) {
/* 169 */       if (DefaultPropertiesPropertySource.hasMatchingName(propertySource)) {
/* 170 */         defaultPropertySource = propertySource;
/*     */         continue;
/*     */       } 
/* 173 */       this.logger.trace(LogMessage.format("Creating wrapped config data contributor for '%s'", propertySource
/* 174 */             .getName()));
/* 175 */       contributors.add(ConfigDataEnvironmentContributor.ofExisting(propertySource, (ConversionService)this.environment
/* 176 */             .getConversionService()));
/*     */     } 
/*     */     
/* 179 */     contributors.addAll(getInitialImportContributors(binder));
/* 180 */     if (defaultPropertySource != null) {
/* 181 */       this.logger.trace("Creating wrapped config data contributor for default property source");
/* 182 */       contributors.add(ConfigDataEnvironmentContributor.ofExisting(defaultPropertySource, (ConversionService)this.environment
/* 183 */             .getConversionService()));
/*     */     } 
/* 185 */     return createContributors(contributors);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ConfigDataEnvironmentContributors createContributors(List<ConfigDataEnvironmentContributor> contributors) {
/* 190 */     return new ConfigDataEnvironmentContributors(this.logFactory, this.bootstrapContext, contributors, (ConversionService)this.environment
/* 191 */         .getConversionService(), this.environmentUpdateListener);
/*     */   }
/*     */   
/*     */   ConfigDataEnvironmentContributors getContributors() {
/* 195 */     return this.contributors;
/*     */   }
/*     */   
/*     */   private List<ConfigDataEnvironmentContributor> getInitialImportContributors(Binder binder) {
/* 199 */     List<ConfigDataEnvironmentContributor> initialContributors = new ArrayList<>();
/* 200 */     addInitialImportContributors(initialContributors, bindLocations(binder, "spring.config.import", EMPTY_LOCATIONS));
/* 201 */     addInitialImportContributors(initialContributors, 
/* 202 */         bindLocations(binder, "spring.config.additional-location", EMPTY_LOCATIONS));
/* 203 */     addInitialImportContributors(initialContributors, 
/* 204 */         bindLocations(binder, "spring.config.location", DEFAULT_SEARCH_LOCATIONS));
/* 205 */     return initialContributors;
/*     */   }
/*     */   
/*     */   private ConfigDataLocation[] bindLocations(Binder binder, String propertyName, ConfigDataLocation[] other) {
/* 209 */     return (ConfigDataLocation[])binder.bind(propertyName, CONFIG_DATA_LOCATION_ARRAY).orElse(other);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addInitialImportContributors(List<ConfigDataEnvironmentContributor> initialContributors, ConfigDataLocation[] locations) {
/* 214 */     for (int i = locations.length - 1; i >= 0; i--) {
/* 215 */       initialContributors.add(createInitialImportContributor(locations[i]));
/*     */     }
/*     */   }
/*     */   
/*     */   private ConfigDataEnvironmentContributor createInitialImportContributor(ConfigDataLocation location) {
/* 220 */     this.logger.trace(LogMessage.format("Adding initial config data import from location '%s'", location));
/* 221 */     return ConfigDataEnvironmentContributor.ofInitialImport(location, (ConversionService)this.environment.getConversionService());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void processAndApply() {
/* 229 */     ConfigDataImporter importer = new ConfigDataImporter(this.logFactory, this.notFoundAction, this.resolvers, this.loaders);
/*     */     
/* 231 */     registerBootstrapBinder(this.contributors, null, DENY_INACTIVE_BINDING);
/* 232 */     ConfigDataEnvironmentContributors contributors = processInitial(this.contributors, importer);
/* 233 */     ConfigDataActivationContext activationContext = createActivationContext(contributors
/* 234 */         .getBinder(null, new ConfigDataEnvironmentContributors.BinderOption[] { ConfigDataEnvironmentContributors.BinderOption.FAIL_ON_BIND_TO_INACTIVE_SOURCE }));
/* 235 */     contributors = processWithoutProfiles(contributors, importer, activationContext);
/* 236 */     activationContext = withProfiles(contributors, activationContext);
/* 237 */     contributors = processWithProfiles(contributors, importer, activationContext);
/* 238 */     applyToEnvironment(contributors, activationContext, importer.getLoadedLocations(), importer
/* 239 */         .getOptionalLocations());
/*     */   }
/*     */ 
/*     */   
/*     */   private ConfigDataEnvironmentContributors processInitial(ConfigDataEnvironmentContributors contributors, ConfigDataImporter importer) {
/* 244 */     this.logger.trace("Processing initial config data environment contributors without activation context");
/* 245 */     contributors = contributors.withProcessedImports(importer, null);
/* 246 */     registerBootstrapBinder(contributors, null, DENY_INACTIVE_BINDING);
/* 247 */     return contributors;
/*     */   }
/*     */   
/*     */   private ConfigDataActivationContext createActivationContext(Binder initialBinder) {
/* 251 */     this.logger.trace("Creating config data activation context from initial contributions");
/*     */     try {
/* 253 */       return new ConfigDataActivationContext((Environment)this.environment, initialBinder);
/*     */     }
/* 255 */     catch (BindException ex) {
/* 256 */       Throwable throwable = ex.getCause(); if (throwable instanceof InactiveConfigDataAccessException) { InactiveConfigDataAccessException inactiveException = (InactiveConfigDataAccessException)throwable;
/* 257 */         throw inactiveException; }
/*     */       
/* 259 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private ConfigDataEnvironmentContributors processWithoutProfiles(ConfigDataEnvironmentContributors contributors, ConfigDataImporter importer, ConfigDataActivationContext activationContext) {
/* 265 */     this.logger.trace("Processing config data environment contributors with initial activation context");
/* 266 */     contributors = contributors.withProcessedImports(importer, activationContext);
/* 267 */     registerBootstrapBinder(contributors, activationContext, DENY_INACTIVE_BINDING);
/* 268 */     return contributors;
/*     */   }
/*     */ 
/*     */   
/*     */   private ConfigDataActivationContext withProfiles(ConfigDataEnvironmentContributors contributors, ConfigDataActivationContext activationContext) {
/* 273 */     this.logger.trace("Deducing profiles from current config data environment contributors");
/* 274 */     Binder binder = contributors.getBinder(activationContext, contributor -> !contributor.hasConfigDataOption(ConfigData.Option.IGNORE_PROFILES), new ConfigDataEnvironmentContributors.BinderOption[] { ConfigDataEnvironmentContributors.BinderOption.FAIL_ON_BIND_TO_INACTIVE_SOURCE });
/*     */ 
/*     */     
/*     */     try {
/* 278 */       Set<String> additionalProfiles = new LinkedHashSet<>(this.additionalProfiles);
/* 279 */       additionalProfiles.addAll(getIncludedProfiles(contributors, activationContext));
/* 280 */       Profiles profiles = new Profiles((Environment)this.environment, binder, additionalProfiles);
/* 281 */       return activationContext.withProfiles(profiles);
/*     */     }
/* 283 */     catch (BindException ex) {
/* 284 */       Throwable throwable = ex.getCause(); if (throwable instanceof InactiveConfigDataAccessException) { InactiveConfigDataAccessException inactiveException = (InactiveConfigDataAccessException)throwable;
/* 285 */         throw inactiveException; }
/*     */       
/* 287 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<? extends String> getIncludedProfiles(ConfigDataEnvironmentContributors contributors, ConfigDataActivationContext activationContext) {
/* 294 */     PlaceholdersResolver placeholdersResolver = new ConfigDataEnvironmentContributorPlaceholdersResolver(contributors, activationContext, null, true, (ConversionService)this.environment.getConversionService());
/* 295 */     Set<String> result = new LinkedHashSet<>();
/* 296 */     for (ConfigDataEnvironmentContributor contributor : contributors) {
/* 297 */       ConfigurationPropertySource source = contributor.getConfigurationPropertySource();
/* 298 */       if (source != null && !contributor.hasConfigDataOption(ConfigData.Option.IGNORE_PROFILES)) {
/* 299 */         Binder binder = new Binder(Collections.singleton(source), placeholdersResolver);
/* 300 */         binder.bind(Profiles.INCLUDE_PROFILES, STRING_LIST, ProfilesValidator.get(binder))
/* 301 */           .ifBound(includes -> {
/*     */               if (!contributor.isActive(activationContext)) {
/*     */                 InactiveConfigDataAccessException.throwIfPropertyFound(contributor, Profiles.INCLUDE_PROFILES);
/*     */                 
/*     */                 InactiveConfigDataAccessException.throwIfPropertyFound(contributor, Profiles.INCLUDE_PROFILES.append("[0]"));
/*     */               } 
/*     */               
/*     */               result.addAll(includes);
/*     */             });
/*     */       } 
/*     */     } 
/* 312 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private ConfigDataEnvironmentContributors processWithProfiles(ConfigDataEnvironmentContributors contributors, ConfigDataImporter importer, ConfigDataActivationContext activationContext) {
/* 317 */     this.logger.trace("Processing config data environment contributors with profile activation context");
/* 318 */     contributors = contributors.withProcessedImports(importer, activationContext);
/* 319 */     registerBootstrapBinder(contributors, activationContext, ALLOW_INACTIVE_BINDING);
/* 320 */     return contributors;
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerBootstrapBinder(ConfigDataEnvironmentContributors contributors, ConfigDataActivationContext activationContext, ConfigDataEnvironmentContributors.BinderOption... binderOptions) {
/* 325 */     this.bootstrapContext.register(Binder.class, 
/* 326 */         BootstrapRegistry.InstanceSupplier.from(() -> contributors.getBinder(activationContext, binderOptions))
/* 327 */         .withScope(BootstrapRegistry.Scope.PROTOTYPE));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyToEnvironment(ConfigDataEnvironmentContributors contributors, ConfigDataActivationContext activationContext, Set<ConfigDataLocation> loadedLocations, Set<ConfigDataLocation> optionalLocations) {
/* 333 */     checkForInvalidProperties(contributors);
/* 334 */     checkMandatoryLocations(contributors, activationContext, loadedLocations, optionalLocations);
/* 335 */     MutablePropertySources propertySources = this.environment.getPropertySources();
/* 336 */     applyContributor(contributors, activationContext, propertySources);
/* 337 */     DefaultPropertiesPropertySource.moveToEnd(propertySources);
/* 338 */     Profiles profiles = activationContext.getProfiles();
/* 339 */     this.logger.trace(LogMessage.format("Setting default profiles: %s", profiles.getDefault()));
/* 340 */     this.environment.setDefaultProfiles(StringUtils.toStringArray(profiles.getDefault()));
/* 341 */     this.logger.trace(LogMessage.format("Setting active profiles: %s", profiles.getActive()));
/* 342 */     this.environment.setActiveProfiles(StringUtils.toStringArray(profiles.getActive()));
/* 343 */     this.environmentUpdateListener.onSetProfiles(profiles);
/*     */   }
/*     */ 
/*     */   
/*     */   private void applyContributor(ConfigDataEnvironmentContributors contributors, ConfigDataActivationContext activationContext, MutablePropertySources propertySources) {
/* 348 */     this.logger.trace("Applying config data environment contributions");
/* 349 */     for (ConfigDataEnvironmentContributor contributor : contributors) {
/* 350 */       PropertySource<?> propertySource = contributor.getPropertySource();
/* 351 */       if (contributor.getKind() == ConfigDataEnvironmentContributor.Kind.BOUND_IMPORT && propertySource != null) {
/* 352 */         if (!contributor.isActive(activationContext)) {
/* 353 */           this.logger
/* 354 */             .trace(LogMessage.format("Skipping inactive property source '%s'", propertySource.getName()));
/*     */           continue;
/*     */         } 
/* 357 */         this.logger
/* 358 */           .trace(LogMessage.format("Adding imported property source '%s'", propertySource.getName()));
/* 359 */         propertySources.addLast(propertySource);
/* 360 */         this.environmentUpdateListener.onPropertySourceAdded(propertySource, contributor.getLocation(), contributor
/* 361 */             .getResource());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkForInvalidProperties(ConfigDataEnvironmentContributors contributors) {
/* 368 */     for (ConfigDataEnvironmentContributor contributor : contributors) {
/* 369 */       InvalidConfigDataPropertyException.throwIfPropertyFound(contributor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkMandatoryLocations(ConfigDataEnvironmentContributors contributors, ConfigDataActivationContext activationContext, Set<ConfigDataLocation> loadedLocations, Set<ConfigDataLocation> optionalLocations) {
/* 376 */     Set<ConfigDataLocation> mandatoryLocations = new LinkedHashSet<>();
/* 377 */     for (ConfigDataEnvironmentContributor contributor : contributors) {
/* 378 */       if (contributor.isActive(activationContext)) {
/* 379 */         mandatoryLocations.addAll(getMandatoryImports(contributor));
/*     */       }
/*     */     } 
/* 382 */     for (ConfigDataEnvironmentContributor contributor : contributors) {
/* 383 */       if (contributor.getLocation() != null) {
/* 384 */         mandatoryLocations.remove(contributor.getLocation());
/*     */       }
/*     */     } 
/* 387 */     mandatoryLocations.removeAll(loadedLocations);
/* 388 */     mandatoryLocations.removeAll(optionalLocations);
/* 389 */     if (!mandatoryLocations.isEmpty()) {
/* 390 */       for (ConfigDataLocation mandatoryLocation : mandatoryLocations) {
/* 391 */         this.notFoundAction.handle(this.logger, new ConfigDataLocationNotFoundException(mandatoryLocation));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Set<ConfigDataLocation> getMandatoryImports(ConfigDataEnvironmentContributor contributor) {
/* 397 */     List<ConfigDataLocation> imports = contributor.getImports();
/* 398 */     Set<ConfigDataLocation> mandatoryLocations = new LinkedHashSet<>(imports.size());
/* 399 */     for (ConfigDataLocation location : imports) {
/* 400 */       if (!location.isOptional()) {
/* 401 */         mandatoryLocations.add(location);
/*     */       }
/*     */     } 
/* 404 */     return mandatoryLocations;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataEnvironment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */