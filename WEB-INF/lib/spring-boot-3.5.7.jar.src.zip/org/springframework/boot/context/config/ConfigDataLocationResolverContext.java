package org.springframework.boot.context.config;

import org.springframework.boot.ConfigurableBootstrapContext;
import org.springframework.boot.context.properties.bind.Binder;

public interface ConfigDataLocationResolverContext {
  Binder getBinder();
  
  ConfigDataResource getParent();
  
  ConfigurableBootstrapContext getBootstrapContext();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataLocationResolverContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */