/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.boot.context.properties.bind.BindResult;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.style.ToStringCreator;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Profiles
/*     */   implements Iterable<String>
/*     */ {
/*     */   public static final String INCLUDE_PROFILES_PROPERTY_NAME = "spring.profiles.include";
/*  60 */   static final ConfigurationPropertyName INCLUDE_PROFILES = ConfigurationPropertyName.of("spring.profiles.include");
/*     */ 
/*     */   
/*  63 */   private static final Bindable<MultiValueMap<String, String>> STRING_STRINGS_MAP = Bindable.of(ResolvableType.forClassWithGenerics(MultiValueMap.class, new Class[] { String.class, String.class }));
/*     */   
/*  65 */   private static final Bindable<Set<String>> STRING_SET = Bindable.setOf(String.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final MultiValueMap<String, String> groups;
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<String> activeProfiles;
/*     */ 
/*     */   
/*     */   private final List<String> defaultProfiles;
/*     */ 
/*     */ 
/*     */   
/*     */   Profiles(Environment environment, Binder binder, Collection<String> additionalProfiles) {
/*  81 */     ProfilesValidator validator = ProfilesValidator.get(binder);
/*  82 */     if (additionalProfiles != null) {
/*  83 */       validator.validate(additionalProfiles, () -> "Invalid profile property value found in additional profiles");
/*     */     }
/*  85 */     this
/*  86 */       .groups = (MultiValueMap<String, String>)binder.bind("spring.profiles.group", STRING_STRINGS_MAP, validator).orElseGet(org.springframework.util.LinkedMultiValueMap::new);
/*  87 */     this.activeProfiles = expandProfiles(getActivatedProfiles(environment, binder, validator, additionalProfiles));
/*  88 */     this.defaultProfiles = expandProfiles(getDefaultProfiles(environment, binder, validator));
/*     */   }
/*     */ 
/*     */   
/*     */   private List<String> getActivatedProfiles(Environment environment, Binder binder, ProfilesValidator validator, Collection<String> additionalProfiles) {
/*  93 */     return asUniqueItemList(getProfiles(environment, binder, validator, Type.ACTIVE), additionalProfiles);
/*     */   }
/*     */   
/*     */   private List<String> getDefaultProfiles(Environment environment, Binder binder, ProfilesValidator validator) {
/*  97 */     return asUniqueItemList(getProfiles(environment, binder, validator, Type.DEFAULT));
/*     */   }
/*     */ 
/*     */   
/*     */   private Collection<String> getProfiles(Environment environment, Binder binder, ProfilesValidator validator, Type type) {
/* 102 */     String environmentPropertyValue = environment.getProperty(type.getName());
/*     */ 
/*     */     
/* 105 */     Set<String> environmentPropertyProfiles = !StringUtils.hasLength(environmentPropertyValue) ? Collections.<String>emptySet() : StringUtils.commaDelimitedListToSet(StringUtils.trimAllWhitespace(environmentPropertyValue));
/* 106 */     validator.validate(environmentPropertyProfiles, () -> "Invalid profile property value found in Environment under '%s'".formatted(new Object[] { type.getName() }));
/*     */     
/* 108 */     Set<String> environmentProfiles = new LinkedHashSet<>(Arrays.asList(type.get(environment)));
/* 109 */     BindResult<Set<String>> boundProfiles = binder.bind(type.getName(), STRING_SET, validator);
/* 110 */     if (hasProgrammaticallySetProfiles(type, environmentPropertyValue, environmentPropertyProfiles, environmentProfiles)) {
/*     */       
/* 112 */       if (!type.isMergeWithEnvironmentProfiles() || !boundProfiles.isBound()) {
/* 113 */         return environmentProfiles;
/*     */       }
/* 115 */       return (Collection<String>)boundProfiles.map(bound -> merge(environmentProfiles, bound)).get();
/*     */     } 
/* 117 */     return (Collection<String>)boundProfiles.orElse(type.getDefaultValue());
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasProgrammaticallySetProfiles(Type type, String environmentPropertyValue, Set<String> environmentPropertyProfiles, Set<String> environmentProfiles) {
/* 122 */     if (!StringUtils.hasLength(environmentPropertyValue)) {
/* 123 */       return !type.getDefaultValue().equals(environmentProfiles);
/*     */     }
/* 125 */     if (type.getDefaultValue().equals(environmentProfiles)) {
/* 126 */       return false;
/*     */     }
/* 128 */     return !environmentPropertyProfiles.equals(environmentProfiles);
/*     */   }
/*     */   
/*     */   private Set<String> merge(Set<String> environmentProfiles, Set<String> bound) {
/* 132 */     Set<String> result = new LinkedHashSet<>(environmentProfiles);
/* 133 */     result.addAll(bound);
/* 134 */     return result;
/*     */   }
/*     */   
/*     */   private List<String> expandProfiles(List<String> profiles) {
/* 138 */     Deque<String> stack = new ArrayDeque<>();
/* 139 */     Objects.requireNonNull(stack); asReversedList(profiles).forEach(stack::push);
/* 140 */     Set<String> expandedProfiles = new LinkedHashSet<>();
/* 141 */     while (!stack.isEmpty()) {
/* 142 */       String current = stack.pop();
/* 143 */       if (expandedProfiles.add(current)) {
/* 144 */         Objects.requireNonNull(stack); asReversedList((List<String>)this.groups.get(current)).forEach(stack::push);
/*     */       } 
/*     */     } 
/* 147 */     return asUniqueItemList(expandedProfiles);
/*     */   }
/*     */   
/*     */   private List<String> asReversedList(List<String> list) {
/* 151 */     if (CollectionUtils.isEmpty(list)) {
/* 152 */       return Collections.emptyList();
/*     */     }
/* 154 */     List<String> reversed = new ArrayList<>(list);
/* 155 */     Collections.reverse(reversed);
/* 156 */     return reversed;
/*     */   }
/*     */   
/*     */   private List<String> asUniqueItemList(Collection<String> profiles) {
/* 160 */     return asUniqueItemList(profiles, null);
/*     */   }
/*     */   
/*     */   private List<String> asUniqueItemList(Collection<String> profiles, Collection<String> additional) {
/* 164 */     LinkedHashSet<String> uniqueItems = new LinkedHashSet<>();
/* 165 */     if (!CollectionUtils.isEmpty(additional)) {
/* 166 */       uniqueItems.addAll(additional);
/*     */     }
/* 168 */     uniqueItems.addAll(profiles);
/* 169 */     return Collections.unmodifiableList(new ArrayList<>(uniqueItems));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<String> iterator() {
/* 177 */     return getAccepted().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getActive() {
/* 185 */     return this.activeProfiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getDefault() {
/* 193 */     return this.defaultProfiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getAccepted() {
/* 201 */     return !this.activeProfiles.isEmpty() ? this.activeProfiles : this.defaultProfiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAccepted(String profile) {
/* 210 */     return getAccepted().contains(profile);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 215 */     ToStringCreator creator = new ToStringCreator(this);
/* 216 */     creator.append("active", getActive().toString());
/* 217 */     creator.append("default", getDefault().toString());
/* 218 */     creator.append("accepted", getAccepted().toString());
/* 219 */     return creator.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum Type
/*     */   {
/* 227 */     ACTIVE("spring.profiles.active", Environment::getActiveProfiles, true, 
/* 228 */       (Function)Collections.emptySet()),
/*     */     
/* 230 */     DEFAULT("spring.profiles.default", Environment::getDefaultProfiles, false, 
/* 231 */       (Function)Collections.singleton("default"));
/*     */     
/*     */     private final Function<Environment, String[]> getter;
/*     */     
/*     */     private final boolean mergeWithEnvironmentProfiles;
/*     */     
/*     */     private final String name;
/*     */     
/*     */     private final Set<String> defaultValue;
/*     */ 
/*     */     
/*     */     Type(String name, Function<Environment, String[]> getter, boolean mergeWithEnvironmentProfiles, Set<String> defaultValue) {
/* 243 */       this.name = name;
/* 244 */       this.getter = getter;
/* 245 */       this.mergeWithEnvironmentProfiles = mergeWithEnvironmentProfiles;
/* 246 */       this.defaultValue = defaultValue;
/*     */     }
/*     */     
/*     */     String getName() {
/* 250 */       return this.name;
/*     */     }
/*     */     
/*     */     String[] get(Environment environment) {
/* 254 */       return this.getter.apply(environment);
/*     */     }
/*     */     
/*     */     Set<String> getDefaultValue() {
/* 258 */       return this.defaultValue;
/*     */     }
/*     */     
/*     */     boolean isMergeWithEnvironmentProfiles() {
/* 262 */       return this.mergeWithEnvironmentProfiles;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\Profiles.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */