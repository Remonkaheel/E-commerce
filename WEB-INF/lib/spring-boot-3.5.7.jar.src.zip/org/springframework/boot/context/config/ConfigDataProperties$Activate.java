/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.boot.cloud.CloudPlatform;
/*     */ import org.springframework.core.env.Profiles;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Activate
/*     */ {
/*     */   private final CloudPlatform onCloudPlatform;
/*     */   private final String[] onProfile;
/*     */   
/*     */   Activate(CloudPlatform onCloudPlatform, String[] onProfile) {
/* 108 */     this.onProfile = onProfile;
/* 109 */     this.onCloudPlatform = onCloudPlatform;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isActive(ConfigDataActivationContext activationContext) {
/* 119 */     if (activationContext == null) {
/* 120 */       return false;
/*     */     }
/* 122 */     CloudPlatform cloudPlatform = activationContext.getCloudPlatform();
/* 123 */     boolean activate = isActive((cloudPlatform != null) ? cloudPlatform : CloudPlatform.NONE);
/* 124 */     activate = (activate && isActive(activationContext.getProfiles()));
/* 125 */     return activate;
/*     */   }
/*     */   
/*     */   private boolean isActive(CloudPlatform cloudPlatform) {
/* 129 */     return (this.onCloudPlatform == null || this.onCloudPlatform == cloudPlatform);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isActive(Profiles profiles) {
/* 134 */     Objects.requireNonNull(profiles); return (ObjectUtils.isEmpty((Object[])this.onProfile) || (profiles != null && matchesActiveProfiles(profiles::isAccepted)));
/*     */   }
/*     */   
/*     */   private boolean matchesActiveProfiles(Predicate<String> activeProfiles) {
/* 138 */     return Profiles.of(this.onProfile).matches(activeProfiles);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataProperties$Activate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */