/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.file.Path;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import org.springframework.boot.env.ConfigTreePropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigTreeConfigDataLoader
/*    */   implements ConfigDataLoader<ConfigTreeConfigDataResource>
/*    */ {
/*    */   public ConfigData load(ConfigDataLoaderContext context, ConfigTreeConfigDataResource resource) throws IOException, ConfigDataResourceNotFoundException {
/* 38 */     Path path = resource.getPath();
/* 39 */     ConfigDataResourceNotFoundException.throwIfDoesNotExist(resource, path);
/* 40 */     String name = "Config tree '" + String.valueOf(path) + "'";
/* 41 */     ConfigTreePropertySource source = new ConfigTreePropertySource(name, path, new ConfigTreePropertySource.Option[] { ConfigTreePropertySource.Option.AUTO_TRIM_TRAILING_NEW_LINE });
/* 42 */     return new ConfigData((Collection)Collections.singletonList(source), new ConfigData.Option[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigTreeConfigDataLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */