package org.springframework.boot.context.config;

import org.springframework.boot.ConfigurableBootstrapContext;

public interface ConfigDataLoaderContext {
  ConfigurableBootstrapContext getBootstrapContext();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataLoaderContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */