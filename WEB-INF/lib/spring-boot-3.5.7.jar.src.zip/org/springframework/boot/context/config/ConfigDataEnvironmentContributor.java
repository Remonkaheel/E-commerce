/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.stream.Stream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.bind.PlaceholdersResolver;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigDataEnvironmentContributor
/*     */   implements Iterable<ConfigDataEnvironmentContributor>
/*     */ {
/*  59 */   private static final ConfigData.Options EMPTY_LOCATION_OPTIONS = ConfigData.Options.of(new ConfigData.Option[] { ConfigData.Option.IGNORE_IMPORTS });
/*     */ 
/*     */ 
/*     */   
/*     */   private final ConfigDataLocation location;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ConfigDataResource resource;
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean fromProfileSpecificImport;
/*     */ 
/*     */ 
/*     */   
/*     */   private final PropertySource<?> propertySource;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ConfigurationPropertySource configurationPropertySource;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ConfigDataProperties properties;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ConfigData.Options configDataOptions;
/*     */ 
/*     */   
/*     */   private final Map<ImportPhase, List<ConfigDataEnvironmentContributor>> children;
/*     */ 
/*     */   
/*     */   private final Kind kind;
/*     */ 
/*     */   
/*     */   private final ConversionService conversionService;
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataEnvironmentContributor(Kind kind, ConfigDataLocation location, ConfigDataResource resource, boolean fromProfileSpecificImport, PropertySource<?> propertySource, ConfigurationPropertySource configurationPropertySource, ConfigDataProperties properties, ConfigData.Options configDataOptions, Map<ImportPhase, List<ConfigDataEnvironmentContributor>> children, ConversionService conversionService) {
/* 101 */     this.kind = kind;
/* 102 */     this.location = location;
/* 103 */     this.resource = resource;
/* 104 */     this.fromProfileSpecificImport = fromProfileSpecificImport;
/* 105 */     this.properties = properties;
/* 106 */     this.propertySource = propertySource;
/* 107 */     this.configurationPropertySource = configurationPropertySource;
/* 108 */     this.configDataOptions = (configDataOptions != null) ? configDataOptions : ConfigData.Options.NONE;
/* 109 */     this.children = (children != null) ? children : Collections.<ImportPhase, List<ConfigDataEnvironmentContributor>>emptyMap();
/* 110 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Kind getKind() {
/* 118 */     return this.kind;
/*     */   }
/*     */   
/*     */   ConfigDataLocation getLocation() {
/* 122 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isActive(ConfigDataActivationContext activationContext) {
/* 131 */     if (this.kind == Kind.UNBOUND_IMPORT) {
/* 132 */       return false;
/*     */     }
/* 134 */     return (this.properties == null || this.properties.isActive(activationContext));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataResource getResource() {
/* 142 */     return this.resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isFromProfileSpecificImport() {
/* 150 */     return this.fromProfileSpecificImport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PropertySource<?> getPropertySource() {
/* 158 */     return this.propertySource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigurationPropertySource getConfigurationPropertySource() {
/* 166 */     return this.configurationPropertySource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasConfigDataOption(ConfigData.Option option) {
/* 175 */     return this.configDataOptions.contains(option);
/*     */   }
/*     */   
/*     */   ConfigDataEnvironmentContributor withoutConfigDataOption(ConfigData.Option option) {
/* 179 */     return new ConfigDataEnvironmentContributor(this.kind, this.location, this.resource, this.fromProfileSpecificImport, this.propertySource, this.configurationPropertySource, this.properties, this.configDataOptions
/*     */         
/* 181 */         .without(option), this.children, this.conversionService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<ConfigDataLocation> getImports() {
/* 189 */     return (this.properties != null) ? this.properties.getImports() : Collections.<ConfigDataLocation>emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasUnprocessedImports(ImportPhase importPhase) {
/* 199 */     if (getImports().isEmpty()) {
/* 200 */       return false;
/*     */     }
/* 202 */     return !this.children.containsKey(importPhase);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<ConfigDataEnvironmentContributor> getChildren(ImportPhase importPhase) {
/* 211 */     return this.children.getOrDefault(importPhase, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Stream<ConfigDataEnvironmentContributor> stream() {
/* 220 */     return StreamSupport.stream(spliterator(), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<ConfigDataEnvironmentContributor> iterator() {
/* 231 */     return new ContributorIterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataEnvironmentContributor withBoundProperties(Iterable<ConfigDataEnvironmentContributor> contributors, ConfigDataActivationContext activationContext) {
/* 243 */     Iterable<ConfigurationPropertySource> sources = Collections.singleton(getConfigurationPropertySource());
/* 244 */     PlaceholdersResolver placeholdersResolver = new ConfigDataEnvironmentContributorPlaceholdersResolver(contributors, activationContext, this, true, this.conversionService);
/*     */     
/* 246 */     Binder binder = new Binder(sources, placeholdersResolver, null, null, null);
/* 247 */     ConfigDataProperties properties = ConfigDataProperties.get(binder);
/* 248 */     if (properties != null && this.configDataOptions.contains(ConfigData.Option.IGNORE_IMPORTS)) {
/* 249 */       properties = properties.withoutImports();
/*     */     }
/* 251 */     return new ConfigDataEnvironmentContributor(Kind.BOUND_IMPORT, this.location, this.resource, this.fromProfileSpecificImport, this.propertySource, this.configurationPropertySource, properties, this.configDataOptions, null, this.conversionService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataEnvironmentContributor withChildren(ImportPhase importPhase, List<ConfigDataEnvironmentContributor> children) {
/* 265 */     Map<ImportPhase, List<ConfigDataEnvironmentContributor>> updatedChildren = new LinkedHashMap<>(this.children);
/* 266 */     updatedChildren.put(importPhase, children);
/* 267 */     if (importPhase == ImportPhase.AFTER_PROFILE_ACTIVATION) {
/* 268 */       moveProfileSpecific(updatedChildren);
/*     */     }
/* 270 */     return new ConfigDataEnvironmentContributor(this.kind, this.location, this.resource, this.fromProfileSpecificImport, this.propertySource, this.configurationPropertySource, this.properties, this.configDataOptions, updatedChildren, this.conversionService);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void moveProfileSpecific(Map<ImportPhase, List<ConfigDataEnvironmentContributor>> children) {
/* 276 */     List<ConfigDataEnvironmentContributor> before = children.get(ImportPhase.BEFORE_PROFILE_ACTIVATION);
/* 277 */     if (!hasAnyProfileSpecificChildren(before)) {
/*     */       return;
/*     */     }
/* 280 */     List<ConfigDataEnvironmentContributor> updatedBefore = new ArrayList<>(before.size());
/* 281 */     List<ConfigDataEnvironmentContributor> updatedAfter = new ArrayList<>();
/* 282 */     for (ConfigDataEnvironmentContributor contributor : before) {
/* 283 */       updatedBefore.add(moveProfileSpecificChildren(contributor, updatedAfter));
/*     */     }
/* 285 */     updatedAfter.addAll(children.getOrDefault(ImportPhase.AFTER_PROFILE_ACTIVATION, Collections.emptyList()));
/* 286 */     children.put(ImportPhase.BEFORE_PROFILE_ACTIVATION, updatedBefore);
/* 287 */     children.put(ImportPhase.AFTER_PROFILE_ACTIVATION, updatedAfter);
/*     */   }
/*     */ 
/*     */   
/*     */   private ConfigDataEnvironmentContributor moveProfileSpecificChildren(ConfigDataEnvironmentContributor contributor, List<ConfigDataEnvironmentContributor> removed) {
/* 292 */     for (ImportPhase importPhase : ImportPhase.values()) {
/* 293 */       List<ConfigDataEnvironmentContributor> children = contributor.getChildren(importPhase);
/* 294 */       List<ConfigDataEnvironmentContributor> updatedChildren = new ArrayList<>(children.size());
/* 295 */       for (ConfigDataEnvironmentContributor child : children) {
/* 296 */         if (child.hasConfigDataOption(ConfigData.Option.PROFILE_SPECIFIC)) {
/* 297 */           removed.add(child.withoutConfigDataOption(ConfigData.Option.PROFILE_SPECIFIC));
/*     */           continue;
/*     */         } 
/* 300 */         updatedChildren.add(child);
/*     */       } 
/*     */       
/* 303 */       contributor = contributor.withChildren(importPhase, updatedChildren);
/*     */     } 
/* 305 */     return contributor;
/*     */   }
/*     */   
/*     */   private boolean hasAnyProfileSpecificChildren(List<ConfigDataEnvironmentContributor> contributors) {
/* 309 */     if (CollectionUtils.isEmpty(contributors)) {
/* 310 */       return false;
/*     */     }
/* 312 */     for (ConfigDataEnvironmentContributor contributor : contributors) {
/* 313 */       for (ImportPhase importPhase : ImportPhase.values()) {
/* 314 */         if (contributor.getChildren(importPhase)
/* 315 */           .stream()
/* 316 */           .anyMatch(child -> child.hasConfigDataOption(ConfigData.Option.PROFILE_SPECIFIC))) {
/* 317 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 321 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataEnvironmentContributor withReplacement(ConfigDataEnvironmentContributor existing, ConfigDataEnvironmentContributor replacement) {
/* 333 */     if (this == existing) {
/* 334 */       return replacement;
/*     */     }
/*     */     
/* 337 */     Map<ImportPhase, List<ConfigDataEnvironmentContributor>> updatedChildren = new LinkedHashMap<>(this.children.size());
/* 338 */     this.children.forEach((importPhase, contributors) -> {
/*     */           List<ConfigDataEnvironmentContributor> updatedContributors = new ArrayList<>(contributors.size());
/*     */           for (ConfigDataEnvironmentContributor contributor : contributors) {
/*     */             updatedContributors.add(contributor.withReplacement(existing, replacement));
/*     */           }
/*     */           updatedChildren.put(importPhase, Collections.unmodifiableList(updatedContributors));
/*     */         });
/* 345 */     return new ConfigDataEnvironmentContributor(this.kind, this.location, this.resource, this.fromProfileSpecificImport, this.propertySource, this.configurationPropertySource, this.properties, this.configDataOptions, updatedChildren, this.conversionService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 352 */     StringBuilder builder = new StringBuilder();
/* 353 */     buildToString("", builder);
/* 354 */     return builder.toString();
/*     */   }
/*     */   
/*     */   private void buildToString(String prefix, StringBuilder builder) {
/* 358 */     builder.append(prefix);
/* 359 */     builder.append(this.kind);
/* 360 */     builder.append(" ");
/* 361 */     builder.append(this.location);
/* 362 */     builder.append(" ");
/* 363 */     builder.append(this.resource);
/* 364 */     builder.append(" ");
/* 365 */     builder.append(this.configDataOptions);
/* 366 */     builder.append("\n");
/* 367 */     for (ConfigDataEnvironmentContributor child : this.children.getOrDefault(ImportPhase.BEFORE_PROFILE_ACTIVATION, 
/* 368 */         Collections.emptyList())) {
/* 369 */       child.buildToString(prefix + "    ", builder);
/*     */     }
/* 371 */     for (ConfigDataEnvironmentContributor child : this.children.getOrDefault(ImportPhase.AFTER_PROFILE_ACTIVATION, 
/* 372 */         Collections.emptyList())) {
/* 373 */       child.buildToString(prefix + "    ", builder);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigDataEnvironmentContributor of(List<ConfigDataEnvironmentContributor> contributors, ConversionService conversionService) {
/* 385 */     Map<ImportPhase, List<ConfigDataEnvironmentContributor>> children = new LinkedHashMap<>();
/* 386 */     children.put(ImportPhase.BEFORE_PROFILE_ACTIVATION, Collections.unmodifiableList(contributors));
/* 387 */     return new ConfigDataEnvironmentContributor(Kind.ROOT, null, null, false, null, null, null, null, children, conversionService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigDataEnvironmentContributor ofInitialImport(ConfigDataLocation initialImport, ConversionService conversionService) {
/* 401 */     List<ConfigDataLocation> imports = Collections.singletonList(initialImport);
/* 402 */     ConfigDataProperties properties = new ConfigDataProperties(imports, null);
/* 403 */     return new ConfigDataEnvironmentContributor(Kind.INITIAL_IMPORT, null, null, false, null, null, properties, null, null, conversionService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigDataEnvironmentContributor ofExisting(PropertySource<?> propertySource, ConversionService conversionService) {
/* 417 */     return new ConfigDataEnvironmentContributor(Kind.EXISTING, null, null, false, propertySource, 
/* 418 */         asConfigurationPropertySource(propertySource), null, null, null, conversionService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigDataEnvironmentContributor ofUnboundImport(ConfigDataLocation location, ConfigDataResource resource, boolean profileSpecific, ConfigData configData, int propertySourceIndex, ConversionService conversionService, ConfigDataEnvironmentUpdateListener environmentUpdateListener) {
/* 437 */     PropertySource<?> propertySource = configData.getPropertySources().get(propertySourceIndex);
/* 438 */     ConfigData.Options options = configData.getOptions(propertySource);
/* 439 */     options = environmentUpdateListener.onConfigDataOptions(configData, propertySource, options);
/* 440 */     return new ConfigDataEnvironmentContributor(Kind.UNBOUND_IMPORT, location, resource, profileSpecific, propertySource, 
/* 441 */         asConfigurationPropertySource(propertySource), null, options, null, conversionService);
/*     */   }
/*     */   
/*     */   private static ConfigurationPropertySource asConfigurationPropertySource(PropertySource<?> propertySource) {
/* 445 */     ConfigurationPropertySource configurationPropertySource = ConfigurationPropertySource.from(propertySource);
/* 446 */     if (configurationPropertySource != null && propertySource instanceof OriginLookup) { OriginLookup<?> originLookup = (OriginLookup)propertySource;
/* 447 */       configurationPropertySource = configurationPropertySource.withPrefix(originLookup.getPrefix()); }
/*     */     
/* 449 */     return configurationPropertySource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigDataEnvironmentContributor ofEmptyLocation(ConfigDataLocation location, boolean profileSpecific, ConversionService conversionService) {
/* 461 */     return new ConfigDataEnvironmentContributor(Kind.EMPTY_LOCATION, location, null, profileSpecific, null, null, null, EMPTY_LOCATION_OPTIONS, null, conversionService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum Kind
/*     */   {
/* 473 */     ROOT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 478 */     INITIAL_IMPORT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 483 */     EXISTING,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 489 */     UNBOUND_IMPORT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 495 */     BOUND_IMPORT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 500 */     EMPTY_LOCATION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum ImportPhase
/*     */   {
/* 512 */     BEFORE_PROFILE_ACTIVATION,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 517 */     AFTER_PROFILE_ACTIVATION;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static ImportPhase get(ConfigDataActivationContext activationContext) {
/* 525 */       if (activationContext != null && activationContext.getProfiles() != null) {
/* 526 */         return AFTER_PROFILE_ACTIVATION;
/*     */       }
/* 528 */       return BEFORE_PROFILE_ACTIVATION;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class ContributorIterator
/*     */     implements Iterator<ConfigDataEnvironmentContributor>
/*     */   {
/*     */     private ConfigDataEnvironmentContributor.ImportPhase phase;
/*     */     
/*     */     private Iterator<ConfigDataEnvironmentContributor> children;
/*     */     
/*     */     private Iterator<ConfigDataEnvironmentContributor> current;
/*     */     
/*     */     private ConfigDataEnvironmentContributor next;
/*     */ 
/*     */     
/*     */     private ContributorIterator() {
/* 547 */       this.phase = ConfigDataEnvironmentContributor.ImportPhase.AFTER_PROFILE_ACTIVATION;
/* 548 */       this.children = ConfigDataEnvironmentContributor.this.getChildren(this.phase).iterator();
/* 549 */       this.current = Collections.emptyIterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 554 */       return (fetchIfNecessary() != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigDataEnvironmentContributor next() {
/* 559 */       ConfigDataEnvironmentContributor next = fetchIfNecessary();
/* 560 */       if (next == null) {
/* 561 */         throw new NoSuchElementException();
/*     */       }
/* 563 */       this.next = null;
/* 564 */       return next;
/*     */     }
/*     */     
/*     */     private ConfigDataEnvironmentContributor fetchIfNecessary() {
/* 568 */       if (this.next != null) {
/* 569 */         return this.next;
/*     */       }
/* 571 */       if (this.current.hasNext()) {
/* 572 */         this.next = this.current.next();
/* 573 */         return this.next;
/*     */       } 
/* 575 */       if (this.children.hasNext()) {
/* 576 */         this.current = ((ConfigDataEnvironmentContributor)this.children.next()).iterator();
/* 577 */         return fetchIfNecessary();
/*     */       } 
/* 579 */       if (this.phase == ConfigDataEnvironmentContributor.ImportPhase.AFTER_PROFILE_ACTIVATION) {
/* 580 */         this.phase = ConfigDataEnvironmentContributor.ImportPhase.BEFORE_PROFILE_ACTIVATION;
/* 581 */         this.children = ConfigDataEnvironmentContributor.this.getChildren(this.phase).iterator();
/* 582 */         return fetchIfNecessary();
/*     */       } 
/* 584 */       if (this.phase == ConfigDataEnvironmentContributor.ImportPhase.BEFORE_PROFILE_ACTIVATION) {
/* 585 */         this.phase = null;
/* 586 */         this.next = ConfigDataEnvironmentContributor.this;
/* 587 */         return this.next;
/*     */       } 
/* 589 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataEnvironmentContributor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */