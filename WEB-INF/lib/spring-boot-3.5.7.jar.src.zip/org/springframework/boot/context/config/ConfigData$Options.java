/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Options
/*     */ {
/* 178 */   public static final Options NONE = new Options(Collections.emptySet());
/*     */   
/*     */   private final Set<ConfigData.Option> options;
/*     */   
/*     */   private Options(Set<ConfigData.Option> options) {
/* 183 */     this.options = Collections.unmodifiableSet(options);
/*     */   }
/*     */   
/*     */   Set<ConfigData.Option> asSet() {
/* 187 */     return this.options;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(ConfigData.Option option) {
/* 196 */     return this.options.contains(option);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 201 */     if (this == obj) {
/* 202 */       return true;
/*     */     }
/* 204 */     if (obj == null || getClass() != obj.getClass()) {
/* 205 */       return false;
/*     */     }
/* 207 */     Options other = (Options)obj;
/* 208 */     return this.options.equals(other.options);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 213 */     return this.options.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 218 */     return this.options.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Options without(ConfigData.Option option) {
/* 228 */     return copy(options -> options.remove(option));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Options with(ConfigData.Option option) {
/* 238 */     return copy(options -> options.add(option));
/*     */   }
/*     */ 
/*     */   
/*     */   private Options copy(Consumer<EnumSet<ConfigData.Option>> processor) {
/* 243 */     EnumSet<ConfigData.Option> options = !this.options.isEmpty() ? EnumSet.<ConfigData.Option>copyOf(this.options) : EnumSet.<ConfigData.Option>noneOf(ConfigData.Option.class);
/* 244 */     processor.accept(options);
/* 245 */     return new Options(options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Options of(ConfigData.Option... options) {
/* 254 */     Assert.notNull(options, "'options' must not be null");
/* 255 */     if (options.length == 0) {
/* 256 */       return NONE;
/*     */     }
/* 258 */     return new Options(EnumSet.copyOf(Arrays.asList(options)));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigData$Options.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */