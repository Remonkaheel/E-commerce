/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedConfigDataLocationException
/*    */   extends ConfigDataException
/*    */ {
/*    */   private final ConfigDataLocation location;
/*    */   
/*    */   UnsupportedConfigDataLocationException(ConfigDataLocation location) {
/* 35 */     super("Unsupported config data location '" + String.valueOf(location) + "'", null);
/* 36 */     this.location = location;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigDataLocation getLocation() {
/* 44 */     return this.location;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\UnsupportedConfigDataLocationException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */