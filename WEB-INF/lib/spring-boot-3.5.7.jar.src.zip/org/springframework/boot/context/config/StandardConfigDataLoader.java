/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.origin.Origin;
/*    */ import org.springframework.boot.origin.OriginTrackedResource;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardConfigDataLoader
/*    */   implements ConfigDataLoader<StandardConfigDataResource>
/*    */ {
/* 38 */   private static final ConfigData.PropertySourceOptions PROFILE_SPECIFIC = ConfigData.PropertySourceOptions.always(new ConfigData.Option[] { ConfigData.Option.PROFILE_SPECIFIC });
/*    */   
/* 40 */   private static final ConfigData.PropertySourceOptions NON_PROFILE_SPECIFIC = ConfigData.PropertySourceOptions.ALWAYS_NONE;
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigData load(ConfigDataLoaderContext context, StandardConfigDataResource resource) throws IOException, ConfigDataNotFoundException {
/* 45 */     if (resource.isEmptyDirectory()) {
/* 46 */       return ConfigData.EMPTY;
/*    */     }
/* 48 */     ConfigDataResourceNotFoundException.throwIfDoesNotExist(resource, resource.getResource());
/* 49 */     StandardConfigDataReference reference = resource.getReference();
/* 50 */     OriginTrackedResource originTrackedResource = OriginTrackedResource.of(resource.getResource(), 
/* 51 */         Origin.from(reference.getConfigDataLocation()));
/* 52 */     String name = String.format("Config resource '%s' via location '%s'", new Object[] { resource, reference
/* 53 */           .getConfigDataLocation() });
/* 54 */     List<PropertySource<?>> propertySources = reference.getPropertySourceLoader().load(name, (Resource)originTrackedResource);
/* 55 */     ConfigData.PropertySourceOptions options = (resource.getProfile() != null) ? PROFILE_SPECIFIC : NON_PROFILE_SPECIFIC;
/* 56 */     return new ConfigData(propertySources, options);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\StandardConfigDataLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */