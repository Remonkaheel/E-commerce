/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import org.springframework.boot.ansi.AnsiOutput;
/*    */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*    */ import org.springframework.boot.context.properties.bind.Binder;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnsiOutputApplicationListener
/*    */   implements ApplicationListener<ApplicationEnvironmentPreparedEvent>, Ordered
/*    */ {
/*    */   public void onApplicationEvent(ApplicationEnvironmentPreparedEvent event) {
/* 42 */     ConfigurableEnvironment environment = event.getEnvironment();
/* 43 */     Binder.get((Environment)environment)
/* 44 */       .bind("spring.output.ansi.enabled", AnsiOutput.Enabled.class)
/* 45 */       .ifBound(AnsiOutput::setEnabled);
/* 46 */     AnsiOutput.setConsoleAvailable((Boolean)environment.getProperty("spring.output.ansi.console-available", Boolean.class));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 52 */     return -2147483637;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\AnsiOutputApplicationListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */