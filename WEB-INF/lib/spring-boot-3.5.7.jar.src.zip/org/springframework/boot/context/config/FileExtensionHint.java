/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FileExtensionHint
/*    */ {
/* 29 */   private static final Pattern PATTERN = Pattern.compile("^(.*)\\[(\\.\\w+)](?!\\[)$");
/*    */   
/* 31 */   private static final FileExtensionHint NONE = new FileExtensionHint(null);
/*    */   
/*    */   private final Matcher matcher;
/*    */   
/*    */   private FileExtensionHint(Matcher matcher) {
/* 36 */     this.matcher = matcher;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean isPresent() {
/* 44 */     return (this.matcher != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String orElse(String extension) {
/* 54 */     return (this.matcher != null) ? toString() : extension;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     return (this.matcher != null) ? this.matcher.group(2) : "";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static FileExtensionHint from(String value) {
/* 68 */     Matcher matcher = PATTERN.matcher(value);
/* 69 */     return matcher.matches() ? new FileExtensionHint(matcher) : NONE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static String removeFrom(String value) {
/* 78 */     Matcher matcher = PATTERN.matcher(value);
/* 79 */     return matcher.matches() ? matcher.group(1) : value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\FileExtensionHint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */