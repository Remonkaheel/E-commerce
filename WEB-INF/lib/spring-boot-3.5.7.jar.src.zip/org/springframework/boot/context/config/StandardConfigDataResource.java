/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardConfigDataResource
/*     */   extends ConfigDataResource
/*     */ {
/*     */   private final StandardConfigDataReference reference;
/*     */   private final Resource resource;
/*     */   private final boolean emptyDirectory;
/*     */   
/*     */   StandardConfigDataResource(StandardConfigDataReference reference, Resource resource) {
/*  49 */     this(reference, resource, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StandardConfigDataResource(StandardConfigDataReference reference, Resource resource, boolean emptyDirectory) {
/*  59 */     Assert.notNull(reference, "'reference' must not be null");
/*  60 */     Assert.notNull(resource, "'resource' must not be null");
/*  61 */     this.reference = reference;
/*  62 */     this.resource = resource;
/*  63 */     this.emptyDirectory = emptyDirectory;
/*     */   }
/*     */   
/*     */   StandardConfigDataReference getReference() {
/*  67 */     return this.reference;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Resource getResource() {
/*  76 */     return this.resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProfile() {
/*  85 */     return this.reference.getProfile();
/*     */   }
/*     */   
/*     */   boolean isEmptyDirectory() {
/*  89 */     return this.emptyDirectory;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  94 */     if (this == obj) {
/*  95 */       return true;
/*     */     }
/*  97 */     if (obj == null || getClass() != obj.getClass()) {
/*  98 */       return false;
/*     */     }
/* 100 */     StandardConfigDataResource other = (StandardConfigDataResource)obj;
/* 101 */     return (this.emptyDirectory == other.emptyDirectory && isSameUnderlyingResource(this.resource, other.resource));
/*     */   }
/*     */   
/*     */   private boolean isSameUnderlyingResource(Resource ours, Resource other) {
/* 105 */     return (ours.equals(other) || isSameFile(getUnderlyingFile(ours), getUnderlyingFile(other)));
/*     */   }
/*     */   
/*     */   private boolean isSameFile(File ours, File other) {
/* 109 */     return (ours != null && ours.equals(other));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 114 */     File underlyingFile = getUnderlyingFile(this.resource);
/* 115 */     return (underlyingFile != null) ? underlyingFile.hashCode() : this.resource.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 120 */     if (this.resource instanceof org.springframework.core.io.FileSystemResource || this.resource instanceof org.springframework.core.io.FileUrlResource) {
/*     */       try {
/* 122 */         return "file [" + String.valueOf(this.resource.getFile()) + "]";
/*     */       }
/* 124 */       catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */     
/* 128 */     return this.resource.toString();
/*     */   }
/*     */   
/*     */   private File getUnderlyingFile(Resource resource) {
/*     */     try {
/* 133 */       if (resource instanceof org.springframework.core.io.ClassPathResource || resource instanceof org.springframework.core.io.FileSystemResource || resource instanceof org.springframework.core.io.FileUrlResource)
/*     */       {
/* 135 */         return resource.getFile().getAbsoluteFile();
/*     */       }
/*     */     }
/* 138 */     catch (IOException iOException) {}
/*     */ 
/*     */     
/* 141 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\StandardConfigDataResource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */