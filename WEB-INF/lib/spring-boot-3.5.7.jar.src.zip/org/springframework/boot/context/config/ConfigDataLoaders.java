/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.boot.BootstrapContext;
/*     */ import org.springframework.boot.BootstrapRegistry;
/*     */ import org.springframework.boot.ConfigurableBootstrapContext;
/*     */ import org.springframework.boot.logging.DeferredLogFactory;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigDataLoaders
/*     */ {
/*     */   private final Log logger;
/*     */   private final List<ConfigDataLoader> loaders;
/*     */   private final List<Class<?>> resourceTypes;
/*     */   
/*     */   ConfigDataLoaders(DeferredLogFactory logFactory, ConfigurableBootstrapContext bootstrapContext, SpringFactoriesLoader springFactoriesLoader) {
/*  60 */     this.logger = logFactory.getLog(getClass());
/*  61 */     SpringFactoriesLoader.ArgumentResolver argumentResolver = SpringFactoriesLoader.ArgumentResolver.of(DeferredLogFactory.class, logFactory);
/*  62 */     argumentResolver = argumentResolver.and(ConfigurableBootstrapContext.class, bootstrapContext);
/*  63 */     argumentResolver = argumentResolver.and(BootstrapContext.class, bootstrapContext);
/*  64 */     argumentResolver = argumentResolver.and(BootstrapRegistry.class, bootstrapContext);
/*  65 */     argumentResolver = argumentResolver.andSupplied(Log.class, () -> {
/*     */           throw new IllegalArgumentException("Log types cannot be injected, please use DeferredLogFactory");
/*     */         });
/*  68 */     this.loaders = springFactoriesLoader.load(ConfigDataLoader.class, argumentResolver);
/*  69 */     this.resourceTypes = getResourceTypes(this.loaders);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Class<?>> getResourceTypes(List<ConfigDataLoader> loaders) {
/*  74 */     List<Class<?>> resourceTypes = new ArrayList<>(loaders.size());
/*  75 */     for (ConfigDataLoader<?> loader : loaders) {
/*  76 */       resourceTypes.add(getResourceType(loader));
/*     */     }
/*  78 */     return Collections.unmodifiableList(resourceTypes);
/*     */   }
/*     */   
/*     */   private Class<?> getResourceType(ConfigDataLoader<?> loader) {
/*  82 */     return ResolvableType.forClass(loader.getClass()).as(ConfigDataLoader.class).resolveGeneric(new int[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <R extends ConfigDataResource> ConfigData load(ConfigDataLoaderContext context, R resource) throws IOException {
/*  94 */     ConfigDataLoader<R> loader = getLoader(context, resource);
/*  95 */     this.logger.trace(LogMessage.of(() -> "Loading " + String.valueOf(resource) + " using loader " + loader.getClass().getName()));
/*  96 */     return loader.load(context, resource);
/*     */   }
/*     */ 
/*     */   
/*     */   private <R extends ConfigDataResource> ConfigDataLoader<R> getLoader(ConfigDataLoaderContext context, R resource) {
/* 101 */     ConfigDataLoader<R> result = null;
/* 102 */     for (int i = 0; i < this.loaders.size(); i++) {
/* 103 */       ConfigDataLoader<R> candidate = this.loaders.get(i);
/* 104 */       if (((Class)this.resourceTypes.get(i)).isInstance(resource) && 
/* 105 */         candidate.isLoadable(context, resource)) {
/* 106 */         if (result != null) {
/* 107 */           throw new IllegalStateException("Multiple loaders found for resource '" + String.valueOf(resource) + "' [" + candidate
/* 108 */               .getClass().getName() + "," + result.getClass().getName() + "]");
/*     */         }
/* 110 */         result = candidate;
/*     */       } 
/*     */     } 
/*     */     
/* 114 */     Assert.state((result != null), () -> "No loader found for resource '" + String.valueOf(resource) + "'");
/* 115 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataLoaders.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */