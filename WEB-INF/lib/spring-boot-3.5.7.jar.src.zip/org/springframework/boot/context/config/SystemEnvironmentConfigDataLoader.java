/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SystemEnvironmentConfigDataLoader
/*    */   implements ConfigDataLoader<SystemEnvironmentConfigDataResource>
/*    */ {
/*    */   public ConfigData load(ConfigDataLoaderContext context, SystemEnvironmentConfigDataResource resource) throws IOException, ConfigDataResourceNotFoundException {
/* 34 */     List<PropertySource<?>> loaded = resource.load();
/* 35 */     if (loaded == null) {
/* 36 */       throw new ConfigDataResourceNotFoundException(resource);
/*    */     }
/* 38 */     return new ConfigData(loaded, new ConfigData.Option[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\SystemEnvironmentConfigDataLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */