/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.boot.ConfigurableBootstrapContext;
/*     */ import org.springframework.boot.DefaultBootstrapContext;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.env.EnvironmentPostProcessor;
/*     */ import org.springframework.boot.logging.DeferredLogFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigDataEnvironmentPostProcessor
/*     */   implements EnvironmentPostProcessor, Ordered
/*     */ {
/*     */   public static final int ORDER = -2147483638;
/*     */   public static final String ON_LOCATION_NOT_FOUND_PROPERTY = "spring.config.on-not-found";
/*     */   private final DeferredLogFactory logFactory;
/*     */   private final Log logger;
/*     */   private final ConfigurableBootstrapContext bootstrapContext;
/*     */   private final ConfigDataEnvironmentUpdateListener environmentUpdateListener;
/*     */   
/*     */   public ConfigDataEnvironmentPostProcessor(DeferredLogFactory logFactory, ConfigurableBootstrapContext bootstrapContext) {
/*  70 */     this(logFactory, bootstrapContext, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ConfigDataEnvironmentPostProcessor(DeferredLogFactory logFactory, ConfigurableBootstrapContext bootstrapContext, ConfigDataEnvironmentUpdateListener environmentUpdateListener) {
/*  76 */     this.logFactory = logFactory;
/*  77 */     this.logger = logFactory.getLog(getClass());
/*  78 */     this.bootstrapContext = bootstrapContext;
/*  79 */     this.environmentUpdateListener = environmentUpdateListener;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  84 */     return -2147483638;
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
/*  89 */     postProcessEnvironment(environment, application.getResourceLoader(), application.getAdditionalProfiles());
/*     */   }
/*     */ 
/*     */   
/*     */   void postProcessEnvironment(ConfigurableEnvironment environment, ResourceLoader resourceLoader, Collection<String> additionalProfiles) {
/*  94 */     this.logger.trace("Post-processing environment to add config data");
/*  95 */     resourceLoader = (resourceLoader != null) ? resourceLoader : (ResourceLoader)new DefaultResourceLoader();
/*  96 */     getConfigDataEnvironment(environment, resourceLoader, additionalProfiles).processAndApply();
/*     */   }
/*     */ 
/*     */   
/*     */   ConfigDataEnvironment getConfigDataEnvironment(ConfigurableEnvironment environment, ResourceLoader resourceLoader, Collection<String> additionalProfiles) {
/* 101 */     return new ConfigDataEnvironment(this.logFactory, this.bootstrapContext, environment, resourceLoader, additionalProfiles, this.environmentUpdateListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void applyTo(ConfigurableEnvironment environment) {
/* 112 */     applyTo(environment, (ResourceLoader)null, (ConfigurableBootstrapContext)null, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void applyTo(ConfigurableEnvironment environment, ResourceLoader resourceLoader, ConfigurableBootstrapContext bootstrapContext, String... additionalProfiles) {
/* 127 */     applyTo(environment, resourceLoader, bootstrapContext, Arrays.asList(additionalProfiles));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void applyTo(ConfigurableEnvironment environment, ResourceLoader resourceLoader, ConfigurableBootstrapContext bootstrapContext, Collection<String> additionalProfiles) {
/* 142 */     DeferredLogFactory logFactory = Supplier::get;
/* 143 */     bootstrapContext = (bootstrapContext != null) ? bootstrapContext : (ConfigurableBootstrapContext)new DefaultBootstrapContext();
/* 144 */     ConfigDataEnvironmentPostProcessor postProcessor = new ConfigDataEnvironmentPostProcessor(logFactory, bootstrapContext);
/*     */     
/* 146 */     postProcessor.postProcessEnvironment(environment, resourceLoader, additionalProfiles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void applyTo(ConfigurableEnvironment environment, ResourceLoader resourceLoader, ConfigurableBootstrapContext bootstrapContext, Collection<String> additionalProfiles, ConfigDataEnvironmentUpdateListener environmentUpdateListener) {
/* 165 */     DeferredLogFactory logFactory = Supplier::get;
/* 166 */     bootstrapContext = (bootstrapContext != null) ? bootstrapContext : (ConfigurableBootstrapContext)new DefaultBootstrapContext();
/* 167 */     ConfigDataEnvironmentPostProcessor postProcessor = new ConfigDataEnvironmentPostProcessor(logFactory, bootstrapContext, environmentUpdateListener);
/*     */     
/* 169 */     postProcessor.postProcessEnvironment(environment, resourceLoader, additionalProfiles);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataEnvironmentPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */