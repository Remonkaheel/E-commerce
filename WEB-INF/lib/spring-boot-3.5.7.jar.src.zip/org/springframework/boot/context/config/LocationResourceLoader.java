/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LocationResourceLoader
/*     */ {
/*  43 */   private static final Resource[] EMPTY_RESOURCES = new Resource[0];
/*     */   
/*  45 */   private static final Comparator<File> FILE_PATH_COMPARATOR = Comparator.comparing(File::getAbsolutePath);
/*     */   
/*  47 */   private static final Comparator<File> FILE_NAME_COMPARATOR = Comparator.comparing(File::getName);
/*     */ 
/*     */ 
/*     */   
/*     */   private final ResourceLoader resourceLoader;
/*     */ 
/*     */ 
/*     */   
/*     */   LocationResourceLoader(ResourceLoader resourceLoader) {
/*  56 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isPattern(String location) {
/*  65 */     return (StringUtils.hasLength(location) && location.contains("*"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Resource getResource(String location) {
/*  75 */     validateNonPattern(location);
/*  76 */     location = StringUtils.cleanPath(location);
/*  77 */     if (!ResourceUtils.isUrl(location)) {
/*  78 */       location = "file:" + location;
/*     */     }
/*  80 */     return this.resourceLoader.getResource(location);
/*     */   }
/*     */   
/*     */   private void validateNonPattern(String location) {
/*  84 */     Assert.state(!isPattern(location), () -> String.format("Location '%s' must not be a pattern", new Object[] { location }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Resource[] getResources(String location, ResourceType type) {
/*  95 */     validatePattern(location, type);
/*  96 */     String directoryPath = location.substring(0, location.indexOf("*/"));
/*  97 */     String fileName = location.substring(location.lastIndexOf("/") + 1);
/*  98 */     Resource resource = getResource(directoryPath);
/*  99 */     if (!resource.exists()) {
/* 100 */       return EMPTY_RESOURCES;
/*     */     }
/* 102 */     File file = getFile(location, resource);
/* 103 */     if (!file.isDirectory()) {
/* 104 */       return EMPTY_RESOURCES;
/*     */     }
/* 106 */     File[] subDirectories = file.listFiles(this::isVisibleDirectory);
/* 107 */     if (subDirectories == null) {
/* 108 */       return EMPTY_RESOURCES;
/*     */     }
/* 110 */     Arrays.sort(subDirectories, FILE_PATH_COMPARATOR);
/* 111 */     if (type == ResourceType.DIRECTORY) {
/* 112 */       return (Resource[])Arrays.<File>stream(subDirectories).map(org.springframework.core.io.FileSystemResource::new).toArray(x$0 -> new Resource[x$0]);
/*     */     }
/* 114 */     List<Resource> resources = new ArrayList<>();
/* 115 */     FilenameFilter filter = (dir, name) -> name.equals(fileName);
/* 116 */     for (File subDirectory : subDirectories) {
/* 117 */       File[] files = subDirectory.listFiles(filter);
/* 118 */       if (files != null) {
/* 119 */         Arrays.sort(files, FILE_NAME_COMPARATOR);
/* 120 */         Objects.requireNonNull(resources); Arrays.<File>stream(files).map(org.springframework.core.io.FileSystemResource::new).forEach(resources::add);
/*     */       } 
/*     */     } 
/* 123 */     return resources.<Resource>toArray(EMPTY_RESOURCES);
/*     */   }
/*     */   
/*     */   private void validatePattern(String location, ResourceType type) {
/* 127 */     Assert.state(isPattern(location), () -> String.format("Location '%s' must be a pattern", new Object[] { location }));
/* 128 */     Assert.state(!location.startsWith("classpath*:"), () -> String.format("Location '%s' cannot use classpath wildcards", new Object[] { location }));
/*     */     
/* 130 */     Assert.state((StringUtils.countOccurrencesOf(location, "*") == 1), () -> String.format("Location '%s' cannot contain multiple wildcards", new Object[] { location }));
/*     */ 
/*     */     
/* 133 */     String directoryPath = (type != ResourceType.DIRECTORY) ? location.substring(0, location.lastIndexOf("/") + 1) : location;
/* 134 */     Assert.state(directoryPath.endsWith("*/"), () -> String.format("Location '%s' must end with '*/'", new Object[] { location }));
/*     */   }
/*     */   
/*     */   private File getFile(String patternLocation, Resource resource) {
/*     */     try {
/* 139 */       return resource.getFile();
/*     */     }
/* 141 */     catch (Exception ex) {
/* 142 */       throw new IllegalStateException("Unable to load config data resource from pattern '" + patternLocation + "'", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isVisibleDirectory(File file) {
/* 148 */     return (file.isDirectory() && !file.getName().startsWith(".."));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum ResourceType
/*     */   {
/* 159 */     FILE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 164 */     DIRECTORY;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\LocationResourceLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */