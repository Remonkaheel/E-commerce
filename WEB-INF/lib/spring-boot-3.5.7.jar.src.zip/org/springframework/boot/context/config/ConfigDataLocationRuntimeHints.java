/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.aot.hint.support.FilePatternResourceHintsRegistrar;
/*     */ import org.springframework.boot.env.PropertySourceLoader;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigDataLocationRuntimeHints
/*     */   implements RuntimeHintsRegistrar
/*     */ {
/*  41 */   private static final Log logger = LogFactory.getLog(ConfigDataLocationRuntimeHints.class);
/*     */ 
/*     */   
/*     */   public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/*  45 */     List<String> fileNames = getFileNames(classLoader);
/*  46 */     List<String> locations = getLocations(classLoader);
/*  47 */     List<String> extensions = getExtensions(classLoader);
/*  48 */     if (logger.isDebugEnabled()) {
/*  49 */       logger.debug("Registering application configuration hints for " + String.valueOf(fileNames) + "(" + String.valueOf(extensions) + ") at " + String.valueOf(locations));
/*     */     }
/*     */     
/*  52 */     FilePatternResourceHintsRegistrar.forClassPathLocations(locations)
/*  53 */       .withFilePrefixes(fileNames)
/*  54 */       .withFileExtensions(extensions)
/*  55 */       .registerHints(hints.resources(), classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> getFileNames(ClassLoader classLoader) {
/*  64 */     return Arrays.asList(StandardConfigDataLocationResolver.DEFAULT_CONFIG_NAMES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> getLocations(ClassLoader classLoader) {
/*  74 */     List<String> classpathLocations = new ArrayList<>();
/*  75 */     for (ConfigDataLocation candidate : ConfigDataEnvironment.DEFAULT_SEARCH_LOCATIONS) {
/*  76 */       for (ConfigDataLocation configDataLocation : candidate.split()) {
/*  77 */         String location = configDataLocation.getValue();
/*  78 */         if (location.startsWith("classpath:")) {
/*  79 */           classpathLocations.add(location);
/*     */         }
/*     */       } 
/*     */     } 
/*  83 */     return classpathLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> getExtensions(ClassLoader classLoader) {
/*  93 */     List<String> extensions = new ArrayList<>();
/*     */     
/*  95 */     List<PropertySourceLoader> propertySourceLoaders = getSpringFactoriesLoader(classLoader).load(PropertySourceLoader.class);
/*  96 */     for (PropertySourceLoader propertySourceLoader : propertySourceLoaders) {
/*  97 */       for (String fileExtension : propertySourceLoader.getFileExtensions()) {
/*  98 */         String candidate = "." + fileExtension;
/*  99 */         if (!extensions.contains(candidate)) {
/* 100 */           extensions.add(candidate);
/*     */         }
/*     */       } 
/*     */     } 
/* 104 */     return extensions;
/*     */   }
/*     */   
/*     */   protected SpringFactoriesLoader getSpringFactoriesLoader(ClassLoader classLoader) {
/* 108 */     return SpringFactoriesLoader.forDefaultResourceLocation(classLoader);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataLocationRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */