/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import java.util.function.Supplier;
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.boot.context.properties.bind.BindContext;
/*    */ import org.springframework.boot.context.properties.bind.BindHandler;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.bind.Binder;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ProfilesValidator
/*    */   implements BindHandler
/*    */ {
/*    */   private static final String ALLOWED_CHARS = "-_.+@";
/*    */   private final boolean validate;
/*    */   
/*    */   private ProfilesValidator(boolean validate) {
/* 46 */     this.validate = validate;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object onSuccess(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) {
/* 51 */     validate(result);
/* 52 */     return result;
/*    */   }
/*    */   
/*    */   void validate(Object value, Supplier<String> wrappedExceptionMessage) {
/*    */     try {
/* 57 */       validate(value);
/*    */     }
/* 59 */     catch (IllegalStateException ex) {
/* 60 */       throw new IllegalStateException((String)wrappedExceptionMessage.get(), ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void validate(Object value) {
/* 65 */     if (!this.validate) {
/*    */       return;
/*    */     }
/* 68 */     if (value instanceof Collection) { Collection<?> list = (Collection)value;
/* 69 */       list.forEach(this::validate);
/*    */       return; }
/*    */     
/* 72 */     if (value instanceof Map) { Map<?, ?> map = (Map<?, ?>)value;
/* 73 */       map.forEach((k, v) -> validate(v));
/*    */       return; }
/*    */     
/* 76 */     String profile = (value != null) ? value.toString() : null;
/* 77 */     Assert.state(StringUtils.hasText(profile), "Invalid empty profile");
/* 78 */     for (int i = 0; i < profile.length(); i++) {
/* 79 */       int codePoint = profile.codePointAt(i);
/* 80 */       boolean isAllowedChar = ("-_.+@".indexOf(codePoint) != -1);
/* 81 */       Assert.state((isAllowedChar || Character.isLetterOrDigit(codePoint)), () -> "Profile '%s' must contain a letter, digit or allowed char (%s)".formatted(new Object[] { profile, Arrays.<CharSequence>stream((CharSequence[])"-_.+@".split("")).collect(Collectors.joining("', '", "'", "'")) }));
/*    */ 
/*    */       
/* 84 */       Assert.state(((i > 0 && i < profile.length() - 1) || Character.isLetterOrDigit(codePoint)), () -> "Profile '%s' must start and end with a letter or digit".formatted(new Object[] { profile }));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static ProfilesValidator get(Binder binder) {
/* 91 */     return new ProfilesValidator(((Boolean)binder.bind("spring.profiles.validate", Boolean.class).orElse(Boolean.valueOf(true))).booleanValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ProfilesValidator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */