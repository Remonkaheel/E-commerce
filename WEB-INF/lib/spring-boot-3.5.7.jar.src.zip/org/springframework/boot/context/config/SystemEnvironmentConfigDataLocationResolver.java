/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.boot.env.PropertySourceLoader;
/*    */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SystemEnvironmentConfigDataLocationResolver
/*    */   implements ConfigDataLocationResolver<SystemEnvironmentConfigDataResource>
/*    */ {
/*    */   private static final String PREFIX = "env:";
/*    */   private static final String DEFAULT_EXTENSION = ".properties";
/*    */   private final List<PropertySourceLoader> loaders;
/*    */   private final Function<String, String> environment;
/*    */   
/*    */   SystemEnvironmentConfigDataLocationResolver() {
/* 44 */     this.loaders = SpringFactoriesLoader.loadFactories(PropertySourceLoader.class, getClass().getClassLoader());
/* 45 */     this.environment = System::getenv;
/*    */   }
/*    */ 
/*    */   
/*    */   SystemEnvironmentConfigDataLocationResolver(List<PropertySourceLoader> loaders, Function<String, String> environment) {
/* 50 */     this.loaders = loaders;
/* 51 */     this.environment = environment;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isResolvable(ConfigDataLocationResolverContext context, ConfigDataLocation location) {
/* 56 */     return location.hasPrefix("env:");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<SystemEnvironmentConfigDataResource> resolve(ConfigDataLocationResolverContext context, ConfigDataLocation location) throws ConfigDataLocationNotFoundException, ConfigDataResourceNotFoundException {
/* 63 */     String value = location.getNonPrefixedValue("env:");
/* 64 */     FileExtensionHint fileExtensionHint = FileExtensionHint.from(value);
/* 65 */     String variableName = FileExtensionHint.removeFrom(value);
/* 66 */     PropertySourceLoader loader = getLoader(fileExtensionHint.orElse(".properties"));
/* 67 */     if (hasEnvVariable(variableName)) {
/* 68 */       return List.of(new SystemEnvironmentConfigDataResource(variableName, loader, this.environment));
/*    */     }
/* 70 */     if (location.isOptional()) {
/* 71 */       return Collections.emptyList();
/*    */     }
/* 73 */     throw new ConfigDataLocationNotFoundException(location, "Environment variable '%s' is not set"
/* 74 */         .formatted(new Object[] { variableName }, ), null);
/*    */   }
/*    */   
/*    */   private PropertySourceLoader getLoader(String extension) {
/* 78 */     extension = !extension.startsWith(".") ? extension : extension.substring(1);
/* 79 */     for (PropertySourceLoader loader : this.loaders) {
/* 80 */       for (String supportedExtension : loader.getFileExtensions()) {
/* 81 */         if (supportedExtension.equalsIgnoreCase(extension)) {
/* 82 */           return loader;
/*    */         }
/*    */       } 
/*    */     } 
/* 86 */     throw new IllegalStateException("File extension '%s' is not known to any PropertySourceLoader"
/* 87 */         .formatted(new Object[] { extension }));
/*    */   }
/*    */   
/*    */   private boolean hasEnvVariable(String variableName) {
/* 91 */     return (this.environment.apply(variableName) != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\SystemEnvironmentConfigDataLocationResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */