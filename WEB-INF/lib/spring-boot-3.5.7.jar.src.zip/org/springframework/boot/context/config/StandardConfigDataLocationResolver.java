/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.env.PropertySourceLoader;
/*     */ import org.springframework.boot.logging.DeferredLogFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardConfigDataLocationResolver
/*     */   implements ConfigDataLocationResolver<StandardConfigDataResource>, Ordered
/*     */ {
/*     */   private static final String PREFIX = "resource:";
/*     */   static final String CONFIG_NAME_PROPERTY = "spring.config.name";
/*  66 */   static final String[] DEFAULT_CONFIG_NAMES = new String[] { "application" };
/*     */   
/*  68 */   private static final Pattern URL_PREFIX = Pattern.compile("^([a-zA-Z][a-zA-Z0-9*]*?:)(.*$)");
/*     */   
/*  70 */   private static final String NO_PROFILE = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Log logger;
/*     */ 
/*     */   
/*     */   private final List<PropertySourceLoader> propertySourceLoaders;
/*     */ 
/*     */   
/*     */   private final String[] configNames;
/*     */ 
/*     */   
/*     */   private final LocationResourceLoader resourceLoader;
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardConfigDataLocationResolver(DeferredLogFactory logFactory, Binder binder, ResourceLoader resourceLoader) {
/*  88 */     this.logger = logFactory.getLog(StandardConfigDataLocationResolver.class);
/*  89 */     this.propertySourceLoaders = SpringFactoriesLoader.loadFactories(PropertySourceLoader.class, resourceLoader
/*  90 */         .getClassLoader());
/*  91 */     this.configNames = getConfigNames(binder);
/*  92 */     this.resourceLoader = new LocationResourceLoader(resourceLoader);
/*     */   }
/*     */   
/*     */   private String[] getConfigNames(Binder binder) {
/*  96 */     String[] configNames = (String[])binder.bind("spring.config.name", String[].class).orElse(DEFAULT_CONFIG_NAMES);
/*  97 */     for (String configName : configNames) {
/*  98 */       validateConfigName(configName);
/*     */     }
/* 100 */     return configNames;
/*     */   }
/*     */   
/*     */   private void validateConfigName(String name) {
/* 104 */     Assert.state(!name.contains("*"), () -> "Config name '" + name + "' cannot contain '*'");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 109 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isResolvable(ConfigDataLocationResolverContext context, ConfigDataLocation location) {
/* 114 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<StandardConfigDataResource> resolve(ConfigDataLocationResolverContext context, ConfigDataLocation location) throws ConfigDataNotFoundException {
/* 120 */     return resolve(getReferences(context, location.split()));
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<StandardConfigDataReference> getReferences(ConfigDataLocationResolverContext context, ConfigDataLocation[] configDataLocations) {
/* 125 */     Set<StandardConfigDataReference> references = new LinkedHashSet<>();
/* 126 */     for (ConfigDataLocation configDataLocation : configDataLocations) {
/* 127 */       references.addAll(getReferences(context, configDataLocation));
/*     */     }
/* 129 */     return references;
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<StandardConfigDataReference> getReferences(ConfigDataLocationResolverContext context, ConfigDataLocation configDataLocation) {
/* 134 */     String resourceLocation = getResourceLocation(context, configDataLocation);
/*     */     try {
/* 136 */       if (isDirectory(resourceLocation)) {
/* 137 */         return getReferencesForDirectory(configDataLocation, resourceLocation, NO_PROFILE);
/*     */       }
/* 139 */       return getReferencesForFile(configDataLocation, resourceLocation, NO_PROFILE);
/*     */     }
/* 141 */     catch (RuntimeException ex) {
/* 142 */       throw new IllegalStateException("Unable to load config data from '" + String.valueOf(configDataLocation) + "'", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<StandardConfigDataResource> resolveProfileSpecific(ConfigDataLocationResolverContext context, ConfigDataLocation location, Profiles profiles) {
/* 149 */     return resolve(getProfileSpecificReferences(context, location.split(), profiles));
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<StandardConfigDataReference> getProfileSpecificReferences(ConfigDataLocationResolverContext context, ConfigDataLocation[] configDataLocations, Profiles profiles) {
/* 154 */     Set<StandardConfigDataReference> references = new LinkedHashSet<>();
/* 155 */     for (String profile : profiles) {
/* 156 */       for (ConfigDataLocation configDataLocation : configDataLocations) {
/* 157 */         String resourceLocation = getResourceLocation(context, configDataLocation);
/* 158 */         references.addAll(getReferences(configDataLocation, resourceLocation, profile));
/*     */       } 
/*     */     } 
/* 161 */     return references;
/*     */   }
/*     */ 
/*     */   
/*     */   private String getResourceLocation(ConfigDataLocationResolverContext context, ConfigDataLocation configDataLocation) {
/* 166 */     String resourceLocation = configDataLocation.getNonPrefixedValue("resource:");
/* 167 */     boolean isFixedPath = (resourceLocation.startsWith("/") || URL_PREFIX.matcher(resourceLocation).matches());
/* 168 */     if (isFixedPath) {
/* 169 */       return resourceLocation;
/*     */     }
/* 171 */     ConfigDataResource parent = context.getParent();
/* 172 */     if (parent instanceof StandardConfigDataResource) { StandardConfigDataResource resource = (StandardConfigDataResource)parent;
/* 173 */       String parentResourceLocation = resource.getReference().getResourceLocation();
/* 174 */       String parentDirectory = parentResourceLocation.substring(0, parentResourceLocation.lastIndexOf("/") + 1);
/* 175 */       return parentDirectory + parentDirectory; }
/*     */     
/* 177 */     return resourceLocation;
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<StandardConfigDataReference> getReferences(ConfigDataLocation configDataLocation, String resourceLocation, String profile) {
/* 182 */     if (isDirectory(resourceLocation)) {
/* 183 */       return getReferencesForDirectory(configDataLocation, resourceLocation, profile);
/*     */     }
/* 185 */     return getReferencesForFile(configDataLocation, resourceLocation, profile);
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<StandardConfigDataReference> getReferencesForDirectory(ConfigDataLocation configDataLocation, String directory, String profile) {
/* 190 */     Set<StandardConfigDataReference> references = new LinkedHashSet<>();
/* 191 */     for (String name : this.configNames) {
/* 192 */       Deque<StandardConfigDataReference> referencesForName = getReferencesForConfigName(name, configDataLocation, directory, profile);
/*     */       
/* 194 */       references.addAll(referencesForName);
/*     */     } 
/* 196 */     return references;
/*     */   }
/*     */ 
/*     */   
/*     */   private Deque<StandardConfigDataReference> getReferencesForConfigName(String name, ConfigDataLocation configDataLocation, String directory, String profile) {
/* 201 */     Deque<StandardConfigDataReference> references = new ArrayDeque<>();
/* 202 */     for (PropertySourceLoader propertySourceLoader : this.propertySourceLoaders) {
/* 203 */       for (String extension : propertySourceLoader.getFileExtensions()) {
/* 204 */         StandardConfigDataReference reference = new StandardConfigDataReference(configDataLocation, directory, directory + directory, profile, extension, propertySourceLoader);
/*     */         
/* 206 */         if (!references.contains(reference)) {
/* 207 */           references.addFirst(reference);
/*     */         }
/*     */       } 
/*     */     } 
/* 211 */     return references;
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<StandardConfigDataReference> getReferencesForFile(ConfigDataLocation configDataLocation, String file, String profile) {
/* 216 */     FileExtensionHint fileExtensionHint = FileExtensionHint.from(file);
/* 217 */     if (fileExtensionHint.isPresent()) {
/* 218 */       file = FileExtensionHint.removeFrom(file) + FileExtensionHint.removeFrom(file);
/*     */     }
/* 220 */     for (PropertySourceLoader propertySourceLoader : this.propertySourceLoaders) {
/* 221 */       String fileExtension = getLoadableFileExtension(propertySourceLoader, file);
/* 222 */       if (fileExtension != null) {
/* 223 */         String root = file.substring(0, file.length() - fileExtension.length() - 1);
/*     */         
/* 225 */         StandardConfigDataReference reference = new StandardConfigDataReference(configDataLocation, null, root, profile, !fileExtensionHint.isPresent() ? fileExtension : null, propertySourceLoader);
/* 226 */         return Collections.singleton(reference);
/*     */       } 
/*     */     } 
/* 229 */     if (configDataLocation.isOptional()) {
/* 230 */       return Collections.emptySet();
/*     */     }
/* 232 */     if (configDataLocation.hasPrefix("resource:") || configDataLocation.hasPrefix("file:") || configDataLocation
/* 233 */       .hasPrefix("classpath:") || configDataLocation
/* 234 */       .toString().indexOf(':') == -1) {
/* 235 */       throw new IllegalStateException("File extension is not known to any PropertySourceLoader. If the location is meant to reference a directory, it must end in '/' or File.separator");
/*     */     }
/*     */     
/* 238 */     throw new IllegalStateException("Incorrect ConfigDataLocationResolver chosen or file extension is not known to any PropertySourceLoader. If the location is meant to reference a directory, it must end in '/' or File.separator. The location is being resolved using the StandardConfigDataLocationResolver, check the location prefix if a different resolver is expected");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getLoadableFileExtension(PropertySourceLoader loader, String file) {
/* 246 */     for (String fileExtension : loader.getFileExtensions()) {
/* 247 */       if (StringUtils.endsWithIgnoreCase(file, fileExtension)) {
/* 248 */         return fileExtension;
/*     */       }
/*     */     } 
/* 251 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isDirectory(String resourceLocation) {
/* 255 */     return (resourceLocation.endsWith("/") || resourceLocation.endsWith(File.separator));
/*     */   }
/*     */   
/*     */   private List<StandardConfigDataResource> resolve(Set<StandardConfigDataReference> references) {
/* 259 */     List<StandardConfigDataResource> resolved = new ArrayList<>();
/* 260 */     for (StandardConfigDataReference reference : references) {
/* 261 */       resolved.addAll(resolve(reference));
/*     */     }
/* 263 */     if (resolved.isEmpty()) {
/* 264 */       resolved.addAll(resolveEmptyDirectories(references));
/*     */     }
/* 266 */     return resolved;
/*     */   }
/*     */ 
/*     */   
/*     */   private Collection<StandardConfigDataResource> resolveEmptyDirectories(Set<StandardConfigDataReference> references) {
/* 271 */     Set<StandardConfigDataResource> empty = new LinkedHashSet<>();
/* 272 */     for (StandardConfigDataReference reference : references) {
/* 273 */       if (reference.getDirectory() != null) {
/* 274 */         empty.addAll(resolveEmptyDirectories(reference));
/*     */       }
/*     */     } 
/* 277 */     return empty;
/*     */   }
/*     */   
/*     */   private Set<StandardConfigDataResource> resolveEmptyDirectories(StandardConfigDataReference reference) {
/* 281 */     if (!this.resourceLoader.isPattern(reference.getResourceLocation())) {
/* 282 */       return resolveNonPatternEmptyDirectories(reference);
/*     */     }
/* 284 */     return resolvePatternEmptyDirectories(reference);
/*     */   }
/*     */   
/*     */   private Set<StandardConfigDataResource> resolveNonPatternEmptyDirectories(StandardConfigDataReference reference) {
/* 288 */     Resource resource = this.resourceLoader.getResource(reference.getDirectory());
/* 289 */     return (resource instanceof org.springframework.core.io.ClassPathResource || !resource.exists()) ? Collections.<StandardConfigDataResource>emptySet() : 
/* 290 */       Collections.<StandardConfigDataResource>singleton(new StandardConfigDataResource(reference, resource, true));
/*     */   }
/*     */   
/*     */   private Set<StandardConfigDataResource> resolvePatternEmptyDirectories(StandardConfigDataReference reference) {
/* 294 */     Resource[] subdirectories = this.resourceLoader.getResources(reference.getDirectory(), LocationResourceLoader.ResourceType.DIRECTORY);
/* 295 */     ConfigDataLocation location = reference.getConfigDataLocation();
/* 296 */     if (!location.isOptional() && ObjectUtils.isEmpty((Object[])subdirectories)) {
/* 297 */       String message = String.format("Config data location '%s' contains no subdirectories", new Object[] { location });
/* 298 */       throw new ConfigDataLocationNotFoundException(location, message, null);
/*     */     } 
/* 300 */     return (Set<StandardConfigDataResource>)Arrays.<Resource>stream(subdirectories)
/* 301 */       .filter(Resource::exists)
/* 302 */       .map(resource -> new StandardConfigDataResource(reference, resource, true))
/* 303 */       .collect(Collectors.toCollection(LinkedHashSet::new));
/*     */   }
/*     */   
/*     */   private List<StandardConfigDataResource> resolve(StandardConfigDataReference reference) {
/* 307 */     if (!this.resourceLoader.isPattern(reference.getResourceLocation())) {
/* 308 */       return resolveNonPattern(reference);
/*     */     }
/* 310 */     return resolvePattern(reference);
/*     */   }
/*     */   
/*     */   private List<StandardConfigDataResource> resolveNonPattern(StandardConfigDataReference reference) {
/* 314 */     Resource resource = this.resourceLoader.getResource(reference.getResourceLocation());
/* 315 */     if (!resource.exists() && reference.isSkippable()) {
/* 316 */       logSkippingResource(reference);
/* 317 */       return Collections.emptyList();
/*     */     } 
/* 319 */     return Collections.singletonList(createConfigResourceLocation(reference, resource));
/*     */   }
/*     */   
/*     */   private List<StandardConfigDataResource> resolvePattern(StandardConfigDataReference reference) {
/* 323 */     List<StandardConfigDataResource> resolved = new ArrayList<>();
/* 324 */     for (Resource resource : this.resourceLoader.getResources(reference.getResourceLocation(), LocationResourceLoader.ResourceType.FILE)) {
/* 325 */       if (!resource.exists() && reference.isSkippable()) {
/* 326 */         logSkippingResource(reference);
/*     */       } else {
/*     */         
/* 329 */         resolved.add(createConfigResourceLocation(reference, resource));
/*     */       } 
/*     */     } 
/* 332 */     return resolved;
/*     */   }
/*     */   
/*     */   private void logSkippingResource(StandardConfigDataReference reference) {
/* 336 */     this.logger.trace(LogMessage.format("Skipping missing resource %s", reference));
/*     */   }
/*     */ 
/*     */   
/*     */   private StandardConfigDataResource createConfigResourceLocation(StandardConfigDataReference reference, Resource resource) {
/* 341 */     return new StandardConfigDataResource(reference, resource);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\StandardConfigDataLocationResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */