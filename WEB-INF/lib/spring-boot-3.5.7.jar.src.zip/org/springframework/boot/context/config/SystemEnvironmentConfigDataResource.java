/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.boot.env.PropertySourceLoader;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ import org.springframework.core.io.ByteArrayResource;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SystemEnvironmentConfigDataResource
/*    */   extends ConfigDataResource
/*    */ {
/*    */   private final String variableName;
/*    */   private final PropertySourceLoader loader;
/*    */   private final Function<String, String> environment;
/*    */   
/*    */   SystemEnvironmentConfigDataResource(String variableName, PropertySourceLoader loader, Function<String, String> environment) {
/* 46 */     this.variableName = variableName;
/* 47 */     this.loader = loader;
/* 48 */     this.environment = environment;
/*    */   }
/*    */   
/*    */   String getVariableName() {
/* 52 */     return this.variableName;
/*    */   }
/*    */   
/*    */   PropertySourceLoader getLoader() {
/* 56 */     return this.loader;
/*    */   }
/*    */   
/*    */   List<PropertySource<?>> load() throws IOException {
/* 60 */     String content = this.environment.apply(this.variableName);
/* 61 */     return (content != null) ? this.loader.load(StringUtils.capitalize(toString()), (Resource)asResource(content)) : null;
/*    */   }
/*    */   
/*    */   private ByteArrayResource asResource(String content) {
/* 65 */     return new ByteArrayResource(content.getBytes(StandardCharsets.UTF_8));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 70 */     if (this == obj) {
/* 71 */       return true;
/*    */     }
/* 73 */     if (obj == null || getClass() != obj.getClass()) {
/* 74 */       return false;
/*    */     }
/* 76 */     SystemEnvironmentConfigDataResource other = (SystemEnvironmentConfigDataResource)obj;
/* 77 */     return (Objects.equals(this.loader.getClass(), other.loader.getClass()) && 
/* 78 */       Objects.equals(this.variableName, other.variableName));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 83 */     return Objects.hash(new Object[] { this.variableName, this.loader.getClass() });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 88 */     return "system environment variable [" + this.variableName + "] content loaded using " + 
/* 89 */       ClassUtils.getShortName(this.loader.getClass());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\SystemEnvironmentConfigDataResource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */