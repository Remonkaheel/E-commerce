/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ConfigDataResource
/*    */ {
/*    */   private final boolean optional;
/*    */   
/*    */   public ConfigDataResource() {
/* 36 */     this(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ConfigDataResource(boolean optional) {
/* 45 */     this.optional = optional;
/*    */   }
/*    */   
/*    */   boolean isOptional() {
/* 49 */     return this.optional;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataResource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */