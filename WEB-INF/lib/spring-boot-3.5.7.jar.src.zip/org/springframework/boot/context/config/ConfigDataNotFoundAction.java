/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ConfigDataNotFoundAction
/*    */ {
/* 34 */   FAIL
/*    */   {
/*    */     void handle(Log logger, ConfigDataNotFoundException ex)
/*    */     {
/* 38 */       throw ex;
/*    */     }
/*    */   },
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   IGNORE
/*    */   {
/*    */     void handle(Log logger, ConfigDataNotFoundException ex)
/*    */     {
/* 50 */       logger.trace(LogMessage.format("Ignoring missing config data %s", ex.getReferenceDescription()));
/*    */     }
/*    */   };
/*    */   
/*    */   abstract void handle(Log paramLog, ConfigDataNotFoundException paramConfigDataNotFoundException);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataNotFoundAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */