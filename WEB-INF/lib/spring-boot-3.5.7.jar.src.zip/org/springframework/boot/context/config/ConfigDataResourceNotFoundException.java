/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigDataResourceNotFoundException
/*     */   extends ConfigDataNotFoundException
/*     */ {
/*     */   private final ConfigDataResource resource;
/*     */   private final ConfigDataLocation location;
/*     */   
/*     */   public ConfigDataResourceNotFoundException(ConfigDataResource resource) {
/*  45 */     this(resource, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigDataResourceNotFoundException(ConfigDataResource resource, Throwable cause) {
/*  54 */     this(resource, null, cause);
/*     */   }
/*     */ 
/*     */   
/*     */   private ConfigDataResourceNotFoundException(ConfigDataResource resource, ConfigDataLocation location, Throwable cause) {
/*  59 */     super(getMessage(resource, location), cause);
/*  60 */     Assert.notNull(resource, "'resource' must not be null");
/*  61 */     this.resource = resource;
/*  62 */     this.location = location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigDataResource getResource() {
/*  70 */     return this.resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigDataLocation getLocation() {
/*  78 */     return this.location;
/*     */   }
/*     */ 
/*     */   
/*     */   public Origin getOrigin() {
/*  83 */     return Origin.from(this.location);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getReferenceDescription() {
/*  88 */     return getReferenceDescription(this.resource, this.location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataResourceNotFoundException withLocation(ConfigDataLocation location) {
/*  97 */     return new ConfigDataResourceNotFoundException(this.resource, location, getCause());
/*     */   }
/*     */   
/*     */   private static String getMessage(ConfigDataResource resource, ConfigDataLocation location) {
/* 101 */     return String.format("Config data %s cannot be found", new Object[] { getReferenceDescription(resource, location) });
/*     */   }
/*     */   
/*     */   private static String getReferenceDescription(ConfigDataResource resource, ConfigDataLocation location) {
/* 105 */     String description = String.format("resource '%s'", new Object[] { resource });
/* 106 */     if (location != null) {
/* 107 */       description = description + description;
/*     */     }
/* 109 */     return description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void throwIfDoesNotExist(ConfigDataResource resource, Path pathToCheck) {
/* 119 */     throwIfNot(resource, Files.exists(pathToCheck, new java.nio.file.LinkOption[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void throwIfDoesNotExist(ConfigDataResource resource, File fileToCheck) {
/* 129 */     throwIfNot(resource, fileToCheck.exists());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void throwIfDoesNotExist(ConfigDataResource resource, Resource resourceToCheck) {
/* 139 */     throwIfNot(resource, resourceToCheck.exists());
/*     */   }
/*     */   
/*     */   private static void throwIfNot(ConfigDataResource resource, boolean check) {
/* 143 */     if (!check)
/* 144 */       throw new ConfigDataResourceNotFoundException(resource); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataResourceNotFoundException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */