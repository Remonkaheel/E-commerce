/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConfigData
/*     */ {
/*     */   private final List<PropertySource<?>> propertySources;
/*     */   private final PropertySourceOptions propertySourceOptions;
/*  52 */   public static final ConfigData EMPTY = new ConfigData(Collections.emptySet(), new Option[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigData(Collection<? extends PropertySource<?>> propertySources, Option... options) {
/*  63 */     this(propertySources, PropertySourceOptions.always(Options.of(options)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigData(Collection<? extends PropertySource<?>> propertySources, PropertySourceOptions propertySourceOptions) {
/*  75 */     Assert.notNull(propertySources, "'propertySources' must not be null");
/*  76 */     Assert.notNull(propertySourceOptions, "'propertySourceOptions' must not be null");
/*  77 */     this.propertySources = Collections.unmodifiableList(new ArrayList<>(propertySources));
/*  78 */     this.propertySourceOptions = propertySourceOptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PropertySource<?>> getPropertySources() {
/*  88 */     return this.propertySources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Options getOptions(PropertySource<?> propertySource) {
/*  98 */     Options options = this.propertySourceOptions.get(propertySource);
/*  99 */     return (options != null) ? options : Options.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface PropertySourceOptions
/*     */   {
/* 116 */     public static final PropertySourceOptions ALWAYS_NONE = new ConfigData.AlwaysPropertySourceOptions(ConfigData.Options.NONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ConfigData.Options get(PropertySource<?> param1PropertySource);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static PropertySourceOptions always(ConfigData.Option... options) {
/* 132 */       return always(ConfigData.Options.of(options));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static PropertySourceOptions always(ConfigData.Options options) {
/* 142 */       if (options == ConfigData.Options.NONE) {
/* 143 */         return ALWAYS_NONE;
/*     */       }
/* 145 */       return new ConfigData.AlwaysPropertySourceOptions(options);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AlwaysPropertySourceOptions
/*     */     implements PropertySourceOptions
/*     */   {
/*     */     private final ConfigData.Options options;
/*     */ 
/*     */     
/*     */     AlwaysPropertySourceOptions(ConfigData.Options options) {
/* 158 */       this.options = options;
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigData.Options get(PropertySource<?> propertySource) {
/* 163 */       return this.options;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Options
/*     */   {
/* 178 */     public static final Options NONE = new Options(Collections.emptySet());
/*     */     
/*     */     private final Set<ConfigData.Option> options;
/*     */     
/*     */     private Options(Set<ConfigData.Option> options) {
/* 183 */       this.options = Collections.unmodifiableSet(options);
/*     */     }
/*     */     
/*     */     Set<ConfigData.Option> asSet() {
/* 187 */       return this.options;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean contains(ConfigData.Option option) {
/* 196 */       return this.options.contains(option);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 201 */       if (this == obj) {
/* 202 */         return true;
/*     */       }
/* 204 */       if (obj == null || getClass() != obj.getClass()) {
/* 205 */         return false;
/*     */       }
/* 207 */       Options other = (Options)obj;
/* 208 */       return this.options.equals(other.options);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 213 */       return this.options.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 218 */       return this.options.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Options without(ConfigData.Option option) {
/* 228 */       return copy(options -> options.remove(option));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Options with(ConfigData.Option option) {
/* 238 */       return copy(options -> options.add(option));
/*     */     }
/*     */ 
/*     */     
/*     */     private Options copy(Consumer<EnumSet<ConfigData.Option>> processor) {
/* 243 */       EnumSet<ConfigData.Option> options = !this.options.isEmpty() ? EnumSet.<ConfigData.Option>copyOf(this.options) : EnumSet.<ConfigData.Option>noneOf(ConfigData.Option.class);
/* 244 */       processor.accept(options);
/* 245 */       return new Options(options);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Options of(ConfigData.Option... options) {
/* 254 */       Assert.notNull(options, "'options' must not be null");
/* 255 */       if (options.length == 0) {
/* 256 */         return NONE;
/*     */       }
/* 258 */       return new Options(EnumSet.copyOf(Arrays.asList(options)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Option
/*     */   {
/* 271 */     IGNORE_IMPORTS,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     IGNORE_PROFILES,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     PROFILE_SPECIFIC;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */