/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.boot.logging.DeferredLogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigDataImporter
/*     */ {
/*     */   private final Log logger;
/*     */   private final ConfigDataLocationResolvers resolvers;
/*     */   private final ConfigDataLoaders loaders;
/*     */   private final ConfigDataNotFoundAction notFoundAction;
/*  51 */   private final Set<ConfigDataResource> loaded = new HashSet<>();
/*     */   
/*  53 */   private final Set<ConfigDataLocation> loadedLocations = new HashSet<>();
/*     */   
/*  55 */   private final Set<ConfigDataLocation> optionalLocations = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataImporter(DeferredLogFactory logFactory, ConfigDataNotFoundAction notFoundAction, ConfigDataLocationResolvers resolvers, ConfigDataLoaders loaders) {
/*  66 */     this.logger = logFactory.getLog(getClass());
/*  67 */     this.resolvers = resolvers;
/*  68 */     this.loaders = loaders;
/*  69 */     this.notFoundAction = notFoundAction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<ConfigDataResolutionResult, ConfigData> resolveAndLoad(ConfigDataActivationContext activationContext, ConfigDataLocationResolverContext locationResolverContext, ConfigDataLoaderContext loaderContext, List<ConfigDataLocation> locations) {
/*     */     try {
/*  85 */       Profiles profiles = (activationContext != null) ? activationContext.getProfiles() : null;
/*  86 */       List<ConfigDataResolutionResult> resolved = resolve(locationResolverContext, profiles, locations);
/*  87 */       return load(loaderContext, resolved);
/*     */     }
/*  89 */     catch (IOException ex) {
/*  90 */       throw new IllegalStateException("IO error on loading imports from " + String.valueOf(locations), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ConfigDataResolutionResult> resolve(ConfigDataLocationResolverContext locationResolverContext, Profiles profiles, List<ConfigDataLocation> locations) {
/*  96 */     List<ConfigDataResolutionResult> resolved = new ArrayList<>(locations.size());
/*  97 */     for (ConfigDataLocation location : locations) {
/*  98 */       resolved.addAll(resolve(locationResolverContext, profiles, location));
/*     */     }
/* 100 */     return Collections.unmodifiableList(resolved);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ConfigDataResolutionResult> resolve(ConfigDataLocationResolverContext locationResolverContext, Profiles profiles, ConfigDataLocation location) {
/*     */     try {
/* 106 */       return this.resolvers.resolve(locationResolverContext, location, profiles);
/*     */     }
/* 108 */     catch (ConfigDataNotFoundException ex) {
/* 109 */       handle(ex, location, null);
/* 110 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<ConfigDataResolutionResult, ConfigData> load(ConfigDataLoaderContext loaderContext, List<ConfigDataResolutionResult> candidates) throws IOException {
/* 116 */     Map<ConfigDataResolutionResult, ConfigData> result = new LinkedHashMap<>();
/* 117 */     for (int i = candidates.size() - 1; i >= 0; i--) {
/* 118 */       ConfigDataResolutionResult candidate = candidates.get(i);
/* 119 */       ConfigDataLocation location = candidate.getLocation();
/* 120 */       ConfigDataResource resource = candidate.getResource();
/* 121 */       this.logger.trace(LogMessage.format("Considering resource %s from location %s", resource, location));
/* 122 */       if (resource.isOptional()) {
/* 123 */         this.optionalLocations.add(location);
/*     */       }
/* 125 */       if (this.loaded.contains(resource)) {
/* 126 */         this.logger
/* 127 */           .trace(LogMessage.format("Already loaded resource %s ignoring location %s", resource, location));
/* 128 */         this.loadedLocations.add(location);
/*     */       } else {
/*     */         
/*     */         try {
/* 132 */           ConfigData loaded = this.loaders.load(loaderContext, resource);
/* 133 */           if (loaded != null) {
/* 134 */             this.logger.trace(LogMessage.format("Loaded resource %s from location %s", resource, location));
/* 135 */             this.loaded.add(resource);
/* 136 */             this.loadedLocations.add(location);
/* 137 */             result.put(candidate, loaded);
/*     */           }
/*     */         
/* 140 */         } catch (ConfigDataNotFoundException ex) {
/* 141 */           handle(ex, location, resource);
/*     */         } 
/*     */       } 
/*     */     } 
/* 145 */     return Collections.unmodifiableMap(result);
/*     */   }
/*     */   
/*     */   private void handle(ConfigDataNotFoundException ex, ConfigDataLocation location, ConfigDataResource resource) {
/* 149 */     if (ex instanceof ConfigDataResourceNotFoundException) { ConfigDataResourceNotFoundException notFoundException = (ConfigDataResourceNotFoundException)ex;
/* 150 */       ex = notFoundException.withLocation(location); }
/*     */     
/* 152 */     getNotFoundAction(location, resource).handle(this.logger, ex);
/*     */   }
/*     */   
/*     */   private ConfigDataNotFoundAction getNotFoundAction(ConfigDataLocation location, ConfigDataResource resource) {
/* 156 */     if (location.isOptional() || (resource != null && resource.isOptional())) {
/* 157 */       return ConfigDataNotFoundAction.IGNORE;
/*     */     }
/* 159 */     return this.notFoundAction;
/*     */   }
/*     */   
/*     */   Set<ConfigDataLocation> getLoadedLocations() {
/* 163 */     return this.loadedLocations;
/*     */   }
/*     */   
/*     */   Set<ConfigDataLocation> getOptionalLocations() {
/* 167 */     return this.optionalLocations;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataImporter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */