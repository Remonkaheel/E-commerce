/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InvalidConfigDataPropertyException
/*     */   extends ConfigDataException
/*     */ {
/*     */   private static final Map<ConfigurationPropertyName, ConfigurationPropertyName> ERRORS;
/*     */   private static final Set<ConfigurationPropertyName> PROFILE_SPECIFIC_ERRORS;
/*     */   private final ConfigurationProperty property;
/*     */   private final ConfigurationPropertyName replacement;
/*     */   private final ConfigDataResource location;
/*     */   
/*     */   static {
/*  41 */     Map<ConfigurationPropertyName, ConfigurationPropertyName> map = new LinkedHashMap<>();
/*  42 */     map.put(ConfigurationPropertyName.of("spring.profiles"), 
/*  43 */         ConfigurationPropertyName.of("spring.config.activate.on-profile"));
/*  44 */     map.put(ConfigurationPropertyName.of("spring.profiles[0]"), 
/*  45 */         ConfigurationPropertyName.of("spring.config.activate.on-profile"));
/*  46 */     ERRORS = Collections.unmodifiableMap(map);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     Set<ConfigurationPropertyName> errors = new LinkedHashSet<>();
/*  52 */     errors.add(Profiles.INCLUDE_PROFILES);
/*  53 */     errors.add(Profiles.INCLUDE_PROFILES.append("[0]"));
/*  54 */     errors.add(ConfigurationPropertyName.of("spring.profiles.active"));
/*  55 */     errors.add(ConfigurationPropertyName.of("spring.profiles.active[0]"));
/*  56 */     errors.add(ConfigurationPropertyName.of("spring.profiles.default"));
/*  57 */     errors.add(ConfigurationPropertyName.of("spring.profiles.default[0]"));
/*  58 */     PROFILE_SPECIFIC_ERRORS = Collections.unmodifiableSet(errors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InvalidConfigDataPropertyException(ConfigurationProperty property, boolean profileSpecific, ConfigurationPropertyName replacement, ConfigDataResource location) {
/*  69 */     super(getMessage(property, profileSpecific, replacement, location), null);
/*  70 */     this.property = property;
/*  71 */     this.replacement = replacement;
/*  72 */     this.location = location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationProperty getProperty() {
/*  80 */     return this.property;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigDataResource getLocation() {
/*  89 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPropertyName getReplacement() {
/*  98 */     return this.replacement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void throwIfPropertyFound(ConfigDataEnvironmentContributor contributor) {
/* 107 */     ConfigurationPropertySource propertySource = contributor.getConfigurationPropertySource();
/* 108 */     if (propertySource != null) {
/* 109 */       ERRORS.forEach((name, replacement) -> {
/*     */             ConfigurationProperty property = propertySource.getConfigurationProperty(name);
/*     */             
/*     */             if (property != null) {
/*     */               throw new InvalidConfigDataPropertyException(property, false, replacement, contributor.getResource());
/*     */             }
/*     */           });
/* 116 */       if (contributor.isFromProfileSpecificImport() && 
/* 117 */         !contributor.hasConfigDataOption(ConfigData.Option.IGNORE_PROFILES)) {
/* 118 */         PROFILE_SPECIFIC_ERRORS.forEach(name -> {
/*     */               ConfigurationProperty property = propertySource.getConfigurationProperty(name);
/*     */               if (property != null) {
/*     */                 throw new InvalidConfigDataPropertyException(property, true, null, contributor.getResource());
/*     */               }
/*     */             });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getMessage(ConfigurationProperty property, boolean profileSpecific, ConfigurationPropertyName replacement, ConfigDataResource location) {
/* 130 */     StringBuilder message = new StringBuilder("Property '");
/* 131 */     message.append(property.getName());
/* 132 */     if (location != null) {
/* 133 */       message.append("' imported from location '");
/* 134 */       message.append(location);
/*     */     } 
/* 136 */     message.append("' is invalid");
/* 137 */     if (profileSpecific) {
/* 138 */       message.append(" in a profile specific resource");
/*     */     }
/* 140 */     if (replacement != null) {
/* 141 */       message.append(" and should be replaced with '");
/* 142 */       message.append(replacement);
/* 143 */       message.append("'");
/*     */     } 
/* 145 */     if (property.getOrigin() != null) {
/* 146 */       message.append(" [origin: ");
/* 147 */       message.append(property.getOrigin());
/* 148 */       message.append("]");
/*     */     } 
/* 150 */     return message.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\InvalidConfigDataPropertyException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */