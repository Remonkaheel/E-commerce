/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigTreeConfigDataLocationResolver
/*    */   implements ConfigDataLocationResolver<ConfigTreeConfigDataResource>
/*    */ {
/*    */   private static final String PREFIX = "configtree:";
/*    */   private final LocationResourceLoader resourceLoader;
/*    */   
/*    */   public ConfigTreeConfigDataLocationResolver(ResourceLoader resourceLoader) {
/* 43 */     this.resourceLoader = new LocationResourceLoader(resourceLoader);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isResolvable(ConfigDataLocationResolverContext context, ConfigDataLocation location) {
/* 48 */     return location.hasPrefix("configtree:");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<ConfigTreeConfigDataResource> resolve(ConfigDataLocationResolverContext context, ConfigDataLocation location) {
/*    */     try {
/* 55 */       return resolve(location.getNonPrefixedValue("configtree:"));
/*    */     }
/* 57 */     catch (IOException ex) {
/* 58 */       throw new ConfigDataLocationNotFoundException(location, ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   private List<ConfigTreeConfigDataResource> resolve(String location) throws IOException {
/* 63 */     Assert.state(location.endsWith("/"), () -> String.format("Config tree location '%s' must end with '/'", new Object[] { location }));
/*    */     
/* 65 */     if (!this.resourceLoader.isPattern(location)) {
/* 66 */       return Collections.singletonList(new ConfigTreeConfigDataResource(location));
/*    */     }
/* 68 */     Resource[] resources = this.resourceLoader.getResources(location, LocationResourceLoader.ResourceType.DIRECTORY);
/* 69 */     List<ConfigTreeConfigDataResource> resolved = new ArrayList<>(resources.length);
/* 70 */     for (Resource resource : resources) {
/* 71 */       resolved.add(new ConfigTreeConfigDataResource(resource.getFile().toPath()));
/*    */     }
/* 73 */     return resolved;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigTreeConfigDataLocationResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */