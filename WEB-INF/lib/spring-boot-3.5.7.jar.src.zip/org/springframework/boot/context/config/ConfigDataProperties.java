/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.boot.cloud.CloudPlatform;
/*     */ import org.springframework.boot.context.properties.bind.BindHandler;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.bind.Name;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.core.env.Profiles;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigDataProperties
/*     */ {
/*  39 */   private static final ConfigurationPropertyName NAME = ConfigurationPropertyName.of("spring.config");
/*     */   
/*  41 */   private static final Bindable<ConfigDataProperties> BINDABLE_PROPERTIES = Bindable.of(ConfigDataProperties.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<ConfigDataLocation> imports;
/*     */ 
/*     */   
/*     */   private final Activate activate;
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataProperties(@Name("import") List<ConfigDataLocation> imports, Activate activate) {
/*  53 */     this.imports = (imports != null) ? imports : Collections.<ConfigDataLocation>emptyList();
/*  54 */     this.activate = activate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<ConfigDataLocation> getImports() {
/*  62 */     return this.imports;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isActive(ConfigDataActivationContext activationContext) {
/*  72 */     return (this.activate == null || this.activate.isActive(activationContext));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataProperties withoutImports() {
/*  80 */     return new ConfigDataProperties(null, this.activate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConfigDataProperties get(Binder binder) {
/*  90 */     return (ConfigDataProperties)binder.bind(NAME, BINDABLE_PROPERTIES, (BindHandler)new ConfigDataLocationBindHandler()).orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Activate
/*     */   {
/*     */     private final CloudPlatform onCloudPlatform;
/*     */ 
/*     */ 
/*     */     
/*     */     private final String[] onProfile;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Activate(CloudPlatform onCloudPlatform, String[] onProfile) {
/* 108 */       this.onProfile = onProfile;
/* 109 */       this.onCloudPlatform = onCloudPlatform;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isActive(ConfigDataActivationContext activationContext) {
/* 119 */       if (activationContext == null) {
/* 120 */         return false;
/*     */       }
/* 122 */       CloudPlatform cloudPlatform = activationContext.getCloudPlatform();
/* 123 */       boolean activate = isActive((cloudPlatform != null) ? cloudPlatform : CloudPlatform.NONE);
/* 124 */       activate = (activate && isActive(activationContext.getProfiles()));
/* 125 */       return activate;
/*     */     }
/*     */     
/*     */     private boolean isActive(CloudPlatform cloudPlatform) {
/* 129 */       return (this.onCloudPlatform == null || this.onCloudPlatform == cloudPlatform);
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean isActive(Profiles profiles) {
/* 134 */       Objects.requireNonNull(profiles); return (ObjectUtils.isEmpty((Object[])this.onProfile) || (profiles != null && matchesActiveProfiles(profiles::isAccepted)));
/*     */     }
/*     */     
/*     */     private boolean matchesActiveProfiles(Predicate<String> activeProfiles) {
/* 138 */       return Profiles.of(this.onProfile).matches(activeProfiles);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */