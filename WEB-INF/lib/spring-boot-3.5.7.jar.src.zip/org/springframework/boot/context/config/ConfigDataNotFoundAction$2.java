/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum null
/*    */ {
/*    */   void handle(Log logger, ConfigDataNotFoundException ex) {
/* 50 */     logger.trace(LogMessage.format("Ignoring missing config data %s", ex.getReferenceDescription()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataNotFoundAction$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */