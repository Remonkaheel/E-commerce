/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.boot.ConfigurableBootstrapContext;
/*     */ import org.springframework.boot.context.properties.bind.BindContext;
/*     */ import org.springframework.boot.context.properties.bind.BindHandler;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.boot.context.properties.bind.PlaceholdersResolver;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.logging.DeferredLogFactory;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigDataEnvironmentContributors
/*     */   implements Iterable<ConfigDataEnvironmentContributor>
/*     */ {
/*     */   private static final Predicate<ConfigDataEnvironmentContributor> NO_CONTRIBUTOR_FILTER = contributor -> true;
/*     */   private final Log logger;
/*     */   private final ConfigDataEnvironmentContributor root;
/*     */   private final ConfigurableBootstrapContext bootstrapContext;
/*     */   private final ConversionService conversionService;
/*     */   private final ConfigDataEnvironmentUpdateListener environmentUpdateListener;
/*     */   
/*     */   ConfigDataEnvironmentContributors(DeferredLogFactory logFactory, ConfigurableBootstrapContext bootstrapContext, List<ConfigDataEnvironmentContributor> contributors, ConversionService conversionService, ConfigDataEnvironmentUpdateListener environmentUpdateListener) {
/*  78 */     this.logger = logFactory.getLog(getClass());
/*  79 */     this.bootstrapContext = bootstrapContext;
/*  80 */     this.root = ConfigDataEnvironmentContributor.of(contributors, conversionService);
/*  81 */     this.conversionService = conversionService;
/*  82 */     this.environmentUpdateListener = environmentUpdateListener;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ConfigDataEnvironmentContributors(Log logger, ConfigurableBootstrapContext bootstrapContext, ConfigDataEnvironmentContributor root, ConversionService conversionService, ConfigDataEnvironmentUpdateListener environmentUpdateListener) {
/*  88 */     this.logger = logger;
/*  89 */     this.bootstrapContext = bootstrapContext;
/*  90 */     this.root = root;
/*  91 */     this.conversionService = conversionService;
/*  92 */     this.environmentUpdateListener = environmentUpdateListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataEnvironmentContributors withProcessedImports(ConfigDataImporter importer, ConfigDataActivationContext activationContext) {
/* 106 */     ConfigDataEnvironmentContributor.ImportPhase importPhase = ConfigDataEnvironmentContributor.ImportPhase.get(activationContext);
/* 107 */     this.logger.trace(LogMessage.format("Processing imports for phase %s. %s", importPhase, 
/* 108 */           (activationContext != null) ? activationContext : "no activation context"));
/* 109 */     ConfigDataEnvironmentContributors result = this;
/* 110 */     int processed = 0;
/*     */     while (true) {
/* 112 */       ConfigDataEnvironmentContributor contributor = getNextToProcess(result, activationContext, importPhase);
/* 113 */       if (contributor == null) {
/* 114 */         this.logger.trace(LogMessage.format("Processed imports for of %d contributors", Integer.valueOf(processed)));
/* 115 */         return result;
/*     */       } 
/* 117 */       if (contributor.getKind() == ConfigDataEnvironmentContributor.Kind.UNBOUND_IMPORT) {
/* 118 */         ConfigDataEnvironmentContributor bound = contributor.withBoundProperties(result, activationContext);
/*     */         
/* 120 */         result = new ConfigDataEnvironmentContributors(this.logger, this.bootstrapContext, result.getRoot().withReplacement(contributor, bound), this.conversionService, this.environmentUpdateListener);
/*     */         
/*     */         continue;
/*     */       } 
/* 124 */       ConfigDataLocationResolverContext locationResolverContext = new ContributorConfigDataLocationResolverContext(result, contributor, activationContext);
/*     */       
/* 126 */       ConfigDataLoaderContext loaderContext = new ContributorDataLoaderContext(this);
/* 127 */       List<ConfigDataLocation> imports = contributor.getImports();
/* 128 */       this.logger.trace(LogMessage.format("Processing imports %s", imports));
/* 129 */       Map<ConfigDataResolutionResult, ConfigData> imported = importer.resolveAndLoad(activationContext, locationResolverContext, loaderContext, imports);
/*     */       
/* 131 */       this.logger.trace(LogMessage.of(() -> getImportedMessage(imported.keySet())));
/* 132 */       ConfigDataEnvironmentContributor contributorAndChildren = contributor.withChildren(importPhase, 
/* 133 */           asContributors(imported));
/*     */       
/* 135 */       result = new ConfigDataEnvironmentContributors(this.logger, this.bootstrapContext, result.getRoot().withReplacement(contributor, contributorAndChildren), this.conversionService, this.environmentUpdateListener);
/*     */       
/* 137 */       processed++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private CharSequence getImportedMessage(Set<ConfigDataResolutionResult> results) {
/* 142 */     if (results.isEmpty()) {
/* 143 */       return "Nothing imported";
/*     */     }
/* 145 */     StringBuilder message = new StringBuilder();
/* 146 */     message.append("Imported " + results.size() + " resource" + ((results.size() != 1) ? "s " : " "));
/* 147 */     message.append(results.stream().map(ConfigDataResolutionResult::getResource).toList());
/* 148 */     return message;
/*     */   }
/*     */   
/*     */   protected final ConfigurableBootstrapContext getBootstrapContext() {
/* 152 */     return this.bootstrapContext;
/*     */   }
/*     */ 
/*     */   
/*     */   private ConfigDataEnvironmentContributor getNextToProcess(ConfigDataEnvironmentContributors contributors, ConfigDataActivationContext activationContext, ConfigDataEnvironmentContributor.ImportPhase importPhase) {
/* 157 */     for (ConfigDataEnvironmentContributor contributor : contributors.getRoot()) {
/* 158 */       if (contributor.getKind() == ConfigDataEnvironmentContributor.Kind.UNBOUND_IMPORT || 
/* 159 */         isActiveWithUnprocessedImports(activationContext, importPhase, contributor)) {
/* 160 */         return contributor;
/*     */       }
/*     */     } 
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isActiveWithUnprocessedImports(ConfigDataActivationContext activationContext, ConfigDataEnvironmentContributor.ImportPhase importPhase, ConfigDataEnvironmentContributor contributor) {
/* 168 */     return (contributor.isActive(activationContext) && contributor.hasUnprocessedImports(importPhase));
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ConfigDataEnvironmentContributor> asContributors(Map<ConfigDataResolutionResult, ConfigData> imported) {
/* 173 */     List<ConfigDataEnvironmentContributor> contributors = new ArrayList<>(imported.size() * 5);
/* 174 */     imported.forEach((resolutionResult, data) -> {
/*     */           ConfigDataLocation location = resolutionResult.getLocation();
/*     */           
/*     */           ConfigDataResource resource = resolutionResult.getResource();
/*     */           
/*     */           boolean profileSpecific = resolutionResult.isProfileSpecific();
/*     */           
/*     */           if (data.getPropertySources().isEmpty()) {
/*     */             contributors.add(ConfigDataEnvironmentContributor.ofEmptyLocation(location, profileSpecific, this.conversionService));
/*     */           } else {
/*     */             for (int i = data.getPropertySources().size() - 1; i >= 0; i--) {
/*     */               contributors.add(ConfigDataEnvironmentContributor.ofUnboundImport(location, resource, profileSpecific, data, i, this.conversionService, this.environmentUpdateListener));
/*     */             }
/*     */           } 
/*     */         });
/* 189 */     return Collections.unmodifiableList(contributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigDataEnvironmentContributor getRoot() {
/* 197 */     return this.root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Binder getBinder(ConfigDataActivationContext activationContext, BinderOption... options) {
/* 207 */     return getBinder(activationContext, NO_CONTRIBUTOR_FILTER, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Binder getBinder(ConfigDataActivationContext activationContext, Predicate<ConfigDataEnvironmentContributor> filter, BinderOption... options) {
/* 219 */     return getBinder(activationContext, filter, asBinderOptionsSet(options));
/*     */   }
/*     */   
/*     */   private Set<BinderOption> asBinderOptionsSet(BinderOption... options) {
/* 223 */     return ObjectUtils.isEmpty((Object[])options) ? EnumSet.<BinderOption>noneOf(BinderOption.class) : 
/* 224 */       EnumSet.<BinderOption>copyOf(Arrays.asList(options));
/*     */   }
/*     */ 
/*     */   
/*     */   private Binder getBinder(ConfigDataActivationContext activationContext, Predicate<ConfigDataEnvironmentContributor> filter, Set<BinderOption> options) {
/* 229 */     boolean failOnInactiveSource = options.contains(BinderOption.FAIL_ON_BIND_TO_INACTIVE_SOURCE);
/* 230 */     Iterable<ConfigurationPropertySource> sources = () -> getBinderSources(filter.and(()));
/*     */     
/* 232 */     PlaceholdersResolver placeholdersResolver = new ConfigDataEnvironmentContributorPlaceholdersResolver(this.root, activationContext, null, failOnInactiveSource, this.conversionService);
/*     */     
/* 234 */     BindHandler bindHandler = !failOnInactiveSource ? null : new InactiveSourceChecker(activationContext);
/* 235 */     return new Binder(sources, placeholdersResolver, null, null, bindHandler);
/*     */   }
/*     */   
/*     */   private Iterator<ConfigurationPropertySource> getBinderSources(Predicate<ConfigDataEnvironmentContributor> filter) {
/* 239 */     return this.root.stream()
/* 240 */       .filter(this::hasConfigurationPropertySource)
/* 241 */       .filter(filter)
/* 242 */       .map(ConfigDataEnvironmentContributor::getConfigurationPropertySource)
/* 243 */       .iterator();
/*     */   }
/*     */   
/*     */   private boolean hasConfigurationPropertySource(ConfigDataEnvironmentContributor contributor) {
/* 247 */     return (contributor.getConfigurationPropertySource() != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<ConfigDataEnvironmentContributor> iterator() {
/* 252 */     return this.root.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ContributorDataLoaderContext
/*     */     implements ConfigDataLoaderContext
/*     */   {
/*     */     private final ConfigDataEnvironmentContributors contributors;
/*     */ 
/*     */     
/*     */     ContributorDataLoaderContext(ConfigDataEnvironmentContributors contributors) {
/* 263 */       this.contributors = contributors;
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigurableBootstrapContext getBootstrapContext() {
/* 268 */       return this.contributors.getBootstrapContext();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ContributorConfigDataLocationResolverContext
/*     */     implements ConfigDataLocationResolverContext
/*     */   {
/*     */     private final ConfigDataEnvironmentContributors contributors;
/*     */ 
/*     */     
/*     */     private final ConfigDataEnvironmentContributor contributor;
/*     */     
/*     */     private final ConfigDataActivationContext activationContext;
/*     */     
/*     */     private volatile Binder binder;
/*     */ 
/*     */     
/*     */     ContributorConfigDataLocationResolverContext(ConfigDataEnvironmentContributors contributors, ConfigDataEnvironmentContributor contributor, ConfigDataActivationContext activationContext) {
/* 288 */       this.contributors = contributors;
/* 289 */       this.contributor = contributor;
/* 290 */       this.activationContext = activationContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public Binder getBinder() {
/* 295 */       Binder binder = this.binder;
/* 296 */       if (binder == null) {
/* 297 */         binder = this.contributors.getBinder(this.activationContext, new ConfigDataEnvironmentContributors.BinderOption[0]);
/* 298 */         this.binder = binder;
/*     */       } 
/* 300 */       return binder;
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigDataResource getParent() {
/* 305 */       return this.contributor.getResource();
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigurableBootstrapContext getBootstrapContext() {
/* 310 */       return this.contributors.getBootstrapContext();
/*     */     }
/*     */   }
/*     */   
/*     */   private class InactiveSourceChecker
/*     */     implements BindHandler
/*     */   {
/*     */     private final ConfigDataActivationContext activationContext;
/*     */     
/*     */     InactiveSourceChecker(ConfigDataActivationContext activationContext) {
/* 320 */       this.activationContext = activationContext;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object onSuccess(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result) {
/* 326 */       for (ConfigDataEnvironmentContributor contributor : ConfigDataEnvironmentContributors.this) {
/* 327 */         if (!contributor.isActive(this.activationContext)) {
/* 328 */           InactiveConfigDataAccessException.throwIfPropertyFound(contributor, name);
/*     */         }
/*     */       } 
/* 331 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum BinderOption
/*     */   {
/* 345 */     FAIL_ON_BIND_TO_INACTIVE_SOURCE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\config\ConfigDataEnvironmentContributors.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */