/*     */ package org.springframework.boot.context.annotation;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.springframework.core.io.UrlResource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImportCandidates
/*     */   implements Iterable<String>
/*     */ {
/*     */   private static final String LOCATION = "META-INF/spring/%s.imports";
/*     */   private static final String COMMENT_START = "#";
/*     */   private final List<String> candidates;
/*     */   
/*     */   private ImportCandidates(List<String> candidates) {
/*  52 */     Assert.notNull(candidates, "'candidates' must not be null");
/*  53 */     this.candidates = Collections.unmodifiableList(candidates);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<String> iterator() {
/*  58 */     return this.candidates.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getCandidates() {
/*  66 */     return this.candidates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImportCandidates load(Class<?> annotation, ClassLoader classLoader) {
/*  80 */     Assert.notNull(annotation, "'annotation' must not be null");
/*  81 */     ClassLoader classLoaderToUse = decideClassloader(classLoader);
/*  82 */     String location = String.format("META-INF/spring/%s.imports", new Object[] { annotation.getName() });
/*  83 */     Enumeration<URL> urls = findUrlsInClasspath(classLoaderToUse, location);
/*  84 */     List<String> importCandidates = new ArrayList<>();
/*  85 */     while (urls.hasMoreElements()) {
/*  86 */       URL url = urls.nextElement();
/*  87 */       importCandidates.addAll(readCandidateConfigurations(url));
/*     */     } 
/*  89 */     return new ImportCandidates(importCandidates);
/*     */   }
/*     */   
/*     */   private static ClassLoader decideClassloader(ClassLoader classLoader) {
/*  93 */     if (classLoader == null) {
/*  94 */       return ImportCandidates.class.getClassLoader();
/*     */     }
/*  96 */     return classLoader;
/*     */   }
/*     */   
/*     */   private static Enumeration<URL> findUrlsInClasspath(ClassLoader classLoader, String location) {
/*     */     try {
/* 101 */       return classLoader.getResources(location);
/*     */     }
/* 103 */     catch (IOException ex) {
/* 104 */       throw new IllegalArgumentException("Failed to load configurations from location [" + location + "]", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static List<String> readCandidateConfigurations(URL url) {
/*     */     try {
/* 110 */       BufferedReader reader = new BufferedReader(new InputStreamReader((new UrlResource(url)).getInputStream(), StandardCharsets.UTF_8)); 
/* 111 */       try { List<String> candidates = new ArrayList<>();
/*     */         String line;
/* 113 */         while ((line = reader.readLine()) != null) {
/* 114 */           line = stripComment(line);
/* 115 */           line = line.trim();
/* 116 */           if (line.isEmpty()) {
/*     */             continue;
/*     */           }
/* 119 */           candidates.add(line);
/*     */         } 
/* 121 */         List<String> list1 = candidates;
/* 122 */         reader.close(); return list1; } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 123 */     } catch (IOException ex) {
/* 124 */       throw new IllegalArgumentException("Unable to load configurations from location [" + String.valueOf(url) + "]", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String stripComment(String line) {
/* 129 */     int commentStart = line.indexOf("#");
/* 130 */     if (commentStart == -1) {
/* 131 */       return line;
/*     */     }
/* 133 */     return line.substring(0, commentStart);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\annotation\ImportCandidates.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */