package org.springframework.boot.context.annotation;

import java.util.Set;
import org.springframework.core.type.AnnotationMetadata;

@FunctionalInterface
public interface DeterminableImports {
  Set<Object> determineImports(AnnotationMetadata paramAnnotationMetadata);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\annotation\DeterminableImports.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */