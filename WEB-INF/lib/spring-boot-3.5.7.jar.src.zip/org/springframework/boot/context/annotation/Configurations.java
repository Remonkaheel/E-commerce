/*     */ package org.springframework.boot.context.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.function.UnaryOperator;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Configurations
/*     */ {
/*     */   private static final Comparator<Object> COMPARATOR;
/*     */   private final UnaryOperator<Collection<Class<?>>> sorter;
/*     */   private final Set<Class<?>> classes;
/*     */   private final Function<Class<?>, String> beanNameGenerator;
/*     */   
/*     */   static {
/*  63 */     COMPARATOR = OrderComparator.INSTANCE.thenComparing(other -> other.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Configurations(Collection<Class<?>> classes) {
/*  76 */     Assert.notNull(classes, "'classes' must not be null");
/*  77 */     Collection<Class<?>> sorted = sort(classes);
/*  78 */     this.sorter = null;
/*  79 */     this.classes = Collections.unmodifiableSet(new LinkedHashSet<>(sorted));
/*  80 */     this.beanNameGenerator = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Configurations(UnaryOperator<Collection<Class<?>>> sorter, Collection<Class<?>> classes, Function<Class<?>, String> beanNameGenerator) {
/*  92 */     Assert.notNull(classes, "'classes' must not be null");
/*  93 */     this.sorter = (sorter != null) ? sorter : UnaryOperator.<Collection<Class<?>>>identity();
/*  94 */     Collection<Class<?>> sorted = this.sorter.apply(classes);
/*  95 */     this.classes = Collections.unmodifiableSet(new LinkedHashSet<>(sorted));
/*  96 */     this.beanNameGenerator = beanNameGenerator;
/*     */   }
/*     */   
/*     */   protected final Set<Class<?>> getClasses() {
/* 100 */     return this.classes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "3.4.0", forRemoval = true)
/*     */   protected Collection<Class<?>> sort(Collection<Class<?>> classes) {
/* 112 */     return classes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Configurations merge(Configurations other) {
/* 122 */     Set<Class<?>> mergedClasses = new LinkedHashSet<>(getClasses());
/* 123 */     mergedClasses.addAll(other.getClasses());
/* 124 */     if (this.sorter != null) {
/* 125 */       mergedClasses = new LinkedHashSet<>(this.sorter.apply(mergedClasses));
/*     */     }
/* 127 */     return merge(mergedClasses);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBeanName(Class<?> beanClass) {
/* 145 */     return (this.beanNameGenerator != null) ? this.beanNameGenerator.apply(beanClass) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?>[] getClasses(Configurations... configurations) {
/* 155 */     return getClasses(Arrays.asList(configurations));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?>[] getClasses(Collection<Configurations> configurations) {
/* 165 */     List<Configurations> collated = collate(configurations);
/*     */ 
/*     */     
/* 168 */     LinkedHashSet<Class<?>> classes = (LinkedHashSet<Class<?>>)collated.stream().flatMap(Configurations::streamClasses).collect(Collectors.toCollection(LinkedHashSet::new));
/* 169 */     return ClassUtils.toClassArray(classes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Configurations> collate(Collection<Configurations> configurations) {
/* 179 */     LinkedList<Configurations> collated = new LinkedList<>();
/* 180 */     for (Configurations configuration : sortConfigurations(configurations)) {
/* 181 */       if (collated.isEmpty() || ((Configurations)collated.getLast()).getClass() != configuration.getClass()) {
/* 182 */         collated.add(configuration);
/*     */         continue;
/*     */       } 
/* 185 */       collated.set(collated.size() - 1, ((Configurations)collated.getLast()).merge(configuration));
/*     */     } 
/*     */     
/* 188 */     return collated;
/*     */   }
/*     */   
/*     */   private static List<Configurations> sortConfigurations(Collection<Configurations> configurations) {
/* 192 */     List<Configurations> sorted = new ArrayList<>(configurations);
/* 193 */     sorted.sort(COMPARATOR);
/* 194 */     return sorted;
/*     */   }
/*     */   
/*     */   private static Stream<Class<?>> streamClasses(Configurations configurations) {
/* 198 */     return configurations.getClasses().stream();
/*     */   }
/*     */   
/*     */   protected abstract Configurations merge(Set<Class<?>> paramSet);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\annotation\Configurations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */