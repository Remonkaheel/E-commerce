package org.springframework.boot.context;

import org.springframework.boot.context.event.SpringApplicationEvent;

interface Property {
  String getValue(SpringApplicationEvent paramSpringApplicationEvent);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\ApplicationPidFileWriter$Property.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */