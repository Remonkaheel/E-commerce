/*     */ package org.springframework.boot.context;
/*     */ 
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConfigurationWarningsPostProcessor
/*     */   implements PriorityOrdered, BeanDefinitionRegistryPostProcessor
/*     */ {
/*     */   private final ConfigurationWarningsApplicationContextInitializer.Check[] checks;
/*     */   
/*     */   public ConfigurationWarningsPostProcessor(ConfigurationWarningsApplicationContextInitializer.Check[] checks) {
/*  79 */     this.checks = checks;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  84 */     return 2147483646;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*     */ 
/*     */   
/*     */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/*  93 */     for (ConfigurationWarningsApplicationContextInitializer.Check check : this.checks) {
/*  94 */       String message = check.getWarning(registry);
/*  95 */       if (StringUtils.hasLength(message)) {
/*  96 */         warn(message);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void warn(String message) {
/* 103 */     if (ConfigurationWarningsApplicationContextInitializer.logger.isWarnEnabled())
/* 104 */       ConfigurationWarningsApplicationContextInitializer.logger.warn(String.format("%n%n** WARNING ** : %s%n%n", new Object[] { message })); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\context\ConfigurationWarningsApplicationContextInitializer$ConfigurationWarningsPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */