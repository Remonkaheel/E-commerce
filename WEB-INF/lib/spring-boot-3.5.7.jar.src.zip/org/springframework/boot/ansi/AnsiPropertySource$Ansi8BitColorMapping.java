/*     */ package org.springframework.boot.ansi;
/*     */ 
/*     */ import java.util.function.IntFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Ansi8BitColorMapping
/*     */   extends AnsiPropertySource.Mapping
/*     */ {
/*     */   private final IntFunction<Ansi8BitColor> factory;
/*     */   
/*     */   Ansi8BitColorMapping(String prefix, IntFunction<Ansi8BitColor> factory) {
/* 143 */     super(prefix);
/* 144 */     this.factory = factory;
/*     */   }
/*     */ 
/*     */   
/*     */   AnsiElement getElement(String postfix) {
/* 149 */     if (containsOnlyDigits(postfix)) {
/*     */       try {
/* 151 */         return this.factory.apply(Integer.parseInt(postfix));
/*     */       }
/* 153 */       catch (IllegalArgumentException illegalArgumentException) {}
/*     */     }
/*     */ 
/*     */     
/* 157 */     return null;
/*     */   }
/*     */   
/*     */   private boolean containsOnlyDigits(String postfix) {
/* 161 */     for (int i = 0; i < postfix.length(); i++) {
/* 162 */       if (!Character.isDigit(postfix.charAt(i))) {
/* 163 */         return false;
/*     */       }
/*     */     } 
/* 166 */     return !postfix.isEmpty();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\ansi\AnsiPropertySource$Ansi8BitColorMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */