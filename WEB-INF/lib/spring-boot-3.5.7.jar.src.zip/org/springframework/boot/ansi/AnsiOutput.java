/*     */ package org.springframework.boot.ansi;
/*     */ 
/*     */ import java.io.Console;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Locale;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnsiOutput
/*     */ {
/*     */   private static final String ENCODE_JOIN = ";";
/*  38 */   private static Enabled enabled = Enabled.DETECT;
/*     */   
/*     */   private static Boolean consoleAvailable;
/*     */   
/*     */   private static Boolean ansiCapable;
/*     */   
/*  44 */   private static final String OPERATING_SYSTEM_NAME = System.getProperty("os.name").toLowerCase(Locale.ENGLISH);
/*     */   
/*     */   private static final String ENCODE_START = "\033[";
/*     */   
/*     */   private static final String ENCODE_END = "m";
/*     */   
/*  50 */   private static final String RESET = "0;" + String.valueOf(AnsiColor.DEFAULT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setEnabled(Enabled enabled) {
/*  57 */     Assert.notNull(enabled, "'enabled' must not be null");
/*  58 */     AnsiOutput.enabled = enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Enabled getEnabled() {
/*  66 */     return enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setConsoleAvailable(Boolean consoleAvailable) {
/*  75 */     AnsiOutput.consoleAvailable = consoleAvailable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode(AnsiElement element) {
/*  84 */     if (isEnabled()) {
/*  85 */       return "\033[" + String.valueOf(element) + "m";
/*     */     }
/*  87 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Object... elements) {
/*  97 */     StringBuilder sb = new StringBuilder();
/*  98 */     if (isEnabled()) {
/*  99 */       buildEnabled(sb, elements);
/*     */     } else {
/*     */       
/* 102 */       buildDisabled(sb, elements);
/*     */     } 
/* 104 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static void buildEnabled(StringBuilder sb, Object[] elements) {
/* 108 */     boolean writingAnsi = false;
/* 109 */     boolean containsEncoding = false;
/* 110 */     for (Object element : elements) {
/* 111 */       if (element instanceof AnsiElement) {
/* 112 */         containsEncoding = true;
/* 113 */         if (!writingAnsi) {
/* 114 */           sb.append("\033[");
/* 115 */           writingAnsi = true;
/*     */         } else {
/*     */           
/* 118 */           sb.append(";");
/*     */         }
/*     */       
/*     */       }
/* 122 */       else if (writingAnsi) {
/* 123 */         sb.append("m");
/* 124 */         writingAnsi = false;
/*     */       } 
/*     */       
/* 127 */       sb.append(element);
/*     */     } 
/* 129 */     if (containsEncoding) {
/* 130 */       sb.append(writingAnsi ? ";" : "\033[");
/* 131 */       sb.append(RESET);
/* 132 */       sb.append("m");
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void buildDisabled(StringBuilder sb, Object[] elements) {
/* 137 */     for (Object element : elements) {
/* 138 */       if (!(element instanceof AnsiElement) && element != null) {
/* 139 */         sb.append(element);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isEnabled() {
/* 145 */     if (enabled == Enabled.DETECT) {
/* 146 */       if (ansiCapable == null) {
/* 147 */         ansiCapable = Boolean.valueOf(detectIfAnsiCapable());
/*     */       }
/* 149 */       return ansiCapable.booleanValue();
/*     */     } 
/* 151 */     return (enabled == Enabled.ALWAYS);
/*     */   }
/*     */   
/*     */   private static boolean detectIfAnsiCapable() {
/*     */     try {
/* 156 */       if (Boolean.FALSE.equals(consoleAvailable)) {
/* 157 */         return false;
/*     */       }
/* 159 */       if (consoleAvailable == null) {
/* 160 */         Console console = System.console();
/* 161 */         if (console == null) {
/* 162 */           return false;
/*     */         }
/* 164 */         Method isTerminalMethod = ClassUtils.getMethodIfAvailable(Console.class, "isTerminal", new Class[0]);
/* 165 */         if (isTerminalMethod != null) {
/* 166 */           Boolean isTerminal = (Boolean)isTerminalMethod.invoke(console, new Object[0]);
/* 167 */           if (Boolean.FALSE.equals(isTerminal)) {
/* 168 */             return false;
/*     */           }
/*     */         } 
/*     */       } 
/* 172 */       return !OPERATING_SYSTEM_NAME.contains("win");
/*     */     }
/* 174 */     catch (Throwable ex) {
/* 175 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Enabled
/*     */   {
/* 189 */     DETECT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     ALWAYS,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     NEVER;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\ansi\AnsiOutput.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */