/*    */ package org.springframework.boot.ansi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AnsiStyle
/*    */   implements AnsiElement
/*    */ {
/* 27 */   NORMAL("0"),
/*    */   
/* 29 */   BOLD("1"),
/*    */   
/* 31 */   FAINT("2"),
/*    */   
/* 33 */   ITALIC("3"),
/*    */   
/* 35 */   UNDERLINE("4");
/*    */   
/*    */   private final String code;
/*    */   
/*    */   AnsiStyle(String code) {
/* 40 */     this.code = code;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 45 */     return this.code;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\ansi\AnsiStyle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */