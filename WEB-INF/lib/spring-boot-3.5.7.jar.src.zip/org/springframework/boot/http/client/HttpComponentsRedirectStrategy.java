/*    */ package org.springframework.boot.http.client;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.apache.hc.client5.http.protocol.RedirectStrategy;
/*    */ import org.apache.hc.core5.http.HttpRequest;
/*    */ import org.apache.hc.core5.http.HttpResponse;
/*    */ import org.apache.hc.core5.http.protocol.HttpContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HttpComponentsRedirectStrategy
/*    */ {
/*    */   static RedirectStrategy get(HttpRedirects redirects) {
/* 42 */     switch (redirects) { default: throw new IncompatibleClassChangeError();case FOLLOW_WHEN_POSSIBLE: case FOLLOW: case DONT_FOLLOW: break; }  return 
/*    */       
/* 44 */       NoFollowRedirectStrategy.INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static final class NoFollowRedirectStrategy
/*    */     implements RedirectStrategy
/*    */   {
/* 53 */     private static final RedirectStrategy INSTANCE = new NoFollowRedirectStrategy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public boolean isRedirected(HttpRequest request, HttpResponse response, HttpContext context) {
/* 60 */       return false;
/*    */     }
/*    */ 
/*    */     
/*    */     public URI getLocationURI(HttpRequest request, HttpResponse response, HttpContext context) {
/* 65 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\HttpComponentsRedirectStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */