/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.apache.hc.client5.http.config.RequestConfig;
/*     */ import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
/*     */ import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
/*     */ import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
/*     */ import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
/*     */ import org.apache.hc.client5.http.io.HttpClientConnectionManager;
/*     */ import org.apache.hc.client5.http.ssl.TlsSocketStrategy;
/*     */ import org.apache.hc.core5.http.io.SocketConfig;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpComponentsHttpClientBuilder
/*     */ {
/*     */   private final Consumer<HttpClientBuilder> customizer;
/*     */   private final Consumer<PoolingHttpClientConnectionManagerBuilder> connectionManagerCustomizer;
/*     */   private final Consumer<SocketConfig.Builder> socketConfigCustomizer;
/*     */   private final Consumer<RequestConfig.Builder> defaultRequestConfigCustomizer;
/*     */   private final Function<SslBundle, TlsSocketStrategy> tlsSocketStrategyFactory;
/*     */   
/*     */   public HttpComponentsHttpClientBuilder() {
/*  60 */     this(Empty.consumer(), Empty.consumer(), Empty.consumer(), Empty.consumer(), HttpComponentsSslBundleTlsStrategy::get);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpComponentsHttpClientBuilder(Consumer<HttpClientBuilder> customizer, Consumer<PoolingHttpClientConnectionManagerBuilder> connectionManagerCustomizer, Consumer<SocketConfig.Builder> socketConfigCustomizer, Consumer<RequestConfig.Builder> defaultRequestConfigCustomizer, Function<SslBundle, TlsSocketStrategy> tlsSocketStrategyFactory) {
/*  69 */     this.customizer = customizer;
/*  70 */     this.connectionManagerCustomizer = connectionManagerCustomizer;
/*  71 */     this.socketConfigCustomizer = socketConfigCustomizer;
/*  72 */     this.defaultRequestConfigCustomizer = defaultRequestConfigCustomizer;
/*  73 */     this.tlsSocketStrategyFactory = tlsSocketStrategyFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsHttpClientBuilder withCustomizer(Consumer<HttpClientBuilder> customizer) {
/*  83 */     Assert.notNull(customizer, "'customizer' must not be null");
/*  84 */     return new HttpComponentsHttpClientBuilder(this.customizer.andThen(customizer), this.connectionManagerCustomizer, this.socketConfigCustomizer, this.defaultRequestConfigCustomizer, this.tlsSocketStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsHttpClientBuilder withConnectionManagerCustomizer(Consumer<PoolingHttpClientConnectionManagerBuilder> connectionManagerCustomizer) {
/*  97 */     Assert.notNull(connectionManagerCustomizer, "'connectionManagerCustomizer' must not be null");
/*  98 */     return new HttpComponentsHttpClientBuilder(this.customizer, this.connectionManagerCustomizer
/*  99 */         .andThen(connectionManagerCustomizer), this.socketConfigCustomizer, this.defaultRequestConfigCustomizer, this.tlsSocketStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsHttpClientBuilder withSocketConfigCustomizer(Consumer<SocketConfig.Builder> socketConfigCustomizer) {
/* 112 */     Assert.notNull(socketConfigCustomizer, "'socketConfigCustomizer' must not be null");
/* 113 */     return new HttpComponentsHttpClientBuilder(this.customizer, this.connectionManagerCustomizer, this.socketConfigCustomizer
/* 114 */         .andThen(socketConfigCustomizer), this.defaultRequestConfigCustomizer, this.tlsSocketStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsHttpClientBuilder withTlsSocketStrategyFactory(Function<SslBundle, TlsSocketStrategy> tlsSocketStrategyFactory) {
/* 129 */     Assert.notNull(tlsSocketStrategyFactory, "'tlsSocketStrategyFactory' must not be null");
/* 130 */     return new HttpComponentsHttpClientBuilder(this.customizer, this.connectionManagerCustomizer, this.socketConfigCustomizer, this.defaultRequestConfigCustomizer, tlsSocketStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsHttpClientBuilder withDefaultRequestConfigCustomizer(Consumer<RequestConfig.Builder> defaultRequestConfigCustomizer) {
/* 144 */     Assert.notNull(defaultRequestConfigCustomizer, "'defaultRequestConfigCustomizer' must not be null");
/* 145 */     return new HttpComponentsHttpClientBuilder(this.customizer, this.connectionManagerCustomizer, this.socketConfigCustomizer, this.defaultRequestConfigCustomizer
/*     */         
/* 147 */         .andThen(defaultRequestConfigCustomizer), this.tlsSocketStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CloseableHttpClient build(HttpClientSettings settings) {
/* 157 */     settings = (settings != null) ? settings : HttpClientSettings.DEFAULTS;
/* 158 */     Assert.isTrue((settings.connectTimeout() == null), "'settings' must not have a 'connectTimeout'");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     HttpClientBuilder builder = HttpClientBuilder.create().useSystemProperties().setRedirectStrategy(HttpComponentsRedirectStrategy.get(settings.redirects())).setConnectionManager((HttpClientConnectionManager)createConnectionManager(settings)).setDefaultRequestConfig(createDefaultRequestConfig());
/* 164 */     this.customizer.accept(builder);
/* 165 */     return builder.build();
/*     */   }
/*     */ 
/*     */   
/*     */   private PoolingHttpClientConnectionManager createConnectionManager(HttpClientSettings settings) {
/* 170 */     PoolingHttpClientConnectionManagerBuilder builder = PoolingHttpClientConnectionManagerBuilder.create().useSystemProperties();
/* 171 */     PropertyMapper map = PropertyMapper.get();
/* 172 */     builder.setDefaultSocketConfig(createSocketConfig(settings));
/* 173 */     Objects.requireNonNull(settings); Objects.requireNonNull(builder); map.from(settings::sslBundle).as(this.tlsSocketStrategyFactory).whenNonNull().to(builder::setTlsSocketStrategy);
/* 174 */     this.connectionManagerCustomizer.accept(builder);
/* 175 */     return builder.build();
/*     */   }
/*     */   
/*     */   private SocketConfig createSocketConfig(HttpClientSettings settings) {
/* 179 */     SocketConfig.Builder builder = SocketConfig.custom();
/* 180 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 181 */     Objects.requireNonNull(settings); map.from(settings::readTimeout)
/* 182 */       .asInt(Duration::toMillis)
/* 183 */       .to(timeout -> builder.setSoTimeout(timeout.intValue(), TimeUnit.MILLISECONDS));
/* 184 */     this.socketConfigCustomizer.accept(builder);
/* 185 */     return builder.build();
/*     */   }
/*     */   
/*     */   private RequestConfig createDefaultRequestConfig() {
/* 189 */     RequestConfig.Builder builder = RequestConfig.custom();
/* 190 */     this.defaultRequestConfigCustomizer.accept(builder);
/* 191 */     return builder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\HttpComponentsHttpClientBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */