/*     */ package org.springframework.boot.http.client.reactive;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.boot.http.client.HttpRedirects;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClientHttpConnectorSettings
/*     */   extends Record
/*     */ {
/*     */   private final HttpRedirects redirects;
/*     */   private final Duration connectTimeout;
/*     */   private final Duration readTimeout;
/*     */   private final SslBundle sslBundle;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lorg/springframework/boot/http/client/reactive/ClientHttpConnectorSettings;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #37	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/boot/http/client/reactive/ClientHttpConnectorSettings;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/http/client/reactive/ClientHttpConnectorSettings;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #37	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/boot/http/client/reactive/ClientHttpConnectorSettings;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lorg/springframework/boot/http/client/reactive/ClientHttpConnectorSettings;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #37	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lorg/springframework/boot/http/client/reactive/ClientHttpConnectorSettings;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   public HttpRedirects redirects() {
/*  37 */     return this.redirects; } public Duration connectTimeout() { return this.connectTimeout; } public Duration readTimeout() { return this.readTimeout; } public SslBundle sslBundle() { return this.sslBundle; }
/*     */ 
/*     */   
/*  40 */   private static final ClientHttpConnectorSettings defaults = new ClientHttpConnectorSettings(null, null, null, null);
/*     */   
/*     */   public ClientHttpConnectorSettings(HttpRedirects redirects, Duration connectTimeout, Duration readTimeout, SslBundle sslBundle) {
/*  43 */     redirects = (redirects != null) ? redirects : HttpRedirects.FOLLOW_WHEN_POSSIBLE;
/*     */     this.redirects = redirects;
/*     */     this.connectTimeout = connectTimeout;
/*     */     this.readTimeout = readTimeout;
/*     */     this.sslBundle = sslBundle;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpConnectorSettings withConnectTimeout(Duration connectTimeout) {
/*  53 */     return new ClientHttpConnectorSettings(this.redirects, connectTimeout, this.readTimeout, this.sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpConnectorSettings withReadTimeout(Duration readTimeout) {
/*  63 */     return new ClientHttpConnectorSettings(this.redirects, this.connectTimeout, readTimeout, this.sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpConnectorSettings withTimeouts(Duration connectTimeout, Duration readTimeout) {
/*  74 */     return new ClientHttpConnectorSettings(this.redirects, connectTimeout, readTimeout, this.sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpConnectorSettings withSslBundle(SslBundle sslBundle) {
/*  84 */     return new ClientHttpConnectorSettings(this.redirects, this.connectTimeout, this.readTimeout, sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpConnectorSettings withRedirects(HttpRedirects redirects) {
/*  94 */     return new ClientHttpConnectorSettings(redirects, this.connectTimeout, this.readTimeout, this.sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientHttpConnectorSettings ofSslBundle(SslBundle sslBundle) {
/* 104 */     return defaults().withSslBundle(sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientHttpConnectorSettings defaults() {
/* 113 */     return defaults;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\reactive\ClientHttpConnectorSettings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */