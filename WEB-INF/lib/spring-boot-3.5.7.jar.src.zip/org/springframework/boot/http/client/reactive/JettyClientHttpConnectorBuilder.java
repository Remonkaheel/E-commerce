/*     */ package org.springframework.boot.http.client.reactive;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.jetty.client.HttpClient;
/*     */ import org.eclipse.jetty.client.HttpClientTransport;
/*     */ import org.eclipse.jetty.io.ClientConnector;
/*     */ import org.springframework.boot.http.client.JettyHttpClientBuilder;
/*     */ import org.springframework.http.client.reactive.ClientHttpConnector;
/*     */ import org.springframework.http.client.reactive.JettyClientHttpConnector;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JettyClientHttpConnectorBuilder
/*     */   extends AbstractClientHttpConnectorBuilder<JettyClientHttpConnector>
/*     */ {
/*     */   private final JettyHttpClientBuilder httpClientBuilder;
/*     */   
/*     */   JettyClientHttpConnectorBuilder() {
/*  44 */     this((List<Consumer<JettyClientHttpConnector>>)null, new JettyHttpClientBuilder());
/*     */   }
/*     */ 
/*     */   
/*     */   private JettyClientHttpConnectorBuilder(List<Consumer<JettyClientHttpConnector>> customizers, JettyHttpClientBuilder httpClientBuilder) {
/*  49 */     super(customizers);
/*  50 */     this.httpClientBuilder = httpClientBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public JettyClientHttpConnectorBuilder withCustomizer(Consumer<JettyClientHttpConnector> customizer) {
/*  55 */     return new JettyClientHttpConnectorBuilder(mergedCustomizers(customizer), this.httpClientBuilder);
/*     */   }
/*     */ 
/*     */   
/*     */   public JettyClientHttpConnectorBuilder withCustomizers(Collection<Consumer<JettyClientHttpConnector>> customizers) {
/*  60 */     return new JettyClientHttpConnectorBuilder(mergedCustomizers(customizers), this.httpClientBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpConnectorBuilder withHttpClientCustomizer(Consumer<HttpClient> httpClientCustomizer) {
/*  70 */     Assert.notNull(httpClientCustomizer, "'httpClientCustomizer' must not be null");
/*  71 */     return new JettyClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/*  72 */         .withCustomizer(httpClientCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpConnectorBuilder withHttpClientTransportCustomizer(Consumer<HttpClientTransport> httpClientTransportCustomizer) {
/*  83 */     Assert.notNull(httpClientTransportCustomizer, "'httpClientTransportCustomizer' must not be null");
/*  84 */     return new JettyClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/*  85 */         .withHttpClientTransportCustomizer(httpClientTransportCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpConnectorBuilder withClientConnectorCustomizerCustomizer(Consumer<ClientConnector> clientConnectorCustomizerCustomizer) {
/*  96 */     Assert.notNull(clientConnectorCustomizerCustomizer, "'clientConnectorCustomizerCustomizer' must not be null");
/*  97 */     return new JettyClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/*  98 */         .withClientConnectorCustomizerCustomizer(clientConnectorCustomizerCustomizer));
/*     */   }
/*     */ 
/*     */   
/*     */   protected JettyClientHttpConnector createClientHttpConnector(ClientHttpConnectorSettings settings) {
/* 103 */     HttpClient httpClient = this.httpClientBuilder.build(asHttpClientSettings(settings));
/* 104 */     return new JettyClientHttpConnector(httpClient);
/*     */   }
/*     */ 
/*     */   
/*     */   static class Classes
/*     */   {
/*     */     static final String HTTP_CLIENT = "org.eclipse.jetty.client.HttpClient";
/*     */     static final String REACTIVE_REQUEST = "org.eclipse.jetty.reactive.client.ReactiveRequest";
/*     */     
/*     */     static boolean present(ClassLoader classLoader) {
/* 114 */       return (ClassUtils.isPresent("org.eclipse.jetty.client.HttpClient", classLoader) && 
/* 115 */         ClassUtils.isPresent("org.eclipse.jetty.reactive.client.ReactiveRequest", classLoader));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\reactive\JettyClientHttpConnectorBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */