/*    */ package org.springframework.boot.http.client.reactive;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.boot.http.client.HttpClientSettings;
/*    */ import org.springframework.boot.util.LambdaSafe;
/*    */ import org.springframework.http.client.reactive.ClientHttpConnector;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractClientHttpConnectorBuilder<T extends ClientHttpConnector>
/*    */   implements ClientHttpConnectorBuilder<T>
/*    */ {
/*    */   private final List<Consumer<T>> customizers;
/*    */   
/*    */   protected AbstractClientHttpConnectorBuilder(List<Consumer<T>> customizers) {
/* 42 */     this.customizers = (customizers != null) ? customizers : Collections.<Consumer<T>>emptyList();
/*    */   }
/*    */   
/*    */   protected final List<Consumer<T>> getCustomizers() {
/* 46 */     return this.customizers;
/*    */   }
/*    */   
/*    */   protected final List<Consumer<T>> mergedCustomizers(Consumer<T> customizer) {
/* 50 */     Assert.notNull(this.customizers, "'customizer' must not be null");
/* 51 */     return merge(this.customizers, List.of(customizer));
/*    */   }
/*    */   
/*    */   protected final List<Consumer<T>> mergedCustomizers(Collection<Consumer<T>> customizers) {
/* 55 */     Assert.notNull(customizers, "'customizers' must not be null");
/* 56 */     Assert.noNullElements(customizers, "'customizers' must not contain null elements");
/* 57 */     return merge(this.customizers, customizers);
/*    */   }
/*    */   
/*    */   private <E> List<E> merge(Collection<E> list, Collection<? extends E> additional) {
/* 61 */     List<E> merged = new ArrayList<>(list);
/* 62 */     merged.addAll(additional);
/* 63 */     return List.copyOf(merged);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final T build(ClientHttpConnectorSettings settings) {
/* 69 */     T connector = createClientHttpConnector((settings != null) ? settings : ClientHttpConnectorSettings.defaults());
/* 70 */     LambdaSafe.callbacks(Consumer.class, this.customizers, connector, new Object[0])
/* 71 */       .invoke(consumer -> consumer.accept(connector));
/* 72 */     return connector;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected final HttpClientSettings asHttpClientSettings(ClientHttpConnectorSettings settings) {
/* 78 */     return (settings != null) ? new HttpClientSettings(settings.redirects(), settings.connectTimeout(), settings
/* 79 */         .readTimeout(), settings.sslBundle()) : null;
/*    */   }
/*    */   
/*    */   protected abstract T createClientHttpConnector(ClientHttpConnectorSettings paramClientHttpConnectorSettings);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\reactive\AbstractClientHttpConnectorBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */