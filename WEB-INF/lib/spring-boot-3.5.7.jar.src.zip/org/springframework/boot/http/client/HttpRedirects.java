/*    */ package org.springframework.boot.http.client;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum HttpRedirects
/*    */ {
/* 30 */   FOLLOW_WHEN_POSSIBLE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   FOLLOW,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   DONT_FOLLOW;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\HttpRedirects.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */