/*    */ package org.springframework.boot.http.client.reactive;
/*    */ 
/*    */ import java.net.http.HttpClient;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.boot.http.client.JdkHttpClientBuilder;
/*    */ import org.springframework.http.client.reactive.ClientHttpConnector;
/*    */ import org.springframework.http.client.reactive.JdkClientHttpConnector;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JdkClientHttpConnectorBuilder
/*    */   extends AbstractClientHttpConnectorBuilder<JdkClientHttpConnector>
/*    */ {
/*    */   private final JdkHttpClientBuilder httpClientBuilder;
/*    */   
/*    */   JdkClientHttpConnectorBuilder() {
/* 41 */     this((List<Consumer<JdkClientHttpConnector>>)null, new JdkHttpClientBuilder());
/*    */   }
/*    */ 
/*    */   
/*    */   private JdkClientHttpConnectorBuilder(List<Consumer<JdkClientHttpConnector>> customizers, JdkHttpClientBuilder httpClientBuilder) {
/* 46 */     super(customizers);
/* 47 */     this.httpClientBuilder = httpClientBuilder;
/*    */   }
/*    */ 
/*    */   
/*    */   public JdkClientHttpConnectorBuilder withCustomizer(Consumer<JdkClientHttpConnector> customizer) {
/* 52 */     return new JdkClientHttpConnectorBuilder(mergedCustomizers(customizer), this.httpClientBuilder);
/*    */   }
/*    */ 
/*    */   
/*    */   public JdkClientHttpConnectorBuilder withCustomizers(Collection<Consumer<JdkClientHttpConnector>> customizers) {
/* 57 */     return new JdkClientHttpConnectorBuilder(mergedCustomizers(customizers), this.httpClientBuilder);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JdkClientHttpConnectorBuilder withHttpClientCustomizer(Consumer<HttpClient.Builder> httpClientCustomizer) {
/* 67 */     Assert.notNull(httpClientCustomizer, "'httpClientCustomizer' must not be null");
/* 68 */     return new JdkClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/* 69 */         .withCustomizer(httpClientCustomizer));
/*    */   }
/*    */ 
/*    */   
/*    */   protected JdkClientHttpConnector createClientHttpConnector(ClientHttpConnectorSettings settings) {
/* 74 */     HttpClient httpClient = this.httpClientBuilder.build(asHttpClientSettings(settings.withReadTimeout(null)));
/* 75 */     JdkClientHttpConnector connector = new JdkClientHttpConnector(httpClient);
/* 76 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 77 */     Objects.requireNonNull(settings); Objects.requireNonNull(connector); map.from(settings::readTimeout).to(connector::setReadTimeout);
/* 78 */     return connector;
/*    */   }
/*    */   
/*    */   static class Classes
/*    */   {
/*    */     static final String HTTP_CLIENT = "java.net.http.HttpClient";
/*    */     
/*    */     static boolean present(ClassLoader classLoader) {
/* 86 */       return ClassUtils.isPresent("java.net.http.HttpClient", classLoader);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\reactive\JdkClientHttpConnectorBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */