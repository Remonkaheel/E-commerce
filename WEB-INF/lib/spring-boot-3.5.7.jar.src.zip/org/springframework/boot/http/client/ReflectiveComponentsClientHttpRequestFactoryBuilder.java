/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.http.client.AbstractClientHttpRequestFactoryWrapper;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ReflectiveComponentsClientHttpRequestFactoryBuilder<T extends ClientHttpRequestFactory>
/*     */   implements ClientHttpRequestFactoryBuilder<T>
/*     */ {
/*     */   private final Supplier<T> requestFactorySupplier;
/*     */   
/*     */   ReflectiveComponentsClientHttpRequestFactoryBuilder(Supplier<T> requestFactorySupplier) {
/*  47 */     Assert.notNull(requestFactorySupplier, "'requestFactorySupplier' must not be null");
/*  48 */     this.requestFactorySupplier = requestFactorySupplier;
/*     */   }
/*     */   
/*     */   ReflectiveComponentsClientHttpRequestFactoryBuilder(Class<T> requestFactoryType) {
/*  52 */     Assert.notNull(requestFactoryType, "'requestFactoryType' must not be null");
/*  53 */     this.requestFactorySupplier = (() -> createRequestFactory(requestFactoryType));
/*     */   }
/*     */   
/*     */   private static <T extends ClientHttpRequestFactory> T createRequestFactory(Class<T> requestFactory) {
/*     */     try {
/*  58 */       Constructor<T> constructor = requestFactory.getDeclaredConstructor(new Class[0]);
/*  59 */       constructor.setAccessible(true);
/*  60 */       return constructor.newInstance(new Object[0]);
/*     */     }
/*  62 */     catch (Exception ex) {
/*  63 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public T build(ClientHttpRequestFactorySettings settings) {
/*  69 */     ClientHttpRequestFactory clientHttpRequestFactory = (ClientHttpRequestFactory)this.requestFactorySupplier.get();
/*  70 */     if (settings != null) {
/*  71 */       configure(clientHttpRequestFactory, settings);
/*     */     }
/*  73 */     return (T)clientHttpRequestFactory;
/*     */   }
/*     */   
/*     */   private void configure(ClientHttpRequestFactory requestFactory, ClientHttpRequestFactorySettings settings) {
/*  77 */     Assert.state((settings.sslBundle() == null), "Unable to set SSL bundle using reflection");
/*  78 */     Assert.state((settings.redirects() == ClientHttpRequestFactorySettings.Redirects.FOLLOW_WHEN_POSSIBLE), "Unable to set redirect follow using reflection");
/*     */     
/*  80 */     ClientHttpRequestFactory unwrapped = unwrapRequestFactoryIfNecessary(requestFactory);
/*  81 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*  82 */     Objects.requireNonNull(settings); map.from(settings::connectTimeout).to(connectTimeout -> setConnectTimeout(unwrapped, connectTimeout));
/*  83 */     Objects.requireNonNull(settings); map.from(settings::readTimeout).to(readTimeout -> setReadTimeout(unwrapped, readTimeout));
/*     */   }
/*     */   
/*     */   private ClientHttpRequestFactory unwrapRequestFactoryIfNecessary(ClientHttpRequestFactory requestFactory) {
/*  87 */     if (!(requestFactory instanceof AbstractClientHttpRequestFactoryWrapper)) {
/*  88 */       return requestFactory;
/*     */     }
/*  90 */     Field field = ReflectionUtils.findField(AbstractClientHttpRequestFactoryWrapper.class, "requestFactory");
/*  91 */     ReflectionUtils.makeAccessible(field);
/*  92 */     ClientHttpRequestFactory unwrappedRequestFactory = requestFactory;
/*  93 */     while (unwrappedRequestFactory instanceof AbstractClientHttpRequestFactoryWrapper) {
/*  94 */       unwrappedRequestFactory = (ClientHttpRequestFactory)ReflectionUtils.getField(field, unwrappedRequestFactory);
/*     */     }
/*     */     
/*  97 */     return unwrappedRequestFactory;
/*     */   }
/*     */   
/*     */   private void setConnectTimeout(ClientHttpRequestFactory factory, Duration connectTimeout) {
/* 101 */     Method method = tryFindMethod(factory, "setConnectTimeout", new Class[] { Duration.class });
/* 102 */     if (method != null) {
/* 103 */       invoke(factory, method, new Object[] { connectTimeout });
/*     */       return;
/*     */     } 
/* 106 */     method = findMethod(factory, "setConnectTimeout", new Class[] { int.class });
/* 107 */     int timeout = Math.toIntExact(connectTimeout.toMillis());
/* 108 */     invoke(factory, method, new Object[] { Integer.valueOf(timeout) });
/*     */   }
/*     */   
/*     */   private void setReadTimeout(ClientHttpRequestFactory factory, Duration readTimeout) {
/* 112 */     Method method = tryFindMethod(factory, "setReadTimeout", new Class[] { Duration.class });
/* 113 */     if (method != null) {
/* 114 */       invoke(factory, method, new Object[] { readTimeout });
/*     */       return;
/*     */     } 
/* 117 */     method = findMethod(factory, "setReadTimeout", new Class[] { int.class });
/* 118 */     int timeout = Math.toIntExact(readTimeout.toMillis());
/* 119 */     invoke(factory, method, new Object[] { Integer.valueOf(timeout) });
/*     */   }
/*     */   
/*     */   private Method findMethod(ClientHttpRequestFactory requestFactory, String methodName, Class<?>... parameters) {
/* 123 */     Method method = ReflectionUtils.findMethod(requestFactory.getClass(), methodName, parameters);
/* 124 */     Assert.state((method != null), () -> "Request factory %s does not have a suitable %s method".formatted(new Object[] { requestFactory.getClass().getName(), methodName }));
/*     */     
/* 126 */     Assert.state(!method.isAnnotationPresent((Class)Deprecated.class), () -> "Request factory %s has the %s method marked as deprecated".formatted(new Object[] { requestFactory.getClass().getName(), methodName }));
/*     */ 
/*     */     
/* 129 */     return method;
/*     */   }
/*     */   
/*     */   private Method tryFindMethod(ClientHttpRequestFactory requestFactory, String methodName, Class<?>... parameters) {
/* 133 */     Method method = ReflectionUtils.findMethod(requestFactory.getClass(), methodName, parameters);
/* 134 */     if (method == null) {
/* 135 */       return null;
/*     */     }
/* 137 */     if (method.isAnnotationPresent((Class)Deprecated.class)) {
/* 138 */       return null;
/*     */     }
/* 140 */     return method;
/*     */   }
/*     */   
/*     */   private void invoke(ClientHttpRequestFactory requestFactory, Method method, Object... parameters) {
/* 144 */     ReflectionUtils.invokeMethod(method, requestFactory, parameters);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\ReflectiveComponentsClientHttpRequestFactoryBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */