/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.time.Duration;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.ReflectionHints;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.aot.hint.TypeHint;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ import org.springframework.http.client.AbstractClientHttpRequestFactoryWrapper;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
/*     */ import org.springframework.http.client.JdkClientHttpRequestFactory;
/*     */ import org.springframework.http.client.JettyClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ReactorClientHttpRequestFactory;
/*     */ import org.springframework.http.client.SimpleClientHttpRequestFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClientHttpRequestFactoryRuntimeHints
/*     */   implements RuntimeHintsRegistrar
/*     */ {
/*     */   public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/*  50 */     if (ClassUtils.isPresent("org.springframework.http.client.ClientHttpRequestFactory", classLoader)) {
/*  51 */       registerHints(hints.reflection(), classLoader);
/*     */     }
/*     */   }
/*     */   
/*     */   private void registerHints(ReflectionHints hints, ClassLoader classLoader) {
/*  56 */     hints.registerField(findField(AbstractClientHttpRequestFactoryWrapper.class, "requestFactory"));
/*  57 */     registerClientHttpRequestFactoryHints(hints, classLoader, "org.apache.hc.client5.http.impl.classic.HttpClients", () -> registerReflectionHints(hints, (Class)HttpComponentsClientHttpRequestFactory.class));
/*     */ 
/*     */     
/*  60 */     registerClientHttpRequestFactoryHints(hints, classLoader, "org.eclipse.jetty.client.HttpClient", () -> registerReflectionHints(hints, (Class)JettyClientHttpRequestFactory.class, long.class));
/*     */ 
/*     */     
/*  63 */     registerClientHttpRequestFactoryHints(hints, classLoader, "reactor.netty.http.client.HttpClient", () -> registerReflectionHints(hints, (Class)ReactorClientHttpRequestFactory.class, long.class));
/*     */ 
/*     */     
/*  66 */     registerClientHttpRequestFactoryHints(hints, classLoader, "java.net.http.HttpClient", () -> registerReflectionHints(hints, (Class)JdkClientHttpRequestFactory.class));
/*     */ 
/*     */     
/*  69 */     hints.registerType(SimpleClientHttpRequestFactory.class, typeHint -> {
/*     */           typeHint.onReachableType(HttpURLConnection.class);
/*     */           registerReflectionHints(hints, (Class)SimpleClientHttpRequestFactory.class);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerClientHttpRequestFactoryHints(ReflectionHints hints, ClassLoader classLoader, String className, Runnable action) {
/*  77 */     hints.registerTypeIfPresent(classLoader, className, typeHint -> {
/*     */           typeHint.onReachableType(TypeReference.of(className));
/*     */           action.run();
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerReflectionHints(ReflectionHints hints, Class<? extends ClientHttpRequestFactory> requestFactoryType) {
/*  85 */     registerReflectionHints(hints, requestFactoryType, int.class);
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerReflectionHints(ReflectionHints hints, Class<? extends ClientHttpRequestFactory> requestFactoryType, Class<?> readTimeoutType) {
/*  90 */     registerMethod(hints, requestFactoryType, "setConnectTimeout", new Class[] { int.class });
/*  91 */     registerMethod(hints, requestFactoryType, "setConnectTimeout", new Class[] { Duration.class });
/*  92 */     registerMethod(hints, requestFactoryType, "setReadTimeout", new Class[] { readTimeoutType });
/*  93 */     registerMethod(hints, requestFactoryType, "setReadTimeout", new Class[] { Duration.class });
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerMethod(ReflectionHints hints, Class<? extends ClientHttpRequestFactory> requestFactoryType, String methodName, Class<?>... parameterTypes) {
/*  98 */     Method method = ReflectionUtils.findMethod(requestFactoryType, methodName, parameterTypes);
/*  99 */     if (method != null) {
/* 100 */       hints.registerMethod(method, ExecutableMode.INVOKE);
/*     */     }
/*     */   }
/*     */   
/*     */   private Field findField(Class<?> type, String name) {
/* 105 */     Field field = ReflectionUtils.findField(type, name);
/* 106 */     Assert.state((field != null), () -> "Unable to find field '%s' on %s".formatted(new Object[] { type.getName(), name }));
/* 107 */     return field;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\ClientHttpRequestFactoryRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */