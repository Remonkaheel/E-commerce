/*     */ package org.springframework.boot.http.client.reactive;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.apache.hc.client5.http.config.ConnectionConfig;
/*     */ import org.apache.hc.client5.http.config.RequestConfig;
/*     */ import org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient;
/*     */ import org.apache.hc.client5.http.impl.async.HttpAsyncClientBuilder;
/*     */ import org.apache.hc.client5.http.impl.nio.PoolingAsyncClientConnectionManagerBuilder;
/*     */ import org.apache.hc.core5.http.nio.ssl.TlsStrategy;
/*     */ import org.springframework.boot.http.client.HttpComponentsHttpAsyncClientBuilder;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.http.client.reactive.ClientHttpConnector;
/*     */ import org.springframework.http.client.reactive.HttpComponentsClientHttpConnector;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpComponentsClientHttpConnectorBuilder
/*     */   extends AbstractClientHttpConnectorBuilder<HttpComponentsClientHttpConnector>
/*     */ {
/*     */   private final HttpComponentsHttpAsyncClientBuilder httpClientBuilder;
/*     */   
/*     */   HttpComponentsClientHttpConnectorBuilder() {
/*  48 */     this((List<Consumer<HttpComponentsClientHttpConnector>>)null, new HttpComponentsHttpAsyncClientBuilder());
/*     */   }
/*     */ 
/*     */   
/*     */   private HttpComponentsClientHttpConnectorBuilder(List<Consumer<HttpComponentsClientHttpConnector>> customizers, HttpComponentsHttpAsyncClientBuilder httpClientBuilder) {
/*  53 */     super(customizers);
/*  54 */     this.httpClientBuilder = httpClientBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpConnectorBuilder withHttpClientCustomizer(Consumer<HttpAsyncClientBuilder> httpClientCustomizer) {
/*  65 */     Assert.notNull(httpClientCustomizer, "'customizer' must not be null");
/*  66 */     return new HttpComponentsClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/*  67 */         .withCustomizer(httpClientCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpConnectorBuilder withConnectionManagerCustomizer(Consumer<PoolingAsyncClientConnectionManagerBuilder> connectionManagerCustomizer) {
/*  79 */     Assert.notNull(connectionManagerCustomizer, "'connectionManagerCustomizer' must not be null");
/*  80 */     return new HttpComponentsClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/*  81 */         .withConnectionManagerCustomizer(connectionManagerCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpConnectorBuilder withConnectionConfigCustomizer(Consumer<ConnectionConfig.Builder> connectionConfigCustomizer) {
/*  93 */     Assert.notNull(connectionConfigCustomizer, "'connectionConfigCustomizer' must not be null");
/*  94 */     return new HttpComponentsClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/*  95 */         .withConnectionConfigCustomizer(connectionConfigCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpConnectorBuilder withTlsSocketStrategyFactory(Function<SslBundle, TlsStrategy> tlsStrategyFactory) {
/* 107 */     Assert.notNull(tlsStrategyFactory, "'tlsStrategyFactory' must not be null");
/* 108 */     return new HttpComponentsClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/* 109 */         .withTlsStrategyFactory(tlsStrategyFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpConnectorBuilder withDefaultRequestConfigCustomizer(Consumer<RequestConfig.Builder> defaultRequestConfigCustomizer) {
/* 122 */     Assert.notNull(defaultRequestConfigCustomizer, "'defaultRequestConfigCustomizer' must not be null");
/* 123 */     return new HttpComponentsClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/* 124 */         .withDefaultRequestConfigCustomizer(defaultRequestConfigCustomizer));
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpComponentsClientHttpConnector createClientHttpConnector(ClientHttpConnectorSettings settings) {
/* 129 */     CloseableHttpAsyncClient client = this.httpClientBuilder.build(asHttpClientSettings(settings));
/* 130 */     return new HttpComponentsClientHttpConnector(client);
/*     */   }
/*     */ 
/*     */   
/*     */   static class Classes
/*     */   {
/*     */     static final String HTTP_CLIENTS = "org.apache.hc.client5.http.impl.async.HttpAsyncClients";
/*     */     static final String REACTIVE_RESPONSE_CONSUMER = "org.apache.hc.core5.reactive.ReactiveResponseConsumer";
/*     */     
/*     */     static boolean present(ClassLoader classLoader) {
/* 140 */       return (ClassUtils.isPresent("org.apache.hc.client5.http.impl.async.HttpAsyncClients", classLoader) && 
/* 141 */         ClassUtils.isPresent("org.apache.hc.core5.reactive.ReactiveResponseConsumer", classLoader));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\reactive\HttpComponentsClientHttpConnectorBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */