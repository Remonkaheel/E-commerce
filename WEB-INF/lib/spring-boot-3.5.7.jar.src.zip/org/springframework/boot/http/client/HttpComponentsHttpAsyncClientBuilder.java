/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.apache.hc.client5.http.config.ConnectionConfig;
/*     */ import org.apache.hc.client5.http.config.RequestConfig;
/*     */ import org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient;
/*     */ import org.apache.hc.client5.http.impl.async.HttpAsyncClientBuilder;
/*     */ import org.apache.hc.client5.http.impl.nio.PoolingAsyncClientConnectionManager;
/*     */ import org.apache.hc.client5.http.impl.nio.PoolingAsyncClientConnectionManagerBuilder;
/*     */ import org.apache.hc.client5.http.nio.AsyncClientConnectionManager;
/*     */ import org.apache.hc.core5.http.nio.ssl.TlsStrategy;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpComponentsHttpAsyncClientBuilder
/*     */ {
/*     */   private final Consumer<HttpAsyncClientBuilder> customizer;
/*     */   private final Consumer<PoolingAsyncClientConnectionManagerBuilder> connectionManagerCustomizer;
/*     */   private final Consumer<ConnectionConfig.Builder> connectionConfigCustomizer;
/*     */   private final Consumer<RequestConfig.Builder> defaultRequestConfigCustomizer;
/*     */   private final Function<SslBundle, TlsStrategy> tlsStrategyFactory;
/*     */   
/*     */   public HttpComponentsHttpAsyncClientBuilder() {
/*  60 */     this(Empty.consumer(), Empty.consumer(), Empty.consumer(), Empty.consumer(), HttpComponentsSslBundleTlsStrategy::get);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpComponentsHttpAsyncClientBuilder(Consumer<HttpAsyncClientBuilder> customizer, Consumer<PoolingAsyncClientConnectionManagerBuilder> connectionManagerCustomizer, Consumer<ConnectionConfig.Builder> connectionConfigCustomizer, Consumer<RequestConfig.Builder> defaultRequestConfigCustomizer, Function<SslBundle, TlsStrategy> tlsStrategyFactory) {
/*  69 */     this.customizer = customizer;
/*  70 */     this.connectionManagerCustomizer = connectionManagerCustomizer;
/*  71 */     this.connectionConfigCustomizer = connectionConfigCustomizer;
/*  72 */     this.defaultRequestConfigCustomizer = defaultRequestConfigCustomizer;
/*  73 */     this.tlsStrategyFactory = tlsStrategyFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsHttpAsyncClientBuilder withCustomizer(Consumer<HttpAsyncClientBuilder> customizer) {
/*  83 */     Assert.notNull(customizer, "'customizer' must not be null");
/*  84 */     return new HttpComponentsHttpAsyncClientBuilder(this.customizer.andThen(customizer), this.connectionManagerCustomizer, this.connectionConfigCustomizer, this.defaultRequestConfigCustomizer, this.tlsStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsHttpAsyncClientBuilder withConnectionManagerCustomizer(Consumer<PoolingAsyncClientConnectionManagerBuilder> connectionManagerCustomizer) {
/*  97 */     Assert.notNull(connectionManagerCustomizer, "'connectionManagerCustomizer' must not be null");
/*  98 */     return new HttpComponentsHttpAsyncClientBuilder(this.customizer, this.connectionManagerCustomizer
/*  99 */         .andThen(connectionManagerCustomizer), this.connectionConfigCustomizer, this.defaultRequestConfigCustomizer, this.tlsStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsHttpAsyncClientBuilder withConnectionConfigCustomizer(Consumer<ConnectionConfig.Builder> connectionConfigCustomizer) {
/* 112 */     Assert.notNull(connectionConfigCustomizer, "'connectionConfigCustomizer' must not be null");
/* 113 */     return new HttpComponentsHttpAsyncClientBuilder(this.customizer, this.connectionManagerCustomizer, this.connectionConfigCustomizer
/* 114 */         .andThen(connectionConfigCustomizer), this.defaultRequestConfigCustomizer, this.tlsStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsHttpAsyncClientBuilder withTlsStrategyFactory(Function<SslBundle, TlsStrategy> tlsStrategyFactory) {
/* 127 */     Assert.notNull(tlsStrategyFactory, "'tlsStrategyFactory' must not be null");
/* 128 */     return new HttpComponentsHttpAsyncClientBuilder(this.customizer, this.connectionManagerCustomizer, this.connectionConfigCustomizer, this.defaultRequestConfigCustomizer, tlsStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsHttpAsyncClientBuilder withDefaultRequestConfigCustomizer(Consumer<RequestConfig.Builder> defaultRequestConfigCustomizer) {
/* 142 */     Assert.notNull(defaultRequestConfigCustomizer, "'defaultRequestConfigCustomizer' must not be null");
/* 143 */     return new HttpComponentsHttpAsyncClientBuilder(this.customizer, this.connectionManagerCustomizer, this.connectionConfigCustomizer, this.defaultRequestConfigCustomizer
/*     */         
/* 145 */         .andThen(defaultRequestConfigCustomizer), this.tlsStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CloseableHttpAsyncClient build(HttpClientSettings settings) {
/* 154 */     settings = (settings != null) ? settings : HttpClientSettings.DEFAULTS;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     HttpAsyncClientBuilder builder = HttpAsyncClientBuilder.create().useSystemProperties().setRedirectStrategy(HttpComponentsRedirectStrategy.get(settings.redirects())).setConnectionManager((AsyncClientConnectionManager)createConnectionManager(settings)).setDefaultRequestConfig(createDefaultRequestConfig());
/* 160 */     this.customizer.accept(builder);
/* 161 */     return builder.build();
/*     */   }
/*     */ 
/*     */   
/*     */   private PoolingAsyncClientConnectionManager createConnectionManager(HttpClientSettings settings) {
/* 166 */     PoolingAsyncClientConnectionManagerBuilder builder = PoolingAsyncClientConnectionManagerBuilder.create().useSystemProperties();
/* 167 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 168 */     builder.setDefaultConnectionConfig(createConnectionConfig(settings));
/* 169 */     Objects.requireNonNull(settings); Objects.requireNonNull(builder); map.from(settings::sslBundle).as(this.tlsStrategyFactory).to(builder::setTlsStrategy);
/* 170 */     this.connectionManagerCustomizer.accept(builder);
/* 171 */     return builder.build();
/*     */   }
/*     */   
/*     */   private ConnectionConfig createConnectionConfig(HttpClientSettings settings) {
/* 175 */     ConnectionConfig.Builder builder = ConnectionConfig.custom();
/* 176 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 177 */     Objects.requireNonNull(settings); map.from(settings::connectTimeout)
/* 178 */       .as(Duration::toMillis)
/* 179 */       .to(timeout -> builder.setConnectTimeout(timeout.longValue(), TimeUnit.MILLISECONDS));
/* 180 */     Objects.requireNonNull(settings); map.from(settings::readTimeout)
/* 181 */       .asInt(Duration::toMillis)
/* 182 */       .to(timeout -> builder.setSocketTimeout(timeout.intValue(), TimeUnit.MILLISECONDS));
/* 183 */     this.connectionConfigCustomizer.accept(builder);
/* 184 */     return builder.build();
/*     */   }
/*     */   
/*     */   private RequestConfig createDefaultRequestConfig() {
/* 188 */     RequestConfig.Builder builder = RequestConfig.custom();
/* 189 */     this.defaultRequestConfigCustomizer.accept(builder);
/* 190 */     return builder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\HttpComponentsHttpAsyncClientBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */