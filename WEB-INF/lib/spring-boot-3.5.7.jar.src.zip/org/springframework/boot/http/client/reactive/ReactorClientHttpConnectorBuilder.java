/*     */ package org.springframework.boot.http.client.reactive;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.function.UnaryOperator;
/*     */ import org.springframework.boot.http.client.ReactorHttpClientBuilder;
/*     */ import org.springframework.http.client.ReactorResourceFactory;
/*     */ import org.springframework.http.client.reactive.ClientHttpConnector;
/*     */ import org.springframework.http.client.reactive.ReactorClientHttpConnector;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReactorClientHttpConnectorBuilder
/*     */   extends AbstractClientHttpConnectorBuilder<ReactorClientHttpConnector>
/*     */ {
/*     */   private final ReactorHttpClientBuilder httpClientBuilder;
/*     */   
/*     */   ReactorClientHttpConnectorBuilder() {
/*  45 */     this((List<Consumer<ReactorClientHttpConnector>>)null, new ReactorHttpClientBuilder());
/*     */   }
/*     */ 
/*     */   
/*     */   private ReactorClientHttpConnectorBuilder(List<Consumer<ReactorClientHttpConnector>> customizers, ReactorHttpClientBuilder httpClientBuilder) {
/*  50 */     super(customizers);
/*  51 */     this.httpClientBuilder = httpClientBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public ReactorClientHttpConnectorBuilder withCustomizer(Consumer<ReactorClientHttpConnector> customizer) {
/*  56 */     return new ReactorClientHttpConnectorBuilder(mergedCustomizers(customizer), this.httpClientBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpConnectorBuilder withCustomizers(Collection<Consumer<ReactorClientHttpConnector>> customizers) {
/*  62 */     return new ReactorClientHttpConnectorBuilder(mergedCustomizers(customizers), this.httpClientBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpConnectorBuilder withReactorResourceFactory(ReactorResourceFactory reactorResourceFactory) {
/*  72 */     Assert.notNull(reactorResourceFactory, "'reactorResourceFactory' must not be null");
/*  73 */     return new ReactorClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/*  74 */         .withReactorResourceFactory(reactorResourceFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpConnectorBuilder withHttpClientFactory(Supplier<HttpClient> factory) {
/*  84 */     Assert.notNull(factory, "'factory' must not be null");
/*  85 */     return new ReactorClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/*  86 */         .withHttpClientFactory(factory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpConnectorBuilder withHttpClientCustomizer(UnaryOperator<HttpClient> httpClientCustomizer) {
/*  96 */     Assert.notNull(httpClientCustomizer, "'httpClientCustomizer' must not be null");
/*  97 */     return new ReactorClientHttpConnectorBuilder(getCustomizers(), this.httpClientBuilder
/*  98 */         .withHttpClientCustomizer(httpClientCustomizer));
/*     */   }
/*     */ 
/*     */   
/*     */   protected ReactorClientHttpConnector createClientHttpConnector(ClientHttpConnectorSettings settings) {
/* 103 */     HttpClient httpClient = this.httpClientBuilder.build(asHttpClientSettings(settings));
/* 104 */     return new ReactorClientHttpConnector(httpClient);
/*     */   }
/*     */   
/*     */   static class Classes
/*     */   {
/*     */     static final String HTTP_CLIENT = "reactor.netty.http.client.HttpClient";
/*     */     
/*     */     static boolean present(ClassLoader classLoader) {
/* 112 */       return ClassUtils.isPresent("reactor.netty.http.client.HttpClient", classLoader);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\reactive\ReactorClientHttpConnectorBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */