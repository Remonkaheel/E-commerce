/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClientHttpRequestFactorySettings
/*     */   extends Record
/*     */ {
/*     */   private final Redirects redirects;
/*     */   private final Duration connectTimeout;
/*     */   private final Duration readTimeout;
/*     */   private final SslBundle sslBundle;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lorg/springframework/boot/http/client/ClientHttpRequestFactorySettings;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #38	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/boot/http/client/ClientHttpRequestFactorySettings;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/http/client/ClientHttpRequestFactorySettings;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #38	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/boot/http/client/ClientHttpRequestFactorySettings;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lorg/springframework/boot/http/client/ClientHttpRequestFactorySettings;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #38	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lorg/springframework/boot/http/client/ClientHttpRequestFactorySettings;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   public Redirects redirects() {
/*  38 */     return this.redirects; } public Duration connectTimeout() { return this.connectTimeout; } public Duration readTimeout() { return this.readTimeout; } public SslBundle sslBundle() { return this.sslBundle; }
/*     */ 
/*     */   
/*  41 */   private static final ClientHttpRequestFactorySettings defaults = new ClientHttpRequestFactorySettings(null, null, null, null);
/*     */ 
/*     */   
/*     */   public ClientHttpRequestFactorySettings(Redirects redirects, Duration connectTimeout, Duration readTimeout, SslBundle sslBundle) {
/*  45 */     redirects = (redirects != null) ? redirects : Redirects.FOLLOW_WHEN_POSSIBLE;
/*     */     this.redirects = redirects;
/*     */     this.connectTimeout = connectTimeout;
/*     */     this.readTimeout = readTimeout;
/*     */     this.sslBundle = sslBundle;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequestFactorySettings withConnectTimeout(Duration connectTimeout) {
/*  55 */     return new ClientHttpRequestFactorySettings(this.redirects, connectTimeout, this.readTimeout, this.sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequestFactorySettings withReadTimeout(Duration readTimeout) {
/*  65 */     return new ClientHttpRequestFactorySettings(this.redirects, this.connectTimeout, readTimeout, this.sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequestFactorySettings withTimeouts(Duration connectTimeout, Duration readTimeout) {
/*  76 */     return new ClientHttpRequestFactorySettings(this.redirects, connectTimeout, readTimeout, this.sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequestFactorySettings withSslBundle(SslBundle sslBundle) {
/*  86 */     return new ClientHttpRequestFactorySettings(this.redirects, this.connectTimeout, this.readTimeout, sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequestFactorySettings withRedirects(Redirects redirects) {
/*  96 */     return new ClientHttpRequestFactorySettings(redirects, this.connectTimeout, this.readTimeout, this.sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientHttpRequestFactorySettings ofSslBundle(SslBundle sslBundle) {
/* 106 */     return defaults().withSslBundle(sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientHttpRequestFactorySettings defaults() {
/* 115 */     return defaults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Redirects
/*     */   {
/* 126 */     FOLLOW_WHEN_POSSIBLE((String)HttpRedirects.FOLLOW_WHEN_POSSIBLE),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     FOLLOW((String)HttpRedirects.FOLLOW),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     DONT_FOLLOW((String)HttpRedirects.DONT_FOLLOW);
/*     */     
/*     */     private final HttpRedirects httpClientRedirects;
/*     */     
/*     */     Redirects(HttpRedirects httpClientRedirects) {
/* 141 */       this.httpClientRedirects = httpClientRedirects;
/*     */     }
/*     */     
/*     */     HttpRedirects httpClientRedirects() {
/* 145 */       return this.httpClientRedirects;
/*     */     }
/*     */     
/*     */     public static Redirects of(HttpRedirects httpRedirects) {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: ifnull -> 66
/*     */       //   4: getstatic org/springframework/boot/http/client/ClientHttpRequestFactorySettings$1.$SwitchMap$org$springframework$boot$http$client$HttpRedirects : [I
/*     */       //   7: aload_0
/*     */       //   8: invokevirtual ordinal : ()I
/*     */       //   11: iaload
/*     */       //   12: tableswitch default -> 40, 1 -> 48, 2 -> 54, 3 -> 60
/*     */       //   40: new java/lang/IncompatibleClassChangeError
/*     */       //   43: dup
/*     */       //   44: invokespecial <init> : ()V
/*     */       //   47: athrow
/*     */       //   48: getstatic org/springframework/boot/http/client/ClientHttpRequestFactorySettings$Redirects.FOLLOW_WHEN_POSSIBLE : Lorg/springframework/boot/http/client/ClientHttpRequestFactorySettings$Redirects;
/*     */       //   51: goto -> 67
/*     */       //   54: getstatic org/springframework/boot/http/client/ClientHttpRequestFactorySettings$Redirects.FOLLOW : Lorg/springframework/boot/http/client/ClientHttpRequestFactorySettings$Redirects;
/*     */       //   57: goto -> 67
/*     */       //   60: getstatic org/springframework/boot/http/client/ClientHttpRequestFactorySettings$Redirects.DONT_FOLLOW : Lorg/springframework/boot/http/client/ClientHttpRequestFactorySettings$Redirects;
/*     */       //   63: goto -> 67
/*     */       //   66: aconst_null
/*     */       //   67: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #155	-> 0
/*     */       //   #156	-> 48
/*     */       //   #157	-> 54
/*     */       //   #158	-> 60
/*     */       //   #159	-> 66
/*     */       //   #155	-> 67
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	68	0	httpRedirects	Lorg/springframework/boot/http/client/HttpRedirects;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\ClientHttpRequestFactorySettings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */