/*    */ package org.springframework.boot.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.HttpURLConnection;
/*    */ import javax.net.ssl.HttpsURLConnection;
/*    */ import javax.net.ssl.SSLSocketFactory;
/*    */ import org.springframework.http.client.SimpleClientHttpRequestFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SimpleClientHttpsRequestFactory
/*    */   extends SimpleClientHttpRequestFactory
/*    */ {
/*    */   private final ClientHttpRequestFactorySettings settings;
/*    */   
/*    */   SimpleClientHttpsRequestFactory(ClientHttpRequestFactorySettings settings) {
/* 86 */     this.settings = settings;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void prepareConnection(HttpURLConnection connection, String httpMethod) throws IOException {
/* 91 */     super.prepareConnection(connection, httpMethod);
/* 92 */     if (this.settings.sslBundle() != null && connection instanceof HttpsURLConnection) { HttpsURLConnection secureConnection = (HttpsURLConnection)connection;
/* 93 */       SSLSocketFactory socketFactory = this.settings.sslBundle().createSslContext().getSocketFactory();
/* 94 */       secureConnection.setSSLSocketFactory(socketFactory); }
/*    */     
/* 96 */     if (this.settings.redirects() == ClientHttpRequestFactorySettings.Redirects.DONT_FOLLOW)
/* 97 */       connection.setInstanceFollowRedirects(false); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\SimpleClientHttpRequestFactoryBuilder$SimpleClientHttpsRequestFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */