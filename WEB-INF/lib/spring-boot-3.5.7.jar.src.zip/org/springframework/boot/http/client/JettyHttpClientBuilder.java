/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.Consumer;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import org.eclipse.jetty.client.HttpClient;
/*     */ import org.eclipse.jetty.client.HttpClientTransport;
/*     */ import org.eclipse.jetty.client.Request;
/*     */ import org.eclipse.jetty.client.transport.HttpClientTransportDynamic;
/*     */ import org.eclipse.jetty.client.transport.HttpClientTransportOverHTTP;
/*     */ import org.eclipse.jetty.io.ClientConnector;
/*     */ import org.eclipse.jetty.util.ssl.SslContextFactory;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslOptions;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JettyHttpClientBuilder
/*     */ {
/*     */   private final Consumer<HttpClient> customizer;
/*     */   private final Consumer<HttpClientTransport> httpClientTransportCustomizer;
/*     */   private final Consumer<ClientConnector> clientConnectorCustomizerCustomizer;
/*     */   
/*     */   public JettyHttpClientBuilder() {
/*  55 */     this(Empty.consumer(), Empty.consumer(), Empty.consumer());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JettyHttpClientBuilder(Consumer<HttpClient> customizer, Consumer<HttpClientTransport> httpClientTransportCustomizer, Consumer<ClientConnector> clientConnectorCustomizerCustomizer) {
/*  61 */     this.customizer = customizer;
/*  62 */     this.httpClientTransportCustomizer = httpClientTransportCustomizer;
/*  63 */     this.clientConnectorCustomizerCustomizer = clientConnectorCustomizerCustomizer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyHttpClientBuilder withCustomizer(Consumer<HttpClient> customizer) {
/*  73 */     Assert.notNull(customizer, "'customizer' must not be null");
/*  74 */     return new JettyHttpClientBuilder(this.customizer.andThen(customizer), this.httpClientTransportCustomizer, this.clientConnectorCustomizerCustomizer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyHttpClientBuilder withHttpClientTransportCustomizer(Consumer<HttpClientTransport> httpClientTransportCustomizer) {
/*  86 */     Assert.notNull(httpClientTransportCustomizer, "'httpClientTransportCustomizer' must not be null");
/*  87 */     return new JettyHttpClientBuilder(this.customizer, this.httpClientTransportCustomizer
/*  88 */         .andThen(httpClientTransportCustomizer), this.clientConnectorCustomizerCustomizer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyHttpClientBuilder withClientConnectorCustomizerCustomizer(Consumer<ClientConnector> clientConnectorCustomizerCustomizer) {
/* 100 */     Assert.notNull(clientConnectorCustomizerCustomizer, "'clientConnectorCustomizerCustomizer' must not be null");
/* 101 */     return new JettyHttpClientBuilder(this.customizer, this.httpClientTransportCustomizer, this.clientConnectorCustomizerCustomizer
/* 102 */         .andThen(clientConnectorCustomizerCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClient build(HttpClientSettings settings) {
/* 111 */     settings = (settings != null) ? settings : HttpClientSettings.DEFAULTS;
/* 112 */     HttpClientTransport transport = createTransport(settings);
/* 113 */     this.httpClientTransportCustomizer.accept(transport);
/* 114 */     HttpClient httpClient = createHttpClient(settings.readTimeout(), transport);
/* 115 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 116 */     Objects.requireNonNull(settings); Objects.requireNonNull(httpClient); map.from(settings::connectTimeout).as(Duration::toMillis).to(httpClient::setConnectTimeout);
/* 117 */     Objects.requireNonNull(settings); Objects.requireNonNull(httpClient); map.from(settings::redirects).as(this::followRedirects).to(httpClient::setFollowRedirects);
/* 118 */     this.customizer.accept(httpClient);
/* 119 */     return httpClient;
/*     */   }
/*     */   
/*     */   private HttpClient createHttpClient(Duration readTimeout, HttpClientTransport transport) {
/* 123 */     return (readTimeout != null) ? new HttpClientWithReadTimeout(transport, readTimeout) : 
/* 124 */       new HttpClient(transport);
/*     */   }
/*     */   
/*     */   private HttpClientTransport createTransport(HttpClientSettings settings) {
/* 128 */     ClientConnector connector = createClientConnector(settings.sslBundle());
/* 129 */     return (connector.getSslContextFactory() != null) ? (HttpClientTransport)new HttpClientTransportDynamic(connector, new org.eclipse.jetty.io.ClientConnectionFactory.Info[0]) : 
/* 130 */       (HttpClientTransport)new HttpClientTransportOverHTTP(connector);
/*     */   }
/*     */   
/*     */   private ClientConnector createClientConnector(SslBundle sslBundle) {
/* 134 */     ClientConnector connector = new ClientConnector();
/* 135 */     if (sslBundle != null) {
/* 136 */       connector.setSslContextFactory(createSslContextFactory(sslBundle));
/*     */     }
/* 138 */     this.clientConnectorCustomizerCustomizer.accept(connector);
/* 139 */     return connector;
/*     */   }
/*     */   
/*     */   private SslContextFactory.Client createSslContextFactory(SslBundle sslBundle) {
/* 143 */     SslOptions options = sslBundle.getOptions();
/* 144 */     SSLContext sslContext = sslBundle.createSslContext();
/* 145 */     SslContextFactory.Client factory = new SslContextFactory.Client();
/* 146 */     factory.setSslContext(sslContext);
/* 147 */     if (options.getCiphers() != null) {
/* 148 */       factory.setIncludeCipherSuites(options.getCiphers());
/* 149 */       factory.setExcludeCipherSuites(new String[0]);
/*     */     } 
/* 151 */     if (options.getEnabledProtocols() != null) {
/* 152 */       factory.setIncludeProtocols(options.getEnabledProtocols());
/* 153 */       factory.setExcludeProtocols(new String[0]);
/*     */     } 
/* 155 */     return factory;
/*     */   }
/*     */   
/*     */   private boolean followRedirects(HttpRedirects redirects) {
/* 159 */     switch (redirects) { default: throw new IncompatibleClassChangeError();case FOLLOW_WHEN_POSSIBLE: case FOLLOW: case DONT_FOLLOW: break; }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class HttpClientWithReadTimeout
/*     */     extends HttpClient
/*     */   {
/*     */     private final Duration readTimeout;
/*     */ 
/*     */ 
/*     */     
/*     */     HttpClientWithReadTimeout(HttpClientTransport transport, Duration readTimeout) {
/* 173 */       super(transport);
/* 174 */       this.readTimeout = readTimeout;
/*     */     }
/*     */ 
/*     */     
/*     */     public Request newRequest(URI uri) {
/* 179 */       Request request = super.newRequest(uri);
/* 180 */       request.timeout(this.readTimeout.toMillis(), TimeUnit.MILLISECONDS);
/* 181 */       return request;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\JettyHttpClientBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */