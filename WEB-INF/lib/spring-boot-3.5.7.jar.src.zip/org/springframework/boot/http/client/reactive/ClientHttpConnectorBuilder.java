/*     */ package org.springframework.boot.http.client.reactive;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.boot.util.LambdaSafe;
/*     */ import org.springframework.http.client.reactive.ClientHttpConnector;
/*     */ import org.springframework.http.client.reactive.HttpComponentsClientHttpConnector;
/*     */ import org.springframework.http.client.reactive.JdkClientHttpConnector;
/*     */ import org.springframework.http.client.reactive.JettyClientHttpConnector;
/*     */ import org.springframework.http.client.reactive.ReactorClientHttpConnector;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface ClientHttpConnectorBuilder<T extends ClientHttpConnector>
/*     */ {
/*     */   default T build() {
/*  50 */     return build(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ClientHttpConnectorBuilder<T> withCustomizer(Consumer<T> customizer) {
/*  68 */     return withCustomizers(List.of(customizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ClientHttpConnectorBuilder<T> withCustomizers(Collection<Consumer<T>> customizers) {
/*  79 */     Assert.notNull(customizers, "'customizers' must not be null");
/*  80 */     Assert.noNullElements(customizers, "'customizers' must not contain null elements");
/*  81 */     return settings -> {
/*     */         T factory = build(settings);
/*     */         LambdaSafe.callbacks(Consumer.class, customizers, factory, new Object[0]).invoke(());
/*     */         return (ClientHttpConnector)factory;
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpComponentsClientHttpConnectorBuilder httpComponents() {
/*  94 */     return new HttpComponentsClientHttpConnectorBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JettyClientHttpConnectorBuilder jetty() {
/* 103 */     return new JettyClientHttpConnectorBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ReactorClientHttpConnectorBuilder reactor() {
/* 112 */     return new ReactorClientHttpConnectorBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JdkClientHttpConnectorBuilder jdk() {
/* 121 */     return new JdkClientHttpConnectorBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends ClientHttpConnector> ClientHttpConnectorBuilder<T> of(Class<T> clientHttpConnectorType) {
/* 139 */     Assert.notNull(clientHttpConnectorType, "'requestFactoryType' must not be null");
/* 140 */     Assert.isTrue((clientHttpConnectorType != ClientHttpConnector.class), "'clientHttpConnectorType' must be an implementation of ClientHttpConnector");
/*     */     
/* 142 */     if (clientHttpConnectorType == ReactorClientHttpConnector.class) {
/* 143 */       return reactor();
/*     */     }
/* 145 */     if (clientHttpConnectorType == JettyClientHttpConnector.class) {
/* 146 */       return jetty();
/*     */     }
/* 148 */     if (clientHttpConnectorType == HttpComponentsClientHttpConnector.class) {
/* 149 */       return httpComponents();
/*     */     }
/* 151 */     if (clientHttpConnectorType == JdkClientHttpConnector.class) {
/* 152 */       return jdk();
/*     */     }
/* 154 */     throw new IllegalArgumentException("'clientHttpConnectorType' %s is not supported"
/* 155 */         .formatted(new Object[] { clientHttpConnectorType.getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ClientHttpConnectorBuilder<? extends ClientHttpConnector> detect() {
/* 170 */     return detect(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ClientHttpConnectorBuilder<? extends ClientHttpConnector> detect(ClassLoader classLoader) {
/* 186 */     if (ReactorClientHttpConnectorBuilder.Classes.present(classLoader)) {
/* 187 */       return reactor();
/*     */     }
/* 189 */     if (JettyClientHttpConnectorBuilder.Classes.present(classLoader)) {
/* 190 */       return jetty();
/*     */     }
/* 192 */     if (HttpComponentsClientHttpConnectorBuilder.Classes.present(classLoader)) {
/* 193 */       return httpComponents();
/*     */     }
/* 195 */     if (JdkClientHttpConnectorBuilder.Classes.present(classLoader)) {
/* 196 */       return jdk();
/*     */     }
/* 198 */     throw new IllegalStateException("Unable to detect any ClientHttpConnectorBuilder");
/*     */   }
/*     */   
/*     */   T build(ClientHttpConnectorSettings paramClientHttpConnectorSettings);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\reactive\ClientHttpConnectorBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */