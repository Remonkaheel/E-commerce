/*    */ package org.springframework.boot.http.client;
/*    */ 
/*    */ import javax.net.ssl.HostnameVerifier;
/*    */ import javax.net.ssl.SSLContext;
/*    */ import org.apache.hc.client5.http.ssl.DefaultClientTlsStrategy;
/*    */ import org.apache.hc.client5.http.ssl.DefaultHostnameVerifier;
/*    */ import org.springframework.boot.ssl.SslBundle;
/*    */ import org.springframework.boot.ssl.SslOptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HttpComponentsSslBundleTlsStrategy
/*    */ {
/*    */   static DefaultClientTlsStrategy get(SslBundle sslBundle) {
/* 40 */     if (sslBundle == null) {
/* 41 */       return null;
/*    */     }
/* 43 */     SslOptions options = sslBundle.getOptions();
/* 44 */     SSLContext sslContext = sslBundle.createSslContext();
/* 45 */     return new DefaultClientTlsStrategy(sslContext, options.getEnabledProtocols(), options.getCiphers(), null, (HostnameVerifier)new DefaultHostnameVerifier());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\HttpComponentsSslBundleTlsStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */