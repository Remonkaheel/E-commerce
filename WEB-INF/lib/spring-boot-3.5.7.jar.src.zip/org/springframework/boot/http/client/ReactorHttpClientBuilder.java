/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.handler.ssl.SslContextBuilder;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.function.UnaryOperator;
/*     */ import javax.net.ssl.SSLException;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslManagerBundle;
/*     */ import org.springframework.boot.ssl.SslOptions;
/*     */ import org.springframework.http.client.ReactorResourceFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.function.ThrowingConsumer;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ import reactor.netty.tcp.SslProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReactorHttpClientBuilder
/*     */ {
/*     */   private final Supplier<HttpClient> factory;
/*     */   private final UnaryOperator<HttpClient> customizer;
/*     */   
/*     */   public ReactorHttpClientBuilder() {
/*  53 */     this(HttpClient::create, UnaryOperator.identity());
/*     */   }
/*     */   
/*     */   private ReactorHttpClientBuilder(Supplier<HttpClient> httpClientFactory, UnaryOperator<HttpClient> customizer) {
/*  57 */     this.factory = httpClientFactory;
/*  58 */     this.customizer = customizer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorHttpClientBuilder withReactorResourceFactory(ReactorResourceFactory reactorResourceFactory) {
/*  68 */     Assert.notNull(reactorResourceFactory, "'reactorResourceFactory' must not be null");
/*  69 */     return new ReactorHttpClientBuilder(() -> HttpClient.create(reactorResourceFactory.getConnectionProvider()), httpClient -> (HttpClient)((HttpClient)this.customizer.apply(httpClient)).runOn(reactorResourceFactory.getLoopResources()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorHttpClientBuilder withHttpClientFactory(Supplier<HttpClient> factory) {
/*  80 */     Assert.notNull(factory, "'factory' must not be null");
/*  81 */     return new ReactorHttpClientBuilder(factory, this.customizer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorHttpClientBuilder withHttpClientCustomizer(UnaryOperator<HttpClient> customizer) {
/*  91 */     Assert.notNull(customizer, "'customizer' must not be null");
/*  92 */     return new ReactorHttpClientBuilder(this.factory, httpClient -> (HttpClient)customizer.apply(this.customizer.apply(httpClient)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClient build(HttpClientSettings settings) {
/* 102 */     settings = (settings != null) ? settings : HttpClientSettings.DEFAULTS;
/* 103 */     HttpClient httpClient = applyDefaults(this.factory.get());
/* 104 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 105 */     Objects.requireNonNull(settings); httpClient = (HttpClient)map.from(settings::connectTimeout).to(httpClient, this::setConnectTimeout);
/* 106 */     Objects.requireNonNull(settings); httpClient = (HttpClient)map.from(settings::readTimeout).to(httpClient, HttpClient::responseTimeout);
/* 107 */     Objects.requireNonNull(settings); httpClient = (HttpClient)map.from(settings::redirects).as(this::followRedirects).to(httpClient, HttpClient::followRedirect);
/* 108 */     Objects.requireNonNull(settings); httpClient = (HttpClient)map.from(settings::sslBundle).to(httpClient, this::secure);
/* 109 */     return this.customizer.apply(httpClient);
/*     */   }
/*     */ 
/*     */   
/*     */   HttpClient applyDefaults(HttpClient httpClient) {
/* 114 */     return httpClient.compress(true);
/*     */   }
/*     */   
/*     */   private HttpClient setConnectTimeout(HttpClient httpClient, Duration timeout) {
/* 118 */     return (HttpClient)httpClient.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, Integer.valueOf((int)timeout.toMillis()));
/*     */   }
/*     */   
/*     */   private boolean followRedirects(HttpRedirects redirects) {
/* 122 */     switch (redirects) { default: throw new IncompatibleClassChangeError();case FOLLOW_WHEN_POSSIBLE: case FOLLOW: case DONT_FOLLOW: break; }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpClient secure(HttpClient httpClient, SslBundle sslBundle) {
/* 129 */     return httpClient.secure((Consumer)ThrowingConsumer.of(spec -> configureSsl(spec, sslBundle)));
/*     */   }
/*     */   
/*     */   private void configureSsl(SslProvider.SslContextSpec spec, SslBundle sslBundle) throws SSLException {
/* 133 */     SslOptions options = sslBundle.getOptions();
/* 134 */     SslManagerBundle managers = sslBundle.getManagers();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     SslContextBuilder builder = SslContextBuilder.forClient().keyManager(managers.getKeyManagerFactory()).trustManager(managers.getTrustManagerFactory()).ciphers(SslOptions.asSet(options.getCiphers())).protocols(options.getEnabledProtocols());
/* 140 */     spec.sslContext(builder.build());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\ReactorHttpClientBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */