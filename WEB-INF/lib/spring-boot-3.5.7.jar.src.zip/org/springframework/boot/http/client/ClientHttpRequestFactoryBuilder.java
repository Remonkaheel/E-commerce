/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.boot.util.LambdaSafe;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
/*     */ import org.springframework.http.client.JdkClientHttpRequestFactory;
/*     */ import org.springframework.http.client.JettyClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ReactorClientHttpRequestFactory;
/*     */ import org.springframework.http.client.SimpleClientHttpRequestFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface ClientHttpRequestFactoryBuilder<T extends ClientHttpRequestFactory>
/*     */ {
/*     */   default T build() {
/*  53 */     return build(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ClientHttpRequestFactoryBuilder<T> withCustomizer(Consumer<T> customizer) {
/*  71 */     return withCustomizers(List.of(customizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ClientHttpRequestFactoryBuilder<T> withCustomizers(Collection<Consumer<T>> customizers) {
/*  82 */     Assert.notNull(customizers, "'customizers' must not be null");
/*  83 */     Assert.noNullElements(customizers, "'customizers' must not contain null elements");
/*  84 */     return settings -> {
/*     */         T factory = build(settings);
/*     */         LambdaSafe.callbacks(Consumer.class, customizers, factory, new Object[0]).invoke(());
/*     */         return (ClientHttpRequestFactory)factory;
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpComponentsClientHttpRequestFactoryBuilder httpComponents() {
/*  97 */     return new HttpComponentsClientHttpRequestFactoryBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JettyClientHttpRequestFactoryBuilder jetty() {
/* 106 */     return new JettyClientHttpRequestFactoryBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ReactorClientHttpRequestFactoryBuilder reactor() {
/* 115 */     return new ReactorClientHttpRequestFactoryBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JdkClientHttpRequestFactoryBuilder jdk() {
/* 124 */     return new JdkClientHttpRequestFactoryBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SimpleClientHttpRequestFactoryBuilder simple() {
/* 133 */     return new SimpleClientHttpRequestFactoryBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends ClientHttpRequestFactory> ClientHttpRequestFactoryBuilder<T> of(Class<T> requestFactoryType) {
/* 153 */     Assert.notNull(requestFactoryType, "'requestFactoryType' must not be null");
/* 154 */     Assert.isTrue((requestFactoryType != ClientHttpRequestFactory.class), "'requestFactoryType' must be an implementation of ClientHttpRequestFactory");
/*     */     
/* 156 */     if (requestFactoryType == HttpComponentsClientHttpRequestFactory.class) {
/* 157 */       return httpComponents();
/*     */     }
/* 159 */     if (requestFactoryType == JettyClientHttpRequestFactory.class) {
/* 160 */       return jetty();
/*     */     }
/* 162 */     if (requestFactoryType == ReactorClientHttpRequestFactory.class) {
/* 163 */       return reactor();
/*     */     }
/* 165 */     if (requestFactoryType == JdkClientHttpRequestFactory.class) {
/* 166 */       return jdk();
/*     */     }
/* 168 */     if (requestFactoryType == SimpleClientHttpRequestFactory.class) {
/* 169 */       return simple();
/*     */     }
/* 171 */     return new ReflectiveComponentsClientHttpRequestFactoryBuilder<>(requestFactoryType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends ClientHttpRequestFactory> ClientHttpRequestFactoryBuilder<T> of(Supplier<T> requestFactorySupplier) {
/* 183 */     return new ReflectiveComponentsClientHttpRequestFactoryBuilder<>(requestFactorySupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ClientHttpRequestFactoryBuilder<? extends ClientHttpRequestFactory> detect() {
/* 199 */     return detect(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ClientHttpRequestFactoryBuilder<? extends ClientHttpRequestFactory> detect(ClassLoader classLoader) {
/* 217 */     if (HttpComponentsClientHttpRequestFactoryBuilder.Classes.present(classLoader)) {
/* 218 */       return httpComponents();
/*     */     }
/* 220 */     if (JettyClientHttpRequestFactoryBuilder.Classes.present(classLoader)) {
/* 221 */       return jetty();
/*     */     }
/* 223 */     if (ReactorClientHttpRequestFactoryBuilder.Classes.present(classLoader)) {
/* 224 */       return reactor();
/*     */     }
/* 226 */     if (JdkClientHttpRequestFactoryBuilder.Classes.present(classLoader)) {
/* 227 */       return jdk();
/*     */     }
/* 229 */     return simple();
/*     */   }
/*     */   
/*     */   T build(ClientHttpRequestFactorySettings paramClientHttpRequestFactorySettings);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\ClientHttpRequestFactoryBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */