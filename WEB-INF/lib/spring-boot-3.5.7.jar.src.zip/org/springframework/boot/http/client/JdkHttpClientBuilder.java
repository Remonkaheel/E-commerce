/*    */ package org.springframework.boot.http.client;
/*    */ 
/*    */ import java.net.http.HttpClient;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ import javax.net.ssl.SSLParameters;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.boot.ssl.SslBundle;
/*    */ import org.springframework.boot.ssl.SslOptions;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JdkHttpClientBuilder
/*    */ {
/*    */   private final Consumer<HttpClient.Builder> customizer;
/*    */   
/*    */   public JdkHttpClientBuilder() {
/* 43 */     this(Empty.consumer());
/*    */   }
/*    */   
/*    */   private JdkHttpClientBuilder(Consumer<HttpClient.Builder> customizer) {
/* 47 */     this.customizer = customizer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JdkHttpClientBuilder withCustomizer(Consumer<HttpClient.Builder> customizer) {
/* 57 */     Assert.notNull(customizer, "'customizer' must not be null");
/* 58 */     return new JdkHttpClientBuilder(this.customizer.andThen(customizer));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpClient build(HttpClientSettings settings) {
/* 67 */     settings = (settings != null) ? settings : HttpClientSettings.DEFAULTS;
/* 68 */     Assert.isTrue((settings.readTimeout() == null), "'settings' must not have a 'readTimeout'");
/* 69 */     HttpClient.Builder builder = HttpClient.newBuilder();
/* 70 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 71 */     Objects.requireNonNull(settings); Objects.requireNonNull(builder); map.from(settings::redirects).as(this::asHttpClientRedirect).to(builder::followRedirects);
/* 72 */     Objects.requireNonNull(settings); Objects.requireNonNull(builder); map.from(settings::connectTimeout).to(builder::connectTimeout);
/* 73 */     Objects.requireNonNull(settings); Objects.requireNonNull(builder); map.from(settings::sslBundle).as(SslBundle::createSslContext).to(builder::sslContext);
/* 74 */     Objects.requireNonNull(settings); Objects.requireNonNull(builder); map.from(settings::sslBundle).as(this::asSslParameters).to(builder::sslParameters);
/* 75 */     this.customizer.accept(builder);
/* 76 */     return builder.build();
/*    */   }
/*    */   
/*    */   private SSLParameters asSslParameters(SslBundle sslBundle) {
/* 80 */     SslOptions options = sslBundle.getOptions();
/* 81 */     SSLParameters parameters = new SSLParameters();
/* 82 */     parameters.setCipherSuites(options.getCiphers());
/* 83 */     parameters.setProtocols(options.getEnabledProtocols());
/* 84 */     return parameters;
/*    */   }
/*    */   
/*    */   private HttpClient.Redirect asHttpClientRedirect(HttpRedirects redirects) {
/* 88 */     switch (redirects) { default: throw new IncompatibleClassChangeError();case FOLLOW_WHEN_POSSIBLE: case FOLLOW: case DONT_FOLLOW: break; }  return 
/*    */       
/* 90 */       HttpClient.Redirect.NEVER;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\JdkHttpClientBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */