/*    */ package org.springframework.boot.http.client;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.boot.util.LambdaSafe;
/*    */ import org.springframework.http.client.ClientHttpRequestFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractClientHttpRequestFactoryBuilder<T extends ClientHttpRequestFactory>
/*    */   implements ClientHttpRequestFactoryBuilder<T>
/*    */ {
/*    */   private final List<Consumer<T>> customizers;
/*    */   
/*    */   protected AbstractClientHttpRequestFactoryBuilder(List<Consumer<T>> customizers) {
/* 41 */     this.customizers = (customizers != null) ? customizers : Collections.<Consumer<T>>emptyList();
/*    */   }
/*    */   
/*    */   protected final List<Consumer<T>> getCustomizers() {
/* 45 */     return this.customizers;
/*    */   }
/*    */   
/*    */   protected final List<Consumer<T>> mergedCustomizers(Consumer<T> customizer) {
/* 49 */     Assert.notNull(this.customizers, "'customizer' must not be null");
/* 50 */     return merge(this.customizers, List.of(customizer));
/*    */   }
/*    */   
/*    */   protected final List<Consumer<T>> mergedCustomizers(Collection<Consumer<T>> customizers) {
/* 54 */     Assert.notNull(customizers, "'customizers' must not be null");
/* 55 */     Assert.noNullElements(customizers, "'customizers' must not contain null elements");
/* 56 */     return merge(this.customizers, customizers);
/*    */   }
/*    */   
/*    */   private <E> List<E> merge(Collection<E> list, Collection<? extends E> additional) {
/* 60 */     List<E> merged = new ArrayList<>(list);
/* 61 */     merged.addAll(additional);
/* 62 */     return List.copyOf(merged);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final T build(ClientHttpRequestFactorySettings settings) {
/* 68 */     T factory = createClientHttpRequestFactory(
/* 69 */         (settings != null) ? settings : ClientHttpRequestFactorySettings.defaults());
/* 70 */     LambdaSafe.callbacks(Consumer.class, this.customizers, factory, new Object[0]).invoke(consumer -> consumer.accept(factory));
/* 71 */     return factory;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected final HttpClientSettings asHttpClientSettings(ClientHttpRequestFactorySettings settings) {
/* 77 */     return (settings != null) ? new HttpClientSettings(settings.redirects().httpClientRedirects(), settings
/* 78 */         .connectTimeout(), settings.readTimeout(), settings.sslBundle()) : null;
/*    */   }
/*    */   
/*    */   protected abstract T createClientHttpRequestFactory(ClientHttpRequestFactorySettings paramClientHttpRequestFactorySettings);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\AbstractClientHttpRequestFactoryBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */