/*     */ package org.springframework.boot.http.client;


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\JettyHttpClientBuilder$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */