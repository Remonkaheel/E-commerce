/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.function.UnaryOperator;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ReactorClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ReactorResourceFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReactorClientHttpRequestFactoryBuilder
/*     */   extends AbstractClientHttpRequestFactoryBuilder<ReactorClientHttpRequestFactory>
/*     */ {
/*     */   private final ReactorHttpClientBuilder httpClientBuilder;
/*     */   
/*     */   ReactorClientHttpRequestFactoryBuilder() {
/*  48 */     this((List<Consumer<ReactorClientHttpRequestFactory>>)null, new ReactorHttpClientBuilder());
/*     */   }
/*     */ 
/*     */   
/*     */   private ReactorClientHttpRequestFactoryBuilder(List<Consumer<ReactorClientHttpRequestFactory>> customizers, ReactorHttpClientBuilder httpClientBuilder) {
/*  53 */     super(customizers);
/*  54 */     this.httpClientBuilder = httpClientBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public ReactorClientHttpRequestFactoryBuilder withCustomizer(Consumer<ReactorClientHttpRequestFactory> customizer) {
/*  59 */     return new ReactorClientHttpRequestFactoryBuilder(mergedCustomizers(customizer), this.httpClientBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpRequestFactoryBuilder withCustomizers(Collection<Consumer<ReactorClientHttpRequestFactory>> customizers) {
/*  65 */     return new ReactorClientHttpRequestFactoryBuilder(mergedCustomizers(customizers), this.httpClientBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpRequestFactoryBuilder withReactorResourceFactory(ReactorResourceFactory reactorResourceFactory) {
/*  77 */     Assert.notNull(reactorResourceFactory, "'reactorResourceFactory' must not be null");
/*  78 */     return new ReactorClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/*  79 */         .withReactorResourceFactory(reactorResourceFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpRequestFactoryBuilder withHttpClientFactory(Supplier<HttpClient> factory) {
/*  90 */     Assert.notNull(factory, "'factory' must not be null");
/*  91 */     return new ReactorClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/*  92 */         .withHttpClientFactory(factory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpRequestFactoryBuilder withHttpClientCustomizer(UnaryOperator<HttpClient> httpClientCustomizer) {
/* 103 */     Assert.notNull(httpClientCustomizer, "'httpClientCustomizer' must not be null");
/* 104 */     return new ReactorClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/* 105 */         .withHttpClientCustomizer(httpClientCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ReactorClientHttpRequestFactory createClientHttpRequestFactory(ClientHttpRequestFactorySettings settings) {
/* 111 */     HttpClient httpClient = this.httpClientBuilder.build(asHttpClientSettings(settings.withTimeouts(null, null)));
/* 112 */     ReactorClientHttpRequestFactory requestFactory = new ReactorClientHttpRequestFactory(httpClient);
/* 113 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 114 */     Objects.requireNonNull(settings); Objects.requireNonNull(requestFactory); map.from(settings::connectTimeout).asInt(Duration::toMillis).to(requestFactory::setConnectTimeout);
/* 115 */     Objects.requireNonNull(settings); Objects.requireNonNull(requestFactory); map.from(settings::readTimeout).asInt(Duration::toMillis).to(requestFactory::setReadTimeout);
/* 116 */     return requestFactory;
/*     */   }
/*     */   
/*     */   static class Classes
/*     */   {
/*     */     static final String HTTP_CLIENT = "reactor.netty.http.client.HttpClient";
/*     */     
/*     */     static boolean present(ClassLoader classLoader) {
/* 124 */       return ClassUtils.isPresent("reactor.netty.http.client.HttpClient", classLoader);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\ReactorClientHttpRequestFactoryBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */