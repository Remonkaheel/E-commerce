/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Redirects
/*     */ {
/* 126 */   FOLLOW_WHEN_POSSIBLE(HttpRedirects.FOLLOW_WHEN_POSSIBLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   FOLLOW(HttpRedirects.FOLLOW),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   DONT_FOLLOW(HttpRedirects.DONT_FOLLOW);
/*     */   
/*     */   private final HttpRedirects httpClientRedirects;
/*     */   
/*     */   Redirects(HttpRedirects httpClientRedirects) {
/* 141 */     this.httpClientRedirects = httpClientRedirects;
/*     */   }
/*     */   
/*     */   HttpRedirects httpClientRedirects() {
/* 145 */     return this.httpClientRedirects;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Redirects of(HttpRedirects httpRedirects) {
/* 155 */     switch (ClientHttpRequestFactorySettings.null.$SwitchMap$org$springframework$boot$http$client$HttpRedirects[httpRedirects.ordinal()]) { default: throw new IncompatibleClassChangeError();case 1: case 2: case 3: break; }  return (httpRedirects != null) ? 
/*     */ 
/*     */       
/* 158 */       DONT_FOLLOW : 
/* 159 */       null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\ClientHttpRequestFactorySettings$Redirects.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */