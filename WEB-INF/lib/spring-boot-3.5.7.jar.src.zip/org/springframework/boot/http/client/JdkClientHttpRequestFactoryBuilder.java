/*    */ package org.springframework.boot.http.client;
/*    */ 
/*    */ import java.net.http.HttpClient;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.http.client.ClientHttpRequestFactory;
/*    */ import org.springframework.http.client.JdkClientHttpRequestFactory;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JdkClientHttpRequestFactoryBuilder
/*    */   extends AbstractClientHttpRequestFactoryBuilder<JdkClientHttpRequestFactory>
/*    */ {
/*    */   private final JdkHttpClientBuilder httpClientBuilder;
/*    */   
/*    */   JdkClientHttpRequestFactoryBuilder() {
/* 43 */     this((List<Consumer<JdkClientHttpRequestFactory>>)null, new JdkHttpClientBuilder());
/*    */   }
/*    */ 
/*    */   
/*    */   private JdkClientHttpRequestFactoryBuilder(List<Consumer<JdkClientHttpRequestFactory>> customizers, JdkHttpClientBuilder httpClientBuilder) {
/* 48 */     super(customizers);
/* 49 */     this.httpClientBuilder = httpClientBuilder;
/*    */   }
/*    */ 
/*    */   
/*    */   public JdkClientHttpRequestFactoryBuilder withCustomizer(Consumer<JdkClientHttpRequestFactory> customizer) {
/* 54 */     return new JdkClientHttpRequestFactoryBuilder(mergedCustomizers(customizer), this.httpClientBuilder);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JdkClientHttpRequestFactoryBuilder withCustomizers(Collection<Consumer<JdkClientHttpRequestFactory>> customizers) {
/* 60 */     return new JdkClientHttpRequestFactoryBuilder(mergedCustomizers(customizers), this.httpClientBuilder);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JdkClientHttpRequestFactoryBuilder withHttpClientCustomizer(Consumer<HttpClient.Builder> httpClientCustomizer) {
/* 71 */     Assert.notNull(httpClientCustomizer, "'httpClientCustomizer' must not be null");
/* 72 */     return new JdkClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/* 73 */         .withCustomizer(httpClientCustomizer));
/*    */   }
/*    */ 
/*    */   
/*    */   protected JdkClientHttpRequestFactory createClientHttpRequestFactory(ClientHttpRequestFactorySettings settings) {
/* 78 */     HttpClient httpClient = this.httpClientBuilder.build(asHttpClientSettings(settings.withReadTimeout(null)));
/* 79 */     JdkClientHttpRequestFactory requestFactory = new JdkClientHttpRequestFactory(httpClient);
/* 80 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 81 */     Objects.requireNonNull(settings); Objects.requireNonNull(requestFactory); map.from(settings::readTimeout).to(requestFactory::setReadTimeout);
/* 82 */     return requestFactory;
/*    */   }
/*    */   
/*    */   static class Classes
/*    */   {
/*    */     static final String HTTP_CLIENT = "java.net.http.HttpClient";
/*    */     
/*    */     static boolean present(ClassLoader classLoader) {
/* 90 */       return ClassUtils.isPresent("java.net.http.HttpClient", classLoader);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\JdkClientHttpRequestFactoryBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */