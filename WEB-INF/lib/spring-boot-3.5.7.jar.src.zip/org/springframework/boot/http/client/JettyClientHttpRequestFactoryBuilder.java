/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.jetty.client.HttpClient;
/*     */ import org.eclipse.jetty.client.HttpClientTransport;
/*     */ import org.eclipse.jetty.io.ClientConnector;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.JettyClientHttpRequestFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JettyClientHttpRequestFactoryBuilder
/*     */   extends AbstractClientHttpRequestFactoryBuilder<JettyClientHttpRequestFactory>
/*     */ {
/*     */   private final JettyHttpClientBuilder httpClientBuilder;
/*     */   
/*     */   JettyClientHttpRequestFactoryBuilder() {
/*  47 */     this((List<Consumer<JettyClientHttpRequestFactory>>)null, new JettyHttpClientBuilder());
/*     */   }
/*     */ 
/*     */   
/*     */   private JettyClientHttpRequestFactoryBuilder(List<Consumer<JettyClientHttpRequestFactory>> customizers, JettyHttpClientBuilder httpClientBuilder) {
/*  52 */     super(customizers);
/*  53 */     this.httpClientBuilder = httpClientBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public JettyClientHttpRequestFactoryBuilder withCustomizer(Consumer<JettyClientHttpRequestFactory> customizer) {
/*  58 */     return new JettyClientHttpRequestFactoryBuilder(mergedCustomizers(customizer), this.httpClientBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpRequestFactoryBuilder withCustomizers(Collection<Consumer<JettyClientHttpRequestFactory>> customizers) {
/*  64 */     return new JettyClientHttpRequestFactoryBuilder(mergedCustomizers(customizers), this.httpClientBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpRequestFactoryBuilder withHttpClientCustomizer(Consumer<HttpClient> httpClientCustomizer) {
/*  74 */     Assert.notNull(httpClientCustomizer, "'httpClientCustomizer' must not be null");
/*  75 */     return new JettyClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/*  76 */         .withCustomizer(httpClientCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpRequestFactoryBuilder withHttpClientTransportCustomizer(Consumer<HttpClientTransport> httpClientTransportCustomizer) {
/*  87 */     Assert.notNull(httpClientTransportCustomizer, "'httpClientTransportCustomizer' must not be null");
/*  88 */     return new JettyClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/*  89 */         .withHttpClientTransportCustomizer(httpClientTransportCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpRequestFactoryBuilder withClientConnectorCustomizerCustomizer(Consumer<ClientConnector> clientConnectorCustomizerCustomizer) {
/* 100 */     Assert.notNull(clientConnectorCustomizerCustomizer, "'clientConnectorCustomizerCustomizer' must not be null");
/* 101 */     return new JettyClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/* 102 */         .withClientConnectorCustomizerCustomizer(clientConnectorCustomizerCustomizer));
/*     */   }
/*     */ 
/*     */   
/*     */   protected JettyClientHttpRequestFactory createClientHttpRequestFactory(ClientHttpRequestFactorySettings settings) {
/* 107 */     HttpClient httpClient = this.httpClientBuilder.build(asHttpClientSettings(settings.withTimeouts(null, null)));
/* 108 */     JettyClientHttpRequestFactory requestFactory = new JettyClientHttpRequestFactory(httpClient);
/* 109 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 110 */     Objects.requireNonNull(settings); Objects.requireNonNull(requestFactory); map.from(settings::connectTimeout).asInt(Duration::toMillis).to(requestFactory::setConnectTimeout);
/* 111 */     Objects.requireNonNull(settings); Objects.requireNonNull(requestFactory); map.from(settings::readTimeout).asInt(Duration::toMillis).to(requestFactory::setReadTimeout);
/* 112 */     return requestFactory;
/*     */   }
/*     */   
/*     */   static class Classes
/*     */   {
/*     */     static final String HTTP_CLIENT = "org.eclipse.jetty.client.HttpClient";
/*     */     
/*     */     static boolean present(ClassLoader classLoader) {
/* 120 */       return ClassUtils.isPresent("org.eclipse.jetty.client.HttpClient", classLoader);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\JettyClientHttpRequestFactoryBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */