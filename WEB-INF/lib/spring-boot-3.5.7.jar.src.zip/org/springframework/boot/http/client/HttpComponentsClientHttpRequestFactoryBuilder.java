/*     */ package org.springframework.boot.http.client;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.apache.hc.client5.http.classic.HttpClient;
/*     */ import org.apache.hc.client5.http.config.RequestConfig;
/*     */ import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
/*     */ import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
/*     */ import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
/*     */ import org.apache.hc.client5.http.ssl.TlsSocketStrategy;
/*     */ import org.apache.hc.core5.http.io.SocketConfig;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpComponentsClientHttpRequestFactoryBuilder
/*     */   extends AbstractClientHttpRequestFactoryBuilder<HttpComponentsClientHttpRequestFactory>
/*     */ {
/*     */   private final HttpComponentsHttpClientBuilder httpClientBuilder;
/*     */   
/*     */   HttpComponentsClientHttpRequestFactoryBuilder() {
/*  52 */     this((List<Consumer<HttpComponentsClientHttpRequestFactory>>)null, new HttpComponentsHttpClientBuilder());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpComponentsClientHttpRequestFactoryBuilder(List<Consumer<HttpComponentsClientHttpRequestFactory>> customizers, HttpComponentsHttpClientBuilder httpClientBuilder) {
/*  58 */     super(customizers);
/*  59 */     this.httpClientBuilder = httpClientBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpRequestFactoryBuilder withCustomizer(Consumer<HttpComponentsClientHttpRequestFactory> customizer) {
/*  65 */     return new HttpComponentsClientHttpRequestFactoryBuilder(mergedCustomizers(customizer), this.httpClientBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpRequestFactoryBuilder withCustomizers(Collection<Consumer<HttpComponentsClientHttpRequestFactory>> customizers) {
/*  71 */     return new HttpComponentsClientHttpRequestFactoryBuilder(mergedCustomizers(customizers), this.httpClientBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpRequestFactoryBuilder withHttpClientCustomizer(Consumer<HttpClientBuilder> httpClientCustomizer) {
/*  83 */     Assert.notNull(httpClientCustomizer, "'httpClientCustomizer' must not be null");
/*  84 */     return new HttpComponentsClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/*  85 */         .withCustomizer(httpClientCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpRequestFactoryBuilder withConnectionManagerCustomizer(Consumer<PoolingHttpClientConnectionManagerBuilder> connectionManagerCustomizer) {
/*  97 */     Assert.notNull(connectionManagerCustomizer, "'connectionManagerCustomizer' must not be null");
/*  98 */     return new HttpComponentsClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/*  99 */         .withConnectionManagerCustomizer(connectionManagerCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpRequestFactoryBuilder withSocketConfigCustomizer(Consumer<SocketConfig.Builder> socketConfigCustomizer) {
/* 111 */     Assert.notNull(socketConfigCustomizer, "'socketConfigCustomizer' must not be null");
/* 112 */     return new HttpComponentsClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/* 113 */         .withSocketConfigCustomizer(socketConfigCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpRequestFactoryBuilder withTlsSocketStrategyFactory(Function<SslBundle, TlsSocketStrategy> tlsSocketStrategyFactory) {
/* 125 */     Assert.notNull(tlsSocketStrategyFactory, "'tlsSocketStrategyFactory' must not be null");
/* 126 */     return new HttpComponentsClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/* 127 */         .withTlsSocketStrategyFactory(tlsSocketStrategyFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpRequestFactoryBuilder withDefaultRequestConfigCustomizer(Consumer<RequestConfig.Builder> defaultRequestConfigCustomizer) {
/* 140 */     Assert.notNull(defaultRequestConfigCustomizer, "'defaultRequestConfigCustomizer' must not be null");
/* 141 */     return new HttpComponentsClientHttpRequestFactoryBuilder(getCustomizers(), this.httpClientBuilder
/* 142 */         .withDefaultRequestConfigCustomizer(defaultRequestConfigCustomizer));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpComponentsClientHttpRequestFactory createClientHttpRequestFactory(ClientHttpRequestFactorySettings settings) {
/* 148 */     CloseableHttpClient closeableHttpClient = this.httpClientBuilder.build(asHttpClientSettings(settings.withConnectTimeout(null)));
/* 149 */     HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory((HttpClient)closeableHttpClient);
/* 150 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 151 */     Objects.requireNonNull(settings); Objects.requireNonNull(factory); map.from(settings::connectTimeout).asInt(Duration::toMillis).to(factory::setConnectTimeout);
/* 152 */     return factory;
/*     */   }
/*     */   
/*     */   static class Classes
/*     */   {
/*     */     static final String HTTP_CLIENTS = "org.apache.hc.client5.http.impl.classic.HttpClients";
/*     */     
/*     */     static boolean present(ClassLoader classLoader) {
/* 160 */       return ClassUtils.isPresent("org.apache.hc.client5.http.impl.classic.HttpClients", classLoader);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\HttpComponentsClientHttpRequestFactoryBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */