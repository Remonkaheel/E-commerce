/*    */ package org.springframework.boot.http.client;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Empty
/*    */ {
/*    */   private static final Consumer<?> EMPTY_CUSTOMIZER = t -> {
/*    */     
/*    */     };
/*    */   
/*    */   static <T> Consumer<T> consumer() {
/* 36 */     return (Consumer)EMPTY_CUSTOMIZER;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\Empty.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */