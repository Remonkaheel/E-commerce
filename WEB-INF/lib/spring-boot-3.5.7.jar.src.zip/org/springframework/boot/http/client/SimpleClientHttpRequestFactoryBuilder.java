/*    */ package org.springframework.boot.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.time.Duration;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ import javax.net.ssl.HttpsURLConnection;
/*    */ import javax.net.ssl.SSLSocketFactory;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.boot.ssl.SslBundle;
/*    */ import org.springframework.http.client.ClientHttpRequestFactory;
/*    */ import org.springframework.http.client.SimpleClientHttpRequestFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleClientHttpRequestFactoryBuilder
/*    */   extends AbstractClientHttpRequestFactoryBuilder<SimpleClientHttpRequestFactory>
/*    */ {
/*    */   SimpleClientHttpRequestFactoryBuilder() {
/* 47 */     this((List<Consumer<SimpleClientHttpRequestFactory>>)null);
/*    */   }
/*    */   
/*    */   private SimpleClientHttpRequestFactoryBuilder(List<Consumer<SimpleClientHttpRequestFactory>> customizers) {
/* 51 */     super(customizers);
/*    */   }
/*    */ 
/*    */   
/*    */   public SimpleClientHttpRequestFactoryBuilder withCustomizer(Consumer<SimpleClientHttpRequestFactory> customizer) {
/* 56 */     return new SimpleClientHttpRequestFactoryBuilder(mergedCustomizers(customizer));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SimpleClientHttpRequestFactoryBuilder withCustomizers(Collection<Consumer<SimpleClientHttpRequestFactory>> customizers) {
/* 62 */     return new SimpleClientHttpRequestFactoryBuilder(mergedCustomizers(customizers));
/*    */   }
/*    */ 
/*    */   
/*    */   protected SimpleClientHttpRequestFactory createClientHttpRequestFactory(ClientHttpRequestFactorySettings settings) {
/* 67 */     SslBundle sslBundle = settings.sslBundle();
/* 68 */     SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpsRequestFactory(settings);
/* 69 */     Assert.state((sslBundle == null || !sslBundle.getOptions().isSpecified()), "SSL Options cannot be specified with Java connections");
/*    */     
/* 71 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 72 */     Objects.requireNonNull(settings); Objects.requireNonNull(requestFactory); map.from(settings::readTimeout).asInt(Duration::toMillis).to(requestFactory::setReadTimeout);
/* 73 */     Objects.requireNonNull(settings); Objects.requireNonNull(requestFactory); map.from(settings::connectTimeout).asInt(Duration::toMillis).to(requestFactory::setConnectTimeout);
/* 74 */     return requestFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static class SimpleClientHttpsRequestFactory
/*    */     extends SimpleClientHttpRequestFactory
/*    */   {
/*    */     private final ClientHttpRequestFactorySettings settings;
/*    */ 
/*    */     
/*    */     SimpleClientHttpsRequestFactory(ClientHttpRequestFactorySettings settings) {
/* 86 */       this.settings = settings;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void prepareConnection(HttpURLConnection connection, String httpMethod) throws IOException {
/* 91 */       super.prepareConnection(connection, httpMethod);
/* 92 */       if (this.settings.sslBundle() != null && connection instanceof HttpsURLConnection) { HttpsURLConnection secureConnection = (HttpsURLConnection)connection;
/* 93 */         SSLSocketFactory socketFactory = this.settings.sslBundle().createSslContext().getSocketFactory();
/* 94 */         secureConnection.setSSLSocketFactory(socketFactory); }
/*    */       
/* 96 */       if (this.settings.redirects() == ClientHttpRequestFactorySettings.Redirects.DONT_FOLLOW)
/* 97 */         connection.setInstanceFollowRedirects(false); 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\SimpleClientHttpRequestFactoryBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */