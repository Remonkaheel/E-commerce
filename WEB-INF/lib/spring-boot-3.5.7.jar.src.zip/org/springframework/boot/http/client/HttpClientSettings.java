/*    */ package org.springframework.boot.http.client;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.boot.ssl.SslBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpClientSettings
/*    */   extends Record
/*    */ {
/*    */   private final HttpRedirects redirects;
/*    */   private final Duration connectTimeout;
/*    */   private final Duration readTimeout;
/*    */   private final SslBundle sslBundle;
/*    */   
/*    */   public SslBundle sslBundle() {
/* 34 */     return this.sslBundle; } public Duration readTimeout() { return this.readTimeout; } public Duration connectTimeout() { return this.connectTimeout; } public HttpRedirects redirects() { return this.redirects; }
/*    */    public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/boot/http/client/HttpClientSettings;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #34	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/boot/http/client/HttpClientSettings;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/* 37 */   } static final HttpClientSettings DEFAULTS = new HttpClientSettings(null, null, null, null);
/*    */   public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/http/client/HttpClientSettings;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #34	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/boot/http/client/HttpClientSettings; }
/*    */   public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/boot/http/client/HttpClientSettings;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #34	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/boot/http/client/HttpClientSettings; } public HttpClientSettings(HttpRedirects redirects, Duration connectTimeout, Duration readTimeout, SslBundle sslBundle) {
/* 40 */     redirects = (redirects != null) ? redirects : HttpRedirects.FOLLOW_WHEN_POSSIBLE;
/*    */     this.redirects = redirects;
/*    */     this.connectTimeout = connectTimeout;
/*    */     this.readTimeout = readTimeout;
/*    */     this.sslBundle = sslBundle;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-3.5.7.jar!\org\springframework\boot\http\client\HttpClientSettings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */