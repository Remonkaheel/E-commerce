module jakarta.annotation {
  requires java.base;
  
  exports jakarta.annotation;
  exports jakarta.annotation.security;
  exports jakarta.annotation.sql;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.annotation-api-2.1.1.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */