package jakarta.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Deprecated
public @interface ManagedBean {
  String value() default "";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.annotation-api-2.1.1.jar!\jakarta\annotation\ManagedBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */