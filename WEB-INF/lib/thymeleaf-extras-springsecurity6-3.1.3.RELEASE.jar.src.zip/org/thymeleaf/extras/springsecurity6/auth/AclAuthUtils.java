/*     */ package org.thymeleaf.extras.springsecurity6.auth;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.acls.domain.DefaultPermissionFactory;
/*     */ import org.springframework.security.acls.domain.ObjectIdentityRetrievalStrategyImpl;
/*     */ import org.springframework.security.acls.domain.PermissionFactory;
/*     */ import org.springframework.security.acls.domain.SidRetrievalStrategyImpl;
/*     */ import org.springframework.security.acls.model.Acl;
/*     */ import org.springframework.security.acls.model.AclService;
/*     */ import org.springframework.security.acls.model.NotFoundException;
/*     */ import org.springframework.security.acls.model.ObjectIdentity;
/*     */ import org.springframework.security.acls.model.ObjectIdentityRetrievalStrategy;
/*     */ import org.springframework.security.acls.model.Permission;
/*     */ import org.springframework.security.acls.model.Sid;
/*     */ import org.springframework.security.acls.model.SidRetrievalStrategy;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AclAuthUtils
/*     */ {
/*  61 */   private static final Logger logger = LoggerFactory.getLogger(AclAuthUtils.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean authorizeUsingAccessControlList(IExpressionContext context, Object domainObject, ApplicationContext applicationContext, String permissionsString, Authentication authentication) {
/*  80 */     List<Permission> permissions = parsePermissionsString(applicationContext, permissionsString);
/*     */     
/*  82 */     return authorizeUsingAccessControlList(context, domainObject, permissions, authentication);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean authorizeUsingAccessControlList(IExpressionContext context, Object domainObject, List<Permission> permissions, Authentication authentication) {
/*     */     SidRetrievalStrategyImpl sidRetrievalStrategyImpl;
/*     */     ObjectIdentityRetrievalStrategyImpl objectIdentityRetrievalStrategyImpl;
/*  94 */     if (logger.isTraceEnabled()) {
/*  95 */       logger.trace("[THYMELEAF][{}] Checking authorization using Access Control List for user \"{}\". Domain object is of class \"{}\" and permissions are \"{}\".", new Object[] {
/*     */             
/*  97 */             TemplateEngine.threadIndex(), (authentication == null) ? null : authentication.getName(), 
/*  98 */             (domainObject == null) ? null : domainObject.getClass().getName(), permissions
/*     */           });
/*     */     }
/* 101 */     ApplicationContext applicationContext = AuthUtils.getContext((IContext)context);
/*     */     
/* 103 */     AclService aclService = getBeanOfType(applicationContext, AclService.class);
/*     */     
/* 105 */     if (authentication == null) {
/*     */ 
/*     */       
/* 108 */       if (logger.isTraceEnabled()) {
/* 109 */         logger.trace("[THYMELEAF][{}] Authentication object is null. Access is DENIED. ", new Object[] {
/* 110 */               TemplateEngine.threadIndex()
/*     */             });
/*     */       }
/* 113 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     SidRetrievalStrategy sidRetrievalStrategy = getBeanOfType(applicationContext, SidRetrievalStrategy.class);
/* 123 */     if (sidRetrievalStrategy == null) {
/* 124 */       sidRetrievalStrategyImpl = new SidRetrievalStrategyImpl();
/*     */     }
/*     */     
/* 127 */     ObjectIdentityRetrievalStrategy objectIdentityRetrievalStrategy = getBeanOfType(applicationContext, ObjectIdentityRetrievalStrategy.class);
/* 128 */     if (objectIdentityRetrievalStrategy == null) {
/* 129 */       objectIdentityRetrievalStrategyImpl = new ObjectIdentityRetrievalStrategyImpl();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     if (null == permissions || permissions.isEmpty()) {
/*     */       
/* 139 */       if (logger.isTraceEnabled()) {
/* 140 */         logger.trace("[THYMELEAF][{}] Permissions are null or empty. Access is DENIED. ", new Object[] {
/* 141 */               TemplateEngine.threadIndex()
/*     */             });
/*     */       }
/* 144 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 148 */     if (domainObject == null) {
/* 149 */       if (logger.isTraceEnabled()) {
/* 150 */         logger.trace("[THYMELEAF][{}] Domain object for resolved to null. Access by Access Control List is GRANTED.", new Object[] {
/* 151 */               TemplateEngine.threadIndex()
/*     */             });
/*     */       }
/* 154 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 158 */     List<Sid> sids = sidRetrievalStrategyImpl.getSids(SecurityContextHolder.getContext().getAuthentication());
/*     */ 
/*     */     
/* 161 */     ObjectIdentity oid = objectIdentityRetrievalStrategyImpl.getObjectIdentity(domainObject);
/*     */ 
/*     */     
/*     */     try {
/* 165 */       Acl acl = aclService.readAclById(oid, sids);
/*     */       
/* 167 */       if (acl.isGranted(permissions, sids, false)) {
/*     */         
/* 169 */         if (logger.isTraceEnabled()) {
/* 170 */           logger.trace("[THYMELEAF][{}] Checked authorization using Access Control List for user \"{}\". Domain object is of class \"{}\" and permissions are \"{}\". Access is GRANTED.", new Object[] {
/*     */                 
/* 172 */                 TemplateEngine.threadIndex(), authentication.getName(), domainObject
/* 173 */                 .getClass().getName(), permissions
/*     */               });
/*     */         }
/* 176 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 180 */       if (logger.isTraceEnabled()) {
/* 181 */         logger.trace("[THYMELEAF][{}] Checked authorization using Access Control List for user \"{}\". Domain object is of class \"{}\" and permissions are \"{}\". Access is DENIED.", new Object[] {
/*     */               
/* 183 */               TemplateEngine.threadIndex(), authentication.getName(), domainObject
/* 184 */               .getClass().getName(), permissions
/*     */             });
/*     */       }
/* 187 */       return false;
/*     */     }
/* 189 */     catch (NotFoundException nfe) {
/* 190 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Permission> parsePermissionsString(ApplicationContext applicationContext, String permissionsString) throws NumberFormatException {
/*     */     DefaultPermissionFactory defaultPermissionFactory;
/* 203 */     if (logger.isTraceEnabled()) {
/* 204 */       logger.trace("[THYMELEAF][{}] Parsing permissions string \"{}\".", new Object[] {
/* 205 */             TemplateEngine.threadIndex(), permissionsString
/*     */           });
/*     */     }
/* 208 */     if (permissionsString == null || permissionsString.trim().length() == 0) {
/* 209 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 212 */     PermissionFactory permissionFactory = getBeanOfType(applicationContext, PermissionFactory.class);
/* 213 */     if (permissionFactory == null) {
/* 214 */       defaultPermissionFactory = new DefaultPermissionFactory();
/*     */     }
/*     */     
/* 217 */     Set<Permission> permissions = new HashSet<>();
/* 218 */     StringTokenizer tokenizer = new StringTokenizer(permissionsString, ",", false);
/*     */     
/* 220 */     while (tokenizer.hasMoreTokens()) {
/* 221 */       String permission = tokenizer.nextToken();
/*     */       try {
/* 223 */         permissions.add(defaultPermissionFactory.buildFromMask(Integer.valueOf(permission).intValue()));
/* 224 */       } catch (NumberFormatException nfe) {
/*     */         
/* 226 */         permissions.add(defaultPermissionFactory.buildFromName(permission));
/*     */       } 
/*     */     } 
/*     */     
/* 230 */     return new ArrayList<>(permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> T getBeanOfType(ApplicationContext applicationContext, Class<T> type) {
/* 239 */     Map<String, T> map = applicationContext.getBeansOfType(type);
/*     */     
/* 241 */     for (ApplicationContext context = applicationContext.getParent(); context != null; context = context.getParent()) {
/* 242 */       map.putAll(context.getBeansOfType(type));
/*     */     }
/*     */     
/* 245 */     if (map.size() == 0)
/* 246 */       return null; 
/* 247 */     if (map.size() == 1) {
/* 248 */       return map.values().iterator().next();
/*     */     }
/*     */     
/* 251 */     throw new ConfigurationException("Found incorrect number of " + type
/* 252 */         .getSimpleName() + " instances in application context - you must have only have one!");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity6\auth\AclAuthUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */