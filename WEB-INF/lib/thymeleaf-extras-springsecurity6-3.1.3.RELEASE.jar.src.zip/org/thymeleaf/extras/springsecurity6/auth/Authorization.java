/*    */ package org.thymeleaf.extras.springsecurity6.auth;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Authorization
/*    */ {
/*    */   private final IExpressionContext context;
/*    */   private final Authentication authentication;
/*    */   
/*    */   public Authorization(IExpressionContext context, Authentication authentication) {
/* 50 */     this.context = context;
/* 51 */     this.authentication = authentication;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IExpressionContext getContext() {
/* 57 */     return this.context;
/*    */   }
/*    */   
/*    */   public Authentication getAuthentication() {
/* 61 */     return this.authentication;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean expr(String expression) {
/* 68 */     return expression(expression);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean expression(String expression) {
/* 74 */     Validate.notEmpty(expression, "Access expression cannot be null");
/*    */     
/* 76 */     return AuthUtils.authorizeUsingAccessExpression(this.context, expression, this.authentication);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean url(String url) {
/* 84 */     return url("GET", url);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean url(String method, String url) {
/* 91 */     Validate.notEmpty(url, "URL cannot be null");
/*    */     
/* 93 */     return AuthUtils.authorizeUsingUrlCheck(this.context, url, method, this.authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity6\auth\Authorization.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */