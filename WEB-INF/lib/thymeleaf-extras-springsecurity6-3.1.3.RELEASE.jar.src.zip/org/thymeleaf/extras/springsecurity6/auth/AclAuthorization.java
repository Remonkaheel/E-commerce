/*    */ package org.thymeleaf.extras.springsecurity6.auth;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.security.acls.model.Permission;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.thymeleaf.context.IContext;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AclAuthorization
/*    */ {
/*    */   private final IExpressionContext context;
/*    */   private final Authentication authentication;
/*    */   
/*    */   public AclAuthorization(IExpressionContext context, Authentication authentication) {
/* 51 */     this.context = context;
/* 52 */     this.authentication = authentication;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Authentication getAuthentication() {
/* 58 */     return this.authentication;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean acl(Object domainObject, String permissions) {
/* 65 */     Validate.notEmpty(permissions, "permissions cannot be null or empty");
/*    */     
/* 67 */     ApplicationContext applicationContext = AuthUtils.getContext((IContext)this.context);
/*    */ 
/*    */     
/* 70 */     List<Permission> permissionsList = AclAuthUtils.parsePermissionsString(applicationContext, permissions);
/*    */     
/* 72 */     return AclAuthUtils.authorizeUsingAccessControlList(this.context, domainObject, permissionsList, this.authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity6\auth\AclAuthorization.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */