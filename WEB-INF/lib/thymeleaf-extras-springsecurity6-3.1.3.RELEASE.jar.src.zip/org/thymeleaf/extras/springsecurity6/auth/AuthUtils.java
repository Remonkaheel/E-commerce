/*     */ package org.thymeleaf.extras.springsecurity6.auth;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ParseException;
/*     */ import org.springframework.security.access.expression.ExpressionUtils;
/*     */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ import org.springframework.security.web.WebAttributes;
/*     */ import org.springframework.security.web.access.WebInvocationPrivilegeEvaluator;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ import org.thymeleaf.extras.springsecurity6.util.SpringSecurityContextUtils;
/*     */ import org.thymeleaf.extras.springsecurity6.util.SpringVersionSpecificUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthUtils
/*     */ {
/*  82 */   private static final Logger logger = LoggerFactory.getLogger(AuthUtils.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Authentication getAuthenticationObject(IExpressionContext context) {
/*  96 */     if (logger.isTraceEnabled()) {
/*  97 */       logger.trace("[THYMELEAF][{}] Obtaining authentication object.", new Object[] {
/*  98 */             TemplateEngine.threadIndex()
/*     */           });
/*     */     }
/*     */     
/* 102 */     Authentication authentication = SpringSecurityContextUtils.getAuthenticationObject((IContext)context);
/*     */     
/* 104 */     if (authentication == null || authentication.getPrincipal() == null) {
/* 105 */       if (logger.isTraceEnabled())
/* 106 */         logger.trace("[THYMELEAF][{}] No authentication object found in context.", new Object[] {
/* 107 */               TemplateEngine.threadIndex()
/*     */             }); 
/* 109 */       return null;
/*     */     } 
/*     */     
/* 112 */     if (logger.isTraceEnabled()) {
/* 113 */       logger.trace("[THYMELEAF][{}] Authentication object of class {} found in context for user \"{}\".", new Object[] {
/* 114 */             TemplateEngine.threadIndex(), authentication.getClass().getName(), authentication.getName()
/*     */           });
/*     */     }
/* 117 */     return authentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getAuthenticationProperty(Authentication authentication, String property) {
/* 125 */     if (logger.isTraceEnabled()) {
/* 126 */       logger.trace("[THYMELEAF][{}] Reading property \"{}\" from authentication object.", new Object[] {
/* 127 */             TemplateEngine.threadIndex(), property
/*     */           });
/*     */     }
/* 130 */     if (authentication == null) {
/* 131 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 136 */       BeanWrapperImpl wrapper = new BeanWrapperImpl(authentication);
/* 137 */       Object propertyObj = wrapper.getPropertyValue(property);
/*     */       
/* 139 */       if (logger.isTraceEnabled()) {
/* 140 */         logger.trace("[THYMELEAF][{}] Property \"{}\" obtained from authentication object for user \"{}\". Returned value of class {}.", new Object[] {
/*     */               
/* 142 */               TemplateEngine.threadIndex(), property, authentication.getName(), 
/* 143 */               (propertyObj == null) ? null : propertyObj.getClass().getName()
/*     */             });
/*     */       }
/* 146 */       return propertyObj;
/*     */     }
/* 148 */     catch (BeansException e) {
/* 149 */       throw new TemplateProcessingException("Error retrieving value for property \"" + property + "\" of authentication object of class " + authentication
/*     */           
/* 151 */           .getClass().getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean authorizeUsingAccessExpression(IExpressionContext context, String accessExpression, Authentication authentication) {
/* 163 */     Validate.notNull(context, "Context cannot be null");
/*     */     
/* 165 */     if (logger.isTraceEnabled()) {
/* 166 */       logger.trace("[THYMELEAF][{}] Checking authorization using access expression \"{}\" for user \"{}\".", new Object[] {
/* 167 */             TemplateEngine.threadIndex(), accessExpression, (authentication == null) ? null : authentication.getName()
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 173 */     boolean authorized = SpringVersionSpecificUtils.isWebFluxContext((IContext)context) ? WebFluxAuthUtils.authorizeUsingAccessExpressionWebFlux(context, accessExpression, authentication) : MvcAuthUtils.authorizeUsingAccessExpressionMvc(context, accessExpression, authentication);
/*     */     
/* 175 */     if (authorized) {
/*     */       
/* 177 */       if (logger.isTraceEnabled()) {
/* 178 */         logger.trace("[THYMELEAF][{}] Checked authorization using access expression \"{}\" for user \"{}\". Access GRANTED.", new Object[] {
/* 179 */               TemplateEngine.threadIndex(), accessExpression, (authentication == null) ? null : authentication.getName()
/*     */             });
/*     */       }
/* 182 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 186 */     if (logger.isTraceEnabled()) {
/* 187 */       logger.trace("[THYMELEAF][{}] Checked authorization using access expression \"{}\" for user \"{}\". Access DENIED.", new Object[] {
/* 188 */             TemplateEngine.threadIndex(), accessExpression, (authentication == null) ? null : authentication.getName()
/*     */           });
/*     */     }
/* 191 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SecurityExpressionHandler<FilterInvocation> getExpressionHandler(IExpressionContext context) {
/* 201 */     ApplicationContext ctx = getContext((IContext)context);
/*     */ 
/*     */     
/* 204 */     Map<String, SecurityExpressionHandler> expressionHandlers = ctx.getBeansOfType(SecurityExpressionHandler.class);
/*     */     
/* 206 */     for (SecurityExpressionHandler<FilterInvocation> handler : expressionHandlers.values()) {
/* 207 */       Class<?> clazz = GenericTypeResolver.resolveTypeArgument(handler.getClass(), SecurityExpressionHandler.class);
/* 208 */       if (FilterInvocation.class.equals(GenericTypeResolver.resolveTypeArgument(handler.getClass(), SecurityExpressionHandler.class))) {
/* 209 */         return handler;
/*     */       }
/*     */     } 
/*     */     
/* 213 */     throw new TemplateProcessingException("No visible SecurityExpressionHandler instance could be found in the application context. There must be at least one in order to support expressions in Spring Security authorization queries.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean authorizeUsingUrlCheck(IExpressionContext context, String url, String method, Authentication authentication) {
/* 226 */     Validate.notNull(context, "Context cannot be null");
/*     */     
/* 228 */     if (logger.isTraceEnabled()) {
/* 229 */       logger.trace("[THYMELEAF][{}] Checking authorization for URL \"{}\" and method \"{}\" for user \"{}\".", new Object[] {
/* 230 */             TemplateEngine.threadIndex(), url, method, (authentication == null) ? null : authentication.getName()
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 236 */     boolean authorized = SpringVersionSpecificUtils.isWebFluxContext((IContext)context) ? WebFluxAuthUtils.authorizeUsingUrlCheckWebFlux(context, url, method, authentication) : MvcAuthUtils.authorizeUsingUrlCheckMvc(context, url, method, authentication);
/*     */     
/* 238 */     if (logger.isTraceEnabled()) {
/* 239 */       logger.trace("[THYMELEAF][{}] Checked authorization for URL \"{}\" and method \"{}\" for user \"{}\". " + (
/* 240 */           authorized ? "Access GRANTED." : "Access DENIED."), new Object[] {
/* 241 */             TemplateEngine.threadIndex(), url, method, (authentication == null) ? null : authentication.getName()
/*     */           });
/*     */     }
/* 244 */     return authorized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static WebInvocationPrivilegeEvaluator getPrivilegeEvaluator(IExpressionContext context) {
/* 254 */     WebInvocationPrivilegeEvaluator privEvaluatorFromRequest = (WebInvocationPrivilegeEvaluator)SpringSecurityContextUtils.getRequestAttribute((IContext)context, WebAttributes.WEB_INVOCATION_PRIVILEGE_EVALUATOR_ATTRIBUTE);
/*     */     
/* 256 */     if (privEvaluatorFromRequest != null) {
/* 257 */       return privEvaluatorFromRequest;
/*     */     }
/*     */     
/* 260 */     ApplicationContext ctx = getContext((IContext)context);
/*     */ 
/*     */     
/* 263 */     Map<String, WebInvocationPrivilegeEvaluator> privilegeEvaluators = ctx.getBeansOfType(WebInvocationPrivilegeEvaluator.class);
/*     */     
/* 265 */     if (privilegeEvaluators.size() == 0) {
/* 266 */       throw new TemplateProcessingException("No visible WebInvocationPrivilegeEvaluator instance could be found in the application context. There must be at least one in order to support URL access checks in Spring Security authorization queries.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 272 */     return (WebInvocationPrivilegeEvaluator)privilegeEvaluators.values().toArray()[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ApplicationContext getContext(IContext context) {
/* 280 */     return SpringSecurityContextUtils.getApplicationContext(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ServletFilterChainHolder
/*     */   {
/* 289 */     private static final FilterChain DUMMY_CHAIN = new FilterChain()
/*     */       {
/*     */         public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
/* 292 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class MvcAuthUtils
/*     */   {
/*     */     private static boolean authorizeUsingAccessExpressionMvc(IExpressionContext context, String accessExpression, Authentication authentication) {
/* 317 */       String expr = (accessExpression != null && accessExpression.startsWith("${") && accessExpression.endsWith("}")) ? accessExpression.substring(2, accessExpression.length() - 1) : accessExpression;
/*     */       
/* 319 */       SecurityExpressionHandler<FilterInvocation> handler = AuthUtils.getExpressionHandler(context);
/*     */       
/* 321 */       Expression expressionObject = null;
/*     */       try {
/* 323 */         expressionObject = handler.getExpressionParser().parseExpression(expr);
/* 324 */       } catch (ParseException e) {
/* 325 */         throw new TemplateProcessingException("An error happened trying to parse Spring Security access expression \"" + expr + "\"", e);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 330 */       HttpServletRequest request = SpringVersionSpecificUtils.getHttpServletRequest((IContext)context);
/* 331 */       HttpServletResponse response = SpringVersionSpecificUtils.getHttpServletResponse((IContext)context);
/*     */       
/* 333 */       FilterInvocation filterInvocation = new FilterInvocation((ServletRequest)request, (ServletResponse)response, AuthUtils.ServletFilterChainHolder.DUMMY_CHAIN);
/*     */       
/* 335 */       EvaluationContext evaluationContext = handler.createEvaluationContext(authentication, filterInvocation);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 343 */       IExpressionObjects expressionObjects = context.getExpressionObjects();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 350 */       EvaluationContext wrappedEvaluationContext = SpringVersionSpecificUtils.wrapEvaluationContext(evaluationContext, expressionObjects);
/*     */ 
/*     */       
/* 353 */       return ExpressionUtils.evaluateAsBoolean(expressionObject, wrappedEvaluationContext);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean authorizeUsingUrlCheckMvc(IExpressionContext context, String url, String method, Authentication authentication) {
/* 361 */       String contextPath = SpringSecurityContextUtils.getContextPath((IContext)context);
/* 362 */       return AuthUtils.getPrivilegeEvaluator(context).isAllowed(contextPath, url, method, authentication);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class WebFluxAuthUtils
/*     */   {
/*     */     private static boolean authorizeUsingAccessExpressionWebFlux(IExpressionContext context, String accessExpression, Authentication authentication) {
/* 380 */       if (!AuthUtils.MinimalAuthenticationExpressionSupport.isMinimalHandledExpression(accessExpression)) {
/* 381 */         throw new TemplateProcessingException("Authorization-oriented expressions (such as those in 'sec:authorize') are restricted in WebFlux applications due to a lack of support in the reactive side of Spring Security (as of Spring Security 5.1). Only a minimal set of security expressions is allowed: " + AuthUtils.MinimalAuthenticationExpressionSupport
/*     */ 
/*     */ 
/*     */             
/* 385 */             .HANDLED_EXPRESSIONS);
/*     */       }
/*     */       
/* 388 */       return AuthUtils.MinimalAuthenticationExpressionSupport.evaluateMinimalExpression(accessExpression, authentication);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean authorizeUsingUrlCheckWebFlux(IExpressionContext context, String url, String method, Authentication authentication) {
/* 396 */       throw new TemplateProcessingException("Authorization-oriented expressions (such as those in 'sec:authorize') are restricted in WebFlux applications due to a lack of support in the reactive side of Spring Security (as of Spring Security 5.1). Only a minimal set of security expressions is allowed: " + AuthUtils.MinimalAuthenticationExpressionSupport
/*     */ 
/*     */ 
/*     */           
/* 400 */           .HANDLED_EXPRESSIONS);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class MinimalAuthenticationExpressionSupport
/*     */   {
/* 421 */     private static final AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*     */     
/*     */     private static final String EXPR_ISAUTHENTICATED = "isAuthenticated()";
/*     */     
/*     */     private static final String EXPR_ISFULLYAUTHENTICATED = "isFullyAuthenticated()";
/*     */     
/*     */     private static final String EXPR_ISANONYMOUS = "isAnonymous()";
/*     */     
/*     */     private static final String EXPR_ISREMEMBERME = "isRememberMe()";
/* 430 */     private static final Set<String> HANDLED_EXPRESSIONS = new LinkedHashSet<>(
/* 431 */         Arrays.asList(new String[] { "isAuthenticated()", "isFullyAuthenticated()", "isAnonymous()", "isRememberMe()" }));
/*     */ 
/*     */ 
/*     */     
/*     */     static boolean isMinimalHandledExpression(String accessExpression) {
/* 436 */       return HANDLED_EXPRESSIONS.contains(accessExpression);
/*     */     }
/*     */ 
/*     */     
/*     */     static boolean evaluateMinimalExpression(String accessExpression, Authentication authentication) {
/* 441 */       if ("isAuthenticated()".equals(accessExpression)) {
/* 442 */         return isAuthenticated(authentication);
/*     */       }
/* 444 */       if ("isFullyAuthenticated()".equals(accessExpression)) {
/* 445 */         return isFullyAuthenticated(authentication);
/*     */       }
/* 447 */       if ("isAnonymous()".equals(accessExpression)) {
/* 448 */         return isAnonymous(authentication);
/*     */       }
/* 450 */       if ("isRememberMe()".equals(accessExpression)) {
/* 451 */         return isRememberMe(authentication);
/*     */       }
/* 453 */       throw new IllegalArgumentException("Unknown minimal expression: \"" + accessExpression + "\". Supported expressions are: " + HANDLED_EXPRESSIONS);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean isAnonymous(Authentication authentication) {
/* 459 */       return trustResolver.isAnonymous(authentication);
/*     */     }
/*     */     
/*     */     private static boolean isAuthenticated(Authentication authentication) {
/* 463 */       return !isAnonymous(authentication);
/*     */     }
/*     */     
/*     */     private static boolean isRememberMe(Authentication authentication) {
/* 467 */       return trustResolver.isRememberMe(authentication);
/*     */     }
/*     */     
/*     */     private static boolean isFullyAuthenticated(Authentication authentication) {
/* 471 */       return (!trustResolver.isAnonymous(authentication) && 
/* 472 */         !trustResolver.isRememberMe(authentication));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity6\auth\AuthUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */