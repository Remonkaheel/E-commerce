/*     */ package org.thymeleaf.extras.springsecurity6.util;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import java.util.Enumeration;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IWebContext;
/*     */ import org.thymeleaf.context.WebEngineContext;
/*     */ import org.thymeleaf.web.IWebExchange;
/*     */ import org.thymeleaf.web.servlet.IServletWebApplication;
/*     */ import org.thymeleaf.web.servlet.IServletWebExchange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringSecurityContextUtils
/*     */ {
/*  52 */   private static final Logger logger = LoggerFactory.getLogger(SpringSecurityContextUtils.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String SECURITY_CONTEXT_MODEL_ATTRIBUTE_NAME = "thymeleafSpringSecurityContext";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ApplicationContext getApplicationContext(IContext context) {
/*  71 */     if (SpringVersionSpecificUtils.isWebMvcContext(context)) {
/*  72 */       return SpringSecurityWebMvcApplicationContextUtils.findRequiredWebApplicationContext(context);
/*     */     }
/*     */     
/*  75 */     if (SpringVersionSpecificUtils.isWebFluxContext(context)) {
/*  76 */       return SpringSecurityWebFluxApplicationContextUtils.findRequiredApplicationContext(context);
/*     */     }
/*     */     
/*  79 */     throw new IllegalStateException("No ApplicationContext found for Spring Security: Thymeleaf context is neither an implementation of IWebContext (for Spring MVC apps) nor ISpringWebFluxContext (for Spring WebFlux apps). Thymeleaf's Spring Security support can only be used in web applications.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getRequestAttribute(IContext context, String attributeName) {
/*  90 */     if (SpringVersionSpecificUtils.isWebMvcContext(context)) {
/*  91 */       return SpringSecurityWebMvcApplicationContextUtils.getRequestAttribute(context, attributeName);
/*     */     }
/*     */     
/*  94 */     if (SpringVersionSpecificUtils.isWebFluxContext(context)) {
/*  95 */       return SpringSecurityWebFluxApplicationContextUtils.getRequestAttribute(context, attributeName);
/*     */     }
/*     */     
/*  98 */     throw new IllegalStateException("Could not obtain request attributes: Thymeleaf context is neither an implementation of IWebContext (for Spring MVC apps) nor ISpringWebFluxContext (for Spring WebFlux apps). Thymeleaf's Spring Security support can only be used in web applications.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getContextPath(IContext context) {
/* 109 */     if (SpringVersionSpecificUtils.isWebMvcContext(context)) {
/* 110 */       return SpringSecurityWebMvcApplicationContextUtils.getContextPath(context);
/*     */     }
/*     */     
/* 113 */     if (SpringVersionSpecificUtils.isWebFluxContext(context)) {
/* 114 */       return SpringSecurityWebFluxApplicationContextUtils.getContextPath(context);
/*     */     }
/*     */     
/* 117 */     throw new IllegalStateException("Could not obtain context path: Thymeleaf context is neither an implementation of IWebContext (for Spring MVC apps) nor ISpringWebFluxContext (for Spring WebFlux apps). Thymeleaf's Spring Security support can only be used in web applications.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Authentication getAuthenticationObject(IContext context) {
/* 127 */     if (SpringVersionSpecificUtils.isWebMvcContext(context)) {
/* 128 */       return SpringSecurityWebMvcApplicationContextUtils.getAuthenticationObject();
/*     */     }
/*     */     
/* 131 */     if (SpringVersionSpecificUtils.isWebFluxContext(context)) {
/* 132 */       return SpringSecurityWebFluxApplicationContextUtils.getAuthenticationObject(context);
/*     */     }
/*     */     
/* 135 */     throw new IllegalStateException("Could not obtain authentication object: Thymeleaf context is neither an implementation of IWebContext (for Spring MVC apps) nor ISpringWebFluxContext (for Spring WebFlux apps). Thymeleaf's Spring Security support can only be used in web applications.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class SpringSecurityWebMvcApplicationContextUtils
/*     */   {
/*     */     static Object getRequestAttribute(IContext context, String attributeName) {
/* 148 */       return ((IWebContext)context).getExchange().getAttributeValue(attributeName);
/*     */     }
/*     */ 
/*     */     
/*     */     static String getContextPath(IContext context) {
/* 153 */       WebEngineContext webEngineContext = (WebEngineContext)context;
/* 154 */       IWebExchange webExchange = webEngineContext.getExchange();
/* 155 */       IServletWebExchange servletWebExchange = (IServletWebExchange)webExchange;
/* 156 */       return servletWebExchange.getRequest().getContextPath();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static ApplicationContext findRequiredWebApplicationContext(IContext context) {
/* 175 */       IServletWebApplication application = (IServletWebApplication)((IWebContext)context).getExchange().getApplication();
/* 176 */       ServletContext servletContext = (ServletContext)application.getNativeServletContextObject();
/*     */       
/* 178 */       WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(servletContext);
/* 179 */       if (wac == null) {
/* 180 */         Enumeration<String> attrNames = servletContext.getAttributeNames();
/* 181 */         while (attrNames.hasMoreElements()) {
/* 182 */           String attrName = attrNames.nextElement();
/* 183 */           Object attrValue = servletContext.getAttribute(attrName);
/* 184 */           if (attrValue instanceof WebApplicationContext) {
/* 185 */             if (wac != null) {
/* 186 */               throw new IllegalStateException("No unique WebApplicationContext found: more than one DispatcherServlet registered with publishContext=true?");
/*     */             }
/*     */             
/* 189 */             wac = (WebApplicationContext)attrValue;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 194 */       if (wac == null) {
/* 195 */         throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener registered?");
/*     */       }
/*     */       
/* 198 */       return (ApplicationContext)wac;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     static Authentication getAuthenticationObject() {
/* 204 */       SecurityContext securityContext = SecurityContextHolder.getContext();
/* 205 */       if (securityContext == null) {
/* 206 */         if (SpringSecurityContextUtils.logger.isTraceEnabled())
/* 207 */           SpringSecurityContextUtils.logger.trace("[THYMELEAF][{}] No security context found, no authentication object returned.", new Object[] {
/* 208 */                 TemplateEngine.threadIndex()
/*     */               }); 
/* 210 */         return null;
/*     */       } 
/* 212 */       return securityContext.getAuthentication();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class SpringSecurityWebFluxApplicationContextUtils
/*     */   {
/*     */     static Object getRequestAttribute(IContext context, String attributeName) {
/* 224 */       ServerWebExchange exchange = SpringVersionSpecificUtils.getServerWebExchange(context);
/* 225 */       return exchange.getAttribute(attributeName);
/*     */     }
/*     */ 
/*     */     
/*     */     static String getContextPath(IContext context) {
/* 230 */       ServerWebExchange exchange = SpringVersionSpecificUtils.getServerWebExchange(context);
/* 231 */       return exchange.getRequest().getPath().contextPath().value();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     static ApplicationContext findRequiredApplicationContext(IContext context) {
/* 237 */       ServerWebExchange exchange = SpringVersionSpecificUtils.getServerWebExchange(context);
/* 238 */       ApplicationContext applicationContext = exchange.getApplicationContext();
/*     */       
/* 240 */       if (applicationContext == null) {
/* 241 */         throw new IllegalStateException("No ApplicationContext found in context for WebFlux application");
/*     */       }
/*     */       
/* 244 */       return applicationContext;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     static Authentication getAuthenticationObject(IContext context) {
/* 250 */       SecurityContext securityContext = (SecurityContext)context.getVariable("thymeleafSpringSecurityContext");
/* 251 */       if (securityContext == null) {
/* 252 */         if (SpringSecurityContextUtils.logger.isTraceEnabled())
/* 253 */           SpringSecurityContextUtils.logger.trace("[THYMELEAF][{}] No security context found, no authentication object returned.", new Object[] {
/* 254 */                 TemplateEngine.threadIndex()
/*     */               }); 
/* 256 */         return null;
/*     */       } 
/* 258 */       return securityContext.getAuthentication();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity\\util\SpringSecurityContextUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */