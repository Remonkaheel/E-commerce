/*     */ package org.thymeleaf.extras.springsecurity6.util;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IWebContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ import org.thymeleaf.spring6.expression.ThymeleafEvaluationContextWrapper;
/*     */ import org.thymeleaf.spring6.web.webflux.ISpringWebFluxWebExchange;
/*     */ import org.thymeleaf.web.IWebExchange;
/*     */ import org.thymeleaf.web.servlet.IServletWebExchange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Spring6VersionSpecificUtility
/*     */   implements ISpringVersionSpecificUtility
/*     */ {
/*     */   public EvaluationContext wrapEvaluationContext(EvaluationContext evaluationContext, IExpressionObjects expresionObjects) {
/*  58 */     ThymeleafEvaluationContextWrapper thymeleafEvaluationContextWrapper = new ThymeleafEvaluationContextWrapper(evaluationContext);
/*  59 */     thymeleafEvaluationContextWrapper.setExpressionObjects(expresionObjects);
/*  60 */     return (EvaluationContext)thymeleafEvaluationContextWrapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWebContext(IContext context) {
/*  68 */     if (context instanceof IWebContext) {
/*  69 */       return true;
/*     */     }
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWebMvcContext(IContext context) {
/*  78 */     if (context instanceof IWebContext) {
/*  79 */       IWebContext webContext = (IWebContext)context;
/*  80 */       IWebExchange webExchange = webContext.getExchange();
/*  81 */       if (webExchange instanceof IServletWebExchange) {
/*  82 */         return true;
/*     */       }
/*     */     } 
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWebFluxContext(IContext context) {
/*  92 */     if (!isWebContext(context)) {
/*  93 */       return false;
/*     */     }
/*  95 */     return getWebExchange(context) instanceof ISpringWebFluxWebExchange;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServletRequest getHttpServletRequest(IContext context) {
/* 100 */     return (HttpServletRequest)getServletWebExchange(context).getNativeRequestObject();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServletResponse getHttpServletResponse(IContext context) {
/* 105 */     return (HttpServletResponse)getServletWebExchange(context).getNativeResponseObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerWebExchange getServerWebExchange(IContext context) {
/* 112 */     IWebExchange webExchange = getWebExchange(context);
/* 113 */     if (webExchange instanceof ISpringWebFluxWebExchange) {
/* 114 */       ISpringWebFluxWebExchange webFluxWebExchange = (ISpringWebFluxWebExchange)webExchange;
/* 115 */       return (ServerWebExchange)webFluxWebExchange.getNativeExchangeObject();
/*     */     } 
/* 117 */     throw new TemplateProcessingException("Cannot obtain ServerWebExchange from a non-WebFlux context implementation (\"" + context
/*     */         
/* 119 */         .getClass().getName() + "\")");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static IServletWebExchange getServletWebExchange(IContext context) {
/* 125 */     IWebExchange webExchange = getWebExchange(context);
/* 126 */     if (webExchange instanceof IServletWebExchange) {
/* 127 */       return (IServletWebExchange)webExchange;
/*     */     }
/* 129 */     throw new TemplateProcessingException("Cannot obtain IServletWebExchange from a non-Servlet context implementation (\"" + context
/*     */         
/* 131 */         .getClass().getName() + "\")");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static IWebExchange getWebExchange(IContext context) {
/* 137 */     if (context instanceof IWebContext) {
/* 138 */       IWebContext webContext = (IWebContext)context;
/* 139 */       return webContext.getExchange();
/*     */     } 
/* 141 */     throw new TemplateProcessingException("Cannot obtain IWebExchange from a non-Servlet context implementation (\"" + context
/*     */         
/* 143 */         .getClass().getName() + "\")");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity\\util\Spring6VersionSpecificUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */