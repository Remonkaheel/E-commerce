/*     */ package org.thymeleaf.extras.springsecurity6.util;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringVersionSpecificUtils
/*     */ {
/*  45 */   private static final Logger LOG = LoggerFactory.getLogger(SpringVersionSpecificUtils.class);
/*     */   
/*  47 */   private static final String PACKAGE_NAME = SpringVersionSpecificUtils.class.getPackage().getName();
/*     */   
/*  49 */   private static final String SPRING6_DELEGATE_CLASS = PACKAGE_NAME + ".Spring6VersionSpecificUtility";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final ISpringVersionSpecificUtility spring6Delegate;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  58 */     if (SpringVersionUtils.isSpring60AtLeast()) {
/*     */       
/*  60 */       LOG.trace("[THYMELEAF][TESTING] Spring 6.0+ found on classpath. Initializing version-specific utilities for Spring 6");
/*     */       
/*     */       try {
/*  63 */         Class<?> implClass = ClassLoaderUtils.loadClass(SPRING6_DELEGATE_CLASS);
/*  64 */         spring6Delegate = implClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/*  65 */       } catch (Exception e) {
/*  66 */         throw new ExceptionInInitializerError(new ConfigurationException("Environment has been detected to be at least Spring 6, but thymeleaf could not initialize a delegate of class \"" + SPRING6_DELEGATE_CLASS + "\"", e));
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  74 */       throw new ExceptionInInitializerError(new ConfigurationException("The Spring-version-specific infrastructure could not create utility for the specific version of Spring being used. Currently only Spring 6.x or newer is supported."));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EvaluationContext wrapEvaluationContext(EvaluationContext evaluationContext, IExpressionObjects expresionObjects) {
/*  89 */     if (spring6Delegate != null) {
/*  90 */       return spring6Delegate.wrapEvaluationContext(evaluationContext, expresionObjects);
/*     */     }
/*     */     
/*  93 */     throw new ConfigurationException("The authorization infrastructure could not create initializer for the specific version of Spring beingused. Currently only Spring 6.x or newer is supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWebContext(IContext context) {
/* 104 */     if (spring6Delegate != null) {
/* 105 */       return spring6Delegate.isWebContext(context);
/*     */     }
/*     */     
/* 108 */     throw new ConfigurationException("The authorization infrastructure could not create initializer for the specific version of Spring beingused. Currently only Spring 6.x or newer is supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWebMvcContext(IContext context) {
/* 117 */     if (spring6Delegate != null) {
/* 118 */       return spring6Delegate.isWebMvcContext(context);
/*     */     }
/*     */     
/* 121 */     throw new ConfigurationException("The authorization infrastructure could not create initializer for the specific version of Spring beingused. Currently only Spring 6.x or newer is supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWebFluxContext(IContext context) {
/* 130 */     if (spring6Delegate != null) {
/* 131 */       return spring6Delegate.isWebFluxContext(context);
/*     */     }
/*     */     
/* 134 */     throw new ConfigurationException("The authorization infrastructure could not create initializer for the specific version of Spring beingused. Currently only Spring 6.x or newer is supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpServletRequest getHttpServletRequest(IContext context) {
/* 145 */     if (spring6Delegate != null) {
/* 146 */       return spring6Delegate.getHttpServletRequest(context);
/*     */     }
/*     */     
/* 149 */     throw new ConfigurationException("The authorization infrastructure could not create initializer for the specific version of Spring beingused. Currently only Spring 6.x or newer is supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpServletResponse getHttpServletResponse(IContext context) {
/* 160 */     if (spring6Delegate != null) {
/* 161 */       return spring6Delegate.getHttpServletResponse(context);
/*     */     }
/*     */     
/* 164 */     throw new ConfigurationException("The authorization infrastructure could not create initializer for the specific version of Spring beingused. Currently only Spring 6.x or newer is supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ServerWebExchange getServerWebExchange(IContext context) {
/* 175 */     if (spring6Delegate != null) {
/* 176 */       return spring6Delegate.getServerWebExchange(context);
/*     */     }
/*     */     
/* 179 */     throw new ConfigurationException("The authorization infrastructure could not create initializer for the specific version of Spring beingused. Currently only Spring 6.x or newer is supported.");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity\\util\SpringVersionSpecificUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */