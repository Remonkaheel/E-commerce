package org.thymeleaf.extras.springsecurity6.util;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.expression.EvaluationContext;
import org.springframework.web.server.ServerWebExchange;
import org.thymeleaf.context.IContext;
import org.thymeleaf.expression.IExpressionObjects;

interface ISpringVersionSpecificUtility {
  EvaluationContext wrapEvaluationContext(EvaluationContext paramEvaluationContext, IExpressionObjects paramIExpressionObjects);
  
  boolean isWebContext(IContext paramIContext);
  
  boolean isWebMvcContext(IContext paramIContext);
  
  boolean isWebFluxContext(IContext paramIContext);
  
  HttpServletRequest getHttpServletRequest(IContext paramIContext);
  
  HttpServletResponse getHttpServletResponse(IContext paramIContext);
  
  ServerWebExchange getServerWebExchange(IContext paramIContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity\\util\ISpringVersionSpecificUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */