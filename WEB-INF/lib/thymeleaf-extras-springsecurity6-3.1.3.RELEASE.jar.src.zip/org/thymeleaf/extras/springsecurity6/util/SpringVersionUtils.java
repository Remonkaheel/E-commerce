/*     */ package org.thymeleaf.extras.springsecurity6.util;
/*     */ 
/*     */ import org.springframework.core.SpringVersion;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ import org.thymeleaf.util.VersionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringVersionUtils
/*     */ {
/*     */   private static final VersionUtils.VersionSpec SPRING_VERSION_SPEC;
/*     */   private static final boolean SPRING_WEB_MVC_PRESENT;
/*     */   private static final boolean SPRING_WEB_REACTIVE_PRESENT;
/*     */   
/*     */   static {
/*  47 */     String springVersion = SpringVersion.getVersion();
/*     */ 
/*     */ 
/*     */     
/*  51 */     String corePackageName = SpringVersion.class.getPackage().getName();
/*  52 */     String springPackageName = corePackageName.substring(0, corePackageName.length() - 5);
/*     */ 
/*     */     
/*  55 */     if (springVersion != null) {
/*     */       
/*  57 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion(springVersion);
/*     */       
/*  59 */       if (SPRING_VERSION_SPEC.isUnknown()) {
/*  60 */         throw new ExceptionInInitializerError("Exception during initialization of Spring versioning utilities. Identified Spring version is '" + springVersion + "', which does not follow the {major}.{minor}.{patch}[.{...}] scheme");
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*  68 */     else if (ClassLoaderUtils.isClassPresent(springPackageName + ".core.io.buffer.DataBuffer")) {
/*  69 */       if (!ClassLoaderUtils.isClassPresent(springPackageName + ".lang.UsesJava8")) {
/*  70 */         SPRING_VERSION_SPEC = VersionUtils.parseVersion("6.0.0");
/*  71 */       } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".util.ConcurrentLruCache")) {
/*  72 */         SPRING_VERSION_SPEC = VersionUtils.parseVersion("5.3.0");
/*  73 */       } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".util.SimpleRouteMatcher")) {
/*  74 */         SPRING_VERSION_SPEC = VersionUtils.parseVersion("5.2.0.RELEASE");
/*  75 */       } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".util.function.SupplierUtils")) {
/*  76 */         SPRING_VERSION_SPEC = VersionUtils.parseVersion("5.1.0.RELEASE");
/*     */       } else {
/*  78 */         SPRING_VERSION_SPEC = VersionUtils.parseVersion("5.0.0.RELEASE");
/*     */       } 
/*  80 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".context.annotation.ComponentScans")) {
/*  81 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("4.3.0.RELEASE");
/*  82 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".core.annotation.AliasFor")) {
/*  83 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("4.2.0.RELEASE");
/*  84 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".cache.annotation.CacheConfig")) {
/*  85 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("4.1.0.RELEASE");
/*  86 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".core.io.PathResource")) {
/*  87 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("4.0.0.RELEASE");
/*  88 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".web.context.request.async.DeferredResult")) {
/*  89 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("3.2.0.RELEASE");
/*  90 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".web.servlet.support.RequestDataValueProcessor")) {
/*  91 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("3.1.0.RELEASE");
/*  92 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".web.bind.annotation.RequestBody")) {
/*  93 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("3.0.0.RELEASE");
/*     */     } else {
/*     */       
/*  96 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("2.5.0.RELEASE");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     SPRING_WEB_MVC_PRESENT = ClassLoaderUtils.isClassPresent(springPackageName + ".web.servlet.View");
/*     */     
/* 104 */     SPRING_WEB_REACTIVE_PRESENT = (SPRING_VERSION_SPEC.isAtLeast(5) && ClassLoaderUtils.isClassPresent(springPackageName + ".web.reactive.result.view.View"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSpringVersion() {
/* 111 */     return SPRING_VERSION_SPEC.getVersion();
/*     */   }
/*     */   
/*     */   public static int getSpringVersionMajor() {
/* 115 */     return SPRING_VERSION_SPEC.getMajor();
/*     */   }
/*     */   
/*     */   public static int getSpringVersionMinor() {
/* 119 */     return SPRING_VERSION_SPEC.getMinor();
/*     */   }
/*     */   
/*     */   public static int getSpringVersionPatch() {
/* 123 */     return SPRING_VERSION_SPEC.getPatch();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSpring30AtLeast() {
/* 129 */     return isSpringAtLeast(3, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpring31AtLeast() {
/* 134 */     return isSpringAtLeast(3, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpring32AtLeast() {
/* 139 */     return isSpringAtLeast(3, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpring40AtLeast() {
/* 144 */     return isSpringAtLeast(4, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpring41AtLeast() {
/* 149 */     return isSpringAtLeast(4, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpring42AtLeast() {
/* 154 */     return isSpringAtLeast(4, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpring43AtLeast() {
/* 159 */     return isSpringAtLeast(4, 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpring50AtLeast() {
/* 164 */     return isSpringAtLeast(5, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpring51AtLeast() {
/* 169 */     return isSpringAtLeast(5, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpring52AtLeast() {
/* 174 */     return isSpringAtLeast(5, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpring53AtLeast() {
/* 179 */     return isSpringAtLeast(5, 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpring60AtLeast() {
/* 184 */     return isSpringAtLeast(6, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpringAtLeast(int major, int minor) {
/* 189 */     return isSpringAtLeast(major, minor, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpringAtLeast(int major, int minor, int patch) {
/* 194 */     return SPRING_VERSION_SPEC.isAtLeast(major, minor, patch);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpringWebMvcPresent() {
/* 199 */     return SPRING_WEB_MVC_PRESENT;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpringWebFluxPresent() {
/* 204 */     return SPRING_WEB_REACTIVE_PRESENT;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity\\util\SpringVersionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */