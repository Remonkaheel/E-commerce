/*     */ package org.thymeleaf.extras.springsecurity6.util;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.security.core.SpringSecurityCoreVersion;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringSecurityVersionUtils
/*     */ {
/*     */   private static final int SPRING_SECURITY_VERSION_MAJOR;
/*     */   private static final int SPRING_SECURITY_VERSION_MINOR;
/*     */   
/*     */   static {
/*  44 */     String springSecurityVersion = SpringSecurityCoreVersion.getVersion();
/*     */ 
/*     */ 
/*     */     
/*  48 */     String securityCorePackageName = SpringSecurityCoreVersion.class.getPackage().getName();
/*     */     
/*  50 */     String springSecurityPackageName = securityCorePackageName.substring(0, securityCorePackageName.length() - 5);
/*     */ 
/*     */     
/*  53 */     if (springSecurityVersion != null) {
/*     */ 
/*     */       
/*     */       try {
/*  57 */         String versionRemainder = springSecurityVersion;
/*     */         
/*  59 */         int separatorIdx = versionRemainder.indexOf('.');
/*  60 */         SPRING_SECURITY_VERSION_MAJOR = Integer.parseInt(versionRemainder.substring(0, separatorIdx));
/*     */         
/*  62 */         int separator2Idx = versionRemainder.indexOf('.', separatorIdx + 1);
/*  63 */         SPRING_SECURITY_VERSION_MINOR = Integer.parseInt(versionRemainder.substring(separatorIdx + 1, separator2Idx));
/*     */       }
/*  65 */       catch (Exception e) {
/*  66 */         throw new ExceptionInInitializerError("Exception during initialization of Spring Security versioning utilities. Identified Spring Security version is '" + springSecurityVersion + "', which does not follow the {major}.{minor}.{...} scheme");
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*  73 */     else if (testClassExistence(springSecurityPackageName + ".web.server.context.SecurityContextServerWebExchange")) {
/*  74 */       SPRING_SECURITY_VERSION_MAJOR = 5;
/*  75 */       SPRING_SECURITY_VERSION_MINOR = 0;
/*  76 */     } else if (testClassExistence(springSecurityPackageName + ".jackson2.SecurityJackson2Modules")) {
/*  77 */       SPRING_SECURITY_VERSION_MAJOR = 4;
/*  78 */       SPRING_SECURITY_VERSION_MINOR = 2;
/*  79 */     } else if (testClassExistence(springSecurityPackageName + ".core.annotation.AuthenticationPrincipal")) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  84 */       Class<?> authenticationPrincipalClass = getClass(springSecurityPackageName + ".core.annotation.AuthenticationPrincipal");
/*  85 */       Method[] methods = authenticationPrincipalClass.getDeclaredMethods();
/*  86 */       boolean hasExpressionAttribute = false;
/*  87 */       for (int i = 0; i < methods.length; i++) {
/*  88 */         if ("expression".equals(methods[i].getName())) {
/*  89 */           hasExpressionAttribute = true;
/*     */         }
/*     */       } 
/*     */       
/*  93 */       if (hasExpressionAttribute) {
/*  94 */         SPRING_SECURITY_VERSION_MAJOR = 4;
/*  95 */         SPRING_SECURITY_VERSION_MINOR = 1;
/*     */       } else {
/*  97 */         SPRING_SECURITY_VERSION_MAJOR = 4;
/*  98 */         SPRING_SECURITY_VERSION_MINOR = 0;
/*     */       }
/*     */     
/* 101 */     } else if (testClassExistence(springSecurityPackageName + ".access.method.P")) {
/* 102 */       SPRING_SECURITY_VERSION_MAJOR = 3;
/* 103 */       SPRING_SECURITY_VERSION_MINOR = 2;
/* 104 */     } else if (testClassExistence(springSecurityPackageName + ".provisioning.MutableUserDetails")) {
/* 105 */       SPRING_SECURITY_VERSION_MAJOR = 3;
/* 106 */       SPRING_SECURITY_VERSION_MINOR = 1;
/* 107 */     } else if (testClassExistence(springSecurityPackageName + ".access.expression.method.AbstractExpressionBasedMethodConfigAttribute")) {
/* 108 */       SPRING_SECURITY_VERSION_MAJOR = 3;
/* 109 */       SPRING_SECURITY_VERSION_MINOR = 0;
/*     */     } else {
/*     */       
/* 112 */       SPRING_SECURITY_VERSION_MAJOR = 2;
/* 113 */       SPRING_SECURITY_VERSION_MINOR = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean testClassExistence(String className) {
/* 123 */     ClassLoader classLoader = ClassLoaderUtils.getClassLoader(SpringSecurityVersionUtils.class);
/*     */     try {
/* 125 */       Class.forName(className, false, classLoader);
/* 126 */       return true;
/* 127 */     } catch (Throwable t) {
/* 128 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static Class<?> getClass(String className) {
/* 134 */     ClassLoader classLoader = ClassLoaderUtils.getClassLoader(SpringSecurityVersionUtils.class);
/*     */     try {
/* 136 */       return Class.forName(className, false, classLoader);
/* 137 */     } catch (Throwable t) {
/* 138 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getSpringSecurityVersionMajor() {
/* 146 */     return SPRING_SECURITY_VERSION_MAJOR;
/*     */   }
/*     */   
/*     */   public static int getSpringSecurityVersionMinor() {
/* 150 */     return SPRING_SECURITY_VERSION_MINOR;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSpringSecurity30AtLeast() {
/* 156 */     return (SPRING_SECURITY_VERSION_MAJOR >= 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpringSecurity31AtLeast() {
/* 161 */     return (SPRING_SECURITY_VERSION_MAJOR > 3 || (SPRING_SECURITY_VERSION_MAJOR == 3 && SPRING_SECURITY_VERSION_MINOR >= 1));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpringSecurity32AtLeast() {
/* 166 */     return (SPRING_SECURITY_VERSION_MAJOR > 3 || (SPRING_SECURITY_VERSION_MAJOR == 3 && SPRING_SECURITY_VERSION_MINOR >= 2));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpringSecurity40AtLeast() {
/* 171 */     return (SPRING_SECURITY_VERSION_MAJOR >= 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpringSecurity41AtLeast() {
/* 176 */     return (SPRING_SECURITY_VERSION_MAJOR > 4 || (SPRING_SECURITY_VERSION_MAJOR == 4 && SPRING_SECURITY_VERSION_MINOR >= 1));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpringSecurity42AtLeast() {
/* 181 */     return (SPRING_SECURITY_VERSION_MAJOR > 4 || (SPRING_SECURITY_VERSION_MAJOR == 4 && SPRING_SECURITY_VERSION_MINOR >= 2));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpringSecurity50AtLeast() {
/* 186 */     return (SPRING_SECURITY_VERSION_MAJOR >= 5);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity\\util\SpringSecurityVersionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */