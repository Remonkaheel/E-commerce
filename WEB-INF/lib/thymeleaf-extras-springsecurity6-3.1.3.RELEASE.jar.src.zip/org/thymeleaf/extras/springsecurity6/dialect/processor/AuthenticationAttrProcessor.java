/*    */ package org.thymeleaf.extras.springsecurity6.dialect.processor;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.extras.springsecurity6.auth.AuthUtils;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.EscapedAttributeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AuthenticationAttrProcessor
/*    */   extends AbstractAttributeTagProcessor
/*    */ {
/*    */   public static final int ATTR_PRECEDENCE = 1300;
/*    */   public static final String ATTR_NAME = "authentication";
/*    */   
/*    */   public AuthenticationAttrProcessor(TemplateMode templateMode, String dialectPrefix) {
/* 48 */     super(templateMode, dialectPrefix, null, false, "authentication", true, 1300, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler) {
/* 60 */     String attrValue = (attributeValue == null) ? null : attributeValue.trim();
/*    */     
/* 62 */     if (attrValue == null || attrValue.length() == 0) {
/*    */       return;
/*    */     }
/*    */     
/* 66 */     Authentication authentication = AuthUtils.getAuthenticationObject((IExpressionContext)context);
/* 67 */     Object authenticationProperty = AuthUtils.getAuthenticationProperty(authentication, attrValue);
/*    */     
/* 69 */     if (authenticationProperty == null) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 74 */     String encodedAttribute = EscapedAttributeUtils.escapeAttribute(getTemplateMode(), authenticationProperty.toString());
/* 75 */     structureHandler.setBody(encodedAttribute, false);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity6\dialect\processor\AuthenticationAttrProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */