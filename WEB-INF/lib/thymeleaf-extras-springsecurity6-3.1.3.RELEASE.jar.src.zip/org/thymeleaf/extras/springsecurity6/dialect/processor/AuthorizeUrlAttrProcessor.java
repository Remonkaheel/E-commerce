/*    */ package org.thymeleaf.extras.springsecurity6.dialect.processor;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.extras.springsecurity6.auth.AuthUtils;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.standard.processor.AbstractStandardConditionalVisibilityTagProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AuthorizeUrlAttrProcessor
/*    */   extends AbstractStandardConditionalVisibilityTagProcessor
/*    */ {
/*    */   public static final int ATTR_PRECEDENCE = 300;
/*    */   public static final String ATTR_NAME = "authorize-url";
/*    */   
/*    */   public AuthorizeUrlAttrProcessor(TemplateMode templateMode, String dialectPrefix) {
/* 46 */     super(templateMode, dialectPrefix, "authorize-url", 300);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isVisible(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue) {
/* 56 */     String attrValue = (attributeValue == null) ? null : attributeValue.trim();
/*    */     
/* 58 */     if (attrValue == null || attrValue.length() == 0) {
/* 59 */       return false;
/*    */     }
/*    */     
/* 62 */     int spaceIndex = attrValue.indexOf(' ');
/*    */     
/* 64 */     String url = ((spaceIndex < 0) ? attrValue : attrValue.substring(spaceIndex + 1)).trim();
/*    */     
/* 66 */     String method = ((spaceIndex < 0) ? "GET" : attrValue.substring(0, spaceIndex)).trim();
/*    */     
/* 68 */     Authentication authentication = AuthUtils.getAuthenticationObject((IExpressionContext)context);
/*    */     
/* 70 */     if (authentication == null) {
/* 71 */       return false;
/*    */     }
/*    */     
/* 74 */     return AuthUtils.authorizeUsingUrlCheck((IExpressionContext)context, url, method, authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity6\dialect\processor\AuthorizeUrlAttrProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */