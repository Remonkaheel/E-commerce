/*     */ package org.thymeleaf.extras.springsecurity6.dialect.expression;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*     */ import org.thymeleaf.extras.springsecurity6.auth.AuthUtils;
/*     */ import org.thymeleaf.extras.springsecurity6.auth.Authorization;
/*     */ import org.thymeleaf.extras.springsecurity6.util.SpringVersionSpecificUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringSecurityExpressionObjectFactory
/*     */   implements IExpressionObjectFactory
/*     */ {
/*     */   public static final String AUTHENTICATION_EXPRESSION_OBJECT_NAME = "authentication";
/*     */   public static final String AUTHORIZATION_EXPRESSION_OBJECT_NAME = "authorization";
/*  57 */   protected static final Set<String> ALL_EXPRESSION_OBJECT_NAMES = Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(new String[] { "authentication", "authorization" })));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getAllExpressionObjectNames() {
/*  75 */     return ALL_EXPRESSION_OBJECT_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCacheable(String expressionObjectName) {
/*  82 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object buildObject(IExpressionContext context, String expressionObjectName) {
/*  89 */     if ("authentication".equals(expressionObjectName) && 
/*  90 */       SpringVersionSpecificUtils.isWebContext((IContext)context)) {
/*  91 */       return AuthUtils.getAuthenticationObject(context);
/*     */     }
/*     */ 
/*     */     
/*  95 */     if ("authorization".equals(expressionObjectName)) {
/*  96 */       if (SpringVersionSpecificUtils.isWebContext((IContext)context)) {
/*     */ 
/*     */ 
/*     */         
/* 100 */         Authentication authentication = (Authentication)context.getExpressionObjects().getObject("authentication");
/*     */         
/* 102 */         return new Authorization(context, authentication);
/*     */       } 
/*     */       
/* 105 */       return null;
/*     */     } 
/*     */     
/* 108 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity6\dialect\expression\SpringSecurityExpressionObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */