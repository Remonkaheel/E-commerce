/*    */ package org.thymeleaf.extras.springsecurity6.dialect.processor;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.extras.springsecurity6.auth.AuthUtils;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.standard.processor.AbstractStandardConditionalVisibilityTagProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AuthorizeAttrProcessor
/*    */   extends AbstractStandardConditionalVisibilityTagProcessor
/*    */ {
/*    */   public static final int ATTR_PRECEDENCE = 300;
/*    */   public static final String ATTR_NAME = "authorize";
/*    */   public static final String ATTR_NAME_EXPR = "authorize-expr";
/*    */   
/*    */   public AuthorizeAttrProcessor(TemplateMode templateMode, String dialectPrefix, String attrName) {
/* 48 */     super(templateMode, dialectPrefix, attrName, 300);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isVisible(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue) {
/* 61 */     String attrValue = (attributeValue == null) ? null : attributeValue.trim();
/*    */     
/* 63 */     if (attrValue == null || attrValue.length() == 0) {
/* 64 */       return false;
/*    */     }
/*    */     
/* 67 */     Authentication authentication = AuthUtils.getAuthenticationObject((IExpressionContext)context);
/*    */     
/* 69 */     if (authentication == null) {
/* 70 */       return false;
/*    */     }
/*    */     
/* 73 */     return AuthUtils.authorizeUsingAccessExpression((IExpressionContext)context, attrValue, authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity6\dialect\processor\AuthorizeAttrProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */