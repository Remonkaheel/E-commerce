/*     */ package org.thymeleaf.extras.springsecurity6.dialect;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*     */ import org.springframework.security.web.server.csrf.CsrfToken;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.thymeleaf.dialect.AbstractDialect;
/*     */ import org.thymeleaf.dialect.IExecutionAttributeDialect;
/*     */ import org.thymeleaf.dialect.IExpressionObjectDialect;
/*     */ import org.thymeleaf.dialect.IProcessorDialect;
/*     */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*     */ import org.thymeleaf.extras.springsecurity6.dialect.expression.SpringSecurityExpressionObjectFactory;
/*     */ import org.thymeleaf.extras.springsecurity6.dialect.processor.AuthenticationAttrProcessor;
/*     */ import org.thymeleaf.extras.springsecurity6.dialect.processor.AuthorizeAclAttrProcessor;
/*     */ import org.thymeleaf.extras.springsecurity6.dialect.processor.AuthorizeAttrProcessor;
/*     */ import org.thymeleaf.extras.springsecurity6.dialect.processor.AuthorizeUrlAttrProcessor;
/*     */ import org.thymeleaf.extras.springsecurity6.util.SpringVersionUtils;
/*     */ import org.thymeleaf.processor.IProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardXmlNsTagProcessor;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringSecurityDialect
/*     */   extends AbstractDialect
/*     */   implements IProcessorDialect, IExpressionObjectDialect, IExecutionAttributeDialect
/*     */ {
/*     */   public static final String NAME = "SpringSecurity";
/*     */   public static final String DEFAULT_PREFIX = "sec";
/*     */   public static final int PROCESSOR_PRECEDENCE = 800;
/*  64 */   private static final IExpressionObjectFactory EXPRESSION_OBJECT_FACTORY = (IExpressionObjectFactory)new SpringSecurityExpressionObjectFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Map<String, Object> EXECUTION_ATTRIBUTES;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String SECURITY_CONTEXT_EXECUTION_ATTRIBUTE_NAME = "ThymeleafReactiveModelAdditions:thymeleafSpringSecurityContext";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String CSRF_EXECUTION_ATTRIBUTE_NAME = "ThymeleafReactiveModelAdditions:_csrf";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  84 */     if (!SpringVersionUtils.isSpringWebFluxPresent()) {
/*     */       
/*  86 */       EXECUTION_ATTRIBUTES = null;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  91 */       Function<ServerWebExchange, Object> secCtxInitializer = exchange -> ReactiveSecurityContextHolder.getContext();
/*     */ 
/*     */ 
/*     */       
/*  95 */       Function<ServerWebExchange, Object> csrfTokenInitializer = exchange -> {
/*     */           Mono<CsrfToken> csrfToken = (Mono<CsrfToken>)exchange.getAttribute(CsrfToken.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return (csrfToken == null) ? Mono.empty() : csrfToken.doOnSuccess(());
/*     */         };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 109 */       EXECUTION_ATTRIBUTES = new HashMap<>(3, 1.0F);
/* 110 */       EXECUTION_ATTRIBUTES.put("ThymeleafReactiveModelAdditions:thymeleafSpringSecurityContext", secCtxInitializer);
/* 111 */       EXECUTION_ATTRIBUTES.put("ThymeleafReactiveModelAdditions:_csrf", csrfTokenInitializer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringSecurityDialect() {
/* 120 */     super("SpringSecurity");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/* 126 */     return "sec";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDialectProcessorPrecedence() {
/* 133 */     return 800;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<IProcessor> getProcessors(String dialectPrefix) {
/* 141 */     Set<IProcessor> processors = new LinkedHashSet<>();
/*     */     
/* 143 */     TemplateMode[] templateModes = { TemplateMode.HTML, TemplateMode.XML, TemplateMode.TEXT, TemplateMode.JAVASCRIPT, TemplateMode.CSS };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     for (TemplateMode templateMode : templateModes) {
/*     */       
/* 150 */       processors.add(new AuthenticationAttrProcessor(templateMode, dialectPrefix));
/*     */ 
/*     */       
/* 153 */       processors.add(new AuthorizeAttrProcessor(templateMode, dialectPrefix, "authorize"));
/* 154 */       processors.add(new AuthorizeAttrProcessor(templateMode, dialectPrefix, "authorize-expr"));
/* 155 */       processors.add(new AuthorizeUrlAttrProcessor(templateMode, dialectPrefix));
/* 156 */       processors.add(new AuthorizeAclAttrProcessor(templateMode, dialectPrefix));
/* 157 */       processors.add(new StandardXmlNsTagProcessor(templateMode, dialectPrefix));
/*     */     } 
/*     */ 
/*     */     
/* 161 */     return processors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IExpressionObjectFactory getExpressionObjectFactory() {
/* 170 */     return EXPRESSION_OBJECT_FACTORY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getExecutionAttributes() {
/* 178 */     return EXECUTION_ATTRIBUTES;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity6\dialect\SpringSecurityDialect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */