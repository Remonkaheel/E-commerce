/*     */ package org.thymeleaf.extras.springsecurity6.dialect.processor;
/*     */ 
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.extras.springsecurity6.auth.AclAuthUtils;
/*     */ import org.thymeleaf.extras.springsecurity6.auth.AuthUtils;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.standard.expression.TextLiteralExpression;
/*     */ import org.thymeleaf.standard.processor.AbstractStandardConditionalVisibilityTagProcessor;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizeAclAttrProcessor
/*     */   extends AbstractStandardConditionalVisibilityTagProcessor
/*     */ {
/*     */   public static final int ATTR_PRECEDENCE = 300;
/*     */   public static final String ATTR_NAME = "authorize-acl";
/*     */   private static final String VALUE_SEPARATOR = "::";
/*     */   
/*     */   public AuthorizeAclAttrProcessor(TemplateMode templateMode, String dialectPrefix) {
/*  59 */     super(templateMode, dialectPrefix, "authorize-acl", 300);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isVisible(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue) {
/*  69 */     String attrValue = (attributeValue == null) ? null : attributeValue.trim();
/*     */     
/*  71 */     if (attrValue == null || attrValue.length() == 0) {
/*  72 */       return false;
/*     */     }
/*     */     
/*  75 */     Authentication authentication = AuthUtils.getAuthenticationObject((IExpressionContext)context);
/*  76 */     if (authentication == null) {
/*  77 */       return false;
/*     */     }
/*     */     
/*  80 */     ApplicationContext applicationContext = AuthUtils.getContext((IContext)context);
/*     */     
/*  82 */     IEngineConfiguration configuration = context.getConfiguration();
/*     */     
/*  84 */     int separatorPos = attrValue.lastIndexOf("::");
/*  85 */     if (separatorPos == -1) {
/*  86 */       throw new TemplateProcessingException("Could not parse \"" + attributeValue + "\" as an access control list expression. Syntax should be \"[domain object expression] :: [permissions]\"");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  91 */     String domainObjectExpression = attrValue.substring(0, separatorPos).trim();
/*  92 */     String permissionsExpression = attrValue.substring(separatorPos + 2).trim();
/*     */     
/*  94 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(configuration);
/*     */ 
/*     */     
/*  97 */     IStandardExpression domainObjectExpr = getExpressionDefaultToLiteral(expressionParser, (IExpressionContext)context, domainObjectExpression);
/*     */     
/*  99 */     IStandardExpression permissionsExpr = getExpressionDefaultToLiteral(expressionParser, (IExpressionContext)context, permissionsExpression);
/*     */     
/* 101 */     Object domainObject = domainObjectExpr.execute((IExpressionContext)context);
/*     */     
/* 103 */     Object permissionsObject = permissionsExpr.execute((IExpressionContext)context);
/*     */     
/* 105 */     String permissionsStr = (permissionsObject == null) ? null : permissionsObject.toString();
/*     */     
/* 107 */     return AclAuthUtils.authorizeUsingAccessControlList((IExpressionContext)context, domainObject, applicationContext, permissionsStr, authentication);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static IStandardExpression getExpressionDefaultToLiteral(IStandardExpressionParser expressionParser, IExpressionContext context, String input) {
/* 119 */     IStandardExpression expression = expressionParser.parseExpression(context, input);
/* 120 */     if (expression == null) {
/* 121 */       return (IStandardExpression)new TextLiteralExpression(input);
/*     */     }
/* 123 */     return expression;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-extras-springsecurity6-3.1.3.RELEASE.jar!\org\thymeleaf\extras\springsecurity6\dialect\processor\AuthorizeAclAttrProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */