module org.jboss.logging {
  requires java.base;
  requires java.logging;
  requires log4j.api;
  requires org.apache.logging.log4j;
  requires org.slf4j;
  
  exports org.jboss.logging;
  
  uses org.jboss.logging.LoggerProvider;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */