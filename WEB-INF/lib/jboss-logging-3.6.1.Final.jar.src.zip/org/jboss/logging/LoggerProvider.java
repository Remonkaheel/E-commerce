package org.jboss.logging;

import java.util.Map;

public interface LoggerProvider {
  Logger getLogger(String paramString);
  
  void clearMdc();
  
  Object putMdc(String paramString, Object paramObject);
  
  Object getMdc(String paramString);
  
  void removeMdc(String paramString);
  
  Map<String, Object> getMdcMap();
  
  void clearNdc();
  
  String getNdc();
  
  int getNdcDepth();
  
  String popNdc();
  
  String peekNdc();
  
  void pushNdc(String paramString);
  
  void setNdcMaxDepth(int paramInt);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\LoggerProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */