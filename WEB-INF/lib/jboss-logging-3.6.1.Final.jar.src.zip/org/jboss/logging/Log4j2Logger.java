/*    */ package org.jboss.logging;
/*    */ 
/*    */ import org.apache.logging.log4j.Level;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.logging.log4j.LoggingException;
/*    */ import org.apache.logging.log4j.message.Message;
/*    */ import org.apache.logging.log4j.message.MessageFormatMessageFactory;
/*    */ import org.apache.logging.log4j.message.StringFormattedMessage;
/*    */ import org.apache.logging.log4j.spi.AbstractLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Log4j2Logger
/*    */   extends Logger
/*    */ {
/*    */   private static final long serialVersionUID = -2507841068232627725L;
/*    */   private final AbstractLogger logger;
/*    */   private final MessageFormatMessageFactory messageFactory;
/*    */   
/*    */   Log4j2Logger(String name) {
/* 35 */     super(name);
/* 36 */     Logger logger = LogManager.getLogger(name);
/* 37 */     if (!(logger instanceof AbstractLogger)) {
/* 38 */       throw new LoggingException("The logger for [" + name + "] does not extend AbstractLogger. Actual logger: " + logger
/* 39 */           .getClass().getName());
/*    */     }
/* 41 */     this.logger = (AbstractLogger)logger;
/* 42 */     this.messageFactory = new MessageFormatMessageFactory();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEnabled(Logger.Level level) {
/* 47 */     return this.logger.isEnabled(translate(level));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doLog(Logger.Level level, String loggerClassName, Object message, Object[] parameters, Throwable thrown) {
/* 53 */     Level translatedLevel = translate(level);
/* 54 */     if (this.logger.isEnabled(translatedLevel)) {
/*    */       try {
/* 56 */         this.logger.logMessage(loggerClassName, translatedLevel, null, (
/* 57 */             parameters == null || parameters.length == 0) ? this.messageFactory.newMessage(String.valueOf(message)) : 
/* 58 */             this.messageFactory.newMessage(String.valueOf(message), parameters), thrown);
/*    */       }
/* 60 */       catch (Throwable throwable) {}
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doLogf(Logger.Level level, String loggerClassName, String format, Object[] parameters, Throwable thrown) {
/* 68 */     Level translatedLevel = translate(level);
/* 69 */     if (this.logger.isEnabled(translatedLevel)) {
/*    */       try {
/* 71 */         this.logger.logMessage(loggerClassName, translatedLevel, null, (Message)new StringFormattedMessage(format, parameters), thrown);
/*    */       }
/* 73 */       catch (Throwable throwable) {}
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private static Level translate(Logger.Level level) {
/* 79 */     if (level == Logger.Level.TRACE)
/* 80 */       return Level.TRACE; 
/* 81 */     if (level == Logger.Level.DEBUG) {
/* 82 */       return Level.DEBUG;
/*    */     }
/* 84 */     return infoOrHigher(level);
/*    */   }
/*    */   
/*    */   private static Level infoOrHigher(Logger.Level level) {
/* 88 */     if (level == Logger.Level.INFO)
/* 89 */       return Level.INFO; 
/* 90 */     if (level == Logger.Level.WARN)
/* 91 */       return Level.WARN; 
/* 92 */     if (level == Logger.Level.ERROR)
/* 93 */       return Level.ERROR; 
/* 94 */     if (level == Logger.Level.FATAL) {
/* 95 */       return Level.FATAL;
/*    */     }
/* 97 */     return Level.ALL;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\Log4j2Logger.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */