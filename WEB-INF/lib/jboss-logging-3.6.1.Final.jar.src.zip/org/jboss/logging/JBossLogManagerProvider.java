/*     */ package org.jboss.logging;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.jboss.logmanager.LogContext;
/*     */ import org.jboss.logmanager.Logger;
/*     */ import org.jboss.logmanager.MDC;
/*     */ import org.jboss.logmanager.NDC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JBossLogManagerProvider
/*     */   implements LoggerProvider
/*     */ {
/*  38 */   private static final Logger.AttachmentKey<Logger> KEY = new Logger.AttachmentKey();
/*  39 */   private static final Logger.AttachmentKey<ConcurrentMap<String, Logger>> LEGACY_KEY = new Logger.AttachmentKey();
/*     */ 
/*     */   
/*     */   public Logger getLogger(String name) {
/*  43 */     SecurityManager sm = System.getSecurityManager();
/*  44 */     if (sm != null) {
/*  45 */       return AccessController.<Logger>doPrivileged(() -> {
/*     */             try {
/*     */               return doGetLogger(name);
/*  48 */             } catch (NoSuchMethodError noSuchMethodError) {
/*     */               return doLegacyGetLogger(name);
/*     */             } 
/*     */           });
/*     */     }
/*     */     
/*     */     try {
/*  55 */       return doGetLogger(name);
/*  56 */     } catch (NoSuchMethodError noSuchMethodError) {
/*     */ 
/*     */       
/*  59 */       return doLegacyGetLogger(name);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Logger doLegacyGetLogger(String name) {
/*  64 */     Logger lmLogger = LogContext.getLogContext().getLogger("");
/*  65 */     ConcurrentMap<String, Logger> loggers = (ConcurrentMap<String, Logger>)lmLogger.getAttachment(LEGACY_KEY);
/*  66 */     if (loggers == null) {
/*  67 */       loggers = new ConcurrentHashMap<>();
/*  68 */       ConcurrentMap<String, Logger> concurrentMap = (ConcurrentMap<String, Logger>)lmLogger.attachIfAbsent(LEGACY_KEY, loggers);
/*  69 */       if (concurrentMap != null) {
/*  70 */         loggers = concurrentMap;
/*     */       }
/*     */     } 
/*     */     
/*  74 */     Logger l = loggers.get(name);
/*  75 */     if (l != null) {
/*  76 */       return l;
/*     */     }
/*     */     
/*  79 */     Logger logger = Logger.getLogger(name);
/*  80 */     l = new JBossLogManagerLogger(name, logger);
/*  81 */     Logger appearing = loggers.putIfAbsent(name, l);
/*  82 */     if (appearing == null) {
/*  83 */       return l;
/*     */     }
/*  85 */     return appearing;
/*     */   }
/*     */   
/*     */   private static Logger doGetLogger(String name) {
/*  89 */     Logger l = (Logger)LogContext.getLogContext().getAttachment(name, KEY);
/*  90 */     if (l != null) {
/*  91 */       return l;
/*     */     }
/*  93 */     Logger logger = Logger.getLogger(name);
/*  94 */     l = new JBossLogManagerLogger(name, logger);
/*  95 */     Logger a = (Logger)logger.attachIfAbsent(KEY, l);
/*  96 */     if (a == null) {
/*  97 */       return l;
/*     */     }
/*  99 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearMdc() {
/* 105 */     MDC.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object putMdc(String key, Object value) {
/* 110 */     return MDC.putObject(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getMdc(String key) {
/* 115 */     return MDC.getObject(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeMdc(String key) {
/* 120 */     MDC.removeObject(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getMdcMap() {
/* 126 */     return MDC.copyObject();
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearNdc() {
/* 131 */     NDC.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNdc() {
/* 136 */     return NDC.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNdcDepth() {
/* 141 */     return NDC.getDepth();
/*     */   }
/*     */ 
/*     */   
/*     */   public String popNdc() {
/* 146 */     return NDC.pop();
/*     */   }
/*     */ 
/*     */   
/*     */   public String peekNdc() {
/* 151 */     return NDC.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushNdc(String message) {
/* 156 */     NDC.push(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNdcMaxDepth(int maxDepth) {
/* 161 */     NDC.trimTo(maxDepth);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\JBossLogManagerProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */