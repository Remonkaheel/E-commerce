/*    */ package org.jboss.logging;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import org.apache.log4j.Level;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.apache.log4j.Priority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Log4jLogger
/*    */   extends Logger
/*    */ {
/*    */   private static final long serialVersionUID = -5446154366955151335L;
/*    */   private final Logger logger;
/*    */   
/*    */   Log4jLogger(String name) {
/* 30 */     super(name);
/* 31 */     this.logger = Logger.getLogger(name);
/*    */   }
/*    */   
/*    */   public boolean isEnabled(Logger.Level level) {
/* 35 */     Level l = translate(level);
/* 36 */     return (this.logger.isEnabledFor((Priority)l) && l.isGreaterOrEqual((Priority)this.logger.getEffectiveLevel()));
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doLog(Logger.Level level, String loggerClassName, Object message, Object[] parameters, Throwable thrown) {
/* 41 */     Level translatedLevel = translate(level);
/* 42 */     if (this.logger.isEnabledFor((Priority)translatedLevel)) {
/*    */       try {
/* 44 */         this.logger.log(loggerClassName, (Priority)translatedLevel, (parameters == null || parameters.length == 0) ? message : 
/* 45 */             MessageFormat.format(String.valueOf(message), parameters), thrown);
/* 46 */       } catch (Throwable throwable) {}
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doLogf(Logger.Level level, String loggerClassName, String format, Object[] parameters, Throwable thrown) {
/* 52 */     Level translatedLevel = translate(level);
/* 53 */     if (this.logger.isEnabledFor((Priority)translatedLevel)) {
/*    */       try {
/* 55 */         this.logger.log(loggerClassName, (Priority)translatedLevel, 
/* 56 */             (parameters == null) ? String.format(format, new Object[0]) : String.format(format, parameters), thrown);
/* 57 */       } catch (Throwable throwable) {}
/*    */     }
/*    */   }
/*    */   
/*    */   private static Level translate(Logger.Level level) {
/* 62 */     if (level == Logger.Level.TRACE)
/* 63 */       return Level.TRACE; 
/* 64 */     if (level == Logger.Level.DEBUG) {
/* 65 */       return Level.DEBUG;
/*    */     }
/* 67 */     return infoOrHigher(level);
/*    */   }
/*    */   
/*    */   private static Level infoOrHigher(Logger.Level level) {
/* 71 */     if (level == Logger.Level.INFO)
/* 72 */       return Level.INFO; 
/* 73 */     if (level == Logger.Level.WARN)
/* 74 */       return Level.WARN; 
/* 75 */     if (level == Logger.Level.ERROR)
/* 76 */       return Level.ERROR; 
/* 77 */     if (level == Logger.Level.FATAL) {
/* 78 */       return Level.FATAL;
/*    */     }
/* 80 */     return Level.ALL;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\Log4jLogger.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */