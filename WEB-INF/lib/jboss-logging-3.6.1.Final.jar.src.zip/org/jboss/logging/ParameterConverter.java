package org.jboss.logging;

import java.util.Locale;

@Deprecated
public interface ParameterConverter<I> {
  Object convert(Locale paramLocale, I paramI);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\ParameterConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */