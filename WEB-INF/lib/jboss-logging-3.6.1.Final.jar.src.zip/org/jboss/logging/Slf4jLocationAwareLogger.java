/*     */ package org.jboss.logging;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.text.MessageFormat;
/*     */ import org.slf4j.spi.LocationAwareLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Slf4jLocationAwareLogger
/*     */   extends Logger
/*     */ {
/*     */   private static final long serialVersionUID = 8685757928087758380L;
/*  32 */   private static final Object[] EMPTY = new Object[0];
/*     */   
/*     */   private static final boolean POST_1_6;
/*     */   
/*     */   static {
/*  37 */     Method[] methods = LocationAwareLogger.class.getDeclaredMethods();
/*  38 */     Method logMethod = null;
/*  39 */     boolean post16 = false;
/*  40 */     for (Method method : methods) {
/*  41 */       if (method.getName().equals("log")) {
/*  42 */         logMethod = method;
/*  43 */         Class<?>[] parameterTypes = method.getParameterTypes();
/*  44 */         post16 = (parameterTypes.length == 6);
/*     */       } 
/*     */     } 
/*  47 */     if (logMethod == null) {
/*  48 */       throw new NoSuchMethodError("Cannot find LocationAwareLogger.log() method");
/*     */     }
/*  50 */     POST_1_6 = post16;
/*  51 */     LOG_METHOD = logMethod;
/*     */   }
/*     */   private static final Method LOG_METHOD;
/*     */   private final LocationAwareLogger logger;
/*     */   
/*     */   Slf4jLocationAwareLogger(String name, LocationAwareLogger logger) {
/*  57 */     super(name);
/*  58 */     this.logger = logger;
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Logger.Level level) {
/*  62 */     if (level != null)
/*  63 */       switch (level) {
/*     */         case FATAL:
/*  65 */           return this.logger.isErrorEnabled();
/*     */         case ERROR:
/*  67 */           return this.logger.isErrorEnabled();
/*     */         case WARN:
/*  69 */           return this.logger.isWarnEnabled();
/*     */         case INFO:
/*  71 */           return this.logger.isInfoEnabled();
/*     */         case DEBUG:
/*  73 */           return this.logger.isDebugEnabled();
/*     */         case TRACE:
/*  75 */           return this.logger.isTraceEnabled();
/*     */       }  
/*  77 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doLog(Logger.Level level, String loggerClassName, Object message, Object[] parameters, Throwable thrown) {
/*  82 */     if (isEnabled(level)) {
/*     */       
/*  84 */       String text = (parameters == null || parameters.length == 0) ? String.valueOf(message) : MessageFormat.format(String.valueOf(message), parameters);
/*  85 */       doLog(this.logger, loggerClassName, translate(level), text, thrown);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doLogf(Logger.Level level, String loggerClassName, String format, Object[] parameters, Throwable thrown) {
/*  91 */     if (isEnabled(level)) {
/*  92 */       String text = (parameters == null) ? String.format(format, new Object[0]) : String.format(format, parameters);
/*  93 */       doLog(this.logger, loggerClassName, translate(level), text, thrown);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void doLog(LocationAwareLogger logger, String className, int level, String text, Throwable thrown) {
/*     */     try {
/*  99 */       if (POST_1_6) {
/* 100 */         LOG_METHOD.invoke(logger, new Object[] { null, className, Integer.valueOf(level), text, EMPTY, thrown });
/*     */       } else {
/* 102 */         LOG_METHOD.invoke(logger, new Object[] { null, className, Integer.valueOf(level), text, thrown });
/*     */       } 
/* 104 */     } catch (InvocationTargetException e) {
/*     */       try {
/* 106 */         throw e.getCause();
/* 107 */       } catch (RuntimeException ex) {
/* 108 */         throw ex;
/* 109 */       } catch (Error er) {
/* 110 */         throw er;
/* 111 */       } catch (Throwable throwable) {
/* 112 */         throw new UndeclaredThrowableException(throwable);
/*     */       } 
/* 114 */     } catch (IllegalAccessException e) {
/* 115 */       throw new IllegalAccessError(e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int translate(Logger.Level level) {
/* 120 */     if (level != null)
/* 121 */       switch (level) {
/*     */         case FATAL:
/*     */         case ERROR:
/* 124 */           return 40;
/*     */         case WARN:
/* 126 */           return 30;
/*     */         case INFO:
/* 128 */           return 20;
/*     */         case DEBUG:
/* 130 */           return 10;
/*     */         case TRACE:
/* 132 */           return 0;
/*     */       }  
/* 134 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\Slf4jLocationAwareLogger.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */