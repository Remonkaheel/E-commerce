/*     */ package org.jboss.logging;
/*     */ 
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JDKLogger
/*     */   extends Logger
/*     */ {
/*     */   private static final long serialVersionUID = 2563174097983721393L;
/*     */   private final transient Logger logger;
/*     */   
/*     */   public JDKLogger(String name) {
/*  32 */     super(name);
/*  33 */     this.logger = Logger.getLogger(name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doLog(Logger.Level level, String loggerClassName, Object message, Object[] parameters, Throwable thrown) {
/*  38 */     if (isEnabled(level)) {
/*     */       try {
/*  40 */         JBossLogRecord rec = new JBossLogRecord(translate(level), String.valueOf(message), loggerClassName);
/*  41 */         if (thrown != null)
/*  42 */           rec.setThrown(thrown); 
/*  43 */         rec.setLoggerName(getName());
/*  44 */         rec.setParameters(parameters);
/*  45 */         rec.setResourceBundleName(this.logger.getResourceBundleName());
/*  46 */         rec.setResourceBundle(this.logger.getResourceBundle());
/*  47 */         this.logger.log(rec);
/*  48 */       } catch (Throwable throwable) {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doLogf(Logger.Level level, String loggerClassName, String format, Object[] parameters, Throwable thrown) {
/*  54 */     if (isEnabled(level)) {
/*     */       try {
/*  56 */         ResourceBundle resourceBundle = this.logger.getResourceBundle();
/*  57 */         if (resourceBundle != null) {
/*     */           try {
/*  59 */             format = resourceBundle.getString(format);
/*  60 */           } catch (MissingResourceException missingResourceException) {}
/*     */         }
/*     */         
/*  63 */         String msg = (parameters == null) ? String.format(format, new Object[0]) : String.format(format, parameters);
/*  64 */         JBossLogRecord rec = new JBossLogRecord(translate(level), msg, loggerClassName);
/*  65 */         if (thrown != null)
/*  66 */           rec.setThrown(thrown); 
/*  67 */         rec.setLoggerName(getName());
/*  68 */         rec.setResourceBundleName(this.logger.getResourceBundleName());
/*     */         
/*  70 */         rec.setResourceBundle(null);
/*  71 */         rec.setParameters(null);
/*  72 */         this.logger.log(rec);
/*  73 */       } catch (Throwable throwable) {}
/*     */     }
/*     */   }
/*     */   
/*     */   private static Level translate(Logger.Level level) {
/*  78 */     if (level == Logger.Level.TRACE)
/*  79 */       return JDKLevel.TRACE; 
/*  80 */     if (level == Logger.Level.DEBUG) {
/*  81 */       return JDKLevel.DEBUG;
/*     */     }
/*  83 */     return infoOrHigher(level);
/*     */   }
/*     */   
/*     */   private static Level infoOrHigher(Logger.Level level) {
/*  87 */     if (level == Logger.Level.INFO)
/*  88 */       return JDKLevel.INFO; 
/*  89 */     if (level == Logger.Level.WARN)
/*  90 */       return JDKLevel.WARN; 
/*  91 */     if (level == Logger.Level.ERROR)
/*  92 */       return JDKLevel.ERROR; 
/*  93 */     if (level == Logger.Level.FATAL) {
/*  94 */       return JDKLevel.FATAL;
/*     */     }
/*  96 */     return JDKLevel.ALL;
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Logger.Level level) {
/* 100 */     return this.logger.isLoggable(translate(level));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\JDKLogger.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */