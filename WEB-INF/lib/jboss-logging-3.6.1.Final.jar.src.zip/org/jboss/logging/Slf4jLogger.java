/*    */ package org.jboss.logging;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import org.slf4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Slf4jLogger
/*    */   extends Logger
/*    */ {
/*    */   private static final long serialVersionUID = 8685757928087758380L;
/*    */   private final Logger logger;
/*    */   
/*    */   Slf4jLogger(String name, Logger logger) {
/* 30 */     super(name);
/* 31 */     this.logger = logger;
/*    */   }
/*    */   
/*    */   public boolean isEnabled(Logger.Level level) {
/* 35 */     if (level == Logger.Level.TRACE)
/* 36 */       return this.logger.isTraceEnabled(); 
/* 37 */     if (level == Logger.Level.DEBUG) {
/* 38 */       return this.logger.isDebugEnabled();
/*    */     }
/* 40 */     return infoOrHigherEnabled(level);
/*    */   }
/*    */   
/*    */   private boolean infoOrHigherEnabled(Logger.Level level) {
/* 44 */     if (level == Logger.Level.INFO)
/* 45 */       return this.logger.isInfoEnabled(); 
/* 46 */     if (level == Logger.Level.WARN)
/* 47 */       return this.logger.isWarnEnabled(); 
/* 48 */     if (level == Logger.Level.ERROR || level == Logger.Level.FATAL) {
/* 49 */       return this.logger.isErrorEnabled();
/*    */     }
/* 51 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doLog(Logger.Level level, String loggerClassName, Object message, Object[] parameters, Throwable thrown) {
/* 56 */     if (isEnabled(level)) {
/*    */       
/*    */       try {
/* 59 */         String text = (parameters == null || parameters.length == 0) ? String.valueOf(message) : MessageFormat.format(String.valueOf(message), parameters);
/* 60 */         if (level == Logger.Level.INFO) {
/* 61 */           this.logger.info(text, thrown);
/* 62 */         } else if (level == Logger.Level.WARN) {
/* 63 */           this.logger.warn(text, thrown);
/* 64 */         } else if (level == Logger.Level.ERROR || level == Logger.Level.FATAL) {
/* 65 */           this.logger.error(text, thrown);
/* 66 */         } else if (level == Logger.Level.DEBUG) {
/* 67 */           this.logger.debug(text, thrown);
/* 68 */         } else if (level == Logger.Level.TRACE) {
/* 69 */           this.logger.debug(text, thrown);
/*    */         } 
/* 71 */       } catch (Throwable throwable) {}
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doLogf(Logger.Level level, String loggerClassName, String format, Object[] parameters, Throwable thrown) {
/* 77 */     if (isEnabled(level))
/*    */       try {
/* 79 */         String text = (parameters == null) ? String.format(format, new Object[0]) : String.format(format, parameters);
/* 80 */         if (level == Logger.Level.INFO) {
/* 81 */           this.logger.info(text, thrown);
/* 82 */         } else if (level == Logger.Level.WARN) {
/* 83 */           this.logger.warn(text, thrown);
/* 84 */         } else if (level == Logger.Level.ERROR || level == Logger.Level.FATAL) {
/* 85 */           this.logger.error(text, thrown);
/* 86 */         } else if (level == Logger.Level.DEBUG) {
/* 87 */           this.logger.debug(text, thrown);
/* 88 */         } else if (level == Logger.Level.TRACE) {
/* 89 */           this.logger.debug(text, thrown);
/*    */         } 
/* 91 */       } catch (Throwable throwable) {} 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\Slf4jLogger.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */