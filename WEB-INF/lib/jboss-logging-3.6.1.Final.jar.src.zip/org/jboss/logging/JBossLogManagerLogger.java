/*    */ package org.jboss.logging;
/*    */ 
/*    */ import java.util.logging.Level;
/*    */ import org.jboss.logmanager.ExtLogRecord;
/*    */ import org.jboss.logmanager.Level;
/*    */ import org.jboss.logmanager.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JBossLogManagerLogger
/*    */   extends Logger
/*    */ {
/*    */   private static final long serialVersionUID = 7429618317727584742L;
/*    */   private final Logger logger;
/*    */   
/*    */   JBossLogManagerLogger(String name, Logger logger) {
/* 30 */     super(name);
/* 31 */     this.logger = logger;
/*    */   }
/*    */   
/*    */   public boolean isEnabled(Logger.Level level) {
/* 35 */     return this.logger.isLoggable(translate(level));
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doLog(Logger.Level level, String loggerClassName, Object message, Object[] parameters, Throwable thrown) {
/* 40 */     Level translatedLevel = translate(level);
/* 41 */     if (this.logger.isLoggable(translatedLevel)) {
/* 42 */       if (parameters == null) {
/* 43 */         this.logger.log(loggerClassName, translatedLevel, String.valueOf(message), thrown);
/*    */       } else {
/* 45 */         this.logger.log(loggerClassName, translatedLevel, String.valueOf(message), ExtLogRecord.FormatStyle.MESSAGE_FORMAT, parameters, thrown);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doLogf(Logger.Level level, String loggerClassName, String format, Object[] parameters, Throwable thrown) {
/* 53 */     if (parameters == null) {
/* 54 */       this.logger.log(loggerClassName, translate(level), format, thrown);
/*    */     } else {
/* 56 */       this.logger.log(loggerClassName, translate(level), format, ExtLogRecord.FormatStyle.PRINTF, parameters, thrown);
/*    */     } 
/*    */   }
/*    */   
/*    */   private static Level translate(Logger.Level level) {
/* 61 */     if (level == Logger.Level.TRACE)
/* 62 */       return (Level)Level.TRACE; 
/* 63 */     if (level == Logger.Level.DEBUG) {
/* 64 */       return (Level)Level.DEBUG;
/*    */     }
/* 66 */     return infoOrHigher(level);
/*    */   }
/*    */   
/*    */   private static Level infoOrHigher(Logger.Level level) {
/* 70 */     if (level == Logger.Level.INFO)
/* 71 */       return (Level)Level.INFO; 
/* 72 */     if (level == Logger.Level.WARN)
/* 73 */       return (Level)Level.WARN; 
/* 74 */     if (level == Logger.Level.ERROR)
/* 75 */       return (Level)Level.ERROR; 
/* 76 */     if (level == Logger.Level.FATAL) {
/* 77 */       return (Level)Level.FATAL;
/*    */     }
/* 79 */     return Level.ALL;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\JBossLogManagerLogger.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */