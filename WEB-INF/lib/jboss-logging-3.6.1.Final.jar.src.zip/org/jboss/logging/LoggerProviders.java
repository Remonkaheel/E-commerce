/*     */ package org.jboss.logging;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.ServiceConfigurationError;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.logging.LogManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LoggerProviders
/*     */ {
/*     */   static final String LOGGING_PROVIDER_KEY = "org.jboss.logging.provider";
/*  29 */   static final LoggerProvider PROVIDER = find();
/*     */   
/*     */   private static LoggerProvider find() {
/*  32 */     return findProvider();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static LoggerProvider findProvider() {
/*  39 */     ClassLoader cl = LoggerProviders.class.getClassLoader();
/*     */     
/*     */     try {
/*  42 */       String loggerProvider = SecurityActions.getSystemProperty("org.jboss.logging.provider");
/*  43 */       if (loggerProvider != null) {
/*  44 */         if ("jboss".equalsIgnoreCase(loggerProvider))
/*  45 */           return tryJBossLogManager(cl, "system property"); 
/*  46 */         if ("jdk".equalsIgnoreCase(loggerProvider))
/*  47 */           return tryJDK("system property"); 
/*  48 */         if ("log4j2".equalsIgnoreCase(loggerProvider))
/*  49 */           return tryLog4j2(cl, "system property"); 
/*  50 */         if ("log4j".equalsIgnoreCase(loggerProvider))
/*  51 */           return tryLog4j(cl, "system property"); 
/*  52 */         if ("slf4j".equalsIgnoreCase(loggerProvider)) {
/*  53 */           return trySlf4j("system property");
/*     */         }
/*     */       } 
/*  56 */     } catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  62 */       ServiceLoader<LoggerProvider> loader = ServiceLoader.load(LoggerProvider.class, cl);
/*  63 */       Iterator<LoggerProvider> iter = loader.iterator();
/*     */       while (true) {
/*     */         try {
/*  66 */           if (!iter.hasNext())
/*     */             break; 
/*  68 */           LoggerProvider provider = iter.next();
/*     */           
/*  70 */           logProvider(provider, "service loader");
/*  71 */           return provider;
/*  72 */         } catch (ServiceConfigurationError serviceConfigurationError) {}
/*     */       } 
/*  74 */     } catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  80 */       return tryJBossLogManager(cl, null);
/*  81 */     } catch (Throwable throwable) {
/*     */ 
/*     */       
/*     */       try {
/*  85 */         return tryLog4j2(cl, null);
/*  86 */       } catch (Throwable throwable1) {
/*     */ 
/*     */         
/*     */         try {
/*     */           
/*  91 */           Class.forName("ch.qos.logback.classic.Logger", false, cl);
/*  92 */           return trySlf4j(null);
/*  93 */         } catch (Throwable throwable2) {
/*     */ 
/*     */           
/*     */           try {
/*     */             
/*  98 */             return tryLog4j(cl, null);
/*  99 */           } catch (Throwable throwable3) {
/*     */ 
/*     */             
/* 102 */             return tryJDK(null);
/*     */           } 
/*     */         } 
/*     */       } 
/* 106 */     }  } private static JDKLoggerProvider tryJDK(String via) { JDKLoggerProvider provider = new JDKLoggerProvider();
/* 107 */     logProvider(provider, via);
/* 108 */     return provider; }
/*     */ 
/*     */   
/*     */   private static LoggerProvider trySlf4j(String via) {
/* 112 */     LoggerProvider provider = new Slf4jLoggerProvider();
/* 113 */     logProvider(provider, via);
/* 114 */     return provider;
/*     */   }
/*     */ 
/*     */   
/*     */   private static LoggerProvider tryLog4j2(ClassLoader cl, String via) throws ClassNotFoundException {
/* 119 */     Class.forName("org.apache.logging.log4j.Logger", true, cl);
/* 120 */     Class.forName("org.apache.logging.log4j.LogManager", true, cl);
/* 121 */     Class.forName("org.apache.logging.log4j.spi.AbstractLogger", true, cl);
/* 122 */     LoggerProvider provider = new Log4j2LoggerProvider();
/*     */     
/* 124 */     logProvider(provider, via);
/* 125 */     return provider;
/*     */   }
/*     */   
/*     */   private static LoggerProvider tryLog4j(ClassLoader cl, String via) throws ClassNotFoundException {
/* 129 */     Class.forName("org.apache.log4j.LogManager", true, cl);
/*     */ 
/*     */     
/* 132 */     Class.forName("org.apache.log4j.config.PropertySetter", true, cl);
/* 133 */     LoggerProvider provider = new Log4jLoggerProvider();
/* 134 */     logProvider(provider, via);
/* 135 */     return provider;
/*     */   }
/*     */   
/*     */   private static LoggerProvider tryJBossLogManager(ClassLoader cl, String via) throws ClassNotFoundException {
/* 139 */     Class<? extends LogManager> logManagerClass = (Class)LogManager.getLogManager().getClass();
/* 140 */     Class<?> jblLogManager = Class.forName("org.jboss.logmanager.LogManager", false, Logger.class
/* 141 */         .getClassLoader());
/* 142 */     if (logManagerClass == jblLogManager && 
/* 143 */       Class.forName("org.jboss.logmanager.Logger$AttachmentKey", true, cl).getClassLoader() == logManagerClass
/* 144 */       .getClassLoader()) {
/*     */ 
/*     */       
/* 147 */       Module module = LoggerProviders.class.getModule();
/* 148 */       if (module.isNamed()) {
/* 149 */         module.addReads(jblLogManager.getModule());
/*     */       }
/* 151 */       LoggerProvider provider = new JBossLogManagerProvider();
/* 152 */       logProvider(provider, via);
/* 153 */       return provider;
/*     */     } 
/* 155 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void logProvider(LoggerProvider provider, String via) {
/* 160 */     Logger logger = provider.getLogger("org.jboss.logging");
/* 161 */     if (via == null) {
/* 162 */       logger.debugf("Logging Provider: %s", provider.getClass().getName());
/*     */     } else {
/* 164 */       logger.debugf("Logging Provider: %s found via %s", provider.getClass().getName(), via);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\LoggerProviders.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */