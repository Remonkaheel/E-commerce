/*      */ package org.jboss.logging;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DelegatingBasicLogger
/*      */   implements BasicLogger, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = -5774903162389601853L;
/*   35 */   private static final String FQCN = DelegatingBasicLogger.class.getName();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Logger log;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DelegatingBasicLogger(Logger log) {
/*   48 */     this.log = log;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTraceEnabled() {
/*   53 */     return this.log.isTraceEnabled();
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Object message) {
/*   58 */     this.log.trace(FQCN, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Object message, Throwable t) {
/*   63 */     this.log.trace(FQCN, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String loggerFqcn, Object message, Throwable t) {
/*   68 */     this.log.trace(loggerFqcn, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String loggerFqcn, Object message, Object[] params, Throwable t) {
/*   73 */     this.log.trace(loggerFqcn, message, params, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracev(String format, Object... params) {
/*   78 */     this.log.logv(FQCN, Logger.Level.TRACE, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracev(String format, Object param1) {
/*   83 */     this.log.logv(FQCN, Logger.Level.TRACE, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracev(String format, Object param1, Object param2) {
/*   88 */     this.log.logv(FQCN, Logger.Level.TRACE, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracev(String format, Object param1, Object param2, Object param3) {
/*   93 */     this.log.logv(FQCN, Logger.Level.TRACE, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracev(Throwable t, String format, Object... params) {
/*   98 */     this.log.logv(FQCN, Logger.Level.TRACE, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracev(Throwable t, String format, Object param1) {
/*  103 */     this.log.logv(FQCN, Logger.Level.TRACE, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracev(Throwable t, String format, Object param1, Object param2) {
/*  108 */     this.log.logv(FQCN, Logger.Level.TRACE, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracev(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  113 */     this.log.logv(FQCN, Logger.Level.TRACE, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, Object... params) {
/*  118 */     this.log.logf(FQCN, Logger.Level.TRACE, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, Object param1) {
/*  123 */     this.log.logf(FQCN, Logger.Level.TRACE, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, Object param1, Object param2) {
/*  128 */     this.log.logf(FQCN, Logger.Level.TRACE, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, Object param1, Object param2, Object param3) {
/*  133 */     this.log.logf(FQCN, Logger.Level.TRACE, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, Object... params) {
/*  138 */     this.log.logf(FQCN, Logger.Level.TRACE, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, Object param1) {
/*  143 */     this.log.logf(FQCN, Logger.Level.TRACE, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, Object param1, Object param2) {
/*  148 */     this.log.logf(FQCN, Logger.Level.TRACE, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  153 */     this.log.logf(FQCN, Logger.Level.TRACE, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, int arg) {
/*  158 */     this.log.tracef(format, arg);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, int arg1, int arg2) {
/*  163 */     this.log.tracef(format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, int arg1, Object arg2) {
/*  168 */     this.log.tracef(format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, int arg1, int arg2, int arg3) {
/*  173 */     this.log.tracef(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, int arg1, int arg2, Object arg3) {
/*  178 */     this.log.tracef(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, int arg1, Object arg2, Object arg3) {
/*  183 */     this.log.tracef(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, int arg) {
/*  188 */     this.log.tracef(t, format, arg);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, int arg1, int arg2) {
/*  193 */     this.log.tracef(t, format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, int arg1, Object arg2) {
/*  198 */     this.log.tracef(t, format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, int arg1, int arg2, int arg3) {
/*  203 */     this.log.tracef(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, int arg1, int arg2, Object arg3) {
/*  208 */     this.log.tracef(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, int arg1, Object arg2, Object arg3) {
/*  213 */     this.log.tracef(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, long arg) {
/*  218 */     this.log.tracef(format, arg);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, long arg1, long arg2) {
/*  223 */     this.log.tracef(format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, long arg1, Object arg2) {
/*  228 */     this.log.tracef(format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, long arg1, long arg2, long arg3) {
/*  233 */     this.log.tracef(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, long arg1, long arg2, Object arg3) {
/*  238 */     this.log.tracef(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(String format, long arg1, Object arg2, Object arg3) {
/*  243 */     this.log.tracef(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, long arg) {
/*  248 */     this.log.tracef(t, format, arg);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, long arg1, long arg2) {
/*  253 */     this.log.tracef(t, format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, long arg1, Object arg2) {
/*  258 */     this.log.tracef(t, format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, long arg1, long arg2, long arg3) {
/*  263 */     this.log.tracef(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, long arg1, long arg2, Object arg3) {
/*  268 */     this.log.tracef(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tracef(Throwable t, String format, long arg1, Object arg2, Object arg3) {
/*  273 */     this.log.tracef(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDebugEnabled() {
/*  278 */     return this.log.isDebugEnabled();
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Object message) {
/*  283 */     this.log.debug(FQCN, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Object message, Throwable t) {
/*  288 */     this.log.debug(FQCN, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String loggerFqcn, Object message, Throwable t) {
/*  293 */     this.log.debug(loggerFqcn, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String loggerFqcn, Object message, Object[] params, Throwable t) {
/*  298 */     this.log.debug(loggerFqcn, message, params, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugv(String format, Object... params) {
/*  303 */     this.log.logv(FQCN, Logger.Level.DEBUG, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugv(String format, Object param1) {
/*  308 */     this.log.logv(FQCN, Logger.Level.DEBUG, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugv(String format, Object param1, Object param2) {
/*  313 */     this.log.logv(FQCN, Logger.Level.DEBUG, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugv(String format, Object param1, Object param2, Object param3) {
/*  318 */     this.log.logv(FQCN, Logger.Level.DEBUG, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugv(Throwable t, String format, Object... params) {
/*  323 */     this.log.logv(FQCN, Logger.Level.DEBUG, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugv(Throwable t, String format, Object param1) {
/*  328 */     this.log.logv(FQCN, Logger.Level.DEBUG, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugv(Throwable t, String format, Object param1, Object param2) {
/*  333 */     this.log.logv(FQCN, Logger.Level.DEBUG, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugv(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  338 */     this.log.logv(FQCN, Logger.Level.DEBUG, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, Object... params) {
/*  343 */     this.log.logf(FQCN, Logger.Level.DEBUG, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, Object param1) {
/*  348 */     this.log.logf(FQCN, Logger.Level.DEBUG, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, Object param1, Object param2) {
/*  353 */     this.log.logf(FQCN, Logger.Level.DEBUG, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, Object param1, Object param2, Object param3) {
/*  358 */     this.log.logf(FQCN, Logger.Level.DEBUG, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, Object... params) {
/*  363 */     this.log.logf(FQCN, Logger.Level.DEBUG, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, Object param1) {
/*  368 */     this.log.logf(FQCN, Logger.Level.DEBUG, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, Object param1, Object param2) {
/*  373 */     this.log.logf(FQCN, Logger.Level.DEBUG, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  378 */     this.log.logf(FQCN, Logger.Level.DEBUG, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, int arg) {
/*  383 */     this.log.debugf(format, arg);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, int arg1, int arg2) {
/*  388 */     this.log.debugf(format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, int arg1, Object arg2) {
/*  393 */     this.log.debugf(format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, int arg1, int arg2, int arg3) {
/*  398 */     this.log.debugf(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, int arg1, int arg2, Object arg3) {
/*  403 */     this.log.debugf(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, int arg1, Object arg2, Object arg3) {
/*  408 */     this.log.debugf(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, int arg) {
/*  413 */     this.log.debugf(t, format, arg);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, int arg1, int arg2) {
/*  418 */     this.log.debugf(t, format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, int arg1, Object arg2) {
/*  423 */     this.log.debugf(t, format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, int arg1, int arg2, int arg3) {
/*  428 */     this.log.debugf(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, int arg1, int arg2, Object arg3) {
/*  433 */     this.log.debugf(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, int arg1, Object arg2, Object arg3) {
/*  438 */     this.log.debugf(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, long arg) {
/*  443 */     this.log.debugf(format, arg);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, long arg1, long arg2) {
/*  448 */     this.log.debugf(format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, long arg1, Object arg2) {
/*  453 */     this.log.debugf(format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, long arg1, long arg2, long arg3) {
/*  458 */     this.log.debugf(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, long arg1, long arg2, Object arg3) {
/*  463 */     this.log.debugf(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(String format, long arg1, Object arg2, Object arg3) {
/*  468 */     this.log.debugf(format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, long arg) {
/*  473 */     this.log.debugf(t, format, arg);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, long arg1, long arg2) {
/*  478 */     this.log.debugf(t, format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, long arg1, Object arg2) {
/*  483 */     this.log.debugf(t, format, arg1, arg2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, long arg1, long arg2, long arg3) {
/*  488 */     this.log.debugf(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, long arg1, long arg2, Object arg3) {
/*  493 */     this.log.debugf(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debugf(Throwable t, String format, long arg1, Object arg2, Object arg3) {
/*  498 */     this.log.debugf(t, format, arg1, arg2, arg3);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInfoEnabled() {
/*  503 */     return this.log.isInfoEnabled();
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Object message) {
/*  508 */     this.log.info(FQCN, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Object message, Throwable t) {
/*  513 */     this.log.info(FQCN, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String loggerFqcn, Object message, Throwable t) {
/*  518 */     this.log.info(loggerFqcn, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String loggerFqcn, Object message, Object[] params, Throwable t) {
/*  523 */     this.log.info(loggerFqcn, message, params, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infov(String format, Object... params) {
/*  528 */     this.log.logv(FQCN, Logger.Level.INFO, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infov(String format, Object param1) {
/*  533 */     this.log.logv(FQCN, Logger.Level.INFO, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infov(String format, Object param1, Object param2) {
/*  538 */     this.log.logv(FQCN, Logger.Level.INFO, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infov(String format, Object param1, Object param2, Object param3) {
/*  543 */     this.log.logv(FQCN, Logger.Level.INFO, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infov(Throwable t, String format, Object... params) {
/*  548 */     this.log.logv(FQCN, Logger.Level.INFO, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infov(Throwable t, String format, Object param1) {
/*  553 */     this.log.logv(FQCN, Logger.Level.INFO, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infov(Throwable t, String format, Object param1, Object param2) {
/*  558 */     this.log.logv(FQCN, Logger.Level.INFO, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infov(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  563 */     this.log.logv(FQCN, Logger.Level.INFO, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infof(String format, Object... params) {
/*  568 */     this.log.logf(FQCN, Logger.Level.INFO, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infof(String format, Object param1) {
/*  573 */     this.log.logf(FQCN, Logger.Level.INFO, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infof(String format, Object param1, Object param2) {
/*  578 */     this.log.logf(FQCN, Logger.Level.INFO, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infof(String format, Object param1, Object param2, Object param3) {
/*  583 */     this.log.logf(FQCN, Logger.Level.INFO, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infof(Throwable t, String format, Object... params) {
/*  588 */     this.log.logf(FQCN, Logger.Level.INFO, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infof(Throwable t, String format, Object param1) {
/*  593 */     this.log.logf(FQCN, Logger.Level.INFO, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infof(Throwable t, String format, Object param1, Object param2) {
/*  598 */     this.log.logf(FQCN, Logger.Level.INFO, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void infof(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  603 */     this.log.logf(FQCN, Logger.Level.INFO, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Object message) {
/*  608 */     this.log.warn(FQCN, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Object message, Throwable t) {
/*  613 */     this.log.warn(FQCN, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String loggerFqcn, Object message, Throwable t) {
/*  618 */     this.log.warn(loggerFqcn, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String loggerFqcn, Object message, Object[] params, Throwable t) {
/*  623 */     this.log.warn(loggerFqcn, message, params, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnv(String format, Object... params) {
/*  628 */     this.log.logv(FQCN, Logger.Level.WARN, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnv(String format, Object param1) {
/*  633 */     this.log.logv(FQCN, Logger.Level.WARN, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnv(String format, Object param1, Object param2) {
/*  638 */     this.log.logv(FQCN, Logger.Level.WARN, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnv(String format, Object param1, Object param2, Object param3) {
/*  643 */     this.log.logv(FQCN, Logger.Level.WARN, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnv(Throwable t, String format, Object... params) {
/*  648 */     this.log.logv(FQCN, Logger.Level.WARN, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnv(Throwable t, String format, Object param1) {
/*  653 */     this.log.logv(FQCN, Logger.Level.WARN, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnv(Throwable t, String format, Object param1, Object param2) {
/*  658 */     this.log.logv(FQCN, Logger.Level.WARN, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnv(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  663 */     this.log.logv(FQCN, Logger.Level.WARN, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnf(String format, Object... params) {
/*  668 */     this.log.logf(FQCN, Logger.Level.WARN, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnf(String format, Object param1) {
/*  673 */     this.log.logf(FQCN, Logger.Level.WARN, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnf(String format, Object param1, Object param2) {
/*  678 */     this.log.logf(FQCN, Logger.Level.WARN, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnf(String format, Object param1, Object param2, Object param3) {
/*  683 */     this.log.logf(FQCN, Logger.Level.WARN, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnf(Throwable t, String format, Object... params) {
/*  688 */     this.log.logf(FQCN, Logger.Level.WARN, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnf(Throwable t, String format, Object param1) {
/*  693 */     this.log.logf(FQCN, Logger.Level.WARN, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnf(Throwable t, String format, Object param1, Object param2) {
/*  698 */     this.log.logf(FQCN, Logger.Level.WARN, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warnf(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  703 */     this.log.logf(FQCN, Logger.Level.WARN, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Object message) {
/*  708 */     this.log.error(FQCN, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Object message, Throwable t) {
/*  713 */     this.log.error(FQCN, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String loggerFqcn, Object message, Throwable t) {
/*  718 */     this.log.error(loggerFqcn, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String loggerFqcn, Object message, Object[] params, Throwable t) {
/*  723 */     this.log.error(loggerFqcn, message, params, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorv(String format, Object... params) {
/*  728 */     this.log.logv(FQCN, Logger.Level.ERROR, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorv(String format, Object param1) {
/*  733 */     this.log.logv(FQCN, Logger.Level.ERROR, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorv(String format, Object param1, Object param2) {
/*  738 */     this.log.logv(FQCN, Logger.Level.ERROR, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorv(String format, Object param1, Object param2, Object param3) {
/*  743 */     this.log.logv(FQCN, Logger.Level.ERROR, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorv(Throwable t, String format, Object... params) {
/*  748 */     this.log.logv(FQCN, Logger.Level.ERROR, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorv(Throwable t, String format, Object param1) {
/*  753 */     this.log.logv(FQCN, Logger.Level.ERROR, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorv(Throwable t, String format, Object param1, Object param2) {
/*  758 */     this.log.logv(FQCN, Logger.Level.ERROR, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorv(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  763 */     this.log.logv(FQCN, Logger.Level.ERROR, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorf(String format, Object... params) {
/*  768 */     this.log.logf(FQCN, Logger.Level.ERROR, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorf(String format, Object param1) {
/*  773 */     this.log.logf(FQCN, Logger.Level.ERROR, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorf(String format, Object param1, Object param2) {
/*  778 */     this.log.logf(FQCN, Logger.Level.ERROR, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorf(String format, Object param1, Object param2, Object param3) {
/*  783 */     this.log.logf(FQCN, Logger.Level.ERROR, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorf(Throwable t, String format, Object... params) {
/*  788 */     this.log.logf(FQCN, Logger.Level.ERROR, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorf(Throwable t, String format, Object param1) {
/*  793 */     this.log.logf(FQCN, Logger.Level.ERROR, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorf(Throwable t, String format, Object param1, Object param2) {
/*  798 */     this.log.logf(FQCN, Logger.Level.ERROR, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void errorf(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  803 */     this.log.logf(FQCN, Logger.Level.ERROR, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Object message) {
/*  808 */     this.log.fatal(FQCN, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Object message, Throwable t) {
/*  813 */     this.log.fatal(FQCN, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String loggerFqcn, Object message, Throwable t) {
/*  818 */     this.log.fatal(loggerFqcn, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String loggerFqcn, Object message, Object[] params, Throwable t) {
/*  823 */     this.log.fatal(loggerFqcn, message, params, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalv(String format, Object... params) {
/*  828 */     this.log.logv(FQCN, Logger.Level.FATAL, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalv(String format, Object param1) {
/*  833 */     this.log.logv(FQCN, Logger.Level.FATAL, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalv(String format, Object param1, Object param2) {
/*  838 */     this.log.logv(FQCN, Logger.Level.FATAL, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalv(String format, Object param1, Object param2, Object param3) {
/*  843 */     this.log.logv(FQCN, Logger.Level.FATAL, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalv(Throwable t, String format, Object... params) {
/*  848 */     this.log.logv(FQCN, Logger.Level.FATAL, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalv(Throwable t, String format, Object param1) {
/*  853 */     this.log.logv(FQCN, Logger.Level.FATAL, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalv(Throwable t, String format, Object param1, Object param2) {
/*  858 */     this.log.logv(FQCN, Logger.Level.FATAL, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalv(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  863 */     this.log.logv(FQCN, Logger.Level.FATAL, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalf(String format, Object... params) {
/*  868 */     this.log.logf(FQCN, Logger.Level.FATAL, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalf(String format, Object param1) {
/*  873 */     this.log.logf(FQCN, Logger.Level.FATAL, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalf(String format, Object param1, Object param2) {
/*  878 */     this.log.logf(FQCN, Logger.Level.FATAL, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalf(String format, Object param1, Object param2, Object param3) {
/*  883 */     this.log.logf(FQCN, Logger.Level.FATAL, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalf(Throwable t, String format, Object... params) {
/*  888 */     this.log.logf(FQCN, Logger.Level.FATAL, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalf(Throwable t, String format, Object param1) {
/*  893 */     this.log.logf(FQCN, Logger.Level.FATAL, t, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalf(Throwable t, String format, Object param1, Object param2) {
/*  898 */     this.log.logf(FQCN, Logger.Level.FATAL, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatalf(Throwable t, String format, Object param1, Object param2, Object param3) {
/*  903 */     this.log.logf(FQCN, Logger.Level.FATAL, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Logger.Level level, Object message) {
/*  908 */     this.log.log(FQCN, level, message, (Object[])null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Logger.Level level, Object message, Throwable t) {
/*  913 */     this.log.log(FQCN, level, message, (Object[])null, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Logger.Level level, String loggerFqcn, Object message, Throwable t) {
/*  918 */     this.log.log(level, loggerFqcn, message, t);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(String loggerFqcn, Logger.Level level, Object message, Object[] params, Throwable t) {
/*  924 */     this.log.log(loggerFqcn, level, message, params, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void logv(Logger.Level level, String format, Object... params) {
/*  929 */     this.log.logv(FQCN, level, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void logv(Logger.Level level, String format, Object param1) {
/*  934 */     this.log.logv(FQCN, level, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void logv(Logger.Level level, String format, Object param1, Object param2) {
/*  939 */     this.log.logv(FQCN, level, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logv(Logger.Level level, String format, Object param1, Object param2, Object param3) {
/*  945 */     this.log.logv(FQCN, level, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void logv(Logger.Level level, Throwable t, String format, Object... params) {
/*  950 */     this.log.logv(FQCN, level, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void logv(Logger.Level level, Throwable t, String format, Object param1) {
/*  955 */     this.log.logv(FQCN, level, t, format, param1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logv(Logger.Level level, Throwable t, String format, Object param1, Object param2) {
/*  961 */     this.log.logv(FQCN, level, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logv(Logger.Level level, Throwable t, String format, Object param1, Object param2, Object param3) {
/*  967 */     this.log.logv(FQCN, level, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logv(String loggerFqcn, Logger.Level level, Throwable t, String format, Object... params) {
/*  973 */     this.log.logv(loggerFqcn, level, t, format, params);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logv(String loggerFqcn, Logger.Level level, Throwable t, String format, Object param1) {
/*  979 */     this.log.logv(loggerFqcn, level, t, format, param1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logv(String loggerFqcn, Logger.Level level, Throwable t, String format, Object param1, Object param2) {
/*  985 */     this.log.logv(loggerFqcn, level, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logv(String loggerFqcn, Logger.Level level, Throwable t, String format, Object param1, Object param2, Object param3) {
/*  991 */     this.log.logv(loggerFqcn, level, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void logf(Logger.Level level, String format, Object... params) {
/*  996 */     this.log.logf(FQCN, level, (Throwable)null, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void logf(Logger.Level level, String format, Object param1) {
/* 1001 */     this.log.logf(FQCN, level, (Throwable)null, format, param1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void logf(Logger.Level level, String format, Object param1, Object param2) {
/* 1006 */     this.log.logf(FQCN, level, (Throwable)null, format, param1, param2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logf(Logger.Level level, String format, Object param1, Object param2, Object param3) {
/* 1012 */     this.log.logf(FQCN, level, (Throwable)null, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void logf(Logger.Level level, Throwable t, String format, Object... params) {
/* 1017 */     this.log.logf(FQCN, level, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void logf(Logger.Level level, Throwable t, String format, Object param1) {
/* 1022 */     this.log.logf(FQCN, level, t, format, param1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logf(Logger.Level level, Throwable t, String format, Object param1, Object param2) {
/* 1028 */     this.log.logf(FQCN, level, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logf(Logger.Level level, Throwable t, String format, Object param1, Object param2, Object param3) {
/* 1034 */     this.log.logf(FQCN, level, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logf(String loggerFqcn, Logger.Level level, Throwable t, String format, Object param1) {
/* 1040 */     this.log.logf(loggerFqcn, level, t, format, param1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logf(String loggerFqcn, Logger.Level level, Throwable t, String format, Object param1, Object param2) {
/* 1046 */     this.log.logf(loggerFqcn, level, t, format, param1, param2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logf(String loggerFqcn, Logger.Level level, Throwable t, String format, Object param1, Object param2, Object param3) {
/* 1052 */     this.log.logf(loggerFqcn, level, t, format, param1, param2, param3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logf(String loggerFqcn, Logger.Level level, Throwable t, String format, Object... params) {
/* 1058 */     this.log.logf(loggerFqcn, level, t, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEnabled(Logger.Level level) {
/* 1063 */     return this.log.isEnabled(level);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\DelegatingBasicLogger.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */