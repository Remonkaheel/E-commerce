/*     */ package org.jboss.logging;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.MDC;
/*     */ import org.apache.log4j.NDC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Log4jLoggerProvider
/*     */   implements LoggerProvider
/*     */ {
/*     */   public Logger getLogger(String name) {
/*  37 */     return new Log4jLogger("".equals(name) ? "ROOT" : name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearMdc() {
/*  42 */     MDC.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getMdc(String key) {
/*  47 */     return MDC.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getMdcMap() {
/*  53 */     Map<String, Object> map = MDC.getContext();
/*  54 */     return (map == null) ? Collections.<String, Object>emptyMap() : map;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object putMdc(String key, Object val) {
/*     */     try {
/*  60 */       return MDC.get(key);
/*     */     } finally {
/*  62 */       MDC.put(key, val);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeMdc(String key) {
/*  68 */     MDC.remove(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearNdc() {
/*  73 */     NDC.remove();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNdc() {
/*  78 */     return NDC.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNdcDepth() {
/*  83 */     return NDC.getDepth();
/*     */   }
/*     */ 
/*     */   
/*     */   public String peekNdc() {
/*  88 */     return NDC.peek();
/*     */   }
/*     */ 
/*     */   
/*     */   public String popNdc() {
/*  93 */     return NDC.pop();
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushNdc(String message) {
/*  98 */     NDC.push(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNdcMaxDepth(int maxDepth) {
/* 103 */     NDC.setMaxDepth(maxDepth);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\Log4jLoggerProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */