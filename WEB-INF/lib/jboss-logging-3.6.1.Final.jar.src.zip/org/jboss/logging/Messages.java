/*     */ package org.jboss.logging;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Messages
/*     */ {
/*     */   @Deprecated(forRemoval = true, since = "3.6")
/*     */   public static <T> T getBundle(Class<T> type) {
/*  50 */     return getBundle(type, LoggingLocale.getLocale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "3.6")
/*     */   public static <T> T getBundle(final Class<T> type, final Locale locale) {
/*  64 */     if (System.getSecurityManager() == null) {
/*     */       try {
/*  66 */         MethodHandles.Lookup lookup = MethodHandles.privateLookupIn(type, MethodHandles.lookup());
/*  67 */         return doGetBundle(lookup, type, locale);
/*  68 */       } catch (IllegalAccessException e) {
/*  69 */         throw new IllegalArgumentException("This library does not have private access to " + String.valueOf(type));
/*     */       } 
/*     */     }
/*  72 */     return AccessController.doPrivileged(new PrivilegedAction<T>() {
/*     */           public T run() {
/*     */             try {
/*  75 */               MethodHandles.Lookup lookup = MethodHandles.privateLookupIn(type, MethodHandles.lookup());
/*  76 */               return Messages.doGetBundle(lookup, type, locale);
/*  77 */             } catch (IllegalAccessException e) {
/*  78 */               throw new IllegalArgumentException("This library does not have private access to " + String.valueOf(type));
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getBundle(MethodHandles.Lookup lookup, Class<T> type) {
/*  95 */     return getBundle(lookup, type, LoggingLocale.getLocale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getBundle(MethodHandles.Lookup lookup, Class<T> type, Locale locale) {
/* 108 */     if (System.getSecurityManager() == null) {
/* 109 */       return doGetBundle(lookup, type, locale);
/*     */     }
/* 111 */     return AccessController.doPrivileged(() -> doGetBundle(lookup, type, locale));
/*     */   }
/*     */   private static <T> T doGetBundle(MethodHandles.Lookup lookup, Class<T> type, Locale locale) {
/*     */     MethodHandle getter;
/* 115 */     String language = locale.getLanguage();
/* 116 */     String country = locale.getCountry();
/* 117 */     String variant = locale.getVariant();
/*     */     
/* 119 */     Class<? extends T> bundleClass = null;
/* 120 */     if (variant != null && !variant.isEmpty()) {
/*     */       try {
/* 122 */         bundleClass = lookup.findClass(join(type.getName(), "$bundle", language, country, variant)).asSubclass(type);
/* 123 */       } catch (ClassNotFoundException classNotFoundException) {
/*     */       
/* 125 */       } catch (IllegalAccessException e) {
/* 126 */         throw new IllegalArgumentException("The given lookup does not have access to the implementation class");
/*     */       } 
/*     */     }
/* 129 */     if (bundleClass == null && country != null && !country.isEmpty()) {
/*     */       try {
/* 131 */         bundleClass = lookup.findClass(join(type.getName(), "$bundle", language, country, null)).asSubclass(type);
/* 132 */       } catch (ClassNotFoundException classNotFoundException) {
/*     */       
/* 134 */       } catch (IllegalAccessException e) {
/* 135 */         throw new IllegalArgumentException("The given lookup does not have access to the implementation class");
/*     */       } 
/*     */     }
/* 138 */     if (bundleClass == null && language != null && !language.isEmpty()) {
/*     */       try {
/* 140 */         bundleClass = lookup.findClass(join(type.getName(), "$bundle", language, null, null)).asSubclass(type);
/* 141 */       } catch (ClassNotFoundException classNotFoundException) {
/*     */       
/* 143 */       } catch (IllegalAccessException e) {
/* 144 */         throw new IllegalArgumentException("The given lookup does not have access to the implementation class");
/*     */       } 
/*     */     }
/* 147 */     if (bundleClass == null) {
/*     */       try {
/* 149 */         bundleClass = lookup.findClass(join(type.getName(), "$bundle", null, null, null)).asSubclass(type);
/* 150 */       } catch (ClassNotFoundException e) {
/* 151 */         throw new IllegalArgumentException("Invalid bundle " + String.valueOf(type) + " (implementation not found)");
/* 152 */       } catch (IllegalAccessException e) {
/* 153 */         throw new IllegalArgumentException("The given lookup does not have access to the implementation class");
/*     */       } 
/*     */     }
/*     */     
/*     */     try {
/* 158 */       getter = lookup.findStaticGetter(bundleClass, "INSTANCE", bundleClass);
/* 159 */     } catch (NoSuchFieldException e) {
/* 160 */       throw new IllegalArgumentException("Bundle implementation " + String.valueOf(bundleClass) + " has no instance field");
/* 161 */     } catch (IllegalAccessException e) {
/* 162 */       throw new IllegalArgumentException("The given lookup does not have access to the implementation class instance field");
/*     */     } 
/*     */     
/*     */     try {
/* 166 */       return type.cast(getter.invoke());
/* 167 */     } catch (Throwable e) {
/* 168 */       throw new IllegalArgumentException("Bundle implementation " + String.valueOf(bundleClass) + " could not be instantiated", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String join(String interfaceName, String a, String b, String c, String d) {
/* 173 */     StringBuilder build = new StringBuilder();
/* 174 */     build.append(interfaceName).append('_').append(a);
/* 175 */     if (b != null && b.length() > 0) {
/* 176 */       build.append('_');
/* 177 */       build.append(b);
/*     */     } 
/* 179 */     if (c != null && c.length() > 0) {
/* 180 */       build.append('_');
/* 181 */       build.append(c);
/*     */     } 
/* 183 */     if (d != null && d.length() > 0) {
/* 184 */       build.append('_');
/* 185 */       build.append(d);
/*     */     } 
/* 187 */     return build.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jboss-logging-3.6.1.Final.jar!\org\jboss\logging\Messages.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */