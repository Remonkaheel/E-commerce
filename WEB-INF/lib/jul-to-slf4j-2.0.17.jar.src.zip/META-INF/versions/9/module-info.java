module jul.to.slf4j {
  requires java.base;
  requires org.slf4j;
  requires java.logging;
  
  exports org.slf4j.bridge;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jul-to-slf4j-2.0.17.jar!\META-INF\versions\9\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */