/*     */ package org.slf4j.bridge;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.logging.Handler;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogManager;
/*     */ import java.util.logging.LogRecord;
/*     */ import java.util.logging.Logger;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.slf4j.spi.LocationAwareLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SLF4JBridgeHandler
/*     */   extends Handler
/*     */ {
/* 111 */   private static final String FQCN = Logger.class.getName();
/*     */   
/*     */   private static final String UNKNOWN_LOGGER_NAME = "unknown.jul.logger";
/* 114 */   private static final int TRACE_LEVEL_THRESHOLD = Level.FINEST.intValue();
/* 115 */   private static final int DEBUG_LEVEL_THRESHOLD = Level.FINE.intValue();
/* 116 */   private static final int INFO_LEVEL_THRESHOLD = Level.INFO.intValue();
/* 117 */   private static final int WARN_LEVEL_THRESHOLD = Level.WARNING.intValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void install() {
/* 128 */     LogManager.getLogManager().getLogger("").addHandler(new SLF4JBridgeHandler());
/*     */   }
/*     */   
/*     */   private static Logger getRootLogger() {
/* 132 */     return LogManager.getLogManager().getLogger("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void uninstall() throws SecurityException {
/* 144 */     Logger rootLogger = getRootLogger();
/* 145 */     Handler[] handlers = rootLogger.getHandlers();
/* 146 */     for (Handler handler : handlers) {
/* 147 */       if (handler instanceof SLF4JBridgeHandler) {
/* 148 */         rootLogger.removeHandler(handler);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInstalled() {
/* 160 */     Logger rootLogger = getRootLogger();
/* 161 */     Handler[] handlers = rootLogger.getHandlers();
/* 162 */     for (Handler handler : handlers) {
/* 163 */       if (handler instanceof SLF4JBridgeHandler) {
/* 164 */         return true;
/*     */       }
/*     */     } 
/* 167 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeHandlersForRootLogger() {
/* 175 */     Logger rootLogger = getRootLogger();
/* 176 */     Handler[] handlers = rootLogger.getHandlers();
/* 177 */     for (Handler handler : handlers) {
/* 178 */       rootLogger.removeHandler(handler);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Logger getSLF4JLogger(LogRecord record) {
/* 209 */     String name = record.getLoggerName();
/* 210 */     if (name == null) {
/* 211 */       name = "unknown.jul.logger";
/*     */     }
/* 213 */     return LoggerFactory.getLogger(name);
/*     */   }
/*     */   
/*     */   protected void callLocationAwareLogger(LocationAwareLogger lal, LogRecord record) {
/* 217 */     int slf4jLevel, julLevelValue = record.getLevel().intValue();
/*     */ 
/*     */     
/* 220 */     if (julLevelValue <= TRACE_LEVEL_THRESHOLD) {
/* 221 */       slf4jLevel = 0;
/* 222 */     } else if (julLevelValue <= DEBUG_LEVEL_THRESHOLD) {
/* 223 */       slf4jLevel = 10;
/* 224 */     } else if (julLevelValue <= INFO_LEVEL_THRESHOLD) {
/* 225 */       slf4jLevel = 20;
/* 226 */     } else if (julLevelValue <= WARN_LEVEL_THRESHOLD) {
/* 227 */       slf4jLevel = 30;
/*     */     } else {
/* 229 */       slf4jLevel = 40;
/*     */     } 
/* 231 */     String i18nMessage = getMessageI18N(record);
/* 232 */     lal.log(null, FQCN, slf4jLevel, i18nMessage, null, record.getThrown());
/*     */   }
/*     */   
/*     */   protected void callPlainSLF4JLogger(Logger slf4jLogger, LogRecord record) {
/* 236 */     String i18nMessage = getMessageI18N(record);
/* 237 */     int julLevelValue = record.getLevel().intValue();
/* 238 */     if (julLevelValue <= TRACE_LEVEL_THRESHOLD) {
/* 239 */       slf4jLogger.trace(i18nMessage, record.getThrown());
/* 240 */     } else if (julLevelValue <= DEBUG_LEVEL_THRESHOLD) {
/* 241 */       slf4jLogger.debug(i18nMessage, record.getThrown());
/* 242 */     } else if (julLevelValue <= INFO_LEVEL_THRESHOLD) {
/* 243 */       slf4jLogger.info(i18nMessage, record.getThrown());
/* 244 */     } else if (julLevelValue <= WARN_LEVEL_THRESHOLD) {
/* 245 */       slf4jLogger.warn(i18nMessage, record.getThrown());
/*     */     } else {
/* 247 */       slf4jLogger.error(i18nMessage, record.getThrown());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getMessageI18N(LogRecord record) {
/* 258 */     String message = record.getMessage();
/*     */     
/* 260 */     if (message == null) {
/* 261 */       return null;
/*     */     }
/*     */     
/* 264 */     ResourceBundle bundle = record.getResourceBundle();
/* 265 */     if (bundle != null) {
/*     */       try {
/* 267 */         message = bundle.getString(message);
/* 268 */       } catch (MissingResourceException missingResourceException) {}
/*     */     }
/*     */     
/* 271 */     Object[] params = record.getParameters();
/*     */ 
/*     */     
/* 274 */     if (params != null && params.length > 0) {
/*     */       try {
/* 276 */         message = MessageFormat.format(message, params);
/* 277 */       } catch (IllegalArgumentException e) {
/*     */ 
/*     */         
/* 280 */         return message;
/*     */       } 
/*     */     }
/* 283 */     return message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void publish(LogRecord record) {
/* 300 */     if (record == null) {
/*     */       return;
/*     */     }
/*     */     
/* 304 */     Logger slf4jLogger = getSLF4JLogger(record);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     if (record.getMessage() == null) {
/* 310 */       record.setMessage("");
/*     */     }
/* 312 */     if (slf4jLogger instanceof LocationAwareLogger) {
/* 313 */       callLocationAwareLogger((LocationAwareLogger)slf4jLogger, record);
/*     */     } else {
/* 315 */       callPlainSLF4JLogger(slf4jLogger, record);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jul-to-slf4j-2.0.17.jar!\org\slf4j\bridge\SLF4JBridgeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */