module jakarta.persistence {
  requires java.base;
  requires java.logging;
  requires transitive java.sql;
  
  exports jakarta.persistence;
  exports jakarta.persistence.criteria;
  exports jakarta.persistence.metamodel;
  exports jakarta.persistence.spi;
  
  uses jakarta.persistence.spi.PersistenceProvider;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\module-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */