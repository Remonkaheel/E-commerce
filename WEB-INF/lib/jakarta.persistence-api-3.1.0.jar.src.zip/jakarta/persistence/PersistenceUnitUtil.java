package jakarta.persistence;

public interface PersistenceUnitUtil extends PersistenceUtil {
  boolean isLoaded(Object paramObject, String paramString);
  
  boolean isLoaded(Object paramObject);
  
  Object getIdentifier(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\PersistenceUnitUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */