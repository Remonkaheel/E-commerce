package jakarta.persistence;

import java.util.Map;

public interface AttributeNode<T> {
  String getAttributeName();
  
  Map<Class, Subgraph> getSubgraphs();
  
  Map<Class, Subgraph> getKeySubgraphs();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\AttributeNode.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */