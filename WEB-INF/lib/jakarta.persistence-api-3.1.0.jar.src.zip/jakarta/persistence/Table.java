package jakarta.persistence;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface Table {
  String name() default "";
  
  String catalog() default "";
  
  String schema() default "";
  
  UniqueConstraint[] uniqueConstraints() default {};
  
  Index[] indexes() default {};
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\Table.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */