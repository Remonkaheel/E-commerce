package jakarta.persistence;

public interface EntityTransaction {
  void begin();
  
  void commit();
  
  void rollback();
  
  void setRollbackOnly();
  
  boolean getRollbackOnly();
  
  boolean isActive();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\EntityTransaction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */