package jakarta.persistence;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Repeatable(NamedEntityGraphs.class)
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface NamedEntityGraph {
  String name() default "";
  
  NamedAttributeNode[] attributeNodes() default {};
  
  boolean includeAllAttributes() default false;
  
  NamedSubgraph[] subgraphs() default {};
  
  NamedSubgraph[] subclassSubgraphs() default {};
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\NamedEntityGraph.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */