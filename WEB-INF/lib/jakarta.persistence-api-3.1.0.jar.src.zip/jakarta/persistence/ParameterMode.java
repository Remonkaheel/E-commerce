/*    */ package jakarta.persistence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ParameterMode
/*    */ {
/* 31 */   IN,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   INOUT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   OUT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   REF_CURSOR;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\ParameterMode.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */