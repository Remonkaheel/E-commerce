package jakarta.persistence;

public interface PersistenceUtil {
  boolean isLoaded(Object paramObject, String paramString);
  
  boolean isLoaded(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\PersistenceUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */