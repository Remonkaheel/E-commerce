package jakarta.persistence;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.metamodel.Metamodel;
import java.util.Map;

public interface EntityManagerFactory extends AutoCloseable {
  EntityManager createEntityManager();
  
  EntityManager createEntityManager(Map paramMap);
  
  EntityManager createEntityManager(SynchronizationType paramSynchronizationType);
  
  EntityManager createEntityManager(SynchronizationType paramSynchronizationType, Map paramMap);
  
  CriteriaBuilder getCriteriaBuilder();
  
  Metamodel getMetamodel();
  
  boolean isOpen();
  
  void close();
  
  Map<String, Object> getProperties();
  
  Cache getCache();
  
  PersistenceUnitUtil getPersistenceUnitUtil();
  
  void addNamedQuery(String paramString, Query paramQuery);
  
  <T> T unwrap(Class<T> paramClass);
  
  <T> void addNamedEntityGraph(String paramString, EntityGraph<T> paramEntityGraph);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\EntityManagerFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */