/*    */ package jakarta.persistence.spi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum LoadState
/*    */ {
/* 26 */   LOADED,
/*    */   
/* 28 */   NOT_LOADED,
/*    */   
/* 30 */   UNKNOWN;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\spi\LoadState.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */