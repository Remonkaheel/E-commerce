package jakarta.persistence.spi;

import java.security.ProtectionDomain;

public interface ClassTransformer {
  byte[] transform(ClassLoader paramClassLoader, String paramString, Class<?> paramClass, ProtectionDomain paramProtectionDomain, byte[] paramArrayOfbyte) throws TransformerException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\spi\ClassTransformer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */