package jakarta.persistence.spi;

import java.util.List;

public interface PersistenceProviderResolver {
  List<PersistenceProvider> getPersistenceProviders();
  
  void clearCachedProviders();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\spi\PersistenceProviderResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */