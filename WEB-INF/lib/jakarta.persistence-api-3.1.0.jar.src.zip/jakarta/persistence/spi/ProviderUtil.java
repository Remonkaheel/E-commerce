package jakarta.persistence.spi;

public interface ProviderUtil {
  LoadState isLoadedWithoutReference(Object paramObject, String paramString);
  
  LoadState isLoadedWithReference(Object paramObject, String paramString);
  
  LoadState isLoaded(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\spi\ProviderUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */