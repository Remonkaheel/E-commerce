/*     */ package jakarta.persistence.spi;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ServiceConfigurationError;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistenceProviderResolverHolder
/*     */ {
/*  47 */   private static PersistenceProviderResolver singleton = new DefaultPersistenceProviderResolver();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PersistenceProviderResolver getPersistenceProviderResolver() {
/*  55 */     return singleton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setPersistenceProviderResolver(PersistenceProviderResolver resolver) {
/*  64 */     if (resolver == null) {
/*  65 */       singleton = new DefaultPersistenceProviderResolver();
/*     */     } else {
/*  67 */       singleton = resolver;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DefaultPersistenceProviderResolver
/*     */     implements PersistenceProviderResolver
/*     */   {
/*  84 */     private volatile HashMap<CacheKey, PersistenceProviderReference> providers = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     private static final ReferenceQueue referenceQueue = new ReferenceQueue();
/*     */     
/*     */     private static final String LOGGER_SUBSYSTEM = "jakarta.persistence.spi";
/*     */     
/*     */     private Logger logger;
/*     */     
/*     */     public List<PersistenceProvider> getPersistenceProviders() {
/*  96 */       processQueue();
/*     */       
/*  98 */       ClassLoader loader = getContextClassLoader();
/*  99 */       CacheKey cacheKey = new CacheKey(loader);
/* 100 */       PersistenceProviderReference providersReferent = this.providers.get(cacheKey);
/* 101 */       List<PersistenceProvider> loadedProviders = null;
/*     */       
/* 103 */       if (providersReferent != null) {
/* 104 */         loadedProviders = providersReferent.get();
/*     */       }
/*     */       
/* 107 */       if (loadedProviders == null) {
/* 108 */         loadedProviders = new ArrayList<>();
/* 109 */         Iterator<PersistenceProvider> ipp = ServiceLoader.<PersistenceProvider>load(PersistenceProvider.class, loader).iterator();
/*     */         try {
/* 111 */           while (ipp.hasNext()) {
/*     */             try {
/* 113 */               PersistenceProvider pp = ipp.next();
/* 114 */               loadedProviders.add(pp);
/* 115 */             } catch (ServiceConfigurationError sce) {
/* 116 */               log(Level.FINEST, sce.toString());
/*     */             } 
/*     */           } 
/* 119 */         } catch (ServiceConfigurationError sce) {
/* 120 */           log(Level.FINEST, sce.toString());
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 125 */         if (loadedProviders.isEmpty()) {
/* 126 */           log(Level.WARNING, "No valid providers found.");
/*     */         }
/*     */         
/* 129 */         providersReferent = new PersistenceProviderReference(loadedProviders, referenceQueue, cacheKey);
/*     */         
/* 131 */         this.providers.put(cacheKey, providersReferent);
/*     */       } 
/*     */       
/* 134 */       return loadedProviders;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void processQueue() {
/*     */       CacheKeyReference ref;
/* 142 */       while ((ref = (CacheKeyReference)referenceQueue.poll()) != null) {
/* 143 */         this.providers.remove(ref.getCacheKey());
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static ClassLoader getContextClassLoader() {
/* 151 */       if (System.getSecurityManager() == null) {
/* 152 */         return Thread.currentThread().getContextClassLoader();
/*     */       }
/* 154 */       return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>() {
/*     */             public ClassLoader run() {
/* 156 */               return Thread.currentThread().getContextClassLoader();
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void log(Level level, String message) {
/* 167 */       if (this.logger == null) {
/* 168 */         this.logger = Logger.getLogger("jakarta.persistence.spi");
/*     */       }
/* 170 */       this.logger.log(level, "jakarta.persistence.spi::" + message);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clearCachedProviders() {
/* 177 */       this.providers.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static interface CacheKeyReference
/*     */     {
/*     */       PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey getCacheKey();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private class CacheKey
/*     */       implements Cloneable
/*     */     {
/*     */       private PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.LoaderReference loaderRef;
/*     */ 
/*     */ 
/*     */       
/*     */       private int hashCodeCache;
/*     */ 
/*     */ 
/*     */       
/*     */       CacheKey(ClassLoader loader) {
/* 203 */         if (loader == null) {
/* 204 */           this.loaderRef = null;
/*     */         } else {
/* 206 */           this.loaderRef = new PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.LoaderReference(loader, PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.referenceQueue, this);
/*     */         } 
/* 208 */         calculateHashCode();
/*     */       }
/*     */       
/*     */       ClassLoader getLoader() {
/* 212 */         return (this.loaderRef != null) ? this.loaderRef.get() : null;
/*     */       }
/*     */       
/*     */       public boolean equals(Object other) {
/* 216 */         if (this == other) {
/* 217 */           return true;
/*     */         }
/*     */         
/* 220 */         try { CacheKey otherEntry = (CacheKey)other;
/*     */           
/* 222 */           if (this.hashCodeCache != otherEntry.hashCodeCache) {
/* 223 */             return false;
/*     */           }
/*     */           
/* 226 */           if (this.loaderRef == null) {
/* 227 */             return (otherEntry.loaderRef == null);
/*     */           }
/* 229 */           ClassLoader loader = this.loaderRef.get();
/* 230 */           return (otherEntry.loaderRef != null && loader != null && loader == otherEntry.loaderRef
/*     */ 
/*     */ 
/*     */             
/* 234 */             .get()); }
/* 235 */         catch (NullPointerException nullPointerException) {  }
/* 236 */         catch (ClassCastException classCastException) {}
/*     */ 
/*     */         
/* 239 */         return false;
/*     */       }
/*     */       
/*     */       public int hashCode() {
/* 243 */         return this.hashCodeCache;
/*     */       }
/*     */       
/*     */       private void calculateHashCode() {
/* 247 */         ClassLoader loader = getLoader();
/* 248 */         if (loader != null) {
/* 249 */           this.hashCodeCache = loader.hashCode();
/*     */         }
/*     */       }
/*     */       
/*     */       public Object clone() {
/*     */         try {
/* 255 */           CacheKey clone = (CacheKey)super.clone();
/* 256 */           if (this.loaderRef != null) {
/* 257 */             clone.loaderRef = new PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.LoaderReference(this.loaderRef.get(), PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.referenceQueue, clone);
/*     */           }
/* 259 */           return clone;
/* 260 */         } catch (CloneNotSupportedException e) {
/*     */           
/* 262 */           throw new InternalError();
/*     */         } 
/*     */       }
/*     */       
/*     */       public String toString() {
/* 267 */         return "CacheKey[" + getLoader() + ")]";
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private class LoaderReference
/*     */       extends WeakReference<ClassLoader>
/*     */       implements CacheKeyReference
/*     */     {
/*     */       private PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey cacheKey;
/*     */ 
/*     */ 
/*     */       
/*     */       LoaderReference(ClassLoader referent, ReferenceQueue<? super ClassLoader> q, PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey key) {
/* 282 */         super(referent, q);
/* 283 */         this.cacheKey = key;
/*     */       }
/*     */       
/*     */       public PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey getCacheKey() {
/* 287 */         return this.cacheKey;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private class PersistenceProviderReference
/*     */       extends SoftReference<List<PersistenceProvider>>
/*     */       implements CacheKeyReference
/*     */     {
/*     */       private PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey cacheKey;
/*     */ 
/*     */       
/*     */       PersistenceProviderReference(List<PersistenceProvider> referent, ReferenceQueue<? super List<PersistenceProvider>> q, PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey key) {
/* 301 */         super(referent, q);
/* 302 */         this.cacheKey = key;
/*     */       }
/*     */       
/*     */       public PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey getCacheKey() {
/* 306 */         return this.cacheKey; } } } class null implements PrivilegedAction<ClassLoader> { public ClassLoader run() { return Thread.currentThread().getContextClassLoader(); } } private class CacheKey implements Cloneable { private PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.LoaderReference loaderRef; private int hashCodeCache; CacheKey(ClassLoader loader) { if (loader == null) { this.loaderRef = null; } else { this.loaderRef = new PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.LoaderReference(loader, PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.referenceQueue, this); }  calculateHashCode(); } ClassLoader getLoader() { return (this.loaderRef != null) ? this.loaderRef.get() : null; } public boolean equals(Object other) { if (this == other) return true;  try { CacheKey otherEntry = (CacheKey)other; if (this.hashCodeCache != otherEntry.hashCodeCache) return false;  if (this.loaderRef == null) return (otherEntry.loaderRef == null);  ClassLoader loader = this.loaderRef.get(); return (otherEntry.loaderRef != null && loader != null && loader == otherEntry.loaderRef.get()); } catch (NullPointerException nullPointerException) {  } catch (ClassCastException classCastException) {} return false; } public int hashCode() { return this.hashCodeCache; } private void calculateHashCode() { ClassLoader loader = getLoader(); if (loader != null) this.hashCodeCache = loader.hashCode();  } public Object clone() { try { CacheKey clone = (CacheKey)super.clone(); if (this.loaderRef != null) clone.loaderRef = new PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.LoaderReference(this.loaderRef.get(), PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.referenceQueue, clone);  return clone; } catch (CloneNotSupportedException e) { throw new InternalError(); }  } public String toString() { return "CacheKey[" + getLoader() + ")]"; } } private class LoaderReference extends WeakReference<ClassLoader> implements DefaultPersistenceProviderResolver.CacheKeyReference { private PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey cacheKey; LoaderReference(ClassLoader referent, ReferenceQueue<? super ClassLoader> q, PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey key) { super(referent, q); this.cacheKey = key; } public PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey getCacheKey() { return this.cacheKey; } } private class PersistenceProviderReference extends SoftReference<List<PersistenceProvider>> implements DefaultPersistenceProviderResolver.CacheKeyReference { public PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey getCacheKey() { return this.cacheKey; }
/*     */ 
/*     */     
/*     */     private PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey cacheKey;
/*     */     
/*     */     PersistenceProviderReference(List<PersistenceProvider> referent, ReferenceQueue<? super List<PersistenceProvider>> q, PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey key) {
/*     */       super(referent, q);
/*     */       this.cacheKey = key;
/*     */     } }
/*     */ 
/*     */   
/*     */   private static interface CacheKeyReference {
/*     */     PersistenceProviderResolverHolder.DefaultPersistenceProviderResolver.CacheKey getCacheKey();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\spi\PersistenceProviderResolverHolder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */