package jakarta.persistence.spi;

import jakarta.persistence.SharedCacheMode;
import jakarta.persistence.ValidationMode;
import java.net.URL;
import java.util.List;
import java.util.Properties;
import javax.sql.DataSource;

public interface PersistenceUnitInfo {
  String getPersistenceUnitName();
  
  String getPersistenceProviderClassName();
  
  PersistenceUnitTransactionType getTransactionType();
  
  DataSource getJtaDataSource();
  
  DataSource getNonJtaDataSource();
  
  List<String> getMappingFileNames();
  
  List<URL> getJarFileUrls();
  
  URL getPersistenceUnitRootUrl();
  
  List<String> getManagedClassNames();
  
  boolean excludeUnlistedClasses();
  
  SharedCacheMode getSharedCacheMode();
  
  ValidationMode getValidationMode();
  
  Properties getProperties();
  
  String getPersistenceXMLSchemaVersion();
  
  ClassLoader getClassLoader();
  
  void addTransformer(ClassTransformer paramClassTransformer);
  
  ClassLoader getNewTempClassLoader();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\spi\PersistenceUnitInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */