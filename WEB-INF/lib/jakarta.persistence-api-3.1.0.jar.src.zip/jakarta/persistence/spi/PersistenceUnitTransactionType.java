/*    */ package jakarta.persistence.spi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PersistenceUnitTransactionType
/*    */ {
/* 29 */   JTA,
/*    */ 
/*    */   
/* 32 */   RESOURCE_LOCAL;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\spi\PersistenceUnitTransactionType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */