package jakarta.persistence.spi;

import jakarta.persistence.EntityManagerFactory;
import java.util.Map;

public interface PersistenceProvider {
  EntityManagerFactory createEntityManagerFactory(String paramString, Map paramMap);
  
  EntityManagerFactory createContainerEntityManagerFactory(PersistenceUnitInfo paramPersistenceUnitInfo, Map paramMap);
  
  void generateSchema(PersistenceUnitInfo paramPersistenceUnitInfo, Map paramMap);
  
  boolean generateSchema(String paramString, Map paramMap);
  
  ProviderUtil getProviderUtil();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\spi\PersistenceProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */