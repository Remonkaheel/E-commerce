/*    */ package jakarta.persistence;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Query
/*    */ {
/*    */   List getResultList();
/*    */   
/*    */   default Stream getResultStream() {
/* 88 */     return getResultList().stream();
/*    */   }
/*    */   
/*    */   Object getSingleResult();
/*    */   
/*    */   int executeUpdate();
/*    */   
/*    */   Query setMaxResults(int paramInt);
/*    */   
/*    */   int getMaxResults();
/*    */   
/*    */   Query setFirstResult(int paramInt);
/*    */   
/*    */   int getFirstResult();
/*    */   
/*    */   Query setHint(String paramString, Object paramObject);
/*    */   
/*    */   Map<String, Object> getHints();
/*    */   
/*    */   <T> Query setParameter(Parameter<T> paramParameter, T paramT);
/*    */   
/*    */   Query setParameter(Parameter<Calendar> paramParameter, Calendar paramCalendar, TemporalType paramTemporalType);
/*    */   
/*    */   Query setParameter(Parameter<Date> paramParameter, Date paramDate, TemporalType paramTemporalType);
/*    */   
/*    */   Query setParameter(String paramString, Object paramObject);
/*    */   
/*    */   Query setParameter(String paramString, Calendar paramCalendar, TemporalType paramTemporalType);
/*    */   
/*    */   Query setParameter(String paramString, Date paramDate, TemporalType paramTemporalType);
/*    */   
/*    */   Query setParameter(int paramInt, Object paramObject);
/*    */   
/*    */   Query setParameter(int paramInt, Calendar paramCalendar, TemporalType paramTemporalType);
/*    */   
/*    */   Query setParameter(int paramInt, Date paramDate, TemporalType paramTemporalType);
/*    */   
/*    */   Set<Parameter<?>> getParameters();
/*    */   
/*    */   Parameter<?> getParameter(String paramString);
/*    */   
/*    */   <T> Parameter<T> getParameter(String paramString, Class<T> paramClass);
/*    */   
/*    */   Parameter<?> getParameter(int paramInt);
/*    */   
/*    */   <T> Parameter<T> getParameter(int paramInt, Class<T> paramClass);
/*    */   
/*    */   boolean isBound(Parameter<?> paramParameter);
/*    */   
/*    */   <T> T getParameterValue(Parameter<T> paramParameter);
/*    */   
/*    */   Object getParameterValue(String paramString);
/*    */   
/*    */   Object getParameterValue(int paramInt);
/*    */   
/*    */   Query setFlushMode(FlushModeType paramFlushModeType);
/*    */   
/*    */   FlushModeType getFlushMode();
/*    */   
/*    */   Query setLockMode(LockModeType paramLockModeType);
/*    */   
/*    */   LockModeType getLockMode();
/*    */   
/*    */   <T> T unwrap(Class<T> paramClass);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\Query.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */