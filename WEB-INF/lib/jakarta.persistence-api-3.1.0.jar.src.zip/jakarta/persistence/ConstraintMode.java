/*    */ package jakarta.persistence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ConstraintMode
/*    */ {
/* 26 */   CONSTRAINT,
/*    */ 
/*    */   
/* 29 */   NO_CONSTRAINT,
/*    */ 
/*    */   
/* 32 */   PROVIDER_DEFAULT;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\ConstraintMode.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */