package jakarta.persistence;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Repeatable(NamedNativeQueries.class)
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface NamedNativeQuery {
  String name();
  
  String query();
  
  QueryHint[] hints() default {};
  
  Class resultClass() default void.class;
  
  String resultSetMapping() default "";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\NamedNativeQuery.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */