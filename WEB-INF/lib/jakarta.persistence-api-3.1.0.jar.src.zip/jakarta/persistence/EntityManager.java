package jakarta.persistence;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaDelete;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.CriteriaUpdate;
import jakarta.persistence.metamodel.Metamodel;
import java.util.List;
import java.util.Map;

public interface EntityManager extends AutoCloseable {
  void persist(Object paramObject);
  
  <T> T merge(T paramT);
  
  void remove(Object paramObject);
  
  <T> T find(Class<T> paramClass, Object paramObject);
  
  <T> T find(Class<T> paramClass, Object paramObject, Map<String, Object> paramMap);
  
  <T> T find(Class<T> paramClass, Object paramObject, LockModeType paramLockModeType);
  
  <T> T find(Class<T> paramClass, Object paramObject, LockModeType paramLockModeType, Map<String, Object> paramMap);
  
  <T> T getReference(Class<T> paramClass, Object paramObject);
  
  void flush();
  
  void setFlushMode(FlushModeType paramFlushModeType);
  
  FlushModeType getFlushMode();
  
  void lock(Object paramObject, LockModeType paramLockModeType);
  
  void lock(Object paramObject, LockModeType paramLockModeType, Map<String, Object> paramMap);
  
  void refresh(Object paramObject);
  
  void refresh(Object paramObject, Map<String, Object> paramMap);
  
  void refresh(Object paramObject, LockModeType paramLockModeType);
  
  void refresh(Object paramObject, LockModeType paramLockModeType, Map<String, Object> paramMap);
  
  void clear();
  
  void detach(Object paramObject);
  
  boolean contains(Object paramObject);
  
  LockModeType getLockMode(Object paramObject);
  
  void setProperty(String paramString, Object paramObject);
  
  Map<String, Object> getProperties();
  
  Query createQuery(String paramString);
  
  <T> TypedQuery<T> createQuery(CriteriaQuery<T> paramCriteriaQuery);
  
  Query createQuery(CriteriaUpdate paramCriteriaUpdate);
  
  Query createQuery(CriteriaDelete paramCriteriaDelete);
  
  <T> TypedQuery<T> createQuery(String paramString, Class<T> paramClass);
  
  Query createNamedQuery(String paramString);
  
  <T> TypedQuery<T> createNamedQuery(String paramString, Class<T> paramClass);
  
  Query createNativeQuery(String paramString);
  
  Query createNativeQuery(String paramString, Class paramClass);
  
  Query createNativeQuery(String paramString1, String paramString2);
  
  StoredProcedureQuery createNamedStoredProcedureQuery(String paramString);
  
  StoredProcedureQuery createStoredProcedureQuery(String paramString);
  
  StoredProcedureQuery createStoredProcedureQuery(String paramString, Class... paramVarArgs);
  
  StoredProcedureQuery createStoredProcedureQuery(String paramString, String... paramVarArgs);
  
  void joinTransaction();
  
  boolean isJoinedToTransaction();
  
  <T> T unwrap(Class<T> paramClass);
  
  Object getDelegate();
  
  void close();
  
  boolean isOpen();
  
  EntityTransaction getTransaction();
  
  EntityManagerFactory getEntityManagerFactory();
  
  CriteriaBuilder getCriteriaBuilder();
  
  Metamodel getMetamodel();
  
  <T> EntityGraph<T> createEntityGraph(Class<T> paramClass);
  
  EntityGraph<?> createEntityGraph(String paramString);
  
  EntityGraph<?> getEntityGraph(String paramString);
  
  <T> List<EntityGraph<? super T>> getEntityGraphs(Class<T> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\EntityManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */