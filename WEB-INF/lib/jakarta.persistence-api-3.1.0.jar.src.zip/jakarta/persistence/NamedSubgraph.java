package jakarta.persistence;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({})
@Retention(RetentionPolicy.RUNTIME)
public @interface NamedSubgraph {
  String name();
  
  Class type() default void.class;
  
  NamedAttributeNode[] attributeNodes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\NamedSubgraph.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */