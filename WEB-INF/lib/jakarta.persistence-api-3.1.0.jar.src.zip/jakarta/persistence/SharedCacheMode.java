/*    */ package jakarta.persistence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SharedCacheMode
/*    */ {
/* 34 */   ALL,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   NONE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   ENABLE_SELECTIVE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   DISABLE_SELECTIVE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   UNSPECIFIED;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\SharedCacheMode.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */