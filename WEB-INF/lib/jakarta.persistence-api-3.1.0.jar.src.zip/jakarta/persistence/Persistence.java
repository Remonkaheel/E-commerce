/*     */ package jakarta.persistence;
/*     */ 
/*     */ import jakarta.persistence.spi.LoadState;
/*     */ import jakarta.persistence.spi.PersistenceProvider;
/*     */ import jakarta.persistence.spi.PersistenceProviderResolver;
/*     */ import jakarta.persistence.spi.PersistenceProviderResolverHolder;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Persistence
/*     */ {
/*     */   @Deprecated
/*     */   public static final String PERSISTENCE_PROVIDER = "jakarta.persistence.spi.PersistenceProvider";
/*     */   
/*     */   public static EntityManagerFactory createEntityManagerFactory(String persistenceUnitName) {
/*  55 */     return createEntityManagerFactory(persistenceUnitName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManagerFactory createEntityManagerFactory(String persistenceUnitName, Map properties) {
/*  74 */     EntityManagerFactory emf = null;
/*  75 */     PersistenceProviderResolver resolver = PersistenceProviderResolverHolder.getPersistenceProviderResolver();
/*     */     
/*  77 */     List<PersistenceProvider> providers = resolver.getPersistenceProviders();
/*     */     
/*  79 */     for (PersistenceProvider provider : providers) {
/*  80 */       emf = provider.createEntityManagerFactory(persistenceUnitName, properties);
/*  81 */       if (emf != null) {
/*     */         break;
/*     */       }
/*     */     } 
/*  85 */     if (emf == null) {
/*  86 */       throw new PersistenceException("No Persistence provider for EntityManager named " + persistenceUnitName);
/*     */     }
/*  88 */     return emf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void generateSchema(String persistenceUnitName, Map map) {
/* 111 */     PersistenceProviderResolver resolver = PersistenceProviderResolverHolder.getPersistenceProviderResolver();
/* 112 */     List<PersistenceProvider> providers = resolver.getPersistenceProviders();
/*     */     
/* 114 */     for (PersistenceProvider provider : providers) {
/* 115 */       if (provider.generateSchema(persistenceUnitName, map)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 120 */     throw new PersistenceException("No Persistence provider to generate schema named " + persistenceUnitName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PersistenceUtil getPersistenceUtil() {
/* 130 */     return new PersistenceUtilImpl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PersistenceUtilImpl
/*     */     implements PersistenceUtil
/*     */   {
/*     */     public boolean isLoaded(Object entity, String attributeName) {
/* 140 */       PersistenceProviderResolver resolver = PersistenceProviderResolverHolder.getPersistenceProviderResolver();
/*     */       
/* 142 */       List<PersistenceProvider> providers = resolver.getPersistenceProviders();
/*     */       
/* 144 */       for (PersistenceProvider provider : providers) {
/* 145 */         LoadState loadstate = provider.getProviderUtil().isLoadedWithoutReference(entity, attributeName);
/* 146 */         if (loadstate == LoadState.LOADED)
/* 147 */           return true; 
/* 148 */         if (loadstate == LoadState.NOT_LOADED) {
/* 149 */           return false;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 154 */       for (PersistenceProvider provider : providers) {
/* 155 */         LoadState loadstate = provider.getProviderUtil().isLoadedWithReference(entity, attributeName);
/* 156 */         if (loadstate == LoadState.LOADED)
/* 157 */           return true; 
/* 158 */         if (loadstate == LoadState.NOT_LOADED) {
/* 159 */           return false;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 164 */       return true;
/*     */     }
/*     */     
/*     */     public boolean isLoaded(Object entity) {
/* 168 */       PersistenceProviderResolver resolver = PersistenceProviderResolverHolder.getPersistenceProviderResolver();
/*     */       
/* 170 */       List<PersistenceProvider> providers = resolver.getPersistenceProviders();
/*     */       
/* 172 */       for (PersistenceProvider provider : providers) {
/* 173 */         LoadState loadstate = provider.getProviderUtil().isLoaded(entity);
/* 174 */         if (loadstate == LoadState.LOADED)
/* 175 */           return true; 
/* 176 */         if (loadstate == LoadState.NOT_LOADED) {
/* 177 */           return false;
/*     */         }
/*     */       } 
/*     */       
/* 181 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/* 203 */   protected static final Set<PersistenceProvider> providers = new HashSet<>();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\Persistence.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */