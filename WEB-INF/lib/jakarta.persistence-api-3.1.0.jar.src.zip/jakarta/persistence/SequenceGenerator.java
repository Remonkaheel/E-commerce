package jakarta.persistence;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Repeatable(SequenceGenerators.class)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface SequenceGenerator {
  String name();
  
  String sequenceName() default "";
  
  String catalog() default "";
  
  String schema() default "";
  
  int initialValue() default 1;
  
  int allocationSize() default 50;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\SequenceGenerator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */