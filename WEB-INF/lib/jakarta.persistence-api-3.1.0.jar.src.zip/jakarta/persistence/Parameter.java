package jakarta.persistence;

public interface Parameter<T> {
  String getName();
  
  Integer getPosition();
  
  Class<T> getParameterType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\Parameter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */