/*    */ package jakarta.persistence;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TypedQuery<X>
/*    */   extends Query
/*    */ {
/*    */   TypedQuery<X> setLockMode(LockModeType paramLockModeType);
/*    */   
/*    */   TypedQuery<X> setFlushMode(FlushModeType paramFlushModeType);
/*    */   
/*    */   TypedQuery<X> setParameter(int paramInt, Date paramDate, TemporalType paramTemporalType);
/*    */   
/*    */   TypedQuery<X> setParameter(int paramInt, Calendar paramCalendar, TemporalType paramTemporalType);
/*    */   
/*    */   TypedQuery<X> setParameter(int paramInt, Object paramObject);
/*    */   
/*    */   TypedQuery<X> setParameter(String paramString, Date paramDate, TemporalType paramTemporalType);
/*    */   
/*    */   TypedQuery<X> setParameter(String paramString, Calendar paramCalendar, TemporalType paramTemporalType);
/*    */   
/*    */   TypedQuery<X> setParameter(String paramString, Object paramObject);
/*    */   
/*    */   TypedQuery<X> setParameter(Parameter<Date> paramParameter, Date paramDate, TemporalType paramTemporalType);
/*    */   
/*    */   TypedQuery<X> setParameter(Parameter<Calendar> paramParameter, Calendar paramCalendar, TemporalType paramTemporalType);
/*    */   
/*    */   <T> TypedQuery<X> setParameter(Parameter<T> paramParameter, T paramT);
/*    */   
/*    */   TypedQuery<X> setHint(String paramString, Object paramObject);
/*    */   
/*    */   TypedQuery<X> setFirstResult(int paramInt);
/*    */   
/*    */   TypedQuery<X> setMaxResults(int paramInt);
/*    */   
/*    */   X getSingleResult();
/*    */   
/*    */   default Stream<X> getResultStream() {
/* 87 */     return getResultList().stream();
/*    */   }
/*    */   
/*    */   List<X> getResultList();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\TypedQuery.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */