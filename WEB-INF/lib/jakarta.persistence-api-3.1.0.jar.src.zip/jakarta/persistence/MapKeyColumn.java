package jakarta.persistence;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface MapKeyColumn {
  String name() default "";
  
  boolean unique() default false;
  
  boolean nullable() default false;
  
  boolean insertable() default true;
  
  boolean updatable() default true;
  
  String columnDefinition() default "";
  
  String table() default "";
  
  int length() default 255;
  
  int precision() default 0;
  
  int scale() default 0;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\MapKeyColumn.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */