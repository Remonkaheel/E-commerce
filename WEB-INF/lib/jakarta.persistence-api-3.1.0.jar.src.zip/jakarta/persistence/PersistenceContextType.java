/*    */ package jakarta.persistence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PersistenceContextType
/*    */ {
/* 29 */   TRANSACTION,
/*    */ 
/*    */   
/* 32 */   EXTENDED;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\PersistenceContextType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */