package jakarta.persistence;

import jakarta.persistence.metamodel.Attribute;
import java.util.List;

public interface EntityGraph<T> {
  String getName();
  
  void addAttributeNodes(String... paramVarArgs);
  
  void addAttributeNodes(Attribute<T, ?>... paramVarArgs);
  
  <X> Subgraph<X> addSubgraph(Attribute<T, X> paramAttribute);
  
  <X> Subgraph<? extends X> addSubgraph(Attribute<T, X> paramAttribute, Class<? extends X> paramClass);
  
  <X> Subgraph<X> addSubgraph(String paramString);
  
  <X> Subgraph<X> addSubgraph(String paramString, Class<X> paramClass);
  
  <X> Subgraph<X> addKeySubgraph(Attribute<T, X> paramAttribute);
  
  <X> Subgraph<? extends X> addKeySubgraph(Attribute<T, X> paramAttribute, Class<? extends X> paramClass);
  
  <X> Subgraph<X> addKeySubgraph(String paramString);
  
  <X> Subgraph<X> addKeySubgraph(String paramString, Class<X> paramClass);
  
  <T> Subgraph<? extends T> addSubclassSubgraph(Class<? extends T> paramClass);
  
  List<AttributeNode<?>> getAttributeNodes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\EntityGraph.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */