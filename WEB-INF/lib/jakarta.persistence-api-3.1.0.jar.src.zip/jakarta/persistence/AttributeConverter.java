package jakarta.persistence;

public interface AttributeConverter<X, Y> {
  Y convertToDatabaseColumn(X paramX);
  
  X convertToEntityAttribute(Y paramY);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\AttributeConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */