package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.EntityType;
import java.util.List;
import java.util.Set;

public interface AbstractQuery<T> extends CommonAbstractCriteria {
  <X> Root<X> from(Class<X> paramClass);
  
  <X> Root<X> from(EntityType<X> paramEntityType);
  
  AbstractQuery<T> where(Expression<Boolean> paramExpression);
  
  AbstractQuery<T> where(Predicate... paramVarArgs);
  
  AbstractQuery<T> groupBy(Expression<?>... paramVarArgs);
  
  AbstractQuery<T> groupBy(List<Expression<?>> paramList);
  
  AbstractQuery<T> having(Expression<Boolean> paramExpression);
  
  AbstractQuery<T> having(Predicate... paramVarArgs);
  
  AbstractQuery<T> distinct(boolean paramBoolean);
  
  Set<Root<?>> getRoots();
  
  Selection<T> getSelection();
  
  List<Expression<?>> getGroupList();
  
  Predicate getGroupRestriction();
  
  boolean isDistinct();
  
  Class<T> getResultType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\AbstractQuery.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */