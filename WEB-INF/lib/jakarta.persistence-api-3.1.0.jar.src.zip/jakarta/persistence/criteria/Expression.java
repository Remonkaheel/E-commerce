package jakarta.persistence.criteria;

import java.util.Collection;

public interface Expression<T> extends Selection<T> {
  Predicate isNull();
  
  Predicate isNotNull();
  
  Predicate in(Object... paramVarArgs);
  
  Predicate in(Expression<?>... paramVarArgs);
  
  Predicate in(Collection<?> paramCollection);
  
  Predicate in(Expression<Collection<?>> paramExpression);
  
  <X> Expression<X> as(Class<X> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\Expression.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */