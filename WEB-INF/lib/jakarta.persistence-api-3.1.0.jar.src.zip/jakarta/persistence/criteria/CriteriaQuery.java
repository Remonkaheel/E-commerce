package jakarta.persistence.criteria;

import java.util.List;
import java.util.Set;

public interface CriteriaQuery<T> extends AbstractQuery<T> {
  CriteriaQuery<T> select(Selection<? extends T> paramSelection);
  
  CriteriaQuery<T> multiselect(Selection<?>... paramVarArgs);
  
  CriteriaQuery<T> multiselect(List<Selection<?>> paramList);
  
  CriteriaQuery<T> where(Expression<Boolean> paramExpression);
  
  CriteriaQuery<T> where(Predicate... paramVarArgs);
  
  CriteriaQuery<T> groupBy(Expression<?>... paramVarArgs);
  
  CriteriaQuery<T> groupBy(List<Expression<?>> paramList);
  
  CriteriaQuery<T> having(Expression<Boolean> paramExpression);
  
  CriteriaQuery<T> having(Predicate... paramVarArgs);
  
  CriteriaQuery<T> orderBy(Order... paramVarArgs);
  
  CriteriaQuery<T> orderBy(List<Order> paramList);
  
  CriteriaQuery<T> distinct(boolean paramBoolean);
  
  List<Order> getOrderList();
  
  Set<ParameterExpression<?>> getParameters();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\CriteriaQuery.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */