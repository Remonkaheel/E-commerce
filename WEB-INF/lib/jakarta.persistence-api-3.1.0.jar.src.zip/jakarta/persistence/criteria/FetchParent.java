package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.PluralAttribute;
import jakarta.persistence.metamodel.SingularAttribute;
import java.util.Set;

public interface FetchParent<Z, X> {
  Set<Fetch<X, ?>> getFetches();
  
  <Y> Fetch<X, Y> fetch(SingularAttribute<? super X, Y> paramSingularAttribute);
  
  <Y> Fetch<X, Y> fetch(SingularAttribute<? super X, Y> paramSingularAttribute, JoinType paramJoinType);
  
  <Y> Fetch<X, Y> fetch(PluralAttribute<? super X, ?, Y> paramPluralAttribute);
  
  <Y> Fetch<X, Y> fetch(PluralAttribute<? super X, ?, Y> paramPluralAttribute, JoinType paramJoinType);
  
  <X, Y> Fetch<X, Y> fetch(String paramString);
  
  <X, Y> Fetch<X, Y> fetch(String paramString, JoinType paramJoinType);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\FetchParent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */