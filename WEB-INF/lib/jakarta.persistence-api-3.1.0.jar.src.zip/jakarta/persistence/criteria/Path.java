package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.Bindable;
import jakarta.persistence.metamodel.MapAttribute;
import jakarta.persistence.metamodel.PluralAttribute;
import jakarta.persistence.metamodel.SingularAttribute;

public interface Path<X> extends Expression<X> {
  Bindable<X> getModel();
  
  Path<?> getParentPath();
  
  <Y> Path<Y> get(SingularAttribute<? super X, Y> paramSingularAttribute);
  
  <E, C extends java.util.Collection<E>> Expression<C> get(PluralAttribute<X, C, E> paramPluralAttribute);
  
  <K, V, M extends java.util.Map<K, V>> Expression<M> get(MapAttribute<X, K, V> paramMapAttribute);
  
  Expression<Class<? extends X>> type();
  
  <Y> Path<Y> get(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\Path.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */