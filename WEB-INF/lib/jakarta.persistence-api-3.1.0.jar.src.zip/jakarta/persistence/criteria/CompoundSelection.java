package jakarta.persistence.criteria;

public interface CompoundSelection<X> extends Selection<X> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\CompoundSelection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */