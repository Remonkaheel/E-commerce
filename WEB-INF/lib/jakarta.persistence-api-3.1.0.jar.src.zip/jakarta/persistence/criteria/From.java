package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.CollectionAttribute;
import jakarta.persistence.metamodel.ListAttribute;
import jakarta.persistence.metamodel.MapAttribute;
import jakarta.persistence.metamodel.SetAttribute;
import jakarta.persistence.metamodel.SingularAttribute;
import java.util.Set;

public interface From<Z, X> extends Path<X>, FetchParent<Z, X> {
  Set<Join<X, ?>> getJoins();
  
  boolean isCorrelated();
  
  From<Z, X> getCorrelationParent();
  
  <Y> Join<X, Y> join(SingularAttribute<? super X, Y> paramSingularAttribute);
  
  <Y> Join<X, Y> join(SingularAttribute<? super X, Y> paramSingularAttribute, JoinType paramJoinType);
  
  <Y> CollectionJoin<X, Y> join(CollectionAttribute<? super X, Y> paramCollectionAttribute);
  
  <Y> SetJoin<X, Y> join(SetAttribute<? super X, Y> paramSetAttribute);
  
  <Y> ListJoin<X, Y> join(ListAttribute<? super X, Y> paramListAttribute);
  
  <K, V> MapJoin<X, K, V> join(MapAttribute<? super X, K, V> paramMapAttribute);
  
  <Y> CollectionJoin<X, Y> join(CollectionAttribute<? super X, Y> paramCollectionAttribute, JoinType paramJoinType);
  
  <Y> SetJoin<X, Y> join(SetAttribute<? super X, Y> paramSetAttribute, JoinType paramJoinType);
  
  <Y> ListJoin<X, Y> join(ListAttribute<? super X, Y> paramListAttribute, JoinType paramJoinType);
  
  <K, V> MapJoin<X, K, V> join(MapAttribute<? super X, K, V> paramMapAttribute, JoinType paramJoinType);
  
  <X, Y> Join<X, Y> join(String paramString);
  
  <X, Y> CollectionJoin<X, Y> joinCollection(String paramString);
  
  <X, Y> SetJoin<X, Y> joinSet(String paramString);
  
  <X, Y> ListJoin<X, Y> joinList(String paramString);
  
  <X, K, V> MapJoin<X, K, V> joinMap(String paramString);
  
  <X, Y> Join<X, Y> join(String paramString, JoinType paramJoinType);
  
  <X, Y> CollectionJoin<X, Y> joinCollection(String paramString, JoinType paramJoinType);
  
  <X, Y> SetJoin<X, Y> joinSet(String paramString, JoinType paramJoinType);
  
  <X, Y> ListJoin<X, Y> joinList(String paramString, JoinType paramJoinType);
  
  <X, K, V> MapJoin<X, K, V> joinMap(String paramString, JoinType paramJoinType);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\From.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */