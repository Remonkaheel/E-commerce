package jakarta.persistence.criteria;

import java.util.List;
import java.util.Set;

public interface Subquery<T> extends AbstractQuery<T>, Expression<T> {
  Subquery<T> select(Expression<T> paramExpression);
  
  Subquery<T> where(Expression<Boolean> paramExpression);
  
  Subquery<T> where(Predicate... paramVarArgs);
  
  Subquery<T> groupBy(Expression<?>... paramVarArgs);
  
  Subquery<T> groupBy(List<Expression<?>> paramList);
  
  Subquery<T> having(Expression<Boolean> paramExpression);
  
  Subquery<T> having(Predicate... paramVarArgs);
  
  Subquery<T> distinct(boolean paramBoolean);
  
  <Y> Root<Y> correlate(Root<Y> paramRoot);
  
  <X, Y> Join<X, Y> correlate(Join<X, Y> paramJoin);
  
  <X, Y> CollectionJoin<X, Y> correlate(CollectionJoin<X, Y> paramCollectionJoin);
  
  <X, Y> SetJoin<X, Y> correlate(SetJoin<X, Y> paramSetJoin);
  
  <X, Y> ListJoin<X, Y> correlate(ListJoin<X, Y> paramListJoin);
  
  <X, K, V> MapJoin<X, K, V> correlate(MapJoin<X, K, V> paramMapJoin);
  
  AbstractQuery<?> getParent();
  
  CommonAbstractCriteria getContainingQuery();
  
  Expression<T> getSelection();
  
  Set<Join<?, ?>> getCorrelatedJoins();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\Subquery.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */