/*      */ package jakarta.persistence.criteria;
/*      */ 
/*      */ import jakarta.persistence.Tuple;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.Date;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.time.LocalDate;
/*      */ import java.time.LocalDateTime;
/*      */ import java.time.LocalTime;
/*      */ import java.util.Collection;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface CriteriaBuilder
/*      */ {
/*      */   CriteriaQuery<Object> createQuery();
/*      */   
/*      */   <T> CriteriaQuery<T> createQuery(Class<T> paramClass);
/*      */   
/*      */   CriteriaQuery<Tuple> createTupleQuery();
/*      */   
/*      */   <T> CriteriaUpdate<T> createCriteriaUpdate(Class<T> paramClass);
/*      */   
/*      */   <T> CriteriaDelete<T> createCriteriaDelete(Class<T> paramClass);
/*      */   
/*      */   <Y> CompoundSelection<Y> construct(Class<Y> paramClass, Selection<?>... paramVarArgs);
/*      */   
/*      */   CompoundSelection<Tuple> tuple(Selection<?>... paramVarArgs);
/*      */   
/*      */   CompoundSelection<Object[]> array(Selection<?>... paramVarArgs);
/*      */   
/*      */   Order asc(Expression<?> paramExpression);
/*      */   
/*      */   Order desc(Expression<?> paramExpression);
/*      */   
/*      */   <N extends Number> Expression<Double> avg(Expression<N> paramExpression);
/*      */   
/*      */   <N extends Number> Expression<N> sum(Expression<N> paramExpression);
/*      */   
/*      */   Expression<Long> sumAsLong(Expression<Integer> paramExpression);
/*      */   
/*      */   Expression<Double> sumAsDouble(Expression<Float> paramExpression);
/*      */   
/*      */   <N extends Number> Expression<N> max(Expression<N> paramExpression);
/*      */   
/*      */   <N extends Number> Expression<N> min(Expression<N> paramExpression);
/*      */   
/*      */   <X extends Comparable<? super X>> Expression<X> greatest(Expression<X> paramExpression);
/*      */   
/*      */   <X extends Comparable<? super X>> Expression<X> least(Expression<X> paramExpression);
/*      */   
/*      */   Expression<Long> count(Expression<?> paramExpression);
/*      */   
/*      */   Expression<Long> countDistinct(Expression<?> paramExpression);
/*      */   
/*      */   Predicate exists(Subquery<?> paramSubquery);
/*      */   
/*      */   <Y> Expression<Y> all(Subquery<Y> paramSubquery);
/*      */   
/*      */   <Y> Expression<Y> some(Subquery<Y> paramSubquery);
/*      */   
/*      */   <Y> Expression<Y> any(Subquery<Y> paramSubquery);
/*      */   
/*      */   Predicate and(Expression<Boolean> paramExpression1, Expression<Boolean> paramExpression2);
/*      */   
/*      */   Predicate and(Predicate... paramVarArgs);
/*      */   
/*      */   Predicate or(Expression<Boolean> paramExpression1, Expression<Boolean> paramExpression2);
/*      */   
/*      */   Predicate or(Predicate... paramVarArgs);
/*      */   
/*      */   Predicate not(Expression<Boolean> paramExpression);
/*      */   
/*      */   Predicate conjunction();
/*      */   
/*      */   Predicate disjunction();
/*      */   
/*      */   Predicate isTrue(Expression<Boolean> paramExpression);
/*      */   
/*      */   Predicate isFalse(Expression<Boolean> paramExpression);
/*      */   
/*      */   Predicate isNull(Expression<?> paramExpression);
/*      */   
/*      */   Predicate isNotNull(Expression<?> paramExpression);
/*      */   
/*      */   Predicate equal(Expression<?> paramExpression1, Expression<?> paramExpression2);
/*      */   
/*      */   Predicate equal(Expression<?> paramExpression, Object paramObject);
/*      */   
/*      */   Predicate notEqual(Expression<?> paramExpression1, Expression<?> paramExpression2);
/*      */   
/*      */   Predicate notEqual(Expression<?> paramExpression, Object paramObject);
/*      */   
/*      */   <Y extends Comparable<? super Y>> Predicate greaterThan(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2);
/*      */   
/*      */   <Y extends Comparable<? super Y>> Predicate greaterThan(Expression<? extends Y> paramExpression, Y paramY);
/*      */   
/*      */   <Y extends Comparable<? super Y>> Predicate greaterThanOrEqualTo(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2);
/*      */   
/*      */   <Y extends Comparable<? super Y>> Predicate greaterThanOrEqualTo(Expression<? extends Y> paramExpression, Y paramY);
/*      */   
/*      */   <Y extends Comparable<? super Y>> Predicate lessThan(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2);
/*      */   
/*      */   <Y extends Comparable<? super Y>> Predicate lessThan(Expression<? extends Y> paramExpression, Y paramY);
/*      */   
/*      */   <Y extends Comparable<? super Y>> Predicate lessThanOrEqualTo(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2);
/*      */   
/*      */   <Y extends Comparable<? super Y>> Predicate lessThanOrEqualTo(Expression<? extends Y> paramExpression, Y paramY);
/*      */   
/*      */   <Y extends Comparable<? super Y>> Predicate between(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2, Expression<? extends Y> paramExpression3);
/*      */   
/*      */   <Y extends Comparable<? super Y>> Predicate between(Expression<? extends Y> paramExpression, Y paramY1, Y paramY2);
/*      */   
/*      */   Predicate gt(Expression<? extends Number> paramExpression1, Expression<? extends Number> paramExpression2);
/*      */   
/*      */   Predicate gt(Expression<? extends Number> paramExpression, Number paramNumber);
/*      */   
/*      */   Predicate ge(Expression<? extends Number> paramExpression1, Expression<? extends Number> paramExpression2);
/*      */   
/*      */   Predicate ge(Expression<? extends Number> paramExpression, Number paramNumber);
/*      */   
/*      */   Predicate lt(Expression<? extends Number> paramExpression1, Expression<? extends Number> paramExpression2);
/*      */   
/*      */   Predicate lt(Expression<? extends Number> paramExpression, Number paramNumber);
/*      */   
/*      */   Predicate le(Expression<? extends Number> paramExpression1, Expression<? extends Number> paramExpression2);
/*      */   
/*      */   Predicate le(Expression<? extends Number> paramExpression, Number paramNumber);
/*      */   
/*      */   Expression<Integer> sign(Expression<? extends Number> paramExpression);
/*      */   
/*      */   <N extends Number> Expression<N> neg(Expression<N> paramExpression);
/*      */   
/*      */   <N extends Number> Expression<N> abs(Expression<N> paramExpression);
/*      */   
/*      */   <N extends Number> Expression<N> ceiling(Expression<N> paramExpression);
/*      */   
/*      */   <N extends Number> Expression<N> floor(Expression<N> paramExpression);
/*      */   
/*      */   <N extends Number> Expression<N> sum(Expression<? extends N> paramExpression1, Expression<? extends N> paramExpression2);
/*      */   
/*      */   <N extends Number> Expression<N> sum(Expression<? extends N> paramExpression, N paramN);
/*      */   
/*      */   <N extends Number> Expression<N> sum(N paramN, Expression<? extends N> paramExpression);
/*      */   
/*      */   <N extends Number> Expression<N> prod(Expression<? extends N> paramExpression1, Expression<? extends N> paramExpression2);
/*      */   
/*      */   <N extends Number> Expression<N> prod(Expression<? extends N> paramExpression, N paramN);
/*      */   
/*      */   <N extends Number> Expression<N> prod(N paramN, Expression<? extends N> paramExpression);
/*      */   
/*      */   <N extends Number> Expression<N> diff(Expression<? extends N> paramExpression1, Expression<? extends N> paramExpression2);
/*      */   
/*      */   <N extends Number> Expression<N> diff(Expression<? extends N> paramExpression, N paramN);
/*      */   
/*      */   <N extends Number> Expression<N> diff(N paramN, Expression<? extends N> paramExpression);
/*      */   
/*      */   Expression<Number> quot(Expression<? extends Number> paramExpression1, Expression<? extends Number> paramExpression2);
/*      */   
/*      */   Expression<Number> quot(Expression<? extends Number> paramExpression, Number paramNumber);
/*      */   
/*      */   Expression<Number> quot(Number paramNumber, Expression<? extends Number> paramExpression);
/*      */   
/*      */   Expression<Integer> mod(Expression<Integer> paramExpression1, Expression<Integer> paramExpression2);
/*      */   
/*      */   Expression<Integer> mod(Expression<Integer> paramExpression, Integer paramInteger);
/*      */   
/*      */   Expression<Integer> mod(Integer paramInteger, Expression<Integer> paramExpression);
/*      */   
/*      */   Expression<Double> sqrt(Expression<? extends Number> paramExpression);
/*      */   
/*      */   Expression<Double> exp(Expression<? extends Number> paramExpression);
/*      */   
/*      */   Expression<Double> ln(Expression<? extends Number> paramExpression);
/*      */   
/*      */   Expression<Double> power(Expression<? extends Number> paramExpression1, Expression<? extends Number> paramExpression2);
/*      */   
/*      */   Expression<Double> power(Expression<? extends Number> paramExpression, Number paramNumber);
/*      */   
/*      */   <T extends Number> Expression<T> round(Expression<T> paramExpression, Integer paramInteger);
/*      */   
/*      */   Expression<Long> toLong(Expression<? extends Number> paramExpression);
/*      */   
/*      */   Expression<Integer> toInteger(Expression<? extends Number> paramExpression);
/*      */   
/*      */   Expression<Float> toFloat(Expression<? extends Number> paramExpression);
/*      */   
/*      */   Expression<Double> toDouble(Expression<? extends Number> paramExpression);
/*      */   
/*      */   Expression<BigDecimal> toBigDecimal(Expression<? extends Number> paramExpression);
/*      */   
/*      */   Expression<BigInteger> toBigInteger(Expression<? extends Number> paramExpression);
/*      */   
/*      */   Expression<String> toString(Expression<Character> paramExpression);
/*      */   
/*      */   <T> Expression<T> literal(T paramT);
/*      */   
/*      */   <T> Expression<T> nullLiteral(Class<T> paramClass);
/*      */   
/*      */   <T> ParameterExpression<T> parameter(Class<T> paramClass);
/*      */   
/*      */   <T> ParameterExpression<T> parameter(Class<T> paramClass, String paramString);
/*      */   
/*      */   <C extends Collection<?>> Predicate isEmpty(Expression<C> paramExpression);
/*      */   
/*      */   <C extends Collection<?>> Predicate isNotEmpty(Expression<C> paramExpression);
/*      */   
/*      */   <C extends Collection<?>> Expression<Integer> size(Expression<C> paramExpression);
/*      */   
/*      */   <C extends Collection<?>> Expression<Integer> size(C paramC);
/*      */   
/*      */   <E, C extends Collection<E>> Predicate isMember(Expression<E> paramExpression, Expression<C> paramExpression1);
/*      */   
/*      */   <E, C extends Collection<E>> Predicate isMember(E paramE, Expression<C> paramExpression);
/*      */   
/*      */   <E, C extends Collection<E>> Predicate isNotMember(Expression<E> paramExpression, Expression<C> paramExpression1);
/*      */   
/*      */   <E, C extends Collection<E>> Predicate isNotMember(E paramE, Expression<C> paramExpression);
/*      */   
/*      */   <V, M extends java.util.Map<?, V>> Expression<Collection<V>> values(M paramM);
/*      */   
/*      */   <K, M extends java.util.Map<K, ?>> Expression<Set<K>> keys(M paramM);
/*      */   
/*      */   Predicate like(Expression<String> paramExpression1, Expression<String> paramExpression2);
/*      */   
/*      */   Predicate like(Expression<String> paramExpression, String paramString);
/*      */   
/*      */   Predicate like(Expression<String> paramExpression1, Expression<String> paramExpression2, Expression<Character> paramExpression);
/*      */   
/*      */   Predicate like(Expression<String> paramExpression1, Expression<String> paramExpression2, char paramChar);
/*      */   
/*      */   Predicate like(Expression<String> paramExpression, String paramString, Expression<Character> paramExpression1);
/*      */   
/*      */   Predicate like(Expression<String> paramExpression, String paramString, char paramChar);
/*      */   
/*      */   Predicate notLike(Expression<String> paramExpression1, Expression<String> paramExpression2);
/*      */   
/*      */   Predicate notLike(Expression<String> paramExpression, String paramString);
/*      */   
/*      */   Predicate notLike(Expression<String> paramExpression1, Expression<String> paramExpression2, Expression<Character> paramExpression);
/*      */   
/*      */   Predicate notLike(Expression<String> paramExpression1, Expression<String> paramExpression2, char paramChar);
/*      */   
/*      */   Predicate notLike(Expression<String> paramExpression, String paramString, Expression<Character> paramExpression1);
/*      */   
/*      */   Predicate notLike(Expression<String> paramExpression, String paramString, char paramChar);
/*      */   
/*      */   Expression<String> concat(Expression<String> paramExpression1, Expression<String> paramExpression2);
/*      */   
/*      */   Expression<String> concat(Expression<String> paramExpression, String paramString);
/*      */   
/*      */   Expression<String> concat(String paramString, Expression<String> paramExpression);
/*      */   
/*      */   Expression<String> substring(Expression<String> paramExpression, Expression<Integer> paramExpression1);
/*      */   
/*      */   Expression<String> substring(Expression<String> paramExpression, int paramInt);
/*      */   
/*      */   Expression<String> substring(Expression<String> paramExpression, Expression<Integer> paramExpression1, Expression<Integer> paramExpression2);
/*      */   
/*      */   Expression<String> substring(Expression<String> paramExpression, int paramInt1, int paramInt2);
/*      */   
/*      */   Expression<String> trim(Expression<String> paramExpression);
/*      */   
/*      */   Expression<String> trim(Trimspec paramTrimspec, Expression<String> paramExpression);
/*      */   
/*      */   Expression<String> trim(Expression<Character> paramExpression, Expression<String> paramExpression1);
/*      */   
/*      */   Expression<String> trim(Trimspec paramTrimspec, Expression<Character> paramExpression, Expression<String> paramExpression1);
/*      */   
/*      */   Expression<String> trim(char paramChar, Expression<String> paramExpression);
/*      */   
/*      */   Expression<String> trim(Trimspec paramTrimspec, char paramChar, Expression<String> paramExpression);
/*      */   
/*      */   Expression<String> lower(Expression<String> paramExpression);
/*      */   
/*      */   Expression<String> upper(Expression<String> paramExpression);
/*      */   
/*      */   Expression<Integer> length(Expression<String> paramExpression);
/*      */   
/*      */   Expression<Integer> locate(Expression<String> paramExpression1, Expression<String> paramExpression2);
/*      */   
/*      */   Expression<Integer> locate(Expression<String> paramExpression, String paramString);
/*      */   
/*      */   Expression<Integer> locate(Expression<String> paramExpression1, Expression<String> paramExpression2, Expression<Integer> paramExpression);
/*      */   
/*      */   Expression<Integer> locate(Expression<String> paramExpression, String paramString, int paramInt);
/*      */   
/*      */   Expression<Date> currentDate();
/*      */   
/*      */   Expression<Timestamp> currentTimestamp();
/*      */   
/*      */   Expression<Time> currentTime();
/*      */   
/*      */   Expression<LocalDate> localDate();
/*      */   
/*      */   Expression<LocalDateTime> localDateTime();
/*      */   
/*      */   Expression<LocalTime> localTime();
/*      */   
/*      */   <T> In<T> in(Expression<? extends T> paramExpression);
/*      */   
/*      */   <Y> Expression<Y> coalesce(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2);
/*      */   
/*      */   <Y> Expression<Y> coalesce(Expression<? extends Y> paramExpression, Y paramY);
/*      */   
/*      */   <Y> Expression<Y> nullif(Expression<Y> paramExpression, Expression<?> paramExpression1);
/*      */   
/*      */   <Y> Expression<Y> nullif(Expression<Y> paramExpression, Y paramY);
/*      */   
/*      */   <T> Coalesce<T> coalesce();
/*      */   
/*      */   <C, R> SimpleCase<C, R> selectCase(Expression<? extends C> paramExpression);
/*      */   
/*      */   <R> Case<R> selectCase();
/*      */   
/*      */   <T> Expression<T> function(String paramString, Class<T> paramClass, Expression<?>... paramVarArgs);
/*      */   
/*      */   <X, T, V extends T> Join<X, V> treat(Join<X, T> paramJoin, Class<V> paramClass);
/*      */   
/*      */   <X, T, E extends T> CollectionJoin<X, E> treat(CollectionJoin<X, T> paramCollectionJoin, Class<E> paramClass);
/*      */   
/*      */   <X, T, E extends T> SetJoin<X, E> treat(SetJoin<X, T> paramSetJoin, Class<E> paramClass);
/*      */   
/*      */   <X, T, E extends T> ListJoin<X, E> treat(ListJoin<X, T> paramListJoin, Class<E> paramClass);
/*      */   
/*      */   <X, K, T, V extends T> MapJoin<X, K, V> treat(MapJoin<X, K, T> paramMapJoin, Class<V> paramClass);
/*      */   
/*      */   <X, T extends X> Path<T> treat(Path<X> paramPath, Class<T> paramClass);
/*      */   
/*      */   <X, T extends X> Root<T> treat(Root<X> paramRoot, Class<T> paramClass);
/*      */   
/*      */   public static interface Case<R>
/*      */     extends Expression<R>
/*      */   {
/*      */     Case<R> when(Expression<Boolean> param1Expression, R param1R);
/*      */     
/*      */     Case<R> when(Expression<Boolean> param1Expression, Expression<? extends R> param1Expression1);
/*      */     
/*      */     Expression<R> otherwise(R param1R);
/*      */     
/*      */     Expression<R> otherwise(Expression<? extends R> param1Expression);
/*      */   }
/*      */   
/*      */   public static interface SimpleCase<C, R>
/*      */     extends Expression<R>
/*      */   {
/*      */     Expression<C> getExpression();
/*      */     
/*      */     SimpleCase<C, R> when(C param1C, R param1R);
/*      */     
/*      */     SimpleCase<C, R> when(C param1C, Expression<? extends R> param1Expression);
/*      */     
/*      */     SimpleCase<C, R> when(Expression<? extends C> param1Expression, R param1R);
/*      */     
/*      */     SimpleCase<C, R> when(Expression<? extends C> param1Expression, Expression<? extends R> param1Expression1);
/*      */     
/*      */     Expression<R> otherwise(R param1R);
/*      */     
/*      */     Expression<R> otherwise(Expression<? extends R> param1Expression);
/*      */   }
/*      */   
/*      */   public static interface Coalesce<T>
/*      */     extends Expression<T>
/*      */   {
/*      */     Coalesce<T> value(T param1T);
/*      */     
/*      */     Coalesce<T> value(Expression<? extends T> param1Expression);
/*      */   }
/*      */   
/*      */   public static interface In<T>
/*      */     extends Predicate
/*      */   {
/*      */     Expression<T> getExpression();
/*      */     
/*      */     In<T> value(T param1T);
/*      */     
/*      */     In<T> value(Expression<? extends T> param1Expression);
/*      */   }
/*      */   
/*      */   public enum Trimspec
/*      */   {
/* 1155 */     LEADING,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1160 */     TRAILING,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1165 */     BOTH;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\CriteriaBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */