package jakarta.persistence.criteria;

import jakarta.persistence.Parameter;

public interface ParameterExpression<T> extends Parameter<T>, Expression<T> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\ParameterExpression.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */