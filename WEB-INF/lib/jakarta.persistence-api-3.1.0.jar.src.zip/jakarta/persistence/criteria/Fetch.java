package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.Attribute;

public interface Fetch<Z, X> extends FetchParent<Z, X> {
  Attribute<? super Z, ?> getAttribute();
  
  FetchParent<?, Z> getParent();
  
  JoinType getJoinType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\Fetch.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */