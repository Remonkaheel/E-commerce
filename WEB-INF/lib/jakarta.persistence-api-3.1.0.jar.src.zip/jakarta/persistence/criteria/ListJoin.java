package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.Bindable;
import jakarta.persistence.metamodel.ListAttribute;
import jakarta.persistence.metamodel.PluralAttribute;
import java.util.List;

public interface ListJoin<Z, E> extends PluralJoin<Z, List<E>, E> {
  ListJoin<Z, E> on(Expression<Boolean> paramExpression);
  
  ListJoin<Z, E> on(Predicate... paramVarArgs);
  
  ListAttribute<? super Z, E> getModel();
  
  Expression<Integer> index();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\ListJoin.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */