package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.Bindable;
import jakarta.persistence.metamodel.PluralAttribute;

public interface PluralJoin<Z, C, E> extends Join<Z, E> {
  PluralAttribute<? super Z, C, E> getModel();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\PluralJoin.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */