package jakarta.persistence.criteria;

public interface CommonAbstractCriteria {
  <U> Subquery<U> subquery(Class<U> paramClass);
  
  Predicate getRestriction();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\CommonAbstractCriteria.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */