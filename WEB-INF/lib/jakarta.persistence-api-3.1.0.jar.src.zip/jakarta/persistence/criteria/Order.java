package jakarta.persistence.criteria;

public interface Order {
  Order reverse();
  
  boolean isAscending();
  
  Expression<?> getExpression();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\Order.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */