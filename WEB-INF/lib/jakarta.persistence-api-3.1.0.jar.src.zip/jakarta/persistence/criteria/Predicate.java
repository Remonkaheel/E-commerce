/*    */ package jakarta.persistence.criteria;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Predicate
/*    */   extends Expression<Boolean>
/*    */ {
/*    */   BooleanOperator getOperator();
/*    */   
/*    */   boolean isNegated();
/*    */   
/*    */   List<Expression<Boolean>> getExpressions();
/*    */   
/*    */   Predicate not();
/*    */   
/*    */   public enum BooleanOperator
/*    */   {
/* 32 */     AND, OR;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\Predicate.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */