package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.Bindable;
import jakarta.persistence.metamodel.PluralAttribute;
import jakarta.persistence.metamodel.SetAttribute;
import java.util.Set;

public interface SetJoin<Z, E> extends PluralJoin<Z, Set<E>, E> {
  SetJoin<Z, E> on(Expression<Boolean> paramExpression);
  
  SetJoin<Z, E> on(Predicate... paramVarArgs);
  
  SetAttribute<? super Z, E> getModel();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\SetJoin.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */