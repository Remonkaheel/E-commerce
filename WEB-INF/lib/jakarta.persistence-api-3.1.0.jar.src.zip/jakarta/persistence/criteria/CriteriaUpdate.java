package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.EntityType;
import jakarta.persistence.metamodel.SingularAttribute;

public interface CriteriaUpdate<T> extends CommonAbstractCriteria {
  Root<T> from(Class<T> paramClass);
  
  Root<T> from(EntityType<T> paramEntityType);
  
  Root<T> getRoot();
  
  <Y, X extends Y> CriteriaUpdate<T> set(SingularAttribute<? super T, Y> paramSingularAttribute, X paramX);
  
  <Y> CriteriaUpdate<T> set(SingularAttribute<? super T, Y> paramSingularAttribute, Expression<? extends Y> paramExpression);
  
  <Y, X extends Y> CriteriaUpdate<T> set(Path<Y> paramPath, X paramX);
  
  <Y> CriteriaUpdate<T> set(Path<Y> paramPath, Expression<? extends Y> paramExpression);
  
  CriteriaUpdate<T> set(String paramString, Object paramObject);
  
  CriteriaUpdate<T> where(Expression<Boolean> paramExpression);
  
  CriteriaUpdate<T> where(Predicate... paramVarArgs);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\CriteriaUpdate.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */