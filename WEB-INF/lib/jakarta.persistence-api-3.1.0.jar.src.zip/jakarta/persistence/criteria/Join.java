package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.Attribute;

public interface Join<Z, X> extends From<Z, X> {
  Join<Z, X> on(Expression<Boolean> paramExpression);
  
  Join<Z, X> on(Predicate... paramVarArgs);
  
  Predicate getOn();
  
  Attribute<? super Z, ?> getAttribute();
  
  From<?, Z> getParent();
  
  JoinType getJoinType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\Join.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */