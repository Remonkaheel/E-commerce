package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.Bindable;
import jakarta.persistence.metamodel.EntityType;

public interface Root<X> extends From<X, X> {
  EntityType<X> getModel();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\Root.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */