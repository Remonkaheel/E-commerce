package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.Bindable;
import jakarta.persistence.metamodel.CollectionAttribute;
import jakarta.persistence.metamodel.PluralAttribute;
import java.util.Collection;

public interface CollectionJoin<Z, E> extends PluralJoin<Z, Collection<E>, E> {
  CollectionJoin<Z, E> on(Expression<Boolean> paramExpression);
  
  CollectionJoin<Z, E> on(Predicate... paramVarArgs);
  
  CollectionAttribute<? super Z, E> getModel();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\CollectionJoin.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */