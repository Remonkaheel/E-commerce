package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.Bindable;
import jakarta.persistence.metamodel.MapAttribute;
import jakarta.persistence.metamodel.PluralAttribute;
import java.util.Map;

public interface MapJoin<Z, K, V> extends PluralJoin<Z, Map<K, V>, V> {
  MapJoin<Z, K, V> on(Expression<Boolean> paramExpression);
  
  MapJoin<Z, K, V> on(Predicate... paramVarArgs);
  
  MapAttribute<? super Z, K, V> getModel();
  
  Path<K> key();
  
  Path<V> value();
  
  Expression<Map.Entry<K, V>> entry();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\MapJoin.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */