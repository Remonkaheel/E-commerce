/*    */ package jakarta.persistence.criteria;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JoinType
/*    */ {
/* 31 */   INNER,
/*    */ 
/*    */   
/* 34 */   LEFT,
/*    */ 
/*    */   
/* 37 */   RIGHT;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\JoinType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */