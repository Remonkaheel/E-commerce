package jakarta.persistence.criteria;

import jakarta.persistence.metamodel.EntityType;

public interface CriteriaDelete<T> extends CommonAbstractCriteria {
  Root<T> from(Class<T> paramClass);
  
  Root<T> from(EntityType<T> paramEntityType);
  
  Root<T> getRoot();
  
  CriteriaDelete<T> where(Expression<Boolean> paramExpression);
  
  CriteriaDelete<T> where(Predicate... paramVarArgs);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\CriteriaDelete.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */