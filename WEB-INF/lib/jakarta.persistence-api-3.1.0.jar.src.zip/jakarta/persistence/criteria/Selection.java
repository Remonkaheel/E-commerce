package jakarta.persistence.criteria;

import jakarta.persistence.TupleElement;
import java.util.List;

public interface Selection<X> extends TupleElement<X> {
  Selection<X> alias(String paramString);
  
  boolean isCompoundSelection();
  
  List<Selection<?>> getCompoundSelectionItems();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\criteria\Selection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */