package jakarta.persistence;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Repeatable(SqlResultSetMappings.class)
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface SqlResultSetMapping {
  String name();
  
  EntityResult[] entities() default {};
  
  ConstructorResult[] classes() default {};
  
  ColumnResult[] columns() default {};
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\SqlResultSetMapping.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */