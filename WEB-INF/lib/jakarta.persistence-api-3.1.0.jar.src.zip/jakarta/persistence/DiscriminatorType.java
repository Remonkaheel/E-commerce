/*    */ package jakarta.persistence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum DiscriminatorType
/*    */ {
/* 29 */   STRING,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   CHAR,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   INTEGER;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\DiscriminatorType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */