package jakarta.persistence;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

public interface StoredProcedureQuery extends Query {
  StoredProcedureQuery setHint(String paramString, Object paramObject);
  
  <T> StoredProcedureQuery setParameter(Parameter<T> paramParameter, T paramT);
  
  StoredProcedureQuery setParameter(Parameter<Calendar> paramParameter, Calendar paramCalendar, TemporalType paramTemporalType);
  
  StoredProcedureQuery setParameter(Parameter<Date> paramParameter, Date paramDate, TemporalType paramTemporalType);
  
  StoredProcedureQuery setParameter(String paramString, Object paramObject);
  
  StoredProcedureQuery setParameter(String paramString, Calendar paramCalendar, TemporalType paramTemporalType);
  
  StoredProcedureQuery setParameter(String paramString, Date paramDate, TemporalType paramTemporalType);
  
  StoredProcedureQuery setParameter(int paramInt, Object paramObject);
  
  StoredProcedureQuery setParameter(int paramInt, Calendar paramCalendar, TemporalType paramTemporalType);
  
  StoredProcedureQuery setParameter(int paramInt, Date paramDate, TemporalType paramTemporalType);
  
  StoredProcedureQuery setFlushMode(FlushModeType paramFlushModeType);
  
  StoredProcedureQuery registerStoredProcedureParameter(int paramInt, Class paramClass, ParameterMode paramParameterMode);
  
  StoredProcedureQuery registerStoredProcedureParameter(String paramString, Class paramClass, ParameterMode paramParameterMode);
  
  Object getOutputParameterValue(int paramInt);
  
  Object getOutputParameterValue(String paramString);
  
  boolean execute();
  
  int executeUpdate();
  
  List getResultList();
  
  Object getSingleResult();
  
  boolean hasMoreResults();
  
  int getUpdateCount();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\StoredProcedureQuery.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */