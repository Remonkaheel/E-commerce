/*    */ package jakarta.persistence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TemporalType
/*    */ {
/* 28 */   DATE,
/*    */ 
/*    */   
/* 31 */   TIME,
/*    */ 
/*    */   
/* 34 */   TIMESTAMP;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\TemporalType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */