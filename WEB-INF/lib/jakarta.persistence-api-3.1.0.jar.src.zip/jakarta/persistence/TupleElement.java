package jakarta.persistence;

public interface TupleElement<X> {
  Class<? extends X> getJavaType();
  
  String getAlias();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\TupleElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */