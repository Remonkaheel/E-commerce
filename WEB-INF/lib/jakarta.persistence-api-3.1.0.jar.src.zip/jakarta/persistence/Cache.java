package jakarta.persistence;

public interface Cache {
  boolean contains(Class paramClass, Object paramObject);
  
  void evict(Class paramClass, Object paramObject);
  
  void evict(Class paramClass);
  
  void evictAll();
  
  <T> T unwrap(Class<T> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\Cache.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */