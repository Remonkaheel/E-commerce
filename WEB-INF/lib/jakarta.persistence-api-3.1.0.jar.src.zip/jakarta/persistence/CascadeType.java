/*    */ package jakarta.persistence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CascadeType
/*    */ {
/* 30 */   ALL,
/*    */ 
/*    */   
/* 33 */   PERSIST,
/*    */ 
/*    */   
/* 36 */   MERGE,
/*    */ 
/*    */   
/* 39 */   REMOVE,
/*    */ 
/*    */   
/* 42 */   REFRESH,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   DETACH;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\CascadeType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */