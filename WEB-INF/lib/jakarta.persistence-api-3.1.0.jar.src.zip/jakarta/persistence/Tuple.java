package jakarta.persistence;

import java.util.List;

public interface Tuple {
  <X> X get(TupleElement<X> paramTupleElement);
  
  <X> X get(String paramString, Class<X> paramClass);
  
  Object get(String paramString);
  
  <X> X get(int paramInt, Class<X> paramClass);
  
  Object get(int paramInt);
  
  Object[] toArray();
  
  List<TupleElement<?>> getElements();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\Tuple.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */