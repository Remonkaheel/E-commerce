package jakarta.persistence.metamodel;

import java.util.Set;

public interface IdentifiableType<X> extends ManagedType<X> {
  <Y> SingularAttribute<? super X, Y> getId(Class<Y> paramClass);
  
  <Y> SingularAttribute<X, Y> getDeclaredId(Class<Y> paramClass);
  
  <Y> SingularAttribute<? super X, Y> getVersion(Class<Y> paramClass);
  
  <Y> SingularAttribute<X, Y> getDeclaredVersion(Class<Y> paramClass);
  
  IdentifiableType<? super X> getSupertype();
  
  boolean hasSingleIdAttribute();
  
  boolean hasVersionAttribute();
  
  Set<SingularAttribute<? super X, ?>> getIdClassAttributes();
  
  Type<?> getIdType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\IdentifiableType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */