package jakarta.persistence.metamodel;

import java.util.Collection;

public interface CollectionAttribute<X, E> extends PluralAttribute<X, Collection<E>, E> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\CollectionAttribute.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */