package jakarta.persistence.metamodel;

import java.util.Set;

public interface Metamodel {
  <X> EntityType<X> entity(Class<X> paramClass);
  
  <X> ManagedType<X> managedType(Class<X> paramClass);
  
  <X> EmbeddableType<X> embeddable(Class<X> paramClass);
  
  Set<ManagedType<?>> getManagedTypes();
  
  Set<EntityType<?>> getEntities();
  
  Set<EmbeddableType<?>> getEmbeddables();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\Metamodel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */