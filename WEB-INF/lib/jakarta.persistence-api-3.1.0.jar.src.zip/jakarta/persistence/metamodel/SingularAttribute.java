package jakarta.persistence.metamodel;

public interface SingularAttribute<X, T> extends Attribute<X, T>, Bindable<T> {
  boolean isId();
  
  boolean isVersion();
  
  boolean isOptional();
  
  Type<T> getType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\SingularAttribute.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */