/*    */ package jakarta.persistence.metamodel;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Attribute<X, Y>
/*    */ {
/*    */   String getName();
/*    */   
/*    */   PersistentAttributeType getPersistentAttributeType();
/*    */   
/*    */   ManagedType<X> getDeclaringType();
/*    */   
/*    */   Class<Y> getJavaType();
/*    */   
/*    */   Member getJavaMember();
/*    */   
/*    */   boolean isAssociation();
/*    */   
/*    */   boolean isCollection();
/*    */   
/*    */   public enum PersistentAttributeType
/*    */   {
/* 32 */     MANY_TO_ONE,
/*    */ 
/*    */     
/* 35 */     ONE_TO_ONE,
/*    */ 
/*    */     
/* 38 */     BASIC,
/*    */ 
/*    */     
/* 41 */     EMBEDDED,
/*    */ 
/*    */     
/* 44 */     MANY_TO_MANY,
/*    */ 
/*    */     
/* 47 */     ONE_TO_MANY,
/*    */ 
/*    */     
/* 50 */     ELEMENT_COLLECTION;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\Attribute.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */