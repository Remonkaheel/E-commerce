package jakarta.persistence.metamodel;

public interface MappedSuperclassType<X> extends IdentifiableType<X> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\MappedSuperclassType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */