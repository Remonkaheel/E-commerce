package jakarta.persistence.metamodel;

import java.util.Set;

public interface SetAttribute<X, E> extends PluralAttribute<X, Set<E>, E> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\SetAttribute.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */