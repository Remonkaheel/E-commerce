/*    */ package jakarta.persistence.metamodel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Bindable<T>
/*    */ {
/*    */   BindableType getBindableType();
/*    */   
/*    */   Class<T> getBindableJavaType();
/*    */   
/*    */   public enum BindableType
/*    */   {
/* 35 */     SINGULAR_ATTRIBUTE,
/*    */ 
/*    */     
/* 38 */     PLURAL_ATTRIBUTE,
/*    */ 
/*    */     
/* 41 */     ENTITY_TYPE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\Bindable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */