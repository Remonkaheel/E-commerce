/*    */ package jakarta.persistence.metamodel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PluralAttribute<X, C, E>
/*    */   extends Attribute<X, C>, Bindable<E>
/*    */ {
/*    */   CollectionType getCollectionType();
/*    */   
/*    */   Type<E> getElementType();
/*    */   
/*    */   public enum CollectionType
/*    */   {
/* 35 */     COLLECTION,
/*    */ 
/*    */     
/* 38 */     SET,
/*    */ 
/*    */     
/* 41 */     LIST,
/*    */ 
/*    */     
/* 44 */     MAP;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\PluralAttribute.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */