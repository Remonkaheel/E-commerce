package jakarta.persistence.metamodel;

import java.util.List;

public interface ListAttribute<X, E> extends PluralAttribute<X, List<E>, E> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\ListAttribute.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */