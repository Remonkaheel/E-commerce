package jakarta.persistence.metamodel;

import java.util.Map;

public interface MapAttribute<X, K, V> extends PluralAttribute<X, Map<K, V>, V> {
  Class<K> getKeyJavaType();
  
  Type<K> getKeyType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\MapAttribute.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */