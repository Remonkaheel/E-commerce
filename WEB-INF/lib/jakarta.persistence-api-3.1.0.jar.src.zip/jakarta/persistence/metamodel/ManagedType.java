package jakarta.persistence.metamodel;

import java.util.Set;

public interface ManagedType<X> extends Type<X> {
  Set<Attribute<? super X, ?>> getAttributes();
  
  Set<Attribute<X, ?>> getDeclaredAttributes();
  
  <Y> SingularAttribute<? super X, Y> getSingularAttribute(String paramString, Class<Y> paramClass);
  
  <Y> SingularAttribute<X, Y> getDeclaredSingularAttribute(String paramString, Class<Y> paramClass);
  
  Set<SingularAttribute<? super X, ?>> getSingularAttributes();
  
  Set<SingularAttribute<X, ?>> getDeclaredSingularAttributes();
  
  <E> CollectionAttribute<? super X, E> getCollection(String paramString, Class<E> paramClass);
  
  <E> CollectionAttribute<X, E> getDeclaredCollection(String paramString, Class<E> paramClass);
  
  <E> SetAttribute<? super X, E> getSet(String paramString, Class<E> paramClass);
  
  <E> SetAttribute<X, E> getDeclaredSet(String paramString, Class<E> paramClass);
  
  <E> ListAttribute<? super X, E> getList(String paramString, Class<E> paramClass);
  
  <E> ListAttribute<X, E> getDeclaredList(String paramString, Class<E> paramClass);
  
  <K, V> MapAttribute<? super X, K, V> getMap(String paramString, Class<K> paramClass, Class<V> paramClass1);
  
  <K, V> MapAttribute<X, K, V> getDeclaredMap(String paramString, Class<K> paramClass, Class<V> paramClass1);
  
  Set<PluralAttribute<? super X, ?, ?>> getPluralAttributes();
  
  Set<PluralAttribute<X, ?, ?>> getDeclaredPluralAttributes();
  
  Attribute<? super X, ?> getAttribute(String paramString);
  
  Attribute<X, ?> getDeclaredAttribute(String paramString);
  
  SingularAttribute<? super X, ?> getSingularAttribute(String paramString);
  
  SingularAttribute<X, ?> getDeclaredSingularAttribute(String paramString);
  
  CollectionAttribute<? super X, ?> getCollection(String paramString);
  
  CollectionAttribute<X, ?> getDeclaredCollection(String paramString);
  
  SetAttribute<? super X, ?> getSet(String paramString);
  
  SetAttribute<X, ?> getDeclaredSet(String paramString);
  
  ListAttribute<? super X, ?> getList(String paramString);
  
  ListAttribute<X, ?> getDeclaredList(String paramString);
  
  MapAttribute<? super X, ?, ?> getMap(String paramString);
  
  MapAttribute<X, ?, ?> getDeclaredMap(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\ManagedType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */