/*    */ package jakarta.persistence.metamodel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Type<X>
/*    */ {
/*    */   PersistenceType getPersistenceType();
/*    */   
/*    */   Class<X> getJavaType();
/*    */   
/*    */   public enum PersistenceType
/*    */   {
/* 32 */     ENTITY,
/*    */ 
/*    */     
/* 35 */     EMBEDDABLE,
/*    */ 
/*    */     
/* 38 */     MAPPED_SUPERCLASS,
/*    */ 
/*    */     
/* 41 */     BASIC;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\metamodel\Type.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */