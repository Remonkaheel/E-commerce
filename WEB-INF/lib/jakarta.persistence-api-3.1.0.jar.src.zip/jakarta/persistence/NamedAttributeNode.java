package jakarta.persistence;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({})
@Retention(RetentionPolicy.RUNTIME)
public @interface NamedAttributeNode {
  String value();
  
  String subgraph() default "";
  
  String keySubgraph() default "";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.persistence-api-3.1.0.jar!\jakarta\persistence\NamedAttributeNode.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */